package com.jonas.tubiao.view;

/**
 * @author jiangzuyun.
 * @date 2017/2/25
 * @des [一句话描述]
 * @since [产品/模版版本]
 */


public class UnitUtil {
    public static String getNumberFormat(int i, int i1, int i2) {
        return i + "";
    }
}
