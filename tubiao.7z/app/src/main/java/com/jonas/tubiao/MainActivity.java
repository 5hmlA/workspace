package com.jonas.tubiao;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.jonas.tubiao.view.SugChart;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private TextView mSugTvTbHeartrate;
    private TextView mSugTvTbHeartbig;
    private SugChart mSugScJHeart;
    private SugChart mSugScJHeartPie;
    private TextView mSugTvHotbody;
    private TextView mSugTvBurn;
    private TextView mSugTvAnaerobic;
    private TextView mSugTvAerobic;
    private TextView mSugTvLimit;
    private TextView mSugTvTbBupinrate;
    private TextView mSugTvTbBupinbig;
    private SugChart mSugScJBupin;
    private ArrayList<SugChart.SugExcel> mHeartSugExcels;
    private LinearLayout mSugllsccontent;
    private ArrayList<SugChart.SugExcel> mStepSugExcels;
    private ArrayList<Integer> mTotaldate;
    private int mLastTime = -1;
    private int mAllowPoints;
    private int mGetDataStep;

    private void assignViews() {
        mSugTvTbHeartrate = (TextView) findViewById(R.id.sug_tv_tb_heartrate);
        mSugllsccontent = (LinearLayout) findViewById(R.id.sug_ll_sc_content);
        mSugTvTbHeartbig = (TextView) findViewById(R.id.sug_tv_tb_heartbig);
        mSugScJHeart = (SugChart) findViewById(R.id.sug_sc_j_heart);
        mSugScJHeartPie = (SugChart) findViewById(R.id.sug_sc_j_heart_pie);
        mSugTvHotbody = (TextView) findViewById(R.id.sug_tv_hotbody);
        mSugTvBurn = (TextView) findViewById(R.id.sug_tv_burn);
        mSugTvAnaerobic = (TextView) findViewById(R.id.sug_tv_anaerobic);
        mSugTvAerobic = (TextView) findViewById(R.id.sug_tv_aerobic);
        mSugTvLimit = (TextView) findViewById(R.id.sug_tv_limit);
        mSugTvTbBupinrate = (TextView) findViewById(R.id.sug_tv_tb_bupinrate);
        mSugTvTbBupinbig = (TextView) findViewById(R.id.sug_tv_tb_bupinbig);
        mSugScJBupin = (SugChart) findViewById(R.id.sug_sc_j_bupin);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sug_fm_detail_heartrate);
        assignViews();

        mTotaldate = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            mTotaldate.add(new Random().nextInt(100) + 60);
        }

        mSugScJHeart.setChartStyle(SugChart.ChartStyle.LINE);
        mSugScJHeart.setYaxisValues(0, 200, 2);
        mSugScJHeart.setLineWidth(getResources().getDimension(R.dimen.linewidth));
        mSugScJHeart.setAbscissaMsgColor(Color.parseColor("#50000000"));
        mSugScJHeart.setAbscissaMsgSize(getResources().getDimension(R.dimen.absmsgsize));
        mSugScJHeart.setExecelPaintShaderColors(Color.parseColor("#80ff3320"), Color.parseColor("#ffbf55"), Color.parseColor("#f7eb57"), Color.parseColor("#b8e986"), Color.parseColor("#73c0fd"));


        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) mSugScJBupin.getLayoutParams();
        int chartWidth = getWindowManager().getDefaultDisplay().getWidth()-layoutParams.leftMargin-layoutParams.rightMargin;
        float ySize = getResources().getDimension(R.dimen.absmsgsize)*"100".length();
        float lineWidth = getResources().getDimension(R.dimen.linewidth);
        mAllowPoints = (int) ((chartWidth-ySize-mSugScJBupin.getPaddingLeft())/lineWidth);
        System.out.println(chartWidth+"----"+ySize+"------"+lineWidth+"-----"+mAllowPoints);
//        mAllowPoints = 107;

        mGetDataStep = mTotaldate.size()/mAllowPoints;
        mGetDataStep = mGetDataStep>0?mGetDataStep:1;
        analyzeStep();

        SugChart.SugExcel hotbody = new SugChart.SugExcel(Color.parseColor("#73c0fd"), 50, "测试");
        SugChart.SugExcel burn = new SugChart.SugExcel(Color.parseColor("#b8e986"), 50, "测试");
        SugChart.SugExcel anaerobic = new SugChart.SugExcel(Color.parseColor("#f7eb57"), 50, "测试");
        SugChart.SugExcel aerobic = new SugChart.SugExcel(Color.parseColor("#ffbf55"), 50, "测试");
        SugChart.SugExcel limit = new SugChart.SugExcel(Color.RED, 50, "测试");
        mSugScJHeartPie.setChartStyle(SugChart.ChartStyle.PIE);
        mSugScJHeartPie.setPieWidth(mSugScJHeartPie.dip2px(30));
        mSugScJHeartPie.cmdFill(hotbody, burn, anaerobic, aerobic, limit);

        mStepSugExcels = new ArrayList<>();
        for (int i = 0; i < 25; i++) {
            SugChart.SugExcel sugExcel = null;
            if (i % 20 == 0) {
                sugExcel = new SugChart.SugExcel(new Random().nextInt(40) + 100, "" + i);
            } else {
                sugExcel = new SugChart.SugExcel(new Random().nextInt(40) + 100, "");

            }
            mStepSugExcels.add(sugExcel);
        }
        mSugScJBupin.setChartStyle(SugChart.ChartStyle.LINE);
        mSugScJBupin.setYaxisValues(0, 200, 4);
        mSugScJBupin.setLineWidth(getResources().getDimension(R.dimen.linewidth));
        mSugScJBupin.setAbscissaMsgColor(Color.parseColor("#50000000"));
        mSugScJBupin.setAbscissaMsgSize(getResources().getDimension(R.dimen.absmsgsize));
        mSugScJBupin.setNormalColor(Color.parseColor("#80ff3320"));
        mSugScJBupin.cmdFill(mStepSugExcels);
    }

    /**
     * 根据点的个数 和 获取心率数据的时间间隔 获取 指定心率点的时间长度
     *
     * @param total    指定心率点个数
     * @param interval 获取心率数据的时间间隔
     * @return
     */
    private float total2min(float total, float interval) {
        return ((total-1) * interval / 60);
//        return (int) ((total-1) * interval / 60);
    }

    private int getRound5(float num) {
        return ((int) (num + 2.5f)) / 5 * 5;
    }

    /**
     * 根据时间 判断显示多少段,
     */
    private void analyzeStep() {
        ArrayList<Float> remainds = new ArrayList<>(); //5,4,3
        float total = total2min(mTotaldate.size(), 60);
        System.out.println("点个数：" + mTotaldate.size() + "----时间：" + total+"....."+total*60);
        if (total >= 60) {
            float _5 = total / 5;
            if (total % 5 == 0) {
                arrangeHeartData(5, (int) _5);
                return;
            }
            float _4 = total / 4;
            if (total % 5 == 0) {
                arrangeHeartData(4, (int) _4);
                return;
            }
            float _3 = total / 3;
            if (total % 5 == 0) {
                arrangeHeartData(3, (int) _3);
                return;
            }
            remainds.add(Math.abs(_5 - getRound5(_5)));
            remainds.add(Math.abs(_4 - getRound5(_4)));
            remainds.add(Math.abs(_3 - getRound5(_3)));

            Float min = Collections.min(remainds);
            for (int i = 0; i < remainds.size(); i++) {
                if (min == remainds.get(i)) {
                    arrangeHeartData(5 - i, getRound5(total / (5 - i)));
                }
            }
        } else {
            float _5 = total / 5;
            if (total % 5 == 0) {
                arrangeHeartData(5, (int) _5);
                return;
            }
            float _4 = total / 4;
            if (total % 5 == 0) {
                arrangeHeartData(4, (int) _4);
                return;
            }
            float _3 = total / 3;
            if (total % 5 == 0) {
                arrangeHeartData(3, (int) _3);
                return;
            }
            remainds.add(Math.abs(_5 - Math.round(_5)));
            remainds.add(Math.abs(_4 - Math.round(_4)));
            remainds.add(Math.abs(_3 - Math.round(_3)));

            Float min = Collections.min(remainds);
            for (int i = 0; i < remainds.size(); i++) {
                if (min == remainds.get(i)) {
                    arrangeHeartData(5 - i, Math.round(total / (5 - i)));
                }
            }
        }
    }

    /**
     * @param graph    多少段
     * @param interval 每段多上时间 分钟
     */
    private void arrangeHeartData(int graph, int interval) {
        interval = interval > 0 ? interval : 1;
        mAllowPoints = mTotaldate.size() > mAllowPoints ? mAllowPoints : mTotaldate.size();
        //曲数据的间隔
        int step = mGetDataStep;
        int showInterval = 0;
        System.out.println("取数间隔：" + step + "======分几组：" + graph + "---每组时间" + interval);

        int pointInterval = mAllowPoints / graph;


        mHeartSugExcels = new ArrayList<>();
        for (int i = 0; i < mTotaldate.size(); i++) {
            if (i % step == 0 && mHeartSugExcels.size() < mAllowPoints) {
                SugChart.SugExcel sugExcel = new SugChart.SugExcel(mTotaldate.get(i), "");
                mHeartSugExcels.add(sugExcel);
            }
        }

        int lastSec = 1;
        for (int i = 0; i < mHeartSugExcels.size(); i++) {
            int sec = i * step * 60 % (interval * 60);
            if (lastSec > sec) {
                mHeartSugExcels.get(i).setXmsg(showInterval + "");
                showInterval += interval;
            }
            lastSec = sec;
//            if (i*step*60 % (interval*60) <= 0) {
//                mHeartSugExcels.get(i).setXmsg(showInterval + "");
//                showInterval += interval;
//            }
        }

        System.out.println("实际取到的点个数>>" + mHeartSugExcels.size());

        mSugScJHeart.cmdFill(mHeartSugExcels);


        Collections.sort(mTotaldate);
        for (Integer integer : mTotaldate) {
            System.out.println(integer);
        }
        mTotaldate.clear();

    }


    public void addCustomView(View view) {

        mSugllsccontent.addView(view);
    }
}
