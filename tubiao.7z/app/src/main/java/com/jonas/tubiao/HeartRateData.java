package com.jonas.tubiao;

import java.io.Serializable;

/**
 * 轨迹心率数据 <功能详细描述>
 * 
 */
public class HeartRateData implements Serializable {
    private static final long serialVersionUID = -6019653484064737738L;
    
    /**
     * 心率对应时间
     */
    private long time;
    
    /**
     * 心率值
     */
    private int heartRate;

    public HeartRateData() {
    }

    public HeartRateData(long time, int heartRate) {
        this.time = time;
        this.heartRate = heartRate;
    }

    public long getTime()
    {
        return time;
    }
    
    public void setTime(long time)
    {
        this.time = time;
    }
    
    public int getHeartRate()
    {
        return heartRate;
    }
    
    public void setHeartRate(int  heartRate)
    {
        this.heartRate = heartRate;
    }
    
    @Override
    public String toString()
    {
        return "HeartRateData [time=" + time + ", heartRate=" + heartRate + "]";
    }

}
