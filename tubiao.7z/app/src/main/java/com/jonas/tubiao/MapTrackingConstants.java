package com.jonas.tubiao;

import android.graphics.Color;

public class MapTrackingConstants {
    private static final boolean IS_SHOW_DATA_ANIMA_ENABLE = true;

    public static final String MAP_TRACKING_PIC_FILE = "tracking.png";
    public static final String MAP_TRACKING_PIC_DIR = "/HealthApp/track";

    public static final int ONE_TO_KILO = 1000;
    public static final int DEFAULT_ANIMATE_CAMERA_TIME = 1000;

    public static final float LOCATION_STRAT_INTERMISSION = 3f;
    public static final long LOCATION_INTERMISSION = 2000; // time
    public static final int LOCATION_INTERVAL = 10; // distance

    public static final int MARKER_TYPE_START = 0;
    public static final int MARKER_TYPE_END = 1;
    public static final int MARKER_TYPE_MID = 2;

    public static final int SHARE_MODE_WEIXIN = 0;
    public static final int SHARE_MODE_FRIENDS = 1;
    public static final int SHARE_MODE_WEIBO = 2;

    public static final int TRACKING_WIDTH = 29;//12; // 7dp //18
    public static final int TRACKING_COLOR_WIDTH = 12;
    public static final int TRACKING_DOT_WIDTH = 15 ; //虚线的宽度 10
    
    public static final int TRACKING_WIDTH_SMALL = 12;//24;//12; // 7dp //18
    public static final int TRACKING_DOT_WIDTH_SMALL = 8 ; //虚线的宽度 10
    
    public static final int SPORT_TRACKING_COLOR = Color.parseColor("#0da0ed");//Color.parseColor("#FF3861");
    public static final float SPORT_TRACKING_Z_INDEX = 1.0f;
    public static final int PAUSE_TRACKING_COLOR = Color.parseColor("#7f000000");//Color.YELLOW;
    public static final float PAUSE_TRACKING_Z_INDEX = 1.0f;
    public static final float COLOR_TRACK_ZINDEX = 3.0f;

    public static final int SPORTS_STATUS_IDLE = 1;
    public static final int SPORTS_STATUS_SPORTING = 2;
    public static final int SPORTS_STATUS_PAUSE = 3;
    public static final int SPORTS_STATUS_STOP = 4;

    public static final float INITIAL_ZOOM_LEVEL = 16.5f;//19.0F;//18.0F;

    public static boolean isShowDataAnimaEnable() {
        return IS_SHOW_DATA_ANIMA_ENABLE;
    }

    public static final int UPDATE_TIME_INTERAL = 1000;

    public static final float GPS_SIGNAL_THRESHOLD = 30.0f;//35.0f;
    
    public static final float GPS_SIGNAL_WEAK = 20f;

    public static final int GPS_SATELLITES_MIN_NUM = 4;
    
    public static final int GPS_SATELLITES_NORMAL_NUM = 9;//11;//15;
    
    public static final int GPS_SATELLITES_STRONG_NUM = 11;//15;
    
    public static final int GPS_SATELLITES_THRESHOLD_NUM = 15;

    public static final String GPS_MAPTRACKING_VERSION = "v1.0";

    public static final String GPS_PRODUCT_NAME = "gps_maptracking";

    public static final int MIN_DISTANCE_SAVABLE = 10; // 10 meters

    public static final int MIN_SPORT_TIME_SAVABLE = 20; // 20 seconds

    public static final int MIN_POINT_NUM_SAVABLE = 4;//16; // 16 points

    public static final int MIN_CALORIE_SAVABLE = 24288;

    public static final int MAP_SHOT_WIDTH = 720;

    public static final int MAP_SHOT_HEIGHT = 300;

    public static final int MAP_SHOT_COMPRESS_OPTION = 30;

    public static final int MARGIN_SPORT_MAP_VIEW = 200;//160;
    
    public static final int MARGIN_SHARE_MAP_VIEW = 200;

    // if location accuracy bigger than GPS_LOCATION_ACCURACY_LIMIT, we think
    // the location not available
    public static final float GPS_LOCATION_ACCURACY_LIMIT = 35f;//25f;//32f; // meter

    public static final float GPS_LOCATION_ACCURACY_IDLE_LIMIT = 70f; // meter

    public static final float INVALIDE_LOCATION_ACCURACY = 0.0f;

    public static final boolean isKmMarkerNeeded = false;

    // grade of urban air quality
    public static final int AIR_QUALITY_GREAT = 0;

    public static final int AIR_QUALITY_GOOD = 50;

    public static final int AIR_QUALITY_LIGHT_POLLUTION = 100;

    public static final int AIR_QUALITY_MIDDLE_POLLUTION = 200;

    public static final int AIR_QUALITY_HEAVY_POLLUTION = 300;
    
    public static final float LOCATION_MAX_SPEED_KMPH = 120f;
    
    public static final float LOCATION_MIN_SPEED_KMPH = 3f;
    
    public static final float DISTANCE_MIN_INTERVAL_WALK = 3f;
    
    public static final float DISTANCE_MIN_INTERVAL_RUN = 4f;
    
    public static final float DISTANCE_MIN_INTERVAL_BYKE = 6f;
    
    public static final String MOCK_PROVIDER = "GpsMockProvider";
    
    public static final int BACK_RETURN_ACTIVITY_EXIT = 1;
    public static final int START_SPORT_ACTIVITY_EXIT = 3;

    public static final int SHARE_PICTRUE_1 = 1;
    public static final int SHARE_PICTRUE_2 = 2;
    public static final int SHARE_PICTRUE_3 = 3;
    public static final int SHARE_PICTRUE_4 = 4;
    public static final int SHARE_PICTRUE_5 = 5;

    public static final int HEART_RATE_SPAN_TIME = 15;

    public static final int SPORT_TRACKING_COLOR_FAST = Color.parseColor("#FF0000");

    public static final int SPORT_TRACKING_COLOR_NORMAL = Color.parseColor("#FFFF00");

    public static final int SPORT_TRACKING_COLOR_SLOW = Color.parseColor("#00FF00");

    //运动建议
    public static final int SUGGEST_TYPE = 1;
    public static final int REGURAL_TYPE = 0;
    /**
     * 速度 12kmph -> 配速 5min
     */
    public static final int SPORT_BIKE_FAST = 12;

    /**
     * 速度 10kmph -> 配速 6min
     */
    public static final int SPORT_BIKE_NORMAL = 10;

    /**
     * 速度 10kmph -> 配速 6min
     */
    public static final int SPORT_RUN_FAST = 10;

    /**
     * 速度 6kmph -> 配速 10min
     */
    public static final int SPORT_RUN_NORMAL = 6;

    /**
     * 速度 8kmph -> 配速 7min30sec
     */
    public static final int SPORT_WALK_FAST = 8;

    /**
     * 速度 5kmph -> 配速 12min
     */
    public static final int SPORT_WALK_NORMAL = 5;

    /**
     * 轨迹点数据数量级
     */
    public static final int MAX_POINT_VALUE_RANK = 100000;

    /**
     * 轨迹配速公里数量级
     */
    public static final int MAX_PACE_VALUE_RANK = 214;

}
