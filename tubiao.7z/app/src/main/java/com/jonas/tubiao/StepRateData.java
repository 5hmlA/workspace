package com.jonas.tubiao;

import java.io.Serializable;

/**
 * 轨迹步频数据 <功能详细描述>
 *  
 */
public class StepRateData implements Serializable
{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -1186336294220451546L;

    /**
     * 对应时间
     */
    private long time;
    
    /**
     * 步频值
     */
    private int setpRate;

    public StepRateData() {
    }

    public StepRateData(long time, int setpRate) {
        this.time = time;
        this.setpRate = setpRate;
    }

    public long getTime()
    {
        return time;
    }
    
    public void setTime(long time)
    {
        this.time = time;
    }
    
    public int getStepRate()
    {
        return setpRate;
    }
    
    public void setStepRate(int  setpRate)
    {
        this.setpRate = setpRate;
    }
    
    @Override
    public String toString()
    {
        return "StepRateData [time=" + time + ", stepRate=" + setpRate + "]";
    }
}
