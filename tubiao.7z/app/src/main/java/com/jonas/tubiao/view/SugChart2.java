//package com.huawei.healthcloud.plugintrack.ui.view;
//
//import android.animation.ValueAnimator;
//import android.content.Context;
//import android.graphics.Canvas;
//import android.graphics.Color;
//import android.graphics.DashPathEffect;
//import android.graphics.LinearGradient;
//import android.graphics.Paint;
//import android.graphics.Path;
//import android.graphics.PointF;
//import android.graphics.Rect;
//import android.graphics.RectF;
//import android.graphics.Shader;
//import android.support.annotation.NonNull;
//import android.util.AttributeSet;
//import android.view.View;
//import android.view.animation.AccelerateDecelerateInterpolator;
//
//import com.huawei.healthcloud.plugintrack.R;
//import com.huawei.hwbasemgr.LanguageUtil;
//import com.huawei.hwbasemgr.UnitUtil;
//import com.huawei.hwlogsmodel.LogUtil;
//
//import java.text.DecimalFormat;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.Comparator;
//import java.util.List;
//
//import static com.huawei.healthcloud.plugintrack.manager.utils.RateDataHelper.HEARTRATELIMIT;
//
//public class SugChart extends View {
//
//    private static final String TAG = "Track_SugChart";
//    private float mLineWidth = 0;
//    private int mWidth;
//    private int mHeight;
//
//    /**
//     * 横轴 y坐标
//     */
//    private float mHCoordinate = 0;
//
//    /**
//     * x轴 柱状图 在x轴上方
//     */
//    private float mAbove;
//
//    private Paint mTextPaint;
//
//    /**
//     * 选中的 柱状图
//     */
////    private int mSelected = -1;
////    private float mDownX;
////    private boolean moved;
//    private Paint mLinePaint;
//    private float mTextSize = 15;
//    //    private float mSugHeightest;
//    private float mHeightRatio;
//    /**
//     * 横坐标 信息颜色
//     */
//    private int mAbscissaMsgColor = Color.parseColor("#556A73");
//    /**
//     * 渐变色
//     */
//    private int[] mShaderColors;
//    private int mLineColor = Color.parseColor("#ffe9d1ba");
//    private float mAbscissaMsgSize;
//    /**
//     * 画横坐标信息
//     */
//    private Paint mAbscissaPaint;
//    /**
//     * 折线 中 折点 圆的半径
//     */
////    private float mLinePointRadio;
//    private Paint mCoordinatePaint;
//    private float phase = 1;
//    private Path mLinepath = new Path();
//    private Path mLineAreapath = new Path();
//    private float mYaxis_Max;
//    private float mYaxis_min;
//    private float mYaxis_showYnum;
//    private float padingY;
//    /**
//     * 最大值文字高度
//     */
//    private int mYaxis_MaxHeight;
//    private Paint mAbscisDashPaint;
//    private PointF mCenterPoint;
//    private Paint mIntervalPaint;
//    private Paint mPiePaint;
//    private RectF mAecRect;
//    private int mIntervalColor;
//    private float pieWidth = 10;
//    private float mIntervalWidth;
//    private float mStartAnger;
//    private float mArcRadio;
//    private float dataTotal;
//    private boolean mYaxiShow;
//    private int mXNums;
//    private int mXInter;
//    private float mTotalTime;
//    private boolean mDrawo;
//    private boolean mSHowRegion;
//    private SugExcel mSugButtom;
//    private SugExcel mSugTop;
//    private Paint mCalloutBgPaint;
//    private Paint mCalloutPaint;
//    private float[] mHeartRateZone = new float[6];//big -- smal
//    private ValueAnimator mValueAnimator;
//    private List<PointF> mLinePoints = new ArrayList<>();
//    private static final int mDuration = 1000;
//    private float mLimitHeight = Integer.MAX_VALUE;
//    private float mDataTop;
//
//
//    public int getFillColorBottom() {
//        return mFillColorBottom;
//    }
//
//    public void setFillColorBottom(int color) {
//        this.mFillColorBottom = color;
//    }
//
//    public int getFillColorTop() {
//        return mFillColorTop;
//    }
//
//    public void setFillColorTop(int color) {
//        this.mFillColorTop = color;
//    }
//
//    private int mFillColorBottom = 0;
//    private int mFillColorTop = 0;
//
//    public void setHeartRateZone(int maxThreshold, int shaderTo) {
//        setHeartRateZone(maxThreshold, maxThreshold * .9f, maxThreshold * .8f, maxThreshold * .7f, maxThreshold * .6f, maxThreshold * .5f);
//    }
//
//    /**
//     * setHeartRateZone
//     *
//     * @param
//     */
//    public void setHeartRateZone(float... zones) {
//        mHeartRateZone = zones;
//        LogUtil.i(TAG, "standed heartRate from:" + mHeartRateZone[0] + " to:" + mHeartRateZone[mHeartRateZone.length - 1]);
//    }
//
//    private float getYnum2Px(float num) {
//        if (mLimitHeight == HEARTRATELIMIT) {
//            return getDrawBaseLine() - (num - mYaxis_min) * mHeightRatio;
//        } else {
//            return mYaxis_MaxHeight + mLineWidth + getPaddingTop() + (mYaxis_Max - num) * mHeightRatio;
//        }
//    }
//
//    public interface ChartStyle {
//        /**
//         * 心率柱状图
//         */
//        int LINE = 2;
//        int PIE = 3;
//    }
//
//    public static class SugExcel {
//        private String mShowMsg;
//        private int index;
//        private float mWidth;//柱状 的 宽
//        private float mHeight;//折线的y
//        private PointF mStart = new PointF();//矩形左下角起点
//        private float mMidX;//中点 折线的x
//        private int mColor;
//        private float mNum; //当前数字
//        private float mMax; //总数据
//        private String textMsg; //要显示的信息
//        private String mXmsg; //横坐标信息
//        private float mUpper;
//        private float mLower;
//        /**
//         * 单位
//         */
//        private String unit;
//
//        public SugExcel(int color, float num, String mXmsg) {
//            this(0, num, mXmsg, mXmsg, color);
//        }
//
//        public SugExcel(float num, String mXmsg) {
//            this(num, "", mXmsg);
//        }
//
//        public SugExcel(float num, String unit, String mXmsg) {
//            this(0, num, unit, mXmsg, Color.GRAY);
//        }
//
//
//        public SugExcel(float lower, float upper, String unit, String mXmsg, int color) {
//            mUpper = upper;
//            mLower = lower;
//            mHeight = mNum = upper - lower;
//            this.mXmsg = mXmsg;
//            mStart.y = mLower;
//            this.unit = unit;
//            this.mColor = color;
//            mShowMsg = new DecimalFormat("##").format(mHeight);
//        }
//
//        public PointF getMidPointF() {
//            return new PointF(getMidX(), mStart.y - mHeight);
//        }
//
//        public RectF getRectF() {
//            return new RectF(mStart.x, mStart.y - mHeight, mStart.x + mWidth, mStart.y);
//        }
//
//        public String getTextMsg() {
//            return textMsg;
//        }
//
//        public void setUnit(String unit) {
//            this.unit = unit;
//        }
//
//        public String getUnit() {
//            return unit;
//        }
//
//        public void setTextMsg(String textMsg) {
//            this.textMsg = textMsg;
//        }
//
//        public float getWidth() {
//            return mWidth;
//        }
//
//        public float getHeight() {
//            return mHeight;
//        }
//
//        public void setWidth(float width) {
//            this.mWidth = width;
//        }
//
//        public void setHeight(float height) {
//            this.mHeight = height;
//        }
//
//
//        public PointF getStart() {
//            return mStart;
//        }
//
//
//        public void setStart(PointF start) {
//            this.mStart = start;
//        }
//
//
//        public float getMidX() {
//            if (null != mStart) {
//                mMidX = mStart.x + mWidth / 2;
//            } else {
//                throw new RuntimeException("mStart 不能为空");
//            }
//            return mMidX;
//        }
//
//        public int getColor() {
//            return mColor;
//        }
//
//        public void setMidX(float midX) {
//            this.mMidX = midX;
//        }
//
//        public void setColor(int color) {
//            mColor = color;
//        }
//
//
//        public float getNum() {
//            return mNum;
//        }
//
//        public void setNum(float num) {
//            this.mNum = num;
//        }
//
//
//        public float getMax() {
//            return mMax;
//        }
//
//        public String getXmsg() {
//            return mXmsg;
//        }
//
//        public void setMax(float max) {
//            this.mMax = max;
//        }
//
//        public void setXmsg(String xmsg) {
//            this.mXmsg = xmsg;
//        }
//
//
//        public float getUpper() {
//            return mUpper;
//        }
//
//
//        public void setUpper(float upper) {
//            mUpper = upper;
//            mHeight = mUpper - mLower;
//            mShowMsg = new DecimalFormat("##.#").format(mUpper);
//        }
//
//
//        public float getLower() {
//            return mLower;
//        }
//
//
//        public int getIndex() {
//            return index;
//        }
//
//        public void setLower(float lower) {
//            mLower = lower;
//        }
//
//        public void setIndex(int index) {
//            this.index = index;
//        }
//
//        public String getShowMsg() {
//            return mShowMsg;
//        }
//
//        public void setShowMsg(String showMsg) {
//            mShowMsg = showMsg;
//        }
//
//        @Override
//        public String toString() {
//            return "height: " + mHeight;
//        }
//
//    }
//
//    private Context mContext;
//    /**
//     * 柱状图间的 间隔
//     */
//    private float mInterval;
//
//    /**
//     * 图表 数据集合
//     */
//    private List<SugExcel> mExcels = new ArrayList<>();
//
//    /**
//     * 柱状图 选中的颜色
//     */
////    private int mActivationColor = Color.RED;
//
//    /**
//     * 柱状图 未选中选中的颜色
//     */
//    private int mNormalColor = Color.DKGRAY;
//
//    /**
//     * 要画的 图表的 风格
//     */
//    private int mChartStyle = ChartStyle.LINE;
//
//    /**
//     * 柱形图 宽
//     */
//    private float mBarWidth = 2;
//
//    public SugChart(Context context) {
//        super(context);
//        init(context);
//    }
//
//
//    public SugChart(Context context, AttributeSet attrs) {
//        super(context, attrs);
//        init(context);
//    }
//
//
//    public SugChart(Context context, AttributeSet attrs, int defStyleAttr) {
//        super(context, attrs, defStyleAttr);
//        init(context);
//    }
//
//    {
//        mTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        mTextPaint.setTextAlign(Paint.Align.CENTER);
//
//        mAbscissaPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        mAbscissaPaint.setColor(mAbscissaMsgColor);
//        mAbscissaPaint.setTextAlign(Paint.Align.CENTER);
//
//        mLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        mLinePaint.setStrokeWidth(mLineWidth);
//        mLinePaint.setStyle(Paint.Style.STROKE);
//        mCoordinatePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        mCoordinatePaint.setStyle(Paint.Style.STROKE);
//
//        mAbscisDashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        mAbscisDashPaint.setStrokeWidth(0.25f);
//        mAbscisDashPaint.setStyle(Paint.Style.STROKE);
//        mAbscisDashPaint.setColor(mAbscissaMsgColor);
//
//        mIntervalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        mPiePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        mPiePaint.setStyle(Paint.Style.STROKE);
//
//        mCalloutPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        mCalloutPaint.setColor(Color.WHITE);
//        mCalloutPaint.setTextAlign(Paint.Align.CENTER);
//        mCalloutBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//    }
//
//    private void init(Context context) {
//        mContext = context;
//        initData();
//        mTextPaint.setTextSize(mTextSize);
//        mPiePaint.setStrokeWidth(pieWidth);
//        mAecRect = new RectF(0, 0, mWidth, mHeight);
//        mIntervalPaint.setStrokeWidth(dip2px(1));
//        mIntervalColor = Color.WHITE;
//        mCalloutPaint.setTextSize(dip2px(12));
//        mAbscissaPaint.setTextSize(mAbscissaMsgSize);
//    }
//
//    private void initData() {
//        mInterval = dip2px(20);
//        mTextSize = sp2px(12);
//        mAbscissaMsgSize = sp2px(12);
////        mLinePointRadio = dip2px(4);
//    }
//
//    @Override
//    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
//        super.onSizeChanged(w, h, oldw, oldh);
//        mHeight = h;
//        mHCoordinate = mHeight - Math.abs(2 * mAbscissaMsgSize);
//        mWidth = w;
//
//        mCenterPoint = new PointF(w / 2f, h / 2f);
//        if (mExcels.size() > 0) {
//            refreshBarWidth_Interval(w);
//            refreshExcels();
//        }
//
//    }
//
//    private void refreshBarWidth_Interval(int w) {
//        if (mYaxiShow) {
//            String y_max = new DecimalFormat("##").format(mYaxis_Max);
//            Rect bounds = new Rect();
//            mAbscissaPaint.getTextBounds(y_max, 0, y_max.length(), bounds);
//            mYaxis_MaxHeight = getPaddingTop();
//        } else {
//            mYaxis_MaxHeight = getPaddingTop();
//        }
//        padingY = getPaddingStart();
//        if (mChartStyle == ChartStyle.LINE) {
//            mInterval = (w - padingY - getPaddingRight() - mBarWidth * mExcels.size()) / (mExcels.size() - 1);
//        }
//    }
//
//    private int ceil2(float max) {
//        return ((int) ((max + 1)) / 2 * 2);
//    }
//
//    private void refreshExcels() {
//        if (mExcels.size() <= 0) return;
//        pieStyleConfig();
//
//        if (mHCoordinate > 0) {
//            mLinepath.reset();
//            calcuteHeightRatio();
//
//            calcuteExcel();
//            if (mChartStyle == ChartStyle.LINE) {
//                initLinePath();
//                shadowPathClose();
//            }
//        }
//    }
//
//    private void shadowPathClose() {
//        if (mLinePoints.size() > 0) {
//            //DTS2016091303915
//            mLineAreapath.lineTo(mLinePoints.get(mLinePoints.size() - 1).x, mHCoordinate);
//            mLineAreapath.lineTo(mLinePoints.get(0).x, mHCoordinate);
//            mLineAreapath.close();
//        }
//    }
//
//    private void calcuteHeightRatio() {
//        if (mLimitHeight == HEARTRATELIMIT) {
//            doHeartRateData();
//        } else {
//            doStepRateData();
//        }
//    }
//
//    private float getDrawBaseLine() {
//        return mHCoordinate - getCalloutHeight() - dip2px(4);
//    }
//
//    private void doHeartRateData() {
//        mYaxis_min = mSugButtom.getHeight();
//        mHeightRatio = (getDrawBaseLine() - mYaxis_MaxHeight - getCalloutHeight() - dip2px(4) - mLineWidth / 2) / (mSugTop.getHeight() - mSugButtom.getHeight());
//    }
//
//    private void doStepRateData() {
//        if (!mDrawo) {
//            //draw Callout
//            mHeightRatio = (mHCoordinate - mYaxis_MaxHeight - getCalloutHeight() - dip2px(4) - mLineWidth / 2) / (mSugTop.getHeight() - mYaxis_min);
//            float limit = (mHCoordinate - mYaxis_MaxHeight) / mHeightRatio;//画图区域能够显示的最大数据
//            mYaxis_Max = mYaxis_Max < ceil2(limit) ? ceil2(limit) : mYaxis_Max;//画图区域能够显示的最大数据转为整数
//        }
//        mHeightRatio = (mHCoordinate - mYaxis_MaxHeight - mLineWidth - getPaddingTop()) / mYaxis_Max;//根据新的最大值 调整缩放比例
//    }
//
//    private void calcuteExcel() {
//        for (int i = 0; i < mExcels.size(); i++) {
//            SugExcel sugExcel = mExcels.get(i);
//            sugExcel.setHeight((sugExcel.getHeight() - mYaxis_min) * mHeightRatio);
//            sugExcel.setWidth(mBarWidth);
//            PointF start = sugExcel.getStart();
//            if (!LanguageUtil.isRTLLanguage(getContext())) {
//                start.x = getPaddingStart() + mInterval * i + mBarWidth * i;
//            } else {
//                start.x = getPaddingEnd() + mInterval * i + mBarWidth * i;
//            }
//            if (mLimitHeight == HEARTRATELIMIT) {
//                start.y = getDrawBaseLine() - sugExcel.getLower();
//            } else {
//                start.y = mHCoordinate - mAbove - sugExcel.getLower();
//            }
////            start.y = mHCoordinate - mAbove - sugExcel.getLower();
//        }
//    }
//
//    private void initLinePath() {
//        mLinePoints.clear();
//        for (SugExcel excel : mExcels) {
//            //数据过滤
//            if (guolvPoint(excel)) {
//                mLinePoints.add(excel.getMidPointF());
//            }
//        }
//        for (int i = 0; i < mLinePoints.size(); i++) {
//            if (mLinePoints.get(i).y >= 0) {
//                PointF prePoint = mLinePoints.get(i);
//                if (i == 0) {
//                    mLinepath.moveTo(prePoint.x, prePoint.y);
//                    mLineAreapath.moveTo(prePoint.x, prePoint.y);
//                }
//                if (i < mLinePoints.size() - 1) {
//                    PointF nextPoint = mLinePoints.get(i + 1);
//                    float c_x = (prePoint.x + nextPoint.x) / 2f;
//                    mLinepath.cubicTo(c_x, prePoint.y, c_x, nextPoint.y, nextPoint.x, nextPoint.y);
//                    mLineAreapath.cubicTo(c_x, prePoint.y, c_x, nextPoint.y, nextPoint.x, nextPoint.y);
//                }
//            }
//        }
//    }
//
//    private boolean guolvPoint(SugExcel excel) {
//        return excel.getHeight() < mLimitHeight * mHeightRatio && excel.getHeight() >= 0;
//    }
//
//    private void pieStyleConfig() {
//        if (mChartStyle == ChartStyle.PIE) {
//            pieWidth = pieWidth > (mHeight / 2 - getPaddingTop()) ? (mHeight / 2 - getPaddingTop()) : pieWidth;
//            mPiePaint.setStrokeWidth(pieWidth);
//            mIntervalWidth = mIntervalWidth < pieWidth / 10f ? pieWidth / 10f : mIntervalWidth;
//            mArcRadio = mHeight / 2 - getPaddingTop() - pieWidth / 2;
//            mAecRect.set(mCenterPoint.x - mArcRadio, mCenterPoint.y - mArcRadio, mCenterPoint.x + mArcRadio, mCenterPoint.y + mArcRadio);
//        }
//    }
//
//    @Override
//    protected void onDraw(Canvas canvas) {
//        super.onDraw(canvas);
//        if (null != mExcels && mExcels.size() > 0) {
//            if (mChartStyle == ChartStyle.PIE) {
//                drawSugExcel_PIE(canvas);
//            } else if (mChartStyle == ChartStyle.LINE) {
//                if (mLinePoints.size() == 1) {
//                    mLinePaint.setColor(mLineColor);
//                    canvas.drawPoint(mExcels.get(0).getMidPointF().x, mExcels.get(0).getMidPointF().y, mLinePaint);
//                } else {
//                    drawSugExcel_LINE(canvas);
//                }
//                drawCoordinateAxes(canvas);
//                if (mYaxiShow) {
//                    drawYCoordinateAxes(canvas);
//                }
//            }
//        }
//        drawAbscissaMsg(canvas);
//        if (mSHowRegion) {
//            for (int i = 0; i < 6; i++) {
//                float y = getYnum2Px(mHeartRateZone[i]);
//                canvas.drawLine(0, y, mWidth, y, mCoordinatePaint);
//            }
//        }
//    }
//
//    private void drawYCoordinateAxes(Canvas canvas) {
//
//        float diffLevel = (mYaxis_Max - mYaxis_min) / ((float) mYaxis_showYnum);
//        float diffCoordinate = diffLevel * mHeightRatio;
//        float linestart = getPaddingStart();
//        float lineend = mWidth - getPaddingEnd();
//        float textStart = getPaddingStart();
//        textStart = dealYisRTL(textStart);
//
//        if (mLimitHeight == HEARTRATELIMIT) {
//            canvas.drawLine(linestart,2,lineend,2,mAbscisDashPaint);
//
//            canvas.drawLine(linestart,getYnum2Px((mDataTop+mYaxis_min)/2),lineend,getYnum2Px((mDataTop+mYaxis_min)/2),mAbscisDashPaint);
//            canvas.drawText(new DecimalFormat("#").format((mDataTop+mYaxis_min)/2), textStart, getYnum2Px((mDataTop+mYaxis_min)/2) - dip2px(4), mAbscissaPaint);
//
//        } else {
//            drawLineY(canvas, diffLevel, diffCoordinate, linestart, lineend, textStart);
//        }
//    }
//
//    private float dealYisRTL(float textStart) {
//        if (!LanguageUtil.isRTLLanguage(getContext())) {
////            linestart = getPaddingStart();
//            textStart = mWidth - getPaddingEnd();
//            mAbscissaPaint.setTextAlign(Paint.Align.RIGHT);
//        } else {
//            mAbscissaPaint.setTextAlign(Paint.Align.LEFT);
//        }
//        return textStart;
//    }
//
//    private void drawLineY(Canvas canvas, float diffLevel, float diffCoordinate, float linestart, float lineend, float textStart) {
//        for (int i = 0; i <= mYaxis_showYnum; i++) {
//            float levelCoordinate = mHCoordinate - diffCoordinate * i;
//            if (i > 0) {
//                canvas.drawText(new DecimalFormat("#").format(mYaxis_min + diffLevel * i), textStart, levelCoordinate + dip2px(4) + getTextHeight(mAbscissaPaint), mAbscissaPaint);
//                Path dashPath = new Path();
//                dashPath.moveTo(linestart, levelCoordinate);
//                if (mExcels != null && mExcels.size() > 0) {
//                    dashPath.lineTo(lineend, levelCoordinate);
//                }
//                mAbscisDashPaint.setPathEffect(pathDashEffect());
//                canvas.drawPath(dashPath, mAbscisDashPaint);
//            }
//        }
//    }
//
//    private DashPathEffect pathDashEffect() {                     //线，段，线，段
//        DashPathEffect dashEffect = new DashPathEffect(new float[]{4, 4}, phase);
//        return dashEffect;
//    }
//
//
//    private void drawSugExcel_PIE(Canvas canvas) {
//        mStartAnger = 0;
//        for (SugExcel excel : mExcels) {
//            mPiePaint.setColor(excel.getColor());
//            float sweep = excel.getHeight() / (dataTotal * mHeightRatio) * 360;
//            canvas.drawArc(mAecRect, mStartAnger, sweep, false, mPiePaint);
//            mStartAnger += sweep;
//        }
//
//        mIntervalPaint.setStrokeWidth(mIntervalWidth);
//        mIntervalPaint.setColor(mIntervalColor);
//        canvas.save();
//        for (SugExcel excel : mExcels) {
//            float sweep = excel.getHeight() / (dataTotal * mHeightRatio) * 360;
//            canvas.drawLine(mCenterPoint.x + mArcRadio - pieWidth / 2 - 1f, mCenterPoint.y, mCenterPoint.x + mArcRadio + pieWidth / 2 + 1f, mCenterPoint.y, mIntervalPaint);
//            canvas.rotate(sweep, mCenterPoint.x, mCenterPoint.y);
//        }
//        canvas.restore();
//
//    }
//
//    private void drawAbscissaMsg(Canvas canvas) {
//        mAbscissaPaint.setTextAlign(Paint.Align.LEFT);
//        String total = String.valueOf((int) mTotalTime);
//        float xWi = mWidth - padingY - getPaddingRight() - mAbscissaPaint.measureText(total, 0, total.length());
//        for (int i = 0; i < mXNums + 1; i++) {
//            String xmsg = UnitUtil.getNumberFormat(mXInter * i, 1, 0);
//            float w = mAbscissaPaint.measureText(xmsg, 0, xmsg.length());
//            float textX = padingY + mXInter * i / mTotalTime * xWi;
//            if (LanguageUtil.isRTLLanguage(getContext())) {
//                textX = mWidth - getPaddingStart() - (mXInter * i / mTotalTime * xWi);
//                mAbscissaPaint.setTextAlign(Paint.Align.RIGHT);
//            }
//            if (textX + w / 2 > mWidth) {
//                textX = mWidth - w;
//            }
//            canvas.drawText(xmsg, textX, mHCoordinate + dip2px(3) + mTextSize, mAbscissaPaint);
//        }
//    }
//
//    /**
//     * 画 折线
//     */
//    private void drawSugExcel_LINE(Canvas canvas) {
//        if (mFillColorBottom != 0 && mFillColorTop != 0) {
//            drawArea(canvas);
//        }
//
//        paintSetShader(mLinePaint);
//        canvas.drawPath(mLinepath, mLinePaint);
//        drawCallout(canvas);
//    }
//
//    private void drawCallout(Canvas canvas) {
//        if (mCalloutPaint != null && mSugTop != null && mSugButtom != null && mShaderColors != null) {
//            mCalloutBgPaint.setColor(Color.parseColor("#ec8900"));
//            drawCalloutActual(canvas, mSugTop, true);
//            mCalloutBgPaint.setColor(mShaderColors[mShaderColors.length - 1]);
////            drawCalloutActual(canvas, mSugButtom, mSugButtom.getHeight() < getCalloutHeight());//最小值的高度大于标注需要的高度才画 为false
//            drawCalloutActual(canvas, mSugButtom, false);
//        }
//    }
//
//    /**
//     * 根据传入的数据 画出图表标注
//     *
//     * @param canvas
//     * @param excel  标注数据
//     * @param top    最大值，上部
//     */
//    private void drawCalloutActual(Canvas canvas, @NonNull SugExcel excel, boolean top) {
//        float toPoint = dip2px(2) + mLineWidth / 2;//标注距离点的间距
//        if (excel.getHeight() < 0) {
//            return;
//        }
//
//        PointF midPointF = excel.getMidPointF();
//        String msg = String.valueOf(excel.getShowMsg());
//
//        Path triangleBg = new Path();
//
//        float calloutHeight = dip2px(21);//胶囊的高
//        float bgPading = dip2px(6);//间距
//        float triangleBgWidth = dip2px(8);
//        float triangleBgHeight = dip2px(4);
//        initTraingleBg(top, toPoint, midPointF, triangleBg, triangleBgWidth, triangleBgHeight);
//        canvas.drawPath(triangleBg, mCalloutBgPaint);
//        float msgWidth = mCalloutPaint.measureText(msg);
//        RectF rectF = new RectF(midPointF.x - msgWidth / 2f - bgPading, midPointF.y - toPoint - triangleBgHeight - calloutHeight
//                , midPointF.x + msgWidth / 2f + bgPading, midPointF.y - toPoint - triangleBgHeight);
//        if (!top) {
//            rectF.offset(0, mLineWidth + getCalloutHeight() + dip2px(4) + dip2px(2));
//        }
//        float dffw = rectF.right - mWidth;
//        float msgX = midPointF.x;
//        float magin = 1;
//        msgX = limitInside(midPointF, rectF, dffw, msgX, magin);
//
//        canvas.drawRoundRect(rectF, rectF.height() / 2f, rectF.height() / 2f, mCalloutBgPaint);
//
//        canvas.drawText(msg, msgX, rectF.bottom - rectF.height() / 2f + getTextHeight(mCalloutPaint) / 2, mCalloutPaint);
//    }
//
//    private float limitInside(PointF midPointF, RectF rectF, float dffw, float msgX, float magin) {
//        if (dffw > 0) {
//            rectF.right = rectF.right - dffw - magin;
//            rectF.left = rectF.left - dffw - magin;
//            msgX = midPointF.x - dffw - magin;
//        } else if (rectF.left < 0) {
//            rectF.right = rectF.right - rectF.left + magin;
//            msgX = midPointF.x - rectF.left + magin;
//            rectF.left = magin;
//        }
//        return msgX;
//    }
//
//    private void initTraingleBg(boolean top, float toPoint, PointF midPointF, Path triangleBg, float triangleBgWidth, float triangleBgHeight) {
//        //三角
//        if (top) {
//            triangleBg.moveTo(midPointF.x, midPointF.y - toPoint);
//            triangleBg.lineTo(midPointF.x - triangleBgWidth / 2, midPointF.y - toPoint - triangleBgHeight - 1);
//            triangleBg.lineTo(midPointF.x + triangleBgWidth / 2, midPointF.y - toPoint - triangleBgHeight - 1);
//            triangleBg.close();
//        } else {
//            triangleBg.moveTo(midPointF.x, midPointF.y + toPoint);
//            triangleBg.lineTo(midPointF.x - triangleBgWidth / 2, midPointF.y + toPoint + triangleBgHeight + 1);
//            triangleBg.lineTo(midPointF.x + triangleBgWidth / 2, midPointF.y + toPoint + triangleBgHeight + 1);
//            triangleBg.close();
//        }
//    }
//
//    private float getTextHeight(Paint textPaint) {
//        return -textPaint.ascent() - textPaint.descent();
//    }
//
//    private float getCalloutHeight() {
//        // 胶囊高 + 三角距离点的间距 + 三角高
//        return dip2px(21) + dip2px(2) + dip2px(4);
//    }
//
//    private void drawArea(Canvas canvas) {
//        Paint p = new Paint();
//        LinearGradient lg = new LinearGradient(0, 0, 0, mHCoordinate, mFillColorTop, mFillColorBottom, Shader.TileMode.MIRROR);
//        p.setStyle(Paint.Style.FILL);
//        p.setShader(lg);
//        canvas.drawPath(mLineAreapath, p);
//    }
//
//    private void paintSetShader(Paint paint) {
//        if (isNeedShader()) {
//            float[] position = new float[6];
//            float top = getYnum2Px(mHeartRateZone[1] + 10);
//            float buttom = getYnum2Px(mHeartRateZone[5] - 10);
//            calcutePosition(position, top, buttom);
//            paint.setShader(new LinearGradient(0, top, 0, buttom
//                    , mShaderColors, position, Shader.TileMode.CLAMP));
//        } else {
//            mLinePaint.setColor(mLineColor);
//        }
//    }
//
//    private void calcutePosition(float[] position, float top, float buttom) {
//        float ji = top - top;
//        float wuyang = getYnum2Px(mHeartRateZone[1]) - top;
//        float youyang = getYnum2Px(mHeartRateZone[2]) - top;
//        float ranzhi = getYnum2Px(mHeartRateZone[3]) - top;
//        float reshe = getYnum2Px(mHeartRateZone[4]) - top;
//        float other = getYnum2Px(mHeartRateZone[5]) + mLineWidth - top;
//        float totalzone = buttom - top;
//        position[0] = ji / totalzone;
//        position[1] = wuyang / totalzone;
//        position[2] = youyang / totalzone;
//        position[3] = ranzhi / totalzone;
//        position[4] = reshe / totalzone;
//        position[5] = other / totalzone;
//    }
//
//    private boolean isNeedShader() {
//        return mShaderColors != null && mShaderColors.length > 1 && mHeartRateZone.length == 6;
//    }
//
//    /**
//     * 画 坐标轴
//     */
//    private void drawCoordinateAxes(Canvas canvas) {
//        mCoordinatePaint.setColor(Color.parseColor("#AFAFB0"));
//        mCoordinatePaint.setStrokeWidth(2);
//        canvas.drawLine(getPaddingStart(), mHCoordinate, mWidth - getPaddingEnd(), mHCoordinate, mCoordinatePaint);
//    }
//
//
//    /**
//     * 传入 数据
//     */
//    public void cmdFill(SugExcel... sugExcels) {
//        cmdFill(Arrays.asList(sugExcels));
//    }
//
//
//    /**
//     * 传入 数据
//     * 先设置 y信息
//     */
//    public void cmdFill(List<SugExcel> sugExcelList) {
//
//        String unit = String.format("%%s%s", getResources().getString(R.string.IDS_main_watch_heart_rate_unit_string));
//        mExcels.clear();
//        dataTotal = 0;
//
//        if (sugExcelList != null && sugExcelList.size() > 0) {
//            if (LanguageUtil.isRTLLanguage(getContext())) {
//                Collections.reverse(sugExcelList);
//            }
//
//            dealShowMsg(sugExcelList, unit);
//            mExcels.addAll(sugExcelList);
//            if (!mYaxiShow && mYaxis_Max == 0) {
//                mYaxis_Max = sugExcelList.get(0).getHeight();
//            }
//            for (SugExcel sugExcel : sugExcelList) {
//                if (!mYaxiShow || mChartStyle == ChartStyle.PIE) {
//                    mYaxis_Max = mYaxis_Max > sugExcel.getHeight() ? mYaxis_Max : sugExcel.getHeight();
//                }
//                dataTotal += sugExcel.getHeight() - mYaxis_min;
//            }
//            if (mWidth > 0) {
//                //已经显示在界面上了 重新设置数据
//                refreshBarWidth_Interval(mWidth);
//                refreshExcels();
//            }
//            postInvalidate();
//        }
//    }
//
//    private void dealShowMsg(List<SugExcel> sugExcelList, String unit) {
//        mSugTop = Collections.max(sugExcelList, new Comparator<SugExcel>() {
//            @Override
//            public int compare(SugExcel lhs, SugExcel rhs) {
//                return Float.compare(getHeightEffect(lhs.getHeight()), getHeightEffect(rhs.getHeight()));
//            }
//        });
//        mDataTop = mSugTop.getHeight();
//        mSugTop.setShowMsg(String.format(unit, new DecimalFormat("#").format(mSugTop.getHeight())));
//        mSugButtom = Collections.min(sugExcelList, new Comparator<SugExcel>() {
//            @Override
//            public int compare(SugExcel lhs, SugExcel rhs) {
//                return Float.compare(getHeightno_0(lhs.getHeight()), getHeightno_0(rhs.getHeight()));
//            }
//        });
//        mSugButtom.setShowMsg(String.format(unit, new DecimalFormat("#").format(mSugButtom.getHeight())));
//    }
//
//    private float getHeightEffect(float heightRatio) {
//        return heightRatio > mLimitHeight ? 0 : heightRatio;
//    }
//
//    private float getHeightno_0(float heightRatio) {
//        return heightRatio <= 0 ? mLimitHeight : heightRatio;
//    }
//
//    public int getNormalColor() {
//        return mNormalColor;
//    }
//
//
//    /**
//     * 默认颜色
//     */
//    public void setNormalColor(int normalColor) {
//        mNormalColor = normalColor;
//        mLineColor = normalColor;
//    }
//
//    public int getChartStyle() {
//        return mChartStyle;
//    }
//
//
//    /**
//     * 设置 图表类型  柱状 折线  折线+柱状
//     */
//    public void setChartStyle(int chartStyle) {
//        mChartStyle = chartStyle;
//    }
//
//    public void setSHowRegion(boolean SHowRegion) {
//        mSHowRegion = SHowRegion;
//        postInvalidate();
//    }
//
//    public boolean isSHowRegion() {
//        return mSHowRegion;
//    }
//
//    public float getTextSize() {
//        return mTextSize;
//    }
//
//
//    /**
//     * 设置 文字大小 同时 调整x轴 距离底部位置(为字体大小两倍)
//     */
//    public void setTextSize(float textSize) {
//        mTextSize = sp2px(textSize);
//        mHCoordinate = mTextSize * 2;
//        mTextPaint.setTextSize(mTextSize);
//    }
//
//    public void setAbscissaMsgSize(float abscissaMsgSize) {
//        mAbscissaMsgSize = abscissaMsgSize;
//        mAbscissaPaint.setTextSize(mAbscissaMsgSize);
//        mHCoordinate = mHeight - Math.abs(2 * mAbscissaMsgSize);
//        if (mWidth > 0) {
//            refreshExcels();
//        }
//    }
//
//    public void setAbscissaMsgColor(int abscissaMsgColor) {
//        mAbscissaMsgColor = abscissaMsgColor;
//        mAbscissaPaint.setColor(mAbscissaMsgColor);
//    }
//
//    public float getHCoordinate() {
//        return mHCoordinate;
//    }
//
//
//    /**
//     * 渐变色
//     *
//     * @param colors
//     */
//    public void setExecelPaintShaderColors(int... colors) {
//        mShaderColors = colors;
//    }
//
//
//    /**
//     * x轴 的位置
//     *
//     * @param HCoordinate 距离底部 多少
//     */
//    public void setHCoordinate(float HCoordinate) {
//        mHCoordinate = HCoordinate;
//    }
//
//    public void setLineWidth(float width) {
//        mLineWidth = width;
//        mLinePaint.setStrokeWidth(mLineWidth);
//    }
//
//    public void setLineColor(int color) {
//        mLineColor = color;
//    }
//
//    /**
//     * 设置y轴 刻度 信息
//     *
//     * @param min      y轴 显示的最小值
//     * @param max      y轴显示的最大值
//     * @param showYnum y轴显示 刻度数量
//     */
//    public void setYaxisValues(int min, int max, int showYnum) {
//        if (min > max) {
//            throw new RuntimeException("min < max");
//        }
//        mYaxiShow = true;
//        mYaxis_Max = max;
//        mYaxis_min = min;
//        mYaxis_showYnum = showYnum;
//    }
//
//    public void setAbove(float above) {
//        mAbove = above;
//    }
//
//    public void setPieWidth(float pieWidth) {
//        this.pieWidth = pieWidth;
//    }
//
//    public void setIntervalColor(int intervalColor) {
//        mIntervalColor = intervalColor;
//    }
//
//    public void setIntervalWidth(float intervalWidth) {
//        mIntervalWidth = intervalWidth;
//    }
//
//    public int dip2px(float dipValue) {
//        final float scale = mContext.getResources().getDisplayMetrics().density;
//        return (int) (dipValue * scale + 0.5f);
//    }
//
//    /**
//     * 将sp值转换为px值，保证文字大小不变
//     *
//     * @param spValue （DisplayMetrics类中属性scaledDensity）
//     */
//    public int sp2px(float spValue) {
//        final float fontScale = mContext.getResources().getDisplayMetrics().scaledDensity;
//        return (int) (spValue * fontScale + 0.5f);
//    }
//
//    /**
//     * @param xNums  几段
//     * @param xInter 每段多少
//     */
//    public void setXnums(int xNums, int xInter, float totalTime) {
//        mXNums = xNums;
//        mXInter = xInter;
//        mTotalTime = totalTime;
//    }
//
//    /**
//     * true  draw  0  step
//     *
//     * @param drawo
//     */
//    public void setDrawo(boolean drawo) {
//        mDrawo = drawo;
//    }
//
//    @Override
//    protected void onAttachedToWindow() {
//        super.onAttachedToWindow();
//        mValueAnimator = ValueAnimator.ofFloat(0, 1);
//        mValueAnimator.setDuration(mDuration);
//        mValueAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
//        mValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
//            @Override
//            public void onAnimationUpdate(ValueAnimator animation) {
//                calcuteAnimation(animation);
//                postInvalidate();
//            }
//        });
//        mValueAnimator.start();
//    }
//
//    private void calcuteAnimation(ValueAnimator animation) {
//        float animatedValue = (float) animation.getAnimatedValue();
//        mIntervalPaint.setStrokeWidth(mIntervalWidth * animatedValue);
//        mPiePaint.setStrokeWidth(pieWidth * animatedValue);
//        mLinepath = new Path();
//        for (int i = 0; i < mLinePoints.size(); i++) {
//            if (mLinePoints.get(i).y >= 0) {
//                PointF prePoint = mLinePoints.get(i);
//                createLinePath(animatedValue, i, prePoint);
//            }
//        }
//    }
//
//    private void createLinePath(float animatedValue, int i, PointF prePoint) {
//        if (i == 0) {
//            mLinepath.moveTo(prePoint.x, prePoint.y * animatedValue);
//            mLineAreapath.moveTo(prePoint.x, prePoint.y * animatedValue);
//        }
//        if (i < mLinePoints.size() - 1) {
//            PointF nextPoint = mLinePoints.get(i + 1);
//            float c_x = (prePoint.x + nextPoint.x) / 2f;
//            mLinepath.cubicTo(c_x, prePoint.y * animatedValue, c_x, nextPoint.y * animatedValue, nextPoint.x, nextPoint.y * animatedValue);
//            mLineAreapath.cubicTo(c_x, prePoint.y * animatedValue, c_x, nextPoint.y * animatedValue, nextPoint.x, nextPoint.y * animatedValue);
//        }
//    }
//
//    public void setLimitHeight(int limitHeight) {
//        mLimitHeight = limitHeight;
//    }
//
//}
