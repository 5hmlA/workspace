package com.jonas.tubiao.view;

import android.content.Context;

/**
 * @author jiangzuyun.
 * @date 2017/2/25
 * @des [一句话描述]
 * @since [产品/模版版本]
 */


public class LanguageUtil {
    public static boolean isRTLLanguage(Context context) {
        return false;
    }
}
