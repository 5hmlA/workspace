package com.jonas.tubiao;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.jonas.tubiao.view.SugChart;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;

import static com.jonas.tubiao.view.SugChart.HEARTRATELIMIT;

public class DetailActivity extends AppCompatActivity {
    private final String TAG = this.getClass().getSimpleName();
    private TextView mSugTvTbHeartrate;
    private TextView mSugTvTbHeartbig;
    private SugChart mSugScJHeart;
    private SugChart mSugScJHeartPie;
    private TextView mSugTvHotbody;
    private TextView mSugTvBurn;
    private TextView mSugTvAnaerobic;
    private TextView mSugTvAerobic;
    private TextView mSugTvLimit;
    private TextView mSugTvTbBupinrate;
    private TextView mSugTvTbBupinbig;
    private SugChart mSugScJBupin;
    private ArrayList<SugChart.SugExcel> mHeartSugExcels;
    private LinearLayout mSugllsccontent;
    private Context mContext;
    private ArrayList<SugChart.SugExcel> mStepSugExcels;
    //允许显示的点的个数
    private int mLineMaxPoints;
    private ArrayList<StepRateData> mStepRateList;
    private ArrayList<HeartRateData> mHeartRateList;
    private static final String hot_color = "#559ff4";
    private static final String bur_color = "#00d659";
    private static final String ana_color = "#f7d01b";
    private static final String aer_color = "#ed7000";
    private static final String lim_color = "#ff1b00";

    private void assignViews(View rootView) {
        mSugTvTbHeartrate = (TextView) rootView.findViewById(R.id.sug_tv_tb_heartrate);
        mSugllsccontent = (LinearLayout) rootView.findViewById(R.id.sug_ll_sc_content);
        mSugTvTbHeartbig = (TextView) rootView.findViewById(R.id.sug_tv_tb_heartbig);
        mSugScJHeart = (SugChart) rootView.findViewById(R.id.sug_sc_j_heart);
        mSugScJHeartPie = (SugChart) rootView.findViewById(R.id.sug_sc_j_heart_pie);
        mSugTvHotbody = (TextView) rootView.findViewById(R.id.sug_tv_hotbody);
        mSugTvBurn = (TextView) rootView.findViewById(R.id.sug_tv_burn);
        mSugTvAnaerobic = (TextView) rootView.findViewById(R.id.sug_tv_anaerobic);
        mSugTvAerobic = (TextView) rootView.findViewById(R.id.sug_tv_aerobic);
        mSugTvLimit = (TextView) rootView.findViewById(R.id.sug_tv_limit);
        mSugTvTbBupinrate = (TextView) rootView.findViewById(R.id.sug_tv_tb_bupinrate);
        mSugTvTbBupinbig = (TextView) rootView.findViewById(R.id.sug_tv_tb_bupinbig);
        mSugScJBupin = (SugChart) rootView.findViewById(R.id.sug_sc_j_bupin);
    }
    private int[] mHearts = new int[]{66,78,77,79,87,99,97,93,111,100,86,89};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sug_fm_detail_heartrate);
        assignViews(findViewById(android.R.id.content));
        mContext = this.getApplicationContext();

        mStepRateList = new ArrayList<>();
        mHeartRateList = new ArrayList<>();

        System.out.println("==================================================");

        int steps = new Random().nextInt(40) + 6;
        int hearts = new Random().nextInt(55) + 1;
        Calendar instance = Calendar.getInstance();
        instance.setTime(new Date());
//        for (int i = 0; i < mHearts.length; i++) {
        for (int i = 0; i < hearts; i++) {
            instance.add(Calendar.MINUTE, 1);
            //模拟 生成点 没一分钟生成一个
            mHeartRateList.add(new HeartRateData(instance.getTimeInMillis(), new Random().nextInt(160) + 60));
//            mHeartRateList.add(new HeartRateData(instance.getTimeInMillis(), mHearts[i]));
        }
        long firsTime = mHeartRateList.get(0).getTime();
        for (HeartRateData heartRateData : mHeartRateList) {
            long duration = heartRateData.getTime() - firsTime;
            heartRateData.setTime(duration / 1000);
        }


        Calendar instance2 = Calendar.getInstance();
        instance2.setTime(new Date());
        for (int i = 0; i < steps; i++) {
            instance2.add(Calendar.MINUTE, 1);
            //模拟 生成点 没一分钟生成一个
            mStepRateList.add(new StepRateData(instance2.getTimeInMillis(), new Random().nextInt(160) + 60));
        }
        long firsTime2 = mStepRateList.get(0).getTime();
        for (StepRateData heartRateData : mStepRateList) {
            long duration = heartRateData.getTime() - firsTime2;
            heartRateData.setTime(duration / 1000);
        }


        mSugTvTbHeartrate.setText(mHeartRateList.get(mHeartRateList.size() - 1).getTime() / 60 + "");
//        //平均步频
        mSugTvTbBupinrate.setText(mStepRateList.get(mStepRateList.size()-1).getTime()/60 + "");
        mSugTvTbHeartbig.setText(hearts + "");
        mSugTvTbBupinbig.setText(steps+"");

        //控件的一些设置
        mSugScJHeart.setChartStyle(SugChart.ChartStyle.LINE);
        mSugScJHeart.setLineWidth(mSugScJHeart.dip2px(3));
        mSugScJHeart.setAbscissaMsgColor(Color.parseColor("#50000000"));
        mSugScJHeart.setAbscissaMsgSize(getResources().getDimension(R.dimen.absmsgsize));
        mSugScJHeart.setExecelPaintShaderColors(Color.parseColor(lim_color), Color.parseColor(aer_color), Color.parseColor(ana_color), Color.parseColor(bur_color)
                , Color.parseColor(hot_color), Color.parseColor("#dddddd"));

        mSugScJHeartPie.setChartStyle(SugChart.ChartStyle.PIE);
        mSugScJHeartPie.setPieWidth(mContext.getResources().getDimension(R.dimen.sug_detail_piewidth));

        mSugScJBupin.setChartStyle(SugChart.ChartStyle.LINE);

        mSugScJBupin.setLineWidth(mSugScJBupin.dip2px(3));
        mSugScJBupin.setAbscissaMsgColor(Color.parseColor("#50000000"));
        mSugScJBupin.setAbscissaMsgSize(getResources().getDimension(R.dimen.absmsgsize));
        mSugScJBupin.setNormalColor(Color.parseColor("#80ff3320"));

        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) mSugScJBupin.getLayoutParams();
        int chartWidth = getWindowManager().getDefaultDisplay().getWidth() - layoutParams.leftMargin - layoutParams.rightMargin;
        float ySize = getResources().getDimension(R.dimen.absmsgsize) * "100".length();
        float lineWidth = getResources().getDimension(R.dimen.sug_detail_linewidth);
        mLineMaxPoints = (int) ((chartWidth - ySize - mSugScJBupin.getPaddingLeft()) / lineWidth);
        System.out.println(chartWidth + "----" + ySize + "------" + lineWidth + "-----" + mLineMaxPoints);

        //mSimplifyData和 motionPath2一定不为null
        updateUiews();
    }

    private void updateUiews() {
//        //平均 心率
//        mSugTvTbHeartrate.setText(mSimplifyData.getAvgHeartRate() + "");
//        //平均步频
//        mSugTvTbBupinrate.setText(mSimplifyData.getAvgStepRate() + "");

        int heartRatebig = Collections.max(mHeartRateList, new Comparator<HeartRateData>() {
            @Override
            public int compare(HeartRateData lhs, HeartRateData rhs) {
                return lhs.getHeartRate() - rhs.getHeartRate();
            }
        }).getHeartRate();
        //最大 心率
//        mSugTvTbHeartbig.setText(heartRatebig + "");
        int stepRatebig = Collections.max(mStepRateList, new Comparator<StepRateData>() {
            @Override
            public int compare(StepRateData lhs, StepRateData rhs) {
                return lhs.getStepRate() - rhs.getStepRate();
            }

        }).getStepRate();
        //最大 步频
//        mSugTvTbBupinbig.setText(stepRatebig + "");

        //设置曲线图 y轴信息
        mSugScJHeart.setYaxisValues(0, getCeil10(heartRatebig), 2);
        mSugScJBupin.setYaxisValues(0, getCeil10(stepRatebig), 2);
        mSugScJHeart.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v){
                mSugScJHeart.setSHowRegion(!mSugScJHeart.isSHowRegion());
                return true;
            }
        });
        //检查数据
        //时间一样 相隔一秒为准 报数据异常

        analyzeStep(mHeartRateList);

        //处理步频数据
        analyzeStep(mStepRateList);

        //处理 环形图数据
        arrayngeRingData();
    }

    private void arrayngeRingData() {
        int tag = 220 - 30;
        Iterator heartRateIterator = mHeartRateList.iterator();
        int timeWarmUp = 0;
        int timeFatBurning = 0;
        int timeAerobic = 0;
        int timeMarathon = 0;
        int timeAnaerobic = 0;

        while (heartRateIterator.hasNext()) {
            HeartRateData motionPathHeartRate = (HeartRateData) heartRateIterator.next();
            int rate = motionPathHeartRate.getHeartRate();
            if (rate >= tag * 0.9) {
                //timeWarmUp
                timeWarmUp++;
            } else if (rate >= tag * 0.8) {
                //timeFatBurning
                timeFatBurning++;
            } else if (rate >= tag * 0.7) {
                //timeAerobic
                timeAerobic++;
            } else if (rate >= tag * 0.6) {
                //timeMarathon
                timeMarathon++;
            } else if (rate >= tag * 0.5) {
                //timeAnaerobic
                timeAnaerobic++;
            }
        }

        SugChart.SugExcel hotbody = new SugChart.SugExcel(Color.parseColor("#73c0fd"), timeAnaerobic, "测试");
        SugChart.SugExcel burn = new SugChart.SugExcel(Color.parseColor("#b8e986"), timeMarathon, "测试");
        SugChart.SugExcel anaerobic = new SugChart.SugExcel(Color.parseColor("#f7eb57"), timeAerobic, "测试");
        SugChart.SugExcel aerobic = new SugChart.SugExcel(Color.parseColor("#ffbf55"), timeFatBurning, "测试");
        SugChart.SugExcel limit = new SugChart.SugExcel(Color.RED, timeWarmUp, "测试");
        mSugScJHeartPie.cmdFill(hotbody, burn, anaerobic, aerobic, limit);

        mSugTvHotbody.setText(timeAnaerobic + "分钟");
        mSugTvBurn.setText(timeMarathon + "分钟");
        mSugTvAnaerobic.setText(timeAerobic + "分钟");
        mSugTvAerobic.setText(timeFatBurning + "分钟");
        mSugTvLimit.setText(timeWarmUp + "分钟");
        int i = timeAnaerobic + timeMarathon + timeAerobic + timeFatBurning + timeWarmUp;
        System.out.println("==" + i);
    }

    private int getRound5(float num) {
        return ((int) (num + 2.5f)) / 5 * 5;
//        return ((int) (num + 5f)) / 5 * 5;
    }

    private int getCeil10(float num) {
        return ((int) (num + 9.99f)) / 10 * 10;
    }

    /**
     * 根据时间 判断显示多少段,
     */
    private void analyzeStep(ArrayList data) {
        ArrayList<Float> remainds = new ArrayList<>(); //5,4,3

        //处理心率数据  总时间/时间
        float totalTime = 0;//单位秒
        if (data.get(0) instanceof HeartRateData) {
            totalTime = ((HeartRateData) data.get(data.size() - 1)).getTime() - ((HeartRateData) data.get(0)).getTime();
        } else {
            totalTime = ((StepRateData) data.get(data.size() - 1)).getTime() - ((StepRateData) data.get(0)).getTime();
        }
        System.out.println("点个数：" + data.size() + "----时间：" + totalTime + ".....");
        totalTime = totalTime / 60;//转为分钟
        if (totalTime > 15) {

            float _5 = totalTime / 5;
            if (totalTime % 5 == 0) {
                arrangeHeartData(5, getRound5(_5), data, totalTime);
                return;
            }
            float _4 = totalTime / 4;
            if (totalTime % 4 == 0) {
                arrangeHeartData(4, getRound5(_4), data, totalTime);
                return;
            }
            float _3 = totalTime / 3;
            if (totalTime % 3 == 0) {
                arrangeHeartData(3, getRound5(_3), data, totalTime);
                return;
            }
            remainds.add(Math.abs(_5 - getRound5(_5)));
            remainds.add(Math.abs(_4 - getRound5(_4)));
            remainds.add(Math.abs(_3 - getRound5(_3)));

            Float min = Collections.min(remainds);
            for (int i = 0; i < remainds.size(); i++) {
                if (remainds.get(i).equals(min)) {
                    arrangeHeartData(5 - i, getRound5(totalTime / (5 - i)), data, totalTime);
                }
            }
        } else {
            //小于 15
            float _5 = totalTime / 5;
            if (totalTime % 5 == 0) {
                arrangeHeartData(5, Math.round(_5), data, totalTime);
                return;
            }
            float _4 = totalTime / 4;
            if (totalTime % 4 == 0) {
                arrangeHeartData(4, Math.round(_4), data, totalTime);
                return;
            }
            float _3 = totalTime / 3;
            if (totalTime % 3 == 0) {
                arrangeHeartData(3, Math.round(_3), data, totalTime);
                return;
            }
            remainds.add(Math.abs(_5 - Math.round(_5)));
            remainds.add(Math.abs(_4 - Math.round(_4)));
            remainds.add(Math.abs(_3 - Math.round(_3)));

            Float min = Collections.min(remainds);
            for (int i = 0; i < remainds.size(); i++) {
                if (Math.abs(min - remainds.get(i)) < .0000001) {
                    arrangeHeartData(5 - i, Math.round(totalTime / (5 - i)), data, totalTime);
                }
            }
        }
    }


    /**
     * @param duration   理论每段分钟(0,5结尾的段)
     * @param graph      多少段
     * @param mTotaldate
     * @param totalTime  分钟
     */
    private void arrangeHeartData(int graph, int duration, ArrayList mTotaldate, float totalTime) {

        totalTime = totalTime * 60;//总时间 转为秒
        //计算 显示时间
        float showTime = graph * duration;
        showTime = totalTime / 60 > showTime ? totalTime / 60 : showTime;
        int mAllowPoints = mLineMaxPoints;
        if (showTime <= mLineMaxPoints) {
            mAllowPoints = Math.round(showTime);
        }
        //
        float step = showTime * 60 / (mAllowPoints - 1);

        if (mTotaldate.get(0) instanceof HeartRateData) {
            System.out.println("心率---===分几组：" + graph + "---每组时间" + duration);
            //心率数据
            mHeartSugExcels = new ArrayList<>(mAllowPoints);

            float startTime = ((HeartRateData) mTotaldate.get(0)).getTime();//第一个点开始时间 秒
            int lastFinded = 0;

            //根据时间取数
            for (int i = 0; i < mAllowPoints; i++) {
                int excelY = 0;
                float currTime = 0;
                float goalTime = startTime + step * i;
                SugChart.SugExcel sugExcel = null;
                if (goalTime > totalTime) {
                    sugExcel = new SugChart.SugExcel(0, "" + ((int) (currTime / 60)));
                } else {
                    //从上次找到的地方 往下查找
                    for (int h = lastFinded; h < mHeartRateList.size() - 1; h++) {
                        currTime = mHeartRateList.get(h).getTime();
                        if (Math.abs(currTime - goalTime) < 0.0000001) {
                            lastFinded = h;
                            excelY = mHeartRateList.get(h).getHeartRate();
                            break;
                        } else if (currTime < goalTime) {
                            //指定时间 在两者之间
                            double nexTime = mHeartRateList.get(h + 1).getTime();
                            if (nexTime >= goalTime) {
                                lastFinded = h;
                                //根据相似比 计算
                                int h1 = mHeartRateList.get(h).getHeartRate();
                                int h2 = mHeartRateList.get(h + 1).getHeartRate();
                                excelY = (int) Math.round(h1 + ((h2 - h1) / (nexTime - currTime)) * (goalTime - currTime));
                                break;
                            }
                        }
                    }
                    sugExcel = new SugChart.SugExcel(excelY, "");
                }
                mHeartSugExcels.add(sugExcel);
            }
            System.out.println("心率实际取到的点个数>>" + mHeartSugExcels.size());
            mSugScJHeart.setXnums(graph, duration, showTime);
            mSugScJHeart.setLimitHeight(HEARTRATELIMIT);
//            mHeartSugExcels.clear();
//            mHeartSugExcels.add(new SugChart.SugExcel(80,""));
//            mHeartSugExcels.add(new SugChart.SugExcel(80,""));
//            mHeartSugExcels.add(new SugChart.SugExcel(110,""));
            mSugScJHeart.cmdFill(mHeartSugExcels);
        } else {
            System.out.println("步频---===分几组：" + graph + "---每组时间" + duration);
            //心率数据
            mStepSugExcels = new ArrayList<>(mAllowPoints);

            float startTime = ((StepRateData) mTotaldate.get(0)).getTime();//第一个点开始时间 秒
            int lastFinded = 0;
            //根据时间取数
            for (int i = 0; i < mAllowPoints; i++) {
                int excelY = 0;
                float currTime = 0;
                float goalTime = startTime + step * i;
                SugChart.SugExcel sugExcel = null;
                if (goalTime > totalTime) {
                    sugExcel = new SugChart.SugExcel(0, "" + ((int) (currTime / 60)));
                } else {
                //从上次找到的地方 往下查找
                for (int h = lastFinded; h < mStepRateList.size() - 1; h++) {
                    currTime = mStepRateList.get(h).getTime();
                    if (Math.abs(currTime - goalTime) < 0.0000001) {
                        lastFinded = h;
                        excelY = mStepRateList.get(h).getStepRate();
                        break;
                    } else if (currTime < goalTime) {
                        //指定时间 在两者之间
                        double nexTime = mStepRateList.get(h + 1).getTime();
                        if (nexTime >= goalTime) {
                            lastFinded = h;
                            //根据相似比 计算
//                            excelY = (int) Math.round(goalTime / nexTime * mHeartRateList.get(h + 1).getHeartRate());
                            int h1 = mStepRateList.get(h).getStepRate();
                            int h2 = mStepRateList.get(h + 1).getStepRate();
                            excelY = (int) Math.round(h1 + ((h2 - h1) / (nexTime - currTime)) * (goalTime - currTime));
                            break;
                        }
                    }
                }
                sugExcel = new SugChart.SugExcel(excelY, "");}
                mStepSugExcels.add(sugExcel);
            }
            System.out.println("步频 实际取到的点个数>>" + mStepSugExcels.size());
            mSugScJBupin.setXnums(graph, duration, showTime);
            mSugScJBupin.cmdFill(mStepSugExcels);
        }
    }

}
