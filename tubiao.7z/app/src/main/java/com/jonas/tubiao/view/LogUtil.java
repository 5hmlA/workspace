package com.jonas.tubiao.view;

import android.util.Log;

/**
 * @author jiangzuyun.
 * @date 2017/2/25
 * @des [一句话描述]
 * @since [产品/模版版本]
 */


public class LogUtil {

    public static void i(String tag, String s) {
        Log.i(tag, s);
    }

}
