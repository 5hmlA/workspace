/*
    This file is part of CoverflowAltTab.

    CoverflowAltTab is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    CoverflowAltTab is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CoverflowAltTab.  If not, see <http://www.gnu.org/licenses/>.
*/

/* CoverflowAltTab::CoverflowSwitcher:
 *
 * Extends CoverflowAltTab::Switcher, switching tabs using a cover flow.
 */

const Config = imports.misc.config;

const Clutter = imports.gi.Clutter;
const Graphene = imports.gi.Graphene;
const ExtensionImports = imports.misc.extensionUtils.getCurrentExtension().imports;

const BaseSwitcher = ExtensionImports.switcher.Switcher;

const {
    Preview,
    Placement,
    Direction,
    findUpperLeftFromCenter,
} = ExtensionImports.preview;

const SIDE_ANGLE = 90;
const BLEND_OUT_ANGLE = 30;
const ALPHA = 1;

function appendParams(base, extra) {
    for (let key in extra) {
        base[key] = extra[key];
    }
}

var CoverflowSwitcher = class CoverflowSwitcher extends BaseSwitcher {
    constructor(...args) {
        super(...args);
    }

    _createPreviews() {
        // TODO: Shouldn't monitor be set once per coverflow state?
        let monitor = this._updateActiveMonitor();
        let currentWorkspace = this._manager.workspace_manager.get_active_workspace();

        this._previewsCenterPosition = {
            x: monitor.width / 2,
            y: monitor.height / 2 + this._settings.offset
        };
        this._xOffsetLeft = monitor.width * 0.1;
        this._xOffsetRight = monitor.width - this._xOffsetLeft;

        for (let metaWin of this._windows) {
            let compositor = metaWin.get_compositor_private();
            if (compositor) {
                let texture = compositor.get_texture();
                let width, height;
                if (texture.get_size) {
                    [width, height] = texture.get_size();
                } else {
                    // TODO: Check this OK!
                    let preferred_size_ok;
                    [preferred_size_ok, width, height] = texture.get_preferred_size();
                }

                let scale = 1.0;
                let previewScale = this._settings.preview_to_monitor_ratio;
                let previewWidth = monitor.width * previewScale;
                let previewHeight = monitor.height * previewScale;
                if (width > previewWidth || height > previewHeight)
                     scale = Math.min(previewWidth / width, previewHeight / height);

                let preview = new Preview({
                    name: metaWin.title,
                    opacity: ALPHA * (!metaWin.minimized && metaWin.get_workspace() == currentWorkspace || metaWin.is_on_all_workspaces()) ? 255 : 0,
                    source: texture.get_size ? texture : compositor,
                    reactive: true,
                    x: metaWin.minimized ? 0 :
                        compositor.x - monitor.x,
                    y: metaWin.minimized ? 0 :
                        compositor.y - monitor.y,
                    translation_x: 0,
                    width: width,
                    height: height,
                    scale_x: metaWin.minimized ? 0 : 1,
                    scale_y: metaWin.minimized ? 0 : 1,
                    scale_z: metaWin.minimized ? 0 : 1,
                    rotation_angle_y: 0,
                });

                preview.scale = scale;
                preview.set_pivot_point_placement(Placement.CENTER);
                preview.center_position = {
                    x: findUpperLeftFromCenter(width,
                        this._previewsCenterPosition.x),
                    y: findUpperLeftFromCenter(height,
                        this._previewsCenterPosition.y)
                };

                this._previews.push(preview);
                this.previewActor.add_actor(preview);
            }
        }
    }

    _previewNext() {
        if (this._currentIndex == this._windows.length - 1) {
            this._currentIndex = 0;
            this._flipStack(Direction.TO_LEFT);
        } else {
            this._currentIndex = this._currentIndex + 1;
            this._updatePreviews();
        }
    }

    _previewPrevious() {
        if (this._currentIndex == 0) {
            this._currentIndex = this._windows.length-1;
            this._flipStack(Direction.TO_RIGHT);
        } else {
            this._currentIndex = this._currentIndex - 1;
            this._updatePreviews();
        }
    }

    _flipStack(direction) {
        this._looping = true;

        let xOffset, angle;
        this._updateActiveMonitor();

        if (direction === Direction.TO_LEFT) {
            xOffset = -this._xOffsetLeft;
            angle = BLEND_OUT_ANGLE;
        } else {
            xOffset = this._activeMonitor.width + this._xOffsetLeft;
            angle = -BLEND_OUT_ANGLE;
        }

        let animation_time = this._settings.animation_time * 2/3;

        for (let [i, preview] of this._previews.entries()) {
            preview._cfIsLast = (i === this._windows.length - 1);
            let params = {
                onComplete: this._onFlipIn,
                onCompleteScope: this,
                onCompleteParams: [preview, i, direction],
                transition: 'EaseInOutQuint',
                opacity: 0,
                x: 0,
                y: 0,
                scale_x: 0,
                scale_y: 0,
                scale_z: 0,
                rotation_angle_y: 0,
                time: animation_time * (direction === Direction.TO_RIGHT ? (i / this._previews.length) : (1 - i / this._previews.length)),
            };

            this._manager.platform.tween(preview, params);
        }
    }

    _onFlipIn(preview, index, direction) {
        let xOffsetStart, xOffsetEnd, angleStart, angleEnd;
        this._updateActiveMonitor();

        if (direction === Direction.TO_LEFT) {
            xOffsetStart = this._activeMonitor.width + this._xOffsetLeft;
            xOffsetEnd = this._xOffsetRight;
            angleStart = -BLEND_OUT_ANGLE;
            angleEnd = -SIDE_ANGLE;
        } else {
            xOffsetStart = -this._xOffsetLeft;
            xOffsetEnd = this._xOffsetLeft;
            angleStart = BLEND_OUT_ANGLE;
            angleEnd = SIDE_ANGLE;
        }

        let animation_time = this._settings.animation_time * 2/3;

        if (direction === Direction.TO_RIGHT) {
            preview.translation_x = xOffsetStart - (this._previewsCenterPosition.x
                - preview.width / 2) + 50 * (index - this._currentIndex);
        } else {
            preview.translation_x = xOffsetStart - (this._previewsCenterPosition.x
                + preview.width / 2) + 50 * (index - this._currentIndex);
        }
        let lastExtraParams = {
            transition: 'userChoice',
            onCompleteParams: [direction],
            onComplete: this._onFlipComplete,
            onCompleteScope: this
        };
        this._manager.platform.tween(preview, {
            transition: 'EaseInOutQuint',
            opacity: ALPHA * 255,
            time: animation_time,
        });
        preview.make_top_layer(this.previewActor);
        if (index == this._currentIndex) {
            preview.make_top_layer(this.previewActor);
            let extraParams = preview._cfIsLast ? lastExtraParams :  {transition: 'userChoice'};
            this._animatePreviewToMid(preview, animation_time, extraParams);
        } else {
            let extraParams = {
                rotation_angle_y: angleEnd,
                time: animation_time,
                transition: 'userChoice'
            };
            if (preview._cfIsLast)
                appendParams(extraParams, lastExtraParams);
            this._animatePreviewToSide(preview, index, xOffsetEnd, extraParams);
        }
    }

    _onFlipComplete(direction) {
        this._looping = false;
        if (this._requiresUpdate === true) {
            this._requiresUpdate = false;
            this._updatePreviews();
        }
    }

    // TODO: Remove unused direction variable
    _animatePreviewToMid(preview, animation_time, extraParams = []) {
        preview.make_top_layer(this.previewActor);
        let pivot_point = preview.get_pivot_point_placement(Placement.CENTER);
        let tweenParams = {
            x: findUpperLeftFromCenter(preview.width, this._previewsCenterPosition.x),
            y: findUpperLeftFromCenter(preview.height, this._previewsCenterPosition.y),
            scale_x: preview.scale,
            scale_y: preview.scale,
            scale_z: preview.scale,
            pivot_point: pivot_point,
            translation_x: 0,
            rotation_angle_y: 0,
            time: animation_time,
            transition: 'userChoice',
        };
        appendParams(tweenParams, extraParams);
        this._manager.platform.tween(preview, tweenParams);
    }

    _animatePreviewToSide(preview, index, xOffset, extraParams, toChangePivotPoint = true) {
        let [x, y] = preview.get_pivot_point();
        let pivot_point = new Graphene.Point({ x: x, y: y });
        if (toChangePivotPoint) {
            if (index < this._currentIndex) {
                pivot_point = preview.get_pivot_point_placement(Placement.LEFT);
            } else if (index > this._currentIndex) {
                pivot_point = preview.get_pivot_point_placement(Placement.RIGHT);
            }
        }
        let scale = Math.pow(this._settings.preview_scaling_factor, Math.abs(index - this._currentIndex));
        scale = scale * preview.scale;
        let tweenParams = {
            time: this._settings.animation_time,
            x: findUpperLeftFromCenter(preview.width, this._previewsCenterPosition.x),
            y: findUpperLeftFromCenter(preview.height, this._previewsCenterPosition.y),
            scale_x: scale,
            scale_y: scale,
            scale_z: scale,
            pivot_point: pivot_point,
        };
        if (index < this._currentIndex) {
            tweenParams.translation_x = xOffset - (this._previewsCenterPosition.x
                - preview.width / 2) + 50 * (index - this._currentIndex);
        } else if (index > this._currentIndex) {
            tweenParams.translation_x = xOffset - (this._previewsCenterPosition.x
                + preview.width / 2) + 50 * (index - this._currentIndex);
        }
        appendParams(tweenParams, extraParams);
        this._manager.platform.tween(preview, tweenParams);
    }

    _updatePreviews() {
        if(this._looping) {
            this._requiresUpdate = true;
            return;
        }

        this._updateActiveMonitor();

        // preview windows
        for (let [i, preview] of this._previews.entries()) {
            let animation_time = this._settings.animation_time * (this._settings.randomize_animation_times ? this._getRandomArbitrary(0.25, 1) : 1);
            if (i === this._currentIndex) {
                this._animatePreviewToMid(preview, animation_time);
            } else if (i < this._currentIndex) {
                preview.make_top_layer(this.previewActor);
                this._animatePreviewToSide(preview, i, this._xOffsetLeft, {
                    rotation_angle_y: SIDE_ANGLE,
                    time: animation_time,
                    transition: 'userChoice',
                });
            } else /* i > this._currentIndex */ {
                preview.make_bottom_layer(this.previewActor);
                this._animatePreviewToSide(preview, i, this._xOffsetRight, {
                    rotation_angle_y: -SIDE_ANGLE,
                    time: animation_time,
                    transition: 'userChoice',
                });
            }
            this._manager.platform.tween(preview, {
                opacity: ALPHA * 255,
                time: this._settings.animation_time,
                transition: 'EaseInOutQuint',
                onComplete: () => {
                    preview.set_reactive(true);
                }
            });
        }
    }
};
