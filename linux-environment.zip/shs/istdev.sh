echo "~/code/dev/My"
cd ~/code/dev/My
if [ "$1" = "clean" ]; then
    echo "./gradlew app:clean app:installRelease"
    ./gradlew app:clean app:assembleRelease
fi
adb install -r ~/code/dev/My/app/build/outputs/apk/release/dev-release.apk

