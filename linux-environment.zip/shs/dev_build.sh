echo "~/code/dev/My"
cd ~/code/dev/My
if [ "$1" = "clean" ]; then
    echo "./gradlew app:clean pp:assembleRelease"
    ./gradlew app:clean app:assembleRelease
else
    echo "./gradlew app:assembleRelease"
    ./gradlew app:assembleRelease
fi	
adb install -r -t ~/code/dev/My/app/build/outputs/apk/release/dev-release.apk

