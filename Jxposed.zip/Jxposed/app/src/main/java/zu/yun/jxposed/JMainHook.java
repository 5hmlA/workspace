package zu.yun.jxposed;

import android.graphics.Color;
import android.util.Log;
import android.widget.TextView;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * <pre>
 *     author : jinagzuyun
 *     e-mail : jonas.jzy@gmail.com
 *     time   : 2019/03/16
 *     desc   :
 *     version: 1.0
 * </pre>
 */
public class JMainHook implements IXposedHookLoadPackage {
	public static final String TAG = JMainHook.class.getSimpleName();


	public static void Jlog(Object... o) {
		StringBuilder stringBuilder = new StringBuilder();
		for (Object o1 : o) {
			stringBuilder.append(o1.toString()).append("  **  ");
		}
		Log.e(TAG, stringBuilder.toString());
		//XposedBridge.log("XposedBridge : " + stringBuilder.toString());
	}


	@Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
		Jlog("  ===========  handleLoadPackage    ==========",lpparam.packageName);
		//com.miui.weather2
		//com.android.deskclock
		//com.miui.core
		//com.android.calendar
		//com.android.mms

		if("zu.yun.jxposed".equals(lpparam.packageName)) {
			Jlog(lpparam.isFirstApplication, lpparam.processName, lpparam.packageName);
			XposedHelpers.findAndHookMethod("android.widget.TextView", lpparam.classLoader, "setText", CharSequence.class, new XC_MethodHook() {
				@Override protected void afterHookedMethod(MethodHookParam param) throws Throwable {
					//super.afterHookedMethod(param);
					Jlog("=================");
					TextView thisObject = (TextView) param.thisObject;
					//thisObject.setText("09090");
					thisObject.setTextColor(Color.RED);
					Jlog("======   ===========  ");
					//TextView tv = (TextView) param.thisObject;
					//String text = tv.getText().toString();
					//tv.setText(text + " :)");
					//tv.setTextColor(Color.RED);
				}
			});
		}
		if("com.android.systemui".equals(lpparam.packageName)) {
			XposedHelpers.findAndHookMethod("com.android.systemui.statusbar.policy.Clock", lpparam.classLoader, "updateClock", new XC_MethodHook() {
				@Override protected void afterHookedMethod(MethodHookParam param) throws Throwable {
					//super.afterHookedMethod(param);
					//TextView thisObject = (TextView) param.thisObject;
					//thisObject.setTextColor(Color.RED);
					TextView tv = (TextView) param.thisObject;
					String text = tv.getText().toString();
					tv.setText("赟哥 "+text + " :)");
					tv.setTextColor(Color.RED);
				}
			});
		}
	}

	//@Override public void initZygote(StartupParam startupParam) throws Throwable {
	//	Jlog("  ===========  initZygote    ==========");
	//	Jlog(startupParam.modulePath,startupParam.startsSystemServer);
	//}
	//
	//
	//@Override public void handleInitPackageResources(XC_InitPackageResources.InitPackageResourcesParam resparam) throws Throwable {
	//	Jlog("  ===========  handleInitPackageResources    ==========");
	//	Jlog(resparam.packageName);
	//}
}
