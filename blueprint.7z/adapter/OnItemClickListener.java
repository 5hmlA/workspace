package com.blueprint.adapter;

/**
 * @another 江祖赟
 * @date 2017/6/21.
 */
public interface OnItemClickListener<T> {
    void onItemClicked(T itemData, int position);
}
