package com.blueprint.adapter;

import android.content.Context;
import android.support.annotation.LayoutRes;

/**
 * @another 江祖赟
 * @date 2017/7/5.
 */
public interface IRecvJData {
    void setHolderLayout(@LayoutRes int layoutut);

    void bindHolder(Context context);
}
