package com.blueprint.http;

public class HttpResult<T> {

    public boolean error;
    public T results;
}
