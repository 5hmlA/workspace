package com.blueprint.crash;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class CrashLog {
    private static final String TAG = "CrashLog";

    /**
     * 保存异常信息到sdcard中
     *
     * @param pContext
     * @param ex
     *         异常信息对象
     */
    public static void saveCrashToSdcard(Context pContext, Throwable ex){
        String fileName = null;
        StringBuffer sBuffer = new StringBuffer();
        // 添加异常信息
        sBuffer.append(getExceptionInfo(ex));
        if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File externalCacheDir = pContext.getExternalCacheDir();
            if(externalCacheDir == null) {
                externalCacheDir = pContext.getCacheDir();
            }
            String logDir = externalCacheDir.getAbsolutePath()+File.separator+"Crashs";

            File file1 = new File(logDir);
            if(!file1.exists()) {
                file1.mkdir();
            }
            fileName = file1.toString()+File.separator+paserTime(System.currentTimeMillis())+".log";
            File file2 = new File(fileName);
            FileOutputStream fos;
            try {
                fos = new FileOutputStream(file2);
                fos.write(sBuffer.toString().getBytes());
                fos.flush();
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 获取并且转化异常信息
     * 同时可以进行投递相关的设备，用户信息
     *
     * @param ex
     * @return 异常信息的字符串形式
     */
    public static String getExceptionInfo(Throwable ex){
//        CRASH_HEAD = "\n************* Crash Log Head ****************" +
//                "\nDevice Manufacturer: " + Build.MANUFACTURER +// 设备厂商
//                "\nDevice Model       : " + Build.MODEL +// 设备型号
//                "\nAndroid Version    : " + Build.VERSION.RELEASE +// 系统版本
//                "\nAndroid SDK        : " + Build.VERSION.SDK_INT +// SDK版本
//                "\nApp VersionName    : " + versionName +
//                "\nApp VersionCode    : " + versionCode +
//                "\n************* Crash Log Head ****************\n\n";
        StringWriter sw = new StringWriter();
        ex.printStackTrace(new PrintWriter(sw));
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("---------Crash Log Begin---------\n");
        //在这边可以进行相关设备信息投递--这边就稍微设置几个吧
        //其他设备和用户信息大家可以自己去扩展收集上传投递
        stringBuffer.append("SystemVersion:"+getLocalSystemVersion()+"\n");
        stringBuffer.append(sw.toString()+"\n");
        stringBuffer.append("---------Crash Log End---------\n");
        return stringBuffer.toString();
    }

    /**
     * 将毫秒数转换成yyyy-MM-dd-HH-mm-ss的格式
     *
     * @param milliseconds
     * @return
     */
    public static String paserTime(long milliseconds){
        System.setProperty("user.timezone", "Asia/Shanghai");
        TimeZone tz = TimeZone.getTimeZone("Asia/Shanghai");
        TimeZone.setDefault(tz);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        String times = format.format(new Date(milliseconds));

        return times;
    }

    // 获取手机系统版本
    public static String getLocalSystemVersion(){
        String version = android.os.Build.VERSION.RELEASE;
        if(version == null) {
            version = "";
        }
        return version;
    }
}
