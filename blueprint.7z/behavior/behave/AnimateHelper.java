package com.blueprint.behavior.behave;

/**
 * Created by wing on 11/8/16.
 */

public interface AnimateHelper {


    int STATE_SHOW = 1;
    int STATE_HIDE = 0;


    void show();

    void hide();

}
