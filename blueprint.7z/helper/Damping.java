package com.blueprint.helper;

import android.animation.ValueAnimator;
import android.graphics.PointF;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.animation.LinearOutSlowInInterpolator;
import android.support.v7.widget.RecyclerView;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;

import com.blueprint.LibApp;

import static android.support.v7.widget.RecyclerView.SCROLL_STATE_SETTLING;

/**
 * @author yun.
 * @date 2017/7/15
 * @des [一句话描述]
 * @since [https://github.com/mychoices]
 * <p><a href="https://github.com/mychoices">github</a>
 */
public class Damping {
    private static final long ANIDURATION = 300;
    private View mView;
    float mScale;
    private PointF mTdown;
    private float mDistance;
    private int direction = LinearLayout.VERTICAL;

    public class DampScrollListener extends RecyclerView.OnScrollListener{
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState){
            if(newState == SCROLL_STATE_SETTLING) {
                //向下滚动然后快速反向滚动
                if (mDistance > 0) {
                    animateRestore(true);
                } else {
                    animateRestore(false);
                }
            }
        }
    }

    public Damping(View view){
        mView = view;
        if(view instanceof RecyclerView) {
            ( (RecyclerView)mView ).addOnScrollListener(new DampScrollListener());
        }
    }

    public Damping configDirection(int direction){
        this.direction = direction;
        return this;
    }

    public void animateRestore(final boolean isPullRestore){
        ValueAnimator animator = ValueAnimator.ofFloat(mScale, 1f);
        animator.setDuration(300);
        animator.setInterpolator(new OvershootInterpolator(1.6f));
        //        animator.setInterpolator(new DecelerateInterpolator(2f));
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation){
                float value = (float)animation.getAnimatedValue();
                if(isPullRestore) {
                    pull(value);
                }else {
                    push(value);
                }
            }
        });
        animator.start();
    }


    public float calculateDamping2(float distance){
        float dragRadio = distance/( LibApp.getContext().getResources().getDisplayMetrics().heightPixels );
        float dragPercent = Math.min(1f, dragRadio);
        float rate = 2f*dragPercent-(float)Math.pow(dragPercent, 2f);
        return mScale = 1+rate/6f;
    }

    /**
     * 处于顶部 往下拉动
     */
    public void pull(float mScale){
        if(direction == LinearLayout.VERTICAL) {
            mView.setPivotY(mView.getPaddingTop());
            mView.setScaleY(mScale);
        }else {
            mView.setPivotX(mView.getPaddingLeft());
            mView.setScaleX(mScale);
        }
    }

    /**
     * 处于底部 往上拉动
     */
    public void push(float mScale){
        if(direction == LinearLayout.VERTICAL) {
            mView.setPivotY(mView.getHeight());
            mView.setScaleY(mScale);
        }else {
            mView.setPivotX(mView.getRight());
            mView.setScaleX(mScale);
        }

    }


    /**
     * 处于顶部 往下拉动
     *
     * @param miui
     * @param scale
     */
    public static void pull(View miui, float scale){
        miui.setPivotY(miui.getPaddingTop());
        miui.setScaleY(scale);
    }

    /**
     * 处于底部 往上拉动
     *
     * @param miui
     * @param scale
     */
    public static void push(View miui, float scale){
        miui.setPivotY(miui.getHeight());
        miui.setScaleY(scale);
    }

    public static void hide(final View view){
        view.animate().cancel();
        view.animate().translationY(-view.getHeight()).setInterpolator(new LinearOutSlowInInterpolator()).withLayer()
                .setDuration(ANIDURATION).start();
    }

    public static void hide(final View view, int height){
        view.animate().cancel();
        view.animate().translationY(-height).setInterpolator(new LinearOutSlowInInterpolator()).withLayer()
                .setDuration(ANIDURATION).start();
    }

    public static void show(final View view){
        view.animate().cancel();
        view.animate().translationY(0).setInterpolator(new LinearOutSlowInInterpolator()).withLayer()
                .setDuration(ANIDURATION).start();
    }


    public static float calculateDamping(float distance){
        float dragRadio = distance/( LibApp.getContext().getResources().getDisplayMetrics().heightPixels );
        float dragPercent = Math.min(1f, dragRadio);
        float rate = 2f*dragPercent-(float)Math.pow(dragPercent, 2f);
        return 1+rate/6f;
    }

    public static void animateRestore(final View miui, float mScale, final boolean isPullRestore){
        ValueAnimator animator = ValueAnimator.ofFloat(mScale, 1f);
        animator.setDuration(300);
        animator.setInterpolator(new OvershootInterpolator(1.6f));
        //        animator.setInterpolator(new DecelerateInterpolator(2f));
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation){
                float value = (float)animation.getAnimatedValue();
                if(isPullRestore) {
                    pull(miui, value);
                }else {
                    push(miui, value);
                }
            }
        });
        animator.start();
    }

    public static boolean isScrollToTop(View view){
        return !ViewCompat.canScrollVertically(view, -1);
    }

    public static boolean isScrollToBottom(View view){
        return !ViewCompat.canScrollVertically(view, 1);
    }

    public boolean isScrollToTop(){
        return !ViewCompat.canScrollVertically(mView, -1);
    }

    public boolean isScrollToBottom(){
        return !ViewCompat.canScrollVertically(mView, 1);
    }


    public boolean dampOnTouch(MotionEvent event){
        if(mView != null) {
            switch(event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    mTdown = new PointF(event.getX(), event.getY());
                    break;
                case MotionEvent.ACTION_MOVE:
                    if(mTdown == null) {
                        mTdown = new PointF(event.getX(), event.getY());
                    }
                    float c = event.getY();
                    float l = mTdown.y;
                    if(direction == LinearLayout.HORIZONTAL) {
                        c = event.getX();
                        l = mTdown.x;
                    }
                    calcuteMove(c, l);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    mTdown = null;
                    if(isScrollToTop() && !isScrollToBottom()) {
                        animateRestore(true);
                    }else if(!isScrollToTop() && isScrollToBottom()) {
                        animateRestore(false);
                    }else if(isScrollToTop() && isScrollToBottom()) {
                        if(mDistance>0) {
                            animateRestore(true);
                        }else {
                            animateRestore(false);
                        }
                    }
                    break;

            }
        }
        return false;
    }

    private void calcuteMove(float y, float ly){
        if(isScrollToTop() && !isScrollToBottom()) {
            // 在顶部不在底部
            mDistance = y-ly;
            mScale = Damping.calculateDamping(mDistance);
            pull(mScale);
        }else if(!isScrollToTop() && isScrollToBottom()) {
            // 在底部不在顶部
            mDistance = ly-y;
            mScale = calculateDamping(mDistance);
            push(mScale);
        }else if(isScrollToTop() && isScrollToBottom()) {
            // 在底部也在顶部
            mDistance = y-ly;
            if(mDistance>0) {
                mScale = calculateDamping(mDistance);
                pull(mScale);
            }else {
                mScale = calculateDamping(-mDistance);
                push(mScale);
            }
        }
        //去掉 会没有底部反弹效果
//        mDistance = y-ly;
        //顶部下拉 有filing 底部上拉有filing 两侧都会有回弹效果
        mDistance = ly-y;
    }
}

