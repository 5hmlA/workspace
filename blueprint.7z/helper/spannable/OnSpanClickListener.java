package com.blueprint.helper.spannable;

/**
 * @author yiw
 * @Description:
 * @date 16/1/2 19:44
 */
public interface OnSpanClickListener {
    public void onClick(CharSequence clickSpanStr);
}
