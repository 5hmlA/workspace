package com.blueprint.helper;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.blueprint.R;
import com.blueprint.helper.spannable.CircleMovementMethod;
import com.blueprint.helper.spannable.OnSpanClickListener;
import com.blueprint.helper.spannable.SpannableClickable;

import april.yun.other.JTabStyleDelegate;

import static com.blueprint.LibApp.findColor;
import static com.blueprint.LibApp.findDimens;

/**
 * @another 江祖赟
 * @date 2017/7/3.
 */
public class UIhelper {

    /**
     * 无边框 圆角
     *
     * @param textView
     * @param bgColor
     * @param textColor
     */
    public static GradientDrawable RoundBgText(TextView textView, int bgColor, int textColor){
        return RoundBgText(textView, Integer.MAX_VALUE, 0, bgColor, textColor);
    }

    /**
     * 无边框 圆角
     *
     * @param textView
     * @param bgColor
     *         背景颜色
     * @param textColor
     *         文字颜色
     */
    public static void RoundBgTextRes(TextView textView, int bgColor, int textColor){
        RoundBgText(textView, Integer.MAX_VALUE, 0, findColor(bgColor), findColor(textColor));
    }

    /**
     * 边框2 文字边框颜色一样
     *
     * @param textView
     * @param color
     *         文字颜色
     */
    public static GradientDrawable RoundBgText(TextView textView, int color){
        return RoundBgText(textView, Float.MAX_VALUE, color);
    }

    /**
     * 边框2 文字边框颜色一样
     *
     * @param textView
     * @param color
     *         文字颜色
     */
    public static GradientDrawable RoundBgTextRes(TextView textView, int color){
        return RoundBgText(textView, Float.MAX_VALUE, findColor(color));
    }

    /**
     * 边框为2
     *
     * @param textView
     * @param cornerRadius
     *         圆角半斤
     * @param color
     *         文字颜色
     */
    public static GradientDrawable RoundBgText(TextView textView, float cornerRadius, int color){
        return RoundBgText(textView, cornerRadius, 1, color, color);
    }

    /**
     * @param textView
     * @param strokeWidth
     * @param strokeColor
     * @param textColor
     */
    public static GradientDrawable RoundBgText(TextView textView, float cornerRadius, int strokeWidth, int strokeColor, int textColor){
        GradientDrawable drawable = new GradientDrawable();
        drawable.setCornerRadius(cornerRadius);
        drawable.setColor(Color.TRANSPARENT);//To shange the solid color gd
        if(strokeWidth == 0) {
            drawable.setColor(strokeColor);
        }else {
            drawable.setStroke(strokeWidth, strokeColor);
        }
        textView.setTextColor(textColor);
        textView.setBackground(drawable); //不同标签不同背景颜色
        return drawable;
    }

    public static JTabStyleDelegate initTabStrip(JTabStyleDelegate tabStyleDelegate){
        //        2，拿TabStyleDelegate
        //        3, 用TabStyleDelegate设置属性
        tabStyleDelegate.setShouldExpand(false)
                //也可以直接传字符串的颜色，第一个颜色表示checked状态的颜色第二个表示normal状态
                .setTextColor(findColor(R.color.colorPrimary), findColor(R.color.j_gray999))
                .setTabTextSize(findDimens(R.dimen.tab_top_textsize)).setTabPadding(findDimens(R.dimen.tab_pading))
                .setDividerPadding(0)//tab之间分割线 的上下pading
                .setTabPadding(0).setUnderlineHeight(0)//底部横线的高度
                .setIndicatorHeight(findDimens(R.dimen.tab_indicator_height))
                .setUnderlineHeight(findDimens(R.dimen.tab_underline_height))
                .setUnderlineColor(Color.parseColor("#e6e6e6")).setIndicatorColor(findColor(R.color.colorPrimary));
        return tabStyleDelegate;
    }

    public static PopupWindow getDynamicDelPopWindow(Context context, View.OnClickListener listener){
        //评论删除
        PopupWindow delWindow = new PopupWindow(context);
        //        View contentView = layout2View(R.layout.dynamic_home_popdel, null);
        //        View delView = contentView.findViewById(R.id.dynamic_home_del);
        //        delView.setOnClickListener(listener);
        //        delWindow.setContentView(contentView);
        //        delWindow.setWidth(dp2pxCeilInt(78));
        //        delWindow.setHeight(dp2pxCeilInt(37));
        //        delWindow.setOutsideTouchable(true);
        //        delWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        //        delView.setTag(delWindow);
        //        delWindow.getContentView().setTag(delView);
        return delWindow;
    }

    public static DialogHelper getCommonDelDialog(Activity activity, String content, View.OnClickListener listener){

        return DialogHelper.create(activity).customDialog(R.layout.dialog_jblu_common_msg)
                .setText(R.id.dialog_jblu_common_content, content).setOnclickListener(R.id.dialog_cancel, listener)
                .setOnclickListener(R.id.dialog_confirm, listener);
    }

    public static SpannableString clickSpanAbleString(String spanString, int presColor, final OnSpanClickListener
            spanClickListener){
//        int pressColor = LibApp.findColor(R.color.j_black_a85);
        final CircleMovementMethod circleMovementMethod = new CircleMovementMethod(presColor, presColor);
        SpannableString subjectSpanText = new SpannableString(spanString);
        subjectSpanText.setSpan(new SpannableClickable(Color.parseColor("#6093CD")) {
            @Override
            public void onClick(View widget){
                // TODO add check if widget instanceof TextView
                TextView tv = (TextView)widget;
                // TODO add check if tv.getText() instanceof Spanned
                Spanned s = (Spanned)tv.getText();
                int start = s.getSpanStart(this);
                int end = s.getSpanEnd(this);
                Log.d("clickSpan", "onClick ["+s.subSequence(start, end)+"]");
                spanClickListener.onClick(s.subSequence(start, end));
            }
        }, 0, subjectSpanText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return subjectSpanText;
    }


}
