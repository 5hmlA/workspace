package com.blueprint.basic.features;

/**
 * @another 江祖赟
 * @date 2017/6/27.
 */
public class IWebViewFeature {}
