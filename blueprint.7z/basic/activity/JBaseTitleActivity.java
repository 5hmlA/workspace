package com.blueprint.basic.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;

import com.blueprint.R;
import com.blueprint.basic.JBasePresenter;
import com.blueprint.widget.JTitleBar;
import com.jakewharton.rxbinding2.view.RxView;

import java.util.concurrent.TimeUnit;

import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Consumer;
import jonas.jlayout.MultiStateLayout;
import jonas.jlayout.OnStateClickListener;

import static com.blueprint.LibApp.setTextView;

/**
 * @author 江祖赟.
 * @date 2017/6/7
 * @des [标题+状态界面  有统一处理 basePresenter的subscribe和unsubscribe]
 * 在 onAttachtoWindow会获取数据
 * onContentChanged在setContentView内部调用 然后基类才获取各种控件，所以在onContentChanged中可以获取intent中的数据，就不需要在super.onCreate之前获取数据
 */
public abstract class JBaseTitleActivity extends JBaseActivity implements OnStateClickListener {
    public MultiStateLayout mMultiStateLayout;
    public JTitleBar mTitleBar;
    public JBasePresenter mBasePresenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        mBasePresenter = initPresenter();
        setContentView(R.layout.jbasic_title_state_layout);
        mMultiStateLayout = (MultiStateLayout)findViewById(R.id.jbase_state_container);
        mMultiStateLayout.setOnStateClickListener(this);
        mTitleBar = (JTitleBar)findViewById(R.id.jbase_titlebar);
        if(requestNoTitleBar()) {
            mTitleBar.setVisibility(View.GONE);
        }else {
            initStableViews();
        }
        onCreateContent(getLayoutInflater(), mMultiStateLayout);
    }

    protected abstract JBasePresenter initPresenter();

    //onResume之后
    @Override
    public void onAttachedToWindow(){
        super.onAttachedToWindow();
        toSubscribe();
    }

    @Override
    public void onContentChanged(){
        super.onContentChanged();
        //该方法是在 setContentView()内部触发的 并不是onCreate结束之后才执行
        //        @Override
        //        public void setContentView(View v) {
        //            ensureSubDecor();
        //            ViewGroup contentParent = (ViewGroup) mSubDecor.findViewById(android.R.id.content);
        //            contentParent.removeAllViews();
        //            contentParent.addView(v);
        //            mOriginalWindowCallback.onContentChanged();
        //        }
    }

    /**
     * 默认 有titlebar
     *
     * @return
     */
    protected boolean requestNoTitleBar(){
        return false;
    }

    private void initStableViews(){
        //标题内容
        setTextView(mTitleBar.getTitleTextView(), setTitle());
        //空页面提示信息
        setTextView(mMultiStateLayout.getEmptyLayout(), R.id.j_multity_empt_msg, setEmptMsg());
        setTextView(mMultiStateLayout.getEmptyLayout(), R.id.j_multity_retry, setEmptRetryMsg());
        //错误页面提示信息
        setTextView(mMultiStateLayout.getErrorLayout(), R.id.j_multity_error_msg, setErrorMsg());
        setTextView(mMultiStateLayout.getErrorLayout(), R.id.j_multity_retry, setErrorRetryMsg());

        setClicks();

        refreshTitleBar(mTitleBar);
    }

    /**
     * 复写 更新titlebar样式
     *
     * @param titleBar
     */
    protected void refreshTitleBar(JTitleBar titleBar){

    }

    private void setClicks(){
        //左边的点击事件
        RxView.clicks(mTitleBar.getLiftIcon()).subscribe(new Consumer<Object>() {
            @Override
            public void accept(@NonNull Object aVoid) throws Exception{
                doTitleBarLeftClick();
            }
        });
        RxView.clicks(mTitleBar.getRightIcon()).throttleFirst(1, TimeUnit.SECONDS).subscribe(new Consumer<Object>() {
            @Override
            public void accept(@NonNull Object aVoid) throws Exception{
                doTitleBarRightClick();
            }
        });
    }

    protected void doTitleBarRightClick(){

    }

    protected void doTitleBarLeftClick(){
        onBackPressed();
    }

    protected CharSequence setErrorRetryMsg(){
        return null;
    }

    protected CharSequence setEmptRetryMsg(){
        return null;
    }

    protected String setErrorMsg(){
        return "";
    }

    protected String setEmptMsg(){
        return "";
    }

    protected String setTitle(){
        return null;
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        if(mBasePresenter != null) {
            mBasePresenter.unsubscribe();
        }
    }

    /**
     * 将布局添加到 container中
     *
     * @param inflater
     * @param container
     */
    protected abstract void onCreateContent(LayoutInflater inflater, RelativeLayout container);

    @Override
    public void onRetry(@MultiStateLayout.LayoutState int layoutState){
        toSubscribe();
    }

    private void toSubscribe(){
        if(mBasePresenter != null) {
            mBasePresenter.subscribe(null);
        }
    }

    @Override
    public void onLoadingCancel(){
       //todo
    }

}
