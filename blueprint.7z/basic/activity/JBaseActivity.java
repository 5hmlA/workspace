package com.blueprint.basic.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.transition.Explode;
import android.widget.Toast;

import com.blueprint.LibApp;
import com.blueprint.R;
import com.blueprint.helper.NetHelper;
import com.blueprint.helper.ToastHelper;

import java.util.concurrent.TimeUnit;

import io.reactivex.Single;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

/**
 * @author 江祖赟.
 * @date 2017/6/6
 * @des [一句话描述]
 */
public class JBaseActivity extends AppCompatActivity {

    public Toast mDoubleFinish;
    protected CompositeDisposable mCompositeDisposable = new CompositeDisposable();
    private boolean currentWifi;
    private NetworkConnectChangedReceiver mConnectChangedReceiver;

    protected void collectDisposables(Disposable disposable){
        mCompositeDisposable.add(disposable);
    }

    protected void clearDisposables(){
        mCompositeDisposable.clear();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setExitTransition(new Explode());
            getWindow().setEnterTransition(new Explode());
        }
        mDoubleFinish = Toast.makeText(this, LibApp.findString(R.string.jdouble_exit), Toast.LENGTH_SHORT);
        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        mConnectChangedReceiver = new NetworkConnectChangedReceiver();
        registerReceiver(mConnectChangedReceiver, filter);
        currentWifi = NetHelper.isWifionnected();
    }

    public void doubleExit(){
        if(mDoubleFinish.getView() != null && mDoubleFinish.getView().isShown()) {
            finish();
            Single.just(0).delay(400, TimeUnit.MILLISECONDS).subscribe(new Consumer<Integer>() {
                @Override
                public void accept(@NonNull Integer integer) throws Exception{
                    System.exit(0);
                }
            });
        }else {
            mDoubleFinish.show();
        }
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if(mConnectChangedReceiver != null) {
            unregisterReceiver(mConnectChangedReceiver);
        }
        clearDisposables();
    }

    private class NetworkConnectChangedReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent){
            if(NetHelper.isConnected()) {
                if(!NetHelper.isWifionnected()) {
                    if(currentWifi) {
                        currentWifi = false;
                        ToastHelper.showShort("切换到手机流量");
                    }
                }else {
                    if(!currentWifi) {
                        currentWifi = NetHelper.isWifionnected();
                        ToastHelper.showShort("切换到wifi");
                    }
                }
            }
        }
    }
}
