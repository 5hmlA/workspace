package com.blueprint.basic.frgmt;


import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.blueprint.R;
import com.blueprint.adapter.LoadMoreWrapperAdapter;
import com.blueprint.adapter.OnMoreloadListener;
import com.blueprint.adapter.RecyclerHolder;
import com.blueprint.adapter.decoration.JDividerItemDecoration;
import com.blueprint.basic.JBasePresenter;
import com.blueprint.basic.common.GeneralListContract;
import com.blueprint.basic.common.GeneralListPresenter;

import java.util.ArrayList;
import java.util.List;

import me.drakeet.multitype.MultiTypeAdapter;

import static com.blueprint.Consistent.ErrorCode.ERROR_EMPTY;

/**
 * @author 江祖赟.
 * @date 2017/6/7
 * @des [推荐]
 */
public abstract class JAbsListFrgmt<IT,SD> extends JBaseTitleFrgmt implements GeneralListContract.View<IT,SD>,
        SwipeRefreshLayout.OnRefreshListener, OnMoreloadListener {
    public RecyclerView mCommonRecv;
    public SwipeRefreshLayout mSwipeRefreshLayout;
    public List<IT> mListData = new ArrayList();
    public LoadMoreWrapperAdapter mRecvAdapter;
    public GeneralListPresenter<IT> mGeneralListPresenter;
    private static final int NO_CUSTOM_LAYOUT  = -10;

    @Override
    protected final JBasePresenter initPresenter(){
        return mGeneralListPresenter = initListPresenter();
    }

    protected abstract GeneralListPresenter<IT> initListPresenter();

    @Override
    protected boolean requestNoTitleBar(){
        return true;
    }

    @Override
    protected void onCreateContent(LayoutInflater inflater, RelativeLayout container){
        View rootView;
        if(setCustomLayout() == NO_CUSTOM_LAYOUT) {
            rootView = inflater.inflate(R.layout.jbasic_abslist_layout, container);
        }else {
            rootView = inflater.inflate(setCustomLayout(), container);
        }
        mCommonRecv = (RecyclerView)rootView.findViewById(R.id.jbase_recv);
        mSwipeRefreshLayout = (SwipeRefreshLayout)rootView.findViewById(R.id.jbase_swipe);
        initRecView();
        initSwipeLayout();
    }

    public int setCustomLayout(){
        return NO_CUSTOM_LAYOUT;
    }

    private void initSwipeLayout(){
        mSwipeRefreshLayout.setEnabled(setEnableSwipeRefresh());
        mSwipeRefreshLayout.setOnRefreshListener(this);
    }

    private void initRecView(){
        MultiTypeAdapter multiTypeAdapter = new MultiTypeAdapter(mListData);
        mCommonRecv.setLayoutManager(setLayoutManager());
        mCommonRecv.addItemDecoration(setItemDecoration());
        register2Adapter(multiTypeAdapter);
        mRecvAdapter = new LoadMoreWrapperAdapter(multiTypeAdapter) {

            @Override
            public RecyclerHolder onCreateLoadingHolder(ViewGroup parent){
                return setLoadingHolder(parent);
            }

            @Override
            public void loadError(){
                setLoadError();
            }
        };
        mRecvAdapter.setPagesize(setPageSize());
        mRecvAdapter.setOnMoreloadListener(this);
        mCommonRecv.setAdapter(mRecvAdapter);
    }

    protected RecyclerView.ItemDecoration setItemDecoration(){
        return new JDividerItemDecoration(1);
    }

    public int setPageSize(){
        return 10;
    }

    @Override
    public void enAbleLoadMore(boolean enable){
        mRecvAdapter.enAbleLoadMore(enable);
    }

    /**
     * 没必要复写或者调用adapter的loadError
     * 只要持有loadingHolder就可以动态修改footview的显示
     */
    public void setLoadError(){
        mRecvAdapter.loadError();
    }

    /**
     * 通过该方法 创建的footview可以控制上拉加载,加载失败,没有更多 三种状态
     * @param parent
     * @return
     */
    protected RecyclerHolder setLoadingHolder(ViewGroup parent){
        return null;
    }

    protected abstract RecyclerView.LayoutManager setLayoutManager();

    protected abstract void register2Adapter(MultiTypeAdapter multiTypeAdapter);

    public boolean setEnableSwipeRefresh(){
        return true;
    }

    @Override
    public void onRefresh(){
        if(mGeneralListPresenter != null) {
            mGeneralListPresenter.down2RefreshData(mListData);
        }
    }

    /**
     * 上拉加载更多
     */
    @Override
    public void onup2LoadingMore(){
        if(mGeneralListPresenter != null) {
            mGeneralListPresenter.up2LoadMoreData(mListData);
        }
    }

    @Override
    public void onMoreLoad(List<IT> moreData){
        mRecvAdapter.addMoreList(moreData);
    }

    @Override
    public void showSucceed(List<SD> data){
        //结束 下拉刷新状态
        mSwipeRefreshLayout.setRefreshing(false);
        mRecvAdapter.refreshAllData(data);
        mMultiStateLayout.showStateSucceed();
    }

    @Override
    public void showLoading(){
        mMultiStateLayout.showStateLoading();
    }

    @Override
    public void showError(int eCode){
        if(eCode == ERROR_EMPTY) {
            mMultiStateLayout.showStateEmpty();
        }else {
            mMultiStateLayout.showStateError();
        }
    }
}
