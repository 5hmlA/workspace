package com.blueprint.basic.common;

import com.blueprint.basic.JBaseView;
import com.blueprint.basic.JBasePresenter;

import java.util.List;

/**
 * @another 江祖赟
 * @date 2017/6/21.
 */
public class GeneralListContract {
    //页面可能存在多种数据 list列表 只是其中一种/如果showSucceed的数据是复杂的Object那就返回一个元素的集合即可
    public interface View<IT, SD> extends JBaseView<List<SD>> {

        void onMoreLoad(List<IT> moreData);

        /**
         * listv有数据 但是enAbleLoadMore传入false那么就是上拉加载更多失败
         *
         * @param enable
         */
        void enAbleLoadMore(boolean enable);

        /**
         * 上啦加载更多失败
         */
//        void onMoreLoadError();
    }

    public interface Presenter<IT> extends JBasePresenter<Object> {

        void search(String key);//success显示数据

        void up2LoadMoreData(List<IT> containerData);

        void down2RefreshData(List<IT> containerData);//success显示数据
    }
}
