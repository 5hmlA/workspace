package com.a4399.funnycore.base.network;

import java.util.List;

/**
 * @another 江祖赟
 * @date 2017/7/13.
 * 分页数据包装类基类
 */
public class PageDataWrapper<D> {
    /**
     * page : 页码int
     * hasNext : 是否有下一页(true或者false)
     * total : 总数
     * list : 数据列表
     * tip ：提示数据
     * lastindex ：数据最后一条数据索引
     */

    public String page;
    public boolean hasNext;
    public int total;
    public String tip;
    public List<D> list;
    public long lastindex;//最后一条数据索引


    public boolean isHasNext() {
        return hasNext;
    }

    public String getPage() {
        return page;
    }


    public void setPage(String page) {
        this.page = page;
    }


    public boolean getHasNext() {
        return hasNext;
    }


    public void setHasNext(boolean hasNext) {
        this.hasNext = hasNext;
    }


    public List<D> getList() {
        return list;
    }


    public void setList(List<D> list) {
        this.list = list;
    }
}
