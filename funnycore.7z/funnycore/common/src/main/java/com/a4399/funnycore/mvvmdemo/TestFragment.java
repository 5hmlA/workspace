package com.a4399.funnycore.mvvmdemo;

import android.databinding.ViewDataBinding;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.a4399.funnycore.base.BaseFragment;

public class TestFragment extends BaseFragment<TestViewModel> {

    @Override
    protected TestViewModel initModel() {
        return new TestViewModel();
    }

    @Override
    protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        return  null;
    }


    @Override protected void initViewAndData() {

    }
}
