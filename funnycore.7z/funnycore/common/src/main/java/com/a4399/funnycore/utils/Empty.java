package com.a4399.funnycore.utils;

import java.util.Collection;
import java.util.Map;

/**
 * "空"判断工具类<br/>
 * 先对对象进行 {@code null}判断,再判断非空对象的"空"
 * @author Linbing Tang
 * @since 2017/03/30
 */
public class Empty {
  private Empty() {}

  /**
   * @return {@code container == null || container.isEmpty()}
   */
  public static boolean yes(Collection<?> container) {
    return container == null || container.isEmpty();
  }

  /**
   * @return {@code str == null || str.length() == 0}
   */
  public static boolean yes(String str) {
    return str == null || str.length() == 0;
  }

  public static boolean yes(Object[] args) {
    return args == null || args.length == 0;
  }

  public static <K, V> boolean yes(Map<K, V> map) {
    return map == null || map.isEmpty();
  }
}
