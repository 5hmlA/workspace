package com.a4399.funnycore.rx;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.ObservableTransformer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

/**
 * 文件描述：RxJavaUtil2.0版本的工具
 * Created by zhanlinjian2888 on 2017/12/11 14:33.
 * E-mail:zhanlinjian@4399inc.com
 */
public class RxJavaUtil {

    // rxJavaUtil
    private static RxJavaUtil rxJavaUtil;

    // getInstance()
    public synchronized static RxJavaUtil getRxJavaUtilInstance() {
        if (rxJavaUtil == null) {
            return rxJavaUtil = new RxJavaUtil();
        }
        return rxJavaUtil;
    }

    /**
     * 实例CompositeDisposable
     * @return
     */
    protected CompositeDisposable newCompositeDisposable(CompositeDisposable compositeDisposable){
        if (compositeDisposable==null){
            return new CompositeDisposable();
        }else{
            return compositeDisposable;
        }
    }

    public static <T> ObservableTransformer<T,T> defaultSchedulers_obser(){
        return new ObservableTransformer<T,T>() {
            @Override
            public ObservableSource<T> apply(Observable<T> upstream){
                return upstream.observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io());
            }
        };
    }

}
