package com.a4399.funnycore.base;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.databinding.Observable;
import android.databinding.ObservableField;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.ImageView;
import com.a4399.common.R;
import com.a4399.funnycore.CommonConsts;
import com.a4399.funnycore.loading.StateException;
import com.a4399.funnycore.loading.StateInterface;
import com.a4399.funnycore.utils.ResUtil;
import java.util.List;

/**
 * 文件描述：viewmodel基类
 * Created by zhanlinjian2888 on 2017/12/08 16:32.
 * E-mail:zhanlinjian@4399inc.com
 */
public abstract class BaseViewModel extends BaseObservable {

    // 当前页面状态
    @StateInterface private int currentState = StateInterface.FREETIME;

    // 非空闲状态显示文字
    public String unFreeMsg = "UnFreeMsg";

    // 非空闲状态显示图片
    public int unFreeDrawable = R.drawable.ic_back;

    public int getCurrentState() {
        return currentState;
    }

    /**
     * 设置状态
     */
    public void setCurrentState(@StateInterface int currentState) {
        this.currentState = currentState;
        notifyChange();
    }


    /**
     * 设置状态
     */
    public void setCurrentState(@StateInterface int currentState, String unFreeMsg) {
        this.currentState = currentState;
        this.unFreeMsg = unFreeMsg;
        notifyChange();
    }


    /**
     * 设置状态
     */
    public void setCurrentState(@StateInterface int currentState, String unFreeMsg, int UnFreeDrawable) {
        this.currentState = currentState;
        this.unFreeMsg = unFreeMsg;
        this.unFreeDrawable = unFreeDrawable;
        notifyChange();
    }


    /**
     * 显示进度条
     */
    public boolean isProgress() {
        return (this.currentState == StateInterface.LOADING) ||
                (this.currentState == StateInterface.LOADING_DIALOG);
    }

/*
    *//**
     * 根据异常显示状态
     *//*
    public void bindThrowable(Throwable e) {
        if (e instanceof StateException) {
            @StateInterface int code = ((StateException) e).getCode();
            setCurrentState(code);
        }
    }*/


    /**
     * 是否空闲状态
     */
    public boolean isFreeTime() {
        return this.currentState == StateInterface.FREETIME;
    }


    /**
     * 状态信息
     */
    @Bindable public String getCurrentStateLabel() {

        switch (currentState) {
            case StateInterface.ERROR:
                return unFreeMsg;
            case StateInterface.LOADING:
                return ResUtil.getString(R.string.state_loading);
            case StateInterface.LOADING_DIALOG:
                return ResUtil.getString(R.string.state_loading);
            case StateInterface.NO_NETWORK:
                return ResUtil.getString(R.string.network_error);
            default:
                return unFreeMsg;
        }
    }


    /**
     * 状态图片
     */
    @Bindable public Drawable getCurrentStateRes() {

        switch (currentState) {
            case StateInterface.ERROR:
                return ResUtil.getDrawable(unFreeDrawable);
            case StateInterface.LOADING:
                return ResUtil.getDrawable(R.drawable.ic_back);
            case StateInterface.LOADING_DIALOG:
                return ResUtil.getDrawable(R.drawable.ic_back);
            case StateInterface.NO_NETWORK:
                return ResUtil.getDrawable(R.drawable.ic_back);
            default:
                return ResUtil.getDrawable(R.drawable.ic_back);
        }
    }


    /**
     * 页面数据初始化
     */
    public abstract void initViewModelData();

    /*
     * 检验模型，将出错属性及对应的错误消息构造ModelErrorInfo对象， 形成列表返回, 如果模型正确则返回null
	 */
    public abstract List<BaseViewModelErrorInfo> verifyViewModel();


    /**
     * 判断模型是否有错, 如果有错则提示错误信息
     *
     * @return null:模型验证正确
     */
    public BaseViewModelErrorInfo hasError() {
        List<BaseViewModelErrorInfo> list = verifyViewModel();
        if (list == null || list.size() < 0) {
            return null;
        }
        else {
            return list.get(0);
        }
    }
}
