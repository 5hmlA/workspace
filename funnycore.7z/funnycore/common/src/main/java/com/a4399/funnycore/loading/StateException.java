package com.a4399.funnycore.loading;

/**
 * 文件描述：异常状态信息
 * Created by zhanlinjian2888 on 2017/12/15.
 * E-mail:zhanlinjian@4399inc.com
 */

public class StateException extends Exception{

    private int code;

    public StateException(@StateInterface int code) {
        super();
        this.code = code;
    }


    @StateInterface
    public int getCode() {
        return code;
    }

    public void setCode(@StateInterface int code) {
        this.code = code;
    }
}
