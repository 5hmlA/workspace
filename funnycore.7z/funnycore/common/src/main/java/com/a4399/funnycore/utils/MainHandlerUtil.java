package com.a4399.funnycore.utils;

import android.os.Handler;
import android.os.Looper;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 15/9/30
 */
public class MainHandlerUtil {

  private static Handler sHandler = new Handler(Looper.getMainLooper());

  /**
   * 主线程中执行操作
   */
  public static void runOnMainThread(Runnable runnable) {
    sHandler.post(runnable);
  }

  /**
   * 主线程执行延时操作
   */
  public static void runOnMainThread(Runnable runnable, long delayMillis) {
    sHandler.postDelayed(runnable, delayMillis);
  }

}
