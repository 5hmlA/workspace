package com.a4399.funnycore.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.os.Environment;
import android.support.annotation.NonNull;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 图像压缩工具类
 * <li> {@link #getCompressedPath(String, int, int, int)} 获取(压缩后的)图像路径</li>
 * <li>{@link #cleanTempDir()} 清空缓存目录</li>
 * <p>2016/1/6</p>
 */
public class BitmapUtil {
    private static final String TAG = BitmapUtil.class.getSimpleName();
    public static final String TEMP_COMPRESS_PATH = buildDir("tmp_upload"+File.separator+"compress");
    private static final String FILENAME_JPG = new SimpleDateFormat("yyyyMMdd_HHmmssSSS").format(new Date())+".jpg";

    /**
     * @param path
     *         图片路径
     * @param maxWidth
     *         目标图片最大宽(px)
     * @param maxHeight
     *         目标图片最大高(px)
     * @param maxSizeInKB
     *         目标图片最大大小(存储所需的空间)
     * @return 压缩后图片的缓存路径
     */
    public static String getCompressedPath(String path, int maxWidth, int maxHeight, int maxSizeInKB) throws IOException{
        return getCompressedPath(path, maxWidth, maxHeight, false, maxSizeInKB);
    }

    /**
     * @param path
     *         图片路径
     * @param maxWidth
     *         目标图片最大宽(px)
     * @param maxHeight
     *         目标图片最大高(px)
     * @param isEqually
     *         超过的图片是否是按等比缩放
     * @param maxSizeInKB
     *         目标图片最大大小(存储所需的空间)
     * @return 压缩后图片的缓存路径
     */
    public static String getCompressedPath(String path, int maxWidth, int maxHeight, boolean isEqually, int maxSizeInKB) throws IOException{
        File file;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);

        //1:    小于给定尺寸, 压缩质量
        if(options.outWidth<maxWidth && options.outHeight<maxHeight) {
            file = getCompressQualityFile(path, maxSizeInKB);
        }else {
            // 2.1: 按尺寸调整 inSampleSize 压缩
            file = getCompressSampleFile(path, maxWidth, maxHeight, options);

            // 2.2   调整尺寸
            file = getCompressDimenFile(maxWidth, maxHeight, isEqually, file);

            // 2.3   调整质量
            file = getCompressQualityFile(file.getAbsolutePath(), maxSizeInKB);
        }
        int pictureDegree = readPictureDegree(path);
        //原始图片有旋转属性
        if(pictureDegree != 0) {
            file = getResetRotationFile(file.getAbsolutePath(), pictureDegree);
        }

        return file.getAbsolutePath();
    }

    /**
     * 将给定图片截取中间部分,伸缩为64x32或64x64的尺寸, 同时控制大小不超过 {@code maxBytesKb}.
     * <p>截取方案如下:
     * <ul>
     * <li>宽:高&lt;2, 按照64x64</li>
     * <li>宽:高>=2, 按照64x32</li>
     * </ul>
     *
     * @param iconPathName
     *         皮肤封面图片
     * @param maxBytesKb
     *         大小上限
     * @return 处理后的封面路径
     */
    public static String getCompressedSkinIcon(String iconPathName, int maxBytesKb) throws IOException{
        File result = new File(iconPathName);
        long originSize = result.length();

        //文件过大压缩
        if(originSize>=maxBytesKb*1024) {
            BitmapFactory.Options opt = new BitmapFactory.Options();
            opt.inJustDecodeBounds = false;
            opt.inSampleSize = (int)( originSize/maxBytesKb );
            result = new File(TEMP_COMPRESS_PATH, FILENAME_JPG);
            FileOutputStream fos = new FileOutputStream(result);
            BitmapFactory.decodeFile(iconPathName, opt).compress(Bitmap.CompressFormat.JPEG, 100, fos);
            try {
                fos.close();
            }catch(IOException e) {
                e.printStackTrace();
            }
        }

        Bitmap bitmap = BitmapFactory.decodeFile(result.getAbsolutePath());
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        //宽高比<2,按64x64截取
        boolean is64x64 = width/height<64f/32;

        //计算裁切位置
        int x = 0, y = 0;
        int cutW = width;//裁切宽度
        int cutH = height;//裁切高度
        if(is64x64) {//64x64
            if(width>height) {
                x = ( width-height )/2;
                cutW = cutH;
            }else {
                y = ( height-width )/2;
                cutH = cutW;
            }
        }else {//64x32, 保持宽高比=2
            if(width>height) {
                x = ( width-2*height )/2;
                cutW = 2*cutH;
            }else {
                y = ( height-2*width )/2;
                cutH = cutW/2;
            }
        }

        //按比例裁切图像
        Bitmap cropBitmap = Bitmap.createBitmap(bitmap, x, y, cutW, cutH);

        //伸缩图像
        Bitmap scaledBitmap;
        if(is64x64) {
            scaledBitmap = Bitmap.createScaledBitmap(cropBitmap, 64, 64, false);
        }else {
            scaledBitmap = Bitmap.createScaledBitmap(cropBitmap, 64, 32, false);
        }

        FileOutputStream fos = new FileOutputStream(result);
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
        try {
            fos.close();
        }catch(IOException e) {
            e.printStackTrace();
        }

        result = getCompressQualityFile(result.getAbsolutePath(), maxBytesKb);
        return result.getCanonicalPath();
    }

    private static final String buildDir(String dirName){
        String mcroot = Environment.getExternalStorageDirectory()+File.separator+"4399MCPE";
        String dir = String.format("%s%s%s%s", mcroot, File.separator, dirName, File.separator);
        File dirFolder = new File(dir);
        if(!dirFolder.exists()) {
            dirFolder.mkdirs();
        }
        return dir;
    }

    /**
     * @param path
     *         图片路径
     * @param maxSizeInKB
     *         目标图片最大大小(存储所需的空间)
     * @return 压缩后图片的缓存路径
     */
    public static String getCompressedPath(String path, int maxSizeInKB) throws IOException{
        File file;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);

        //1:    小于给定尺寸, 压缩质量
        file = getCompressQualityFile(path, maxSizeInKB);
        return file.getAbsolutePath();
    }

    /**
     * 清空缓存目录
     */
    public static boolean cleanTempDir(){
        try {
            File tempDir = new File(TEMP_COMPRESS_PATH);
            cleanTempDir(tempDir);
            return tempDir.listFiles().length == 0;
        }catch(Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private static void cleanTempDir(File parent){
        if(parent == null || !parent.exists()) {
            return;
        }

        File[] files = parent.listFiles();
        if(files != null && files.length>0) {
            for(int i = 0; i<files.length; i++) {
                File file = files[i];
                if(file.isDirectory()) {
                    cleanTempDir(file);
                }else {
                    file.delete();
                }
            }
        }else {
            parent.delete();
        }
    }

    @NonNull
    private static File getCompressSampleFile(String path, int maxWidth, int maxHeight, BitmapFactory.Options options) throws IOException{
        options.inSampleSize = Math.min(options.outWidth/maxWidth, options.outHeight/maxHeight);
        options.inJustDecodeBounds = false;
        // 压缩后 options.outWidth >= maxWidth, options.outHeight >= maxHeight, 需要进一步压缩
        Bitmap bitmap = BitmapFactory.decodeFile(path, options);
        File file = new File(TEMP_COMPRESS_PATH, FILENAME_JPG);
        FileOutputStream outputStream = new FileOutputStream(file);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
        recycleBitmap(bitmap);
        outputStream.close();
        return file;
    }

    @NonNull
    private static File getCompressDimenFile(float maxWidth, float maxHeight, boolean isEqually, File file) throws IOException{
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
        Matrix matrix = new Matrix();
        if(isEqually) {//等比缩放
            float sx = Math.min(maxWidth/bitmap.getWidth(), maxHeight/bitmap.getHeight());
            matrix.postScale(sx, sx);
        }else {//填充缩放
            float sx = maxWidth/bitmap.getWidth();
            float sy = maxHeight/bitmap.getHeight();
            matrix.postScale(sx, sy);
        }
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
        file = new File(TEMP_COMPRESS_PATH, FILENAME_JPG);
        FileOutputStream outputStream = new FileOutputStream(file);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
        recycleBitmap(bitmap);
        outputStream.close();
        return file;
    }

    @NonNull
    private static File getCompressQualityFile(String path, int maxSizeInKB) throws IOException{
        Bitmap bitmap = BitmapFactory.decodeFile(path);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int quality = 100;
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos);
        LogUtil.info(TAG, String.format("size=%sBytes", baos.size()));
        boolean isCompressed = false;
        while(quality>0 && baos.size()/1024>maxSizeInKB) {
            quality -= 5;
            baos.reset();
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos);
            LogUtil.info(TAG, String.format("quality=%s,size=%sBytes", quality, baos.size()));
            isCompressed = true;
        }

        File file;
        if(isCompressed) {
            bitmap = BitmapFactory.decodeStream(new ByteArrayInputStream(baos.toByteArray()));
            file = new File(TEMP_COMPRESS_PATH, FILENAME_JPG);
            FileOutputStream outputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
            outputStream.close();
        }else {
            file = new File(path);
        }
        recycleBitmap(bitmap);
        return file;
    }

    @NonNull
    private static File getResetRotationFile(String path, int rotation) throws IOException{
        Bitmap bitmap = BitmapFactory.decodeFile(path);
        Matrix matrix = new Matrix();
        matrix.reset();
        matrix.setRotate(rotation);
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);

        File file;
        file = new File(TEMP_COMPRESS_PATH, FILENAME_JPG);
        FileOutputStream outputStream = new FileOutputStream(file);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
        outputStream.close();
        recycleBitmap(bitmap);
        return file;
    }

    /**
     * 图片转成二进制 并进行压缩
     *
     * @param compress
     *         压缩的大小 kb为单位
     */
    public static byte[] getBitmapByte(Bitmap bitmap, int compress){
        if(bitmap == null) {
            return null;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int options = 100;
        bitmap.compress(Bitmap.CompressFormat.JPEG, options, out);
        while(out.toByteArray().length/1024>compress) {  //循环判断如果压缩后图片是否大于compress,大于继续压缩
            out.reset();//重置baos即清空baos
            bitmap.compress(Bitmap.CompressFormat.JPEG, options, out);//这里压缩options%，把压缩后的数据存放到out中
            options -= 10;//每次都减少10
        }
        try {
            out.flush();
            out.close();
        }catch(IOException e) {
            e.printStackTrace();
        }
        bitmap.recycle();
        return out.toByteArray();
    }

    /**
     * 根据路径获取图片
     */
    public static Bitmap getDiskBitmap(String pathString){
        Bitmap bitmap = null;
        try {
            File file = new File(pathString);
            if(file.exists()) {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(pathString, opts);

                opts.inSampleSize = computeSampleSize(opts, -1, 512*512);
                opts.inJustDecodeBounds = false;
                try {
                    bitmap = BitmapFactory.decodeFile(pathString, opts);
                }catch(OutOfMemoryError err) {
                }
            }
        }catch(Exception e) {
            e.printStackTrace();
        }catch(OutOfMemoryError err) {

        }
        return bitmap;
    }

    /**
     * 计算缩放比例
     */
    public static int computeSampleSize(BitmapFactory.Options options, int minSideLength, int maxNumOfPixels){
        int initialSize = computeInitialSampleSize(options, minSideLength, maxNumOfPixels);
        int roundedSize;
        if(initialSize<=8) {
            roundedSize = 1;
            while(roundedSize<initialSize) {
                roundedSize <<= 1;
            }
        }else {
            roundedSize = ( initialSize+7 )/8*8;
        }

        return roundedSize;
    }

    /**
     * 计算缩放比例
     */
    private static int computeInitialSampleSize(BitmapFactory.Options options, int minSideLength, int maxNumOfPixels){
        double w = options.outWidth;
        double h = options.outHeight;

        int lowerBound = ( maxNumOfPixels == -1 ) ? 1 : (int)Math.ceil(Math.sqrt(w*h/maxNumOfPixels));
        int upperBound = ( minSideLength == -1 ) ? 128 : (int)Math
                .min(Math.floor(w/minSideLength), Math.floor(h/minSideLength));

        if(upperBound<lowerBound) {
            // return the larger one when there is no overlapping zone.
            return lowerBound;
        }

        if(( maxNumOfPixels == -1 ) && ( minSideLength == -1 )) {
            return 1;
        }else if(minSideLength == -1) {
            return lowerBound;
        }else {
            return upperBound;
        }
    }

    private static void recycleBitmap(Bitmap bitmap){
        if(bitmap != null && !bitmap.isRecycled()) {
            bitmap.recycle();
            bitmap = null;
            System.gc();
        }
    }

    /**
     * 读取图片属性：旋转的角度
     *
     * @param path
     *         图片绝对路径 degree旋转的角度
     * @author GuoJing
     */
    public static int readPictureDegree(String path){
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(path);
            int orientation = exifInterface
                    .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            switch(orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        }catch(IOException e) {
            e.printStackTrace();
        }
        return degree;
    }

    /**
     * 复制图片旋转属性 如三星拍照的图片带有旋转属性
     *
     * @param sourceFile
     * @param destFile
     * @return
     */
    public static boolean copyExifRotation(File sourceFile, File destFile){
        if(sourceFile == null || destFile == null) {
            return false;
        }
        try {
            ExifInterface exifSource = new ExifInterface(sourceFile.getAbsolutePath());
            ExifInterface exifDest = new ExifInterface(destFile.getAbsolutePath());
            exifDest.setAttribute(ExifInterface.TAG_ORIENTATION,
                    exifSource.getAttribute(ExifInterface.TAG_ORIENTATION));
            exifDest.saveAttributes();
            return true;
        }catch(IOException e) {
            return false;
        }
    }

    public static boolean saveBitmap(Bitmap bmp, String path){
        Bitmap.CompressFormat format = Bitmap.CompressFormat.JPEG;
        if(path.endsWith("png")) {
            format = Bitmap.CompressFormat.PNG;
        }
        int quality = 100;
        OutputStream stream = null;
        try {
            stream = new FileOutputStream(path);
        }catch(FileNotFoundException e) {
            e.printStackTrace();
        }

        return bmp.compress(format, quality, stream);
    }
}
