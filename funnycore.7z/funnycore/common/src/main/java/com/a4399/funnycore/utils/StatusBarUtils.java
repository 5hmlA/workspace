package com.a4399.funnycore.utils;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.support.v4.widget.DrawerLayout;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;

/**
 * 状态栏工具类
 */
public class StatusBarUtils {

  /**
   * 设置状态栏颜色
   *
   * @param activity 需要设置的activity
   * @param color 状态栏颜色值
   */
  public static void setColor(Activity activity, int color) {
    if (Build.VERSION.SDK_INT == Build.VERSION_CODES.KITKAT) {
      // 设置状态栏透明
      activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
      // 生成一个状态栏大小的矩形
      View statusView = createStatusBarView(activity, color);
      // 添加 statusView 到布局中
      ViewGroup decorView = (ViewGroup) activity.getWindow().getDecorView();
      decorView.addView(statusView);
      // 设置根布局的参数
      ViewGroup rootView = (ViewGroup) ((ViewGroup) activity.findViewById(
          android.R.id.content)).getChildAt(0);
      rootView.setFitsSystemWindows(true);
      rootView.setClipToPadding(true);
    }else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
      Window window = activity.getWindow();
      //取消设置透明状态栏,使 ContentView 内容不再覆盖状态栏
      window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

      //需要设置这个 flag 才能调用 setStatusBarColor 来设置状态栏颜色
      window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
      //设置状态栏颜色
      window.setStatusBarColor(color);
    }
  }

  /**
   * 使状态栏透明
   * <p/>
   * 适用于图片作为背景的界面,此时需要图片填充到状态栏
   *
   * @param activity 需要设置的activity
   */
  public static void setTranslucent(Activity activity) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
      // 设置状态栏透明
      activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
      // 设置根布局的参数
      ViewGroup rootView = (ViewGroup) ((ViewGroup) activity.findViewById(
          android.R.id.content)).getChildAt(0);
      rootView.setFitsSystemWindows(true);
      rootView.setClipToPadding(true);
    }
  }


  /**
   * 为DrawerLayout 布局设置状态栏变色
   *
   * @param activity 需要设置的activity
   * @param drawerLayout DrawerLayout
   * @param color 状态栏颜色值
   */
  public static void setColorForDrawerLayout(Activity activity, DrawerLayout drawerLayout,
                                             int color) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
      activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
      // 生成一个状态栏大小的矩形
      View statusBarView = createStatusBarView(activity, color);
      // 添加 statusBarView 到布局中
      ViewGroup contentLayout = (ViewGroup) drawerLayout.getChildAt(0);
      contentLayout.addView(statusBarView, 0);
      // 内容布局不是 LinearLayout 时,设置padding top
      if (!(contentLayout instanceof LinearLayout) && contentLayout.getChildAt(1) != null) {
        contentLayout.getChildAt(1).setPadding(0, getStatusBarHeight(activity), 0, 0);
      }
      // 设置属性
      ViewGroup drawer = (ViewGroup) drawerLayout.getChildAt(1);
      drawerLayout.setFitsSystemWindows(false);
      contentLayout.setFitsSystemWindows(false);
      contentLayout.setClipToPadding(true);
      drawer.setFitsSystemWindows(false);
    }
  }

  /**
   * 为 DrawerLayout 布局设置状态栏透明
   *
   * @param activity 需要设置的activity
   * @param drawerLayout DrawerLayout
   */
  public static void setTranslucentForDrawerLayout(Activity activity, DrawerLayout drawerLayout) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
      // 设置状态栏透明
      activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
      // 设置内容布局属性
      ViewGroup contentLayout = (ViewGroup) drawerLayout.getChildAt(0);
      contentLayout.setFitsSystemWindows(true);
      contentLayout.setClipToPadding(true);
      // 设置抽屉布局属性
      ViewGroup vg = (ViewGroup) drawerLayout.getChildAt(1);
      vg.setFitsSystemWindows(false);
      // 设置 DrawerLayout 属性
      drawerLayout.setFitsSystemWindows(false);
    }
  }

  /**
   * 生成一个和状态栏大小相同的矩形条
   *
   * @param activity 需要设置的activity
   * @param color 状态栏颜色值
   * @return 状态栏矩形条
   */
  private static View createStatusBarView(Activity activity, int color) {
    // 绘制一个和状态栏一样高的矩形
    View statusBarView = new View(activity);
    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        getStatusBarHeight(activity));
    statusBarView.setLayoutParams(params);
    statusBarView.setBackgroundColor(color);
    return statusBarView;
  }

  /**
   * 获取状态栏高度
   *
   * @param context context
   * @return 状态栏高度
   */
  private static int getStatusBarHeight(Context context) {
    // 获得状态栏高度
    int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
    return context.getResources().getDimensionPixelSize(resourceId);
  }
}
