package com.a4399.funnycore.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;

import java.io.File;
import java.io.FileFilter;
import java.util.regex.Pattern;

/**
 * 跟设备有关的工具类
 *
 * @author 徐智伟
 * @create 15/9/30
 */
public class DeviceUtil {

  /**
   * 获取mac地址.
   */
  public static String getMac(Context context) {
    WifiManager wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
    WifiInfo info = wifi.getConnectionInfo();
    if (info.getMacAddress() == null) {
      return null;
    } else {
      return info.getMacAddress();
    }
  }

  /**
   * 获取SSID地址.
   */
  public static String getSSID(Context context) {

    WifiManager wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
    WifiInfo info = wifi.getConnectionInfo();
    if (info.getSSID() == null) {
      return null;
    } else {
      return info.getSSID();
    }
  }

  /**
   * 获取IMSI.
   */
  public static String getIMSI(Context context) {
    TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(
        Context.TELEPHONY_SERVICE);
    if (telephonyManager.getSubscriberId() == null) {
      return null;
    } else {
      return telephonyManager.getSubscriberId();
    }
  }

  /**
   * 获取IMEI.
   */
  public static String getIMEI(Context context) {
    TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(
        Context.TELEPHONY_SERVICE);
    if (telephonyManager.getDeviceId() == null) {
      return null;
    } else {
      return telephonyManager.getDeviceId();
    }
  }

  /**
   * 手机号码
   */
  public static String getPhoneNumber(Context context) {
    TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(
        Context.TELEPHONY_SERVICE);
    if (telephonyManager.getLine1Number() == null
        || telephonyManager.getLine1Number().length() < 11) {
      return null;
    } else {
      return telephonyManager.getLine1Number();
    }
  }

  /**
   * Gets the number of cores available in this device, across all processors.
   * Requires: Ability to peruse the filesystem at "/sys/devices/system/cpu"
   *
   * @return The number of cores, or 1 if failed to get result
   */
  public static int getNumCores() {
    try {
      //Get directory containing CPU info
      File dir = new File("/sys/devices/system/cpu/");
      //Filter to only list the devices we care about
      File[] files = dir.listFiles(new FileFilter() {

        @Override
        public boolean accept(File pathname) {
          //Check if filename is "cpu", followed by a single digit number
          if (Pattern.matches("cpu[0-9]", pathname.getName())) {
            return true;
          }
          return false;
        }

      });
      //Return the number of cores (virtual CPU devices)
      return files.length;
    } catch (Exception e) {
      e.printStackTrace();
      return 1;
    }
  }
  public static String getDeviceID(Context context){
    return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
  }

  /**
   * 获取版本号
   *
   * @return 当前应用的版本号
   */
  public static String getVersionName(Context context,String packageName){
    try {
      PackageManager manager = context.getPackageManager();
      PackageInfo info = manager.getPackageInfo(packageName, 0);
      return info.versionName;
    }catch(Exception e) {
      e.printStackTrace();
      return "";
    }
  }
  public static String getDiviceName(){
    return android.os.Build.MODEL;
  }
}
