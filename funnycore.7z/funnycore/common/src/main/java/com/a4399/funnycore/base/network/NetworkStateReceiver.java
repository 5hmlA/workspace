package com.a4399.funnycore.base.network;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.a4399.funnycore.utils.LogUtil;

/**
 * 网络状态广播
 *
 * @author 徐智伟
 * @create 16/4/22
 */
public class NetworkStateReceiver extends BroadcastReceiver {

  public static final String ACTION = "android.net.conn.CONNECTIVITY_CHANGE";
  private static final String TAG = "NetworkStateReceiver";

  @Override
  public void onReceive(Context context, Intent intent) {
    if (ACTION.equals(intent.getAction())) {

      ConnectivityManager manager = (ConnectivityManager) context
          .getSystemService(Context.CONNECTIVITY_SERVICE);
      NetworkInfo activeInfo = manager.getActiveNetworkInfo();
      LogUtil.info(TAG, "NETWORK.onReceive..." + activeInfo);
      if (activeInfo != null) {
        //有网络
        // TODO need fix by zhanlinjian2888 on 20171211
        // RxBus.getDefault().post(new NetworkStateEvent(NetworkStateEvent.NETWORKTYPE_OTHER));
      } else {
        //无网络
        // TODO need fix by zhanlinjian2888 on 20171211
        // RxBus.getDefault().post(new NetworkStateEvent(NetworkStateEvent.NETWORKTYPE_INVALID));

      }
    }
  }
}
