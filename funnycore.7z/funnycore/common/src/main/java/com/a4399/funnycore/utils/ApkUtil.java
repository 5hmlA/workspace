package com.a4399.funnycore.utils;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.View;
import com.a4399.funnycore.CommonConsts;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 文件描述：apk工具类
 * Created by zhanlinjian2888 on 2017/12/26.
 * E-mail:zhanlinjian@4399inc.com
 */

public class ApkUtil {

    /**
     * 打开apk并提示安装
     */
    public static void openApkFile(Context context, String apkPath) {
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setAction(android.content.Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(new File(apkPath)), "application/vnd.android.package-archive");
        context.startActivity(intent);
    }


    /**
     * 打开apk并提示安装
     */
    public static void openApkFile(View view, String apkPath) {
        Context context = ContextUtil.getContextByView(view);
        if (context == null) {
            return;
        }
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setAction(android.content.Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(new File(apkPath)), "application/vnd.android.package-archive");
        context.startActivity(intent);
    }


    /**
     * 启动其他应用
     * @param view
     * @param packagename
     */
    public static void startAppWithPackageName(View view, String packagename) {

        Context context = ContextUtil.getContextByView(view);
        if (context == null) {
            return;
        }
        // 通过包名获取此APP详细信息，包括Activities、services、versioncode、name等等
        PackageInfo packageinfo = null;
        try {
            packageinfo = context.getPackageManager().getPackageInfo(packagename, 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (packageinfo == null) {
            return;
        }

        // 创建一个类别为CATEGORY_LAUNCHER的该包名的Intent
        Intent resolveIntent = new Intent(Intent.ACTION_MAIN, null);
        resolveIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        resolveIntent.setPackage(packageinfo.packageName);

        // 通过getPackageManager()的queryIntentActivities方法遍历
        List<ResolveInfo> resolveinfoList = context.getPackageManager()
                                                   .queryIntentActivities(resolveIntent, 0);

        ResolveInfo resolveinfo = resolveinfoList.iterator().next();
        if (resolveinfo != null) {
            // packagename = 参数packname
            String packageName = resolveinfo.activityInfo.packageName;
            // 这个就是我们要找的该APP的LAUNCHER的Activity[组织形式：packagename.mainActivityname]
            String className = resolveinfo.activityInfo.name;
            // LAUNCHER Intent
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);

            // 设置ComponentName参数1:packagename参数2:MainActivity路径
            ComponentName cn = new ComponentName(packageName, className);

            intent.setComponent(cn);
            context.startActivity(intent);
        }
    }


    /**
     * 查询所有已经安装的应用程序
     */
    public static List<AppInfo> getAllApp() {
        PackageManager pm = CommonConsts.getAppContextInstance.getPackageManager();
        List<AppInfo> myAppInfos = new ArrayList<AppInfo>();
        List<AppInfo> mFilterApps = new ArrayList<AppInfo>();
        try {
            List<PackageInfo> packageInfos = pm.getInstalledPackages(0);
            for (int i = 0; i < packageInfos.size(); i++) {
                PackageInfo packageInfo = packageInfos.get(i);
                //过滤掉系统app
                if ((ApplicationInfo.FLAG_SYSTEM & packageInfo.applicationInfo.flags) != 0) {
                    continue;
                }
                AppInfo appInfo = new AppInfo();
                appInfo.setPkgName((String) packageInfo.applicationInfo.loadLabel(pm));
                if (packageInfo.applicationInfo.loadIcon(pm) == null) {
                    continue;
                }
                appInfo.setAppIcon(packageInfo.applicationInfo.loadIcon(pm));
                myAppInfos.add(appInfo);
            }
            myAppInfos.addAll(mFilterApps);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return myAppInfos;
    }


    private static AppInfo getAppInfo(PackageManager pm, ApplicationInfo app) {
        AppInfo appInfo = new AppInfo();
        appInfo.setAppLabel((String) app.loadLabel(pm));
        appInfo.setAppIcon(app.loadIcon(pm));
        appInfo.setPkgName(app.packageName);
        return appInfo;
    }


    public static class AppInfo {

        private String appLabel;    //应用程序标签
        private Drawable appIcon;  //应用程序图像
        private Intent intent;     //启动应用程序的Intent ，一般是Action为Main和Category为Lancher的Activity
        private String pkgName;    //应用程序所对应的包名


        public AppInfo() {}


        public String getAppLabel() {
            return appLabel;
        }


        public void setAppLabel(String appName) {
            this.appLabel = appName;
        }


        public Drawable getAppIcon() {
            return appIcon;
        }


        public void setAppIcon(Drawable appIcon) {
            this.appIcon = appIcon;
        }


        public Intent getIntent() {
            return intent;
        }


        public void setIntent(Intent intent) {
            this.intent = intent;
        }


        public String getPkgName() {
            return pkgName;
        }


        public void setPkgName(String pkgName) {
            this.pkgName = pkgName;
        }
    }
}
