package com.a4399.funnycore.base;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import com.a4399.funnycore.utils.ResUtil;
import java.util.ArrayList;
import java.util.List;

/**
 * 文件描述：FragmentPagerAdapter基类
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public class BaseFragmentPagerAdapter extends FragmentPagerAdapter {

    // 存储fragment
    private List<Fragment> mFragments;

    // 标题
    private List<String> mTitles;


    /**
     * 初始化数据等
     * @param fm
     */
    public BaseFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
        mFragments = new ArrayList<>();
        mTitles = new ArrayList<>();
    }


    /**
     * 添加一个fragment
     *
     * @param title 标题
     */
    public void addFragment(Fragment fragment, String title) {
        mFragments.add(fragment);
        mTitles.add(title);
    }


    /**
     * 添加一个fragment
     *
     * @param titleId 标题
     */
    public void addFragment(Fragment fragment, int titleId) {
        mFragments.add(fragment);
        mTitles.add(ResUtil.getString(titleId));
    }


    @Override public Fragment getItem(int position) {
        return mFragments.get(position);
    }


    @Override public int getCount() {
        return mFragments.size();
    }
}
