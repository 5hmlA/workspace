package com.a4399.funnycore.base;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import java.lang.reflect.Field;

// TODO need fix by zhanlinjian2888 on 20171211
//
// import rx.subjects.PublishSubject;
// import rx.subscriptions.CompositeSubscription;
// import sandboxtool.sj4399.com.myapplication.rx.RxLifeCycleEvent;
// import sandboxtool.sj4399.com.myapplication.rx.RxUtils;

/**
 * 文件描述：basefragment基类
 * Created by zhanlinjian2888 on 2017/12/08 16:32.
 * E-mail:zhanlinjian@4399inc.com
 */
public abstract class BaseSimpleFragment extends LazyFragment{

    // 生命周期Event
    // TODO need fix by zhanlinjian2888 on 20171211
    // protected final PublishSubject<RxLifeCycleEvent> lifecycleSubject = PublishSubject.create();

    // tag
    protected static String sTag = null;

    // 持有所有的Subscriptions
    // TODO need fix by zhanlinjian2888 on 20171211
    // protected CompositeSubscription rxSubscription = new CompositeSubscription();



    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sTag = this.getClass().getSimpleName();

        if (isBindRxBus()) {
            // TODO need fix by zhanlinjian2888 on 20171211
            // rxSubscription = RxUtils.getNewCompositeSubIfUnsubscribed(rxSubscription);
            initRxBus();
        }
        // TODO need fix by zhanlinjian2888 on 20171211
        // lifecycleSubject.onNext(RxLifeCycleEvent.CREATE);

    }


    @Override public void onDestroy() {
        super.onDestroy();
        // TODO need fix by zhanlinjian2888 on 20171211
        // lifecycleSubject.onNext(RxLifeCycleEvent.DESTROY);

        if (isBindRxBus()) {
            // TODO need fix by zhanlinjian2888 on 20171211
            // RxUtils.unsubscribeIfNotNull(rxSubscription);
        }
    }


    @Override public void onDetach() {
        super.onDetach();

        // for bug ---> java.lang.IllegalStateException: Activity has been destroyed
        try {
            Field childFragmentManager = Fragment.class.getDeclaredField("mChildFragmentManager");
            childFragmentManager.setAccessible(true);
            childFragmentManager.set(this, null);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * 初始化views以及数据相关
     */
    protected abstract void initViewAndData();

    /**
     * 是否需要绑定EventBus
     */
    protected abstract boolean isBindRxBus();

    /**
     * 事件响应
     */
    protected abstract void initRxBus();

    @Override public void firstUserVisibile() {

    }
}
