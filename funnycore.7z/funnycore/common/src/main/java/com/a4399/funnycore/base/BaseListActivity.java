package com.a4399.funnycore.base;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.a4399.common.R;
import com.a4399.funnycore.base.network.NetworkStateReceiver;
import com.a4399.funnycore.rx.RxLifeCycleEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import april.yun.widget.JToolbar;
import io.reactivex.subjects.PublishSubject;

/**
 * 文件描述：Activity基类
 * Created by zhanlinjian2888 on 2017/12/08 16:35.
 * E-mail:zhanlinjian@4399inc.com
 */
public abstract class BaseListActivity<T extends LoadMoreViewModel> extends BaseAppCompatActivity {

    // title
    protected JToolbar mToolbar;

    // 生命周期Event
    protected final PublishSubject<RxLifeCycleEvent> lifecycleSubject = PublishSubject.create();

    // 对应一个activity的数据模型
    public T viewModel;

    /**
     * 广播接收器列表
     */
    protected List<BroadcastReceiver> mBroadcastReceivers = null;

    private NetworkStateReceiver mNetworkStateReceiver;


    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = initModel();
        if (initBinding() instanceof  JToolbar){
            mToolbar = (JToolbar) initBinding();
        }
        //初始化广播
        mNetworkStateReceiver = new NetworkStateReceiver();
        putBroadcastReceiver(mNetworkStateReceiver, ConnectivityManager.CONNECTIVITY_ACTION);
        lifecycleSubject.onNext(RxLifeCycleEvent.CREATE);
        initActionToolbar();
        initViewAndData();
        viewModel.toGetData(putParam());
    }


    /**
     * 有Intent的时候 解析
     */
    protected void praseIntent(Intent intent) {

    }


    /**
     * 初始化title
     */
    protected void initActionToolbar() {
        //mToolbar =  findViewById(R.id.toolbar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            //必须在setsupportactionbar后设置
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            //mToolbar.setLeftIcon(R.drawable.btn_back_38_darkgray);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.btn_back_38_darkgray);
            initToolBar();
        }
    }


    /**
     * toobar相关功能设置
     */
    protected void initToolBar() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                BaseListActivity.this.finish();
            }
        });
    }


    /**
     * 注册一个广播接收器
     */
    public void putBroadcastReceiver(BroadcastReceiver receiver, String... filterAction) {
        if (mBroadcastReceivers == null) {
            mBroadcastReceivers = new ArrayList<BroadcastReceiver>();
        }

        IntentFilter filter = new IntentFilter();
        for (String action : filterAction) {
            filter.addAction(action);
        }
        registerReceiver(receiver, filter);
        mBroadcastReceivers.add(receiver);
    }


    /**
     * 清空所有广播接收器
     */
    public void clearBroadcastReceiver() {
        if (mBroadcastReceivers == null) {
            return;
        }
        for (BroadcastReceiver receiver : mBroadcastReceivers) {
            unregisterReceiver(receiver);
        }
        mBroadcastReceivers.clear();
    }


    @Override protected void onDestroy() {
        unregisterReceiver(mNetworkStateReceiver);
        lifecycleSubject.onNext(RxLifeCycleEvent.DESTROY);
        if (viewModel != null) {
            viewModel.clearOnDestory();
        }
        super.onDestroy();
    }


    /**
     * 抽象方法，用于构造初始的ViewModel并赋给VM变量
     *
     * @return 视图模型
     */
    protected abstract T initModel();

    /**
     * 初始化binding类型
     */
    protected abstract View initBinding();


    /**
     * 初始化views以及数据相关
     */
    protected void initViewAndData() {

    }


    /**
     * 接口调用的请求参数
     */
    protected abstract HashMap putParam();
}
