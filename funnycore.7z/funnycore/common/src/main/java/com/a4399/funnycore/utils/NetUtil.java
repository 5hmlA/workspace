package com.a4399.funnycore.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * 网络工具
 *
 * @author 徐智伟
 * @create 16/3/1
 */
public final class NetUtil {
  /**
   * 判断网络是否可用
   *
   * @param context Context对象
   */
  public static Boolean isNetworkAvailable(Context context) {
    ConnectivityManager cm = (ConnectivityManager) context
        .getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo current = cm.getActiveNetworkInfo();
    if (current == null) {
      return false;
    }
    return (current.isAvailable());
  }

  public static boolean isWifiConnected(Context context){
    ConnectivityManager cm = (ConnectivityManager) context
        .getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo current = cm.getActiveNetworkInfo();
    if (current == null) {
      return false;
    }
    if(current.getType()==1){
      return true;
    }else {
      return false;
    }
  }
}
