package com.a4399.funnycore.base;

import com.a4399.funnycore.CommonConsts;
import java.io.Serializable;

/**
 * 文件描述：数据模型验证错误
 * Created by zhanlinjian2888 on 2017/12/08 16:35.
 * E-mail:zhanlinjian@4399inc.com
 */
public class BaseViewModelErrorInfo implements Serializable {

    private static final long serialVersionUID = -4912699355134642262L;

    //错误属性名称
    private String errAttName;

    //错误消息
    private String errMsg;


    public BaseViewModelErrorInfo(String errAttName, String errMsg) {
        this.errAttName = errAttName;
        this.errMsg = errMsg;
    }


    public String getAttName() {
        return this.errAttName;
    }


    public void setErrAttName(String aErrAttName) {
        this.errAttName = aErrAttName;
    }


    public String getErrMsg() {
        if (errMsg == null) {
            return CommonConsts.BASE_VIEW_MODEL_ERROR;
        }
        return this.errMsg;
    }


    public void setErrMsg(String aErrMsg) {
        this.errMsg = aErrMsg;
    }


    public BaseViewModelErrorInfo() {
        errAttName = errMsg = "";
    }
}
