package com.a4399.funnycore.utils;

import android.os.Environment;
import android.os.StatFs;

import java.io.File;

/**
 * SDCard相关工具类
 *
 * @author 徐智伟
 * @create 15/9/30
 */
public class SdCardUtil {

  /**
   * 检测sdcard是否可用
   *
   * @return true为可用，否则为不可用
   */
  public static boolean isSdCardAvailable() {
    String status = Environment.getExternalStorageState();
    if (!status.equals(Environment.MEDIA_MOUNTED)) {
      return false;
    }
    return true;
  }

  /**
   * 计算SD卡的剩余空间
   *
   * @return 返回-1，说明没有安装sd卡
   */
  public static long getFreeDiskSpace() {

    long freeSpace = 0;
    if (isSdCardAvailable()) {
      try {
        File path = Environment.getExternalStorageDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        freeSpace = availableBlocks * blockSize / 1024;
      } catch (Exception e) {
        e.printStackTrace();
      }
    } else {
      return -1;
    }
    return (freeSpace);
  }

}
