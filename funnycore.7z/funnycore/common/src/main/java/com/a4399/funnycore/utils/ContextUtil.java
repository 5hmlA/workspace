package com.a4399.funnycore.utils;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.view.View;

/**
 * 文件描述：上下文的工具
 * Created by zhanlinjian2888 on 2018/1/3.
 * E-mail:zhanlinjian@4399inc.com
 */

public class ContextUtil {

    /**
     * 获取view对应的上下文
     */
    public static Context getContextByView(View view) {
        Context context = view.getContext();
        //while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                return context;
            }
            context = ((ContextWrapper) context).getBaseContext();
        //}
        return null;
    }
}
