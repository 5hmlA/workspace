package com.a4399.funnycore;

import android.content.Context;

/**
 * 通用常量类
 * Created by zhanlinjian2888 on 2017/12/11 16:35.
 * E-mail:zhanlinjian@4399inc.com
 */
public final class CommonConsts {
    /**
     * 存放用户信息的共享文件名
     */
    public static final String BASE_VIEW_MODEL_ERROR = "模型格式有误";

    public static Context getAppContextInstance;
}
