/*
 * Copyright 2014 Google Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.a4399.funnycore.utils;

import java.lang.reflect.InvocationTargetException;

/**
 * 反射类
 */
public class ReflectionUtil {

  private static final String TAG = "ReflectionUtil";

  /**
   * 获取class
   * @param name
   * @return
   */
  public static Class getClass(String name) {
    try {
      return Class.forName(name);
    } catch (ClassNotFoundException e) {
      LogUtil.error(TAG,"Could not find class: " + name + "!");
    }
    return null;
  }

  public static Object newInstance(String className, Object[] args, Class<?> argsType) {
    return null;
  }

  public static Object tryInvokeMethod(Class target, String methodName, Object... args) {
    Class<?>[] argTypes = new Class<?>[args.length];
    for (int i = 0; i < args.length; i++) {
      if (args[i].getClass() == Integer.class) { //一般的函数都是 int 而不是Integer
        argTypes[i]  = int.class;
      } else if (args[i].getClass() == Float.class) { //一般的函数都是 int 而不是Integer
        argTypes[i] = float.class;
      } else if (args[i].getClass() == Double.class) { //一般的函数都是 int 而不是Integer
        argTypes[i] = double.class;
      } else {
        argTypes[i] = args[i].getClass();
      }
    }

    return tryInvokeMethod(target, methodName, argTypes, args);
  }

  public static Object tryInvokeMethod(Class target, String methodName, Class<?>[] argTypes,
                                       Object... args) {
    if (target == null) {
      return null;
    }
    try {
      return target.getMethod(methodName, argTypes).invoke(target, args);
    } catch (NoSuchMethodException ignored) {
      LogUtil.error(TAG,"NoSuchMethodException:" + methodName + "!",ignored);

    } catch (IllegalAccessException ignored) {
      LogUtil.error(TAG,"IllegalAccessException:" + methodName + "!",ignored);

    } catch (InvocationTargetException ignored) {
      LogUtil.error(TAG,"InvocationTargetException:" + methodName + "!",ignored);

    }
    return null;
  }

}
