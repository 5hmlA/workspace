package com.a4399.funnycore.utils;

import java.text.DecimalFormat;

/**
 * 文件描述：加减乘除工具
 * Created by zhanlinjian2888 on 2017/12/26.
 * E-mail:zhanlinjian@4399inc.com
 */

public class CalculationUtil {

    /**
     * 两个整数整除，获取2位小数点的计算
     *
     * @param divisored 被除
     * @param divisor 除数
     */
    public static String divisionDecimal2(int divisored, int divisor) {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format((float) divisored / divisor);
    }
}
