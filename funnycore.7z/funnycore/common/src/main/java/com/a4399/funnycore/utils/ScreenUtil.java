package com.a4399.funnycore.utils;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/**
 * 文件描述：屏幕管理工具
 * Created by zhanlinjian2888 on 2018/1/5.
 * E-mail:zhanlinjian@4399inc.com
 */

public class ScreenUtil {


}
