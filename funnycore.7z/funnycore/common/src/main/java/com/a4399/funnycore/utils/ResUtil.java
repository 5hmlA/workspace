package com.a4399.funnycore.utils;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import com.a4399.funnycore.CommonConsts;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 16/1/5
 */
public final class ResUtil {

  /**
   * 获取资源字符串
   *
   * @param resId 资源ID
   */
  public static String getString(int resId) {
    return resources().getString(resId);
  }

  /**
   * 获取资源字符串数组
   *
   * @param resId 资源ID
   */
  public static String[] getStrings(int resId) {
    return resources().getStringArray(resId);
  }

  /**
   * 获取字符串资源
   */
  public static String getStringFormat(int resId, Object... args) {
    return resources().getString(resId, args);
  }

  /**
   * 获取资源颜色
   *
   * @param resId 资源ID
   */
  public static int getColor(int resId) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      return resources().getColor(resId, CommonConsts.getAppContextInstance.getTheme());
    } else {
      return resources().getColor(resId);
    }
  }

  /**
   * 获取资源drawable对象
   *
   * @param resId 资源ID
   */
  public static Drawable getDrawable(int resId) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
      return resources().getDrawable(resId, CommonConsts.getAppContextInstance.getTheme());
    } else {
      return resources().getDrawable(resId);
    }
  }

  private static Resources resources() {
    return CommonConsts.getAppContextInstance.getResources();
  }

  public static final int drawable(String name) {
    return identifier(name, "drawable");
  }

  private static final int identifier(String name, String type) {
    Resources resources = resources();
    String packageName = CommonConsts.getAppContextInstance.getPackageName();
    if (resources != null) {
      return resources.getIdentifier(name, type, packageName);
    }
    return resources.getIdentifier(name, type, packageName);
  }
}
