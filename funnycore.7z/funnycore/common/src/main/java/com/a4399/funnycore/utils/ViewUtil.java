package com.a4399.funnycore.utils;

import android.app.Dialog;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;

/**
 * @author Linbing Tang
 * @since 2016/11/22
 */

public final class ViewUtil {
    private ViewUtil(){}

    public static <T extends View> T find(View parent, int id){
        return (T) parent.findViewById(id);
    }

    public static <T extends View> T find(Dialog parent, int id){
        return (T) parent.findViewById(id);
    }

    public static View findRecursive(View view, int id){
        if(view == null){
            return null;
        }

        if(view.getId() == id){
            return view;
        }

        if(view instanceof ViewGroup){
            View child = view.findViewById(id);
            if(child != null){
                return child;
            }
        }

        ViewParent parent = view.getParent();
        if(parent == null || !(parent instanceof ViewGroup)) {
            return null;
        }

        View child = ((ViewGroup) parent).findViewById(id);
        if(child != null){
            return child;
        }

        return findRecursive((View) parent, id);
    }

    public static void setText(TextView text, int formatId, Object...args){
        text.setText(text.getContext().getString(formatId, args));
    }
}
