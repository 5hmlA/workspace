package com.a4399.funnycore.loading;

import android.support.annotation.IntDef;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.a4399.funnycore.loading.StateInterface.ERROR;
import static com.a4399.funnycore.loading.StateInterface.FREETIME;
import static com.a4399.funnycore.loading.StateInterface.LOADING;
import static com.a4399.funnycore.loading.StateInterface.LOADING_DIALOG;
import static com.a4399.funnycore.loading.StateInterface.NO_NETWORK;

/**
 * 文件描述：状态控制接口
 * Created by zhanlinjian2888 on 2017/12/15.
 * E-mail:zhanlinjian@4399inc.com
 */
@IntDef({ FREETIME, ERROR, LOADING, LOADING_DIALOG, NO_NETWORK }) @Retention(RetentionPolicy.SOURCE)
public @interface StateInterface {

    int FREETIME = 0;// 空闲状态
    int ERROR = 1;// 错误状态
    int LOADING = 2;// 加载状态
    int LOADING_DIALOG = 3;// 对话框形式的加载状态
    int NO_NETWORK = 4;// 网络异常状态
}
