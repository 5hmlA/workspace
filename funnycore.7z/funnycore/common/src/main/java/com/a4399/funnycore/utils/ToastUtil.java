package com.a4399.funnycore.utils;

import android.content.Context;
import android.text.TextUtils;
import android.widget.Toast;

/**
 * 描述:Toast工具类
 *
 * @author 徐智伟
 * @create 15/9/7
 */
public final class ToastUtil {
    private static Toast sToast;
    private static Context sContext;

    private ToastUtil(){
    }

    public static void regest(Context Context){

        sContext = Context;
    }

    private static void show(int resId, int duration){
        Toast.makeText(sContext, resId, duration).show();
    }

    private static void show(String message, int duration){
        Toast.makeText(sContext, message, duration).show();
    }

    public static void showShort(int resId){
        show( resId, Toast.LENGTH_SHORT);
    }

    public static void showShort(String message){
        show(message, Toast.LENGTH_SHORT);
    }

    public static void toastErrorMsg(Throwable throwable){
        showShort(getMessage(throwable));
    }

    public static String getMessage(Throwable throwable){
        String message = "网络异常";
        if(throwable != null && !TextUtils.isEmpty(message = throwable.getMessage())) {
            if(message.toLowerCase().contains("java.net.unknownhostexception")) {
                message = "网络异常";
            }
        }
        return message;
    }

    public static void showLong( int resId){
        show( resId, Toast.LENGTH_LONG);
    }

    public static void showLong( String message){
        show( message, Toast.LENGTH_LONG);
    }

    /**
     * @param override
     *         {@code true} 显示Toast并取消上一次的Toast
     */
    public static void showShort( int resId, boolean override){
        if(override) {
            overrideToast( resId, Toast.LENGTH_SHORT);
        }else {
            show( resId, Toast.LENGTH_SHORT);
        }
    }

    /**
     * @param override
     *         {@code true} 显示Toast并取消上一次的Toast
     */
    public static void showShort(String message, boolean override){
        if(override) {
            overrideToast(message, Toast.LENGTH_SHORT);
        }else {
            show( message, Toast.LENGTH_SHORT);
        }
    }

    /**
     * @param override
     *         {@code true} 显示Toast并取消上一次的Toast
     */
    public static void showLong( int resId, boolean override){
        if(override) {
            overrideToast(resId, Toast.LENGTH_LONG);
        }else {
            show( resId, Toast.LENGTH_LONG);
        }
    }

    /**
     * @param override
     *         {@code true} 显示Toast并取消上一次的Toast
     */
    public static void showLong( String message, boolean override){
        if(override) {
            overrideToast( message, Toast.LENGTH_LONG);
        }else {
            show( message, Toast.LENGTH_LONG);
        }
    }

    private static void overrideToast(int resId, int duration){
        if(sToast != null) {
            sToast.cancel();
        }
        sToast = Toast.makeText(sContext, resId, duration);
        sToast.show();
    }

    private static void overrideToast(String message, int duration){
        if(sToast != null) {
            sToast.cancel();
        }
        sToast = Toast.makeText(sContext, message, duration);
        sToast.show();
    }
}