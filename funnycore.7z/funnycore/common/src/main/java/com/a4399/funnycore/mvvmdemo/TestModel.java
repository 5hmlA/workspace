package com.a4399.funnycore.mvvmdemo;

/**
 * Created by ZLJ on 2017/12/8.
 */

public class TestModel {
}
