package com.a4399.funnycore.utils;

import java.io.Closeable;
import java.io.IOException;

/**
 * @author Linbing Tang
 * @since 2017/04/05
 */

public class IOUtil {
  private IOUtil(){}

  public static void close(Closeable stream){
    if(stream != null){
      try {
        stream.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }
}
