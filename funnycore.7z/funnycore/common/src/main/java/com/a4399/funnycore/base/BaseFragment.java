package com.a4399.funnycore.base;

import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.a4399.funnycore.utils.ToastUtil;

/**
 * 文件描述：fragment基类
 * Created by zhanlinjian2888 on 2017/12/08 16:32.
 * E-mail:zhanlinjian@4399inc.com
 */
public abstract class BaseFragment<T extends BaseViewModel> extends BaseSimpleFragment {

    // 对应一个fragment的数据模型
    public T viewModel;


    @Nullable @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        viewModel = initModel();
        return initBinding(inflater, container).getRoot();
    }


    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        initViewAndData();
        super.onViewCreated(view, savedInstanceState);
    }


    /**
     * 抽象方法，用于构造初始的ViewModel并赋给VM变量
     *
     * @return 视图模型
     */
    protected abstract T initModel();

    /**
     * 初始化binding类型
     */
    protected abstract ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container);


    public void onUpdated() {
        BaseViewModelErrorInfo errorInfo = viewModel.hasError();
        if (errorInfo != null) {
            // 模拟数据有误，提示用户。
            ToastUtil.showShort(errorInfo.getErrMsg(), true);
            return;
        }
        viewModel.notifyChange();
    }


    @Override protected boolean isBindRxBus() {
        return false;
    }


    @Override protected void initRxBus() {

    }
}
