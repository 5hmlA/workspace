package com.a4399.funnycore.utils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 线程池管理类
 *
 * @author 徐智伟
 * @create 15/9/30
 */
public class ThreadPoolManager {

  private static ThreadPoolManager manager;
  private ExecutorService service;

  private ThreadPoolManager() {
    int num = Runtime.getRuntime().availableProcessors();
    service = Executors.newFixedThreadPool(num * 2);
  }

  public static ThreadPoolManager getInstance() {
    if (manager == null) {
      manager = new ThreadPoolManager();
    }
    return manager;
  }

  public void addTask(Runnable runnable) {
    service.submit(runnable);
  }
}
