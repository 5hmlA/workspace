package com.a4399.funnycore.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.a4399.common.R;

/**
 * 自定义评价星星类(任何形状)
 */

public class JRatingBar extends View {
    //星星评分
    private float mRating = 0.0F;
    //星星个数
    private int starNum = 5;
    //星星高度
    private int starHeight;
    //星星宽度
    private int starWidth;
    //星星间距
    private int starDistance;
    //星星背景
    private Drawable starBackgroundBitmap;
    //动态星星
    private Bitmap starDrawDrawable;
    //星星变化监听
    private OnStarChangeListener changeListener;
    //是否可以点击
    private boolean isClick = true;
    //画笔
    private Paint mPaint;
    private float stepSize = 1;


    public JRatingBar(Context mContext, AttributeSet attrs) {
        super(mContext, attrs);
        init(mContext, attrs);
    }


    public JRatingBar(Context mContext, AttributeSet attrs, int defStyleAttr) {
        super(mContext, attrs, defStyleAttr);
        init(mContext, attrs);
    }


    private void init(Context mContext, AttributeSet attrs) {

        //初始化控件属性
        TypedArray typedArray = mContext.obtainStyledAttributes(attrs, R.styleable.jstar);
        starNum = typedArray.getInteger(R.styleable.jstar_starsNum, 5);
        starHeight = (int) typedArray.getDimension(R.styleable.jstar_starHeight, 0);
        starWidth = (int) typedArray.getDimension(R.styleable.jstar_starWidth, 0);
        stepSize = (int) typedArray.getFloat(R.styleable.jstar_stepSize, 1);
        starDistance = (int) typedArray.getDimension(R.styleable.jstar_starDistance, 0);
        isClick = typedArray.getBoolean(R.styleable.jstar_starClickable, true);
        starBackgroundBitmap = typedArray.getDrawable(R.styleable.jstar_starBackground);
        starDrawDrawable = drawableToBitmap(typedArray.getDrawable(R.styleable.jstar_starDrawBackground));
        typedArray.recycle();
        setClickable(isClick);
        //初始化画笔
        mPaint = new Paint();
        //设置抗锯齿
        mPaint.setAntiAlias(true);
        if (starDrawDrawable != null) mPaint.setShader(new BitmapShader(starDrawDrawable, BitmapShader.TileMode.CLAMP, BitmapShader.TileMode.CLAMP));
    }


    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(starWidth * starNum + starDistance * (starNum - 1), starHeight);
    }


    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (null == starDrawDrawable || null == starBackgroundBitmap) {
            return;
        }
        for (int i = 0; i < starNum; i++) {
            starBackgroundBitmap.setBounds(starDistance * i + starWidth * i, 0, starWidth * (i + 1) + starDistance * i, starHeight);
            starBackgroundBitmap.draw(canvas);
        }
        if (mRating > 1) {
            canvas.drawRect(0, 0, starWidth, starHeight, mPaint);
            if (mRating - (int) (mRating) == 0) {
                for (int i = 1; i < mRating; i++) {
                    canvas.translate(starDistance + starWidth, 0);
                    canvas.drawRect(0, 0, starWidth, starHeight, mPaint);
                }
            }
            else {
                for (int i = 1; i < mRating - 1; i++) {
                    canvas.translate(starDistance + starWidth, 0);
                    canvas.drawRect(0, 0, starWidth, starHeight, mPaint);
                }
                canvas.translate(starDistance + starWidth, 0);
                canvas.drawRect(0, 0, starWidth * (Math.round((mRating - (int) (mRating)) * 10) * 1.0f / 10), starHeight, mPaint);
            }
        }
        else {
            canvas.drawRect(0, 0, starWidth * mRating, starHeight, mPaint);
        }
    }


    @Override public boolean onTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        if (x < 0) {
            x = 0;
        }
        if (x > getMeasuredWidth()) {
            x = getMeasuredWidth();
        }
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                setMark(x * 1.0f / (getMeasuredWidth() * 1.0f / starNum));
                break;
            case MotionEvent.ACTION_MOVE:
                setMark(x * 1.0f / (getMeasuredWidth() * 1.0f / starNum));
                break;
            case MotionEvent.ACTION_UP:
                setMark(x * 1.0f / (getMeasuredWidth() * 1.0f / starNum));
                break;
        }
        return true;
    }


    public void setRating(float rating) {
        setMark(rating);
    }


    /**
     * 设置分数
     */
    public void setMark(Float mark) {
        mRating = Math.round(mark * 10) * 1.0f / 10;
        transforStepSize();
        if (null != changeListener) {
            changeListener.onStarChange(mRating);
        }
        invalidate();
    }


    private void transforStepSize() {
        int stept = (int) (stepSize * 10);
        mRating = getCell(mRating * 10, stept) / 10f;
    }


    public static int getCell(float num, int round) {
        return ((int) (num + round - 0.01)) / round * round;
    }


    /**
     * 设置监听
     */
    public void setStarChangeLister(OnStarChangeListener starChangeLister) {
        changeListener = starChangeLister;
    }


    /**
     * 获取分数
     */
    public float getRating() {
        return mRating;
    }


    /**
     * 星星数量变化监听接口
     */
    public interface OnStarChangeListener {
        void onStarChange(Float mark);
    }


    /**
     * drawable转bitmap
     */
    private Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable == null) {
            return null;
        }
        Bitmap bitmap = Bitmap.createBitmap(starWidth, starHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, starWidth, starHeight);
        drawable.draw(canvas);
        return bitmap;
    }
}
