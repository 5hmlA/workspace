package com.a4399.funnycore.base;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.SparseArray;

/**
 * @author 江祖赟.
 * @date 2017/6/7
 * @des [一句话描述]
 */
public class TabAdapter extends FragmentStatePagerAdapter {

    public abstract static class BaseFrgmtFractory {
        public SparseArray<LazyFragment> fmCache = new SparseArray<LazyFragment>();


        {
            initFrgment();
        }


        protected void initFrgment() {
        }


        public Fragment createFragment(int position) {
            return fmCache.get(position);
        }


        public void removeFragment(int position) {
            fmCache.remove(position);
        }
    }

    private String[] mTabtiles;
    private BaseFrgmtFractory mFrmtFractory;


    public TabAdapter(FragmentManager fm, String[] tabtiles, BaseFrgmtFractory frmtFractory) {
        super(fm);
        mTabtiles = tabtiles.clone();
        mFrmtFractory = frmtFractory;
    }


    @Override public Fragment getItem(int position) {
        return mFrmtFractory.createFragment(position);
    }


    @Override public int getCount() {
        return mTabtiles.length;
    }


    @Override public CharSequence getPageTitle(int position) {
        return mTabtiles[position];
    }
}
