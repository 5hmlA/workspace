package com.a4399.funnycore.base;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import com.a4399.funnycore.utils.StatusBarHelper;

/**
 * 文件描述：BaseActivity基类
 * Created by zhanlinjian2888 on 2017/12/08 16:35.
 * E-mail:zhanlinjian@4399inc.com
 */
public abstract class BaseAppCompatActivity extends AppCompatActivity {
    protected Intent mFromIntent;

    // 持有所有的Subscriptions
    // TODO need fix by zhanlinjian2888 on 20171211
    // protected CompositeSubscription rxSubscription = new CompositeSubscription();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        if (statusBarLight()) {
            StatusBarHelper.StatusBarLightMode(this);
        }
        super.onCreate(savedInstanceState);
        //是否开启rxbus订阅支持
        if (isBindRxBus()) {
            // TODO need fix by zhanlinjian2888 on 20171211
            // rxSubscription = RxUtils.getNewCompositeSubIfUnsubscribed(rxSubscription);
            initRxBus();
        }
        BaseAppManager.getInstance().addActivity(this);
        if(( mFromIntent = getIntent() ) != null) {
            initIntent(mFromIntent);
        }
    }


    protected boolean statusBarLight() {
        return true;
    }


    protected void initIntent(Intent fromIntent) {

    }


    @Override
    protected void onDestroy() {
        if (isBindRxBus()) {
            // TODO need fix by zhanlinjian2888 on 20171211
            // RxUtils.unsubscribeIfNotNull(rxSubscription);
        }
        super.onDestroy();

    }

    @Override
    public void finish() {
        super.finish();
        BaseAppManager.getInstance().removeActivity(this);
    }

    /**
     * 是否需要绑定RxBus
     *
     * @see #initRxBus()
     */
    protected boolean isBindRxBus(){
        return false;
    }

    /**
     * 事件响应
     * <p>需要重写 {@link #isBindRxBus()}返回 <code>true</code></p>
     */
    protected void initRxBus(){}
}
