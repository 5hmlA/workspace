package com.a4399.funnycore.utils;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import static com.a4399.funnycore.utils.LogUtil.makeLogTag;

/**
 * 文件操作工具类
 *
 * @author 徐智伟
 * @create 15/9/30
 */
public class FileUtil {

  public static final String TAG = makeLogTag(FileUtil.class);

  /**
   * 往SDCard写文件
   */
  public static void writeFileToSD(String fileName, String content) {
   writeFileToSD(Environment.getDownloadCacheDirectory(),fileName,content);
  }

  /**
   * 往SDCard写文件
   */
  public static void writeFileToSD(File path, String fileName, String content) {
    if (content == null) {
      content = "";
    }

    try {
      File file = new File(path, fileName);
      if (!file.exists()) {
        file.createNewFile();
      }
      if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
        FileOutputStream fos = new FileOutputStream(file);
        byte[] contentBuffers = content.getBytes();
        fos.write(contentBuffers);
        fos.close();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * SD卡中读取文件名
   */
  public static String readFileFromSD(String fileName) {

    try {
      File file = new File(Environment.getDownloadCacheDirectory(), fileName);
      if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
        FileInputStream fis = new FileInputStream(file);
        return readInStream(fis);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * 写文本文件
   * 在Android系统中，文件保存在 /data/data/PACKAGE_NAME/files 目录下
   */
  public static void write(Context context, String fileName, String content) {
    if (content == null) {
      content = "";
    }

    try {
      FileOutputStream fos = context.openFileOutput(fileName, Context.MODE_PRIVATE);
      fos.write(content.getBytes());

      fos.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * 读取文本文件
   */
  public static String read(Context context, String fileName) {
    try {
      FileInputStream in = context.openFileInput(fileName);
      return readInStream(in);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return "";
  }

/*  *//**
   * 以字节数组形式返回读取文件
   *//*
  public static byte[] getBytes(String pathName){
    return getBytes(new File(pathName));
  }

  *//**
   * 以字节数组形式返回读取文件
   *//*
  public static byte[] getBytes(File pathName){
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(pathName))) {
      byte[] buff = new byte[8*1024];
      int len;
      while((len = bis.read(buff))!=-1){
        bos.write(buff, 0, len);
      }
    }catch(IOException e){
      e.printStackTrace();
    }
    return bos.toByteArray();
  }*/

  /**
   * 以文本形式返回读取文件
   */
  public static String getText(String pathName){
    try {
      return readInStream(new FileInputStream(pathName));
    } catch (Exception e) {
      e.printStackTrace();
    }
    return "";
  }

  /**
   * 以文本形式返回读取文件
   */
  public static String getText(InputStream in){
    try {
      return readInStream(in);
    } catch (Exception e) {
      e.printStackTrace();
      return "";
    }
  }

  /**
   * 写文本到文件中
   */
  public static void writeText(String text, String pathName, boolean append) throws IOException {
    FileWriter writer = null;
    File dest = new File(pathName);
    File parent;
    if(!(parent = dest.getParentFile()).exists()){
      parent.mkdirs();
    }

    try {
      writer = new FileWriter(dest, append);
      writer.write(text);
      writer.flush();
    } finally {
      IOUtil.close(writer);
    }
  }

  /**
   * 写文本到文件中
   */
  public static void writeText(String text, String pathName) throws IOException {
    writeText(text, pathName, false);
  }

  private static String readInStream(InputStream inStream) {
    try {
      ByteArrayOutputStream outStream = new ByteArrayOutputStream();
      byte[] buffer = new byte[512];
      int length = -1;
      while ((length = inStream.read(buffer)) != -1) {
        outStream.write(buffer, 0, length);
      }

      outStream.close();
      inStream.close();
      return outStream.toString();
    } catch (IOException e) {
      Log.i("FileTest", e.getMessage());
    }
    return null;
  }

  public static File createFile(String folderPath, String fileName) {
    File destDir = new File(folderPath);
    if (!destDir.exists()) {
      destDir.mkdirs();
    }
    return new File(folderPath, fileName + fileName);
  }

  /**
   * 向手机写图片
   */
  public static boolean writeFile(byte[] buffer, String folder, String fileName) {
    boolean writeSucc = false;

    boolean sdCardExist = Environment.getExternalStorageState()
        .equals(Environment.MEDIA_MOUNTED);

    String folderPath = "";
    if (sdCardExist) {
      folderPath =
          Environment.getExternalStorageDirectory() + File.separator + folder + File.separator;
    } else {
      writeSucc = false;
    }

    File fileDir = new File(folderPath);
    if (!fileDir.exists()) {
      fileDir.mkdirs();
    }

    File file = new File(folderPath + fileName);
    FileOutputStream out = null;
    try {
      out = new FileOutputStream(file);
      out.write(buffer);
      writeSucc = true;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        out.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }

    return writeSucc;
  }

  /**
   * 根据文件绝对路径获取文件名
   */
  public static String getFileName(String filePath) {
    if (StringUtil.isEmpty(filePath)) {
      return "";
    }
    return filePath.substring(filePath.lastIndexOf(File.separator) + 1);
  }

  /**
   * 根据文件的绝对路径获取文件名但不包含扩展名
   */
  public static String getFileNameNoFormat(String filePath) {
    if (StringUtil.isEmpty(filePath)) {
      return "";
    }
    int point = filePath.lastIndexOf('.');
    return filePath.substring(filePath.lastIndexOf(File.separator) + 1, point);
  }

  /**
   * 获取文件扩展名
   */
  public static String getFileFormat(String fileName) {
    if (StringUtil.isEmpty(fileName)) {
      return "";
    }

    int point = fileName.lastIndexOf('.');
    return fileName.substring(point + 1);
  }

  /**
   * 去掉文件扩展名
   */
  public static String getFileNameWithouExName(String fileName) {
    if ((fileName != null) && (fileName.length() > 0)) {
      int dot = fileName.lastIndexOf('.');
      if ((dot > -1) && (dot < (fileName.length()))) {
        return fileName.substring(0, dot);
      }
    }
    return fileName;
  }

  /**
   * 获取文件大小
   */
  public static long getFileSize(String filePath) {
    long size = 0;

    File file = new File(filePath);
    if (file != null && file.exists()) {
      size = file.length();
    }
    return size;
  }

  /**
   * 获取文件大小
   *
   * @param size 字节
   */
  public static String getFileSize(long size) {
    if (size <= 0) {
      return "0";
    }
    java.text.DecimalFormat df = new java.text.DecimalFormat("##.##");
    float temp = (float) size / 1024;
    if (temp >= 1024) {
      return df.format(temp / 1024) + "M";
    } else {
      return df.format(temp) + "K";
    }
  }

  /**
   * 转换文件大小
   *
   * @return B/KB/MB/GB
   */
  public static String formatFileSize(long fileS) {
    java.text.DecimalFormat df = new java.text.DecimalFormat("#.00");
    String fileSizeString = "";
    if (fileS < 1024) {
      fileSizeString = df.format((double) fileS) + "B";
    } else if (fileS < 1048576) {
      fileSizeString = df.format((double) fileS / 1024) + "KB";
    } else if (fileS < 1073741824) {
      fileSizeString = df.format((double) fileS / 1048576) + "MB";
    } else {
      fileSizeString = df.format((double) fileS / 1073741824) + "G";
    }
    return fileSizeString;
  }

  /**
   * 获取目录文件大小
   */
  public static long getDirSize(File dir) {
    if (dir == null) {
      return 0;
    }
    if (!dir.isDirectory()) {
      return 0;
    }
    long dirSize = 0;
    File[] files = dir.listFiles();
    for (File file : files) {
      if (file.isFile()) {
        dirSize += file.length();
      } else if (file.isDirectory()) {
        dirSize += file.length();
        dirSize += getDirSize(file); //递归调用继续统计
      }
    }
    return dirSize;
  }

  public static byte[] toBytes(InputStream in) throws IOException {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    int ch;
    while ((ch = in.read()) != -1) {
      out.write(ch);
    }
    byte buffer[] = out.toByteArray();
    out.close();
    return buffer;
  }

  /**
   * 检查文件是否存在
   */
  public static boolean checkFileExists(String name) {
    boolean status;
    if (!name.equals("")) {
      File path = Environment.getExternalStorageDirectory();
      File newPath = new File(path.toString() + name);
      status = newPath.exists();
    } else {
      status = false;
    }
    return status;

  }

  /**
   * 新建目录
   */
  public static boolean createDirectory(String directoryName) {
    boolean status;
    if (!directoryName.equals("")) {
      File path = Environment.getExternalStorageDirectory();
      File newPath = new File(path.toString() + directoryName);
      status = newPath.mkdir();
      status = true;
    } else {
      status = false;
    }
    return status;
  }

  /**
   * 删除目录(包括：目录里的所有文件)
   */
  public static boolean deleteDirectory(String fileName) {
    boolean status;
    SecurityManager checker = new SecurityManager();

    if (!fileName.equals("")) {

      File newPath = new File(fileName);
      checker.checkDelete(newPath.toString());
      if (newPath.isDirectory()) {
        String[] listfile = newPath.list();
        // delete all files within the specified directory and then
        // delete the directory
        try {
          for (int i = 0; i < listfile.length; i++) {
            File deletedFile = new File(newPath.toString() + "/"
                + listfile[i].toString());
            if (deletedFile.isDirectory()) {
              deleteDirectory(deletedFile.getPath());
            }
            deletedFile.delete();
          }
          newPath.delete();
          LogUtil.info(TAG, fileName);
          status = true;
        } catch (Exception e) {
          e.printStackTrace();
          status = false;
        }

      } else {
        status = false;
      }
    } else {
      status = false;
    }
    return status;
  }

  /**
   * 删除文件
   */
  public static boolean deleteFile(String fileName) {
    boolean status;
    SecurityManager checker = new SecurityManager();

    if (!StringUtil.isEmpty(fileName)) {

      //File path = Environment.getExternalStorageDirectory();
      File newPath = new File(fileName);
      checker.checkDelete(newPath.toString());
      if (newPath.exists() && newPath.isFile()) {
        try {
          LogUtil.info(TAG, "DirectoryManager deleteFile:" + fileName);
          newPath.delete();
          status = true;
        } catch (SecurityException se) {
          se.printStackTrace();
          status = false;
        }
      } else {
        status = false;
      }
    } else {
      status = false;
    }
    return status;
  }

  /**
   * 移动目录
   *
   * @param sourch 需要移动的目录
   * @param target 目标目录
   */
  public static void moveFiles(File sourch, File target) throws IOException {
    copyFolder(sourch, target);
    deleteDirectory(sourch.getPath());
  }

  /**
   * 移动文件
   * @param source
   * @param target
   * @throws IOException
   */
  public static void moveFile(File source, File target) throws IOException {
    copyFile(source,target);
    deleteFile(source.getPath());
  }
  /**
   * 复制目录
   *
   * @param sourch 需要复制的目录
   * @param target 复制到
   * @throws IOException
   */
  public static void copyFolder(File sourch, File target) throws IOException {
    target.mkdirs();
    File[] list = sourch.listFiles();
    for (File file : list) {
      if (file.isDirectory()) {
        copyFolder(file, (new File(target, file.getName())));
      }
      if (file.isFile()) {
        copyFile(file, (new File(target, file.getName())));
      }
    }
  }

  /**
   * 复制文件
   *
   * @param source 要复制的文件
   * @param target 复制到
   */
  public static void copyFile(File source, File target) throws IOException {
    FileInputStream input = new FileInputStream(source);
    BufferedInputStream inbuff = new BufferedInputStream(input);
    FileOutputStream out = new FileOutputStream(target);
    BufferedOutputStream outbuff = new BufferedOutputStream(out);
    byte[] b = new byte[1024 * 5];
    int len = 0;
    while ((len = inbuff.read(b)) != -1) {
      outbuff.write(b, 0, len);
    }
    outbuff.flush();
    inbuff.close();
    outbuff.close();
    out.close();
    input.close();
  }

  public static void copyFile(String source, String target) throws IOException {
    copyFile(new File(source), new File(target));
  }

  /**
   * 获取目录文件个数
   */
  public long getFileList(File dir) {
    long count = 0;
    File[] files = dir.listFiles();
    count = files.length;
    for (File file : files) {
      if (file.isDirectory()) {
        count = count + getFileList(file);//递归
        count--;
      }
    }
    return count;
  }

  /**
   * Makes a directory, including any necessary but nonexistent parent
   * directories. If a file already exists with specified name but it is
   * not a directory then an IOException is thrown.
   * If the directory cannot be created (or does not already exist)
   * then an IOException is thrown.
   *
   * @param directory directory to create, must not be {@code null}
   * @throws NullPointerException if the directory is {@code null}
   * @throws IOException if the directory cannot be created or the file already exists but is not a
   * directory
   */
  public static void forceMkdir(File directory) throws IOException {
    if (directory.exists()) {
      if (!directory.isDirectory()) {
        String message =
            "File "
                + directory
                + " exists and is "
                + "not a directory. Unable to create directory.";
        throw new IOException(message);
      }
    } else {
      if (!directory.mkdirs()) {
        // Double-check that some other thread or process hasn't made
        // the directory in the background
        if (!directory.isDirectory()) {
          String message =
              "Unable to create directory " + directory;
          throw new IOException(message);
        }
      }
    }
  }

  public static boolean mkdirs(File directory) {
    try {
      forceMkdir(directory);
      return true;
    } catch (IOException e) {
    }
    return false;
  }

  //-----------------------------------------------------------------------

  /**
   * Deletes a directory recursively.
   *
   * @param directory directory to delete
   * @throws IOException in case deletion is unsuccessful
   */
  public static void deleteDirectory(File directory) throws IOException {
    if (!directory.exists()) {
      return;
    }

    if (!isSymlink(directory)) {
      cleanDirectory(directory);
    }

    if (!directory.delete()) {
      String message =
          "Unable to delete directory " + directory + ".";
      throw new IOException(message);
    }
  }

  /**
   * Deletes a file, never throwing an exception. If file is a directory, delete it and all
   * sub-directories.
   * <p/>
   * The difference between File.delete() and this method are:
   * <ul>
   * <li>A directory to be deleted does not have to be empty.</li>
   * <li>No exceptions are thrown when a file or directory cannot be deleted.</li>
   * </ul>
   *
   * @param file file or directory to delete, can be {@code null}
   * @return {@code true} if the file or directory was deleted, otherwise
   * {@code false}
   * @since 1.4
   */
  public static boolean deleteQuietly(File file) {
    if (file == null || !file.exists()) {
      return false;
    }
    try {
      if (file.isDirectory()) {
        cleanDirectory(file);
      }
    } catch (Exception ignored) {
    }

    try {
      return file.delete();
    } catch (Exception ignored) {
      return false;
    }
  }

  /**
   * Cleans a directory without deleting it.
   *
   * @param directory directory to clean
   * @throws IOException in case cleaning is unsuccessful
   */
  public static void cleanDirectory(File directory) throws IOException {
    if (!directory.exists()) {
      String message = directory + " does not exist";
      throw new IllegalArgumentException(message);
    }

    if (!directory.isDirectory()) {
      String message = directory + " is not a directory";
      throw new IllegalArgumentException(message);
    }

    File[] files = directory.listFiles();
    if (files == null) {  // null if security restricted
      throw new IOException("Failed to list contents of " + directory);
    }

    IOException exception = null;
    for (File file : files) {
      try {
        forceDelete(file);
      } catch (IOException ioe) {
        exception = ioe;
      }
    }

    if (null != exception) {
      throw exception;
    }
  }

  /**
   * Determines whether the specified file is a Symbolic Link rather than an actual file.
   * <p/>
   * Will not return true if there is a Symbolic Link anywhere in the path,
   * only if the specific file is.
   * <p/>
   * <b>Note:</b> the current implementation always returns {@code false} if the system
   * is detected as Windows using {@link FilenameUtil#isSystemWindows()}
   *
   * @param file the file to check
   * @return true if the file is a Symbolic Link
   * @throws IOException if an IO error occurs while checking the file
   * @since 2.0
   */
  public static boolean isSymlink(File file) throws IOException {
    if (file == null) {
      throw new NullPointerException("File must not be null");
    }
    if (FilenameUtil.isSystemWindows()) {
      return false;
    }
    File fileInCanonicalDir = null;
    if (file.getParent() == null) {
      fileInCanonicalDir = file;
    } else {
      File canonicalDir = file.getParentFile().getCanonicalFile();
      fileInCanonicalDir = new File(canonicalDir, file.getName());
    }

    if (fileInCanonicalDir.getCanonicalFile().equals(fileInCanonicalDir.getAbsoluteFile())) {
      return false;
    } else {
      return true;
    }
  }

  //-----------------------------------------------------------------------

  /**
   * Deletes a file. If file is a directory, delete it and all sub-directories.
   * <p/>
   * The difference between File.delete() and this method are:
   * <ul>
   * <li>A directory to be deleted does not have to be empty.</li>
   * <li>You get exceptions when a file or directory cannot be deleted.
   * (java.io.File methods returns a boolean)</li>
   * </ul>
   *
   * @param file file or directory to delete, must not be {@code null}
   * @throws NullPointerException if the directory is {@code null}
   * @throws FileNotFoundException if the file was not found
   * @throws IOException in case deletion is unsuccessful
   */
  public static void forceDelete(File file) throws IOException {
    if (file.isDirectory()) {
      deleteDirectory(file);
    } else {
      boolean filePresent = file.exists();
      if (!file.delete()) {
        if (!filePresent) {
          throw new FileNotFoundException("File does not exist: " + file);
        }
        String message =
            "Unable to delete file: " + file;
        throw new IOException(message);
      }
    }
  }

  /**
   * Schedules a file to be deleted when JVM exits.
   * If file is directory delete it and all sub-directories.
   *
   * @param file file or directory to delete, must not be {@code null}
   * @throws NullPointerException if the file is {@code null}
   * @throws IOException in case deletion is unsuccessful
   */
  public static void forceDeleteOnExit(File file) throws IOException {
    if (file.isDirectory()) {
      deleteDirectoryOnExit(file);
    } else {
      file.deleteOnExit();
    }
  }

  /**
   * Schedules a directory recursively for deletion on JVM exit.
   *
   * @param directory directory to delete, must not be {@code null}
   * @throws NullPointerException if the directory is {@code null}
   * @throws IOException in case deletion is unsuccessful
   */
  private static void deleteDirectoryOnExit(File directory) throws IOException {
    if (!directory.exists()) {
      return;
    }

    directory.deleteOnExit();
    if (!isSymlink(directory)) {
      cleanDirectoryOnExit(directory);
    }
  }

  /**
   * Cleans a directory without deleting it.
   *
   * @param directory directory to clean, must not be {@code null}
   * @throws NullPointerException if the directory is {@code null}
   * @throws IOException in case cleaning is unsuccessful
   */
  private static void cleanDirectoryOnExit(File directory) throws IOException {
    if (!directory.exists()) {
      String message = directory + " does not exist";
      throw new IllegalArgumentException(message);
    }

    if (!directory.isDirectory()) {
      String message = directory + " is not a directory";
      throw new IllegalArgumentException(message);
    }

    File[] files = directory.listFiles();
    if (files == null) {  // null if security restricted
      throw new IOException("Failed to list contents of " + directory);
    }

    IOException exception = null;
    for (File file : files) {
      try {
        forceDeleteOnExit(file);
      } catch (IOException ioe) {
        exception = ioe;
      }
    }

    if (null != exception) {
      throw exception;
    }
  }

  //-----------------------------------------------------------------------

  /**
   * 获取文件/目录路径
   * <pre>
   *    getPath("/", "sdcard"));// /sdcard
   *    getPath("/sdcard", "games"));// /sdcard/games
   *    getPath("/sdcard", "games", "options.txt"));// /sdcard/games/options.txt
   *  </pre>
   *
   * @param first 一级目录
   * @param more 子目录
   */
  public static String getPath(String first, String... more) {
    if("/".equals(first)){
      first = "";
    }
    return StringUtil.deepJoin(File.separator, first, more);
  }

  /**
   * 获取目录,如果目录不存在则创建
   * @see #getPath(String, String...)
   */
  public static String generateDir(String first, String... more) {
    String dir = getPath(first, more);
    File dirFolder = new File(dir);
    if (!dirFolder.exists()) {
      dirFolder.mkdirs();
    }
    return dir;
  }
}
