package com.a4399.funnycore.utils;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 15/9/7
 */
public class ActivityUtil {

    /**
     * view方式
     */
    public static void readyGo(View view, Class<?> clazz) {
        Context context = ContextUtil.getContextByView(view);
        readyGo((Activity) context, clazz, null);
    }


    /**
     * Activity跳转不带参数
     */
    public static void readyGo(Activity activity, Class<?> clazz) {
        readyGo(activity, clazz, null);
    }


    /**
     * Activity跳转,携带参数
     */
    public static void readyGo(View view, Class<?> clazz, Bundle bundle) {
        Context context = ContextUtil.getContextByView(view);
        Intent intent = new Intent(context, clazz);
        if (null != bundle) {
            intent.putExtras(bundle);
        }
        context.startActivity(intent);
    }


    /**
     * Activity跳转,携带参数
     */
    public static void readyGo(Activity activity, Class<?> clazz, Bundle bundle) {
        Intent intent = new Intent(activity, clazz);
        if (null != bundle) {
            intent.putExtras(bundle);
        }
        activity.startActivity(intent);
    }


    /**
     * Activity跳转，不带参数，携带requestcode
     */
    public static void readyGoForResult(Activity activity, Class<?> clazz, int requestCode) {
        readyGoForResult(activity, clazz, requestCode, null);
    }


    /**
     * Activity跳转，携带参数与requestcode
     */
    public static void readyGoForResult(Activity activity, Class<?> clazz, int requestCode, Bundle bundle) {
        Intent intent = new Intent(activity, clazz);
        if (null != bundle) {
            intent.putExtras(bundle);
        }
        activity.startActivityForResult(intent, requestCode);
    }
}
