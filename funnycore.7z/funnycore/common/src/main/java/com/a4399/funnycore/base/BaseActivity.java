package com.a4399.funnycore.base;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import april.yun.widget.JToolbar;
import com.a4399.common.R;
import com.a4399.funnycore.base.network.NetworkStateReceiver;
import com.a4399.funnycore.rx.RxLifeCycleEvent;
import com.a4399.funnycore.utils.ToastUtil;
import io.reactivex.subjects.PublishSubject;
import java.util.ArrayList;
import java.util.List;

/**
 * 文件描述：Activity基类
 * Created by zhanlinjian2888 on 2017/12/08 16:35.
 * E-mail:zhanlinjian@4399inc.com
 */
public abstract class BaseActivity<T extends BaseViewModel> extends BaseAppCompatActivity {

    // title
    protected JToolbar mToolbar;

    // 生命周期Event
    protected final PublishSubject<RxLifeCycleEvent> lifecycleSubject = PublishSubject.create();

    // 对应一个activity的数据模型
    public T viewModel;

    /**
     * 广播接收器列表
     */
    protected List<BroadcastReceiver> mBroadcastReceivers = null;

    private NetworkStateReceiver mNetworkStateReceiver;


    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = initModel();
        initBinding();
        //初始化广播
        mNetworkStateReceiver = new NetworkStateReceiver();
        putBroadcastReceiver(mNetworkStateReceiver, ConnectivityManager.CONNECTIVITY_ACTION);
        lifecycleSubject.onNext(RxLifeCycleEvent.CREATE);
        initActionToolbar();
        initViewAndData();
    }


    /**
     * 初始化title
     */
    protected void initActionToolbar() {
        //mToolbar =  findViewById(R.id.toolbar);
        if (mToolbar != null) {
            initToolBar();
            setSupportActionBar(mToolbar);
            //必须在setsupportactionbar后设置
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back);
        }
    }


    /**
     * toobar相关功能设置
     */
    protected void initToolBar() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                BaseActivity.this.finish();
            }
        });
    }


    /**
     * 注册一个广播接收器
     */
    public void putBroadcastReceiver(BroadcastReceiver receiver, String... filterAction) {
        if (mBroadcastReceivers == null) {
            mBroadcastReceivers = new ArrayList<BroadcastReceiver>();
        }

        IntentFilter filter = new IntentFilter();
        for (String action : filterAction) {
            filter.addAction(action);
        }
        registerReceiver(receiver, filter);
        mBroadcastReceivers.add(receiver);
    }


    /**
     * 清空所有广播接收器
     */
    public void clearBroadcastReceiver() {
        if (mBroadcastReceivers == null) {
            return;
        }
        for (BroadcastReceiver receiver : mBroadcastReceivers) {
            unregisterReceiver(receiver);
        }
        mBroadcastReceivers.clear();
    }


    @Override protected void onDestroy() {
        viewModel = null;
        unregisterReceiver(mNetworkStateReceiver);
        lifecycleSubject.onNext(RxLifeCycleEvent.DESTROY);
        super.onDestroy();
    }


    /**
     * 抽象方法，用于构造初始的ViewModel并赋给VM变量
     *
     * @return 视图模型
     */
    protected abstract T initModel();

    /**
     * 初始化binding类型
     */
    protected abstract void initBinding();

    /**
     * 初始化views以及数据相关
     */
    protected abstract void initViewAndData();


    public void onUpdated() {
        BaseViewModelErrorInfo errorInfo = viewModel.hasError();
        if (errorInfo != null) {
            // 模拟数据有误，提示用户。
            ToastUtil.showShort(errorInfo.getErrMsg(), true);
            return;
        }
        viewModel.notifyChange();
    }
}
