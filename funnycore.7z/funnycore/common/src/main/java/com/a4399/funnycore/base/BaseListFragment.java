package com.a4399.funnycore.base;

import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.HashMap;

/**
 * 文件描述：
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public abstract class BaseListFragment<T extends LoadMoreViewModel> extends BaseSimpleFragment {

    // 对应一个fragment的数据模型
    public T viewModel;


    @Nullable @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        viewModel = initModel();
        return initBinding(inflater, container).getRoot();
    }


    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);
    }


    /**
     * 抽象方法，用于构造初始的ViewModel并赋给VM变量
     *
     * @return 视图模型
     */
    protected abstract T initModel();

    /**
     * 初始化binding类型
     */
    protected abstract ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container);


    @Override protected boolean isBindRxBus() {
        return false;
    }


    @Override protected void initRxBus() {

    }


    /**
     * 在可见的时候 会触发
     */
    @Override public void firstUserVisibile() {
        if (viewModel != null) {
            viewModel.toGetData(putParam());
        }
    }


    @Override public void onDestroy() {
        super.onDestroy();
        if (viewModel != null) {
            viewModel.clearOnDestory();
        }
    }


    protected HashMap putParam() {
        return null;
    }
}