package com.a4399.funnycore.mvvmdemo;

import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import java.util.LinkedList;
import java.util.List;


/**
 * Created by ZLJ on 2017/12/7.
 */

public class TestViewModel extends BaseViewModel {

    private TestModel testModel;

    public TestModel getTestModel() {
        return testModel;
    }

    public void setTestModel(TestModel testModel) {
        this.testModel = testModel;
    }

    private String pwd;

    int X;

    public void dosomeing(){

    }

    public void updateX(){

    }


    @Override public void initViewModelData() {

    }


    @Override
    public List<BaseViewModelErrorInfo> verifyViewModel() {
        List<BaseViewModelErrorInfo> errs = new LinkedList<BaseViewModelErrorInfo>();
        if (pwd==null)
        {
            errs.add(new BaseViewModelErrorInfo("password", "请输入密码"));
            return errs;
        }
        return null;
    }
}
