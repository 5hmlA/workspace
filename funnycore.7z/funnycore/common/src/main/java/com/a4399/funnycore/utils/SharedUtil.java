package com.a4399.funnycore.utils;

import android.content.Context;

/**
 * 当前module的一些共享数据工具
 * <ul>
 *   <li>{@link Context }</li>
 * </ul>
 * @author Linbing Tang
 * @since 17-7-21.
 */
public final class SharedUtil {
  private static Context sContext;
  private SharedUtil() {
  }

  public static void init(Context context){
    sContext = context;
  }

  public static void requestContextNotNull(){
    if(sContext == null){
      throw new NullPointerException("Context must not be null, make sure that init() has been invoked.");
    }
  }

  public static Context getContext() {
    requestContextNotNull();
    return sContext;
  }
}
