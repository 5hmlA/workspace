package com.a4399.funnycore.utils;

import android.text.TextUtils;
import android.view.View;

import java.util.Collection;

public class CheckHelper {

    public static final int EQUALTAG = 0x7f199101;
    // 17 位加权因子
    private static final int[] RATIO_ARR = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2};

    // 校验码列表
    private static final char[] CHECK_CODE_LIST = {'1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'};

    private static final int NUM_0 = '0';

    private static final int ID_LENGTH = 17;

    public static boolean verifyId18(String idNo) {
        if (idNo == null || idNo.isEmpty()) {
            return false;
        }
        idNo = idNo.trim();
        if (idNo.length() != 18) {
            return false;
        }
        // 获取身份证号字符数组
        char[] idCharArr = idNo.toCharArray();
        // 获取最后一位（身份证校验码）
        char verifyCode = idCharArr[ID_LENGTH];
        // 身份证号第1-17加权和
        int idSum = 0;
        // 余数
        int residue;

        for (int i = 0; i < ID_LENGTH; i++) {
            int value = idCharArr[i] - NUM_0;
            idSum += value * RATIO_ARR[i];
        }
        // 取得余数   为什么要 mod11
        //https://www.zhihu.com/question/20205184
        residue = idSum % 11;

        return Character.toUpperCase(verifyCode) == CHECK_CODE_LIST[residue];
    }

    /**
     * 检查对象是否相同/都不为空
     *
     * @return true 安全的对象 都不为空
     */
    public static boolean isEqual(Object object1, Object object2){
        if(checkObjects(object1, object2)) {
            if(object2.equals(object1)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param strs
     * @return true 所有字符串都有效
     */
    public static boolean checkStrings(CharSequence... strs){
        for(CharSequence str : strs) {
            if(TextUtils.isEmpty(str)) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param strs
     * @return true 所有字符串都有效
     */
    public static boolean checkObjectStr(Object... strs){
        if(strs != null) {
            for(Object str : strs) {
                if(str == null || TextUtils.isEmpty(str.toString())) {
                    return false;
                }
            }
        }else {
            return false;
        }
        return true;
    }

    /**
     * 检查对象是否为空
     *
     * @return true 安全的对象 都不为空
     */
    public static boolean checkObjects(Object... objects){
        for(Object object : objects) {
            if(object == null) {
                return false;
            }
        }
        return true;
    }

    /**
     * 注意传过来的对象 是不相关的not like{p,p.friend}
     *
     * @param arrays
     * @param <T>
     * @return
     */
    public static <T> boolean checkArrays(T[]... arrays){
        if(arrays != null) {
            for(Object[] array : arrays) {
                if(array == null || array.length == 0) {
                    return false;
                }
            }
        }else {
            return false;
        }
        return true;
    }

    public static <T> T checkNotNull(T o){
        return checkNotNull(o, "CheckHelper");
    }

    public static <T> T checkNotNull(T o, String warm){
        if(o == null) {
            throw new NullPointerException(warm);
        }
        return o;
    }

    /**
     * 校验对象是否为空 为空抛异常
     */
    public static void verifyObjects(Object... objects){
        for(Object object : objects) {
            if(object == null) {
                throw new NullPointerException("CheckHelper");
            }
        }
    }


    public static Object safeObject(Object o){
        if(o == null) {
            return "";
        }else {
            return o;
        }
    }


    /**
     * 检查List集合是否 有效
     *
     * @return true 安全的Collection 都不为空
     */
    public static boolean checkLists(Collection... lists){
        for(Collection list : lists) {
            if(list == null || list.size()<=0) {
                return false;
            }
        }
        return true;
    }


    /**
     * 返回 安全的字符串
     *
     * @return 为空则返回“”
     */
    public static String safeString(Object str){
        if(str != null) {
            return str.toString().trim();
        }else {
            return "";
        }
    }

    public static boolean viewTagBoolean(View view, int viewTag){
        if(view.getTag(viewTag) != null && view.getTag(viewTag) instanceof Boolean) {
            return (boolean)view.getTag(viewTag);
        }else {
            return false;
        }
    }
}

