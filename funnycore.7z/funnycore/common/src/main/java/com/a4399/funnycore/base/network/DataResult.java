package com.a4399.funnycore.base.network;

/**
 * @another 江祖赟
 * @date 2017/7/5.
 * 网络数据的最外层 包装类
 */
public class DataResult<T> {

    /**
     * code : 10000
     * message : success
     * data : {}
     */

    public int code;
    public String message;
    public T data;

    public int getCode(){
        return code;
    }

    public void setCode(int code){
        this.code = code;
    }

    public String getMessage(){
        return message;
    }

    public void setMessage(String message){
        this.message = message;
    }

    public T getData(){
        return data;
    }

    public void setData(T data){
        this.data = data;
    }

}
