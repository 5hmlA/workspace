package com.a4399.funnycore.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 字符串处理工具类
 *
 * @author 徐智伟
 * @create 15/9/30
 */
public class StringUtil {

  /**
   * 描述：判断字符串是否为空
   */
  public static boolean isEmpty(String str) {
    if (str == null || str.length() == 0 || str.equalsIgnoreCase("null") || str.isEmpty()
        || str.equals("")) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * 描述：将null转化为“”.
   *
   * @param str 指定的字符串
   * @return 字符串的String类型
   */
  public static String parseEmpty(String str) {
    if (str == null || "null".equals(str.trim())) {
      str = "";
    }
    return str.trim();
  }

  /**
   * 获取字符串中文字符的长度（每个中文算2个字符）.
   *
   * @param str 指定的字符串
   * @return 中文字符的长度
   */
  public static int chineseLength(String str) {
    int valueLength = 0;
    String chinese = "[\u0391-\uFFE5]";
        /* 获取字段值的长度，如果含中文字符，则每个中文字符长度为2，否则为1 */
    if (!isEmpty(str)) {
      for (int i = 0; i < str.length(); i++) {
                /* 获取一个字符 */
        String temp = str.substring(i, i + 1);
              /* 判断是否为中文字符 */
        if (temp.matches(chinese)) {
          valueLength += 2;
        }
      }
    }
    return valueLength;
  }

  /**
   * 描述：获取字符串的长度.
   *
   * @param str 指定的字符串
   * @return 字符串的长度（中文字符计2个）
   */
  public static int strLength(String str) {
    int valueLength = 0;
    String chinese = "[\u0391-\uFFE5]";
    if (!isEmpty(str)) {
      //获取字段值的长度，如果含中文字符，则每个中文字符长度为2，否则为1
      for (int i = 0; i < str.length(); i++) {
        //获取一个字符
        String temp = str.substring(i, i + 1);
        //判断是否为中文字符
        if (temp.matches(chinese)) {
          //中文字符长度为2
          valueLength += 2;
        } else {
          //其他字符长度为1
          valueLength += 1;
        }
      }
    }
    return valueLength;
  }

  /**
   * 描述：获取指定长度的字符所在位置.
   *
   * @param str 指定的字符串
   * @param maxL 要取到的长度（字符长度，中文字符计2个）
   * @return 字符的所在位置
   */
  public static int subStringLength(String str, int maxL) {
    int currentIndex = 0;
    int valueLength = 0;
    String chinese = "[\u0391-\uFFE5]";
    //获取字段值的长度，如果含中文字符，则每个中文字符长度为2，否则为1
    for (int i = 0; i < str.length(); i++) {
      //获取一个字符
      String temp = str.substring(i, i + 1);
      //判断是否为中文字符
      if (temp.matches(chinese)) {
        //中文字符长度为2
        valueLength += 2;
      } else {
        //其他字符长度为1
        valueLength += 1;
      }
      if (valueLength >= maxL) {
        currentIndex = i;
        break;
      }
    }
    return currentIndex;
  }

  /**
   * 描述：手机号格式验证.
   *
   * @param str 指定的手机号码字符串
   * @return 是否为手机号码格式:是为true，否则false
   */
  public static Boolean isMobileNo(String str) {
    Boolean isMobileNo = false;
    try {
      Pattern p = Pattern.compile("^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$");
      Matcher m = p.matcher(str);
      isMobileNo = m.matches();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return isMobileNo;
  }

  /**
   * 描述：是否只是字母和数字.
   *
   * @param str 指定的字符串
   * @return 是否只是字母和数字:是为true，否则false
   */
  public static Boolean isNumberLetter(String str) {
    Boolean isNoLetter = false;
    String expr = "^[A-Za-z0-9]+$";
    if (str.matches(expr)) {
      isNoLetter = true;
    }
    return isNoLetter;
  }

  /**
   * 描述：是否只是数字.
   *
   * @param str 指定的字符串
   * @return 是否只是数字:是为true，否则false
   */
  public static Boolean isNumber(String str) {
    Boolean isNumber = false;
    String expr = "^[0-9]+$";
    if (str.matches(expr)) {
      isNumber = true;
    }
    return isNumber;
  }

  /**
   * 描述：是否是邮箱.
   *
   * @param str 指定的字符串
   * @return 是否是邮箱:是为true，否则false
   */
  public static Boolean isEmail(String str) {
    Boolean isEmail = false;
    String expr = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
    if (str.matches(expr)) {
      isEmail = true;
    }
    return isEmail;
  }

  /**
   * 描述：是否是中文.
   *
   * @param str 指定的字符串
   * @return 是否是中文:是为true，否则false
   */
  public static Boolean isChinese(String str) {
    Boolean isChinese = true;
    String chinese = "[\u0391-\uFFE5]";
    if (!isEmpty(str)) {
      //获取字段值的长度，如果含中文字符，则每个中文字符长度为2，否则为1
      for (int i = 0; i < str.length(); i++) {
        //获取一个字符
        String temp = str.substring(i, i + 1);
        //判断是否为中文字符
        if (temp.matches(chinese)) {
        } else {
          isChinese = false;
        }
      }
    }
    return isChinese;
  }

  /**
   * 描述：是否包含中文.
   *
   * @param str 指定的字符串
   * @return 是否包含中文:是为true，否则false
   */
  public static Boolean isContainChinese(String str) {
    Boolean isChinese = false;
    String chinese = "[\u0391-\uFFE5]";
    if (!isEmpty(str)) {
      //获取字段值的长度，如果含中文字符，则每个中文字符长度为2，否则为1
      for (int i = 0; i < str.length(); i++) {
        //获取一个字符
        String temp = str.substring(i, i + 1);
        //判断是否为中文字符
        if (temp.matches(chinese)) {
          isChinese = true;
        } else {

        }
      }
    }
    return isChinese;
  }

  /**
   * 描述：从输入流中获得String.
   *
   * @param is 输入流
   * @return 获得的String
   */
  public static String convertStreamToString(InputStream is) {
    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
    StringBuilder sb = new StringBuilder();
    String line = null;
    try {
      while ((line = reader.readLine()) != null) {
        sb.append(line + "\n");
      }

      //最后一个\n删除
      if (sb.indexOf("\n") != -1 && sb.lastIndexOf("\n") == sb.length() - 1) {
        sb.delete(sb.lastIndexOf("\n"), sb.lastIndexOf("\n") + 1);
      }

    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      try {
        is.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return sb.toString();
  }

  /**
   * 描述：标准化日期时间类型的数据，不足两位的补0.
   *
   * @param dateTime 预格式的时间字符串，如:2012-3-2 12:2:20
   * @return String 格式化好的时间字符串，如:2012-03-20 12:02:20
   */
  public static String dateTimeFormat(String dateTime) {
    StringBuilder sb = new StringBuilder();
    try {
      if (isEmpty(dateTime)) {
        return null;
      }
      String[] dateAndTime = dateTime.split(" ");
      if (dateAndTime.length > 0) {
        for (String str : dateAndTime) {
          if (str.indexOf("-") != -1) {
            String[] date = str.split("-");
            for (int i = 0; i < date.length; i++) {
              String str1 = date[i];
              sb.append(strFormat2(str1));
              if (i < date.length - 1) {
                sb.append("-");
              }
            }
          } else if (str.indexOf(":") != -1) {
            sb.append(" ");
            String[] date = str.split(":");
            for (int i = 0; i < date.length; i++) {
              String str1 = date[i];
              sb.append(strFormat2(str1));
              if (i < date.length - 1) {
                sb.append(":");
              }
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
    return sb.toString();
  }

  /**
   * 描述：不足2个字符的在前面补“0”.
   *
   * @param str 指定的字符串
   * @return 至少2个字符的字符串
   */
  public static String strFormat2(String str) {
    try {
      if (str.length() <= 1) {
        str = "0" + str;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return str;
  }

  /**
   * 描述：截取字符串到指定字节长度.
   *
   * @param str the str
   * @param length 指定字节长度
   * @return 截取后的字符串
   */
  public static String cutString(String str, int length) {
    return cutString(str, length, "");
  }

  /**
   * 描述：截取字符串到指定字节长度.
   *
   * @param str 文本
   * @param length 字节长度
   * @param dot 省略符号
   * @return 截取后的字符串
   */
  public static String cutString(String str, int length, String dot) {
    int strBLen = strlen(str, "GBK");
    if (strBLen <= length) {
      return str;
    }
    int temp = 0;
    StringBuffer sb = new StringBuffer(length);
    char[] ch = str.toCharArray();
    for (char c : ch) {
      sb.append(c);
      if (c > 256) {
        temp += 2;
      } else {
        temp += 1;
      }
      if (temp >= length) {
        if (dot != null) {
          sb.append(dot);
        }
        break;
      }
    }
    return sb.toString();
  }

  /**
   * 描述：截取字符串从第一个指定字符.
   *
   * @param str1 原文本
   * @param str2 指定字符
   * @param offset 偏移的索引
   * @return 截取后的字符串
   */
  public static String cutStringFromChar(String str1, String str2, int offset) {
    if (isEmpty(str1)) {
      return "";
    }
    int start = str1.indexOf(str2);
    if (start != -1) {
      if (str1.length() > start + offset) {
        return str1.substring(start + offset);
      }
    }
    return "";
  }

  /**
   * 描述：获取字节长度.
   *
   * @param str 文本
   * @param charset 字符集（GBK）
   * @return the int
   */
  public static int strlen(String str, String charset) {
    if (str == null || str.length() == 0) {
      return 0;
    }
    int length = 0;
    try {
      length = str.getBytes(charset).length;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return length;
  }

  /**
   * 获取大小的描述.
   *
   * @param size 字节个数
   * @return 大小的描述
   */
  public static String getSizeDesc(long size) {
    String suffix = "B";
    if (size >= 1024) {
      suffix = "K";
      size = size >> 10;
      if (size >= 1024) {
        suffix = "M";
        //size /= 1024;
        size = size >> 10;
        if (size >= 1024) {
          suffix = "G";
          size = size >> 10;
          //size /= 1024;
        }
      }
    }
    return size + suffix;
  }

  /**
   * 描述：ip地址转换为10进制数.
   *
   * @param ip the ip
   * @return the long
   */
  public static long ip2int(String ip) {
    ip = ip.replace(".", ",");
    String[] items = ip.split(",");
    return Long.valueOf(items[0]) << 24 | Long.valueOf(items[1]) << 16 | Long.valueOf(items[2]) << 8
        | Long.valueOf(items[3]);
  }

  public static String listToString(List<String> stringList, String split) {
    if (stringList == null) {
      return null;
    }
    StringBuilder result = new StringBuilder();
    boolean flag = false;
    for (String string : stringList) {
      if (flag) {
        result.append(split);
      } else {
        flag = true;
      }
      result.append(string);
    }
    return result.toString();
  }

  /**
   * 简单判断输出字符
   */
  public static String easyOutput(String input) {
    return isEmpty(input) ? "" : input;
  }

  /**
   * 简单判断输出字符
   */
  public static String easyOutput(Integer input) {
    if (input != null) {
      return easyOutput(input.toString());
    } else {
      return "";
    }
  }

  /**
   * 简单判断输出字符
   */
  public static String easyOutput(Object input) {
    if (input != null) {
      return input.toString();
    } else {
      return "";
    }
  }

  public static String from(File file) {
    return from(file.getAbsolutePath());
  }

  public static String from(String pathName) {
    BufferedReader br = null;
    try {
      br = new BufferedReader(new InputStreamReader(new FileInputStream(pathName)));
      String line;
      StringBuilder sb = new StringBuilder();
      while ((line = br.readLine()) != null) {
        sb.append(line);
      }
      return sb.toString();
    } catch (IOException e) {
      throw new RuntimeException(e);
    } finally {
      IOUtil.close(br);
    }
  }

  /**
   * 将分隔符插入到指定数组中
   *
   * @return 形如: a/b/c
   */
  public static String join(Object separator, Object... args) {
    if (Empty.yes(args)) {
      return "";
    }

    StringBuilder sb = new StringBuilder(args[0].toString());
    for (int i = 1; i < args.length; i++) {
      sb.append(separator).append(args[i]);
    }
    return sb.toString();
  }

  /**
   * 深度遍历多维数组, 将分隔符插入到指定数组中
   *
   * @return 形如: a/b/c
   */
  public static String deepJoin(Object separator, Object... args) {
    if (Empty.yes(args)) {
      return "";
    }
    return join(separator, deepFlat(args));
  }

  /**
   * 深度遍历多维数组或集合(如果是多维), 将src展开为一维集合
   */
  public static ArrayList<Object> deepFlat(Object src){
    ArrayList<Object> list = new ArrayList<>();
    if(src == null){
      return list;
    }

    if(src.getClass().isArray()){
      for (int i = 0; i < Array.getLength(src); i++) {
        list.addAll(deepFlat(Array.get(src, i)));
      }
    }else if(src instanceof Iterable){
      for (Object obj : (Iterable) src) {
        list.addAll(deepFlat(obj));
      }
    }else {
      list.add(src);
    }
    return list;
  }

  /**
   * 将分隔符插入到指定集合中
   *
   * @return 形如: a/b/c
   */
  public static <T> String join(Object separator, Collection<T> args) {
    if (Empty.yes(args)) {
      return "";
    }

    StringBuilder sb = new StringBuilder();
    String s = separator.toString();
    for (T arg : args) {
      sb.append(arg).append(s);
    }
    if (sb.length() > s.length()) {
      sb.delete(sb.length() - s.length(), sb.length());
    }
    return sb.toString();
  }

  //移动段
  private static final String MOBILE_REGEX = "13[456789]|147|15[012789]|178|18[23478]";
  //联通段
  private static final String UNICOM_REGEX = "13[012]|145|15[56]|176|18[56]";
  //电信段
  private static final String TELECOM_REGEX = "133|153|17[37]|18[019]";
  private static final String VIRTUAL_REGEX = "17[01]";
  //"13[0123456789]|14[57]|15[012356789]|17[013678]|18[0123456789]"
  private static final String PHONE_REGEX = "^(1[38]\\d|14[57]|15[0-35-9]|17[013678])\\d{8}$";
  /**
   * 泰国有效手机(10位)
   * 812345678
   * 0812345678
   * 08-1234-5678
   * 0066 812345678
   * 0066 0812345678
   * (0066)0812345678
   * (0066) 0812345678
   */
  private static final String THAILAND_REGEX = "((0066|\\(0066\\)) ?)?0?(8(\\-?\\d){8})";

  /**
   * 电话号码验证
   *
   * @see <a href='http://www.jihaoba.com/tools/haoduan/'>号段查询</a>
   * @since 2017-5-18
   */
  public static boolean validPhoneNumber(String phone) {
    return !Empty.yes(phone) && phone.matches(PHONE_REGEX);
  }

  /**
   * 转换泰国电话
   */
  public static String getThailandPhone(String phone) {
    if (Empty.yes(phone)) {
      return null;
    }

    if (phone.matches(THAILAND_REGEX)) {
      return "0066 0" + phone.replaceAll(THAILAND_REGEX, "$3").replace("-", "");
    }
    return null;
  }

  /**
   * 格式化卡号
   * updated by zhanlinjian2888 on 2017/07/12 [13:23]
   */
  public static String formatBankCardNo(String cardNo, int startIndex, int endInex) {
    if (StringUtil.isEmpty(cardNo) || cardNo.length() <= endInex) {
      return cardNo;
    }
    StringBuilder stringBuilder=new StringBuilder(cardNo);
    try {
      stringBuilder.replace(startIndex,endInex,"**** **** **** ");
    }catch (Exception e)
    {
      e.printStackTrace();
      return cardNo;
    }
    return stringBuilder.toString();
  }

  /**
   * 去掉小数点后面不需要的0
   *
   * @param str 源字符串
   */
  public static String formatSurplusZero(String str) {
    if (StringUtil.isEmpty(str)) {
      return str;
    }
    try {
      if (str.indexOf(".") > 0) {
        str = str.replaceAll("0+?$", "");//去掉后面无用的零
        str = str.replaceAll("[.]$", "");//如小数点后面全是零则去掉小数点
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return str;
  }
}
