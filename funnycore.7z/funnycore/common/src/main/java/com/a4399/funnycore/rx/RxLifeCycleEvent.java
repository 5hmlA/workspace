package com.a4399.funnycore.rx;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 2017/1/16
 */

public enum RxLifeCycleEvent {
  CREATE,
  START,
  RESUME,
  POST_RESUME,
  RESUME_FRAGMENTS,
  PAUSE,
  STOP,
  DESTROY
}
