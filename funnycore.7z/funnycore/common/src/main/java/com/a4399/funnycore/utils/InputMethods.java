package com.a4399.funnycore.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import java.lang.reflect.Method;

/**
 * 输入法工具类
 * @author Linbing Tang
 * @since 2017/06/09
 */
public final class InputMethods {
  private static InputMethodManager sInputMethodManager;
  private InputMethods(){}

  /**
   * 显示输入法
   */
  public static void showInputMethod(Context context){
    if(context == null) {
      return;
    }

    InputMethodManager im = getInputMethodManager(context);
    im.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_NOT_ALWAYS);
  }

  /**
   * 隐藏输入法
   */
  public static void hideInputMethod(Activity activity){
    if(activity == null) {
      return;
    }

    InputMethodManager im = getInputMethodManager(activity);
    im.hideSoftInputFromWindow(activity.getWindow().getDecorView().getWindowToken(), 0);
  }

  /**
   * 隐藏输入法
   */
  public static void hideInputMethod(Dialog dialog){
    if(dialog == null) {
      return;
    }

    InputMethodManager im = getInputMethodManager(dialog.getContext());
    im.hideSoftInputFromWindow(dialog.getWindow().getDecorView().getWindowToken(), 0);
  }

  /**
   * 隐藏输入法
   */
  public static void hideInputMethodOfView(View view){
    if(view == null) {
      return;
    }

    InputMethodManager im = getInputMethodManager(view.getContext());
    im.hideSoftInputFromWindow(view.getWindowToken(), 0);
  }

  /**
   * 获取输入法界面高度
   * @see InputMethodManager
   */
  public static int getInputMethodWindowVisibleHeight(Context context){
    InputMethodManager im = getInputMethodManager(context);
    try {
      Method method = InputMethodManager.class.getDeclaredMethod("getInputMethodWindowVisibleHeight");
      method.setAccessible(true);
      return (int) method.invoke(im);
    } catch (Exception e) {
      e.printStackTrace();
      return 0;
    }
  }



  private static InputMethodManager getInputMethodManager(Context context){
    if(sInputMethodManager == null) {
      sInputMethodManager = (InputMethodManager) context.getSystemService(
          Context.INPUT_METHOD_SERVICE);
    }
    return sInputMethodManager;
  }
}
