package com.a4399.funnycore.base.network;

import android.databinding.ObservableBoolean;
import easybind.jzy.bindingstar.statehelper.BaseStateViewModel;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import java.util.HashMap;

/**
 * @another 江祖赟
 * @date 2018/1/2.
 */
public abstract class LoadStateViewModel extends BaseStateViewModel {

    {
        pageState.set(0);
    }

    /**
     * 显示 SwipeRefreshLayout 刷新状态
     */
    public ObservableBoolean enableSwipeRefresh = new ObservableBoolean(true);
    private HashMap mMapParam;
    protected CompositeDisposable mCompositeDisposable = new CompositeDisposable();
    protected void collectDisposables(Disposable disposable){
        mCompositeDisposable.add(disposable);
    }

    protected void clearDisposables(){
        mCompositeDisposable.clear();
    }

    public final void toSubscribeData(HashMap mapParam) {
        mMapParam = mapParam;
        toGetData(mMapParam);
    }

    /**
     * 界面 第一次发起请求 调用 {@link #toSubscribeData(HashMap)}
     */
    @Override public final void subscribeData(Object orignParam) {
        toGetData(mMapParam);
    }


    /**
     * 调用接口 获取数据
     */
    public abstract void toGetData(HashMap mapParam);
}
