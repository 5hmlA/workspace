package com.a4399.funnycore.base;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import com.a4399.funnycore.base.network.PageDataWrapper;
import easybind.jzy.bindingstar.loadmorehelper.BaseLoadmoreViewModel;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import me.tatarka.bindingcollectionadapter2.collections.JObservableList;
import me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass;

/**
 * @another 江祖赟
 * @date 2017/12/18.
 *
 * view 中调用 {@link #toSubscribeData(HashMap)}
 * <br>
 * 请求数据 实现{@link #toGetData(HashMap)}
 * <br>
 * 拿到数据之后 使用{@link #afterGetDataSucceed(PageDataWrapper)}
 */
public abstract class LoadMoreViewModel extends BaseLoadmoreViewModel {

    {
        pageState.set(3);
        mCurrentPage = FIRST_PAGE;
    }


    private HashMap mMapParam;

    protected CompositeDisposable mCompositeDisposable = new CompositeDisposable();


    protected void collectDisposables(Disposable disposable) {
        mCompositeDisposable.add(disposable);
    }


    protected void clearDisposables() {
        mCompositeDisposable.clear();
    }


    @Override protected final void retryUp2LoadMoreData(RecyclerView recyclerView) {
        mLoadmoreControl.loadmoreSucceed();
        super.retryUp2LoadMoreData(recyclerView);
    }


    public final void addMoreData(List moreData, boolean hasNext, String tips) {
        mLoadmoreControl.setLoadmoreFinished(!hasNext, tips);
        mDataLists.addAll(moreData);
    }


    @Override public void showPageStateError(int pageDiffState) {
        super.showPageStateError(pageDiffState);
    }


    public void reflashAll2Finish(Collection data) {
        mDataLists.clear();
        mDataLists.addAll(data);
        hideLoading();
        mLoadmoreControl.loadmoreFinished();
    }


    /**
     * 根据 当前页码 和 是否有下一页数据 设置状态
     */
    public void afterGetDataSucceed(PageDataWrapper pageDataWrapper) {
        if (isFirstPage()) {
            if (mDataLists.isEmpty()) {
                mDataLists.addAll(pageDataWrapper.getList());
            }
            else {
                mDataLists.clear();
                mDataLists.addAll(pageDataWrapper.getList());
            }
            if (!pageDataWrapper.hasNext) {
                mLoadmoreControl.loadmoreFinished();
            }
        }
        else {
            addMoreData(pageDataWrapper.getList(), pageDataWrapper.hasNext, pageDataWrapper.tip);
        }
        hideLoading();
    }


    @Override public final void onRefresh(SwipeRefreshLayout swipeRefreshLayout) {
        mLoadmoreControl.forceDown2Refresh();
        mLoadmoreControl.loadmoreSucceed();
        super.onRefresh(swipeRefreshLayout);
    }


    public boolean isFirstPage() {
        return mCurrentPage == BaseLoadmoreViewModel.FIRST_PAGE;
    }


    public final void toSubscribeData(HashMap mapParam) {
        mMapParam = mapParam;
        toGetData(mMapParam);
    }


    public JObservableList getDataList() {
        return mDataLists;
    }


    @Override protected void toSearchFromService(String key) {
        if (mCurrentPage == FIRST_PAGE) {
            showPageStateLoading();
        }
        super.toSearchFromService(key);
    }


    public void clearOnDestory() {
        clearDisposables();
    }


    /**
     * 界面 第一次发起请求 调用 {@link #toSubscribeData(HashMap)}
     */
    @Override public final void subscribeData(Object orignParam) {
        toGetData(mMapParam);
    }


    /**
     * 调用接口 获取数据
     * <p>
     * <B>下拉刷新</B><br>
     * 下拉刷新 会自动调用 {@link #down2RefreshData()},mCurrentPage会重置为初值---》回掉{@link #subscribeData(Object)}
     * </p>
     * <p>
     * <b> 上拉加载更多</b><br>
     * 参数 当前页码 {@link #mCurrentPage}直接使用 父类有自动增减
     * <br>上拉之后 {@link #mCurrentPage}自增，同时回掉{@link #subscribeData(Object)}
     * </p>
     * <B>拿到数据后需要子类处理</B>
     * <li>数据完整正常 <br>
     * 如果是第一页数据 调用{@link #refreshedAllData(List)}<br>
     * 如果 不是 第一页数据 调用{@link #addMoreData(List, boolean)}同时传入是否还有下一页数据<br>
     * </li>
     * <li>数据异常(空/网络异常) ，直接调用{@link #showPageStateError(int)},或者 {@link #showPageStateError(int, String)}
     * <br>要显示的错误状态{PAGE_STATE_EMPTY,PAGE_STATE_EMPTY}具体看{@link easybind.jzy.bindingstar.statehelper.PageDiffState}</li>
     */
    public abstract void toGetData(HashMap mapParam);

    /**
     * 注册 列表中使用到的 数据类型和布局文件 {@link OnItemBindClass#regist(Class, int, int)}(参数：类型，布局参数变量，布局)
     */
    @Override protected abstract void registItemTypes(OnItemBindClass<Object> multipleItems);
}
