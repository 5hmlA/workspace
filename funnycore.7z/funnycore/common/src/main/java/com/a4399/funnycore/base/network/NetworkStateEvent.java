package com.a4399.funnycore.base.network;

/**
 * 网络状态时间
 *
 * @author 徐智伟
 * @create 16/4/22
 */
public class NetworkStateEvent {

  /** 没有网络 */
  public static final int NETWORKTYPE_INVALID = 0;

  /** wifi网络 */
  public static final int NETWORKTYPE_WIFI = 1;

  /** 2G网络 */
  public static final int NETWORKTYPE_2G = 2;

  /** 3G和3G以上网络，或统称为快速网络 */
  public static final int NETWORKTYPE_3G = 3;

  /** 其他网络 */
  public static final int NETWORKTYPE_OTHER = 4;

  public int status;

  public NetworkStateEvent(int status) {
    this.status = status;
  }
}
