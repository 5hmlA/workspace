package com.a4399.funnycore.app.download;

import android.databinding.Bindable;
import com.a4399.funnycore.R;
import com.a4399.funnycore.utils.ResUtil;
import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.structure.BaseModel;
import java.io.Serializable;
import java.util.Observable;
import sandboxtool.sj4399.com.library_download.BaseDownloadTask;
import sandboxtool.sj4399.com.library_download.FileDownloadListener;

/**
 * 文件描述：下载需要实体
 * Created by zhanlinjian2888 on 2017/12/20.
 * E-mail:zhanlinjian@4399inc.com
 */

public class BaseDownloadBean extends BaseModel implements Serializable{

    // 下载id
    @Column public int downLoadId;

    // 当前状态，默认空闲状态
    @Column public @DownloadStateInterface int mCurrentState = DownloadStateInterface.FREETIME;

    // 请求地址
    @Column public String apkUrl;

    @Column public String apkName;

    // 存储路径
    @Column public String path;

    // 回调数量，默认100，设置为0不接受回调！
    // {@link FileDownloadListener#progress(BaseDownloadTask, int, int)}
    // @see #setCallbackProgressMinInterval(int)
    @Column public int callbackProgressCount;

    // 下载的最小间隔，如果为0或者小于0，不参与计算！
    @Column public int minIntervalUpdateSpeedMs;

    // 下载唯一标记
    @Column public int tag;

    // 路径类型
    @Column public boolean isDir;

    // 当前完成下载
    @Column public String soFarBytes;

    // 总大小
    @Column public int totalBytes;

    // 当前进度
    @Column public String progress = "0";


    /**
     * 状态名称
     */
    public String getStateName() {
        switch (mCurrentState) {
            case DownloadStateInterface.FREETIME:
                return ResUtil.getString(R.string.download);
            case DownloadStateInterface.DOWNING:
                return ResUtil.getString(R.string.downloading);
            case DownloadStateInterface.PAUSE:
                return ResUtil.getString(R.string.continuation);
            case DownloadStateInterface.TRY_AGAIN:
                return ResUtil.getString(R.string.try_again);
            case DownloadStateInterface.OPEN:
                return ResUtil.getString(R.string.open);
            case DownloadStateInterface.UPDATE:
                return ResUtil.getString(R.string.update);
            case DownloadStateInterface.WAIT:
                return ResUtil.getString(R.string.wait);
            case DownloadStateInterface.INSTALL:
                return ResUtil.getString(R.string.install);
            default:
                return "";
        }
    }


    public String getApkName() {
        return apkName;
    }


    public void setApkName(String apkName) {
        this.apkName = apkName;
    }


    public String getProgress() {
        return progress;
    }


    public void setProgress(String progress) {
        this.progress = progress;
    }


    public int getDownLoadId() {
        return downLoadId;
    }


    public void setDownLoadId(int downLoadId) {
        this.downLoadId = downLoadId;
    }


    public int getTotalBytes() {
        return totalBytes;
    }


    public void setTotalBytes(int totalBytes) {
        this.totalBytes = totalBytes;
    }


    public String getSoFarBytes() {
        return soFarBytes;
    }


    public void setSoFarBytes(String soFarBytes) {
        this.soFarBytes = soFarBytes;
    }


    public int getCurrentState() {
        return mCurrentState;
    }


    public void setCurrentState(int currentState) {
        mCurrentState = currentState;
    }


    public boolean isDir() {
        return isDir;
    }


    public void setDir(boolean dir) {
        isDir = dir;
    }


    public String getApkUrl() {
        return apkUrl;
    }


    public void setApkUrl(String apkUrl) {
        this.apkUrl = apkUrl;
    }


    public String getPath() {
        return path;
    }


    public void setPath(String path) {
        this.path = path;
    }


    public int getCallbackProgressCount() {
        return callbackProgressCount;
    }


    public void setCallbackProgressCount(int callbackProgressCount) {
        this.callbackProgressCount = callbackProgressCount;
    }


    public int getMinIntervalUpdateSpeedMs() {
        return minIntervalUpdateSpeedMs;
    }


    public void setMinIntervalUpdateSpeedMs(int minIntervalUpdateSpeedMs) {
        this.minIntervalUpdateSpeedMs = minIntervalUpdateSpeedMs;
    }


    public int getTag() {
        return tag;
    }


    public void setTag(int tag) {
        this.tag = tag;
    }
}
