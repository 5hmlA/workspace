package com.a4399.funnycore.app.data.netservice.urlapi;

import com.a4399.funnycore.app.data.DataResult;
import com.a4399.funnycore.app.data.bean.ForumResponseData;
import com.a4399.funnycore.app.data.bean.UserBean;
import com.a4399.funnycore.app.data.bean.comment.CommentListEntity;
import com.a4399.funnycore.app.data.bean.comment.CommentResultEntity;
import com.a4399.funnycore.app.data.bean.AccountBean;

import java.util.Map;

import io.reactivex.Observable;
import okhttp3.MultipartBody;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.QueryMap;

/**
 * @another 江祖赟
 * @date 2017/6/27.
 */
public interface FunnyCoreApi {

    /**
     * 评论相关url
     */
    public static final String URL_COMMENT_DOMAIN = "http://comment.5054399.com/";

    interface CommentApi {
        /**
         * 评论主题
         */
        //        @FormUrlEncoded
        //        @POST("comment_ajax_app.php")
        //        Observable<CommentResultEntity> addCommentApi(@FieldMap Map<String, String> params);
        @GET("comment_ajax_app.php")
        Observable<CommentResultEntity> addCommentApi(@QueryMap Map<String,String> params);

        /**
         * 回复评论
         */
        @FormUrlEncoded
        @POST("comment_ajax_app.php")
        Observable<CommentResultEntity> replyCommnetApi(@FieldMap Map<String,String> params);

        /**
         * 获取评论列表
         */
        @GET("mnsjzs/{fidPath}/{fid}_{page}_js.html")
        Observable<CommentListEntity> getCommentList(
                @Path("fidPath") long fidPath, @Path("fid") String fid, @Path("page") long page);
    }

    /**
     * 社区接口
     */
    public static final class ForumPaths {
        //        public static final String URL_FORUM_DOMAIN = BuildConfig.URL_MY_DOMAIN;
        //        public static final String URL_BBS_DOMAIN = BuildConfig.URL_BBS_DOMAIN;
        //        public static final String URL_BBS = URL_BBS_DOMAIN + "/m/forums-mtag-82657";

        /**
         * 基础路径
         */
        public static final String FAPI = "fapi";

        /**
         * 刷新群组cookie
         */
        public static final String PATH_REFRESH_COOKIE = FAPI+"/user-refreshCookie";


        /**
         * 修改昵称
         */
        public static final String PATH_SAVE_NICK = FAPI+"/user-saveNick";
        /**
         * 头像上传
         */
        public static final String PATH_AVATAR_UPLOAD = FAPI+"/avatar-upload";


    }

    /**
     * 论坛相关api
     *
     * @author 徐智伟
     * @create 2017/2/24
     */

    public interface ForumApi {

        @FormUrlEncoded
        @POST(ForumPaths.PATH_REFRESH_COOKIE)
        Observable<ForumResponseData> refreshUserCookie(@FieldMap Map<String,String> params);

        /**
         * 修改头像
         */
        @POST(ForumPaths.PATH_AVATAR_UPLOAD)
        Observable<ForumResponseData> modifyAvatar(@Body MultipartBody params);

        @FormUrlEncoded
        @POST(ForumPaths.PATH_SAVE_NICK)
        Observable<ForumResponseData> modifyNickName(@FieldMap Map<String,String> params);
    }

    public interface IUser {
        /**
         * 用户登录/获取token
         *
         * @return
         */
        @GET("service/user/syncdata")
        Observable<DataResult<AccountBean>> login(@QueryMap Map<String,Object> parma);

        /**
         * 获取用户信息
         *
         * @param parma
         * @return
         */
        @GET("service/user/userinfo")
        Observable<DataResult<UserBean>> getUserInfo(
                @Header("Cookie") String Cookie, @QueryMap Map<String,Object> parma);
    }
}
