package com.a4399.funnycore.app.data.bean.home;

import com.a4399.funnycore.app.data.bean.download.GameDownloadTaskBean;
import com.a4399.funnycore.app.download.BaseDownloadBean;
import com.google.gson.annotations.SerializedName;

/**
 * 文件描述：
 * Created by zhanlinjian2888 on 2017/12/26.
 * E-mail:zhanlinjian@4399inc.com
 */

public class DownloadTaskListBean {

    @SerializedName("info") public GameDownloadTaskBean list;


    public GameDownloadTaskBean getList() {
        return list;
    }


    public void setList(GameDownloadTaskBean list) {
        this.list = list;
    }
}