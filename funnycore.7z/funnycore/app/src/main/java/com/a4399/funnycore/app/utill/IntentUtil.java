package com.a4399.funnycore.app.utill;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.a4399.funnycore.FcContents;
import com.a4399.funnycore.app.data.bean.home.GameDetailBean;
import com.a4399.funnycore.app.ui.person.PersonalHomePageActivity;
import com.a4399.funnycore.app.ui.message.MessageCenterActivity;
import com.a4399.funnycore.app.ui.message.MessageNewFansActivity;
import com.a4399.funnycore.app.ui.message.MessageReceivePraiseActivity;
import com.a4399.funnycore.app.ui.message.MessageReplyMeActivity;
import com.a4399.funnycore.app.ui.message.MessageSysNotificationActivity;
import com.a4399.funnycore.app.ui.person.download.DownloadManageActivity;
import com.a4399.funnycore.utils.ActivityUtil;

import java.io.Serializable;
import java.util.List;

/**
 * 文件描述：跳转
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public class IntentUtil {

    /**
     * 下载管理
     *
     * @param TabType {@link FcContents.DownloadManageType}
     */
    public static void openDownloadManage(View view, int TabType) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(FcContents.Extra.DOWNLOAD_MANAGE_DEF_TAB, TabType);
        ActivityUtil.readyGo(view, DownloadManageActivity.class, bundle);
    }


    /**
     * 下载管理
     *
     * @param updateAbleGameList 可更新的游戏
     * @param TabType {@link FcContents.DownloadManageType}
     */
    public static void openDownloadManage(View view, List<GameDetailBean> updateAbleGameList, int TabType) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(FcContents.Extra.DOWNLOAD_MANAGE_DEF_TAB, TabType);
        bundle.putSerializable(FcContents.Extra.ALL_UPDATEABLE_GAME_LIST, (Serializable) updateAbleGameList);
        ActivityUtil.readyGo(view, DownloadManageActivity.class, bundle);
    }


    /**
     * 打开消息中心页面
     */
    public static void openMessageCenterActivity(Activity activity) {
        ActivityUtil.readyGo(activity, MessageCenterActivity.class);
    }


    /**
     * 打开回复我的页面
     */
    public static void openMessageReplyMeActivity(View view) {
        ActivityUtil.readyGo(view, MessageReplyMeActivity.class);
    }


    /**
     * 打开新的粉丝页面
     */
    public static void openMessageNewFansActivity(View view) {
        ActivityUtil.readyGo(view, MessageNewFansActivity.class);
    }


    /**
     * 打开收到的赞页面
     */
    public static void openMessageReceivePraiseActivity(View view) {
        ActivityUtil.readyGo(view, MessageReceivePraiseActivity.class);
    }


    /**
     * 打开系统通知页面
     */
    public static void openMessageSysNotificationActivity(View view) {
        ActivityUtil.readyGo(view, MessageSysNotificationActivity.class);
    }


    /**
     * 打开个人主页
     */
    public static void openPersonalHomePage(View view, String userId) {
        Bundle bundle = new Bundle();
        bundle.putSerializable(FcContents.Extra.USER_ID, userId);
        ActivityUtil.readyGo(view, PersonalHomePageActivity.class, bundle);
    }
}
