package com.a4399.funnycore.app.ui.ranking;

import android.graphics.Color;
import android.os.Build;
import android.support.constraint.ConstraintLayout;
import april.yun.other.JTabStyleDelegate;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.ui.JBaseTabViewpagerFrgmt;
import com.a4399.funnycore.app.widget.CustomTabStyle;
import com.a4399.funnycore.base.TabAdapter;
import com.a4399.funnycore.utils.StatusBarHelper;

import static april.yun.widget.JToolbar.dp2px;
import static com.a4399.funnycore.JApp.findColor;

/**
 * 文件描述：动态首页
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */

public class RankingHomeFragment extends JBaseTabViewpagerFrgmt {

    @Override protected TabAdapter.BaseFrgmtFractory setFrgmtProvider() {
        return new TabAdapter.BaseFrgmtFractory() {
            @Override protected void initFrgment() {
                fmCache.put(0,new HomeRankFrgmt());
                fmCache.put(1,new HomeRankFrgmt());
                fmCache.put(2,new HomeRankFrgmt());
            }
        };
    }


    @Override public void onResume() {
        super.onResume();
        ConstraintLayout constraintLayout = getView().findViewById(R.id.rank_tab_constrain);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            constraintLayout.setPadding(0, StatusBarHelper.getStatusBarHeight(), 0, 0);
        }
    }


    @Override public int getBaseTabLayout() {
        return R.layout.fragment_home_rank_tab;
    }


    @Override protected String[] setTabTitles() {
        return getResources().getStringArray(R.array.home_rank_tab);
    }


    protected void initTabStrip() {

        JTabStyleDelegate tabStyleDelegate = mBaseTabStrip.getTabStyleDelegate();
        //        2，拿TabStyleDelegate
        //        3, 用TabStyleDelegate设置属性
        tabStyleDelegate.setShouldExpand(true)
                        //也可以直接传字符串的颜色，第一个颜色表示checked状态的颜色第二个表示normal状态
                        .setTextColor(findColor(R.color.black_2e33), findColor(R.color.gray_8b8b))
                        .setTabTextSize(dp2px(17))
                        .setUnderlineHeight(0)//底部横线的高度
                        .setIndicatorHeight(dp2px(3))
                        .setUnderlineHeight(0)
                        .setUnderlineColor(Color.TRANSPARENT)
                        .setIndicatorColor(findColor(R.color.tv_orign_ff88)).setUnderLineFixWidth(dp2px(25));
        reConfigTabStrip(tabStyleDelegate.setJTabStyle(new CustomTabStyle(mBaseTabStrip)));
    }
}
