package com.a4399.funnycore.app.ui.home.gamedetail;

import android.animation.ArgbEvaluator;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import april.yun.widget.JToolbar;
import com.a4399.funnycore.JApp;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.home.GameDetail;
import com.a4399.funnycore.app.viewmodel.home.gamedetail.GameDetailViewModel;
import com.a4399.funnycore.base.BaseListActivity;
import com.a4399.funnycore.databinding.ActivityGameDetailBinding;
import com.a4399.funnycore.utils.ToastUtil;
import java.util.HashMap;

public class GameDetailAct extends BaseListActivity<GameDetailViewModel> implements AppBarLayout.OnOffsetChangedListener {

    //"state":"状态：0-预约；1-正常",
    public static final int GAMESTATE_NORMAL=1;
    public static final int GAMESTATE_BOOKING=0;

    private TextView mTitleView;
    private AppBarLayout mAppbar;
    private View mTitleDiviceline;
    private int mVerticalOffset;
    private GameDetailTabFrgmt mGameDetailTabFrgmt;
    private ActivityGameDetailBinding mGameDetailBinding;
    private ImageView mLeftIcon;
    private ImageView mRigthtIcon;
    ArgbEvaluator argbEvaluator = new ArgbEvaluator();
    public static boolean showComment = false;
    public static String gameId;
    private int mDividiColor = JApp.findColor(R.color.divide_line_color);
    private int mIconColor = JApp.findColor(R.color.gray_8b8b);


    public static void startAct4View(View view, String id) {
        startAct4View(view, false, id);
    }

    public static void startAct(Activity activity, String id) {
        gameId = id;
        activity.startActivity(new Intent(activity, GameDetailAct.class));
    }


    public static void startAct4View(View view, boolean comment, String id) {
        gameId = id;
        showComment = comment;
        id = "0";
        if (!TextUtils.isEmpty(id)) {
            Context context = view.getContext();
            while (context instanceof ContextWrapper) {
                if (context instanceof Activity) {
                    Activity activity = ((Activity) context);
                    Intent intent = new Intent(activity, GameDetailAct.class);
                    //intent.putExtra(SEARCH_TYPE, search_type);
                    activity.startActivity(intent);
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
        }
        else {
            ToastUtil.showShort("游戏ID为空");
        }
    }


    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        super.onCreate(savedInstanceState);

    }


    @Override protected GameDetailViewModel initModel() {
        return new GameDetailViewModel();
    }


    @Override protected JToolbar initBinding() {
        mGameDetailBinding = DataBindingUtil.setContentView(this, R.layout.activity_game_detail);
        mGameDetailBinding.setGameDetailViewModel(viewModel);
        return mGameDetailBinding.toolbar;
    }


    @Override protected void initToolBar() {
        mLeftIcon = mToolbar.setLeftIcon(R.drawable.btn_back_38_white);
        (mRigthtIcon = mGameDetailBinding.rightShareIcon).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ToastUtil.showShort("分享");
            }
        });
        setTitle("游戏详情");
        super.initToolBar();
    }


    @Override protected void initViewAndData() {
        super.initViewAndData();
        mAppbar = mGameDetailBinding.appbar;
        mAppbar.addOnOffsetChangedListener(this);
        mTitleView = mGameDetailBinding.toolbar.setTitle2("游戏详情");
        mTitleView.setAlpha(0);
        mTitleDiviceline = mGameDetailBinding.titleDiviceline;
        mGameDetailTabFrgmt = new GameDetailTabFrgmt();
        getSupportFragmentManager().beginTransaction().replace(R.id.home_search_content, mGameDetailTabFrgmt).commitAllowingStateLoss();
        //getSupportFragmentManager().beginTransaction().replace(R.id.home_search_content, new CommentFrgmt()).commitAllowingStateLoss();
        if (showComment) {
            //默认显示 评论tab
            mGameDetailTabFrgmt.setCurrentItem(1);
        }
    }


    @Override protected HashMap putParam() {
        return new HashMap();
    }

    //appbarlayout滑动监听
    @Override public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        if (mVerticalOffset != verticalOffset) {
            mVerticalOffset = verticalOffset;
            float alpha = Math.abs(verticalOffset * 1f / appBarLayout.getTotalScrollRange());
            mTitleView.setAlpha(alpha);
            mTitleDiviceline.setBackgroundColor((Integer) argbEvaluator.evaluate(alpha, Color.TRANSPARENT,mDividiColor));
            int evaluate = (int) argbEvaluator.evaluate(alpha, Color.TRANSPARENT, mIconColor);
            mLeftIcon.setColorFilter(evaluate);
            mRigthtIcon.setColorFilter(evaluate);
        }
    }


    public GameDetailViewModel getViewModel() {
        return viewModel;
    }


    @Override protected void onDestroy() {
        super.onDestroy();
        mAppbar.removeOnOffsetChangedListener(this);
    }


    //预约有戏按钮//下载游戏 // 打开游戏
    public void toBookPlay(View view) {
        ToastUtil.showShort("游戏预约");
    }

    //查看游戏动态
    public void watchGameDynamic(View view) {
        ToastUtil.showShort("查看动态");
    }


    //关注/取消关注
    public void actLike(View view) {
        //view.isSelected();
        //view.setSelected();
        ToastUtil.showShort("关注操作");
    }


    public static interface getGameDataListener {
        void afterGetData(GameDetail gameDetail);
    }
}
