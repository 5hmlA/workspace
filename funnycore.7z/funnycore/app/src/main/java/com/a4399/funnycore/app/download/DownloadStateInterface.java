package com.a4399.funnycore.app.download;

import android.support.annotation.IntDef;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.a4399.funnycore.app.download.DownloadStateInterface.*;

/**
 * 文件描述：下载状态
 * Created by zhanlinjian2888 on 2017/12/20.
 * E-mail:zhanlinjian@4399inc.com
 */
@IntDef({ FREETIME, DOWNING, PAUSE, TRY_AGAIN, OPEN,UPDATE,WAIT,INSTALL }) @Retention(RetentionPolicy.SOURCE)
public @interface DownloadStateInterface {

    int FREETIME = 0; // 空闲状态
    int DOWNING = 1; // 下载中
    int PAUSE = 2; // 暂停
    int TRY_AGAIN = 3; // 重试
    int WAIT=6; // 等待
    int INSTALL=7; // 安裝
    int OPEN = 4; // 打开
    int UPDATE=5; // 更新
}
