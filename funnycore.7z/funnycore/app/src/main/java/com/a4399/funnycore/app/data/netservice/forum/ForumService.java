package com.a4399.funnycore.app.data.netservice.forum;


import com.a4399.funnycore.app.data.netservice.AccountManage;
import com.a4399.funnycore.app.data.netservice.ServiceFactory;
import com.a4399.funnycore.app.data.bean.ForumResponseData;
import com.a4399.funnycore.app.data.netservice.urlapi.FunnyCoreApi;

import io.reactivex.Observable;
import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Function;
import okhttp3.MultipartBody;

/**
 * 论坛相关service
 *
 * @author 徐智伟
 * @create 2017/2/24
 */

public class ForumService implements IForumService {

    private FunnyCoreApi.ForumApi api;

    public ForumService(){
        if(api == null) {
            api = ServiceFactory.createForumService();
        }
    }

    @Override
    public Observable<ForumResponseData> refreshUserCookie(String uid, String accessToken){
        return api.refreshUserCookie(ForumParams.getRefreshCookieParams(uid, accessToken));
    }

    @Override
    public Observable<ForumResponseData> modifyAvatar(String imagePath){
        return ForumParams.getModifyUserAvatar(getUserId(), imagePath)
                .flatMap(new Function<MultipartBody,Observable<ForumResponseData>>() {
                    @Override
                    public Observable<ForumResponseData> apply(@NonNull MultipartBody multipartBody) throws Exception{
                        return api.modifyAvatar(multipartBody);
                    }
                });
    }

    @Override
    public Observable<ForumResponseData> modifyNickName(String nickName){
        return api.modifyNickName(ForumParams.getModifyNickNameParams(getUserId(), nickName));
    }

    private String getUserId(){
        String uid = "0";
        if(AccountManage.getSingleton().isLogin()) {
            uid = AccountManage.getSingleton().getAccount().getUid();
        }
        return uid;
    }
}
