package com.a4399.funnycore.app.data.netservice.forum;

import com.a4399.funnycore.app.data.netservice.urlapi.FunnyCoreApi;
import com.a4399.funnycore.app.utill.compress.Luban;

import java.io.File;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import io.reactivex.Observable;
import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Function;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 2017/2/24
 */

public class ForumParams {
    private static final String TAG = "ChatGroupParams";

    public static final String APP_ID = "75";
    public static final String KEY = "您没有操作该接口的权限";

    public static final String PARAM_KEY_URI = "uri";
    private static final String LIMIT = "20";

    /**
     * 获取cookie参数
     */
    public static final Map<String,String> getRefreshCookieParams(String uid, String accessToken){
        Map<String,String> normalParams = new HashMap<>();
        normalParams.put("uid", uid);
        normalParams.put("access_token", accessToken);

        return addGeneralParam(normalParams, FunnyCoreApi.ForumPaths.PATH_REFRESH_COOKIE);
    }

    public static final Map<String,String> getModifyNickNameParams(String uid, String nick){
        Map<String,String> normalParams = new HashMap<>();
        normalParams.put("uid", uid);
        normalParams.put("nick", nick);

        return addGeneralParam(normalParams, FunnyCoreApi.ForumPaths.PATH_SAVE_NICK);
    }


    public static Observable<MultipartBody> getModifyUserAvatar(final String uid, final String imagePath){
        //先压缩后上传
        return Luban.get().load(new File(imagePath)).putGear(Luban.THIRD_GEAR).asObservable()
                .map(new Function<File,MultipartBody>() {
                    @Override
                    public MultipartBody apply(@NonNull File newImage) throws Exception{
                        //构建MultipartBody
                        MultipartBody.Builder builder = new MultipartBody.Builder();

                        //用户id进行编码
                        Map<String,String> map = new HashMap<>();
                        map.put("uid", uid);
                        map = addGeneralParam(map, FunnyCoreApi.ForumPaths.PATH_AVATAR_UPLOAD);

                        //添加其他参数
                        Iterator<Map.Entry<String,String>> it = map.entrySet().iterator();
                        while(it.hasNext()) {
                            Map.Entry<String,String> entry = it.next();
                            builder.addFormDataPart(entry.getKey(), entry.getValue());
                        }
                        RequestBody requestBody = RequestBody
                                .create(MediaType.parse(guessMimeType(newImage.getAbsolutePath())), newImage);
                        builder.addFormDataPart("avatar", newImage.getAbsolutePath(), requestBody);
                        builder.setType(MultipartBody.FORM);
                        MultipartBody multipartBody = builder.build();
                        return multipartBody;
                    }
                });
    }

    /**
     * 判断类型
     *
     * @param path
     *         根据路径判断文件类型
     */
    public static String guessMimeType(String path){
        FileNameMap fileNameMap = URLConnection.getFileNameMap();
        String contentTypeFor = fileNameMap.getContentTypeFor(path);
        if(contentTypeFor == null) {
            contentTypeFor = "application/octet-stream";
        }
        return contentTypeFor;
    }


    /**
     * 添加通用的接口参数
     *
     * @param param
     *         接口独立参数，非通用
     * @param uri
     *         uri每个接口对应的固定值
     */
    public static Map<String,String> addGeneralParam(Map<String,String> param, String uri){

        Map<String,String> params = new HashMap<>();
        params.putAll(param);

        //----添加通用参数----
        //时间戳，精确到秒
        params.put("time", getSecondStamp());
        params.put("app_id", APP_ID);
        //该参数在计算token接收后进行删除
        params.put(PARAM_KEY_URI, uri);
        params.remove(PARAM_KEY_URI);

        return params;
    }

    /**
     * h获取时间戳，精确到秒
     */
    public static String getSecondStamp(){
        Date date = new Date();
        long secondStamp = date.getTime()/1000;
        return String.valueOf(secondStamp);
    }

}
