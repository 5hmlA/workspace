package com.a4399.funnycore.app.data.netservice;

import com.a4399.funnycore.BuildConfig;
import com.a4399.funnycore.JApp;
import com.a4399.funnycore.app.data.bean.AccountBean;
import com.a4399.funnycore.app.data.netservice.forum.StringConverterFactory;
import com.a4399.funnycore.app.data.netservice.forum.ForumService;
import com.a4399.funnycore.app.data.netservice.urlapi.FunnyCoreApi;
import com.a4399.funnycore.app.utill.CookieUtils;
import com.a4399.funnycore.app.utill.SharedPrefsCookiePersistor;
import com.a4399.funnycore.utils.LogUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.readystatesoftware.chuck.ChuckInterceptor;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.a4399.funnycore.Constants.AboutHead.HTTP_HEADER_COOKIE;
import static com.a4399.funnycore.app.data.netservice.urlapi.FunnyCoreApi.URL_COMMENT_DOMAIN;

/**
 * @another 江祖赟
 * @date 2017/7/19.
 */
public class ServiceFactory {
    private static final String TAG = "ServiceFactory";
    private static final int HTTP_READ_TIME = 15;
    private final Gson mGson;
    private OkHttpClient mOkHttpClient;

    private ServiceFactory(){
        mGson = new GsonBuilder().setDateFormat("yyyy-MM-dd hh:mm:ss").create();
        mOkHttpClient = OkhttpProvider.getDefaultOkHttpClient();
    }

    public static ForumService getForumService(){
        return new ForumService();
    }

    private static class SingletonHolder {
        private static final ServiceFactory INSTANCE = new ServiceFactory();
    }

    public static ServiceFactory getInstance(){
        return SingletonHolder.INSTANCE;
    }

    public <S> S createService(Class<S> serviceClass){
        Retrofit retrofit = new Retrofit.Builder().baseUrl(BuildConfig.APP_BASE_URL).client(mOkHttpClient)
                .addConverterFactory(GsonConverterFactory.create(mGson))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create()).build();
        return retrofit.create(serviceClass);
    }

    public FunnyCoreApi.CommentApi createCommonService(){
        Retrofit retrofit = new Retrofit.Builder().baseUrl(URL_COMMENT_DOMAIN).client(mOkHttpClient)
                .addConverterFactory(GsonConverterFactory.create(mGson))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create()).build();
        return retrofit.create(FunnyCoreApi.CommentApi.class);
    }

    /**
     * 论坛service
     */
    public static FunnyCoreApi.ForumApi createForumService(){
        OkHttpClient.Builder builder = new OkHttpClient.Builder().connectTimeout(HTTP_READ_TIME, TimeUnit.SECONDS)
                .readTimeout(HTTP_READ_TIME, TimeUnit.SECONDS).addInterceptor(new AddForumCookieInterceptor())
                .addInterceptor(new ReceiverForumHeaderInterceptor());
        if(BuildConfig.DEBUG) {
            builder.addInterceptor(new OkhttpProvider.LoggingInterceptor());
            builder.addInterceptor(new ChuckInterceptor(JApp.getContext()));
        }
        OkHttpClient okHttpClient = builder.build();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(BuildConfig.MY_BASE_URL).client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create()).addConverterFactory(
                        StringConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create()).build();
        return retrofit.create(FunnyCoreApi.ForumApi.class);
    }

    /**
     * 描述信息
     *
     * @author 徐智伟
     * @create 16/4/11
     */
    public static class AddForumCookieInterceptor implements Interceptor {
        public static final String TAG = "AddForumCookieInterceptor";

        @Override
        public Response intercept(Chain chain) throws IOException{
            Request.Builder builder = chain.request().newBuilder();
            if(AccountManage.getSingleton().isLogin()) {
                AccountBean userInfoEntitiy = AccountManage.getSingleton().getAccount();
                //设置cookie
                builder.addHeader(HTTP_HEADER_COOKIE, userInfoEntitiy.buildCookie());
            }
            SharedPrefsCookiePersistor prefsCookiePersistor2 = new SharedPrefsCookiePersistor();
            HashSet<String> preferences = (HashSet)prefsCookiePersistor2.loadAll();
            for(String cookie : preferences) {
                builder.addHeader("Cookie", cookie);
                LogUtil.debug(TAG,
                        "Adding Header: "+cookie); // This is done so I know which headers are being added; this interceptor is used after the normal logging of OkHttp
            }
            return chain.proceed(builder.build());
        }
    }


    /**
     * 描述信息
     *
     * @author 徐智伟
     * @create 16/10/21
     */

    public static class ReceiverForumHeaderInterceptor implements Interceptor {

        public static final String TAG = "ReceiverForumHeaderInterceptor";
        private static final String SET_COOKIE = "Set-Cookie";

        @Override
        public Response intercept(Chain chain) throws IOException{
            Response originalResponse = chain.proceed(chain.request());
            List<String> headers = originalResponse.headers(SET_COOKIE);
            LogUtil.debug(TAG, headers.toString());
            if(!headers.isEmpty()) {

                final HashSet<String> cookies = new HashSet<>();
                for(String header : headers) {
                    if(header.contains("Pnick=")) {
                        continue;
                    }
                    cookies.add(header);
                }

                CookieUtils.syncForumCookieFromHeader(cookies);
                if(!cookies.isEmpty()) {
                    SharedPrefsCookiePersistor prefsCookiePersistor = new SharedPrefsCookiePersistor();
                    prefsCookiePersistor.clear();
                    prefsCookiePersistor.saveAll(cookies);
                }
            }
            return originalResponse;
        }

    }
}
