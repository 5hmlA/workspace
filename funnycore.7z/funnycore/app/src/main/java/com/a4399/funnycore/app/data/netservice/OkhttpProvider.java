package com.a4399.funnycore.app.data.netservice;

import android.os.Build;

import com.a4399.funnycore.BuildConfig;
import com.a4399.funnycore.JApp;
import com.a4399.funnycore.app.data.bean.AccountBean;
import com.a4399.funnycore.app.utill.AppConfig;
import com.a4399.funnycore.utils.DeviceUtil;
import com.a4399.funnycore.utils.LogUtil;
import com.a4399.funnycore.utils.NetUtil;
import com.readystatesoftware.chuck.ChuckInterceptor;

import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.CacheControl;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static com.a4399.funnycore.BuildConfig.FLAVOR;
import static com.a4399.funnycore.Constants.AboutHead.HTTP_HEADER_CHANNNEL;
import static com.a4399.funnycore.Constants.AboutHead.HTTP_HEADER_COOKIE;
import static com.a4399.funnycore.Constants.AboutHead.HTTP_HEADER_DEVICE;
import static com.a4399.funnycore.Constants.AboutHead.HTTP_HEADER_DEVICE_IP;
import static com.a4399.funnycore.Constants.AboutHead.HTTP_HEADER_DEVICE_NAME;
import static com.a4399.funnycore.Constants.AboutHead.HTTP_HEADER_DEVICE_TYPE;
import static com.a4399.funnycore.Constants.AboutHead.HTTP_HEADER_USER_AGENT;

/**
 * @another 江祖赟
 * @date 2017/7/19.
 */
public class OkhttpProvider {
    private final static long DEFAULT_CONNECT_TIMEOUT = 5;
    private final static long DEFAULT_WRITE_TIMEOUT = 20;
    private final static long DEFAULT_READ_TIMEOUT = 10;
    private static final String OKHTTPCACHE = "OkHttpCache";


    public static OkHttpClient getDefaultOkHttpClient(){
        return getOkHttpClient(new CacheControlInterceptor());
    }

    private static OkHttpClient getOkHttpClient(Interceptor cacheControl){
        //定制OkHttp
        OkHttpClient.Builder httpClientBuilder = new OkHttpClient.Builder();
        //设置超时时间
        httpClientBuilder.connectTimeout(DEFAULT_CONNECT_TIMEOUT, TimeUnit.SECONDS);
        httpClientBuilder.writeTimeout(DEFAULT_WRITE_TIMEOUT, TimeUnit.SECONDS);
        httpClientBuilder.retryOnConnectionFailure(true);
        httpClientBuilder.readTimeout(DEFAULT_READ_TIMEOUT, TimeUnit.SECONDS);
        //设置拦截器
        httpClientBuilder.addInterceptor(new HeadsInterceptor());

        //        注意：addInterceptor和addNetworkInterceptor 需要同时设置。
        // 如果 只是想实现在线缓存，那么可以只添加网络拦截器，如果只想实现离线缓存，可以使用只添加应用拦截器。
        if(BuildConfig.DEBUG || "internal_dev".equals(FLAVOR)) {
            httpClientBuilder.addInterceptor(new LoggingInterceptor());
            httpClientBuilder.addInterceptor(new ChuckInterceptor(JApp.getContext()));
        }

        //        httpClientBuilder.addInterceptor(cacheControl);
        //        httpClientBuilder.addNetworkInterceptor(cacheControl);
        //设置缓存
        return httpClientBuilder.build();
    }

    /**
     * 没有网络的情况下就从缓存中取
     * 有网络的情况则从网络获取
     */
    private static class CacheControlInterceptor implements Interceptor {

        @Override
        public Response intercept(Chain chain) throws IOException{

            Request request = chain.request();
            if(!NetUtil.isNetworkAvailable(JApp.getContext())) {//没有网络时设置强制读取缓存
                request = request.newBuilder().cacheControl(CacheControl.FORCE_CACHE).build();
            }
            Response response = chain.proceed(request);
            if(NetUtil.isNetworkAvailable(JApp.getContext())) {
                int maxAge = 60;//在有网络连接的情况下，一分钟内不再请求网络
                //接口处可自定义 @Headers("Cache-Control: public, max-age=5")

                String cacheControl = request.cacheControl().toString();
                //                if(TextUtils.isEmpty(cacheControl)) {
                cacheControl = "public, max-age="+maxAge;
                //                }
                response = response.newBuilder().removeHeader("Pragma").header("Cache-Control", cacheControl).build();
            }else {
                /** 设置max-age为5分钟之后，这5分钟之内不管有没有网, 都读缓存。
                 * max-stale设置为5天，意思是，网络未连接的情况下设置缓存时间为1天 */
                int maxStale = 60*60*24*30;
                response = response.newBuilder().removeHeader("Pragma").addHeader("Content-Type", "application/json")
                        .header("Cache-Control", "public, max-stale="+maxStale).build();
            }
            return response;
        }
    }

    /**
     * 没有网络的情况下就从缓存中取
     * 有网络的情况则从网络获取
     */
    private static class HeadsInterceptor implements Interceptor {

        @Override
        public Response intercept(Chain chain) throws IOException{
            Request oldRequest = chain.request();
            //( 例：Cookie : auth=31732cf090dc177ba4b9f7b22f718c49;authExpire=1449740001;userId=2413222778 )
            //获取当前存在的header
            Headers.Builder headerBuilder = new Headers.Builder();
            AccountBean userInfoEntitiy = AccountManage.getSingleton().getAccount();
            if(userInfoEntitiy != null) {
                //设置cookie
                headerBuilder.set(HTTP_HEADER_COOKIE, userInfoEntitiy.buildCookie());
                //                LogHelper.Log_d("=============cookie ！"+userInfoEntitiy.buildCookie());
                //                CookieUtils.syncForumCookieFromHeader();
            }
            //            headerBuilder.set(COOKIE_KEY_AUTH_USERID, userInfoEntitiy.getUid());
            headerBuilder.set(HTTP_HEADER_USER_AGENT, AppConfig.Http.getAppUserAgentWithDeviceInfo());
            headerBuilder.set(HTTP_HEADER_DEVICE, DeviceUtil.getDeviceID(JApp.getContext()));
            headerBuilder.set(HTTP_HEADER_DEVICE_NAME, DeviceUtil.getDiviceName());
            headerBuilder.set(HTTP_HEADER_DEVICE_TYPE, Build.MODEL);
            headerBuilder.set(HTTP_HEADER_DEVICE_IP, AppConfig.getDeviceIP());
            headerBuilder.set(HTTP_HEADER_CHANNNEL, JApp.getCurrentChannel());
            headerBuilder.set("Accept", "application/json");
            headerBuilder.set("Content-Type", "application/json");
            //构建新的request
            Request newRequest = oldRequest.newBuilder().headers(headerBuilder.build()).build();
            Response response = chain.proceed(newRequest);
            return response;
        }
    }

    /**
     * 强制从网络获取数据
     */
    private static class FromNetWorkControlInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException{
            Request request = chain.request();
            request = request.newBuilder().cacheControl(CacheControl.FORCE_CACHE).build();
            return chain.proceed(request);
        }
    }

    /**
     * 强制从本地获取数据
     */
    private static class FromCacheInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException{
            Request request = chain.request();
            request = request.newBuilder().cacheControl(CacheControl.FORCE_NETWORK).build();
            return chain.proceed(request);
        }
    }

    public static class LoggingInterceptor implements Interceptor {

        @Override
        public Response intercept(Chain chain) throws IOException{

            Request request = chain.request();
            LogUtil.debug("",String
                    .format("Sending request %s on %s%n%s", request.url(), chain.connection(), request.headers()));

            long t1 = System.nanoTime();
            Response response = chain.proceed(chain.request());
            long t2 = System.nanoTime();
            LogUtil.debug("",String
                    .format(Locale.getDefault(), "Received response for %s in %.1fms%n%s", response.request().url(),
                            ( t2-t1 )/1e6d, response.headers()));

            okhttp3.MediaType mediaType = response.body().contentType();
            String content = response.body().string();
            return response.newBuilder().body(okhttp3.ResponseBody.create(mediaType, content)).build();
        }
    }
}
