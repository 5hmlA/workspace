package com.a4399.funnycore.example;

import com.a4399.funnycore.base.BaseActivity;
import com.a4399.funnycore.mvvmdemo.TestViewModel;

/**
 * 文件描述：示例activity
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */

public class ExampleActivity extends BaseActivity<TestViewModel> {

    @Override protected void initViewAndData() {

    }


    @Override protected boolean isBindRxBus() {
        return false;
    }


    @Override protected void initRxBus() {

    }


    @Override protected void initToolBar() {
        // ================= 重写setTitle方法可设置标题的文本 ================= //
        setTitle("test");
    }


    @Override protected TestViewModel initModel() {
        return new TestViewModel();
    }


    @Override protected void initBinding() {
        // 对于activity类型，bindning模板：
        // ActivityExampleBin
    }
}
