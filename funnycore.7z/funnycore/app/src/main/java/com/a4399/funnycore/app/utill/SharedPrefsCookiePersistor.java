package com.a4399.funnycore.app.utill;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 16/10/21
 */

import android.content.Context;
import android.content.SharedPreferences;

import com.a4399.funnycore.JApp;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;

import okhttp3.Cookie;

public class SharedPrefsCookiePersistor {

  private SharedPreferences sharedPreferences;

  public SharedPrefsCookiePersistor() {
    final String SHARED_PREFERENCES_NAME = "CookiePersistence";

    sharedPreferences =
        JApp.getContext().getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE);
  }

  public HashSet<String> loadAll() {
    HashSet<String> cookies = new HashSet<>();

    for (Map.Entry<String, ?> entry : sharedPreferences.getAll().entrySet()) {

      String serializedCookie = (String) entry.getValue();

      cookies.add(serializedCookie);
    }

    return cookies;
  }

  public void saveAll(Collection<String> cookies) {
    SharedPreferences.Editor editor = sharedPreferences.edit();

    for (String cookie : cookies) {
      editor.putString(CryptoUtils.HASH.md5(cookie), cookie);
    }

    editor.apply();

  }

  public void clear() {
    SharedPreferences.Editor editor = sharedPreferences.edit();
    editor.clear();
    editor.commit();
  }

  private static String createCookieKey(Cookie cookie) {
    return (cookie.secure() ? "https" : "http") + "://" + cookie.domain();
  }

}