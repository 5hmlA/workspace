package com.a4399.funnycore.app.bindingadapter;

import android.databinding.BindingAdapter;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.View;
import android.widget.TextView;
import com.a4399.funnycore.JApp;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.home.GameInfo;
import com.a4399.funnycore.app.data.bean.home.Home;
import com.a4399.funnycore.utils.BindingReusePagerAdapter;
import com.a4399.funnycore.utils.CheckHelper;
import com.a4399.funnycore.widget.JFlowLayout;
import com.a4399.funnycore.widget.JRatingBar;
import com.a4399.funnycore.widget.LoopMZViewPager;
import easybind.jzy.bindingstar.ScrollChildSwipeRefreshLayout;
import easybind.jzy.bindingstar.statehelper.BaseStateViewModel;
import java.util.List;

import static april.yun.widget.JToolbar.dp2px;
import static com.a4399.funnycore.app.ui.home.gamedetail.GameDetailAct.GAMESTATE_NORMAL;

/**
 * @another 江祖赟
 * @date 2017/12/25.
 */
public class ViewPagerBindingAdapter {

    @BindingAdapter(value = { "loopItems" }, requireAll = false)
    public static void configJViewpager(LoopMZViewPager viewPager, List<? extends BindingReusePagerAdapter.JVpItem> items) {
        if (items != null && items.size() > 0) {
            viewPager.setItems(items);
        }
    }


    @BindingAdapter("padinglb") public static void padingLB(View view, float pading) {
        view.setPadding(Math.round(pading), view.getPaddingTop(), view.getPaddingRight(), Math.round(pading));
    }


    @BindingAdapter("padingrb") public static void padingRB(View view, float pading) {
        view.setPadding(view.getPaddingLeft(), view.getPaddingTop(), Math.round(pading), Math.round(pading));
    }


    @BindingAdapter("padingltr") public static void setPadingltr(View view, float newPadding) {
        view.setPadding(Math.round(newPadding), Math.round(newPadding), Math.round(newPadding), view.getPaddingBottom());
    }


    /**
     * Reloads the data when the pull-to-refresh is triggered.
     * Creates the {@code android:onRefresh} for a {@link SwipeRefreshLayout}.
     */
    @BindingAdapter("onRefresh2") public static void setOnRefreshListener(final ScrollChildSwipeRefreshLayout view, final BaseStateViewModel viewModel) {
        view.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override public void onRefresh() {
                viewModel.onRefresh(view);
            }
        });
    }


    @BindingAdapter("select") public static void setSelect(View view, boolean isSelected) {
        view.setSelected(isSelected);
    }


    @BindingAdapter("levelbg") public static void setLevelBg(TextView view, int level) {
        if (level > 20) {
            view.setBackgroundResource(R.drawable.bg_red_round_2);
            view.setText(JApp.findString(R.string.common_user_level, level));
        }
        else if (level > 10) {
            view.setBackgroundResource(R.drawable.bg_orign_round_2);
            view.setText(JApp.findString(R.string.common_user_level, level));
        }
        else {
            view.setBackgroundResource(R.drawable.bg_blue_round_2);
            view.setText(JApp.findString(R.string.common_user_level_, level));
        }
    }


    //更多的发现游戏中 按钮的状态 我要玩/去预约/已预约
    @BindingAdapter("gameBookstate") public static void configGameBookState(TextView tv, Home.FindGameBean findGameBean) {
        if (findGameBean.state == GAMESTATE_NORMAL) {
            //游戏可玩状态
            tv.setSelected(true);
            tv.setEnabled(true);
        }
        else if (findGameBean.isBook) {
            tv.setEnabled(false);
            tv.setSelected(false);
        }
        tv.setText(findGameBean.getBookState());
    }


    //游戏详情中 底部按钮状态 下载 预约中/已预约
    @BindingAdapter("gameInfostate") public static void configGameInfoState(TextView tv, GameInfo gameInfo) {
        if (gameInfo != null) {
            if (gameInfo.state == GAMESTATE_NORMAL) {
                //下载游戏
                tv.setSelected(true);
                tv.setEnabled(true);
            }
            else if (gameInfo.isBook) {
                tv.setSelected(false);
                //已预约
                tv.setEnabled(false);
            }
            tv.setText(gameInfo.getGameState());
        }
    }


    //福利中心 福利状态，废除 【需求一直显示去领取】
    @BindingAdapter("wealfareState") public static void configWealfareState(TextView tv, boolean isObtain) {
        if (isObtain) {
            tv.setText("已领取");
            tv.setSelected(true);
        }
        else {
            tv.setText("去领取");
            tv.setSelected(false);
        }
    }


    //游戏详情中 游戏的关注状态
    @BindingAdapter("gameAttention") public static void setGameAttention(TextView view, boolean isFollow) {
        if (isFollow) {
            //已关注
            view.setText(JApp.findString(R.string.game_detail_attention_ed));
        }
        else {
            //没关注
            view.setText(JApp.findString(R.string.game_detail_attention));
        }
        view.setSelected(isFollow);
    }

    //标签
    @BindingAdapter(value = { "keyList", "selectListener" }, requireAll = false)
    public static void setKeylist(JFlowLayout flowLayout, List<String> keys, JFlowLayout.OnItemSelectedListener selectedListener) {
        if (CheckHelper.checkLists(keys)) {
            flowLayout.removeAllViews();
            flowLayout.setVisibility(View.VISIBLE);
            flowLayout.setHorizontalSpacing(dp2px(9))
                      .setVerticalSpacing(dp2px(9))
                      .setTextSize(13)
                      .setItemTvColor(JApp.findColor(R.color.gray_8b8b))
                      .setItemBackgroundResource(R.drawable.common_bg_flowitem);
            flowLayout.setOnItemSelectedListener(selectedListener);
            flowLayout.addContents(keys);
        }
        else {
            flowLayout.setVisibility(View.GONE);
        }
    }

    //标签
    @BindingAdapter(value = { "rankkeyList", "rankSelectListener" }, requireAll = false)
    public static void setRankKeylist(JFlowLayout flowLayout, List<String> keys, JFlowLayout.OnItemSelectedListener selectedListener) {
        if (CheckHelper.checkLists(keys)) {
            flowLayout.removeAllViews();
            flowLayout.setVisibility(View.VISIBLE);
            flowLayout.setHorizontalSpacing(dp2px(9))
                      .setVerticalSpacing(dp2px(9))
                      .setTextSize(11)
                      .setItemTvColor(JApp.findColor(R.color.gray_8b8b))
                      .setItemBackgroundResource(R.drawable.rank_bg_flowitem);
            flowLayout.setOnItemSelectedListener(selectedListener);
            flowLayout.addContents(keys);
        }
        else {
            flowLayout.setVisibility(View.GONE);
        }
    }



    //标签
    @BindingAdapter("rbProgress")
    public static void setRatingbarProgress(JRatingBar jRatingBar, float rating) {
        jRatingBar.setRating(rating);
    }


}
