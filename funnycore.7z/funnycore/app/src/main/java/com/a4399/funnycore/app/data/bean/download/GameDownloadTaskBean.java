package com.a4399.funnycore.app.data.bean.download;

import com.a4399.funnycore.app.data.bean.home.GameDetailBean;
import com.a4399.funnycore.app.data.database.DbFlowManager;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;

/**
 * 文件描述：游戏下载任务管理
 * Created by zhanlinjian2888 on 2017/12/26.
 * E-mail:zhanlinjian@4399inc.com
 */
@Table(database = DbFlowManager.class)
public class GameDownloadTaskBean extends GameDetailBean {

    // id,有addTask时手动生成
    @PrimaryKey(autoincrement = true)
    public long taskId;

    public long getTaskId() {
        return taskId;
    }


    public void setTaskId(long taskId) {
        this.taskId = taskId;
    }
}
