package com.a4399.funnycore.app.data.bean;

import com.a4399.funnycore.app.data.database.DbFlowManager;
import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import static com.a4399.funnycore.Constants.AboutHead.COOKIE_KEY_AUTH;
import static com.a4399.funnycore.Constants.AboutHead.COOKIE_KEY_AUTH_EXPIRE;
import static com.a4399.funnycore.Constants.AboutHead.COOKIE_KEY_AUTH_USERID;
import static com.a4399.funnycore.Constants.AboutHead.EQUAL;
import static com.a4399.funnycore.Constants.AboutHead.SEMICOLON;

/**
 * @another 江祖赟
 * @date 2017/6/30.
 */
@Table(database = DbFlowManager.class) public class AccountBean extends BaseModel {

    /**
     * refreshtoken : refreshtoken
     * ad_token : 服务端生成的token
     * ad_expired : 服务端生成的token过期时间
     * uid : uid
     * nickname : 用户名称
     * access_token : access_token
     * qq : qq
     */
    @Column public String refreshtoken;
    @Column public String ad_token;
    @Column public String ad_expired;
    @Column public String uid;
    @PrimaryKey(autoincrement = true) public long id;
    @Column public String nickname;
    @Column public String access_token;
    @Column public String qq;
    //4399游戏盒子提供
    @Column public String authCode;
    @Column public String mCookies;


    public String getRefreshtoken() {
        return refreshtoken;
    }


    public void setRefreshtoken(String refreshtoken) {
        this.refreshtoken = refreshtoken;
    }


    public String getAd_token() {
        return ad_token;
    }


    public void setAd_token(String ad_token) {
        this.ad_token = ad_token;
    }


    public String getAd_expired() {
        return ad_expired;
    }


    public void setAd_expired(String ad_expired) {
        this.ad_expired = ad_expired;
    }


    public String getUid() {
        return uid;
    }


    public void setUid(String uid) {
        this.uid = uid;
    }


    public String getNickname() {
        return nickname;
    }


    public void setNickname(String nickname) {
        this.nickname = nickname;
    }


    public String getAccess_token() {
        return access_token;
    }


    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }


    public String getQq() {
        return qq;
    }


    public void setQq(String qq) {
        this.qq = qq;
    }


    public String getAuthCode() {
        return authCode;
    }


    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }


    public String buildCookie() {
        StringBuilder builder = new StringBuilder();
        builder.append(COOKIE_KEY_AUTH)
               .append(EQUAL)
               .append(ad_token)
               .append(SEMICOLON)
               .append(COOKIE_KEY_AUTH_EXPIRE)
               .append(EQUAL)
               .append(ad_expired)
               .append(SEMICOLON)
               .append(COOKIE_KEY_AUTH_USERID)
               .append(EQUAL)
               .append(uid);
        //        return builder.toString();
        return mCookies = builder.toString();
    }
}
