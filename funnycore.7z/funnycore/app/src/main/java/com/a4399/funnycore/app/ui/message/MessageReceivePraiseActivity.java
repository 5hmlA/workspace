package com.a4399.funnycore.app.ui.message;

import android.databinding.DataBindingUtil;
import android.view.View;

import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.message.MessageReceivePraiseViewModel;
import com.a4399.funnycore.base.BaseListActivity;
import com.a4399.funnycore.databinding.ActivityMessageReceivePraiseBinding;
import com.a4399.funnycore.utils.ResUtil;

import java.util.HashMap;

/**
 * 描述:消息之收到的赞Activity
 *
 * @author 罗远回
 * @since 2018年01月08日 16:45
 */

public class MessageReceivePraiseActivity extends BaseListActivity<MessageReceivePraiseViewModel> {


  @Override
  protected MessageReceivePraiseViewModel initModel() {
    return new MessageReceivePraiseViewModel();
  }

  @Override
  protected View initBinding() {
    ActivityMessageReceivePraiseBinding messageReceivePraiseBinding =
        DataBindingUtil.setContentView(this, R.layout.activity_message_receive_praise);
    messageReceivePraiseBinding.setMrpfviewmodel(viewModel);
    return messageReceivePraiseBinding.toolbar;
  }

  @Override
  protected HashMap putParam() {
    return new HashMap();
  }

  @Override
  protected void initToolBar() {
    super.initToolBar();
    mToolbar.setTitle(ResUtil.getString(R.string.receive_praise));
  }
}
