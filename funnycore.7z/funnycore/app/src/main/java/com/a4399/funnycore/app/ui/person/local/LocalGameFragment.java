package com.a4399.funnycore.app.ui.person.local;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.person.local.LocalGameViewModel;
import com.a4399.funnycore.base.BaseListFragment;
import com.a4399.funnycore.databinding.FragmentLocalGameBinding;

/**
 * 文件描述：本机游戏页面
 * Created by zhanlinjian2888 on 2017/12/28.
 * E-mail:zhanlinjian@4399inc.com
 */

public class LocalGameFragment extends BaseListFragment<LocalGameViewModel> {


    @Override protected LocalGameViewModel initModel() {
        return new LocalGameViewModel();
    }


    @Override protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        FragmentLocalGameBinding fragmentLocalGameBinding = DataBindingUtil.inflate(inflater,
                R.layout.fragment_local_game, container, false);
        fragmentLocalGameBinding.setLocalGameViewModel(viewModel);
        return fragmentLocalGameBinding;
    }


    @Override protected void initViewAndData() {

    }


}
