package com.a4399.funnycore.app.ui.home.search;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.databinding.Observable;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import com.a4399.funnycore.R;
import com.a4399.funnycore.base.BaseActivity;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.databinding.ActivityHomeSearchBinding;
import com.jakewharton.rxbinding2.widget.RxTextView;
import com.jakewharton.rxbinding2.widget.TextViewAfterTextChangeEvent;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import java.util.concurrent.TimeUnit;
import jonas.jlayout.MultiStateLayout;
import jonas.jlayout.OnStateClickListener;

import static android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_CLOSE;
import static android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_OPEN;

public class HomeSearchAct extends BaseActivity implements OnStateClickListener {

    //热词界面选中的 搜索关键字 用于触发搜索
    public ObservableField<String> selectedStr = new ObservableField<>();
    //当前搜索的关键字
    public ObservableField<String> currentSearchKey = new ObservableField<>();
    /**
     * 页面状态
     */
    public ObservableInt layoutState = new ObservableInt();
    private EditText mSearchKeyView;
    private ImageView mSearchClear;
    private FragmentTransaction mFragmentTransaction;
    private HomeSearchTabFrgmt mHomeSearchTabFrgmt;
    private HomeSearchHotHisFrgmt mHomeSearchHotHisFrgmt;
    //由热词页面处罚的搜索
    private boolean isFromHotPannel;
    public MultiStateLayout mHomeSearchStatelayout;


    public static void startAct(Activity activity) {
        Intent intent = new Intent(activity, HomeSearchAct.class);
        activity.startActivity(intent);
    }


    @Override protected BaseViewModel initModel() {
        //热词/本地记录 点击触发的搜索
        selectedStr.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override public void onPropertyChanged(Observable observable, int i) {
                String text = selectedStr.get();
                if (text != null && mSearchKeyView != null && !text.equals(mSearchKeyView.getText())) {
                    isFromHotPannel = true;
                    mSearchKeyView.setText(text);
                    mSearchKeyView.setSelection(text.length());
                    //来自 热词页面 触发发的关键字 直接显示搜索结果
                    toSearchTabView();
                    currentSearchKey.set(text);
                }
            }
        });
        layoutState.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override public void onPropertyChanged(Observable observable, int i) {
                if (mHomeSearchStatelayout != null) {
                    mHomeSearchStatelayout.showStateLayout(layoutState.get());
                }
            }
        });
        return null;
    }


    @Override protected void initBinding() {
        ActivityHomeSearchBinding homeSearchBinding = DataBindingUtil.setContentView(this, R.layout.activity_home_search);
        mHomeSearchStatelayout = homeSearchBinding.homeSearchStatelayout;
        mHomeSearchStatelayout.setOnStateClickListener(this);
        mSearchClear = homeSearchBinding.searchClear;
        mSearchKeyView = homeSearchBinding.searchEtKey;
        RxTextView.afterTextChangeEvents(mSearchKeyView)
                  .debounce(300, TimeUnit.MILLISECONDS)
                  .observeOn(AndroidSchedulers.mainThread())
                  .filter(new Predicate<TextViewAfterTextChangeEvent>() {
                      @Override public boolean test(TextViewAfterTextChangeEvent textViewAfterTextChangeEvent) throws Exception {
                          if (TextUtils.isEmpty(textViewAfterTextChangeEvent.editable())) {
                              if (mSearchClear.getVisibility() == View.VISIBLE) {
                                  mSearchClear.setVisibility(View.GONE);
                                  searchClear(null);
                              }
                              return false;
                          }
                          else {
                              mSearchClear.setVisibility(View.VISIBLE);
                              if (isFromHotPannel) {
                                  //来自 历史热词界面的点击搜索 直接发起搜索
                                  isFromHotPannel = false;
                                  return false;
                              }
                              else {
                                  return true;
                              }
                          }
                      }
                  })
                  .subscribe(new Consumer<TextViewAfterTextChangeEvent>() {
                      @Override public void accept(TextViewAfterTextChangeEvent textViewAfterTextChangeEvent) throws Exception {
                          toSearchTabView();
                          String key = textViewAfterTextChangeEvent.editable().toString();
                          currentSearchKey.set(key);
                          //selectedStr.set(textViewAfterTextChangeEvent.editable().toString());
                      }
                  });
    }


    @Override protected void initViewAndData() {
        toLocalSearchHisView();
    }


    private void toSearchTabView() {
        hideSystemInputPannel();
        mFragmentTransaction = getSupportFragmentManager().beginTransaction();
        mFragmentTransaction.setTransition(TRANSIT_FRAGMENT_CLOSE);
        mFragmentTransaction.hide(mHomeSearchHotHisFrgmt);//一定先显示本地历史页面
        if (mHomeSearchTabFrgmt == null) {
            mFragmentTransaction.add(R.id.home_search_content, mHomeSearchTabFrgmt = new HomeSearchTabFrgmt()).commitAllowingStateLoss();
        }
        else {
            mFragmentTransaction.show(mHomeSearchTabFrgmt).commitAllowingStateLoss();
        }
    }


    private void toLocalSearchHisView() {
        mFragmentTransaction = getSupportFragmentManager().beginTransaction();
        if (mHomeSearchHotHisFrgmt == null) {
            //第一次显示 一定没搜索tab界面
            mFragmentTransaction.add(R.id.home_search_content, mHomeSearchHotHisFrgmt = new HomeSearchHotHisFrgmt()).commitAllowingStateLoss();
        }
        else {
            mFragmentTransaction.setTransition(TRANSIT_FRAGMENT_OPEN);
            mFragmentTransaction.hide(mHomeSearchTabFrgmt).show(mHomeSearchHotHisFrgmt).commitAllowingStateLoss();
        }
    }


    //取消搜索 结束页面
    public void searchCancel(View view) {
        finish();
    }


    //点击X 清空按钮
    public void searchClear(View view) {
        //清空搜索
        selectedStr.set("");
        mSearchKeyView.clearFocus();
        mSearchClear.setVisibility(View.GONE);
        hideSystemInputPannel();
        toLocalSearchHisView();
    }


    private void hideSystemInputPannel() {
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }


    @Override public void onRetry(int layoutState) {
        mHomeSearchHotHisFrgmt.toGetData();
    }


    @Override public void onLoadingCancel() {

    }
}
