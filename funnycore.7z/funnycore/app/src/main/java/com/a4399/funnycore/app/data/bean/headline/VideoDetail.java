package com.a4399.funnycore.app.data.bean.headline;

import com.a4399.funnycore.app.data.bean.MsgCardBean;
import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @another 江祖赟
 * @date 2017/12/21.
 * 头条--视频详情
 */
public class VideoDetail {

    /**
     * detail : {"id":"id","title":"视频名称","pic":"图片地址","url":"链接地址","author":"作者","views":"播放次数","desc":"描述","time":"发布时间","seconds":"视频时长"}
     * related : [{"id":"id","type":"类型(1-资讯，2-视频)","title":"标题","content":"内容","pic":"图片","date":"发布时间（时间戳）","views":"访问数"}]
     */

    @SerializedName("detail") public DetailBean detail;
    @SerializedName("related") public List<MsgCardBean> related;

    public static class DetailBean {
        /**
         * id : id
         * title : 视频名称
         * pic : 图片地址
         * url : 链接地址
         * author : 作者
         * views : 播放次数
         * desc : 描述
         * time : 发布时间
         * seconds : 视频时长
         */

        @SerializedName("id") public String id;
        @SerializedName("title") public String title;
        @SerializedName("pic") public String pic;
        @SerializedName("url") public String url;
        @SerializedName("author") public String author;
        @SerializedName("views") public String views;
        @SerializedName("desc") public String desc;
        @SerializedName("time") public String time;
        @SerializedName("seconds") public String seconds;
    }
}
