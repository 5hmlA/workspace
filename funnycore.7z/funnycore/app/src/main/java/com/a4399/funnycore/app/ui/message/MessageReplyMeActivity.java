package com.a4399.funnycore.app.ui.message;

import android.databinding.DataBindingUtil;
import android.view.View;

import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.message.MessageReplyMeViewModel;
import com.a4399.funnycore.base.BaseListActivity;
import com.a4399.funnycore.databinding.ActivityMessageReplyMeBinding;
import com.a4399.funnycore.utils.ResUtil;

import java.util.HashMap;

/**
 * 描述:消息之收到的回复Activity
 *
 * @author 罗远回
 * @since 2018年01月08日 16:44
 */

public class MessageReplyMeActivity extends BaseListActivity<MessageReplyMeViewModel> {

  @Override
  protected MessageReplyMeViewModel initModel() {
    return new MessageReplyMeViewModel();
  }

  @Override
  protected View initBinding() {
    ActivityMessageReplyMeBinding messageReplyMeBinding =
        DataBindingUtil.setContentView(this, R.layout.activity_message_reply_me);
    messageReplyMeBinding.setMrviewmodel(viewModel);
    return messageReplyMeBinding.toolbar;
  }

  @Override
  protected HashMap putParam() {
    return new HashMap();
  }

  @Override
  protected void initToolBar() {
    super.initToolBar();
    mToolbar.setTitle(ResUtil.getString(R.string.replay_me));
  }
}
