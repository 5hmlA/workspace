package com.a4399.funnycore;

import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.multidex.MultiDexApplication;
import android.view.View;

import com.a4399.funnycore.utils.ToastUtil;
import com.example.library_share_umeng.common.PlatformData;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.raizlabs.android.dbflow.config.FlowConfig;
import com.raizlabs.android.dbflow.config.FlowManager;
import com.squareup.leakcanary.LeakCanary;
import com.umeng.socialize.PlatformConfig;
import com.umeng.socialize.UMShareAPI;

import java.net.Proxy;

import cn.m4399.common.model.SDKResult;
import cn.m4399.operate.OperateCenter;
import cn.m4399.operate.OperateConfig;
import me.drakeet.library.CrashWoodpecker;
import me.drakeet.library.PatchMode;
import me.tatarka.bindingcollectionadapter2.Utils;
import sandboxtool.sj4399.com.library_download.FileDownloader;
import sandboxtool.sj4399.com.library_download.connection.FileDownloadUrlConnection;

import static com.a4399.funnycore.BuildConfig.FLAVOR;

public class JApp extends MultiDexApplication implements Application.ActivityLifecycleCallbacks {

    private OperateCenter mOpeCenter;
    private static final String CLIENT_ID = "b83af400acbb47c9b6247720d1dffd43";
    private static final String REDIRECT_URL = "http://www.4399api.com";
    private static Context sContext;


    @Override public void onCreate() {
        super.onCreate();
        initThirdParty();
        sContext = getBaseContext();
        CommonConsts.getAppContextInstance = sContext;
        ToastUtil.regest(sContext);
        initlogin4399();
        registerActivityLifecycleCallbacks(this);
        //        configAliIM();
        //        ViewTarget.setTagId(R.id.glide_tag);
        Utils.sInDebug = true;
        registerComponentCallbacks(new ComponentCallbacks2() {
            @Override public void onTrimMemory(int level) {
            }


            @Override public void onConfigurationChanged(Configuration newConfig) {

            }


            @Override public void onLowMemory() {
            }
        });
    }


    /**
     * 第三方数据初始化
     */
    private void initThirdParty() {
        // ================= 数据库 =====================
        FlowManager.init(new FlowConfig.Builder(this).build());

        // ================= 图片 =======================
        Fresco.initialize(this);

        // ================= 友盟分享 ===================
        initPlatformConfig();
        UMShareAPI.get(this);

        // ================= 下载 =======================
        FileDownloader.setupOnApplicationOnCreate(this)
                      .connectionCreator(new FileDownloadUrlConnection.Creator(
                              new FileDownloadUrlConnection.Configuration().connectTimeout(
                                      15_000) // set connection timeout.
                                                                           .readTimeout(
                                                                                   15_000) // set read timeout.
                                                                           .proxy(Proxy.NO_PROXY) // set proxy
                      ))
                      .commit();

        // ================= 泄露检测工具 ================
        if (BuildConfig.DEBUG) {
            CrashWoodpecker.instance()
                           .withKeys("widget", "com.a4399.funnycore")
                           .setPatchMode(PatchMode.SHOW_LOG_PAGE)
                           .setPassToOriginalDefaultHandler(true)
                           .flyTo(this);
            if ("internal_dev".equals(FLAVOR)) {
                if (LeakCanary.isInAnalyzerProcess(this)) {
                    return;
                }
                LeakCanary.install(this);
            }
        }
    }


    /**
     * 配置平台数据
     */
    private void initPlatformConfig() {
        PlatformConfig.setWeixin(PlatformData.AccountValues.WE_CHAT, PlatformData.KeyValues.WE_CHAT);
        PlatformConfig.setQQZone(PlatformData.AccountValues.QQ, PlatformData.KeyValues.QQ);
    }

    //    private void configAliIM(){
    //        //必须首先执行这部分代码, 如果在":TCMSSevice"进程中，无需进行云旺（OpenIM）和app业务的初始化，以节省内存;
    //        SysUtil.setApplication(this);
    //        if(SysUtil.isTCMSServiceProcess(this)) {
    //            return;
    //        }
    //        //第一个参数是Application Context
    //        //这里的APP_KEY即应用创建时申请的APP_KEY，同时初始化必须是在主进程中
    //        if(SysUtil.isMainProcess()) {
    //            YWAPI.init(this, BuildConfig.ALI_IM_KEY);
    //        }
    //
    //        if(AccountManage.getSingleton().isLogin()) {
    //            AliIMhelper.getSingleton().addConnectionListener();
    //        }
    //    }


    private void initlogin4399() {
        // 获取sdk操作类
        mOpeCenter = OperateCenter.getInstance();
        // sdk配置信息类
        OperateConfig opeConfig = new OperateConfig.Builder()
                // 登录界面横竖屏配置（ 当使用游戏盒授权时，登录强制为竖屏 ）（ 必填 ）
                .setOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
                // app在用户中心分配的 client_id （ 必填 ）第一次接入的 APP 可自行向 4399用户中心（厦门）申请
                .setClientID(CLIENT_ID)
                // app在用户中心分配的 client_id 所对应的 redirect_url（ 必填 ）
                .setRedirectUrl(REDIRECT_URL)
                // app在游戏盒分配的 id （非必填 默认自动填充为clientid ）
                .setGameID(CLIENT_ID)
                // 是否全屏显示登录界面 （ 选填 ）
                .setFullScreen(false).build();

        // 进行sdk初始化（接口二）（有效防止进程被杀而导致的游戏盒无法授权登录 推荐使用）
        mOpeCenter.init(getApplicationContext(), opeConfig, new OperateCenter.ValidateListener() {
            @Override public void onValidateFinished(SDKResult result) {
            }
        });

    }


    public static Context getInstance() {
        return sContext;
    }


    @Override public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
    }


    @Override public void onActivityStarted(Activity activity) {
    }


    @Override public void onActivityResumed(Activity activity) {
    }


    @Override public void onActivityPaused(Activity activity) {
    }


    @Override public void onActivityStopped(Activity activity) {
    }


    @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

    }


    @Override public void onActivityDestroyed(Activity activity) {
    }


    public static String getCurrentChannel() {
        String channel = "";
        try {
            ApplicationInfo appInfo = sContext.getPackageManager()
                                              .getApplicationInfo(sContext.getPackageName(),
                                                      PackageManager.GET_META_DATA);
            channel = appInfo.metaData.getString("UMENG_CHANNEL");
        } catch (PackageManager.NameNotFoundException e) {
            channel = FLAVOR;
        }
        return channel;
    }


    public static Context getContext() {
        return sContext;
    }


    public static String findString(int strRes) {
        return sContext.getString(strRes);
    }

    public static float findDimens(int strRes) {
        return sContext.getResources().getDimension(strRes);
    }

    public static int findColor(int strRes) {
        return sContext.getResources().getColor(strRes);
    }

    public static String findString(int strRes,Object ...objects) {
        return sContext.getString(strRes,objects);
    }


    public static Activity getAct4View(View view) {
        Context context = view.getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                return (Activity) context;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        return null;
    }

    public static void startAct4View(View view, Intent intent) {
        Context context = view.getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                ((Activity) context).startActivity(intent);
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
    }
}
