package com.a4399.funnycore.app.data.bean.home;

import android.view.View;

/**
 * @another 江祖赟
 * @date 2018/1/2.
 */
public interface ShowDetail {
    void showDetail(View view);
}
