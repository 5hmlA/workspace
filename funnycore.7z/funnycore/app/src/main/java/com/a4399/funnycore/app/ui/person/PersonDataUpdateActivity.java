package com.a4399.funnycore.app.ui.person;

import android.databinding.DataBindingUtil;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.person.PersonDataUpdateViewModel;
import com.a4399.funnycore.base.BaseActivity;
import com.a4399.funnycore.databinding.ActivityPersonDataUpdateBinding;

/**
 * 文件描述：修改个人资料
 * Created by zhanlinjian2888 on 2017/12/19.
 * E-mail:zhanlinjian@4399inc.com
 */

public class PersonDataUpdateActivity extends BaseActivity<PersonDataUpdateViewModel> {

    @Override protected void initToolBar() {

    }


    @Override protected PersonDataUpdateViewModel initModel() {
        return new PersonDataUpdateViewModel();
    }


    @Override protected void initBinding() {
        ActivityPersonDataUpdateBinding activityPersonDataUpdateBinding = DataBindingUtil.setContentView(this,
                R.layout.activity_person_data_update);
        activityPersonDataUpdateBinding.setPersonDataUpdateViewModel(viewModel);
    }


    @Override protected void initViewAndData() {

    }


    @Override protected boolean isBindRxBus() {
        return false;
    }


    @Override protected void initRxBus() {

    }
}
