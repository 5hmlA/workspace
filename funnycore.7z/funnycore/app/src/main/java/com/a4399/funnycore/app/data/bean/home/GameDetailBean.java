package com.a4399.funnycore.app.data.bean.home;

import com.a4399.funnycore.app.download.BaseDownloadBean;
import com.google.gson.annotations.SerializedName;
import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.structure.BaseModel;
import java.io.Serializable;

/**
 * 文件描述：
 * Created by zhanlinjian2888 on 2017/12/26.
 * E-mail:zhanlinjian@4399inc.com
 */

public class GameDetailBean extends BaseDownloadBean implements Serializable {

    @Column public String id;
    // 游戏图标
    @Column public String icon;
    @Column public String name;
    @Column public String version;
    @Column public String size;
    @Column public String url;
    @Column public String package_name;
    // 是否可更新
    @SerializedName("update") public boolean update;

    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }


    public String getIcon() {
        return icon;
    }


    public void setIcon(String icon) {
        this.icon = icon;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getVersion() {
        return version;
    }


    public void setVersion(String version) {
        this.version = version;
    }


    public String getSize() {
        return size;
    }


    public void setSize(String size) {
        this.size = size;
    }


    public String getUrl() {
        return url;
    }


    public void setUrl(String url) {
        this.url = url;
    }


    public boolean getUpdate() {
        return update;
    }


    public void setUpdate(boolean update) {
        this.update = update;
    }


    public String getPackage_name() {
        return package_name;
    }


    public void setPackage_name(String package_name) {
        this.package_name = package_name;
    }
}
