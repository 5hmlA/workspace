package com.a4399.funnycore.app.viewmodel;

import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import java.util.List;

/**
 * @another 江祖赟
 * @date 2017/12/18.
 */
public class HomeViewModel extends BaseViewModel {
    @Override public void initViewModelData() {

    }


    @Override public List<BaseViewModelErrorInfo> verifyViewModel() {
        return null;
    }
}
