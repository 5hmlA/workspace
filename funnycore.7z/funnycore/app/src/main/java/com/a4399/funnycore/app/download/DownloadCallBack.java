package com.a4399.funnycore.app.download;

/**
 * 文件描述：下载进度、状态发生变化回调
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public interface DownloadCallBack {

    /**
     * 改变进度
     * @param newProgress
     */
    void updateProgress(String newProgress);

    /**
     * 状态发生变化
     * @param newState
     */
    void updateState(int newState);



}
