package com.a4399.funnycore.app.viewmodel.ranking;

import com.a4399.funnycore.BR;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.headline.RankGameInfo;
import com.a4399.funnycore.base.LoadMoreViewModel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass;

/**
 * 文件描述：
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */

public class RankingViewModel extends LoadMoreViewModel{

    {
        pageState.set(0);
    }

    @Override public void toGetData(HashMap mapParam) {
        List<RankGameInfo> gameInfoList = new ArrayList<>();
        gameInfoList.add(new RankGameInfo());
        gameInfoList.add(new RankGameInfo());
        gameInfoList.add(new RankGameInfo());
        gameInfoList.add(new RankGameInfo());
        gameInfoList.add(new RankGameInfo());
        gameInfoList.add(new RankGameInfo());
        gameInfoList.add(new RankGameInfo());
        reflashAll2Finish(gameInfoList);

    }


    @Override protected void registItemTypes(OnItemBindClass<Object> multipleItems) {
        multipleItems.regist(RankGameInfo.class, BR.rankGameInfo, R.layout.item_rank_game_download);
    }
}
