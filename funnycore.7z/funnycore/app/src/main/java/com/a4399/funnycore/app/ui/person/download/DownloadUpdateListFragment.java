package com.a4399.funnycore.app.ui.person.download;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.person.download.DownloadUpdateListViewModel;
import com.a4399.funnycore.base.BaseFragment;
import com.a4399.funnycore.base.BaseListFragment;
import com.a4399.funnycore.databinding.FragmentDownloadUpdateableListBinding;

/**
 * 文件描述：下载管理-可更新列表
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public class DownloadUpdateListFragment extends BaseListFragment<DownloadUpdateListViewModel> {

    /**
     * 获取fragment
     */
    public static DownloadUpdateListFragment getInstance() {
        DownloadUpdateListFragment fragment = new DownloadUpdateListFragment();
        return fragment;
    }


    @Override protected DownloadUpdateListViewModel initModel() {
        return new DownloadUpdateListViewModel();
    }


    @Override protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        FragmentDownloadUpdateableListBinding fragmentPersonHomeBinding = DataBindingUtil.inflate(inflater,
                R.layout.fragment_download_updateable_list, container, false);
        fragmentPersonHomeBinding.setDownloadUpdateListViewModel(viewModel);
        return fragmentPersonHomeBinding;
    }


    @Override protected void initViewAndData() {

    }
}
