package com.a4399.funnycore.app.viewmodel.person.download;

import android.view.View;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import com.a4399.funnycore.utils.LogUtil;
import java.util.List;

/**
 * 文件描述：下载管理
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public class DownloadManageViewModel extends BaseViewModel {

    // 进入下载管理默认显示的tab
    public int defShowTab;

    // 是否删除已安装的apk包
    private boolean isDeleteInstalledPackage;

    public void isDeleteInstalledPackages(View view) {
        LogUtil.info("delete?", "delete" + isDeleteInstalledPackage);
    }

    public boolean isDeleteInstalledPackage() {
        LogUtil.info("delete?", "delete" + isDeleteInstalledPackage);
        return isDeleteInstalledPackage;
    }


    public void setDeleteInstalledPackage(boolean deleteInstalledPackage) {
        isDeleteInstalledPackage = deleteInstalledPackage;
    }


    @Override public void initViewModelData() {

    }


    @Override public List<BaseViewModelErrorInfo> verifyViewModel() {
        return null;
    }
}
