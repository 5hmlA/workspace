package com.a4399.funnycore.app.data.bean.msgcenter;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @another 江祖赟
 * @date 2017/12/22.
 */
public class MsgCenter {
    public static final int MSG_TYPE_REPLY = 1;
    public static final int MSG_TYPE_FANS = 2;
    public static final int MSG_TYPE_ZAN =3;
    public static final int MSG_TYPE_SYS =4;

    /**
     * msgNum : 消息未读总数
     * list : [{"type":"类型(1-回复我的，2-新的粉丝，3-收到的赞，4-系统通知)","nums":"数量"}]
     */

    @SerializedName("msgNum") public int msgNum;
    @SerializedName("list") public List<MsgType> list;

    public static class MsgType {
        /**
         * type : 类型(1-回复我的，2-新的粉丝，3-收到的赞，4-系统通知)
         * nums : 数量
         */

        @SerializedName("type") public int type;
        @SerializedName("nums") public String nums;
    }
}
