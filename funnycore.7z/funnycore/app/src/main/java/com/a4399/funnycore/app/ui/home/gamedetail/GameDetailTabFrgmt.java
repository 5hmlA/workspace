package com.a4399.funnycore.app.ui.home.gamedetail;

import april.yun.other.JTabStyleDelegate;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.ui.JBaseTabViewpagerFrgmt;
import com.a4399.funnycore.base.LazyFragment;
import com.a4399.funnycore.base.TabAdapter;

import static april.yun.widget.JToolbar.dp2px;
import static com.a4399.funnycore.JApp.findColor;
import static com.a4399.funnycore.JApp.findDimens;

/**
 * @another 江祖赟
 * @date 2018/1/2.
 */
public class GameDetailTabFrgmt extends JBaseTabViewpagerFrgmt {
    @Override protected TabAdapter.BaseFrgmtFractory setFrgmtProvider() {
        return new TabAdapter.BaseFrgmtFractory() {
            @Override protected void initFrgment() {
                super.initFrgment();
                fmCache.put(0, new GameDetailFrgmt());
                fmCache.put(1, new CommentFrgmt());
            }
        };
    }


    protected void initTabStrip() {
        JTabStyleDelegate tabStyleDelegate = mBaseTabStrip.getTabStyleDelegate();
        mBaseTabStrip.getLayoutParams().height = dp2px(26);
        //        2，拿TabStyleDelegate
        //        3, 用TabStyleDelegate设置属性
        tabStyleDelegate.setShouldExpand(true).setNeedTabTextColorScrollUpdate(true)
                        //也可以直接传字符串的颜色，第一个颜色表示checked状态的颜色第二个表示normal状态
                        .setTextColor(findColor(R.color.j_white), findColor(R.color.gray_8b8b))
                        .setTabTextSize((int) findDimens(R.dimen.spacing_14))
                        .setIndicatorHeight(dp2px(26))
                        .setFrameColor(findColor(R.color.gray_8b8b))
                        .setCornerRadio(dp2px(5))
                        .setIndicatorColor(findColor(R.color.gray_8b8b));
    }


    public LazyFragment getFrgmt(int position) {
        return mBaseFrgmtFractory.fmCache.get(position);
    }


    @Override protected String[] setTabTitles() {
        return new String[] { "详情", "评价" };
    }
}
