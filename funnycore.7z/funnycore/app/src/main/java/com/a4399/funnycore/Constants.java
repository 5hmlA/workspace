package com.a4399.funnycore;

/**
 * @author 江祖赟.
 * @date 2017/6/9
 * @des [一句话描述]
 */
public interface Constants {

    int DATA_PAGESIZE = 20;

    interface Temp {
        String url1
                = "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1515412221077&di=443ebe2909a781f4bf787146d9b12f86&imgtype=0&src=http%3A%2F%2Fpic30.nipic.com%2F20130605%2F7447430_154552029000_2.jpg";
        String url2 = "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3531368612,660350450&fm=27&gp=0.jpg";
        String url3
                = "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1515412321502&di=da6ed6ccd89883abbc3d20d56864c920&imgtype=0&src=http%3A%2F%2Fimg1.3lian.com%2F2015%2Fa1%2F119%2Fd%2F238.jpg";
    }

    interface AboutHead {
        char SEMICOLON = ';';
        char EQUAL = '=';
        String HTTP_HEADER_DEVICE = "Device";
        String HTTP_HEADER_COOKIE = "Cookie";
        String COOKIE_KEY_AUTH = "auth";
        String COOKIE_KEY_AUTH_USERID = "userId";
        String COOKIE_KEY_AUTH_EXPIRE = "authExpire";
        String HTTP_HEADER_DEVICE_TYPE = "Device-Type";
        String HTTP_HEADER_DEVICE_IP = "Device-IP";
        String HTTP_HEADER_DEVICE_NAME = "Device-Name";
        String HTTP_HEADER_USER_AGENT = "User-Agent";
        String HTTP_HEADER_CHANNNEL = "Channel";
    }
}
