package com.a4399.funnycore.app.ui.home;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PagerSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.home.Home;
import com.a4399.funnycore.app.ui.home.gamedetail.GameDetailAct;
import com.a4399.funnycore.app.viewmodel.home.more.BookGameViewModel;
import com.a4399.funnycore.base.BaseListActivity;
import com.a4399.funnycore.databinding.ActivityMore2BookBinding;
import com.a4399.funnycore.utils.ToastUtil;
import java.util.HashMap;

import static android.support.v7.widget.RecyclerView.SCROLL_STATE_IDLE;
import static android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;

/**
 * 发现游戏和 新游预约 的更多页面
 */
public class More2BookAct extends BaseListActivity<BookGameViewModel> {
    public static String HOME_MORE_BOOKGAME = "新游预定";
    public static String HOME_MORE_FINDGAME = "发现游戏";
    private static String sMoreType = HOME_MORE_BOOKGAME;
    private ActivityMore2BookBinding mMore2BookBinding;
    private Home.FindGameBean mCenterFindGameBean;


    public static void startAct4View(View view, String moreType) {
        sMoreType = moreType;
        Context context = view.getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                Activity activity = ((Activity) context);
                Intent intent = new Intent(activity, More2BookAct.class);
                //intent.putExtra(SEARCH_TYPE, search_type);
                activity.startActivity(intent);
                //ActivityCompat.startActivity(activity, intent, ActivityOptionsCompat.makeSceneTransitionAnimation(activity).toBundle());
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
    }


    @Override protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        super.onCreate(savedInstanceState);
    }


    @Override protected BookGameViewModel initModel() {
        return new BookGameViewModel();
    }


    @Override protected View initBinding() {
        mMore2BookBinding = DataBindingUtil.setContentView(this, R.layout.activity_more2_book);
        mMore2BookBinding.setBookGameViewModel(viewModel);
        //LinearSnapHelper pagerSnapHelper = new LinearSnapHelper();
        final PagerSnapHelper pagerSnapHelper = new PagerSnapHelper();
        pagerSnapHelper.attachToRecyclerView(mMore2BookBinding.gameDataRecy);
        //修改背景图片
        mMore2BookBinding.gameDataRecy.addOnScrollListener(new RecyclerView.OnScrollListener() {

            private int mFirstCompletelyVisibleItemPosition;


            @Override public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                if (newState == SCROLL_STATE_IDLE) {
                    int firstCompletelyVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition();
                    if (firstCompletelyVisibleItemPosition != mFirstCompletelyVisibleItemPosition) {
                        if (firstCompletelyVisibleItemPosition > 0 && firstCompletelyVisibleItemPosition < viewModel.getDataList().size()) {
                            mFirstCompletelyVisibleItemPosition = firstCompletelyVisibleItemPosition;
                            mCenterFindGameBean = (Home.FindGameBean) viewModel.getDataList().get(mFirstCompletelyVisibleItemPosition);
                            mMore2BookBinding.gamePicBg.setImageURI(Uri.parse(mCenterFindGameBean.link));
                        }
                    }
                }
            }
        });
        return mMore2BookBinding.toolbar;
    }


    @Override protected HashMap putParam() {
        return new HashMap();
    }


    @Override protected void initViewAndData() {
        super.initViewAndData();
        setTitle("");
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.btn_back_38_white);
    }


    //预约或者玩游戏
    public void toBookPlay(View view) {
        //预约或者进入游戏详情
        ToastUtil.showShort("预约或者进入游戏详情");
    }


    public void nextData(View view) {
        viewModel.changeNextData();
    }


    public void toGameDetail(View view) {
        //进入游戏详情
        if (mCenterFindGameBean == null) {
            //第一个
            mCenterFindGameBean = (Home.FindGameBean) viewModel.getDataList().get(0);
        }
        //TranslateAnimation translateAnimation = new TranslateAnimation(TranslateAnimation.RELATIVE_TO_SELF, 0,TranslateAnimation.RELATIVE_TO_SELF, 0,
        //        TranslateAnimation.RELATIVE_TO_SELF, 0,TranslateAnimation.RELATIVE_TO_SELF, 1);
        //translateAnimation.setDuration(1200);
        //mMore2BookBinding.gameDataRecy.startAnimation(translateAnimation);
        //GameDetailAct.startAct4View(view,mCenterFindGameBean.id);
        GameDetailAct.startAct(this, mCenterFindGameBean.id);
    }
}
