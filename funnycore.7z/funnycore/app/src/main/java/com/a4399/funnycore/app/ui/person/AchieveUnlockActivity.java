package com.a4399.funnycore.app.ui.person;

import android.databinding.DataBindingUtil;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.person.AchieveUnlockViewModel;
import com.a4399.funnycore.base.BaseActivity;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.databinding.ActivityAchieveUnlockBinding;

/**
 * 文件描述：成就解锁
 * Created by zhanlinjian2888 on 2018/1/4.
 * E-mail:zhanlinjian@4399inc.com
 */

public class AchieveUnlockActivity extends BaseActivity<AchieveUnlockViewModel> {
    @Override protected AchieveUnlockViewModel initModel() {
        return new AchieveUnlockViewModel();
    }


    @Override protected void initBinding() {
        ActivityAchieveUnlockBinding activityAchieveUnlockBinding = DataBindingUtil.setContentView(this,
                R.layout.activity_achieve_unlock);
        activityAchieveUnlockBinding.setAchieveUnlockViewModel(viewModel);
    }


    @Override protected void initViewAndData() {

    }
}
