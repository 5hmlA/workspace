package com.a4399.funnycore.app.ui.dynamic;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.dynamic.DynamicViewModel;
import com.a4399.funnycore.base.BaseFragment;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.databinding.FragmentDynamicHomeBinding;

/**
 * 文件描述：动态首页
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */

public class DynamicHomeFragment extends BaseFragment<DynamicViewModel> {

    @Override protected DynamicViewModel initModel() {
        return new DynamicViewModel();
    }


    @Override protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        FragmentDynamicHomeBinding fragmentDynamicHomeBinding= DataBindingUtil.inflate(inflater, R.layout
                        .fragment_dynamic_home,
                container, false);
        // fragmentDynamicHomeBinding.se
        return fragmentDynamicHomeBinding;
    }


    @Override protected void initViewAndData() {

    }
}
