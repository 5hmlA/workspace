package com.a4399.funnycore.app.ui.headlines;

import android.databinding.ViewDataBinding;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.a4399.funnycore.app.viewmodel.headlines.HeadlinesViewModel;
import com.a4399.funnycore.base.BaseListFragment;
import com.a4399.funnycore.databinding.FragmentHanlinesHomeBinding;

/**
 * 文件描述：动态首页
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */

public class HeadlinesHomeFragment extends BaseListFragment<HeadlinesViewModel> {

    @Override protected HeadlinesViewModel initModel() {
        return new HeadlinesViewModel();
    }


    @Override protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        FragmentHanlinesHomeBinding hanlinesHomeBinding = FragmentHanlinesHomeBinding.inflate(inflater);
        hanlinesHomeBinding.setHeadlinesViewModel(viewModel);
        return hanlinesHomeBinding;
    }


    @Override protected void initViewAndData() {

    }
}
