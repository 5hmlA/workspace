package com.a4399.funnycore.app.data.event;

/**
 * @another 江祖赟
 * @date 2017/8/3 0003.
 */
public class LoginEvent {
    public boolean loginSucceed;

    public LoginEvent(boolean loginSucceed){
        this.loginSucceed = loginSucceed;
    }
}
