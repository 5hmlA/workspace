package com.a4399.funnycore.app.data.bean;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @another 江祖赟
 * @date 2018/1/10.
 */
public class HotSearchKeyBean {

    @SerializedName("list") public List<String> list;
}
