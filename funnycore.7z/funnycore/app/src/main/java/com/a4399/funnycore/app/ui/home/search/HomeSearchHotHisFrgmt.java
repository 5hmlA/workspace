package com.a4399.funnycore.app.ui.home.search;

import android.databinding.Observable;
import android.databinding.ObservableField;
import android.databinding.ViewDataBinding;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.a4399.funnycore.app.viewmodel.home.search.HomeSearchHotHisViewModel;
import com.a4399.funnycore.base.BaseFragment;
import com.a4399.funnycore.databinding.FragmentHomeSearchBinding;

/**
 * @another 江祖赟
 * @date 2018/1/10.
 */
public class HomeSearchHotHisFrgmt extends BaseFragment<HomeSearchHotHisViewModel> {

    @Override protected HomeSearchHotHisViewModel initModel() {
        return new HomeSearchHotHisViewModel(((HomeSearchAct) mContext).selectedStr,((HomeSearchAct) mContext).layoutState);
    }


    @Override protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        FragmentHomeSearchBinding inflate = FragmentHomeSearchBinding.inflate(inflater);
        inflate.setHotHisViewModel(viewModel);
        return inflate;
    }


    @Override protected void initViewAndData() {
        final ObservableField<String> currentSearchKey = ((HomeSearchAct) mContext).currentSearchKey;
        currentSearchKey.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override public void onPropertyChanged(Observable observable, int i) {
                if (!TextUtils.isEmpty(currentSearchKey.get())) {
                    viewModel.keepSearchKey(currentSearchKey.get());
                }
            }
        });
        toGetData();
    }


    public void toGetData() {
        viewModel.initViewModelData();
    }


    @Override public void onDestroy() {
        super.onDestroy();
        viewModel.unsubscribe();
    }
}
