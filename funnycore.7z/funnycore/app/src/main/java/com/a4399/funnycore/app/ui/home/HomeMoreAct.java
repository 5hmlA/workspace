package com.a4399.funnycore.app.ui.home;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.home.welfare.HomeMoreViewModel;
import com.a4399.funnycore.base.BaseListActivity;
import com.a4399.funnycore.databinding.ActivityHomeMoreBinding;
import com.jakewharton.rxbinding2.widget.RxTextView;
import com.jakewharton.rxbinding2.widget.TextViewAfterTextChangeEvent;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

/**
 * 福利中心 游戏资源 更多 包括搜搜
 * 玩家推荐只有列表
 */
public class HomeMoreAct extends BaseListActivity<HomeMoreViewModel> {

    public static String MORE_TYPE = "首页更多类型";
    public static String HOME_MORE_WEALFARE = "福利中心";
    public static String HOME_MORE_GAMERES = "游戏资源";
    public static String HOME_MORE_USERRECOM = "玩家推荐";

    private String mType_more;
    private ImageView mSearchClear;
    private EditText mSearchKeyView;


    public static void startAct4View(View view, String moreType) {
        Context context = view.getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                Activity activity = ((Activity) context);
                Intent intent = new Intent(activity, HomeMoreAct.class);
                intent.putExtra(MORE_TYPE, moreType);
                activity.startActivity(intent);
                //ActivityCompat.startActivity(activity, intent, ActivityOptionsCompat.makeSceneTransitionAnimation(activity).toBundle());
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
    }


    @Override protected void initIntent(Intent fromIntent) {
        mType_more = fromIntent.getStringExtra(MORE_TYPE);
    }


    @Override protected HomeMoreViewModel initModel() {
        return new HomeMoreViewModel();
    }


    @Override protected View initBinding() {
        ActivityHomeMoreBinding homeMoreBinding = DataBindingUtil.setContentView(this, R.layout.activity_home_more);
        mSearchClear = homeMoreBinding.searchClear;
        homeMoreBinding.setRecViewModel(viewModel);
        if (HOME_MORE_USERRECOM.equals(mType_more)) {
            ((View) homeMoreBinding.moreTypeEtKey.getParent()).setVisibility(View.GONE);
        }
        else {
            mSearchKeyView = homeMoreBinding.moreTypeEtKey;
            RxTextView.afterTextChangeEvents(mSearchKeyView)
                      .debounce(400, TimeUnit.MILLISECONDS)
                      .observeOn(AndroidSchedulers.mainThread())
                      .filter(new Predicate<TextViewAfterTextChangeEvent>() {
                          @Override public boolean test(TextViewAfterTextChangeEvent textViewAfterTextChangeEvent) throws Exception {
                              if (TextUtils.isEmpty(textViewAfterTextChangeEvent.editable())) {
                                  mSearchClear.setVisibility(View.GONE);
                                  return false;
                              }
                              else {
                                  mSearchClear.setVisibility(View.VISIBLE);
                                  return true;
                              }
                          }
                      })
                      .subscribe(new Consumer<TextViewAfterTextChangeEvent>() {
                          @Override public void accept(TextViewAfterTextChangeEvent textViewAfterTextChangeEvent) throws Exception {
                              System.out.println(textViewAfterTextChangeEvent.editable().toString());
                              hideSystemInputPannel();
                              viewModel.search(null,textViewAfterTextChangeEvent.editable().toString());
                          }
                      });
        }
        return homeMoreBinding.toolbar;
    }


    @Override protected HashMap putParam() {
        return new HashMap();
    }


    @Override protected boolean isBindRxBus() {
        return false;
    }


    @Override protected void initRxBus() {

    }


    @Override protected void initToolBar() {
        super.initToolBar();
        setTitle(mType_more);
    }


    public void searchClear(View view) {
        //清空搜索
        mSearchKeyView.setText("");
        mSearchKeyView.clearFocus();
        mSearchClear.setVisibility(View.GONE);
        hideSystemInputPannel();
        viewModel.search(null,"");
    }


    private void hideSystemInputPannel() {
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }
}
