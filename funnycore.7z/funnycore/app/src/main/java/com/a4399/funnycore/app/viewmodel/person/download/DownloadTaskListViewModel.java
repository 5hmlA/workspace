package com.a4399.funnycore.app.viewmodel.person.download;

import android.databinding.ObservableArrayList;
import com.a4399.funnycore.BR;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.download.GameDownloadTaskBean;
import com.a4399.funnycore.app.download.BaseDownloadBean;
import com.a4399.funnycore.app.download.DownloadStateInterface;
import com.a4399.funnycore.app.download.GameDownloadTaskManager;
import com.a4399.funnycore.base.LoadMoreViewModel;
import easybind.jzy.bindingstar.statehelper.PageDiffState;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass;
import sandboxtool.sj4399.com.library_download.util.FileDownloadUtils;

/**
 * 文件描述：下载管理-下载任务
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public class DownloadTaskListViewModel extends LoadMoreViewModel {

    ObservableArrayList<GameDownloadTaskBean> mTaskListBeans = new ObservableArrayList<>();


    public DownloadTaskListViewModel() {

        // 读取库表获取下载任务
        List<GameDownloadTaskBean> allTask = GameDownloadTaskManager.getInstance().getAllDownLoadTask();
        if (allTask == null || allTask.size() < 1) {
            // 没有任务
            return;
        }
        for (int j = 0; j < allTask.size(); j++) {
            ItemDownloadTaskViewModel itemDownloadTaskViewModel = new ItemDownloadTaskViewModel();
            itemDownloadTaskViewModel.setGameDownloadTaskBean(allTask.get(j));
            itemDownloadTaskViewModel.initDownloadState();
            mDataLists.add(itemDownloadTaskViewModel);
        }
    }


    @Override public void toGetData(HashMap mapParam) {
        Observable.just(mDataLists)
                  .delay(2, TimeUnit.SECONDS)
                  .observeOn(AndroidSchedulers.mainThread())
                  .subscribe(new Consumer() {
                      @Override public void accept(Object o) throws Exception {

                          if (isFirstPage()) {
                              refreshedAllData(mDataLists);
                          }
                          else {
                              if (new Random().nextBoolean()) {
                                  addMoreData(mTaskListBeans, mDataLists.size() < 30);
                              }
                              else {
                                  showPageStateError(PageDiffState.PAGE_STATE_ERROR);
                              }
                          }
                      }
                  });
    }


    @Override protected void registItemTypes(OnItemBindClass<Object> multipleItems) {
        multipleItems.regist(ItemDownloadTaskViewModel.class, BR.itemDownloadTaskViewModel,
                R.layout.item_download_task);
    }
}
