package com.a4399.funnycore.app.ui.headlines;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.view.View;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.headlines.HeadlinesGameViewModel;
import com.a4399.funnycore.base.BaseListActivity;
import com.a4399.funnycore.databinding.ActivityHeadLineGameBinding;
import java.util.HashMap;

/**
 * 某个游戏相关的所有头条咨询
 */
public class HeadLineGameAct extends BaseListActivity<HeadlinesGameViewModel> {

    public static final String GAME_ID = "game_id";
    public static final String GAME_NAME = "game_name";

    public static void startAct4View(View view,String gameName,String gameId) {
        Context context = view.getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                Activity activity = ((Activity) context);
                Intent intent = new Intent(activity, HeadLineGameAct.class);
                intent.putExtra(GAME_ID, gameId);
                intent.putExtra(GAME_NAME, gameName);
                activity.startActivity(intent);
                //ActivityCompat.startActivity(activity, intent, ActivityOptionsCompat.makeSceneTransitionAnimation(activity).toBundle());
            } context = ((ContextWrapper) context).getBaseContext();
        }
    }


    @Override protected void initIntent(Intent fromIntent) {
        String gameName = fromIntent.getStringExtra(GAME_NAME);
        String gameId = fromIntent.getStringExtra(GAME_ID);
        setTitle(gameName);
    }


    @Override protected HeadlinesGameViewModel initModel() {
        return new HeadlinesGameViewModel();
    }


    @Override protected View initBinding() {
        ActivityHeadLineGameBinding headLineGameBinding = DataBindingUtil.setContentView(this, R.layout.activity_head_line_game);
        headLineGameBinding.setHeadlineGameViewModel(viewModel);
        return headLineGameBinding.toolbar;
    }


    @Override protected HashMap putParam() {
        return new HashMap();
    }
}
