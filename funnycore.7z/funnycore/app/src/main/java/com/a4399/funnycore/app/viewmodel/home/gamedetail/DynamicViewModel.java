package com.a4399.funnycore.app.viewmodel.home.gamedetail;

import com.a4399.funnycore.base.LoadMoreViewModel;
import java.util.HashMap;
import me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass;

/**
 * @another 江祖赟
 * @date 2018/1/2.
 * 动态
 */
public class DynamicViewModel extends LoadMoreViewModel {
    @Override public void toGetData(HashMap mapParam) {

    }


    @Override protected void registItemTypes(OnItemBindClass<Object> multipleItems) {

    }
}
