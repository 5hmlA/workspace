package com.a4399.funnycore.app.ui.person;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.ui.person.local.LocalGameFragment;
import com.a4399.funnycore.app.viewmodel.person.PersonViewModel;
import com.a4399.funnycore.base.BaseFragment;
import com.a4399.funnycore.databinding.FragmentPersonHomeBinding;

/**
 * 文件描述：动态首页
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */

public class PersonHomeFragment extends BaseFragment<PersonViewModel> {

    @Override protected PersonViewModel initModel() {
        return new PersonViewModel();
    }


    @Override protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        FragmentPersonHomeBinding fragmentPersonHomeBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_person_home, container, false);
        fragmentPersonHomeBinding.setPersonViewModel(viewModel);
        return fragmentPersonHomeBinding;
    }


    @Override protected void initViewAndData() {
        initLocalGameFragment();
        viewModel.initViewModelData();
    }


    /**
     * 初始化本机游戏的fragment
     */
    private void initLocalGameFragment() {
        LocalGameFragment localGameFragment = new LocalGameFragment();
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        transaction.add(R.id.frame_local_game, localGameFragment).commit();
    }
}
