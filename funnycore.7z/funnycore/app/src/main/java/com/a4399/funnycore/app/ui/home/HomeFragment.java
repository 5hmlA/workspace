package com.a4399.funnycore.app.ui.home;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.home.HomeViewModel;
import com.a4399.funnycore.base.BaseListFragment;
import com.a4399.funnycore.databinding.FragmentHomeBinding;

/**
 * 文件描述：
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */

public class HomeFragment extends BaseListFragment<HomeViewModel> {

    @Override protected HomeViewModel initModel() {
        return new HomeViewModel();
    }


    @Override protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        FragmentHomeBinding fragmentHomeBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_home,
                container, false);
        fragmentHomeBinding.setRecViewModel(viewModel);
        return fragmentHomeBinding;
    }


    @Override protected void initViewAndData() {

    }
}
