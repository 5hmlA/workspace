package com.a4399.funnycore.app.data.netservice;

import android.app.Activity;
import android.text.TextUtils;
import android.util.Log;

import com.a4399.funnycore.app.data.DataResult;
import com.a4399.funnycore.app.data.bean.AccountBean;
import com.a4399.funnycore.app.data.bean.ForumResponseData;
import com.a4399.funnycore.app.data.bean.UserBean;
import com.a4399.funnycore.app.data.bean.UserBean_Table;
import com.a4399.funnycore.app.data.event.LoginEvent;
import com.a4399.funnycore.app.data.netservice.urlapi.FunnyCoreApi;
import com.a4399.funnycore.rx.RxBus;
import com.a4399.funnycore.rx.RxJavaUtil;
import com.a4399.funnycore.utils.LogUtil;
import com.a4399.funnycore.utils.ToastUtil;
import com.raizlabs.android.dbflow.sql.language.Select;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import cn.m4399.common.model.SDKResult;
import cn.m4399.operate.OperateCenter;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.ObservableSource;
import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

import static android.text.TextUtils.isEmpty;
import static com.a4399.funnycore.app.utill.ParamWrapper.paramWrapper;
import static com.a4399.funnycore.utils.CheckHelper.checkObjects;

// import io.objectbox.Box;

/**
 * @another 江祖赟
 * @date 2017/6/30.
 */
public class AccountManage {

    private static final String TAG = "AccountManage";
    private AccountBean mAccountBean;
    private String mAccess_token;
    private String mUid;


    private AccountManage() {
        mAccountBean = getLocalAccount();
    }


    static class Inner {
        public static AccountManage sManage = new AccountManage();
    }


    public static AccountManage getSingleton() {
        return Inner.sManage;
    }


    public AccountManage updateAccount(final AccountBean account) {
        mAccountBean = account;
        saveAccount(account);
        return this;
    }


    public AccountManage clearLocalAccount(AccountBean account) {
        LogUtil.debug(TAG, "==================清空用户信息==================");
        mAccountBean = null;
        mUid = null;
        try {
            //if (getLocalAccount() != null) {
            account.delete();
            // }
            new Select().from(UserBean.class).where(UserBean_Table.id.is(account.id)).querySingle().delete();
            // if (getLocalUserBean() != null) {
            // mUserBeanBox.remove(getLocalUserBean());
            // }
        } catch (Exception e) {
        }

        //        RxBus.getInstance().post(new AccountStateEvent(CHANGE_RESET));
        return this;
    }


    /**
     * 被强登录 清楚本地登录信息
     * 发送 账户重置 事件
     */
    public AccountManage deleteAccount() {
        try {
            if (mAccountBean != null) {
                clearLocalAccount(mAccountBean);
            }
            return this;
        } catch (Exception e) {
            return null;
        }
    }


    public AccountManage saveAccount(AccountBean account) {
        LogUtil.debug(TAG, "账户过期时间：" + getExpiredTime(account.getAd_expired()));
        mAccountBean = account;
        account.save();
        Log.d("MePresenter", "登录成功保存中户信息：");
        return this;
    }


    public AccountManage saveUser(UserBean userBean) {
        try {
            userBean.save();
            return this;
        } catch (Exception e) {
            return null;
        }
    }


    public AccountBean getAccount() {
        if (mAccountBean == null) {
            mAccountBean = getLocalAccount();
        }
        return mAccountBean;
    }


    public String getCookie() {
        return mAccountBean.buildCookie();
    }


    public String getUid() {
        if (TextUtils.isEmpty(mUid)) {
            return mUid = getLocalUserBean().getUid();
        }
        else {
            return mUid;
        }
    }


    public AccountBean getLocalAccount() {
        try {
            return new Select().from(AccountBean.class).querySingle();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    public UserBean getLocalUserBean() {
        try {
            return new Select().from(UserBean.class).querySingle();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    //检查是否有登录 /登录是否有效
    public boolean isLogin() {
        if (checkObjects(mAccountBean = getLocalAccount(), getLocalUserBean())) {
            //判断是否过期
            String ad_expired = mAccountBean.getAd_expired();
            LogUtil.debug(TAG, "过期时间：" + getExpiredTime(ad_expired));
            if (Long.parseLong(ad_expired) * 1000 - System.currentTimeMillis() > 0) {
                return true;
            }
            else {
                //过期
                LogUtil.info(TAG, "账户过期，请重新登录");
                clearLocalAccount(mAccountBean);
                return false;
            }
        }
        else {
            LogUtil.debug(TAG, "账户未登录");
            return false;
        }
    }


    public String getExpiredTime(String expired) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(Long.parseLong(expired) * 1000));
    }


    public Observable<LoginEvent> toLogin(final Activity cactivity) {
        LogUtil.debug(TAG, "发起登录请求");
        final WeakReference<Activity> activityWeakReference = new WeakReference<>(cactivity);
        //1 4399 登录SDK
        //2  用户登录service/user/syncdata
        //3  获取用户信息 service/user/userinfo
        //4  阿里百川登录
        //5  社区刷新cookie
        return Observable.<LoginEvent>create(new ObservableOnSubscribe<LoginEvent>() {
            @Override public void subscribe(final ObservableEmitter<LoginEvent> e) throws Exception {
                OperateCenter.getInstance().login(cactivity, new OperateCenter.ValidateListener() {
                    @Override public void onValidateFinished(SDKResult result) {
                        loginAfter4399login(result, e, activityWeakReference);
                    }
                });
            }
        }).compose(RxJavaUtil.<LoginEvent>defaultSchedulers_obser());
    }


    private void loginAfter4399login(SDKResult result, final ObservableEmitter<LoginEvent> e, WeakReference<Activity> activityWeakReference) {
        LogUtil.info(TAG, "*** 4399SDK:" + result.toString());
        final String authCode = result.getAuthCode();
        final String refreshToken = result.getRefreshToken();
        final String uid = result.getUID();
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("code", authCode);
        param.put("uid", uid);
        param.put("refreshtoken", refreshToken);
        //网页版登录 uid为空

        if (isEmpty(authCode) && isEmpty(uid) && isEmpty(refreshToken)) {
            //全部为空登录取消
            RxBus.getInstance().post(new LoginEvent(false));
            e.onNext(new LoginEvent(false));
            e.onComplete();
            return;
        }
        final Observable<DataResult<AccountBean>> login = ServiceFactory.getInstance()
                                                                        .createService(
                                                                                FunnyCoreApi.IUser.class)
                                                                        .login(paramWrapper(param))
                                                                        .subscribeOn(Schedulers.io());
        login.flatMap(new Function<DataResult<AccountBean>, ObservableSource<DataResult<UserBean>>>() {
            @Override
            public ObservableSource<DataResult<UserBean>> apply(
                    @NonNull DataResult<AccountBean> accountBeanDataResult) throws Exception {
                LogUtil.info(TAG, "***登录成功，获取用户信息 ");
                return logInSuccess2getUserinfo(accountBeanDataResult, authCode);
            }
        }).flatMap(new Function<DataResult<UserBean>, ObservableSource<ForumResponseData>>() {
            @Override
            public ObservableSource<ForumResponseData> apply(DataResult<UserBean> userBeanDataResult)
                    throws Exception {
                AccountManage.getSingleton().saveUser(userBeanDataResult.getData());
                LogUtil.info(TAG, "***获取并保存个人信息成功 开始登录社区 刷新社区cookie ");
                //刷新社区cookie
                return ServiceFactory.getForumService()
                                     .refreshUserCookie(mUid, mAccess_token)
                                     .subscribeOn(Schedulers.io());
            }
        }).subscribe(new Consumer<ForumResponseData>() {
            @Override public void accept(ForumResponseData forumResponseData) throws Exception {
                if (forumResponseData.code == 100) {
                    RxBus.getInstance().post(new LoginEvent(true));
                    e.onNext(new LoginEvent(true));
                    e.onComplete();
                }
                else {
                    LogUtil.info(TAG, "登录验证异常：UID == " + mUid);
                    LogUtil.info(TAG, "登录验证异常：TOKEN == " + mAccess_token);
                    mUid = null;
                    ToastUtil.showLong("登录验证异常");
                    AccountManage.getSingleton().deleteAccount();
                    RxBus.getInstance().post(new LoginEvent(false));
                    e.onNext(new LoginEvent(false));
                    e.onComplete();
                }
            }
        }, new Consumer<Throwable>() {
            @Override public void accept(Throwable throwable) throws Exception {
                LogUtil.error(TAG, Log.getStackTraceString(throwable));
                ToastUtil.showLong(throwable.getMessage());
            }
        });
        //        .flatMap(new Function<ForumResponseData,ObservableSource<Object>>() {
        //            @Override
        //            public ObservableSource<Object> apply(ForumResponseData forumResponseData) throws Exception{
        //                if(forumResponseData.code == 100) {
        //                    LogUtil.info(TAG, "***刷新社区cookie成功 开始登录阿里百川 ");
        //                    return AliIMhelper.getSingleton().refreshAli().aliIMlogin();
        //                }else {
        //                    throw new RuntimeException(forumResponseData.msg);
        //                }
        //            }
        //        }).compose(RxUtill.<Object>defaultSchedulers_obser2(activityWeakReference.get(),
        //                findString(R.string.dlg_data_loading), false))
        //                .subscribe(new Consumer<Object>() {
        //            @Override
        //            public void accept(Object o) throws Exception{
        //                LogUtil.info(TAG, "***登录阿里百川 成功 登录流程结束");
        //                RxBus.getInstance().post(new LoginEvent(true));
        //                e.onNext(new LoginEvent(true));
        //                e.onComplete();
        //            }
        //        }, new Consumer<Throwable>() {
        //            @Override
        //            public void accept(@NonNull Throwable throwable) throws Exception{
        //                LogUtil.info(TAG, "登录验证异常："+Log.getStackTraceString(throwable));
        //                LogUtil.info(TAG, "登录验证异常：UID == "+mUid);
        //                LogUtil.info(TAG, "登录验证异常：TOKEN == "+mAccess_token);
        //                mUid = null;
        //                if(throwable != null && throwable.getMessage() != null) {
        //                    ToastUtil.showLong(JApp.sContext, throwable.getMessage());
        //                }else {
        //                    ToastUtil.showLong(JApp.sContext, "登录验证异常");
        //                }
        //                AccountManage.getSingleton().deleteAccount();
        //                RxBus.getInstance().post(new LoginEvent(false));
        //                e.onNext(new LoginEvent(false));
        //                e.onComplete();
        //            }
        //        });
    }


    private ObservableSource<DataResult<UserBean>> logInSuccess2getUserinfo(
            @NonNull DataResult<AccountBean> accountBeanDataResult, String authCode) {
        if (accountBeanDataResult.getCode() == 10000) {
            AccountBean accountBean = accountBeanDataResult.getData();
            accountBean.setAuthCode(authCode);
            mAccess_token = accountBean.getAccess_token();
            mUid = accountBean.getUid();
            //            AliIMhelper.getSingleton().configIMKitInstance(mUid);
            // 保存账户信息
            AccountManage.getSingleton().saveAccount(accountBean);

            Map<String, Object> stringObjectMap = paramWrapper("flag", 1);
            stringObjectMap.put("uid", mUid);
            //开始获取用户信息
            LogUtil.info(TAG, "登录成功 开始获取用户信息");
            return ServiceFactory.getInstance()
                                 .createService(FunnyCoreApi.IUser.class)
                                 .getUserInfo(AccountManage.getSingleton().getCookie(), stringObjectMap);
        }
        else {
            return Observable.error(new RuntimeException(accountBeanDataResult.getMessage()));
        }
    }


    //没登陆的话会触发登陆
    public boolean checkLogin() {
        return isLogin();
    }
}
