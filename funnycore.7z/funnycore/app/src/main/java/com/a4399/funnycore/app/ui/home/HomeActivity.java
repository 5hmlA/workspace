package com.a4399.funnycore.app.ui.home;

import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.ui.dynamic.DynamicHomeFragment;
import com.a4399.funnycore.app.ui.headlines.HeadlinesHomeFragment;
import com.a4399.funnycore.app.ui.home.search.HomeSearchAct;
import com.a4399.funnycore.app.ui.person.PersonHomeFragment;
import com.a4399.funnycore.app.ui.ranking.RankingHomeFragment;
import com.a4399.funnycore.app.utill.IntentUtil;
import com.a4399.funnycore.app.viewmodel.HomeViewModel;
import com.a4399.funnycore.app.widget.NoSlidingViewPaper;
import com.a4399.funnycore.base.BaseActivity;
import com.a4399.funnycore.databinding.ActivityHomeBinding;
import com.a4399.funnycore.utils.StatusBarHelper;
import java.util.ArrayList;

import static android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;

/**
 * 文件描述：首页activity
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */

public class HomeActivity extends BaseActivity<HomeViewModel> implements RadioGroup.OnCheckedChangeListener {

    // viewpaper
    @BindView(R.id.viewpager) NoSlidingViewPaper mViewPager;

    @BindView(R.id.rg_navigation) RadioGroup mRadioGroup;

    @BindView(R.id.title) TextView mTitleView;

    @BindView(R.id.toolbar_wapper) FrameLayout mToolbarWrapper;

    @BindView(R.id.title_iv) ImageView mHomeImv;
    private ImageView mLeftIcon;


    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        super.onCreate(savedInstanceState);
    }


    @Override protected void initBinding() {
        ActivityHomeBinding activityHomeBinding = DataBindingUtil.setContentView(this, R.layout.activity_home);
        mToolbar = activityHomeBinding.toolbar;
        activityHomeBinding.setHomeViewModel(viewModel);
        ButterKnife.bind(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mToolbarWrapper.setPadding(0, StatusBarHelper.getStatusBarHeight(), 0, 0);
        }
    }


    @Override protected void initActionToolbar() {
        super.initActionToolbar();
    }


    private void toobarSwitch2Home() {
        mHomeImv.setVisibility(View.VISIBLE);
        mTitleView.setVisibility(View.GONE);
        mLeftIcon.setVisibility(View.VISIBLE);
    }


    private void configLeftIcon() {
        mLeftIcon = mToolbar.setLeftIcon(R.drawable.left_38_message);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                IntentUtil.openMessageCenterActivity(HomeActivity.this);
            }
        });
    }


    private void toobarSwitch2Head() {
        mTitleView.setVisibility(View.VISIBLE);
        mHomeImv.setVisibility(View.GONE);
        mTitleView.setText("头条");
        mLeftIcon.setVisibility(View.GONE);
    }


    private void toobarSwitch2Dynamic() {
        mTitleView.setVisibility(View.VISIBLE);
        mHomeImv.setVisibility(View.GONE);
        mTitleView.setText("动态");
        mLeftIcon.setVisibility(View.VISIBLE);
    }


    @Override protected void initToolBar() {
        setTitle(null);
        mToolbar.setRightIcon(R.drawable.btn_search_38_darkgray, 19).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                toSearchAct(v);
            }
        });
    }


    @Override protected HomeViewModel initModel() {
        return new HomeViewModel();
    }


    @Override protected void initViewAndData() {
        configLeftIcon();
        initViewPaper();
    }


    /**
     * 初始化viewpaper
     */
    private void initViewPaper() {

        final ArrayList<Fragment> fgLists = new ArrayList<>();
        fgLists.add(new HomeFragment());         // Home
        fgLists.add(new RankingHomeFragment());  // 排行榜
        fgLists.add(new HeadlinesHomeFragment());// 头条
        fgLists.add(new DynamicHomeFragment());  // 动态
        fgLists.add(new PersonHomeFragment());   // 个人页
        FragmentPagerAdapter mAdapter = new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override public Fragment getItem(int position) {
                return fgLists.get(position);
            }


            @Override public int getCount() {
                return fgLists.size();
            }
        };
        mViewPager.setAdapter(mAdapter);
        mViewPager.setOffscreenPageLimit(fgLists.size());
        mRadioGroup.setOnCheckedChangeListener(this);
        mRadioGroup.check(R.id.rb_homepage);
    }


    @Override protected boolean isBindRxBus() {
        return false;
    }


    @Override protected void initRxBus() {

    }


    @Override public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
        //写法与默认点击页面的相同
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        switch (checkedId) {
            case R.id.rb_homepage:
                mToolbarWrapper.setVisibility(View.VISIBLE);
                mToolbar.setVisibility(View.VISIBLE);
                toobarSwitch2Home();
                mViewPager.setCurrentItem(0, false);
                break;
            case R.id.rb_ranking_list:
                mToolbarWrapper.setVisibility(View.GONE);
                mToolbar.setVisibility(View.GONE);
                mViewPager.setCurrentItem(1, false);
                break;
            case R.id.rb_headlines:
                mToolbarWrapper.setVisibility(View.VISIBLE);
                mToolbar.setVisibility(View.VISIBLE);
                toobarSwitch2Head();
                mViewPager.setCurrentItem(2, false);
                break;
            case R.id.rb_dynamic:
                mToolbarWrapper.setVisibility(View.VISIBLE);
                mToolbar.setVisibility(View.VISIBLE);
                toobarSwitch2Dynamic();
                mViewPager.setCurrentItem(3, false);
                break;
            case R.id.rb_mine:
                mToolbarWrapper.setVisibility(View.GONE);
                mToolbar.setVisibility(View.GONE);
                mViewPager.setCurrentItem(4, false);
                break;
        }
        transaction.commit();
    }


    //切换 右上角图片 是否需要小圆点提示
    public void messageNotify(boolean notify) {
        if (notify) {
            mLeftIcon.setImageResource(R.drawable.btn_messagewithred_darkgray);
        }
        else {
            mLeftIcon.setImageResource(R.drawable.home_topleft_icon_notify);
        }
    }


    public void toSearchAct(View view) {
        HomeSearchAct.startAct(this);
    }
}
