package com.a4399.funnycore.app.data.bean.comment;

import com.google.gson.annotations.SerializedName;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 2017/5/10
 */

public class CommentResultEntity {
  public static final String SUCCESS = "success";

  @SerializedName("msg")
  public String msg;

  public boolean isSucceed(){
    return SUCCESS.equals(msg);
  }

  @Override
  public String toString() {
    return "CommentResultEntity{" +
        "msg='" + msg + '\'' +
        '}';
  }
}
