package com.a4399.funnycore.app.ui.person.download;

import android.databinding.DataBindingUtil;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.a4399.funnycore.FcContents;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.person.download.DownloadManageViewModel;
import com.a4399.funnycore.base.BaseActivity;
import com.a4399.funnycore.base.BaseFragmentPagerAdapter;
import com.a4399.funnycore.databinding.ActivityDownloadManageBinding;

/**
 * 文件描述：下载管理页面
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public class DownloadManageActivity extends BaseActivity<DownloadManageViewModel> {

    // viewpaper
    @BindView(R.id.viewpager) ViewPager mViewPager;
    @BindView(R.id.tabs_top) TabLayout mTabLayout;
    protected BaseFragmentPagerAdapter mFragmentPagerAdapter;


    @Override protected void initToolBar() {

    }


    @Override protected DownloadManageViewModel initModel() {
        return new DownloadManageViewModel();
    }


    @Override protected void initBinding() {
        ActivityDownloadManageBinding activityHomeBinding = DataBindingUtil.setContentView(this,
                R.layout.activity_download_manage);
        activityHomeBinding.setDownloadManageViewModel(viewModel);
    }


    @Override protected void initViewAndData() {
        ButterKnife.bind(this);
        viewModel.defShowTab = getIntent().getIntExtra(FcContents.Extra.DOWNLOAD_MANAGE_DEF_TAB,
                FcContents.DownloadManageType.DOWNLOAD_ING);
        initViewPaper();
    }


    /**
     * 初始化viewpaper
     */
    private void initViewPaper() {
        mFragmentPagerAdapter = new BaseFragmentPagerAdapter(getSupportFragmentManager());
        mFragmentPagerAdapter.addFragment(DownloadTaskListFragment.getInstance(), R.string.download_task);
        mFragmentPagerAdapter.addFragment(DownloadUpdateListFragment.getInstance(),
                R.string.download_update_able);
        mViewPager.setOffscreenPageLimit(2);
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }


            @Override public void onPageSelected(int position) {
            }


            @Override public void onPageScrollStateChanged(int state) {

            }
        });
        mViewPager.setAdapter(mFragmentPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        mTabLayout.setTabMode(TabLayout.MODE_FIXED);
        mTabLayout.getTabAt(viewModel.defShowTab).select();
    }


    @Override protected boolean isBindRxBus() {
        return false;
    }


    @Override protected void initRxBus() {

    }
}
