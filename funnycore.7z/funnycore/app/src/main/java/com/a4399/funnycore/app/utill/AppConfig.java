package com.a4399.funnycore.app.utill;

import android.annotation.SuppressLint;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.text.format.Formatter;

import com.a4399.funnycore.BuildConfig;
import com.a4399.funnycore.JApp;
import com.a4399.funnycore.utils.DensityUtil;
import com.dl7.player.utils.NetWorkUtils;

import java.io.File;

import static android.content.Context.WIFI_SERVICE;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 2017/2/15
 */

public class AppConfig {

    public static final class Http {
        public static final String APP_USER_AGENT = "com.n4399.miniworld";
        public static final String APP_USER_AGENT_VERSION = APP_USER_AGENT+'/'+BuildConfig.VERSION_NAME;

        public static String getAppUserAgentWithDeviceInfo(){
            StringBuilder userAgentSb = new StringBuilder(APP_USER_AGENT_VERSION);
            String brand = Build.BRAND+"_"+Build.MODEL;
            String screen = DensityUtil.getDisplayWidth(JApp.getContext())+"x"+DensityUtil.getDisplayHeight(JApp.getContext());
            userAgentSb.append('(').append("android").append(";").append(brand).append(";")
                    .append(Build.VERSION.RELEASE).append(";").append(screen).append(";")
                    .append(NetWorkUtils.getNetworkType(JApp.getContext())).append(";")
                    //模拟器和真机判断
                    .append(checkEmulator() ? "vm" : "rt").append(")");

            return encodeHeadInfo(userAgentSb.toString());
        }

        private static String encodeHeadInfo(String headInfo){
            StringBuffer stringBuffer = new StringBuffer();
            for(int i = 0, length = headInfo.length(); i<length; i++) {
                char c = headInfo.charAt(i);
                if(c<='\u001f' || c>='\u007f') {
                    stringBuffer.append(String.format("\\u%04x", (int)c));
                }else {
                    stringBuffer.append(c);
                }
            }
            return stringBuffer.toString();
        }
    }

    public static String getDeviceIP(){
        @SuppressLint("WifiManagerLeak") WifiManager wm = (WifiManager)JApp.getContext().getSystemService(WIFI_SERVICE);
        return Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
    }

    /**
     * 检查是否为模拟器
     *
     * @return
     */
    public static boolean checkEmulator(){
        try {
            boolean goldfish = getSystemProperty("ro.hardware").contains("goldfish");
            boolean emu = getSystemProperty("ro.kernel.qemu").length()>0;
            boolean sdk = getSystemProperty("ro.product.model").equals("sdk");
            if(emu || goldfish || sdk) {
                return true;
            }
        }catch(Exception e) {
        }
        return false;
    }

    private static String getSystemProperty(String name) throws Exception{
        Class systemPropertyClazz = Class.forName("android.os.SystemProperties");
        return (String)systemPropertyClazz.getMethod("get", new Class[]{String.class})
                .invoke(systemPropertyClazz, new Object[]{name});
    }

    public static class FileDirs {
        public static final String PUBLIC_MNSJ_DIR = Environment
                .getExternalStorageDirectory()+File.separator+"4399MNSJ";
        public static final String PIC_SAVE = buildPicDir();
        public static final String PIX_SAVE = buildPixDir();

        /**
         * 默认的存储目录
         */
        public static final String DEFAULT_STORAGE_ROOT = Environment
                .getExternalStorageDirectory()+"/Android/data/"+JApp.getContext().getPackageName()+"/files";

        /**
         * APK类型
         */
        public static final int DIR_TYPE_APK = 0;
        /**
         * APK下载目录
         */
        public static final String APK_DIR = buildDir("apk");

        private static String buildDir(String dirName){
            String dir = String.format("%s%s%s%s", DEFAULT_STORAGE_ROOT, File.separator, dirName, File.separator);
            File dirFolder = new File(dir);
            if(!dirFolder.exists()) {
                dirFolder.mkdirs();
            }
            return dir;
        }

        private static String buildPicDir(){
            String dir = String.format("%s%s%s", PUBLIC_MNSJ_DIR, File.separator, "pics");
            File dirFolder = new File(dir);
            if(!dirFolder.exists()) {
                dirFolder.mkdirs();
            }
            return dir;
        }

        private static String buildPixDir(){
            String dir = String.format("%s%s%s", PUBLIC_MNSJ_DIR, File.separator, "pixs");
            File dirFolder = new File(dir);
            if(!dirFolder.exists()) {
                dirFolder.mkdirs();
            }
            return dir;
        }

        public static String getDownloadAppPath(String url){
            return String.format("%s%s%s", APK_DIR, url.hashCode(), "_a");
        }

        public static String getDownloadAppPathByName(String name){
            return String.format("%s%s", APK_DIR, name);
        }
    }
}
