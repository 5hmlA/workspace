package com.a4399.funnycore.app.utill;


import android.os.Build;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;

import com.a4399.funnycore.BuildConfig;
import com.a4399.funnycore.JApp;
import com.a4399.funnycore.app.data.netservice.AccountManage;
import com.a4399.funnycore.utils.LogUtil;

import java.util.HashSet;

/**
 * cookie工具诶
 *
 * @author 徐智伟
 * @create 16/10/21
 */

public class CookieUtils {

    public static final String TAG = "CookieUtils";
    public static final String FORUM_COOKIE_KEY = BuildConfig.BBS_BASE_URL;

    /**
     * 将cookie同步到WebView
     */
    public static void syncForumCookieFromHeader(HashSet<String> headers){

        CookieSyncManager.createInstance(JApp.getContext());
        CookieManager cookieManager = CookieManager.getInstance();

        cookieManager.setAcceptCookie(true);
        cookieManager.removeSessionCookie();//移除
        cookieManager.removeAllCookie();

        for(String header : headers) {
            if(header.contains(".4399.cn")) {
                String[] cookieValues = header.split(";");
                for(String value : cookieValues) {
                    cookieManager.setCookie(FORUM_COOKIE_KEY, value);//如果没有特殊需求，这里只需要将session id以"key=value"形式作为cookie即可
                }
            }
        }
        LogUtil.debug(TAG, cookieManager.getCookie(FORUM_COOKIE_KEY));
        if(Build.VERSION.SDK_INT>=21) {
            CookieManager.getInstance().flush();
        }else {
            CookieSyncManager.getInstance().sync();
        }
    }
    /**
     * 将cookie同步到WebView
     */
    public static void syncWebCookie(String url){

        CookieSyncManager.createInstance(JApp.getContext());
        CookieManager cookieManager = CookieManager.getInstance();

        cookieManager.setAcceptCookie(true);
        cookieManager.removeSessionCookie();//移除
        cookieManager.removeAllCookie();

        StringBuilder sbCookie = new StringBuilder();//创建一个拼接cookie的容器,为什么这么拼接，大家查阅一下http头Cookie的结构
//        sbCookie.append("JSESSIONID=");//拼接sessionId
        sbCookie.append(AccountManage.getSingleton().getCookie());//拼接sessionId
        sbCookie.append(String.format(";domain=%s", ""));
        sbCookie.append(String.format(";path=%s", ""));
        String cookieValue = sbCookie.toString();
        cookieManager.setCookie(url, cookieValue);//为url设置cookie
        LogUtil.debug(TAG, cookieManager.getCookie(FORUM_COOKIE_KEY));
        if(Build.VERSION.SDK_INT>=21) {
            CookieManager.getInstance().flush();
        }else {
            CookieSyncManager.getInstance().sync();
        }
    }

    /**
     * 清除cookie
     */
    public static void removeCookie(){
        CookieSyncManager.createInstance(JApp.getContext());
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.removeAllCookie();
        CookieSyncManager.getInstance().sync();
    }

}
