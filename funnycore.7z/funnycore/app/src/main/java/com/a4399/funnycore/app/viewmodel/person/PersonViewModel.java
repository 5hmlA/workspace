package com.a4399.funnycore.app.viewmodel.person;

import android.app.Activity;
import android.view.View;
import com.a4399.funnycore.FcContents;
import com.a4399.funnycore.JApp;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.UserBean;
import com.a4399.funnycore.app.data.bean.download.GameDownloadTaskBean;
import com.a4399.funnycore.app.data.bean.home.GameDetailBean;
import com.a4399.funnycore.app.data.event.LoginEvent;
import com.a4399.funnycore.app.data.netservice.AccountManage;
import com.a4399.funnycore.app.download.BaseDownloadBean;
import com.a4399.funnycore.app.download.BaseDownloadManager;
import com.a4399.funnycore.app.download.DownloadCallBack;
import com.a4399.funnycore.app.download.DownloadStateInterface;
import com.a4399.funnycore.app.download.GameDownloadTaskManager;
import com.a4399.funnycore.app.utill.IntentUtil;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import com.a4399.funnycore.utils.ApkUtil;
import com.a4399.funnycore.utils.ResUtil;
import com.a4399.funnycore.utils.StringUtil;
import com.a4399.funnycore.utils.ToastUtil;
import io.reactivex.functions.Consumer;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import sandboxtool.sj4399.com.library_download.util.FileDownloadUtils;

/**
 * 文件描述：
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */

public class PersonViewModel extends BaseViewModel {

    // 个人信息数据
    private UserBean mUserBean;

    // 下载测试
    private BaseDownloadBean mBaseDownloadBean;

    // 本机所有安装游戏
    public List<GameDetailBean> mAllGameApp;

    private GameDownloadTaskBean gameDownloadTaskBean;
    BaseDownloadManager mDownloadManager;


    /**
     * 开始下载（测试）
     */
    public void startDownLoad(View view) {
        gameDownloadTaskBean.setDownLoadId(mDownloadManager.startDownLoad(gameDownloadTaskBean));
    }


    public DownloadCallBack mDownloadCallBack = new DownloadCallBack() {
        @Override public void updateProgress(String newProgress) {
            getBaseDownloadBean().setProgress(newProgress + "%");
            gameDownloadTaskBean.setProgress(newProgress + "%");
            notifyChange();
        }


        @Override public void updateState(int newState) {
            getBaseDownloadBean().setCurrentState(newState);
            gameDownloadTaskBean.setCurrentState(newState);
            if (newState == DownloadStateInterface.INSTALL) {
                ApkUtil.openApkFile(JApp.getContext(), getBaseDownloadBean().getPath());
            }
            GameDownloadTaskManager.getInstance().addDownLoadTask(gameDownloadTaskBean);
            notifyChange();
        }
    };


    /**
     * 暂停下载（测试）
     */
    public void stopDownLoad(View view) {
        mDownloadManager.stopDownLoad(gameDownloadTaskBean.getDownLoadId());
    }


    /**
     * 删除下载（测试）
     */
    public void deleteDownLoad(View view) {
        mDownloadManager.deleteDownLoad(gameDownloadTaskBean.getPath());
    }


    /**
     * 下载管理（测试）
     */
    public void openDownloadManage(View view) {
        IntentUtil.openDownloadManage(view, FcContents.DownloadManageType.DOWNLOAD_ING);
    }


    public BaseDownloadBean getBaseDownloadBean() {
        return mBaseDownloadBean;
    }


    public void setBaseDownloadBean(BaseDownloadBean baseDownloadBean) {
        mBaseDownloadBean = baseDownloadBean;
    }


    public UserBean getUserBean() {
        return mUserBean;
    }


    public void setUserBean(UserBean userBean) {
        mUserBean = userBean;
    }


    @Override public void initViewModelData() {
        // TODO 测试数据
        mBaseDownloadBean = new BaseDownloadBean();
        mBaseDownloadBean.setCurrentState(DownloadStateInterface.FREETIME);
        mBaseDownloadBean.setCallbackProgressCount(300);
        mBaseDownloadBean.setDir(false);
        mBaseDownloadBean.setMinIntervalUpdateSpeedMs(300);
        mBaseDownloadBean.setPath(
                FileDownloadUtils.getDefaultSaveRootPath() + File.separator + "tmpdir1111" + File.separator +
                        "LLS-v4.0-595-20160908-143200.apk");
        mBaseDownloadBean.setTag(6);
        mBaseDownloadBean.setApkUrl("http://cdn.llsapp.com/android/LLS-v4.0-595-20160908-143200.apk");
        mUserBean = new UserBean();
        mUserBean.setUid("http://www.sinohrm.com/wp-content/uploads/2016/05/meinv.jpg");
        setUserBean(mUserBean);

        gameDownloadTaskBean = new GameDownloadTaskBean();
        // 共同部分
        gameDownloadTaskBean.setIcon(
                "http://cdn.duitang.com/uploads/item/201603/06/20160306140033_NiUah.jpeg");
        gameDownloadTaskBean.setId("1");
        gameDownloadTaskBean.setName("game");
        gameDownloadTaskBean.setSize("12M");
        gameDownloadTaskBean.setVersion("1.2.2");
        // gameDetailBean.setUrl();
        gameDownloadTaskBean.setCurrentState(DownloadStateInterface.DOWNING);
        gameDownloadTaskBean.setCallbackProgressCount(300);
        gameDownloadTaskBean.setDir(false);
        gameDownloadTaskBean.setMinIntervalUpdateSpeedMs(300);
        // apk1
        gameDownloadTaskBean.setTag(1);
        gameDownloadTaskBean.setUrl(
                "http://shouji.360tpcdn.com/171221/2cdfd7e66ac5c01e2a2c5babb040ac9c/com.game.sgz.a360_830.apk");
        gameDownloadTaskBean.setApkName("com.game.sgz.a360_830.apk");
        gameDownloadTaskBean.setPath(
                FileDownloadUtils.getDefaultSaveRootPath() + File.separator + "tmpdir11" + File.separator +
                        gameDownloadTaskBean.getApkName());
        mDownloadManager = BaseDownloadManager.getInstence(gameDownloadTaskBean.getUrl());
        mDownloadManager.onDownloadListener(mDownloadCallBack);

        mAllGameApp = new ArrayList<>();
        GameDetailBean gameDetailBean1 = new GameDetailBean();
        gameDetailBean1.setName("我的世界");
        gameDetailBean1.setUpdate(true);
        gameDetailBean1.setIcon(
                "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2170745923,321319231&fm=27&gp=0.jpg");
        gameDetailBean1.setPackage_name("com.sj4399.mcpetool");
        mAllGameApp.add(gameDetailBean1);
        GameDetailBean gameDetailBean2 = new GameDetailBean();
        gameDetailBean2.setName("我的世界");
        gameDetailBean2.setUpdate(true);
        gameDetailBean2.setIcon(
                "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1515143938713&di=fc74fad9335d32d9f3b61267057e8290&imgtype=0&src=http%3A%2F%2Fnewsimg.5054399.com%2Fupimg%2Fadd_pic%2F14536897891.jpg");
        gameDetailBean2.setPackage_name("com.sj4399.mcpetool");
        mAllGameApp.add(gameDetailBean2);
        GameDetailBean gameDetailBean3 = new GameDetailBean();
        gameDetailBean3.setName("我的世界");
        gameDetailBean3.setUpdate(true);
        gameDetailBean3.setIcon(
                "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1515144226388&di=cd1ff02bd704d648bb959b46670a34b0&imgtype=0&src=http%3A%2F%2Ffile003.gao7.com%2Fg2%2FM00%2F00%2F90%2FEicAAFnPP1OAbA2dAADDMJXxo5A508.jpg%3Fw%3D500%26h%3D281");
        gameDetailBean3.setPackage_name("com.sj4399.mcpetool");
        mAllGameApp.add(gameDetailBean3);
        // mAllGameApp.add(gameDetailBean);
    }


    /**
     * 登录
     */
    public void onClickLogin(View view) {
        IntentUtil.openPersonalHomePage(view,"");
/*        AccountManage.getSingleton()
                     .toLogin((Activity) view.getContext())
                     .subscribe(new Consumer<LoginEvent>() {
                         @Override public void accept(LoginEvent loginEvent) throws Exception {
                             ToastUtil.showLong(loginEvent.loginSucceed + "");
                         }
                     });*/
    }


    @Override public List<BaseViewModelErrorInfo> verifyViewModel() {
        return null;
    }


    /**
     * 查看所有可更新的游戏
     */
    public void onOpenUpdateAbleGame(View view) {
        IntentUtil.openDownloadManage(view, getAllUpdateAbleGame(),
                FcContents.DownloadManageType.UPDATE_ABLE);
    }


    /**
     * 获取可更新的游戏
     */
    private List<GameDetailBean> getAllUpdateAbleGame() {
        if (mAllGameApp == null) {
            return null;
        }
        List<GameDetailBean> updateAbleList = new ArrayList<>();
        for (GameDetailBean gameDetailBean : mAllGameApp) {
            if (gameDetailBean.update) {
                updateAbleList.add(gameDetailBean);
            }
        }
        return updateAbleList;
    }


    /**
     * 获取可更新游戏的数量(带文本)
     */
    public String gameUpdateAbleCount() {
        List<GameDetailBean> updateAbleList = getAllUpdateAbleGame();
        if (updateAbleList == null) {
            return "";
        }
        return String.format(ResUtil.getString(R.string.game_update_able_count), updateAbleList.size());
    }
}
