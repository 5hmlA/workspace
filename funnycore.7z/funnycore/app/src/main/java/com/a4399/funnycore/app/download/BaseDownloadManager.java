package com.a4399.funnycore.app.download;

import android.webkit.DownloadListener;
import com.a4399.funnycore.app.data.bean.download.GameDownloadTaskBean;
import com.a4399.funnycore.utils.CalculationUtil;
import com.a4399.funnycore.utils.LogUtil;
import com.a4399.funnycore.utils.StringUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import sandboxtool.sj4399.com.library_download.BaseDownloadTask;
import sandboxtool.sj4399.com.library_download.FileDownloadSampleListener;
import sandboxtool.sj4399.com.library_download.FileDownloader;
import sandboxtool.sj4399.com.library_download.util.FileDownloadUtils;

/**
 * 文件描述：下载管理
 * Created by zhanlinjian2888 on 2017/12/20.
 * E-mail:zhanlinjian@4399inc.com
 */

public class BaseDownloadManager {

    // 默认回调数量
    private int defCallbackProgressTimes = 300;

    // 默认下载的最小间隔
    private int defMinIntervalUpdateSpeed = 400;

    // 下载回调序列
    private List<DownloadCallBack> mDownloadCallBackList;

    // apkurl对应一个下载实例
    private static Map<String, BaseDownloadManager> instance;


    /**
     * 获取管理实例
     * @param apkUrl
     * @return
     */
    public static BaseDownloadManager getInstence(String apkUrl) {
        if (instance == null) {
            instance = new HashMap<>();
        }
        if (instance.containsKey(apkUrl)) {
            for (String key : instance.keySet()) {
                BaseDownloadManager value = instance.get(key);
                return value;
            }
        }
        BaseDownloadManager manager = new BaseDownloadManager();
        instance.put(apkUrl, manager);
        return manager;
    }


    /**
     * 启动下载
     *
     * @param mGameDownloadTaskBean 下载基本数据，path值相同即可实现进度同步
     * @return -1：数据有误；其他：downloadId
     */
    public int startDownLoad(final GameDownloadTaskBean mGameDownloadTaskBean) {
        if (mGameDownloadTaskBean == null) {
            LogUtil.info("download abnormal info:", "baseDownloadBean should not null");
            return -1;
        }
        if (StringUtil.isEmpty(mGameDownloadTaskBean.getUrl())) {
            LogUtil.info("download abnormal info:", "not find url!!");
            return -1;
        }
        if (StringUtil.isEmpty(mGameDownloadTaskBean.getPath())) {
            LogUtil.info("download abnormal info:", "not find path!");
            return -1;
        }
        if (mGameDownloadTaskBean.getTag() == 0) {
            LogUtil.info("download abnormal info:", "download tag must not null!");
            return -1;
        }
        if (mGameDownloadTaskBean.getCallbackProgressCount() == 0) {
            mGameDownloadTaskBean.setCallbackProgressCount(defCallbackProgressTimes);
        }
        if (mGameDownloadTaskBean.getMinIntervalUpdateSpeedMs() == 0) {
            mGameDownloadTaskBean.setMinIntervalUpdateSpeedMs(defMinIntervalUpdateSpeed);
        }
        return FileDownloader.getImpl()
                             .create(mGameDownloadTaskBean.getUrl())
                             .setPath(mGameDownloadTaskBean.getPath(), mGameDownloadTaskBean.isDir())
                             .setCallbackProgressTimes(mGameDownloadTaskBean.getCallbackProgressCount())
                             .setMinIntervalUpdateSpeed(mGameDownloadTaskBean.getMinIntervalUpdateSpeedMs())
                             .setTag(mGameDownloadTaskBean.getTag())
                             .setListener(mFileDownloadSampleListener)
                             .start();
    }


    /**
     * 进度、状态的监听
     */
    public FileDownloadSampleListener mFileDownloadSampleListener = new FileDownloadSampleListener() {
        @Override protected void pending(BaseDownloadTask task, int soFarBytes, int totalBytes) {
            super.pending(task, soFarBytes, totalBytes);
            if (mDownloadCallBackList != null) {
                for (DownloadCallBack mCallBack : mDownloadCallBackList) {
                    mCallBack.updateState(DownloadStateInterface.WAIT);
                }
            }
        }


        @Override protected void progress(BaseDownloadTask task, int soFarBytes, int totalBytes) {
            super.progress(task, soFarBytes, totalBytes);
            if (soFarBytes == 0 || totalBytes == 0) {
                return;
            }
            if (mDownloadCallBackList != null) {
                for (DownloadCallBack mCallBack : mDownloadCallBackList) {
                    mCallBack.updateState(DownloadStateInterface.DOWNING);
                    mCallBack.updateProgress(CalculationUtil.divisionDecimal2(soFarBytes, totalBytes / 100));
                }
            }
        }


        @Override protected void error(BaseDownloadTask task, Throwable e) {
            super.error(task, e);
            if (mDownloadCallBackList != null) {
                for (DownloadCallBack mCallBack : mDownloadCallBackList) {
                    mCallBack.updateState(DownloadStateInterface.TRY_AGAIN);
                }
            }
        }


        @Override
        protected void connected(BaseDownloadTask task, String etag, boolean isContinue, int soFarBytes, int totalBytes) {
            super.connected(task, etag, isContinue, soFarBytes, totalBytes);
        }


        @Override protected void paused(BaseDownloadTask task, int soFarBytes, int totalBytes) {
            super.paused(task, soFarBytes, totalBytes);
            if (mDownloadCallBackList != null) {
                for (DownloadCallBack mCallBack : mDownloadCallBackList) {
                    mCallBack.updateState(DownloadStateInterface.PAUSE);
                }
            }
        }


        @Override protected void completed(BaseDownloadTask task) {
            super.completed(task);
            if (mDownloadCallBackList != null) {
                for (DownloadCallBack mCallBack : mDownloadCallBackList) {
                    mCallBack.updateProgress("100");
                    mCallBack.updateState(DownloadStateInterface.INSTALL);
                }
            }
        }


        @Override protected void warn(BaseDownloadTask task) {
            super.warn(task);
            // TODO 添加處理
        }
    };


    /**
     * 暂停下载
     *
     * @param downLoadId 下载id，和startDownLoad方法的返回值对应即可
     */
    public void stopDownLoad(int downLoadId) {
        try {
            FileDownloader.getImpl().pause(downLoadId);
        } catch (Exception e) {
            LogUtil.info("download error info:", "stopDownLoad error,downLoadId:" + downLoadId);
            e.printStackTrace();
        }
    }


    /**
     * 删除下载
     */
    public void deleteDownLoad(String filePath) {
        try {
            new File(filePath).delete();
            new File(FileDownloadUtils.getTempPath(filePath)).delete();
            if (mDownloadCallBackList != null) {
                for (DownloadCallBack mCallBack : mDownloadCallBackList) {
                    mCallBack.updateState(DownloadStateInterface.FREETIME);
                    mCallBack.updateProgress("0");
                }
            }
        } catch (Exception e) {
            LogUtil.info("download error info:", "stopDownLoad error,filePath:" + filePath);
            e.printStackTrace();
        }
    }


    /**
     * 注册下载监听
     */
    public void onDownloadListener(DownloadCallBack mDownloadCallBack) {
        if (mDownloadCallBackList == null) {
            mDownloadCallBackList = new ArrayList<>();
        }
        if (mDownloadCallBackList.contains(mDownloadCallBack)) {
            return;
        }
        mDownloadCallBackList.add(mDownloadCallBack);
    }
}
