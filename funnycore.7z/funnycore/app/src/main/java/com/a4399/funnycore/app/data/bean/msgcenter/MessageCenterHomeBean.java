package com.a4399.funnycore.app.data.bean.msgcenter;

import android.view.View;

import com.a4399.funnycore.R;
import com.a4399.funnycore.app.utill.IntentUtil;
import com.a4399.funnycore.utils.ResUtil;

/**
 * 描述:消息中心首页实体
 *
 * @author 罗远回
 * @since 2018年01月05日 16:33
 */

public class MessageCenterHomeBean{

  /**
   * 图标
   */
  private int iconId;
  /**
   * 标题
   */
  private String text;
  /**
   * 未读消息数量
   */
  private int msgCount;

  public MessageCenterHomeBean(int iconId, String text, int msgCount) {
    this.iconId = iconId;
    this.text = text;
    this.msgCount = msgCount;
  }

  public int getIconId() {
    return iconId;
  }

  public void setIconId(int iconId) {
    this.iconId = iconId;
  }

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  public String getMsgCount() {
    return msgCount+"";
  }

  public void setMsgCount(int msgCount) {
    this.msgCount = msgCount;
  }

  @Override
  public String toString() {
    return "MessageCenterHomeBean{" +
        "iconId=" + iconId +
        ", text='" + text + '\'' +
        ", msgCount=" + msgCount +
        '}';
  }

  /**
   * 点击消息中心的Item
   */
  public void clickMsgCenterItem(View view){
    if (text.equals(ResUtil.getString(R.string.replay_me))){
      IntentUtil.openMessageReplyMeActivity(view);
    }else if (text.equals(ResUtil.getString(R.string.new_fans))){
      IntentUtil.openMessageNewFansActivity(view);
    }else if (text.equals(ResUtil.getString(R.string.receive_praise))){
      IntentUtil.openMessageReceivePraiseActivity(view);
    }else if (text.equals(ResUtil.getString(R.string.system_notification))){
      IntentUtil.openMessageSysNotificationActivity(view);
    }
  }
}
