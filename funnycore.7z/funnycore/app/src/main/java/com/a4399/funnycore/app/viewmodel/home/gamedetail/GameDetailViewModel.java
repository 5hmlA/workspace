package com.a4399.funnycore.app.viewmodel.home.gamedetail;

import android.databinding.Bindable;
import com.a4399.funnycore.BR;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.home.GameDetail;
import com.a4399.funnycore.app.data.bean.home.GameInfo;
import com.a4399.funnycore.base.LoadMoreViewModel;
import java.util.HashMap;
import me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass;

/**
 * @another 江祖赟
 * @date 2018/1/2.
 */
public class GameDetailViewModel extends LoadMoreViewModel {

    {
        pageState.set(0);
    }


    //注册 detail info 图片的item 推荐游戏的item
    public static OnItemBindClass gameDetailBinding = new OnItemBindClass().regist(String.class, BR.prewPic, R.layout.item_gamedetail_prewpics)
                                                                           .regist(GameDetail.RecommendBean.class, BR.recomGames, R.layout.item_gamedetail_recomgames);
    @Bindable public GameInfo gameInfo;


    public void toGetData(HashMap mapParam) {
        //数据 由两个tab获取然后传过来
    }


    public void showGameDetail(GameInfo gameInfo) {
        if (this.gameInfo == null) {
            this.gameInfo = gameInfo;
            hideLoading();
            notifyPropertyChanged(BR.gameInfo);
        }
    }


    @Override protected void registItemTypes(OnItemBindClass<Object> multipleItems) {

    }

}
