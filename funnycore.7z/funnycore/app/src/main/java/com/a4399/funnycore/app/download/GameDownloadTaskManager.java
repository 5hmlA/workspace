package com.a4399.funnycore.app.download;

import com.a4399.funnycore.JApp;
import com.a4399.funnycore.app.data.bean.download.GameDownloadTaskBean;
import com.raizlabs.android.dbflow.sql.language.Select;
import java.util.List;
import sandboxtool.sj4399.com.library_download.util.FileDownloadUtils;

/**
 * 文件描述：任务管理，所有新增的apk下载需要添加到这
 * Created by zhanlinjian2888 on 2017/12/26.
 * E-mail:zhanlinjian@4399inc.com
 */

public class GameDownloadTaskManager {

    private static GameDownloadTaskManager mTaskManager;


    /**
     * 获取实例
     */
    public static synchronized GameDownloadTaskManager getInstance() {
        if (mTaskManager == null) {
            return mTaskManager = new GameDownloadTaskManager();
        }
        return mTaskManager;
    }


    /**
     * 新增一个下载任务
     */
    public void addDownLoadTask(final GameDownloadTaskBean mDownloadTaskBean) {
        try {
            String apkUrl = mDownloadTaskBean.getUrl();
            String path = FileDownloadUtils.getDefaultSaveFilePath(apkUrl);
            final int downloadId = FileDownloadUtils.generateId(apkUrl, path);
            mDownloadTaskBean.setTaskId(Long.valueOf(downloadId));
            List<GameDownloadTaskBean> allDownloadBean = getAllDownLoadTask();
            for (GameDownloadTaskBean mGameDownloadTaskBean : allDownloadBean) {
                // 重复的话去除之前下载记录
                if (mGameDownloadTaskBean.getPath().equals(mDownloadTaskBean.getPath())) {
                    mGameDownloadTaskBean.delete();
                }
            }
            mDownloadTaskBean.save();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 获取所有现在下载任务
     */
    public List<GameDownloadTaskBean> getAllDownLoadTask() {
        try {
            List<GameDownloadTaskBean> allDownloadBean = new Select().from(GameDownloadTaskBean.class)
                                                                     .queryList();
            return allDownloadBean;
            //  Box<GameDownloadTaskBean> beanBox = JApp.getBoxStore().boxFor(GameDownloadTaskBean.class);
            //  List<GameDownloadTaskBean> allDownloadBean = beanBox.query().build().find();
            // return allDownloadBean;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
