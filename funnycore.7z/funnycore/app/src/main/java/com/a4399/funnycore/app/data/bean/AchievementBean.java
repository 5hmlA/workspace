package com.a4399.funnycore.app.data.bean;

import com.google.gson.annotations.SerializedName;

/**
 * 文件描述：成就
 * Created by zhanlinjian2888 on 2018/1/8.
 * E-mail:zhanlinjian@4399inc.com
 */

public class AchievementBean {

    // 图标
    @SerializedName("icon") public String icon;

    // 是否完成
    @SerializedName("is_get") public boolean is_get;


    public String getIcon() {
        return icon;
    }


    public void setIcon(String icon) {
        this.icon = icon;
    }


    public boolean isIs_get() {
        return is_get;
    }


    public void setIs_get(boolean is_get) {
        this.is_get = is_get;
    }
}
