package com.a4399.funnycore.app.data.bean.headline;

import com.a4399.funnycore.app.data.bean.MsgCardBean;
import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @another 江祖赟
 * @date 2017/12/21.
 * 头条--某款游戏详情
 */
public class GameDetail {

    /**
     * detail : {"id":"id","title":"标题","pic":"图片地址","star":"星","points":"分数","follow":"关注数"}
     * list : [{"id":"id","type":"类型(1-资讯，2-视频)","title":"标题","content":"内容","pic":"图片","date":"发布时间（时间戳）","views":"访问数"}]
     */

    @SerializedName("detail") public DetailBean detail;
    @SerializedName("list") public List<MsgCardBean> list;

    public static class DetailBean {
        /**
         * id : id
         * title : 标题
         * pic : 图片地址
         * star : 星
         * points : 分数
         * follow : 关注数
         */
        @SerializedName("id") public String id;
        @SerializedName("title") public String title;
        @SerializedName("pic") public String pic;
        @SerializedName("star") public String star;
        @SerializedName("points") public String points;
        @SerializedName("follow") public String follow;
    }
}
