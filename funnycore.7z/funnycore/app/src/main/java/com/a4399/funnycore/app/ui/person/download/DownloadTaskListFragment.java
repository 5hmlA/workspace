package com.a4399.funnycore.app.ui.person.download;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.person.download.DownloadTaskListViewModel;
import com.a4399.funnycore.base.BaseListFragment;
import com.a4399.funnycore.databinding.FragmentDownloadTaskListBinding;

/**
 * 文件描述：下载管理-任务管理
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public class DownloadTaskListFragment extends BaseListFragment<DownloadTaskListViewModel> {

    /**
     * 获取fragment
     * @return
     */
    public static DownloadTaskListFragment getInstance() {
        DownloadTaskListFragment fragment = new DownloadTaskListFragment();
        return fragment;
    }


    @Override protected DownloadTaskListViewModel initModel() {
        return new DownloadTaskListViewModel();
    }


    @Override protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        FragmentDownloadTaskListBinding fragmentPersonHomeBinding = DataBindingUtil.inflate(inflater,
                R.layout.fragment_download_task_list, container, false);
        fragmentPersonHomeBinding.setDownloadTaskListViewModel(viewModel);
        return fragmentPersonHomeBinding;
    }


    @Override protected void initViewAndData() {

    }
}
