package com.a4399.funnycore.app.utill;


import com.a4399.funnycore.BuildConfig;
import com.a4399.funnycore.JApp;
import com.a4399.funnycore.utils.CheckHelper;
import com.a4399.funnycore.utils.DeviceUtil;
import com.a4399.funnycore.utils.Md5Util;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import static com.a4399.funnycore.Constants.DATA_PAGESIZE;


/**
 * @another 江祖赟
 * @date 2017/6/28.
 */
public class ParamWrapper {

    //todo KEY 拆分成多部分 拼接  最好搞到jni里面
    public static final String key = "4dd81e345d04e11a";

    /**
     * 加密需要加密的参数
     *
     * @return
     */
    public static Map<String,Object> paramWrapper(){
        return paramWrapper(new HashMap<String,Object>());
    }

    /**
     * 加入 签名 参数
     *
     * @param key
     * @param value
     * @return
     */
    public static Map<String,Object> paramWrapper(String key, Object value){
        HashMap<String,Object> param = new HashMap<>();
        if(CheckHelper.checkObjects(value)) {
            param.put(key, value);
        }
        return paramWrapper(param);
    }

    /**
     * 加入 签名 参数
     *
     * @param param
     * @return
     */
    public static Map<String,Object> paramWrapper(Map<String,Object> param){
        param.put("version", DeviceUtil.getVersionName(JApp.getContext(),JApp.getContext().getPackageName()));
        String timestamp = String.valueOf(System.currentTimeMillis()/1000);
        param.put("timestamp", timestamp);
        TreeMap<String,Object> treeMap = new TreeMap<>(param);
        Collection<Object> values = treeMap.values();
        param.put("sign", getSign(values.toArray()));
        if(BuildConfig.DEBUG) {
            param.put("debug", "1");
        }
        return param;
    }

    /**
     * 加入页码 不 签名
     *
     * @param current
     * @return
     */
    public static Map<String,Object> pageWrapper(String key, Object value, long current){
        return pageWrapper(paramWrapper(key, value),current);
    }

    public static Map<String,Object> pageWrapper2(String key, Object value, long lastindex){
        return pageWrapper2(paramWrapper(key, value), lastindex);
    }

    /**
     * 加入页码 不 签名
     *
     * @param param
     * @param current
     * @return
     */
    public static Map<String,Object> pageWrapper(Map<String,Object> param, long current){
        param.put("pagesize", String.valueOf(DATA_PAGESIZE));
        param.put("page", current);
        return param;
    }

    public static Map<String,Object> pageWrapper2(Map<String,Object> param, long lastindex){
        param.put("pagesize", String.valueOf(DATA_PAGESIZE));
        if(lastindex > 1) {
            param.put("lastindex", lastindex);
        }
        return param;
    }

    /**
     * 加入页码 不 签名
     *
     * @param current
     * @return
     */
    public static Map<String,Object> pageWrapper(long current){
//        Map<String,Object> param = paramWrapper();
        return pageWrapper(paramWrapper(),current);
//        param.put("pagesize", String.valueOf(DATA_PAGESIZE));
//        param.put("page", current);
//        return param;
    }

    private static String getSign(Object... signd){
        StringBuilder sb = new StringBuilder();
        for(Object s : signd) {
            sb.append(s).append("||");
        }
        sb.append(key).append(BuildConfig.SIGN_KEY1);
        return Md5Util.md5(sb.toString());
    }

    public static String getMD5(String str){
        try {
            // 生成一个MD5加密计算摘要
            MessageDigest md = MessageDigest.getInstance("MD5");
            // 计算md5函数
            md.update(str.getBytes());
            // digest()最后确定返回md5 hash值，返回值为8为字符串。因为md5 hash值是16位的hex值，实际上就是8位的字符
            // BigInteger函数则将8位的字符串转换成16位hex值，用字符串来表示；得到字符串形式的hash值
            return new BigInteger(1, md.digest()).toString(16);
        }catch(Exception e) {
            throw new RuntimeException("MD5加密出现错误");
        }
    }
}
