package com.a4399.funnycore.app.viewmodel.person;

import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import java.util.List;

/**
 * 文件描述：成就解锁
 * Created by zhanlinjian2888 on 2018/1/4.
 * E-mail:zhanlinjian@4399inc.com
 */

public class AchieveUnlockViewModel extends BaseViewModel {
    @Override public void initViewModelData() {

    }


    @Override public List<BaseViewModelErrorInfo> verifyViewModel() {
        return null;
    }
}
