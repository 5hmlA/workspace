package com.a4399.funnycore.app.viewmodel.message;

import com.a4399.funnycore.BR;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.msgcenter.MessageCenterHomeBean;
import com.a4399.funnycore.base.LoadMoreViewModel;

import java.util.HashMap;

import me.tatarka.bindingcollectionadapter2.collections.JObservableList;
import me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass;

/**
 * 描述:消息之收到的回复ViewModel
 *
 * @author 罗远回
 * @since 2018年01月08日 16:52
 */

public class MessageReplyMeViewModel extends LoadMoreViewModel {

  private JObservableList refreshList = new JObservableList();

  @Override protected void registItemTypes(OnItemBindClass<Object> multipleItems) {
    // 消息中心
    multipleItems.regist(MessageCenterHomeBean.class, BR.msghome,
        R.layout.item_message_center_home);
  }


  @Override public void toGetData(HashMap mapParam) {
    // 加载数据
    refreshedAllData(refreshList);
  }

  public MessageReplyMeViewModel() {
  }
}
