package com.a4399.funnycore;

/**
 * 文件描述：全局常量
 * Created by zhanlinjian2888 on 2018/1/3.
 * E-mail:zhanlinjian@4399inc.com
 */

public final class FcContents {

    /**
     * 跳转携带数据
     */
    public static class Extra{
        // 可更新的游戏
        public static String ALL_UPDATEABLE_GAME_LIST="all_updateable_game_list";
        // 进入下载管理默认显示的
        public static String DOWNLOAD_MANAGE_DEF_TAB= "download_manage_def_tab";
        // 个人id
        public static String USER_ID="user_id";
    }

    /**
     * 下载管理tab
     */
    public static class DownloadManageType{
        // 下载中
        public static int DOWNLOAD_ING=0;
        // 可更新
        public static int UPDATE_ABLE=1;
    }


}
