package com.a4399.funnycore.app.viewmodel.person;

import android.databinding.Bindable;
import com.a4399.funnycore.app.data.bean.UserBean;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import java.util.List;

/**
 * 文件描述：
 * Created by zhanlinjian2888 on 2017/12/19.
 * E-mail:zhanlinjian@4399inc.com
 */

public class PersonDataUpdateViewModel extends BaseViewModel {

    // 用户基本信息
    private UserBean mUserBean;


    @Bindable public UserBean getUserBean() {
        return mUserBean;
    }


    public void setUserBean(UserBean userBean) {
        mUserBean = userBean;
    }


    @Override public void initViewModelData() {

    }

    @Override public List<BaseViewModelErrorInfo> verifyViewModel() {
        return null;
    }
}
