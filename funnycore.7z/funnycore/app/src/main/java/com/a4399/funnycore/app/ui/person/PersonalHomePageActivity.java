package com.a4399.funnycore.app.ui.person;

import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.person.PersonalHomePageViewModel;
import com.a4399.funnycore.base.BaseActivity;
import com.a4399.funnycore.databinding.ActivityPersonalHomePageBinding;

import static android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;

/**
 * 文件描述：个人主页
 * Created by zhanlinjian2888 on 2018/1/4.
 * E-mail:zhanlinjian@4399inc.com
 */

public class PersonalHomePageActivity extends BaseActivity<PersonalHomePageViewModel> {

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        super.onCreate(savedInstanceState);
    }


    @Override protected PersonalHomePageViewModel initModel() {
        return new PersonalHomePageViewModel();
    }


    @Override protected void initBinding() {
        ActivityPersonalHomePageBinding activityPersonalHomePageBinding = DataBindingUtil.setContentView(this,
                R.layout.activity_personal_home_page);
        activityPersonalHomePageBinding.setPersonalHomePageViewModel(viewModel);
    }


    @Override protected void initViewAndData() {

    }
}
