package com.a4399.funnycore.app.data.bean.comment;

import com.google.gson.annotations.SerializedName;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 2017/5/10
 */

public class ReplyItemEntity {
    @SerializedName("id") public String id;
    @SerializedName("uid") public String uid;
    @SerializedName("username") public String username;
    @SerializedName("timeu") public String timeu;
    @SerializedName("time") public String time;
    @SerializedName("ip") public String ip;
    @SerializedName("channel") public String channel;
    @SerializedName("user_agent") public String userAgent;
    @SerializedName("reply") public String reply;

    public ReplyItemEntity(){
    }

    public ReplyItemEntity(String username,String uid, String timeu, String reply){
        this.username = username;
        this.uid = uid;
        this.timeu = timeu;
        this.reply = reply;
    }

    @Override
    public String toString(){
        return "ReplyItemEntity{"+"id='"+id+'\''+", uid='"+uid+'\''+", username='"+username+'\''+", timeu='"+timeu+'\''+", time='"+time+'\''+", ip='"+ip+'\''+", channel='"+channel+'\''+", userAgent='"+userAgent+'\''+", reply='"+reply+'\''+'}';
    }

}
