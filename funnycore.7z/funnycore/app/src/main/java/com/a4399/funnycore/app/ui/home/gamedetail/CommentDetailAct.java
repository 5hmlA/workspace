package com.a4399.funnycore.app.ui.home.gamedetail;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Build;
import android.support.design.widget.AppBarLayout;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import april.yun.widget.JToolbar;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.home.CommonDetail;
import com.a4399.funnycore.app.viewmodel.home.gamedetail.CommentDetailViewModel;
import com.a4399.funnycore.base.BaseListActivity;
import com.a4399.funnycore.databinding.ActivityCommentDetailBinding;
import com.a4399.funnycore.utils.ToastUtil;
import java.util.HashMap;

public class CommentDetailAct extends BaseListActivity<CommentDetailViewModel> implements AppBarLayout.OnOffsetChangedListener, TextWatcher, TextView.OnEditorActionListener {

    private AppBarLayout mAppbar;
    private LinearLayout mCommDetailGameToolbar;
    private Dialog mReplyDialog;
    private View mReplyPublish;
    private EditText mCommentContent;
    private String mToReplayUid;


    public static void startAct4View(View view) {
        Context context = view.getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                Activity activity = ((Activity) context);
                Intent intent = new Intent(activity, CommentDetailAct.class);
                //intent.putExtra(SEARCH_TYPE, search_type);
                activity.startActivity(intent);
                //ActivityCompat.startActivity(activity, intent, ActivityOptionsCompat.makeSceneTransitionAnimation(activity).toBundle());
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
    }


    @Override protected CommentDetailViewModel initModel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        return new CommentDetailViewModel();
    }


    @Override protected JToolbar initBinding() {
        ActivityCommentDetailBinding commentDetailBinding = DataBindingUtil.setContentView(this, R.layout.activity_comment_detail);
        commentDetailBinding.setCommentDetailViewModel(viewModel);
        mAppbar = commentDetailBinding.appbar;
        mCommDetailGameToolbar = commentDetailBinding.commDetailGameToolbar;
        return commentDetailBinding.toolbar;
    }


    @Override protected void initToolBar() {
        super.initToolBar();
        mToolbar.setRightIcon(R.drawable.btn_share_38_darkgray).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ToastUtil.showShort("分享");
            }
        });
    }


    @Override protected HashMap putParam() {
        return new HashMap();
    }


    @Override protected void initViewAndData() {
        setTitle("");
        mToolbar.setDivideLineColor(Color.BLACK);
        mAppbar.addOnOffsetChangedListener(this);
    }


    @Override public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        float alpha = Math.abs(verticalOffset * 1f / appBarLayout.getTotalScrollRange());
        mCommDetailGameToolbar.setAlpha(alpha);
    }


    public void showGameHead(View view) {
        if (view.getAlpha() > 0) {
            mAppbar.setExpanded(true);
        }
    }


    //底部的评论按钮
    public void publishReply(View view) {
        CommonDetail.ReplyDetail replyDetail = new CommonDetail.ReplyDetail();
        replyDetail.addTime = String.valueOf(System.currentTimeMillis() / 1000);
        replyDetail.content = "刚发布的评论";
        viewModel.publishReply(replyDetail);
    }


    /**
     * 回复谁
     */
    public void showReplyDialog(String toReplayName, String toReplayUid) {
        mToReplayUid = toReplayUid;
        if (mReplyDialog == null) {
            mReplyDialog = new Dialog(this, R.style.transDialogStyle);
            mReplyDialog.setContentView(R.layout.dialog_game_comment_reply);
            mReplyDialog.setCanceledOnTouchOutside(true);
            Window window = mReplyDialog.getWindow();
            window.setGravity(Gravity.BOTTOM);
            window.setLayout(-1, -2);
            window.setWindowAnimations(R.style.iosBottomAniStyle);
            window.getDecorView().setPadding(0, 0, 0, 0);
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN |
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

            mCommentContent = mReplyDialog.findViewById(R.id.dialog_game_comment_content);
            mCommentContent.setOnEditorActionListener(this);
            mCommentContent.addTextChangedListener(this);
            mReplyDialog.findViewById(R.id.dialog_game_comment_emoji).setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ToastUtil.showShort("lalal");
                }
            });
            mReplyPublish = mReplyDialog.findViewById(R.id.dialog_game_comment_publish);
            mReplyPublish.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Editable text = mCommentContent.getText();
                    toPublishComment("发布" + text);
                }
            });
        }
        if (!TextUtils.isEmpty(toReplayName)) {
            mCommentContent.setHint("回复：" + toReplayName);
        }
        mReplyDialog.show();
    }


    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }


    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {

    }


    @Override public void afterTextChanged(Editable s) {
        mReplyPublish.setEnabled(!TextUtils.isEmpty(s));
    }


    @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_SEND && !TextUtils.isEmpty(v.getText())) {
            toPublishComment(v.getText().toString());
            return true;
        }
        else {
            return false;
        }
    }


    private void toPublishComment(String message) {
        mToReplayUid = null;//评价之后重置
        ToastUtil.showShort(message);
    }
}
