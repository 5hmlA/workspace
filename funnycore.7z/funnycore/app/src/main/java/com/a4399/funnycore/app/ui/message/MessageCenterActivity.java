package com.a4399.funnycore.app.ui.message;

import android.databinding.DataBindingUtil;
import android.view.View;

import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.message.MessageCenterViewModel;
import com.a4399.funnycore.base.BaseListActivity;
import com.a4399.funnycore.databinding.ActivityMessageCenterBinding;
import com.a4399.funnycore.utils.ResUtil;

import java.util.HashMap;

/**
 * 描述:消息中心的Activity
 *
 * @author 罗远回
 * @since 2018年01月05日 11:55
 */

public class MessageCenterActivity extends BaseListActivity<MessageCenterViewModel>{


  @Override
  protected MessageCenterViewModel initModel() {
    return new MessageCenterViewModel();
  }

  @Override
  protected View initBinding() {
    ActivityMessageCenterBinding messageCenterBinding =
        DataBindingUtil.setContentView(this,R.layout.activity_message_center);
    messageCenterBinding.setMcviewmodel(viewModel);
    return messageCenterBinding.toolbar;
  }

  @Override
  protected HashMap putParam() {
    return new HashMap();
  }

  @Override
  protected void initToolBar() {
    super.initToolBar();
    mToolbar.setTitle(ResUtil.getString(R.string.message_center_title));
  }
}
