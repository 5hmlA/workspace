package com.a4399.funnycore.app.ui.message;

import android.databinding.DataBindingUtil;
import android.view.View;

import com.a4399.funnycore.R;
import com.a4399.funnycore.app.viewmodel.message.MessageSysNotificationViewModel;
import com.a4399.funnycore.base.BaseListActivity;
import com.a4399.funnycore.databinding.ActivityMessageSysNotificationBinding;
import com.a4399.funnycore.utils.ResUtil;

import java.util.HashMap;

/**
 * 描述:消息之系统通知Activity
 *
 * @author 罗远回
 * @since 2018年01月08日 16:46
 */

public class MessageSysNotificationActivity extends BaseListActivity<MessageSysNotificationViewModel> {


  @Override
  protected MessageSysNotificationViewModel initModel() {
    return new MessageSysNotificationViewModel();
  }

  @Override
  protected View initBinding() {
    ActivityMessageSysNotificationBinding messageSysNotificationBinding =
        DataBindingUtil.setContentView(this, R.layout.activity_message_sys_notification);
    messageSysNotificationBinding.setMsnviewmodel(viewModel);
    return messageSysNotificationBinding.toolbar;
  }

  @Override
  protected HashMap putParam() {
    return new HashMap();
  }

  @Override
  protected void initToolBar() {
    super.initToolBar();
    mToolbar.setTitle(ResUtil.getString(R.string.system_notification));
  }
}
