package com.a4399.funnycore.app.data.bean.headline;

import com.a4399.funnycore.app.data.bean.CarouselBean;
import com.a4399.funnycore.app.data.bean.MsgCardBean;
import com.a4399.funnycore.app.data.bean.TagBean;
import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * @another 江祖赟
 * @date 2017/12/21.
 * 头条 首页
 */
public class home {

    @SerializedName("carousel") public List<CarouselBean> carousel;
    @SerializedName("tag") public List<TagBean> tag;
    @SerializedName("list") public List<MsgCardBean> list;
}
