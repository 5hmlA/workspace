package com.a4399.funnycore.app.viewmodel.person.download;

import android.view.View;
import com.a4399.funnycore.app.data.bean.home.GameDetailBean;
import com.a4399.funnycore.utils.ApkUtil;
import me.tatarka.bindingcollectionadapter2.itembindings.ExtrasBindViewModel;

/**
 * 文件描述：本机游戏item
 * Created by zhanlinjian2888 on 2017/12/28.
 * E-mail:zhanlinjian@4399inc.com
 */

public class ItemLocalGameViewModel extends ExtrasBindViewModel {

    // 数据
    private GameDetailBean mGameDetailBean;


    /**
     * 打开游戏
     */
    public void openGame(View view) {
        ApkUtil.startAppWithPackageName(view, mGameDetailBean.getPackage_name());
    }


    public GameDetailBean getGameDetailBean() {
        return mGameDetailBean;
    }


    public void setGameDetailBean(GameDetailBean gameDetailBean) {
        mGameDetailBean = gameDetailBean;
    }
}
