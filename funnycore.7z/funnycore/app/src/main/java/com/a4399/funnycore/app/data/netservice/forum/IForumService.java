package com.a4399.funnycore.app.data.netservice.forum;


import com.a4399.funnycore.app.data.bean.ForumResponseData;

import io.reactivex.Observable;

/**
 * 论坛service
 *
 * @author 徐智伟
 * @create 2017/2/24
 */

public interface IForumService {

  /**
   * 刷新cookie
   */
  Observable<ForumResponseData> refreshUserCookie(String uid, String accessToken);

  /**
   * 修改头像
   * @param imagePath 图片地址
   * @return
   */
  Observable<ForumResponseData> modifyAvatar(String imagePath);

  /**
   * 修改昵称
   * @param nickName 新的用户昵称
   * @return
   */
  Observable<ForumResponseData> modifyNickName(String nickName);
}
