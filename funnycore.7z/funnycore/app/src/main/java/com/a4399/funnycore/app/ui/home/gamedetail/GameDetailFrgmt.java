package com.a4399.funnycore.app.ui.home.gamedetail;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.a4399.funnycore.Constants;
import com.a4399.funnycore.app.data.bean.home.GameDetail;
import com.a4399.funnycore.app.data.bean.home.GameInfo;
import com.a4399.funnycore.base.LazyFragment;
import com.a4399.funnycore.databinding.FragmentGameDetailBinding;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import jonas.jlayout.MultiStateLayout;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GameDetailFrgmt#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GameDetailFrgmt extends LazyFragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private FragmentGameDetailBinding mGameDetailBinding;
    private MultiStateLayout mStateLayout;


    public GameDetailFrgmt() {
        // Required empty public constructor
    }


    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment GameDetailFrgmt.
     */
    // TODO: Rename and change types and number of parameters
    public static GameDetailFrgmt newInstance(String param1, String param2) {
        GameDetailFrgmt fragment = new GameDetailFrgmt();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }


    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    @Override public void firstUserVisibile() {
        //获取 游戏详情数据
        //参数需要有 当前显示的是 详情还是 评论
        Observable.just(0).delay(2, TimeUnit.SECONDS).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer<Integer>() {
            @Override public void accept(Integer integer) throws Exception {
                GameDetail gameDetail = new GameDetail();
                gameDetail.info = new GameInfo();
                gameDetail.detail = new GameDetail.DetailBean();
                setGameDetailData(gameDetail.detail);
                ((GameDetailAct) mContext).getViewModel().showGameDetail(gameDetail.info);
                mStateLayout.showStateSucceed();
            }
        });
    }


    @Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mGameDetailBinding = FragmentGameDetailBinding.inflate(inflater);
        mStateLayout = mGameDetailBinding.stateLayout;
        return mGameDetailBinding.getRoot();
    }


    public void setGameDetailData(GameDetail.DetailBean data) {
        mGameDetailBinding.setGameDetail(data);
        data.gamePics.addAll(Arrays.asList(Constants.Temp.url1, Constants.Temp.url2, Constants.Temp.url3));
        data.recimGames.addAll(Arrays.asList(new GameDetail.RecommendBean(), new GameDetail.RecommendBean(), new GameDetail.RecommendBean()));
    }
}
