package com.a4399.funnycore.app.viewmodel.person;

import android.view.View;
import com.a4399.funnycore.app.data.bean.AccountBean;
import com.a4399.funnycore.app.data.bean.AchievementBean;
import com.a4399.funnycore.app.data.bean.UserBean;
import com.a4399.funnycore.app.ui.person.PersonalHomePageActivity;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import com.a4399.funnycore.utils.ContextUtil;
import java.util.List;

/**
 * 文件描述：个人主页
 * Created by zhanlinjian2888 on 2018/1/4.
 * E-mail:zhanlinjian@4399inc.com
 */

public class PersonalHomePageViewModel extends BaseViewModel {

    // 页面数据
    public UserBean mUserBean;


    @Override public void initViewModelData() {
        // 判断是否是本人
        // 读取库表获取数据
        mUserBean = new UserBean();
        mUserBean.setUid("http://www.sinohrm.com/wp-content/uploads/2016/05/meinv.jpg");
        mUserBean.setIdentity(true);
        mUserBean.setSignature("你好，我是alien！");
        mUserBean.setLevel(2);
        mUserBean.setFans(36);
        mUserBean.setFollows(20);
        mUserBean.setComment_num(10);
        mUserBean.setPlayed_num(20);
        mUserBean.setFollow_num(30);
        mUserBean.setDynamic_num(40);
        AchievementBean achievementBean = new AchievementBean();
        achievementBean.setIcon("http://www.sinohrm.com/wp-content/uploads/2016/05/meinv.jpg");
        achievementBean.setIs_get(true);
        mUserBean.setAchievement(achievementBean);
    }


    @Override public List<BaseViewModelErrorInfo> verifyViewModel() {
        return null;
    }


    /**
     * 返回
     */
    public void onBack(View view) {
        ((PersonalHomePageActivity) ContextUtil.getContextByView(view)).finish();
    }


    /**
     * 编辑用户信息
     */
    public void onEditInfo(View view) {
        //((PersonalHomePageActivity) ContextUtil.getContextByView(view)).finish();
    }
}
