package com.a4399.funnycore.app.data.bean.comment;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 2017/5/10
 */

public class CommentListEntity {

  @SerializedName("num")
  public int num;
  @SerializedName("content")
  public List<CommentItemEntity> content;

  @Override
  public String toString() {
    return "CommentListEntity{" +
        "num=" + num +
        ", content=" + content +
        '}';
  }
}
