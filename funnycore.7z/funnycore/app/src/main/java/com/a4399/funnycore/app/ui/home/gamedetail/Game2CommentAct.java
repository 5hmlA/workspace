package com.a4399.funnycore.app.ui.home.gamedetail;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import april.yun.widget.JToolbar;
import com.a4399.funnycore.JApp;
import com.a4399.funnycore.R;
import com.a4399.funnycore.base.BaseActivity;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.databinding.ActivityGame2CommentBinding;
import com.a4399.funnycore.utils.ToastUtil;
import com.a4399.funnycore.widget.JRatingBar;
import jonas.jlayout.OnStateClickListener;

public class Game2CommentAct extends BaseActivity implements TextWatcher, JRatingBar.OnStarChangeListener, OnStateClickListener {

    private static String sContent;
    private static float sScore;
    private static String sGameID;
    private ActivityGame2CommentBinding mGame2CommentBinding;


    public static void startAct4View(View view, String content, float score, String gameID) {
        //todo 前提：需玩过或预约或已安装该游戏方可参与评价。
        sContent = content;
        sScore = score;
        sGameID = gameID;
        Context context = view.getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                Activity activity = ((Activity) context);
                Intent intent = new Intent(activity, Game2CommentAct.class);
                //intent.putExtra(SEARCH_TYPE, search_type);
                activity.startActivity(intent);
                //ActivityCompat.startActivity(activity, intent, ActivityOptionsCompat.makeSceneTransitionAnimation(activity).toBundle());
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
    }


    @Override protected BaseViewModel initModel() {
        return null;
    }


    @Override protected void initBinding() {
        mGame2CommentBinding = DataBindingUtil.setContentView(this, R.layout.activity_game2_comment);
        mToolbar = (JToolbar) mGame2CommentBinding.toolbar;
        mGame2CommentBinding.outstatelayout.setOnStateClickListener(this);
        mGame2CommentBinding.outstatelayout.showStateSucceed();
    }


    @Override protected void initViewAndData() {
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.btn_close_38_darkgray);
        mGame2CommentBinding.etContent.addTextChangedListener(this);
        mGame2CommentBinding.jrbSetscore.setStarChangeLister(this);
        setTitle("发布评价");
        if (TextUtils.isEmpty(sContent)) {
            //第一次发布评价
            mGame2CommentBinding.publishComment.setEnabled(false);
        }
        else {
            //更新评价
            mGame2CommentBinding.publishComment.setSelected(true);
            //mGame2CommentBinding.publishComment.setBackgroundResource(R.drawable.statebg_gamebook_act);
            mGame2CommentBinding.publishComment.setText("更新");
            mGame2CommentBinding.jrbSetscore.setRating(sScore);
            mGame2CommentBinding.etContent.setText(sContent);
            mGame2CommentBinding.etContent.setSelection(sContent.length());
        }
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                finish();
            }
        });
    }


    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }


    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {

    }


    @Override public void afterTextChanged(Editable s) {
        mGame2CommentBinding.publishComment.setEnabled(!TextUtils.isEmpty(s));
    }


    public void publishComment(View view) {
        topublish_update();
    }


    private void topublish_update() {
        String content = mGame2CommentBinding.etContent.getText().toString();
        float rating = mGame2CommentBinding.jrbSetscore.getRating();
        ToastUtil.showShort("发布或更行");
    }


    @Override public void onStarChange(Float mark) {
        if (mark > 0) {
            mGame2CommentBinding.xxtip.setText(JApp.findString(R.string.game_comment_publish_showstar, mark));
        }
        else {
            mGame2CommentBinding.xxtip.setText(JApp.findString(R.string.game_comment_publish_startip));
        }
    }


    @Override public void onRetry(int layoutState) {
        topublish_update();
    }


    @Override public void onLoadingCancel() {

    }
}
