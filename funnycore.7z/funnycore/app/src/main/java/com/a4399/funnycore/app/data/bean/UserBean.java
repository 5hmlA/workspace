package com.a4399.funnycore.app.data.bean;

import android.databinding.BaseObservable;
import com.a4399.funnycore.app.data.database.DbFlowManager;
import com.google.gson.annotations.SerializedName;
import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.structure.BaseModel;

import static com.a4399.funnycore.app.utill.Data2UIhelper.getMiddlePortrait;

/**
 * @another 江祖赟
 * @date 2017/6/30.
 */
@Table(database = DbFlowManager.class) public class UserBean extends BaseModel {

    @Column public String avatar;
    /**
     * uid : 1
     * nickname : 昵称
     * miniid : 大于0即为有绑定的迷你号
     * follows : 关注数量
     * isFans : 粉丝数量
     * "newfans":"新粉丝数量",
     * isFollow : 是否已关注对方(true|false)
     * isFans : 对方是否已关注自己(true|false)
     * isSelf : 是否自身信息,自身的话不显示是否关注的关系
     */
    @PrimaryKey(autoincrement = true) @Column public long id;
    @Column public String uid;
    @Column public String nickname;
    @Column public int follows;
    @Column public int fans;
    @Column public int newfans;
    @Column public boolean isFollow;
    @Column public boolean isFans;
    @Column public boolean isSelf;

    // 是否认证
    @SerializedName("identity") public boolean identity;
    // 签名
    @SerializedName("signature") public String signature;
    // 等级
    @SerializedName("level") public int level;
    // 评价的游戏数量
    @SerializedName("comment_num") public int comment_num;
    // 玩过的游戏数量
    @SerializedName("played_num") public int played_num;
    // 关注的游戏数量
    @SerializedName("follow_num") public int follow_num;
    // 动态数量
    @SerializedName("dynamic_num") public int dynamic_num;

    // 成就
    @SerializedName("achievement") public AchievementBean achievement;


    public UserBean updateUserInfo(UserBean newbean) {
        follows = newbean.getFollows();
        fans = newbean.getFans();
        nickname = newbean.getNickname();
        return this;
    }


    public AchievementBean getAchievement() {
        return achievement;
    }


    public void setAchievement(AchievementBean achievement) {
        this.achievement = achievement;
    }


    public int getComment_num() {
        return comment_num;
    }


    public void setComment_num(int comment_num) {
        this.comment_num = comment_num;
    }


    public int getPlayed_num() {
        return played_num;
    }


    public void setPlayed_num(int played_num) {
        this.played_num = played_num;
    }


    public int getFollow_num() {
        return follow_num;
    }


    public void setFollow_num(int follow_num) {
        this.follow_num = follow_num;
    }


    public int getDynamic_num() {
        return dynamic_num;
    }


    public void setDynamic_num(int dynamic_num) {
        this.dynamic_num = dynamic_num;
    }


    public int getLevel() {
        return level;
    }


    public void setLevel(int level) {
        this.level = level;
    }


    public boolean isIdentity() {
        return identity;
    }


    public void setIdentity(boolean identity) {
        this.identity = identity;
    }


    public String getSignature() {
        return signature;
    }


    public void setSignature(String signature) {
        this.signature = signature;
    }


    public String getAvatar() {
        return getMiddlePortrait(uid);
    }


    public String getUid() {
        return uid;
    }


    public void setUid(String uid) {
        this.uid = uid;
    }


    public String getNickname() {
        return nickname;
    }


    public void setNickname(String nickname) {
        this.nickname = nickname;
    }


    public int getFollows() {
        return follows;
    }


    public void setFollows(int follows) {
        this.follows = follows;
    }


    public int getFans() {
        return fans;
    }


    public void setFans(int fans) {
        this.fans = fans;
    }


    public boolean isFollow() {
        return isFollow;
    }


    public void setFollow(boolean follow) {
        isFollow = follow;
    }


    public boolean isFans() {
        return isFans;
    }


    public void setFans(boolean fans) {
        isFans = fans;
    }


    public boolean isSelf() {
        return isSelf;
    }


    public void setSelf(boolean self) {
        isSelf = self;
    }


    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserBean userBean = (UserBean) o;

        if (!uid.equals(userBean.uid)) {
            return false;
        }
        if (nickname == null || !nickname.equals(userBean.nickname)) {
            return false;
        }
        return false;
    }


    @Override public int hashCode() {
        int result = uid.hashCode();
        result = 31 * result + nickname.hashCode();
        return result;
    }


    public int getNewfans() {
        return newfans;
    }
}
