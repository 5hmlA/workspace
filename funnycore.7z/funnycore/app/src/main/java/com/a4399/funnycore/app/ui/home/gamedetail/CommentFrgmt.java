package com.a4399.funnycore.app.ui.home.gamedetail;

import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.a4399.funnycore.app.data.bean.home.GameDetail;
import com.a4399.funnycore.app.viewmodel.home.gamedetail.CommentViewModel;
import com.a4399.funnycore.base.BaseListFragment;
import com.a4399.funnycore.databinding.FragmentGameCommentFrgmtBinding;

/**
 * 游戏详情下的 评论
 */
public class CommentFrgmt extends BaseListFragment<CommentViewModel> implements GameDetailAct.getGameDataListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String GAME_ID = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mGameId;
    private String mParam2;
    private FragmentGameCommentFrgmtBinding mGameCommentBinding;

    public CommentFrgmt() {
        // Required empty public constructor
    }


    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @return A new instance of fragment CommentFrgmt.
     */
    // TODO: Rename and change types and number of parameters
    public static CommentFrgmt newInstance(String param1) {
        CommentFrgmt fragment = new CommentFrgmt();
        Bundle args = new Bundle();
        args.putString(GAME_ID, param1);
        fragment.setArguments(args);
        return fragment;
    }


    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mGameId = getArguments().getString(GAME_ID);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    @Override protected void initViewAndData() {

    }


    @Override public void firstUserVisibile() {
        viewModel.toGetData(null);
    }


    @Override protected CommentViewModel initModel() {
        return new CommentViewModel();
    }


    @Override protected ViewDataBinding initBinding(LayoutInflater inflater, @Nullable ViewGroup container) {
        mGameCommentBinding = FragmentGameCommentFrgmtBinding.inflate(inflater);
        viewModel.setOnGameDataGetListener(this);
        mGameCommentBinding.setRecViewModel(viewModel);
        return mGameCommentBinding;
    }


    @Override public void afterGetData(GameDetail gameDetail) {
        if (mContext instanceof GameDetailAct) {
            ((GameDetailAct) mContext).getViewModel().showGameDetail(gameDetail.info);
        }
    }

    //public void setCommentData(Comment comment) {
    //    if (mComment == null) {
    //        mComment = comment;
    //        List<Object> commentList = new ArrayList<>();
    //        commentList.add(mComment.scoreList);
    //        if (CheckHelper.checkLists(mComment.pageList.getList())) {
    //            commentList.addAll(mComment.pageList.list);
    //        }
    //        mCommentViewModel.refreshedData(commentList);
    //    }
    //}
}
