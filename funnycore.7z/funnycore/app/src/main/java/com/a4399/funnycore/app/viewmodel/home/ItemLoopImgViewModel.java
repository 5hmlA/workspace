package com.a4399.funnycore.app.viewmodel.home;

import android.databinding.ObservableArrayList;
import android.databinding.ObservableList;
import com.a4399.funnycore.R;
import com.a4399.funnycore.utils.BindingReusePagerAdapter;
import java.util.List;
import me.tatarka.bindingcollectionadapter2.itembindings.ExtrasBindViewModel;
import me.tatarka.bindingcollectionadapter2.recv.LayoutManagers;

/**
 * Created by evan on 6/14/15.
 */
public class ItemLoopImgViewModel extends ExtrasBindViewModel implements LayoutManagers.FullSpan{
    public static final int layoutRes = R.layout.item_vp_loopimg;
    public ObservableList<BindingReusePagerAdapter.JVpItem> items = new ObservableArrayList<>();

    public ItemLoopImgViewModel(List<BindingReusePagerAdapter.JVpItem> items) {
        this.items.addAll(items) ;
    }
}
