package com.a4399.funnycore.example;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.databinding.ObservableArrayList;
import android.databinding.ObservableArrayMap;
import android.databinding.ObservableField;
import android.view.View;
import android.widget.ImageView;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import java.util.List;

/**
 * 文件描述：示例viewmodel
 * Created by zhanlinjian2888 on 2017/12/12.
 * E-mail:zhanlinjian@4399inc.com
 */
// ============ BindingMethods属性 ==============================
@BindingMethods (
    {
         @BindingMethod(
               type= ImageView.class,
               attribute  = "android:tint",
               method = "setImageTintList")
    }
)
public class ExampleViewModel extends BaseViewModel {

    // ============= 简化set、get设置属性 =======================
    public final ObservableField<String> test = new ObservableField<>();


    private void test() {
        test.set("test");
        test.get();
    }
    // 同理，ObservableBoolean， ObservableByte， ObservableChar， ObservableShort，
    // ObservableInt， ObservableLong，ObservableFloat， ObservableDouble，和 ObservableParcelable。

    // ============= Map类型定义 ================================
    ObservableArrayMap<String, Object> test2 = new ObservableArrayMap<>();


    private void test2() {
        test2.put("t1", "google");
    }
    // 对于xml文件<data>
    // <import type="android.databinding.ObservableMap"/>
    // <variable name="user" type="ObservableMap&lt;String, Object&gt;"/>
    // </data>
    //        …
    // <TextView
    // android:text='@{user["lastName"]}'
    // android:layout_width="wrap_content"
    // android:layout_height="wrap_content"/>
    // <TextView
    // android:text='@{String.valueOf(1 + (Integer)user["age"])}'
    // android:layout_width="wrap_content"
    // android:layout_height="wrap_content"/>

    // ============ List类型定义 ==================================
    ObservableArrayList<Object> test3 = new ObservableArrayList<>();


    private void test3() {
        test3.add("Google");
    }
    // 对于list文件
    // <data>
    // <import type="android.databinding.ObservableList"/>
    // <import type="com.example.my.app.Fields"/>
    // <variable name="user" type="ObservableList&lt;Object&gt;"/>
    // </data>
    //        …
    // <TextView
    // android:text='@{user[Fields.LAST_NAME]}'
    // android:layout_width="wrap_content"
    // android:layout_height="wrap_content"/>
    // <TextView
    // android:text='@{String.valueOf(1 + (Integer)user[Fields.AGE])}'
    // android:layout_width="wrap_content"
    // android:layout_height="wrap_content"/>

    // =============== 双向绑定 ===================
    // <EditText
    // ...
    // android:text="@={model.name}"/>

    // =========== 表达链式 =======================
    // 重复的表达式:
    // <ImageView android:visibility=“@{user.isAdult ? View.VISIBLE : View.GONE}”/>
    // <TextView android:visibility=“@{user.isAdult ? View.VISIBLE : View.GONE}”/>
    // <CheckBox android:visibility="@{user.isAdult ? View.VISIBLE : View.GONE}"/>
    // 可以简化为:
    // <ImageView android:id=“@+id/avatar” android:visibility=“@{user.isAdult ? View.VISIBLE : View.GONE}”/>
    // <TextView android:visibility=“@{avatar.visibility}”/>
    // <CheckBox android:visibility="@{avatar.visibility}"/>
    // 隐式更新:
    // <CheckBox android:id=”@+id/seeAds“/>
    // <ImageView android:visibility=“@{seeAds.checked ? View.VISIBLE : View.GONE}”/>

    @Override public void initViewModelData() {

    }


    @Override public List<BaseViewModelErrorInfo> verifyViewModel() {
        return null;
    }
}
