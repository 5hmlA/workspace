package com.a4399.funnycore.app.data.bean.comment;

import com.a4399.funnycore.app.data.netservice.AccountManage;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * 描述信息
 *
 * @author 徐智伟
 * @create 2017/5/10
 */

public class CommentItemEntity{
    /**
     * 自己评论的id
     */
    public static final String COMMENT_SELF_ID = "-1";
    @SerializedName("id") public String id;
    @SerializedName("fid") public String fid;
    @SerializedName("uid") public String uid;
    @SerializedName("username") public String username;
    @SerializedName("timeu") public String timeu;
    @SerializedName("time") public String time;
    @SerializedName("good") public int good;
    @SerializedName("star") public String star;
    @SerializedName("ip") public String ip;
    @SerializedName("channel") public String channel;
    @SerializedName("user_agent") public String userAgent;
    @SerializedName("comment") public String comment;
    @Expose @SerializedName("reply") public List<ReplyItemEntity> reply = new ArrayList<>();
    public boolean reviewState;

    public CommentItemEntity(){
    }

    public CommentItemEntity(String uid, String username, String time, String comment){
        this.uid = uid;
        this.username = username;
        this.timeu = time;
        this.comment = comment;
        reviewState = true;
    }

    public boolean hasReply(){
        if(reply != null && !reply.isEmpty()) {
            return true;
        }else {
            return false;
        }
    }

    public static CommentItemEntity getDefaultComment(String content){
        CommentItemEntity comment = new CommentItemEntity();
        comment.id = COMMENT_SELF_ID;
        comment.uid = AccountManage.getSingleton().getAccount().getUid();
        comment.username = AccountManage.getSingleton().getAccount().getNickname();
        comment.comment = content;
        return comment;
    }

    @Override
    public String toString(){
        return "CommentItemEntity{"+"id='"+id+'\''+", fid='"+fid+'\''+", uid='"+uid+'\''+", username='"+username+'\''+", timeu='"+timeu+'\''+", time='"+time+'\''+", good="+good+", star='"+star+'\''+", ip='"+ip+'\''+", channel='"+channel+'\''+", userAgent='"+userAgent+'\''+", comment='"+comment+'\''+", reply="+reply+'}';
    }

    @Override
    public boolean equals(Object o){
        if(this == o) {
            return true;
        }
        if(o == null || getClass() != o.getClass()) {
            return false;
        }

        CommentItemEntity that = (CommentItemEntity)o;

        if(id != null ? !id.equals(that.id) : that.id != null) {
            return false;
        }
        if(fid != null ? !fid.equals(that.fid) : that.fid != null) {
            return false;
        }
        if(uid != null ? !uid.equals(that.uid) : that.uid != null) {
            return false;
        }
        if(timeu != null ? !timeu.equals(that.timeu) : that.timeu != null) {
            return false;
        }
        return time != null ? time.equals(that.time) : that.time == null;
    }

    @Override
    public int hashCode(){
        int result = id != null ? id.hashCode() : 0;
        result = 31*result+( fid != null ? fid.hashCode() : 0 );
        result = 31*result+( uid != null ? uid.hashCode() : 0 );
        result = 31*result+( timeu != null ? timeu.hashCode() : 0 );
        result = 31*result+( time != null ? time.hashCode() : 0 );
        return result;
    }

}
