package com.a4399.funnycore.app.viewmodel.person.download;

import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import com.a4399.funnycore.base.LoadMoreViewModel;
import java.util.HashMap;
import java.util.List;
import me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass;

/**
 * 文件描述：下载管理-可更新
 * Created by zhanlinjian2888 on 2017/12/25.
 * E-mail:zhanlinjian@4399inc.com
 */

public class DownloadUpdateListViewModel extends LoadMoreViewModel {

    @Override public void toGetData(HashMap mapParam) {

    }


    @Override protected void registItemTypes(OnItemBindClass<Object> multipleItems) {

    }
}
