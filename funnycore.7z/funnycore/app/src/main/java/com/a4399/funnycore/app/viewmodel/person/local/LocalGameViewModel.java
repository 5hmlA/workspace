package com.a4399.funnycore.app.viewmodel.person.local;

import android.databinding.ObservableArrayList;
import com.a4399.funnycore.BR;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.download.GameDownloadTaskBean;
import com.a4399.funnycore.app.data.bean.home.GameDetailBean;
import com.a4399.funnycore.app.download.GameDownloadTaskManager;
import com.a4399.funnycore.app.viewmodel.person.download.ItemDownloadTaskViewModel;
import com.a4399.funnycore.app.viewmodel.person.download.ItemLocalGameViewModel;
import com.a4399.funnycore.base.BaseViewModel;
import com.a4399.funnycore.base.BaseViewModelErrorInfo;
import com.a4399.funnycore.base.LoadMoreViewModel;
import com.a4399.funnycore.utils.ApkUtil;
import easybind.jzy.bindingstar.statehelper.PageDiffState;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass;

import static easybind.jzy.bindingstar.loadmorehelper.LoadmoreFootViewModel.wrapperLoadMoreBinding;

/**
 * 文件描述：本机游戏
 * Created by zhanlinjian2888 on 2017/12/28.
 * E-mail:zhanlinjian@4399inc.com
 */

public class LocalGameViewModel extends LoadMoreViewModel {

    public LocalGameViewModel() {
        // TODO 参数
        List<ApkUtil.AppInfo> allApk = ApkUtil.getAllApp();
        // TODO 测试数据(从服务端获取获取数据，并做异常、状态的控制)
        GameDetailBean gameDetailBean1 = new GameDetailBean();
        gameDetailBean1.setName("我的世界");
        gameDetailBean1.setIcon(
                "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2170745923,321319231&fm=27&gp=0.jpg");
        gameDetailBean1.setPackage_name("com.sj4399.mcpetool");
        ItemLocalGameViewModel itemLocalGameViewModel1 = new ItemLocalGameViewModel();
        itemLocalGameViewModel1.setGameDetailBean(gameDetailBean1);
        mDataLists.add(itemLocalGameViewModel1);

        GameDetailBean gameDetailBean2 = new GameDetailBean();
        gameDetailBean2.setName("迷你世界");
        gameDetailBean2.setIcon(
                "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1515143938713&di=fc74fad9335d32d9f3b61267057e8290&imgtype=0&src=http%3A%2F%2Fnewsimg.5054399.com%2Fupimg%2Fadd_pic%2F14536897891.jpg");
        gameDetailBean2.setPackage_name("com.sj4399.mcpetool");
        ItemLocalGameViewModel itemLocalGameViewModel2 = new ItemLocalGameViewModel();
        itemLocalGameViewModel2.setGameDetailBean(gameDetailBean2);
        mDataLists.add(itemLocalGameViewModel2);

        GameDetailBean gameDetailBean3 = new GameDetailBean();
        gameDetailBean3.setName("好游快爆");
        gameDetailBean3.setIcon(
                "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1515144226388&di=cd1ff02bd704d648bb959b46670a34b0&imgtype=0&src=http%3A%2F%2Ffile003.gao7.com%2Fg2%2FM00%2F00%2F90%2FEicAAFnPP1OAbA2dAADDMJXxo5A508.jpg%3Fw%3D500%26h%3D281");
        gameDetailBean3.setPackage_name("com.sj4399.mcpetool");
        ItemLocalGameViewModel itemLocalGameViewModel3 = new ItemLocalGameViewModel();
        itemLocalGameViewModel3.setGameDetailBean(gameDetailBean3);
        mDataLists.add(itemLocalGameViewModel3);
        removeFootLoadmoreItem();
    }


    @Override public void toGetData(HashMap mapParam) {
/*        Observable.just(mDataLists)
                  .delay(2, TimeUnit.SECONDS)
                  .observeOn(AndroidSchedulers.mainThread())
                  .subscribe(new Consumer() {
                      @Override public void accept(Object o) throws Exception {

                          if (isFirstPage()) {
                              refreshedAllData(mDataLists);
                          }
                          else {
                              if (new Random().nextBoolean()) {
                                  addMoreData(mDataLists, mDataLists.size() < 30);
                              }
                              else {
                                  showPageStateError(PageDiffState.PAGE_STATE_ERROR);
                              }
                          }
                      }
                  });*/
    }


    @Override protected void registItemTypes(OnItemBindClass<Object> multipleItems) {
        multipleItems.regist(ItemLocalGameViewModel.class, BR.itemLocalGameViewModel,
                R.layout.item_local_game);
    }
}
