package com.a4399.funnycore.app.bindingadapter;

import android.content.res.Resources;
import android.databinding.BindingAdapter;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.widget.AvatorImageView;
import com.a4399.funnycore.utils.ResUtil;
import com.facebook.drawee.drawable.ScalingUtils;
import com.facebook.drawee.generic.RoundingParams;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;

/**
 * 文件描述：Fresco属性设置
 * Created by zhanlinjian2888 on 2017/12/18.
 * E-mail:zhanlinjian@4399inc.com
 */

public class FrescoBindingAdapter {

    // 圆角参数设置
    public static RoundingParams circleParams = null;
    public static RoundingParams roundingParams = null;


    /**
     * 加载图片
     */
    @BindingAdapter(value = { "loadImageUrl", "defaultImage" }, requireAll = false)
    public static void loadImage(SimpleDraweeView imageView, String imageUrl, Drawable defaultImage) {
        if (!TextUtils.isEmpty(imageUrl)) {
            imageView.setImageURI(Uri.parse(imageUrl));
            return;
        }
        if (null == defaultImage) {
            defaultImage = ResUtil.getDrawable(R.drawable.ic_back);
        }
        imageView.setImageDrawable(defaultImage);
        // imageView.setController( defaultImage);
    }


    /**
     * 加载圆形图片（by url ）
     */

    @BindingAdapter(value = { "loadCircleImageUrl", "defaultImage" }, requireAll = false)
    public static void loadCircleImage(SimpleDraweeView imageView, String imageUrl, Drawable defaultImage) {
        if (!TextUtils.isEmpty(imageUrl)) {
            imageView.getHierarchy().setRoundingParams(getCircleParams());
            imageView.getHierarchy().setActualImageScaleType(ScalingUtils.ScaleType.FOCUS_CROP);
            PointF point = new PointF();
            point.set(0.5f, 0.0f);
            imageView.getHierarchy().setActualImageFocusPoint(point);
            imageView.setImageURI(Uri.parse(imageUrl));
            return;
        }
        if (null == defaultImage) {
            defaultImage = ResUtil.getDrawable(R.drawable.ic_back);
        }
        imageView.setImageDrawable(defaultImage);
    }

    /**
     * 加载圆形图片(带有默认颜色)
     */

    @BindingAdapter(value = { "loadAvator" }, requireAll = false)
    public static void loadCircleImage(AvatorImageView imageView, String imageUrl) {
        if (!TextUtils.isEmpty(imageUrl)) {
            imageView.getHierarchy().setRoundingParams(getCircleParams());
            imageView.getHierarchy().setActualImageScaleType(ScalingUtils.ScaleType.FOCUS_CROP);
            PointF point = new PointF();
            point.set(0.5f, 0.0f);
            imageView.getHierarchy().setActualImageFocusPoint(point);
            imageView.setImageURI(Uri.parse(imageUrl));
            return;
        }
        imageView.setImageResource(R.drawable.defalut_holder_round_8);
    }


    /**
     * 加载网络图片圆角
     */
    @BindingAdapter(value = { "loadRoundImageUrl", "round", "defaultImage" }, requireAll = false)
    public static void loadRoundImage(SimpleDraweeView imageView, String imageUrl, float pix, Drawable defaultImage) {
        if (!TextUtils.isEmpty(imageUrl)) {
            imageView.getHierarchy().setRoundingParams(getRoundingParams(pix));
            imageView.setImageURI(Uri.parse(imageUrl));
            return;
        }
        if (null == defaultImage) {
            defaultImage = ResUtil.getDrawable(R.drawable.ic_back);
        }
        imageView.setImageDrawable(defaultImage);
    }


    /**
     * 加载网络图片，图片的顶部为圆角
     */
    @BindingAdapter(value = { "loadTopRoundImageUrl", "round", "defaultImage" }, requireAll = false)
    public static void loadTopRoundImage(SimpleDraweeView imageView, String imageUrl, int round, Drawable defaultImage) {
        int pix = dip2px(round);
        if (!TextUtils.isEmpty(imageUrl)) {
            imageView.getHierarchy()
                     .setRoundingParams(getRoundingParams(pix).setCornersRadii(pix, pix, 0, 0));
            imageView.setImageURI(Uri.parse(imageUrl));
            return;
        }
        if (null == defaultImage) {
            defaultImage = ResUtil.getDrawable(R.drawable.ic_back);
        }
        imageView.setImageDrawable(defaultImage);
    }


    /**
     * 加载资源图片，顶部为圆角
     */

    @BindingAdapter(value = { "loadTopRoundimageDrawable", "round", "defaultImage" }, requireAll = false)
    public static void loadTopRoundimage(SimpleDraweeView imageView, Drawable topRoundDrawable, int round, Drawable defaultImage) {
        int pix = dip2px(round);
        if (null != topRoundDrawable) {
            imageView.getHierarchy()
                     .setRoundingParams(getRoundingParams(pix).setCornersRadii(pix, pix, 0, 0));
            //            imageView.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(topRoundDrawable)).build());
            imageView.setController((DraweeController) topRoundDrawable);
            return;
        }
        if (null == defaultImage) {
            defaultImage = ResUtil.getDrawable(R.drawable.ic_back);
        }
        imageView.setImageDrawable(defaultImage);
    }


    @BindingAdapter(value = { "loadResourceDrawable", "defaultImage" }, requireAll = false)
    public static void loadResourceDrawable(SimpleDraweeView imageView, Drawable resourceDrawable, Drawable defaultImage) {
        if (null != resourceDrawable) {
            //            imageView.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(resourceDrawable)).build());
            imageView.setController((DraweeController) resourceDrawable);
            return;
        }
        if (null == defaultImage) {
            defaultImage = ResUtil.getDrawable(R.drawable.ic_back);
        }
        imageView.setImageDrawable(defaultImage);
    }


    @BindingAdapter(value = { "loadCirclRresourceDrawable", "defaultImage" }, requireAll = false)
    public static void loadCirclRresourceDrawable(SimpleDraweeView imageView, Drawable circlRresourceDrawable, Drawable defaultImage) {
        if (null != circlRresourceDrawable) {
            imageView.getHierarchy().setRoundingParams(getCircleParams());
            //            imageView.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(circlRresourceDrawable)).build());
            imageView.setController((DraweeController) circlRresourceDrawable);
            return;
        }
        if (null == defaultImage) {
            defaultImage = ResUtil.getDrawable(R.drawable.ic_back);
        }
        imageView.setImageDrawable(defaultImage);
    }


    @BindingAdapter(value = { "loadRoundResourceDrawable", "round", "defaultImage" }, requireAll = false)
    public static void loadRoundResourceDrawable(SimpleDraweeView imageView, Drawable roundResourceDrawable, int round, Drawable defaultImage) {
        if (null != roundResourceDrawable) {
            int pix = dip2px(round);
            imageView.getHierarchy().setRoundingParams(getRoundingParams(pix));
            //imageView.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(roundResourceDrawable)).build());
            imageView.setController((DraweeController) roundResourceDrawable);
            return;
        }
        if (null == defaultImage) {
            defaultImage = ResUtil.getDrawable(R.drawable.ic_back);
        }
        imageView.setImageDrawable(defaultImage);
    }


    public static int dip2px(int dip) {
        Resources r = Resources.getSystem();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dip, r.getDisplayMetrics());
    }


    /**
     * 图片的配置参数
     * 使用方法 SimpleDraweeView.getHierarchy().setRoundingParams(FrescoUtil.getRoundParams)
     */
    public static RoundingParams getCircleParams() {
        if (null == circleParams) {
            synchronized (FrescoBindingAdapter.class) {
                if (null == circleParams) {
                    circleParams = new RoundingParams();
                    circleParams.setRoundAsCircle(true);
                }
            }
        }
        return circleParams;
    }


    public static RoundingParams getRoundingParams(float round) {
        roundingParams = new RoundingParams();
        roundingParams.setCornersRadius(round);
        return roundingParams;
    }
}
