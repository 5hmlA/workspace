package com.a4399.funnycore.app.viewmodel.message;

import com.a4399.funnycore.BR;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.data.bean.msgcenter.MessageCenterHomeBean;
import com.a4399.funnycore.base.LoadMoreViewModel;
import com.a4399.funnycore.utils.ResUtil;

import java.util.HashMap;

import me.tatarka.bindingcollectionadapter2.collections.JObservableList;
import me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass;

/**
 * 描述:消息首页ViewModel
 *
 * @author 罗远回
 * @since 2018年01月05日 14:02
 */

public class MessageCenterViewModel extends LoadMoreViewModel{

  private static final int MSG_COUNT = 10;

  private JObservableList refreshList = new JObservableList();

  @Override protected void registItemTypes(OnItemBindClass<Object> multipleItems) {
    // 消息中心
    multipleItems.regist(MessageCenterHomeBean.class, BR.msghome,
        R.layout.item_message_center_home);
  }


  @Override public void toGetData(HashMap mapParam) {
    // 加载数据
    refreshedAllData(refreshList);
  }

  public MessageCenterViewModel() {
    refreshList.add(new MessageCenterHomeBean(R.drawable.btn_reply_54_gradientorange,
        ResUtil.getString(R.string.replay_me),MSG_COUNT));
    refreshList.add(new MessageCenterHomeBean(R.drawable.btn_newfans_54_gradientorange,
        ResUtil.getString(R.string.new_fans),MSG_COUNT));
    refreshList.add(new MessageCenterHomeBean(R.drawable.btn_thumbsup_54_gradientorange,
        ResUtil.getString(R.string.receive_praise),MSG_COUNT));
    refreshList.add(new MessageCenterHomeBean(R.drawable.btn_sysnotice_54_gradientorange,
        ResUtil.getString(R.string.system_notification),MSG_COUNT));
  }
}
