package com.a4399.funnycore.app.utill;

import android.text.TextUtils;
import com.a4399.funnycore.app.data.bean.IRoute;
import java.util.ArrayList;

/**
 * 路由协议配置
 *
 * @create 2017/2/3
 */
public class RouterHelper {
    public static final ArrayList<String> routes = new ArrayList<>();
    public static final String SCHEMA_FUNNY = "gmall4399://";

    public static final String PARAM_ID = "id";
    public static final String PARAM_TITLE = "title";

    public static final String PATH_WEB = "web";
    //游戏详情
    public static final String PATH_DETAIL_GAME = "game_detail";
    //资讯详情
    public static final String PATH_DETAIL_NEWS = "news_detail";
    //视频详情
    public static final String PATH_DETAIL_VIDEO = "video_detail";

    //public static final String PATH_STRATEGY_DETAIL = "strategy_detail";
    //
    //public static final String PATH_MAP_DETAIL = "archive_detail";
    //public static final String PATH_GIFT_DETAIL = "gift_detail";
    //public static final String PATH_TOPIC_DETAIL = "topic_detail";
    //public static final String PATH_VIDEO_DETAIL = "video_detail";
    //public static final String PATH_MAPTYPE_DETAIL = "archive_type";
    //public static final String PATH_MAPLABEL_DETAIL = "archive_label";
    ////视频分类
    //public static final String PATH_VIDEO_TYPE = "video_type";
    ////视频合集
    //public static final String PATH_VIDEO_COLLECTION = "video_collection_list";
    //public static final String PATH_VIDEO_COLLECTION_ONE = "video_collection";


    static {
        routes.clear();
        routes.add(PATH_WEB);
        routes.add(PATH_DETAIL_GAME);
        routes.add(PATH_DETAIL_NEWS);
        routes.add(PATH_DETAIL_VIDEO);
        //routes.add(PATH_VIDEO_DETAIL);
        //routes.add(PATH_MAPTYPE_DETAIL);
        //routes.add(PATH_MAPLABEL_DETAIL);
        //routes.add(PATH_STRATEGY_DETAIL);
        //routes.add(PATH_VIDEO_COLLECTION);
        //routes.add(PATH_VIDEO_COLLECTION_ONE);
        //routes.add(PATH_VIDEO_TYPE);
        //todo 轮播i图只显示 已定义的协议
    }


    /**
     * 协议是否合法
     */
    public static boolean isLegalUrl(IRoute routeUrl) {
        if (routeUrl == null) {
            return false;
        }
        //            mnsj4399://strategy_detail?title=xxx&url=http://xxxxx&id=xxx
        return !TextUtils.isEmpty(routeUrl.getUrl()) && routeUrl.getUrl().startsWith(SCHEMA_FUNNY) &&
                routeUrl.getUrl().contains("?") && RouterHelper.routes.contains(
                routeUrl.getUrl().substring(SCHEMA_FUNNY.length(), routeUrl.getUrl().indexOf("?")));
    }
}
