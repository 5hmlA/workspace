package com.a4399.funnycore.app.ui.home.search;

import android.graphics.Color;
import april.yun.other.JTabStyleDelegate;
import com.a4399.funnycore.R;
import com.a4399.funnycore.app.ui.JBaseTabViewpagerFrgmt;
import com.a4399.funnycore.app.ui.home.HomeFragment;
import com.a4399.funnycore.app.ui.home.gamedetail.CommentFrgmt;
import com.a4399.funnycore.app.ui.person.PersonHomeFragment;
import com.a4399.funnycore.app.ui.person.local.LocalGameFragment;
import com.a4399.funnycore.app.widget.CustomTabStyle;
import com.a4399.funnycore.base.TabAdapter;

import static april.yun.widget.JToolbar.dp2px;
import static com.a4399.funnycore.JApp.findColor;

/**
 * @another 江祖赟
 * @date 2017/12/28.
 */
public class HomeSearchTabFrgmt extends JBaseTabViewpagerFrgmt {

    @Override protected TabAdapter.BaseFrgmtFractory setFrgmtProvider() {
        return new TabAdapter.BaseFrgmtFractory() {
            @Override protected void initFrgment() {
                super.initFrgment();
                fmCache.put(0, new HomeFragment());
                fmCache.put(1, new LocalGameFragment());
                fmCache.put(2, new PersonHomeFragment());
                fmCache.put(3, CommentFrgmt.newInstance(null));
            }
        };
    }


    @Override public int getBaseTabLayout() {
        return R.layout.fragment_home_search_tab;
    }


    @Override protected String[] setTabTitles() {
        return getResources().getStringArray(R.array.home_search_tab);
    }


    protected void initTabStrip() {
        JTabStyleDelegate tabStyleDelegate = mBaseTabStrip.getTabStyleDelegate();
        //        2，拿TabStyleDelegate
        //        3, 用TabStyleDelegate设置属性
        tabStyleDelegate.setShouldExpand(true)
                        //也可以直接传字符串的颜色，第一个颜色表示checked状态的颜色第二个表示normal状态
                        .setTextColor(findColor(R.color.black_2e33), findColor(R.color.gray_8b8b))
                        .setTabTextSize(dp2px(16))
                        .setUnderlineHeight(0)//底部横线的高度
                        .setIndicatorHeight(dp2px(3))
                        .setUnderlineHeight(0)
                        .setUnderlineColor(Color.TRANSPARENT)
                        .setIndicatorColor(findColor(R.color.tv_orign_ff88)).setUnderLineFixWidth(dp2px(15));
        reConfigTabStrip(tabStyleDelegate.setJTabStyle(new CustomTabStyle(mBaseTabStrip)));
    }
}
