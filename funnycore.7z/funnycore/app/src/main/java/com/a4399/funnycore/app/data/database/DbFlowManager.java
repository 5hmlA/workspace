package com.a4399.funnycore.app.data.database;

import com.raizlabs.android.dbflow.annotation.Database;

/**
 * 文件描述：数据库管理类
 * Created by zhanlinjian2888 on 2017/12/26.
 * E-mail:zhanlinjian@4399inc.com
 */
@Database(name = DbFlowManager.DATA_NAME, version = DbFlowManager.DATA_VERSION)
public class DbFlowManager {

    // 数据库名称
    public static final String DATA_NAME = "funnycodeDatabase";

    // 数据库版本
    public static final int DATA_VERSION = 1;

}
