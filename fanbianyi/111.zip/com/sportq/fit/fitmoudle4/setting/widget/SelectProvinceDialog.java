package com.sportq.fit.fitmoudle4.setting.widget;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.NumberPicker;
import android.widget.NumberPicker.OnValueChangeListener;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RLinearLayout;
import com.sportq.fit.fitmoudle.widget.CustomNumberPicker;
import com.sportq.fit.fitmoudle4.R.anim;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.string;

public class SelectProvinceDialog
{
  private String[][] CITIES = { { "安庆", "蚌埠", "亳州", "巢湖", "池州", "滁州", "阜阳", "淮北", "合肥", "淮南", "黄山", "六安", "马鞍山", "宿州", "铜陵", "芜湖", "宣城" }, { "大堂区", "氹仔", "风顺堂区", "花地玛堂区", "路环岛", "圣安多尼堂区", "望德堂区" }, { "昌平", "朝阳", "东城", "大兴", "房山", "丰台", "海淀", "怀柔", "门头沟", "密云", "平谷", "石景山", "顺义", "通州", "西城", "延庆" }, { "北碚", "巴南", "璧山", "城口", "长寿", "大渡口", "垫江", "大足", "丰都", "奉节", "涪陵", "合川", "江北", "江津", "九龙坡", "开县", "两江新区", "梁平", "南岸", "南川", "彭水", "綦江", "黔江", "荣昌", "沙坪坝", "双桥", "石柱", "铜梁", "潼南", "武隆", "万盛", "巫山", "巫溪", "万州", "秀山", "渝北", "永川", "云阳", "酉阳", "渝中", "忠县" }, { "福州", "龙岩", "宁德", "南平", "莆田", "泉州", "三明", "厦门", "漳州" }, { "潮州", "东莞", "佛山", "广州", "河源", "惠州", "江门", "揭阳", "茂名", "梅州", "清远", "韶关", "汕头", "汕尾", "深圳", "云浮", "阳江", "珠海", "湛江", "肇庆", "中山" }, { "白银", "定西", "甘南", "金昌", "酒泉", "嘉峪关", "陇南", "临夏", "兰州", "平凉", "庆阳", "天水", "武威", "张掖" }, { "北海", "百色", "崇左", "防城港", "贵港", "桂林", "河池", "贺州", "来宾", "柳州", "南宁", "钦州", "梧州", "玉林" }, { "安顺", "毕节", "贵阳", "六盘水", "黔东南", "黔南", "黔西南", "铜仁", "遵义" }, { "恩施", "鄂州", "黄冈", "黄石", "荆门", "荆州", "潜江", "神农架", "十堰", "随州", "天门", "武汉", "孝感", "咸宁", "仙桃", "襄阳", "宜昌" }, { "保定", "承德", "沧州", "邯郸", "衡水", "廊坊", "秦皇岛", "石家庄", "唐山", "邢台", "张家口" }, { "大庆", "大兴安岭", "哈尔滨", "鹤岗", "黑河", "佳木斯", "鸡西", "牡丹江", "齐齐哈尔", "七台河", "绥化", "双鸭山", "宜春" }, { "常德", "长沙", "郴州", "怀化", "衡阳", "娄底", "邵阳", "湘潭", "湘西", "益阳", "岳阳", "永州", "张家界", "株洲" }, { "安阳", "鹤壁", "济源", "焦作", "开封", "漯河", "洛阳", "南阳", "平顶山", "濮阳", "三门峡", "商丘", "许昌", "新乡", "信阳", "周口", "驻马店", "郑州" }, { "白沙", "保亭", "昌江", "澄迈", "定安", "东方", "儋州", "海口", "乐东", "临高", "陵水", "南沙", "琼海", "琼中", "三亚", "屯昌", "文昌", "万宁", "五指山", "西沙", "中沙" }, { "白城", "长白山", "长春", "吉林", "辽源", "四平", "松原", "通化", "延边" }, { "抚州", "赣州", "吉安", "景德镇", "九江", "南昌", "萍乡", "上饶", "新余", "宜春", "鹰潭" }, { "常州", "淮安", "连云港", "南京", "南通", "宿迁", "苏州", "泰州", "无锡", "徐州", "盐城", "扬州", "镇江" }, { "鞍山", "本溪", "朝阳", "丹东", "大连", "抚顺", "阜新", "葫芦岛", "锦州", "辽阳", "盘锦", "沈阳", "铁岭", "营口" }, { "阿拉善", "包头", "巴彦淖尔", "赤峰", "鄂尔多斯", "呼和浩特", "呼伦贝尔", "通辽", "乌海", "乌兰察布", "兴安", "锡林郭勒" }, { "固原", "石嘴山", "吴忠", "银川", "中卫" }, { "果洛", "海北", "海东", "黄南", "海南", "海西", "西宁", "玉树" }, { "阿坝", "巴中", "成都", "德阳", "达州", "广安", "广元", "甘孜", "凉山", "乐山", "泸州", "眉山", "绵阳", "南充", "内江", "攀枝花", "遂宁", "雅安", "宜宾", "自贡", "资阳" }, { "滨州", "东营", "德州", "菏泽", "济南", "济宁", "聊城", "莱芜", "临沂", "青岛", "日照", "泰安", "潍坊", "威海", "烟台", "淄博", "枣庄" }, { "宝山", "崇明", "长宁", "奉贤", "虹口", "黄浦", "静安", "嘉定", "金山", "卢湾", "闵行", "浦东新区", "普陀", "青浦", "松江", "徐汇", "杨浦", "闸北" }, { "安康", "宝鸡", "汉中", "商洛", "铜川", "渭南", "西安", "咸阳", "延安", "榆林" }, { "长治", "大同", "晋城", "晋中", "临汾", "吕梁", "朔州", "太原", "忻州", "运城", "阳泉" }, { "北辰", "宝坻", "滨海新区", "东丽", "河北", "河东", "和平", "红桥", "河西", "静海", "津南", "蓟县", "宁河", "南开", "武清", "西青" }, { "高雄市", "花莲县", "基隆市", "金门县", "嘉义市", "嘉义县", "连江县", "苗栗县", "南投县", "屏东县", "澎湖县", "台北市", "台东县", "台南县", "桃园县", "台中市", "新北市", "新竹市", "新竹县", "云林县", "宜兰县", "彰化县" }, { "阿里", "昌都", "拉萨", "林芝", "那曲", "日喀则", "山南" }, { "北区", "大埔区", "东区", "观塘区", "黄大仙区", "九龙城区", "葵青区", "离岛区", "南区", "荃湾区", "深水埗去", "沙田区", "屯门区", "湾仔区", "西贡区", "油尖旺区", "元朗区", "中西区" }, { "阿克苏", "阿拉尔", "阿勒泰", "博尔塔拉", "巴音郭楞", "昌吉", "哈密", "和田", "克拉玛依", "喀什", "克孜勒苏", "石河子", "塔城", "吐鲁番", "图木舒克", "五家渠", "乌鲁木齐", "伊犁" }, { "保山", "楚雄", "德宏", "大理", "迪庆", "红河", "昆明", "临沧", "丽江", "怒江", "普洱", "曲靖", "文山", "西双版纳", "玉溪", "昭通" }, { "湖州", "杭州", "金华", "嘉兴", "丽水", "宁波", "衢州", "绍兴", "台州", "温州", "舟山" } };
  private String[] PROVINCES = { "安徽", "澳门", "北京", "重庆", "福建", "广东", "甘肃", "广西", "贵州", "湖北", "河北", "黑龙江", "湖南", "河南", "海南", "吉林", "江西", "江苏", "辽宁", "内蒙古", "宁夏", "青海", "四川", "山东", "上海", "陕西", "山西", "天津", "台湾", "西藏", "香港", "新疆", "云南", "浙江" };
  private TextView btn_cancel;
  private String city;
  private String cityText;
  private Dialog dialog;
  private int index = 0;
  private Context mContext;
  private String province;
  private CustomNumberPicker select_city;
  private CustomNumberPicker select_province;

  public SelectProvinceDialog(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private void getIndex()
  {
    while (true)
    {
      int i;
      try
      {
        if (!StringUtils.getStringResources(R.string.not_filled).equals(this.cityText))
          continue;
        String str = "安徽";
        this.province = str;
        i = 0;
        if (i >= this.PROVINCES.length)
          continue;
        if (this.province.contains(this.PROVINCES[i]))
        {
          this.index = i;
          return;
          str = this.cityText.substring(0, this.cityText.indexOf(" "));
          continue;
          this.index = 0;
          return;
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        this.index = 0;
        return;
      }
      i++;
    }
  }

  private int getIndex01()
  {
    try
    {
      Object localObject;
      if (StringUtils.getStringResources(R.string.not_filled).equals(this.cityText))
      {
        localObject = "安庆";
        this.city = ((String)localObject);
      }
      for (int i = 0; ; i++)
      {
        if (i >= this.CITIES[this.index].length)
          break label103;
        if (this.city.contains(this.CITIES[this.index][i]))
        {
          return i;
          String str = this.cityText.substring(1 + this.cityText.lastIndexOf(" "), this.cityText.length());
          localObject = str;
          break;
        }
      }
      label103: return 0;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return 0;
  }

  private void initControl()
  {
    getIndex();
    this.select_province.setDisplayedValues(this.PROVINCES);
    this.select_province.setMinValue(0);
    this.select_province.setMaxValue(-1 + this.PROVINCES.length);
    this.select_province.setValue(this.index);
    this.select_city.setDisplayedValues(this.CITIES[this.index]);
    this.select_city.setMinValue(0);
    this.select_city.setMaxValue(-1 + this.CITIES[this.index].length);
    this.select_city.setValue(getIndex01());
    this.select_province.updateView(R.color.color_313131, 16);
    this.select_province.setNumberPickerDividerColor(R.color.color_ffd208);
    this.select_city.updateView(R.color.color_313131, 16);
    this.select_city.setNumberPickerDividerColor(R.color.color_ffd208);
    this.select_province.setDescendantFocusability(393216);
    this.select_city.setDescendantFocusability(393216);
    this.select_province.setOnValueChangedListener(new NumberPicker.OnValueChangeListener()
    {
      public void onValueChange(NumberPicker paramNumberPicker, int paramInt1, int paramInt2)
      {
        SelectProvinceDialog.access$002(SelectProvinceDialog.this, SelectProvinceDialog.this.PROVINCES[paramInt2]);
        SelectProvinceDialog.access$402(SelectProvinceDialog.this, paramInt2);
        SelectProvinceDialog.this.select_city.setMinValue(0);
        SelectProvinceDialog.this.select_city.setMaxValue(0);
        SelectProvinceDialog.this.select_city.setDisplayedValues(SelectProvinceDialog.this.CITIES[paramInt2]);
        SelectProvinceDialog.this.select_city.setMinValue(0);
        SelectProvinceDialog.this.select_city.setMaxValue(-1 + SelectProvinceDialog.this.CITIES[paramInt2].length);
        SelectProvinceDialog.this.select_city.setValue(0);
        SelectProvinceDialog.access$102(SelectProvinceDialog.this, SelectProvinceDialog.this.CITIES[paramInt2][0]);
      }
    });
    this.select_city.setOnValueChangedListener(new NumberPicker.OnValueChangeListener()
    {
      public void onValueChange(NumberPicker paramNumberPicker, int paramInt1, int paramInt2)
      {
        if (SelectProvinceDialog.this.index > -1 + SelectProvinceDialog.this.CITIES.length)
          SelectProvinceDialog.access$402(SelectProvinceDialog.this, 0);
        if (paramInt2 > -1 + SelectProvinceDialog.this.CITIES[SelectProvinceDialog.this.index].length)
          paramInt2 = 0;
        SelectProvinceDialog.access$102(SelectProvinceDialog.this, SelectProvinceDialog.this.CITIES[SelectProvinceDialog.this.index][paramInt2]);
      }
    });
    this.btn_cancel.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        SelectProvinceDialog.this.dialog.dismiss();
      }
    });
  }

  public void createDialog(String paramString, OnCitySelectorListener paramOnCitySelectorListener)
  {
    try
    {
      this.cityText = paramString;
      this.dialog = new Dialog(this.mContext);
      this.dialog.requestWindowFeature(1);
      this.dialog.getWindow().setBackgroundDrawableResource(17170445);
      this.dialog.setCanceledOnTouchOutside(false);
      View localView = LayoutInflater.from(this.mContext).inflate(R.layout.select_province_dialog, null);
      RLinearLayout localRLinearLayout = (RLinearLayout)localView.findViewById(R.id.select_province_l);
      this.select_province = ((CustomNumberPicker)localView.findViewById(R.id.select_province));
      this.select_city = ((CustomNumberPicker)localView.findViewById(R.id.select_city));
      TextView localTextView = (TextView)localView.findViewById(R.id.btn_save);
      this.btn_cancel = ((TextView)localView.findViewById(R.id.btn_cancel));
      this.dialog.setContentView(localView);
      WindowManager.LayoutParams localLayoutParams = this.dialog.getWindow().getAttributes();
      localLayoutParams.width = (int)(0.861D * BaseApplication.screenWidth);
      localLayoutParams.height = -2;
      localLayoutParams.gravity = 17;
      this.dialog.getWindow().setAttributes(localLayoutParams);
      initControl();
      localTextView.setOnClickListener(new View.OnClickListener(paramOnCitySelectorListener)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (this.val$listener != null)
            this.val$listener.onSelect(SelectProvinceDialog.this.province + "  " + SelectProvinceDialog.this.city);
          SelectProvinceDialog.this.dialog.dismiss();
        }
      });
      Animation localAnimation = AnimationUtils.loadAnimation(this.mContext, R.anim.fade_in);
      if (localRLinearLayout != null)
        localRLinearLayout.startAnimation(localAnimation);
      this.dialog.setCanceledOnTouchOutside(true);
      Dialog localDialog = this.dialog;
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public static abstract interface OnCitySelectorListener
  {
    public abstract void onSelect(String paramString);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.widget.SelectProvinceDialog
 * JD-Core Version:    0.6.0
 */