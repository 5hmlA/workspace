package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;

public class Mine03FitnessVideoActivity extends BaseActivity
{
  RadioButton mine03FitnessNanState;
  RadioButton mine03FitnessNvState;
  private RequestModel requestModel;
  CustomToolBar toolbar;

  private void onBackAction()
  {
    Intent localIntent = new Intent();
    String str;
    if (this.requestModel != null)
    {
      if (!CompDeviceInfoUtils.checkNetwork())
        break label108;
      BaseApplication.userModel.coachSexf = this.requestModel.coachSexf;
      MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(this.requestModel, this);
      if (!"0".equals(BaseApplication.userModel.coachSexf))
        break label97;
      str = getString(R.string.male);
      localIntent.putExtra("sex", str);
    }
    while (true)
    {
      setResult(-1, localIntent);
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      return;
      label97: str = getString(R.string.female);
      break;
      label108: ToastUtils.makeToast(this, getString(R.string.current_network_again_later));
    }
  }

  public void fitOnClick(View paramView)
  {
    this.requestModel = new RequestModel();
    if (R.id.mine03_fitness_nan_state == paramView.getId())
      this.requestModel.coachSexf = "0";
    do
      return;
    while (R.id.mine03_fitness_nv_state != paramView.getId());
    this.requestModel.coachSexf = "1";
  }

  public <T> void getDataFail(T paramT)
  {
    ToastUtils.makeToast(this, String.valueOf(paramT));
  }

  public <T> void getDataSuccess(T paramT)
  {
    ToastUtils.makeToast(this, getString(R.string.set_success));
    this.requestModel = null;
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine03_fitness_video);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.mine03FitnessNanState = ((RadioButton)findViewById(R.id.mine03_fitness_nan_state));
    this.mine03FitnessNvState = ((RadioButton)findViewById(R.id.mine03_fitness_nv_state));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(R.string.c_54_1);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    this.mine03FitnessNanState.setOnClickListener(new FitAction(this));
    this.mine03FitnessNvState.setOnClickListener(new FitAction(this));
    if (!StringUtils.isNull(BaseApplication.userModel.coachSexf))
    {
      if ("0".equals(BaseApplication.userModel.coachSexf));
      for (RadioButton localRadioButton2 = this.mine03FitnessNanState; ; localRadioButton2 = this.mine03FitnessNvState)
      {
        localRadioButton2.setChecked(true);
        return;
      }
    }
    if ("0".equals(BaseApplication.userModel.userSex));
    for (RadioButton localRadioButton1 = this.mine03FitnessNanState; ; localRadioButton1 = this.mine03FitnessNvState)
    {
      localRadioButton1.setChecked(true);
      return;
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      onBackAction();
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      onBackAction();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03FitnessVideoActivity
 * JD-Core Version:    0.6.0
 */