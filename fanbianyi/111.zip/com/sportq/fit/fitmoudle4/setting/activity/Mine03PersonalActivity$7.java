package com.sportq.fit.fitmoudle4.setting.activity;

import android.widget.TextView;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.dialogmanager.SelectDateDialog.DateSelectorListener;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.fitmoudle4.R.style;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

class Mine03PersonalActivity$7
  implements SelectDateDialog.DateSelectorListener
{
  public void onSelect(String paramString)
  {
    int[] arrayOfInt = this.this$0.splitAge(paramString);
    String str1 = arrayOfInt[0] + "-" + arrayOfInt[1] + "-" + arrayOfInt[2];
    Date localDate = new Date();
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-M-d", new Locale("zh", "CN"));
    String str2 = localSimpleDateFormat.format(localDate);
    while (true)
    {
      try
      {
        long l = localSimpleDateFormat.parse(str2).getTime();
        if (localSimpleDateFormat.parse(str1).getTime() > l)
          break;
        if (arrayOfInt[1] < 10)
        {
          if (arrayOfInt[2] >= 10)
            continue;
          Mine03PersonalActivity.access$602(this.this$0, arrayOfInt[0] + "." + "0" + arrayOfInt[1] + "." + "0" + arrayOfInt[2]);
          Mine03PersonalActivity.access$700(this.this$0).setText(Mine03PersonalActivity.access$600(this.this$0));
          Mine03PersonalActivity.access$000(this.this$0).birthday = Mine03PersonalActivity.access$600(this.this$0);
          Mine03PersonalActivity.access$200(this.this$0);
          this.this$0.setTheme(R.style.AppTheme_Base04);
          return;
          Mine03PersonalActivity.access$602(this.this$0, arrayOfInt[0] + "." + "0" + arrayOfInt[1] + "." + arrayOfInt[2]);
          continue;
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return;
      }
      if (arrayOfInt[2] < 10)
      {
        Mine03PersonalActivity.access$602(this.this$0, arrayOfInt[0] + "." + arrayOfInt[1] + "." + "0" + arrayOfInt[2]);
        continue;
      }
      Mine03PersonalActivity.access$602(this.this$0, arrayOfInt[0] + "." + arrayOfInt[1] + "." + arrayOfInt[2]);
    }
    ToastUtils.makeToast(this.this$0, this.this$0.getString(R.string.re_enter_age));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity.7
 * JD-Core Version:    0.6.0
 */