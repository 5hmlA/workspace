package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.VersionModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.reformer.VersionReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.UpdateDialog;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.middlelib.api.APIManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import rx.Observable;
import rx.Subscriber;

public class Mine04AboutActivity extends BaseActivity
{
  TextView fit_copyright;
  FrameLayout mine04AboutEmail;
  FrameLayout mine04AboutPrivacy;
  FrameLayout mine04AboutService;
  FrameLayout mine04AboutSina;
  FrameLayout mine04AboutTell;
  TextView mine04AboutVersionNum;
  FrameLayout mine04AboutWeichat;
  TextView mine04AboutWeichatNum;
  FrameLayout mine04_check_version_update;
  private CustomToolBar toolbar;

  private void checkVersionUpdate()
  {
    APIManager.checkVersion(this).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        ToastUtils.makeToast(Mine04AboutActivity.this, StringUtils.getStringResources(R.string.version_update_hint));
        Mine04AboutActivity.this.dialog.closeDialog();
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        Mine04AboutActivity.this.dialog.closeDialog();
        VersionReformer localVersionReformer = new VersionReformer();
        localVersionReformer.dataToVersionReformer(paramResponseModel);
        if (!StringUtils.isNull(localVersionReformer._versionModel.title))
          UpdateDialog.UpdateDialog(Mine04AboutActivity.this, localVersionReformer._versionModel);
      }
    });
  }

  public void fitOnClick(View paramView)
  {
    if (R.id.mine04_about_email == paramView.getId())
    {
      Uri localUri = Uri.parse("mailto:love@fitapp.cn");
      String[] arrayOfString = { "love@fitapp.cn" };
      Intent localIntent3 = new Intent("android.intent.action.SENDTO", localUri);
      localIntent3.putExtra("android.intent.extra.EMAIL", arrayOfString);
      localIntent3.putExtra("android.intent.extra.SUBJECT", "");
      localIntent3.putExtra("android.intent.extra.TEXT", "");
      startActivity(Intent.createChooser(localIntent3, getString(R.string.select_mail_application)));
    }
    do
    {
      return;
      if (R.id.mine04_about_tell == paramView.getId())
      {
        String str = getString(R.string.c_59_6);
        Intent localIntent2 = new Intent("android.intent.action.DIAL", Uri.parse("tel:" + str));
        localIntent2.setFlags(268435456);
        startActivity(localIntent2);
        return;
      }
      if (R.id.mine04_about_sina == paramView.getId())
      {
        FitJumpImpl.getInstance().settingJumpWebView(this, getString(R.string.fit_weibo), "https://weibo.com/fitfitness");
        return;
      }
      if (R.id.mine04_about_weichat == paramView.getId())
      {
        TextUtils.copyToClipboard(getString(R.string.c_59_11));
        ToastUtils.makeToast(this, getString(R.string.copy_to_clipboard));
        Intent localIntent1 = new Intent();
        ComponentName localComponentName = new ComponentName("com.tencent.mm", "com.tencent.mm.ui.LauncherUI");
        localIntent1.setAction("android.intent.action.MAIN");
        localIntent1.addCategory("android.intent.category.LAUNCHER");
        localIntent1.addFlags(268435456);
        localIntent1.setComponent(localComponentName);
        startActivityForResult(localIntent1, 0);
        return;
      }
      if (R.id.mine04_about_sevice == paramView.getId())
      {
        FitJumpImpl.getInstance().settingJumpWebView(this, getString(R.string.c_59_13), VersionUpdateCheck.TERMS_OF_SERVICE);
        return;
      }
      if (R.id.mine04_about_privacy != paramView.getId())
        continue;
      FitJumpImpl.getInstance().settingJumpWebView(this, getString(R.string.c_59_12), VersionUpdateCheck.TERMS_OF_PRIVACY);
      return;
    }
    while (R.id.mine04_check_version_update != paramView.getId());
    if (CompDeviceInfoUtils.checkNetwork())
    {
      this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
      checkVersionUpdate();
      return;
    }
    ToastUtils.makeToast(this, StringUtils.getStringResources(R.string.current_network_again_later));
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine04_about);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.mine04AboutVersionNum = ((TextView)findViewById(R.id.mine04_about_version_num));
    this.mine04AboutEmail = ((FrameLayout)findViewById(R.id.mine04_about_email));
    this.mine04AboutTell = ((FrameLayout)findViewById(R.id.mine04_about_tell));
    this.mine04AboutSina = ((FrameLayout)findViewById(R.id.mine04_about_sina));
    this.mine04AboutWeichat = ((FrameLayout)findViewById(R.id.mine04_about_weichat));
    this.mine04AboutWeichatNum = ((TextView)findViewById(R.id.mine04_about_weichat_num));
    this.mine04AboutPrivacy = ((FrameLayout)findViewById(R.id.mine04_about_privacy));
    this.mine04AboutService = ((FrameLayout)findViewById(R.id.mine04_about_sevice));
    this.mine04_check_version_update = ((FrameLayout)findViewById(R.id.mine04_check_version_update));
    this.fit_copyright = ((TextView)findViewById(R.id.fit_copyright));
    this.fit_copyright.setText(UseStringUtils.getStr(R.string.c_59_14, new String[] { "2019" }));
    this.dialog = new DialogManager();
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(R.string.c_59_1);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    TextView localTextView = this.mine04AboutVersionNum;
    int i = R.string.c_59_2;
    String[] arrayOfString = new String[1];
    arrayOfString[0] = CompDeviceInfoUtils.getVersionCode();
    localTextView.setText(UseStringUtils.getStr(i, arrayOfString));
    this.mine04AboutEmail.setOnClickListener(new FitAction(this));
    this.mine04AboutTell.setOnClickListener(new FitAction(this));
    this.mine04AboutSina.setOnClickListener(new FitAction(this));
    this.mine04AboutWeichat.setOnClickListener(new FitAction(this));
    this.mine04AboutService.setOnClickListener(new FitAction(this));
    this.mine04AboutPrivacy.setOnClickListener(new FitAction(this));
    this.mine04_check_version_update.setOnClickListener(new FitAction(this));
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine04AboutActivity
 * JD-Core Version:    0.6.0
 */