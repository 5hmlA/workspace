package com.sportq.fit.fitmoudle4.setting.activity;

import android.widget.TextView;
import com.sportq.fit.common.utils.LocationHandler.OnLocationListener;
import com.sportq.fit.fitmoudle4.R.string;

class Mine03PersonalActivity$5
  implements LocationHandler.OnLocationListener
{
  public void locationFail()
  {
  }

  public void locationSuccess(String paramString)
  {
    if (paramString.contains("null"))
      paramString = this.this$0.getString(R.string.default_area);
    Mine03PersonalActivity.access$402(this.this$0, paramString);
    Mine03PersonalActivity.access$500(this.this$0).setText(paramString);
    Mine03PersonalActivity.access$000(this.this$0).region = paramString;
    Mine03PersonalActivity.access$200(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity.5
 * JD-Core Version:    0.6.0
 */