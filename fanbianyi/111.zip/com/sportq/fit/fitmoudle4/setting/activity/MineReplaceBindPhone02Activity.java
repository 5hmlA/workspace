package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.MD5Util;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.middlelib.MiddleManager;
import org.greenrobot.eventbus.EventBus;

public class MineReplaceBindPhone02Activity extends BaseActivity
{
  private RTextView confirm_btn;
  private EditText original_password;
  TextView original_phone;
  private RTextViewHelper rTextViewHelper;
  CustomToolBar toolbar;

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.confirm_btn)
    {
      this.dialog.createProgressDialog(this, StringUtils.getStringResources(R.string.wait_hint));
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = BaseApplication.userModel.phoneNumber;
      localRequestModel.password = MD5Util.MD5(this.original_password.getText().toString());
      MiddleManager.getInstance().getMinePresenterImpl(this).checkPhoneNumber(localRequestModel, this);
    }
    super.fitOnClick(paramView);
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    if ("Y".equals(paramT))
    {
      EventBus.getDefault().post("close.bind01");
      Intent localIntent = new Intent(this, MineAddPhoneActivity.class);
      localIntent.putExtra("page.type", "1");
      startActivity(localIntent);
      finish();
      AnimationUtil.pageJumpAnim(this, 0);
    }
    super.getDataSuccess(paramT);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine_replace_phone_layout02);
    this.dialog = new DialogManager();
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.original_phone = ((TextView)findViewById(R.id.original_phone));
    this.original_password = ((EditText)findViewById(R.id.original_password));
    this.confirm_btn = ((RTextView)findViewById(R.id.confirm_btn));
    this.confirm_btn.setEnabled(false);
    this.rTextViewHelper = this.confirm_btn.getHelper();
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(getResources().getString(R.string.c_49_1));
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    this.original_phone.setText(BaseApplication.userModel.phoneNumber);
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        boolean bool = StringUtils.checkPassword(paramString);
        RTextViewHelper localRTextViewHelper1 = MineReplaceBindPhone02Activity.this.rTextViewHelper;
        Resources localResources = MineReplaceBindPhone02Activity.this.getResources();
        int i;
        RTextViewHelper localRTextViewHelper2;
        MineReplaceBindPhone02Activity localMineReplaceBindPhone02Activity;
        if (bool)
        {
          i = R.color.color_ffd208;
          localRTextViewHelper1.setBackgroundColorNormal(localResources.getColor(i));
          localRTextViewHelper2 = MineReplaceBindPhone02Activity.this.rTextViewHelper;
          localMineReplaceBindPhone02Activity = MineReplaceBindPhone02Activity.this;
          if (!bool)
            break label100;
        }
        label100: for (int j = R.color.color_313131; ; j = R.color.white)
        {
          localRTextViewHelper2.setTextColorNormal(ContextCompat.getColor(localMineReplaceBindPhone02Activity, j));
          MineReplaceBindPhone02Activity.this.confirm_btn.setEnabled(bool);
          return;
          i = R.color.color_c8c8c8;
          break;
        }
      }
    }
    , this.original_password);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.MineReplaceBindPhone02Activity
 * JD-Core Version:    0.6.0
 */