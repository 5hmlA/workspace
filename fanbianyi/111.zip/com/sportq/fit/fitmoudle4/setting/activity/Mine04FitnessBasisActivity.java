package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.QuestionnaireModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.QuestionnaireReformer;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.middlelib.MiddleManager;
import java.util.ArrayList;

public class Mine04FitnessBasisActivity extends BaseActivity
{
  private String btnCode01;
  private String btnCode02;
  private String btnCode03;
  String comeFlg;
  RadioButton intermediateState;
  private RadioGroup mine03FitnessRadioGroup;
  private TextView mine04FitnessIntermediate;
  TextView mine04FitnessIntermediateText;
  private TextView mine04FitnessPrimary;
  TextView mine04FitnessPrimaryText;
  private TextView mine04FitnessSenior;
  TextView mine04FitnessSeniorText;
  RadioButton primaryState;
  private String selectContent;
  RadioButton seniorState;
  CustomToolBar toolbar;

  private void onBack()
  {
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.fitGoal = BaseApplication.userModel.fitGoal;
    localRequestModel.fitBase = BaseApplication.userModel.fitBase;
    MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(localRequestModel, this);
    Intent localIntent = new Intent();
    localIntent.putExtra("seceltcontext", this.selectContent);
    setResult(-1, localIntent);
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  private void selectOnFouce(int paramInt)
  {
    this.mine03FitnessRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(paramInt)
    {
      @Instrumented
      public void onCheckedChanged(RadioGroup paramRadioGroup, int paramInt)
      {
        VdsAgent.onCheckedChanged(this, paramRadioGroup, paramInt);
        if (this.val$fig == 0)
          if (R.id.primary_state == paramInt)
          {
            Mine04FitnessBasisActivity.access$002(Mine04FitnessBasisActivity.this, Mine04FitnessBasisActivity.this.mine04FitnessPrimary.getText().toString());
            BaseApplication.userModel.fitGoal = Mine04FitnessBasisActivity.this.btnCode01;
          }
        do
        {
          do
          {
            return;
            if (R.id.intermediate_state != paramInt)
              continue;
            Mine04FitnessBasisActivity.access$002(Mine04FitnessBasisActivity.this, Mine04FitnessBasisActivity.this.mine04FitnessIntermediate.getText().toString());
            BaseApplication.userModel.fitGoal = Mine04FitnessBasisActivity.this.btnCode02;
            return;
          }
          while (R.id.senior_state != paramInt);
          Mine04FitnessBasisActivity.access$002(Mine04FitnessBasisActivity.this, Mine04FitnessBasisActivity.this.mine04FitnessSenior.getText().toString());
          BaseApplication.userModel.fitGoal = Mine04FitnessBasisActivity.this.btnCode03;
          return;
          if (R.id.primary_state == paramInt)
          {
            Mine04FitnessBasisActivity.access$002(Mine04FitnessBasisActivity.this, Mine04FitnessBasisActivity.this.mine04FitnessPrimary.getText().toString());
            BaseApplication.userModel.fitBase = Mine04FitnessBasisActivity.this.btnCode01;
            return;
          }
          if (R.id.intermediate_state != paramInt)
            continue;
          Mine04FitnessBasisActivity.access$002(Mine04FitnessBasisActivity.this, Mine04FitnessBasisActivity.this.mine04FitnessIntermediate.getText().toString());
          BaseApplication.userModel.fitBase = Mine04FitnessBasisActivity.this.btnCode02;
          return;
        }
        while (R.id.senior_state != paramInt);
        Mine04FitnessBasisActivity.access$002(Mine04FitnessBasisActivity.this, Mine04FitnessBasisActivity.this.mine04FitnessSenior.getText().toString());
        BaseApplication.userModel.fitBase = Mine04FitnessBasisActivity.this.btnCode03;
      }
    });
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine04_fitness_basis);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.mine04FitnessPrimary = ((TextView)findViewById(R.id.mine04_fitness_primary));
    this.mine04FitnessPrimaryText = ((TextView)findViewById(R.id.mine04_fitness_primary_text));
    this.mine04FitnessIntermediate = ((TextView)findViewById(R.id.mine04_fitness_intermediate));
    this.mine04FitnessIntermediateText = ((TextView)findViewById(R.id.mine04_fitness_intermediate_text));
    this.mine04FitnessSenior = ((TextView)findViewById(R.id.mine04_fitness_senior));
    this.mine04FitnessSeniorText = ((TextView)findViewById(R.id.mine04_fitness_senior_text));
    this.mine03FitnessRadioGroup = ((RadioGroup)findViewById(R.id.mine03_fitness_radiogroup));
    this.primaryState = ((RadioButton)findViewById(R.id.primary_state));
    this.intermediateState = ((RadioButton)findViewById(R.id.intermediate_state));
    this.seniorState = ((RadioButton)findViewById(R.id.senior_state));
    this.comeFlg = getIntent().getExtras().getString("comeflg");
    if ("0".equals(this.comeFlg))
    {
      this.toolbar.setTitle(R.string.c_51_2);
      this.mine04FitnessPrimary.setText(((QuestionnaireModel)BaseApplication.quReformer._customizedTargetArray.get(0)).name);
      this.mine04FitnessPrimaryText.setText(((QuestionnaireModel)BaseApplication.quReformer._customizedTargetArray.get(0)).comment);
      this.btnCode01 = ((QuestionnaireModel)BaseApplication.quReformer._customizedTargetArray.get(0)).code;
      this.mine04FitnessIntermediate.setText(((QuestionnaireModel)BaseApplication.quReformer._customizedTargetArray.get(1)).name);
      this.mine04FitnessIntermediateText.setText(((QuestionnaireModel)BaseApplication.quReformer._customizedTargetArray.get(1)).comment);
      this.btnCode02 = ((QuestionnaireModel)BaseApplication.quReformer._customizedTargetArray.get(1)).code;
      this.mine04FitnessSenior.setText(((QuestionnaireModel)BaseApplication.quReformer._customizedTargetArray.get(2)).name);
      this.mine04FitnessSeniorText.setText(((QuestionnaireModel)BaseApplication.quReformer._customizedTargetArray.get(2)).comment);
      this.btnCode03 = ((QuestionnaireModel)BaseApplication.quReformer._customizedTargetArray.get(2)).code;
      selectOnFouce(0);
      if (BaseApplication.userModel.fitGoal.equals(this.btnCode01))
        this.primaryState.setChecked(true);
    }
    while (true)
    {
      this.toolbar.setNavIcon(R.mipmap.btn_back_black);
      this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
      this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
      setSupportActionBar(this.toolbar);
      return;
      if (BaseApplication.userModel.fitGoal.equals(this.btnCode02))
      {
        this.intermediateState.setChecked(true);
        continue;
      }
      if (!BaseApplication.userModel.fitGoal.equals(this.btnCode03))
        continue;
      this.seniorState.setChecked(true);
      continue;
      this.toolbar.setTitle(R.string.c_51_3);
      this.mine04FitnessPrimary.setText(((QuestionnaireModel)BaseApplication.quReformer._customizedDifficultArray.get(0)).name);
      this.btnCode01 = ((QuestionnaireModel)BaseApplication.quReformer._customizedDifficultArray.get(0)).code;
      this.mine04FitnessPrimaryText.setText(BaseApplication.quReformer.getDifficultcomment(0));
      this.mine04FitnessIntermediate.setText(((QuestionnaireModel)BaseApplication.quReformer._customizedDifficultArray.get(1)).name);
      this.mine04FitnessIntermediateText.setText(BaseApplication.quReformer.getDifficultcomment(1));
      this.btnCode02 = ((QuestionnaireModel)BaseApplication.quReformer._customizedDifficultArray.get(1)).code;
      this.mine04FitnessSenior.setText(((QuestionnaireModel)BaseApplication.quReformer._customizedDifficultArray.get(2)).name);
      this.mine04FitnessSeniorText.setText(BaseApplication.quReformer.getDifficultcomment(2));
      this.btnCode03 = ((QuestionnaireModel)BaseApplication.quReformer._customizedDifficultArray.get(2)).code;
      selectOnFouce(1);
      if (BaseApplication.userModel.fitBase.equals(this.btnCode01))
      {
        this.primaryState.setChecked(true);
        continue;
      }
      if (BaseApplication.userModel.fitBase.equals(this.btnCode02))
      {
        this.intermediateState.setChecked(true);
        continue;
      }
      if (!BaseApplication.userModel.fitBase.equals(this.btnCode03))
        continue;
      this.seniorState.setChecked(true);
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      onBack();
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      onBack();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine04FitnessBasisActivity
 * JD-Core Version:    0.6.0
 */