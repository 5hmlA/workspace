package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.MD5Util;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;
import com.sportq.fit.fitmoudle.network.reformer.NeceDataUIReformer;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.middlelib.MiddleManager;
import java.util.concurrent.TimeUnit;
import org.greenrobot.eventbus.EventBus;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class MineAddPhoneActivity extends BaseActivity
{
  public static final String PAGE_TYPE = "page.type";
  private RTextView confirm_btn;
  private EditText editCode;
  private EditText editPassword;
  private EditText editPhoneNum;
  private RTextView get_verification_code;
  private boolean isSetPassword;
  private String mineCode = "";
  private String minePassword = "";
  private String minePhoneNum = "";
  private FrameLayout password_layout;
  private TextView password_view;
  TextView phone_type;
  private RTextViewHelper rTextViewHelper;
  private RTextViewHelper rTextViewHelper02;
  private String strPageType;
  private Subscription subscription;
  CustomToolBar toolbar;

  private void checkConfirmState()
  {
    boolean bool = true;
    int i;
    label56: RTextViewHelper localRTextViewHelper2;
    if ("1".equals(this.strPageType))
      if ((this.minePhoneNum.length() == 11) && (this.mineCode.length() == 4))
      {
        RTextViewHelper localRTextViewHelper1 = this.rTextViewHelper;
        Resources localResources = getResources();
        if (!bool)
          break label149;
        i = R.color.color_ffd208;
        localRTextViewHelper1.setBackgroundColorNormal(localResources.getColor(i));
        localRTextViewHelper2 = this.rTextViewHelper;
        if (!bool)
          break label157;
      }
    label149: label157: for (int j = R.color.color_313131; ; j = R.color.white)
    {
      localRTextViewHelper2.setTextColorNormal(ContextCompat.getColor(this, j));
      this.confirm_btn.setEnabled(bool);
      return;
      bool = false;
      break;
      if ((this.minePhoneNum.length() == 11) && (StringUtils.checkPassword(this.minePassword)) && (this.mineCode.length() == 4))
        break;
      while (true)
        bool = false;
      i = R.color.color_c8c8c8;
      break label56;
    }
  }

  private String[] getPageCopy()
  {
    String[] arrayOfString = new String[2];
    String str = this.strPageType;
    int i = -1;
    switch (str.hashCode())
    {
    default:
      switch (i)
      {
      default:
        label80: if (!"1".equals(this.strPageType));
      case 0:
      case 1:
      case 2:
      case 3:
      }
    case 48:
    case 49:
    case 50:
    case 51:
    }
    for (int j = R.string.c_87_2; ; j = R.string.c_43_2)
    {
      arrayOfString[1] = getString(j);
      return arrayOfString;
      if (!str.equals("0"))
        break;
      i = 0;
      break;
      if (!str.equals("1"))
        break;
      i = 1;
      break;
      if (!str.equals("2"))
        break;
      i = 2;
      break;
      if (!str.equals("3"))
        break;
      i = 3;
      break;
      arrayOfString[0] = getString(R.string.c_43_1);
      break label80;
      arrayOfString[0] = getString(R.string.c_87_1);
      break label80;
      arrayOfString[0] = getString(R.string.c_45_1);
      break label80;
      arrayOfString[0] = getString(R.string.c_50_1);
      break label80;
    }
  }

  public void fitOnClick(View paramView)
  {
    this.editPhoneNum.clearFocus();
    this.editCode.clearFocus();
    this.editPassword.clearFocus();
    if (paramView.getId() == R.id.get_verification_code)
    {
      if (StringUtils.isNull(this.minePhoneNum))
      {
        ToastUtils.makeToast(this, StringUtils.getStringResources(R.string.c_43_3));
        return;
      }
      if (!StringUtils.checkNumber(this.minePhoneNum))
      {
        ToastUtils.makeToast(this, StringUtils.getStringResources(R.string.c_43_9));
        return;
      }
      this.dialog.createProgressDialog(this, StringUtils.getStringResources(R.string.wait_hint));
      RequestModel localRequestModel2 = new RequestModel();
      localRequestModel2.phoneNumber = this.minePhoneNum;
      new PresenterImpl(this).getNeceData(localRequestModel2, this);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() != R.id.confirm_btn)
        continue;
      this.dialog.createProgressDialog(this, StringUtils.getStringResources(R.string.wait_hint));
      if (!this.isSetPassword)
        break;
      MiddleManager.getInstance().getLoginPresenterImpl(this).setPasswordWithCode(this.minePhoneNum, this.minePassword, this.mineCode, this);
    }
    RequestModel localRequestModel1 = new RequestModel();
    localRequestModel1.phoneNumber = this.minePhoneNum;
    localRequestModel1.verification = this.mineCode;
    if ("0".equals(this.strPageType));
    for (String str = MD5Util.MD5(this.minePassword); ; str = BaseApplication.userModel.password)
    {
      localRequestModel1.password = str;
      MiddleManager.getInstance().getMinePresenterImpl(this).addPhoneNumber(localRequestModel1, this);
      break;
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, String.valueOf(paramT));
  }

  public <T> void getDataSuccess(T paramT)
  {
    String str2;
    if ((paramT instanceof NeceDataUIReformer))
    {
      String str1 = ((NeceDataUIReformer)paramT).timeKey;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = this.minePhoneNum;
      if (this.isSetPassword)
      {
        str2 = "5";
        localRequestModel.acquisitionMode = str2;
        localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(str1 + NdkUtils.getSignBaseUrl()).toUpperCase();
        MiddleManager.getInstance().getLoginPresenterImpl(this).getVerification(localRequestModel, this);
      }
    }
    label199: 
    do
    {
      LoginReformer localLoginReformer;
      do
      {
        return;
        str2 = "0";
        break;
        if (!(paramT instanceof LoginReformer))
          break label199;
        localLoginReformer = (LoginReformer)paramT;
        if (!"0".equals(localLoginReformer.tag))
          continue;
        this.dialog.closeDialog();
        startTimeCountdown();
        return;
      }
      while (!"1".equals(localLoginReformer.tag));
      BaseApplication.userModel.phoneNumber = this.minePhoneNum;
      EventBus.getDefault().post("have.phone");
      SharePreferenceUtils.putIsClickUnbindCloseBtn(this, BaseApplication.userModel.userId, "0");
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      return;
    }
    while (!"Y".equals(paramT));
    if ("2".equals(this.strPageType));
    for (int i = R.string.c_96_1_6; ; i = R.string.c_50_6)
    {
      ToastUtils.makeToast(getString(i));
      BaseApplication.userModel.password = MD5Util.MD5(this.minePassword);
      EventBus.getDefault().post("set.password.success");
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      return;
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine_add_phone_layout);
    this.dialog = new DialogManager();
    this.strPageType = getIntent().getStringExtra("page.type");
    boolean bool;
    int i;
    label356: TextView localTextView;
    if (("2".equals(this.strPageType)) || ("3".equals(this.strPageType)))
    {
      bool = true;
      this.isSetPassword = bool;
      String[] arrayOfString = getPageCopy();
      this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
      this.toolbar.setNavIcon(R.mipmap.btn_back_black);
      this.toolbar.setTitle(arrayOfString[0]);
      this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
      this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
      setSupportActionBar(this.toolbar);
      this.phone_type = ((TextView)findViewById(R.id.phone_type));
      this.editPhoneNum = ((EditText)findViewById(R.id.phone_num));
      this.editCode = ((EditText)findViewById(R.id.verification_code));
      this.get_verification_code = ((RTextView)findViewById(R.id.get_verification_code));
      this.rTextViewHelper02 = this.get_verification_code.getHelper();
      this.password_layout = ((FrameLayout)findViewById(R.id.password_layout));
      this.password_view = ((TextView)findViewById(R.id.password_view));
      this.editPassword = ((EditText)findViewById(R.id.password));
      this.confirm_btn = ((RTextView)findViewById(R.id.confirm_btn));
      this.rTextViewHelper = this.confirm_btn.getHelper();
      this.confirm_btn.setEnabled(false);
      TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
      {
        public void onChangeResult(String paramString)
        {
          MineAddPhoneActivity.access$002(MineAddPhoneActivity.this, paramString);
          MineAddPhoneActivity.this.checkConfirmState();
        }
      }
      , this.editPhoneNum);
      TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
      {
        public void onChangeResult(String paramString)
        {
          MineAddPhoneActivity.access$202(MineAddPhoneActivity.this, paramString);
          MineAddPhoneActivity.this.checkConfirmState();
        }
      }
      , this.editCode);
      TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
      {
        public void onChangeResult(String paramString)
        {
          MineAddPhoneActivity.access$302(MineAddPhoneActivity.this, paramString);
          MineAddPhoneActivity.this.checkConfirmState();
        }
      }
      , this.editPassword);
      this.phone_type.setText(arrayOfString[1]);
      FrameLayout localFrameLayout = this.password_layout;
      if (!"1".equals(this.strPageType))
        break label445;
      i = 8;
      localFrameLayout.setVisibility(i);
      localTextView = this.password_view;
      if (!"3".equals(this.strPageType))
        break label451;
    }
    label445: label451: for (int j = R.string.c_17_1_3; ; j = R.string.c_96_1_4)
    {
      localTextView.setText(getString(j));
      if (this.isSetPassword)
      {
        this.editPhoneNum.setText(BaseApplication.userModel.phoneNumber);
        this.editPhoneNum.setTextColor(ContextCompat.getColor(this, R.color.color_c8c8c8));
        this.editPhoneNum.setEnabled(false);
      }
      return;
      bool = false;
      break;
      i = 0;
      break label356;
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  public void startTimeCountdown()
  {
    this.get_verification_code.setText("60s");
    this.rTextViewHelper02.setTextColorNormal(ContextCompat.getColor(this, R.color.white));
    this.rTextViewHelper02.setBackgroundColorNormal(ContextCompat.getColor(this, R.color.color_c8c8c8));
    this.get_verification_code.setEnabled(false);
    this.subscription = Observable.interval(1L, TimeUnit.SECONDS).take(61).onBackpressureBuffer().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1()
    {
      public void call(Long paramLong)
      {
        if (paramLong.longValue() == 60L)
        {
          MineAddPhoneActivity.this.subscription.unsubscribe();
          MineAddPhoneActivity.access$402(MineAddPhoneActivity.this, null);
          MineAddPhoneActivity.this.rTextViewHelper02.setTextColorNormal(ContextCompat.getColor(MineAddPhoneActivity.this, R.color.color_313131));
          MineAddPhoneActivity.this.rTextViewHelper02.setBackgroundColorNormal(ContextCompat.getColor(MineAddPhoneActivity.this, R.color.color_ffd208));
          MineAddPhoneActivity.this.get_verification_code.setText(StringUtils.getStringResources(R.string.d_28_4));
          MineAddPhoneActivity.this.get_verification_code.setEnabled(true);
          return;
        }
        MineAddPhoneActivity.this.get_verification_code.setText(String.valueOf(59L - paramLong.longValue() + "s"));
      }
    });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.MineAddPhoneActivity
 * JD-Core Version:    0.6.0
 */