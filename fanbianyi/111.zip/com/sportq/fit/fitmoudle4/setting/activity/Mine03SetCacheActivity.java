package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Environment;
import android.os.Looper;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.model.CacheDBModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.imageloader.StringSupport;
import com.sportq.fit.common.utils.masterCache.MasterCacheDBManager;
import com.sportq.fit.common.utils.masterCache.MasterCacheManager;
import com.sportq.fit.common.utils.masterCache.MasterCacheModel;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.videopresenter.manager.cachemanager.VideoCacheDBManager;
import com.sportq.fit.videopresenter.manager.cachemanager.VideoCacheManager;
import com.stub.StubApp;
import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Mine03SetCacheActivity extends BaseActivity
{
  private static final String TAG;
  FrameLayout clear_focus_video_cache;
  FrameLayout clear_image_cache;
  FrameLayout clear_master_video_cache;
  FrameLayout clear_train_video_cache;
  private String focusVideoPath = VersionUpdateCheck.KANKAN_VIDEO_FILE_NAME;
  TextView focus_video_cache_size;
  List<CacheDBModel> focus_video_data = new ArrayList();
  TextView image_cache_size;
  String imgPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data/" + "fit/find.image.cache" + StringSupport.underscore("ImageCache".replaceAll("\\s", ""));
  private boolean isDestroyed = false;
  private String masterVideoPath = VersionUpdateCheck.MASTER_CACHE_FILE_NAME;
  TextView master_video_cache_size;
  List<MasterCacheModel> master_video_data = new ArrayList();
  CustomToolBar toolBar;
  private String trainMusicPath = VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME;
  private String trainVideoPath = VersionUpdateCheck.ALBUM_VIDEO_FILE_NAME;
  TextView train_video_cache_size;

  static
  {
    StubApp.interface11(11838);
    TAG = Mine03SetCacheActivity.class.getName();
  }

  private void deleteFolderFile(String paramString, boolean paramBoolean)
  {
    if (!TextUtils.isEmpty(paramString))
      try
      {
        File localFile = new File(paramString);
        if (localFile.isDirectory())
        {
          File[] arrayOfFile = localFile.listFiles();
          int i = arrayOfFile.length;
          for (int j = 0; j < i; j++)
            deleteFolderFile(arrayOfFile[j].getAbsolutePath(), true);
        }
        if (paramBoolean)
        {
          if (!localFile.isDirectory())
          {
            localFile.delete();
            return;
          }
          if (localFile.listFiles().length == 0)
          {
            localFile.delete();
            return;
          }
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }

  private String getAutoFileOrFilesSize(String paramString1, String paramString2)
  {
    File localFile1 = new File(paramString1);
    File localFile2 = new File(paramString2);
    long l1 = 0L;
    try
    {
      long l2;
      long l4;
      if (localFile1.isDirectory())
      {
        l2 = getFileSizes(localFile1);
        if (!localFile2.isDirectory())
          break label82;
        long l5 = getFileSizes(localFile2);
        l4 = l5;
      }
      while (true)
      {
        l1 = l2 + l4;
        if (l1 != 0L)
          break label106;
        return "0.0M";
        l2 = getFileSize(localFile1);
        break;
        label82: long l3 = getFileSize(localFile2);
        l4 = l3;
      }
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
    label106: return FileUtils.formatFileSize(l1);
  }

  // ERROR //
  private static long getFileSize(File paramFile)
  {
    // Byte code:
    //   0: lconst_0
    //   1: lstore_1
    //   2: aload_0
    //   3: invokevirtual 190	java/io/File:exists	()Z
    //   6: ifeq +101 -> 107
    //   9: aconst_null
    //   10: astore 5
    //   12: new 192	java/io/FileInputStream
    //   15: dup
    //   16: aload_0
    //   17: invokespecial 195	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   20: astore 6
    //   22: aload 6
    //   24: invokevirtual 199	java/io/FileInputStream:available	()I
    //   27: istore 11
    //   29: iload 11
    //   31: i2l
    //   32: lstore_1
    //   33: aload 6
    //   35: ifnull +8 -> 43
    //   38: aload 6
    //   40: invokevirtual 202	java/io/FileInputStream:close	()V
    //   43: lload_1
    //   44: lreturn
    //   45: astore 12
    //   47: aload 12
    //   49: invokestatic 179	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   52: lload_1
    //   53: lreturn
    //   54: astore 7
    //   56: aload 7
    //   58: invokestatic 179	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   61: aload 5
    //   63: ifnull -20 -> 43
    //   66: aload 5
    //   68: invokevirtual 202	java/io/FileInputStream:close	()V
    //   71: lload_1
    //   72: lreturn
    //   73: astore 10
    //   75: aload 10
    //   77: invokestatic 179	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   80: lload_1
    //   81: lreturn
    //   82: astore 8
    //   84: aload 5
    //   86: ifnull +8 -> 94
    //   89: aload 5
    //   91: invokevirtual 202	java/io/FileInputStream:close	()V
    //   94: aload 8
    //   96: athrow
    //   97: astore 9
    //   99: aload 9
    //   101: invokestatic 179	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   104: goto -10 -> 94
    //   107: aload_0
    //   108: invokevirtual 205	java/io/File:createNewFile	()Z
    //   111: pop
    //   112: lload_1
    //   113: lreturn
    //   114: astore_3
    //   115: aload_3
    //   116: invokestatic 179	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   119: lload_1
    //   120: lreturn
    //   121: astore 8
    //   123: aload 6
    //   125: astore 5
    //   127: goto -43 -> 84
    //   130: astore 7
    //   132: aload 6
    //   134: astore 5
    //   136: goto -80 -> 56
    //
    // Exception table:
    //   from	to	target	type
    //   38	43	45	java/io/IOException
    //   12	22	54	java/io/IOException
    //   66	71	73	java/io/IOException
    //   12	22	82	finally
    //   56	61	82	finally
    //   89	94	97	java/io/IOException
    //   107	112	114	java/io/IOException
    //   22	29	121	finally
    //   22	29	130	java/io/IOException
  }

  private long getFileSizes(File paramFile)
  {
    long l;
    if (this.isDestroyed)
    {
      LogUtils.d(TAG, "getFileSizes外部拦截");
      l = 0L;
    }
    File[] arrayOfFile;
    do
    {
      return l;
      l = 0L;
      arrayOfFile = paramFile.listFiles();
    }
    while ((arrayOfFile == null) || (arrayOfFile.length == 0));
    int i = arrayOfFile.length;
    int j = 0;
    label46: File localFile;
    if (j < i)
    {
      localFile = arrayOfFile[j];
      if (this.isDestroyed)
      {
        LogUtils.d(TAG, "getFileSizes内部拦截");
        return 0L;
      }
      if (!localFile.isDirectory())
        break label100;
      l += getFileSizes(localFile);
    }
    while (true)
    {
      j++;
      break label46;
      break;
      label100: l += getFileSize(localFile);
    }
  }

  private long getFolderSize(File paramFile)
  {
    File localFile1 = new File(this.imgPath);
    long l1;
    if (localFile1.isDirectory())
      l1 = 0L + getFileSizes(localFile1);
    try
    {
      File[] arrayOfFile = paramFile.listFiles();
      int i = arrayOfFile.length;
      int j = 0;
      label41: if (j < i)
      {
        File localFile2 = arrayOfFile[j];
        if (localFile2.isDirectory())
        {
          long l3 = getFolderSize(localFile2);
          l1 += l3;
        }
        while (true)
        {
          j++;
          break label41;
          l1 = 0L + getFileSize(localFile1);
          break;
          long l2 = localFile2.length();
          l1 += l2;
        }
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return l1;
  }

  private static String getFormatSize(double paramDouble)
  {
    double d1 = paramDouble / 1024.0D;
    if (d1 == 0.0D)
      return "0.0M";
    if (d1 < 1.0D)
      return paramDouble + "Byte";
    double d2 = d1 / 1024.0D;
    if (d2 < 1.0D)
    {
      BigDecimal localBigDecimal1 = new BigDecimal(Double.toString(d1));
      return localBigDecimal1.setScale(2, 4).toPlainString() + "KB";
    }
    double d3 = d2 / 1024.0D;
    if (d3 < 1.0D)
    {
      BigDecimal localBigDecimal2 = new BigDecimal(Double.toString(d2));
      return localBigDecimal2.setScale(2, 4).toPlainString() + "MB";
    }
    double d4 = d3 / 1024.0D;
    if (d4 < 1.0D)
    {
      BigDecimal localBigDecimal3 = new BigDecimal(Double.toString(d3));
      return localBigDecimal3.setScale(2, 4).toPlainString() + "GB";
    }
    BigDecimal localBigDecimal4 = new BigDecimal(d4);
    return localBigDecimal4.setScale(2, 4).toPlainString() + "TB";
  }

  private void initData()
  {
    this.toolBar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.toolBar.setNavIcon(R.mipmap.btn_back_black);
    this.toolBar.setAppTitle(getString(R.string.c_34_7));
    this.toolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolBar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolBar);
    this.clear_image_cache = ((FrameLayout)findViewById(R.id.clear_image_cache));
    this.clear_train_video_cache = ((FrameLayout)findViewById(R.id.clear_train_video_cache));
    this.clear_focus_video_cache = ((FrameLayout)findViewById(R.id.clear_focus_video_cache));
    this.clear_master_video_cache = ((FrameLayout)findViewById(R.id.clear_master_video_cache));
    this.image_cache_size = ((TextView)findViewById(R.id.image_cache_size));
    this.train_video_cache_size = ((TextView)findViewById(R.id.train_video_cache_size));
    this.focus_video_cache_size = ((TextView)findViewById(R.id.focus_video_cache_size));
    this.master_video_cache_size = ((TextView)findViewById(R.id.master_video_cache_size));
    this.image_cache_size.setText(getCacheSize(this));
    this.train_video_cache_size.setText(getAutoFileOrFilesSize(this.trainVideoPath, this.trainMusicPath));
    this.focus_video_data = VideoCacheDBManager.getIntance().selectAll();
    Object localObject1;
    long l1;
    String str1;
    label293: Object localObject2;
    label326: long l2;
    TextView localTextView2;
    if (this.focus_video_data == null)
    {
      localObject1 = new ArrayList();
      this.focus_video_data = ((List)localObject1);
      l1 = 0L;
      if (this.focus_video_data.size() > 0)
        l1 = getFileSizes(new File(this.focusVideoPath));
      TextView localTextView1 = this.focus_video_cache_size;
      if (l1 != 0L)
        break label397;
      str1 = "0.0M";
      localTextView1.setText(str1);
      this.master_video_data = MasterCacheDBManager.getIntance().selectAll();
      if (this.master_video_data != null)
        break label406;
      localObject2 = new ArrayList();
      this.master_video_data = ((List)localObject2);
      l2 = 0L;
      if (this.master_video_data.size() > 0)
        l2 = getFileSizes(new File(this.masterVideoPath));
      localTextView2 = this.master_video_cache_size;
      if (l2 != 0L)
        break label415;
    }
    label397: label406: label415: for (String str2 = "0.0M"; ; str2 = FileUtils.formatFileSize(l2))
    {
      localTextView2.setText(str2);
      return;
      localObject1 = this.focus_video_data;
      break;
      str1 = FileUtils.formatFileSize(l1);
      break label293;
      localObject2 = this.master_video_data;
      break label326;
    }
  }

  public void clearImageAllCache(Context paramContext)
  {
    clearImageDiskCache(paramContext);
    clearImageMemoryCache(paramContext);
    deleteFolderFile(paramContext.getExternalCacheDir() + "image_manager_disk_cache", true);
  }

  public void clearImageDiskCache(Context paramContext)
  {
    try
    {
      if (Looper.myLooper() == Looper.getMainLooper())
      {
        new Thread(new Runnable(paramContext)
        {
          public void run()
          {
            Glide.get(this.val$context).clearDiskCache();
          }
        }).start();
        return;
      }
      Glide.get(paramContext).clearDiskCache();
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public void clearImageMemoryCache(Context paramContext)
  {
    try
    {
      if (Looper.myLooper() == Looper.getMainLooper())
        Glide.get(paramContext).clearMemory();
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.clear_image_cache)
    {
      if ("0.0M".equals(this.image_cache_size.getText().toString()))
        return;
      new DialogManager().createChoiceDialog(new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
        {
          if (paramInt == -1)
            CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
            {
              public void result(boolean paramBoolean)
              {
                if (paramBoolean)
                {
                  FileUtils.delAllFile(Mine03SetCacheActivity.this.imgPath);
                  Mine03SetCacheActivity.this.clearImageAllCache(Mine03SetCacheActivity.this);
                  ToastUtils.makeToast(Mine03SetCacheActivity.this, Mine03SetCacheActivity.this.getString(R.string.cleanup_finish));
                  Mine03SetCacheActivity.this.image_cache_size.setText(Mine03SetCacheActivity.this.getCacheSize(Mine03SetCacheActivity.this));
                }
              }
            }
            , Mine03SetCacheActivity.this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
        }
      }
      , this, "清除图片缓存", "本操作将会清除图片缓存", "清除", "取消");
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() == R.id.clear_train_video_cache)
      {
        if ("0.0M".equals(this.train_video_cache_size.getText().toString()))
          break;
        new DialogManager().createChoiceDialog(new FitInterfaceUtils.DialogListener()
        {
          public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
          {
            if (paramInt == -1)
              CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
              {
                public void result(boolean paramBoolean)
                {
                  if (paramBoolean)
                  {
                    FileUtils.delAllFile(Mine03SetCacheActivity.this.trainVideoPath);
                    FileUtils.delAllFile(Mine03SetCacheActivity.this.trainMusicPath);
                    Mine03SetCacheActivity.this.train_video_cache_size.setText(Mine03SetCacheActivity.this.getAutoFileOrFilesSize(Mine03SetCacheActivity.this.trainVideoPath, Mine03SetCacheActivity.this.trainMusicPath));
                    ToastUtils.makeToast(Mine03SetCacheActivity.this, Mine03SetCacheActivity.this.getString(R.string.cleanup_finish));
                    SharePreferenceUtils.putDownLoadedSinglePlanId(Mine03SetCacheActivity.this, "");
                    SharePreferenceUtils.delAllCourseBgMusicName();
                  }
                }
              }
              , Mine03SetCacheActivity.this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
          }
        }
        , this, "清除训练视频缓存", "本操作将会清除训练视频缓存", "清除", "取消");
        continue;
      }
      if (paramView.getId() == R.id.clear_focus_video_cache)
      {
        if ("0.0M".equals(this.focus_video_cache_size.getText().toString()))
          break;
        new DialogManager().createChoiceDialog(new FitInterfaceUtils.DialogListener()
        {
          public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
          {
            if (paramInt == -1)
              CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
              {
                public void result(boolean paramBoolean)
                {
                  if (paramBoolean)
                  {
                    FileUtils.delAllFile(Mine03SetCacheActivity.this.focusVideoPath);
                    VideoCacheDBManager.getIntance().delete(Mine03SetCacheActivity.this.focus_video_data);
                    VideoCacheManager.deleteCache(Mine03SetCacheActivity.this.focus_video_data);
                    Mine03SetCacheActivity.this.focus_video_cache_size.setText("0.0M");
                    ToastUtils.makeToast(Mine03SetCacheActivity.this, Mine03SetCacheActivity.this.getString(R.string.cleanup_finish));
                  }
                }
              }
              , Mine03SetCacheActivity.this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
          }
        }
        , this, getString(R.string.c_24_1_1), "本操作将会清除看点视频缓存", "清除", "取消");
        continue;
      }
      if (paramView.getId() != R.id.clear_master_video_cache)
        continue;
      if ("0.0M".equals(this.master_video_cache_size.getText().toString()))
        break;
      new DialogManager().createChoiceDialog(new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
        {
          if (paramInt == -1)
            CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
            {
              public void result(boolean paramBoolean)
              {
                if (paramBoolean)
                {
                  FileUtils.delAllFile(Mine03SetCacheActivity.this.masterVideoPath);
                  MasterCacheDBManager.getIntance().delete(Mine03SetCacheActivity.this.master_video_data);
                  MasterCacheManager.getInstance().deleteCache(Mine03SetCacheActivity.this.master_video_data);
                  Mine03SetCacheActivity.this.master_video_cache_size.setText("0.0M");
                  ToastUtils.makeToast(Mine03SetCacheActivity.this, Mine03SetCacheActivity.this.getString(R.string.cleanup_finish));
                }
              }
            }
            , Mine03SetCacheActivity.this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
        }
      }
      , this, getString(R.string.c_24_1_2), "本操作将会清除大师课堂缓存", "清除", "取消");
    }
  }

  public String getCacheSize(Context paramContext)
  {
    try
    {
      String str = getFormatSize(getFolderSize(new File(paramContext.getCacheDir() + "/" + "image_manager_disk_cache")));
      return str;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return "";
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine03_set_cache);
    initData();
  }

  protected void onDestroy()
  {
    super.onDestroy();
    this.isDestroyed = true;
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03SetCacheActivity
 * JD-Core Version:    0.6.0
 */