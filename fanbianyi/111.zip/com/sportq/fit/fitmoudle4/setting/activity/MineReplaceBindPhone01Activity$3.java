package com.sportq.fit.fitmoudle4.setting.activity;

import android.support.v4.content.ContextCompat;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.string;
import rx.Subscription;
import rx.functions.Action1;

class MineReplaceBindPhone01Activity$3
  implements Action1<Long>
{
  public void call(Long paramLong)
  {
    if (paramLong.longValue() == 60L)
    {
      MineReplaceBindPhone01Activity.access$200(this.this$0).unsubscribe();
      MineReplaceBindPhone01Activity.access$202(this.this$0, null);
      MineReplaceBindPhone01Activity.access$300(this.this$0).setEnabled(true);
      MineReplaceBindPhone01Activity.access$400(this.this$0).setTextColorNormal(ContextCompat.getColor(this.this$0, R.color.color_313131));
      MineReplaceBindPhone01Activity.access$400(this.this$0).setBackgroundColorNormal(ContextCompat.getColor(this.this$0, R.color.color_ffd208));
      MineReplaceBindPhone01Activity.access$300(this.this$0).setText(StringUtils.getStringResources(R.string.d_28_4));
      return;
    }
    MineReplaceBindPhone01Activity.access$300(this.this$0).setText(String.valueOf(59L - paramLong.longValue() + "s"));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.MineReplaceBindPhone01Activity.3
 * JD-Core Version:    0.6.0
 */