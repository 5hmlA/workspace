package com.sportq.fit.fitmoudle4.setting.activity;

import android.widget.TextView;
import com.sportq.fit.fitmoudle4.setting.widget.SelectProvinceDialog.OnCitySelectorListener;

class Mine03PersonalActivity$6
  implements SelectProvinceDialog.OnCitySelectorListener
{
  public void onSelect(String paramString)
  {
    Mine03PersonalActivity.access$500(this.this$0).setText(paramString);
    Mine03PersonalActivity.access$000(this.this$0).region = paramString;
    Mine03PersonalActivity.access$200(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity.6
 * JD-Core Version:    0.6.0
 */