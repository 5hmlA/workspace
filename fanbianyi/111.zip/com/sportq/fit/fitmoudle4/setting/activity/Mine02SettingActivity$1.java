package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.activity.VipCenterActivity;

class Mine02SettingActivity$1
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    SharePreferenceUtils.putBuyVipFromPage("13");
    this.this$0.startActivity(new Intent(this.this$0, VipCenterActivity.class));
    AnimationUtil.pageJumpAnim(this.this$0, 0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine02SettingActivity.1
 * JD-Core Version:    0.6.0
 */