package com.sportq.fit.fitmoudle4.setting.activity;

import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.middlelib.MiddleManager;

class Mine03PersonalActivity$1
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -1)
    {
      this.this$0.dialog.createProgressDialog(this.this$0, this.this$0.getString(R.string.wait_hint));
      MiddleManager.getInstance().getMinePresenterImpl(this.this$0).updateUserInfo(Mine03PersonalActivity.access$000(this.this$0), this.this$0);
      return;
    }
    this.this$0.dialog.closeDialog();
    this.this$0.finish();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity.1
 * JD-Core Version:    0.6.0
 */