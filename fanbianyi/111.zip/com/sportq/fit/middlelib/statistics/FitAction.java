package com.sportq.fit.middlelib.statistics;

import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UploadUserBehaviorListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import java.util.Calendar;

public class FitAction
  implements View.OnClickListener
{
  private static final int ERR_INFO_LENGTH = 16000;
  private static final int MIN_TIME = 500;
  private static final String STR_EVENT_TYPE_HINT = "event";
  private long lastClickTime = 0L;
  private FitInterfaceUtils.UIInitListener listener;

  public FitAction(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.listener = paramUIInitListener;
  }

  private static String appendDynamicField(String paramString1, String paramString2)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(DateUtils.getCurDateTime());
    localStringBuilder.append(",");
    localStringBuilder.append(CompDeviceInfoUtils.getNetType());
    localStringBuilder.append(",");
    localStringBuilder.append(paramString2);
    localStringBuilder.append(",");
    localStringBuilder.append(BaseApplication.strAPIName);
    localStringBuilder.append(",");
    if (StringUtils.isNull(paramString1))
      return "";
    localStringBuilder.append(paramString1);
    localStringBuilder.append("");
    return localStringBuilder.toString();
  }

  public static void errDataHandler(String paramString, Throwable paramThrowable)
  {
  }

  private static String[] splitUserEvent(String paramString)
  {
    if (StringUtils.isNull(paramString))
      return null;
    return paramString.split(",");
  }

  public static void temporaryPCB(String paramString1, String paramString2)
  {
  }

  public static void temporaryPCB(String paramString1, String paramString2, boolean paramBoolean)
  {
  }

  public static void temporaryPCC(String paramString)
  {
  }

  public static void uploadErrInfo()
  {
  }

  public static void uploadUserBehavior()
  {
  }

  public static void uploadUserBehavior(FitInterfaceUtils.UploadUserBehaviorListener paramUploadUserBehaviorListener)
  {
  }

  private static void uploadUserBehaviorAction(FitInterfaceUtils.UploadUserBehaviorListener paramUploadUserBehaviorListener)
  {
  }

  public static void upload_e(String paramString, Throwable paramThrowable)
  {
  }

  private static void userBehaviorDataHandler(String paramString1, String paramString2, boolean paramBoolean)
  {
  }

  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    try
    {
      long l = Calendar.getInstance().getTimeInMillis();
      if (l - this.lastClickTime > 500L)
      {
        this.lastClickTime = l;
        if (this.listener != null)
          this.listener.fitOnClick(paramView);
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.statistics.FitAction
 * JD-Core Version:    0.6.0
 */