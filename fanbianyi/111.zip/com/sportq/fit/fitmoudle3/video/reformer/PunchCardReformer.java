package com.sportq.fit.fitmoudle3.video.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.PlanReformer;

public class PunchCardReformer extends BaseReformer
{
  public PlanModel planModel;
  public PlanReformer planReformer;
  public RequestModel requestModel;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.reformer.PunchCardReformer
 * JD-Core Version:    0.6.0
 */