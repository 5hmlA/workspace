package com.sportq.fit.fitmoudle3.video.widget;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

class AdjustVolumeView$11
  implements View.OnTouchListener
{
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    return true;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.AdjustVolumeView.11
 * JD-Core Version:    0.6.0
 */