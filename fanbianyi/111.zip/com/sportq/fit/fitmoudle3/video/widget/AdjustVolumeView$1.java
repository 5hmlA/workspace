package com.sportq.fit.fitmoudle3.video.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import com.sportq.fit.fitmoudle3.video.utils.SharePreferenceUtils3;

class AdjustVolumeView$1
  implements DialogInterface.OnDismissListener
{
  public void onDismiss(DialogInterface paramDialogInterface)
  {
    SharePreferenceUtils3.putTrainSettingUnReadTag(this.val$context, true);
    if (AdjustVolumeView.access$000(this.this$0) != null)
      AdjustVolumeView.access$000(this.this$0).onDismiss(paramDialogInterface);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.AdjustVolumeView.1
 * JD-Core Version:    0.6.0
 */