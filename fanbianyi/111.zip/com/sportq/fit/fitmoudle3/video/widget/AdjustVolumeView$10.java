package com.sportq.fit.fitmoudle3.video.widget;

import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle3.video.common.constant.Constant3;
import com.sportq.fit.fitmoudle3.video.presenter.BgMusicMediaPlayerHelper;

class AdjustVolumeView$10
  implements SeekBar.OnSeekBarChangeListener
{
  public void onProgressChanged(SeekBar paramSeekBar, int paramInt, boolean paramBoolean)
  {
    BgMusicMediaPlayerHelper.getInstance().setVolume(AdjustVolumeView.access$800(this.this$0).getProgress() / Constant3.MAX_VOLUME_VALUE);
  }

  public void onStartTrackingTouch(SeekBar paramSeekBar)
  {
  }

  @Instrumented
  public void onStopTrackingTouch(SeekBar paramSeekBar)
  {
    VdsAgent.onStopTrackingTouch(this, paramSeekBar);
    if (AdjustVolumeView.access$1600(this.this$0) != null)
      AdjustVolumeView.access$1600(this.this$0).onStopTrackingTouch(paramSeekBar);
    this.this$0.save();
    AdjustVolumeView.access$500(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.AdjustVolumeView.10
 * JD-Core Version:    0.6.0
 */