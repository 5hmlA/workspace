package com.sportq.fit.fitmoudle3.video.widget.videoplayer;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.view.TextureView;
import android.view.View.MeasureSpec;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;

public class CustomTextureView extends TextureView
{
  private Context mContext;

  public CustomTextureView(Context paramContext)
  {
    this(paramContext, null);
  }

  public CustomTextureView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public CustomTextureView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
  }

  @TargetApi(21)
  public CustomTextureView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.mContext = paramContext;
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    if (((BaseApplication.screenWidth == 0) || (BaseApplication.screenHeight == 0)) && ((this.mContext instanceof Activity)))
      CompDeviceInfoUtils.getDeviceWidthHeight(this.mContext);
    int i = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt2);
    if (this.mContext.getResources().getConfiguration().orientation == 2)
    {
      i = (int)(0.47F * BaseApplication.screenHeight);
      j = (int)(0.56F * i);
    }
    while (true)
    {
      setMeasuredDimension(i, j);
      return;
      if (getResources().getConfiguration().orientation != 1)
        continue;
      i = BaseApplication.screenWidth - CompDeviceInfoUtils.convertOfDip(this.mContext, 32.0F);
      j = (int)(0.56F * i);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.videoplayer.CustomTextureView
 * JD-Core Version:    0.6.0
 */