package com.sportq.fit.fitmoudle3.video.widget.videoplayer;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.ScrollView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.constant.EnumConstant.PageType;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RLinearLayout;
import com.sportq.fit.common.utils.superView.helper.RBaseHelper;
import com.sportq.fit.fitmoudle3.video.R.color;
import com.sportq.fit.fitmoudle3.video.R.id;
import com.sportq.fit.fitmoudle3.video.R.layout;
import com.sportq.fit.fitmoudle3.video.R.mipmap;
import com.sportq.fit.fitmoudle3.video.activity.Video01Activity;
import com.sportq.fit.fitmoudle3.video.datatransform.reformer.TrainingReformer;
import com.sportq.fit.fitmoudle3.video.presenter.Video01Presenter;
import com.sportq.fit.fitmoudle3.video.presenter.Video02Presenter;
import com.sportq.fit.middlelib.statistics.FitAction;

public class MediaController extends FrameLayout
  implements FitInterfaceUtils.UIInitListener
{
  public static final int ACTINDEX_FIRST = 1;
  public static final int ACTINDEX_LAST = 3;
  public static final int ACTINDEX_NEXT = 2;
  ImageView close_icon;
  private Context context;
  RelativeLayout controllerLayout;
  private PlayState currentPlayState = PlayState.PLAY;
  private String feedActionId = "";
  public RelativeLayout feed_back_base_layout;
  ImageView feed_back_icon;
  RelativeLayout feed_back_layout;
  private RLinearLayout feedback_layout;
  private RelativeLayout.LayoutParams feedback_params;
  private String[] keyMap = { "1", "2", "3", "7", "4", "5", "6" };
  ImageView lastBtn;
  RelativeLayout mediaCloseLayout;
  private MediaControllListener mediaControllListener;
  ImageView nextBtn;
  public ImageView pauseIcon;
  private ImageView right_arrow_icon;
  private String selectFeedCode = "";
  ImageView select_img;
  ImageView shrinkIcon;
  RelativeLayout shrinkLayout;
  private ImageView top_arrow_icon;
  RelativeLayout volumeLayout;
  ImageView volume_icon;

  public MediaController(Context paramContext)
  {
    this(paramContext, null);
  }

  public MediaController(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public MediaController(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.context = paramContext;
    initView();
  }

  private void bindView(View paramView)
  {
    this.mediaCloseLayout = ((RelativeLayout)paramView.findViewById(R.id.media_close_layout));
    this.controllerLayout = ((RelativeLayout)paramView.findViewById(R.id.controller_layout));
    this.lastBtn = ((ImageView)paramView.findViewById(R.id.last_btn));
    this.nextBtn = ((ImageView)paramView.findViewById(R.id.next_btn));
    this.volumeLayout = ((RelativeLayout)paramView.findViewById(R.id.volume_layout));
    this.shrinkLayout = ((RelativeLayout)paramView.findViewById(R.id.shrink_layout));
    this.shrinkIcon = ((ImageView)paramView.findViewById(R.id.shrink_icon));
    this.pauseIcon = ((ImageView)paramView.findViewById(R.id.pause_icon));
    this.feed_back_layout = ((RelativeLayout)paramView.findViewById(R.id.feed_back_layout));
    this.volume_icon = ((ImageView)paramView.findViewById(R.id.volume_icon));
    this.feed_back_icon = ((ImageView)paramView.findViewById(R.id.feed_back_icon));
    this.close_icon = ((ImageView)paramView.findViewById(R.id.close_icon));
  }

  private void initView()
  {
    bindView(View.inflate(this.context, R.layout.media_controller, this));
    this.mediaCloseLayout.setOnClickListener(new FitAction(this));
    this.pauseIcon.setOnClickListener(new FitAction(this));
    this.shrinkLayout.setOnClickListener(new FitAction(this));
    this.lastBtn.setOnClickListener(new FitAction(this));
    this.nextBtn.setOnClickListener(new FitAction(this));
    this.volumeLayout.setOnClickListener(new FitAction(this));
    this.feed_back_layout.setOnClickListener(new FitAction(this));
    this.controllerLayout.setVisibility(8);
  }

  private void loopAddFeedbackItem()
  {
    ScrollView localScrollView = new ScrollView(getContext());
    localScrollView.setVerticalScrollBarEnabled(false);
    localScrollView.setLayoutParams(new FrameLayout.LayoutParams(-1, -2));
    LinearLayout localLinearLayout = new LinearLayout(getContext());
    localLinearLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, -2));
    localLinearLayout.setOrientation(1);
    String[] arrayOfString = { "不具备场地条件/没有器械", "动作做不标准", "动作导致疼痛或受伤", "目标肌肉没有发力感", "不喜欢", "动作描述内容错误", "动作语音错误" };
    LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(getContext(), 55.5F));
    for (int i = 0; i < 7; i++)
    {
      String str = String.valueOf(i);
      View localView2 = LayoutInflater.from(this.context).inflate(R.layout.train_feedback_item, null);
      RelativeLayout localRelativeLayout = (RelativeLayout)localView2.findViewById(R.id.fb_choice_layout);
      ImageView localImageView = (ImageView)localView2.findViewById(R.id.choice_img);
      TextView localTextView2 = (TextView)localView2.findViewById(R.id.fb_hint);
      View localView3 = localView2.findViewById(R.id.split_line);
      localTextView2.setTextSize(15.0F);
      localTextView2.setText(arrayOfString[i]);
      localRelativeLayout.setVisibility(0);
      ((RelativeLayout.LayoutParams)localView3.getLayoutParams()).leftMargin = CompDeviceInfoUtils.convertOfDip(this.context, 20.0F);
      localView2.setOnClickListener(new View.OnClickListener(localImageView, str)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          new Handler().postDelayed(new Runnable()
          {
            public void run()
            {
              MediaController.this.hideFeedbackUI();
            }
          }
          , 500L);
          try
          {
            if ((MediaController.this.select_img != null) && (MediaController.this.select_img == this.val$choice_img))
            {
              MediaController.this.select_img.setVisibility(8);
              MediaController.this.select_img = null;
              MediaController.access$002(MediaController.this, "");
              MediaController.access$102(MediaController.this, "");
              return;
            }
            if (MediaController.this.select_img != null)
              MediaController.this.select_img.setVisibility(8);
            this.val$choice_img.setImageResource(R.mipmap.comm_btn_selected);
            this.val$choice_img.setVisibility(0);
            MediaController.this.select_img = this.val$choice_img;
            MediaController.access$002(MediaController.this, ((Video01Activity)MediaController.this.context).video01Presenter.getTrainingReformer().currentActionModel.actionId);
            MediaController.access$102(MediaController.this, this.val$strIndex);
            return;
          }
          catch (Exception localException)
          {
            LogUtils.e(localException);
          }
        }
      });
      localLinearLayout.addView(localView2, localLayoutParams1);
    }
    localScrollView.addView(localLinearLayout);
    View localView1 = LayoutInflater.from(this.context).inflate(R.layout.train_feedback_item, null);
    LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(getContext(), 65.5F));
    TextView localTextView1 = (TextView)localView1.findViewById(R.id.fb_hint);
    localTextView1.setTextSize(18.0F);
    localTextView1.setTextColor(ContextCompat.getColor(getContext(), R.color.color_313131));
    localTextView1.setTypeface(Typeface.defaultFromStyle(1));
    localTextView1.setText("对这个动作，我想反馈");
    ((RelativeLayout.LayoutParams)localTextView1.getLayoutParams()).leftMargin = CompDeviceInfoUtils.convertOfDip(this.context, 20.0F);
    this.feedback_layout.addView(localView1, localLayoutParams2);
    this.feedback_layout.addView(localScrollView);
  }

  public void actionIndexType(int paramInt)
  {
    switch (paramInt)
    {
    default:
      midAction();
      return;
    case 1:
      firstAction();
      return;
    case 2:
      midAction();
      return;
    case 3:
    }
    lastAction();
  }

  public void firstAction()
  {
    this.lastBtn.setVisibility(8);
    this.nextBtn.setVisibility(0);
  }

  public void fitOnClick(View paramView)
  {
    int i = paramView.getId();
    if (i == R.id.pause_icon)
      this.mediaControllListener.onPlayTurn();
    do
    {
      return;
      if (i == R.id.shrink_layout)
      {
        this.mediaControllListener.onPageTurn();
        return;
      }
      if (i == R.id.last_btn)
      {
        this.mediaControllListener.last();
        this.mediaControllListener.hide();
        return;
      }
      if (i == R.id.next_btn)
      {
        this.mediaControllListener.next();
        this.mediaControllListener.hide();
        return;
      }
      if (i == R.id.volume_layout)
      {
        this.mediaControllListener.volumeController();
        this.mediaControllListener.hide();
        return;
      }
      if (i == R.id.media_close_layout)
      {
        this.mediaControllListener.onMediaCloseLayoutClick();
        this.mediaControllListener.hide();
        return;
      }
      if (i != R.id.feed_back_layout)
        continue;
      this.feed_back_base_layout.setVisibility(0);
      setVisibility(0);
      int j = CompDeviceInfoUtils.convertOfDip(getContext(), 8.0F);
      if (((Video01Activity)this.context).mIsLand)
      {
        this.top_arrow_icon.setVisibility(8);
        this.right_arrow_icon.setVisibility(0);
        this.feedback_layout.getHelper().setCornerRadius(j, 0.0F, j, j);
        this.feedback_params.addRule(11);
        this.feedback_params.topMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 20.0F);
        this.feedback_params.rightMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 194.5F);
        return;
      }
      this.top_arrow_icon.setVisibility(0);
      this.right_arrow_icon.setVisibility(8);
      this.feedback_layout.getHelper().setCornerRadius(j);
      this.feedback_params.addRule(3, R.id.top_arrow_icon);
      this.feedback_params.topMargin = 0;
      this.feedback_params.rightMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 23.0F);
      return;
    }
    while (i != R.id.feed_back_base_layout);
    hideFeedbackUI();
  }

  public PlayState getCurrentPlayState()
  {
    return this.currentPlayState;
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
  }

  public void hideFeedbackUI()
  {
    this.feed_back_base_layout.setVisibility(8);
    if (this.mediaControllListener != null)
      this.mediaControllListener.hide();
  }

  public void initFeedbackView()
  {
    this.top_arrow_icon = ((ImageView)((Video01Activity)this.context).findViewById(R.id.top_arrow_icon));
    this.right_arrow_icon = ((ImageView)((Video01Activity)this.context).findViewById(R.id.right_arrow_icon));
    this.feedback_layout = ((RLinearLayout)((Video01Activity)this.context).findViewById(R.id.feedback_layout));
    this.feedback_params = ((RelativeLayout.LayoutParams)this.feedback_layout.getLayoutParams());
    this.feed_back_base_layout = ((RelativeLayout)((Video01Activity)this.context).findViewById(R.id.feed_back_base_layout));
    this.feed_back_base_layout.setOnClickListener(new FitAction(this));
    loopAddFeedbackItem();
    setTopRightOperateIconSize(1);
  }

  public void initLayout(Bundle paramBundle)
  {
  }

  public void lastAction()
  {
    this.lastBtn.setVisibility(0);
    this.nextBtn.setVisibility(8);
  }

  public void midAction()
  {
    this.lastBtn.setVisibility(0);
    this.nextBtn.setVisibility(0);
  }

  public <T> void onRefresh(T paramT)
  {
  }

  public void setFeedBackBtnState(boolean paramBoolean)
  {
    this.feed_back_layout.setEnabled(paramBoolean);
    RelativeLayout localRelativeLayout = this.feed_back_layout;
    float f;
    if (paramBoolean)
      f = 1.0F;
    while (true)
    {
      localRelativeLayout.setAlpha(f);
      return;
      f = 0.3F;
    }
  }

  public void setLastActBtnTag(String paramString)
  {
    this.lastBtn.setTag(paramString);
  }

  public void setMediaControllListener(MediaControllListener paramMediaControllListener)
  {
    this.mediaControllListener = paramMediaControllListener;
  }

  public void setNextActBtnTag(String paramString)
  {
    this.nextBtn.setTag(paramString);
  }

  public void setPageType(EnumConstant.PageType paramPageType)
  {
    if (EnumConstant.PageType.EXPAND.equals(paramPageType))
    {
      this.shrinkIcon.setImageResource(R.mipmap.video_play_btn_zoomout);
      this.shrinkLayout.setVisibility(0);
      this.controllerLayout.setVisibility(0);
      RelativeLayout.LayoutParams localLayoutParams2 = (RelativeLayout.LayoutParams)this.pauseIcon.getLayoutParams();
      localLayoutParams2.width = CompDeviceInfoUtils.convertOfDip(this.context, 90.0F);
      localLayoutParams2.height = CompDeviceInfoUtils.convertOfDip(this.context, 90.0F);
      this.pauseIcon.setLayoutParams(localLayoutParams2);
      this.pauseIcon.setPadding(CompDeviceInfoUtils.convertOfDip(this.context, 25.0F), CompDeviceInfoUtils.convertOfDip(this.context, 25.0F), CompDeviceInfoUtils.convertOfDip(this.context, 25.0F), CompDeviceInfoUtils.convertOfDip(this.context, 25.0F));
      this.mediaCloseLayout.setVisibility(0);
      return;
    }
    this.shrinkIcon.setImageResource(R.mipmap.video_play_btn_fullscreen);
    this.controllerLayout.setVisibility(8);
    RelativeLayout.LayoutParams localLayoutParams1 = (RelativeLayout.LayoutParams)this.pauseIcon.getLayoutParams();
    localLayoutParams1.width = CompDeviceInfoUtils.convertOfDip(this.context, 60.0F);
    localLayoutParams1.height = CompDeviceInfoUtils.convertOfDip(this.context, 60.0F);
    this.pauseIcon.setLayoutParams(localLayoutParams1);
    this.pauseIcon.setPadding(CompDeviceInfoUtils.convertOfDip(this.context, 15.0F), CompDeviceInfoUtils.convertOfDip(this.context, 15.0F), CompDeviceInfoUtils.convertOfDip(this.context, 15.0F), CompDeviceInfoUtils.convertOfDip(this.context, 15.0F));
    this.mediaCloseLayout.setVisibility(8);
  }

  public void setPauseBtnClickable(boolean paramBoolean)
  {
    this.pauseIcon.setClickable(paramBoolean);
  }

  public void setPlayState(PlayState paramPlayState)
  {
    Log.e("点击事件:", "setPlayState");
    int j;
    ImageView localImageView2;
    if (this.context.getResources().getConfiguration().orientation == 2)
    {
      ImageView localImageView3 = this.pauseIcon;
      if (paramPlayState.equals(PlayState.PLAY))
      {
        j = R.mipmap.video_play_btn_pauseb;
        localImageView3.setImageResource(j);
        localImageView2 = this.pauseIcon;
        if (!paramPlayState.equals(PlayState.PLAY))
          break label132;
      }
    }
    label132: for (Object localObject = null; ; localObject = "is.pause")
    {
      localImageView2.setTag(localObject);
      this.currentPlayState = paramPlayState;
      return;
      j = R.mipmap.video_play_btn_playb;
      break;
      ImageView localImageView1 = this.pauseIcon;
      if (paramPlayState.equals(PlayState.PLAY));
      for (int i = R.mipmap.video_play_btn_pauseb; ; i = R.mipmap.video_play_btn_playb)
      {
        localImageView1.setImageResource(i);
        break;
      }
    }
  }

  public void setTopRightOperateIconSize(int paramInt)
  {
    Context localContext = this.context;
    float f;
    if (paramInt == 0)
      f = 33.0F;
    while (true)
    {
      int i = CompDeviceInfoUtils.convertOfDip(localContext, f);
      this.shrinkIcon.getLayoutParams().width = i;
      this.shrinkIcon.getLayoutParams().height = i;
      this.volume_icon.getLayoutParams().width = i;
      this.volume_icon.getLayoutParams().height = i;
      this.feed_back_icon.getLayoutParams().width = i;
      this.feed_back_icon.getLayoutParams().height = i;
      this.close_icon.getLayoutParams().width = i;
      this.close_icon.getLayoutParams().height = i;
      return;
      f = 40.0F;
    }
  }

  public void uploadFeedBackInfo()
  {
    if ((!StringUtils.isNull(this.feedActionId)) || (!StringUtils.isNull(this.selectFeedCode)));
    try
    {
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.planId = ((Video01Activity)this.context).planReformer._individualInfo.planId;
      localRequestModel.actId = this.feedActionId;
      localRequestModel.feedCode = this.keyMap[StringUtils.string2Int(this.selectFeedCode)];
      new Video02Presenter((Video01Activity)this.context).feedBackAct(this.context, localRequestModel);
      this.feedActionId = "";
      this.selectFeedCode = "";
      this.feedback_layout.getChildAt(0).scrollTo(0, 0);
      if (this.select_img != null)
      {
        this.select_img.setVisibility(8);
        this.select_img = null;
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public static abstract interface MediaControllListener
  {
    public abstract void hide();

    public abstract void last();

    public abstract void next();

    public abstract void onMediaCloseLayoutClick();

    public abstract void onPageTurn();

    public abstract void onPlayTurn();

    public abstract void volumeController();
  }

  public static enum PlayState
  {
    static
    {
      PAUSE = new PlayState("PAUSE", 1);
      PlayState[] arrayOfPlayState = new PlayState[2];
      arrayOfPlayState[0] = PLAY;
      arrayOfPlayState[1] = PAUSE;
      $VALUES = arrayOfPlayState;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.videoplayer.MediaController
 * JD-Core Version:    0.6.0
 */