package com.sportq.fit.fitmoudle3.video.widget.videoplayer;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.support.percent.PercentRelativeLayout;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle3.video.activity.Find07TrainPreviewActivity;

public class VHRotationRelativeLayout extends PercentRelativeLayout
{
  private Context context;

  public VHRotationRelativeLayout(Context paramContext)
  {
    this(paramContext, null);
  }

  public VHRotationRelativeLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public VHRotationRelativeLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.context = paramContext;
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt2);
    if ((this.context instanceof Activity))
      CompDeviceInfoUtils.getDeviceWidthHeight(this.context);
    float f = 1.0F;
    if ((this.context instanceof Find07TrainPreviewActivity))
      f = 0.91F;
    if (getResources().getConfiguration().orientation == 1)
    {
      i = (int)(f * Math.min(BaseApplication.screenHeight, BaseApplication.screenWidth));
      j = (int)(0.56F * i);
      paramInt2 = View.MeasureSpec.makeMeasureSpec(j, View.MeasureSpec.getMode(paramInt2));
    }
    super.onMeasure(paramInt1, paramInt2);
    setMeasuredDimension(i, j);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.videoplayer.VHRotationRelativeLayout
 * JD-Core Version:    0.6.0
 */