package com.sportq.fit.fitmoudle3.video.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.RectF;
import android.support.annotation.ColorInt;
import android.support.v4.content.ContextCompat;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.widget.TextView;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle3.video.R.color;
import com.sportq.fit.fitmoudle3.video.R.styleable;

public class CircleTextProgressbar extends TextView
{
  private static final String TAG = CircleTextProgressbar.class.getName();
  final Rect bounds = new Rect();
  private int circleColor;
  private ColorStateList inCircleColors = ColorStateList.valueOf(0);
  private int listenerWhat = 0;
  private RectF mArcRect = new RectF();
  private OnCountdownProgressListener mCountdownProgressListener;
  private Paint mPaint = new Paint();
  private ProgressType mProgressType = ProgressType.COUNT_BACK;
  private int min_size;
  private int outLineColor = -1;
  private int outLineWidth = 2;
  private int progress = 100;
  private Runnable progressChangeTask = new Runnable()
  {
    public void run()
    {
      CircleTextProgressbar.this.removeCallbacks(this);
      switch (CircleTextProgressbar.2.$SwitchMap$com$sportq$fit$fitmoudle3$video$widget$CircleTextProgressbar$ProgressType[CircleTextProgressbar.this.mProgressType.ordinal()])
      {
      default:
      case 1:
      case 2:
      }
      while (true)
      {
        LogUtils.d(CircleTextProgressbar.TAG, "progress:" + CircleTextProgressbar.this.progress);
        if ((CircleTextProgressbar.this.progress < 0) || (CircleTextProgressbar.this.progress > 100))
          break;
        if (CircleTextProgressbar.this.mCountdownProgressListener != null)
          CircleTextProgressbar.this.mCountdownProgressListener.onProgress(CircleTextProgressbar.this.listenerWhat, CircleTextProgressbar.this.progress);
        CircleTextProgressbar.this.invalidate();
        CircleTextProgressbar.this.postDelayed(CircleTextProgressbar.this.progressChangeTask, CircleTextProgressbar.this.timeMillis / 100L);
        return;
        CircleTextProgressbar.access$102(CircleTextProgressbar.this, 1 + CircleTextProgressbar.this.progress);
        continue;
        CircleTextProgressbar.access$102(CircleTextProgressbar.this, -1 + CircleTextProgressbar.this.progress);
      }
      CircleTextProgressbar.access$102(CircleTextProgressbar.this, CircleTextProgressbar.this.validateProgress(CircleTextProgressbar.this.progress));
    }
  };
  private int progressLineColor = -1;
  private int progressLineWidth = 8;
  private long timeMillis = 3000L;

  public CircleTextProgressbar(Context paramContext)
  {
    this(paramContext, null);
  }

  public CircleTextProgressbar(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public CircleTextProgressbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    initialize(paramContext, paramAttributeSet);
  }

  @TargetApi(21)
  public CircleTextProgressbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    initialize(paramContext, paramAttributeSet);
  }

  private float dp2px(Resources paramResources, float paramFloat)
  {
    return 0.5F + paramFloat * paramResources.getDisplayMetrics().density;
  }

  private void initialize(Context paramContext, AttributeSet paramAttributeSet)
  {
    this.mPaint.setAntiAlias(true);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.CircleTextProgressbar);
    if (localTypedArray.hasValue(R.styleable.CircleTextProgressbar_in_circle_color));
    for (this.inCircleColors = localTypedArray.getColorStateList(R.styleable.CircleTextProgressbar_in_circle_color); ; this.inCircleColors = ColorStateList.valueOf(0))
    {
      if (localTypedArray.hasValue(R.styleable.CircleTextProgressbar_outLineColor))
        this.outLineColor = localTypedArray.getColor(R.styleable.CircleTextProgressbar_outLineColor, -16777216);
      if (localTypedArray.hasValue(R.styleable.CircleTextProgressbar_outLineWidth))
        this.outLineWidth = localTypedArray.getInteger(R.styleable.CircleTextProgressbar_outLineWidth, 2);
      if (localTypedArray.hasValue(R.styleable.CircleTextProgressbar_progressLineWidth))
        this.progressLineWidth = localTypedArray.getInteger(R.styleable.CircleTextProgressbar_progressLineWidth, 8);
      if (localTypedArray.hasValue(R.styleable.CircleTextProgressbar_progressLineColor))
        this.progressLineColor = localTypedArray.getInteger(R.styleable.CircleTextProgressbar_progressLineColor, -16777216);
      this.circleColor = this.inCircleColors.getColorForState(getDrawableState(), 0);
      this.min_size = (int)dp2px(getResources(), 100.0F);
      localTypedArray.recycle();
      return;
    }
  }

  private void resetProgress()
  {
    switch (2.$SwitchMap$com$sportq$fit$fitmoudle3$video$widget$CircleTextProgressbar$ProgressType[this.mProgressType.ordinal()])
    {
    default:
      return;
    case 1:
      this.progress = 0;
      return;
    case 2:
    }
    this.progress = 100;
  }

  private void validateCircleColor()
  {
    int i = this.inCircleColors.getColorForState(getDrawableState(), 0);
    if (this.circleColor != i)
    {
      this.circleColor = i;
      invalidate();
    }
  }

  private int validateProgress(int paramInt)
  {
    if (paramInt > 100)
      paramInt = 100;
    do
      return paramInt;
    while (paramInt >= 0);
    return 0;
  }

  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    validateCircleColor();
  }

  public int getProgress()
  {
    return this.progress;
  }

  public ProgressType getProgressType()
  {
    return this.mProgressType;
  }

  public long getTimeMillis()
  {
    return this.timeMillis;
  }

  protected void onDraw(Canvas paramCanvas)
  {
    getDrawingRect(this.bounds);
    float f1 = Math.min(-6 + this.bounds.height(), -6 + this.bounds.width()) / 2.0F;
    this.mPaint.setStyle(Paint.Style.FILL);
    this.mPaint.setColor(ContextCompat.getColor(getContext(), R.color.color_e4e4e5));
    paramCanvas.drawCircle(this.bounds.centerX(), this.bounds.centerY(), f1 - this.outLineWidth, this.mPaint);
    this.mPaint.setStyle(Paint.Style.STROKE);
    this.mPaint.setStrokeWidth(this.outLineWidth);
    this.mPaint.setColor(this.outLineColor);
    paramCanvas.drawCircle(this.bounds.centerX(), this.bounds.centerY(), f1 - (this.outLineWidth + this.progressLineWidth) / 2, this.mPaint);
    TextPaint localTextPaint = getPaint();
    localTextPaint.setColor(ContextCompat.getColor(getContext(), R.color.color_313131));
    localTextPaint.setAntiAlias(true);
    localTextPaint.setTextAlign(Paint.Align.CENTER);
    float f2 = this.bounds.centerY() - (localTextPaint.descent() + localTextPaint.ascent()) / 2.0F;
    paramCanvas.drawText(getText().toString(), this.bounds.centerX(), f2, localTextPaint);
    this.mPaint.setColor(this.progressLineColor);
    this.mPaint.setStyle(Paint.Style.STROKE);
    this.mPaint.setStrokeWidth(this.progressLineWidth);
    this.mPaint.setStrokeCap(Paint.Cap.ROUND);
    int i = this.progressLineWidth + this.outLineWidth;
    this.mArcRect.set(this.bounds.left + i / 2, this.bounds.top + i / 2, this.bounds.right - i / 2, this.bounds.bottom - i / 2);
    paramCanvas.drawArc(this.mArcRect, 270.0F, 360 * this.progress / 100, false, this.mPaint);
  }

  public void reStart()
  {
    resetProgress();
    start();
  }

  public void setCountdownProgressListener(int paramInt, OnCountdownProgressListener paramOnCountdownProgressListener)
  {
    this.listenerWhat = paramInt;
    this.mCountdownProgressListener = paramOnCountdownProgressListener;
  }

  public void setInCircleColor(@ColorInt int paramInt)
  {
    this.inCircleColors = ColorStateList.valueOf(paramInt);
    invalidate();
  }

  public void setOutLineColor(@ColorInt int paramInt)
  {
    this.outLineColor = paramInt;
    invalidate();
  }

  public void setOutLineWidth(@ColorInt int paramInt)
  {
    this.outLineWidth = paramInt;
    invalidate();
  }

  public void setProgress(int paramInt)
  {
    this.progress = validateProgress(paramInt);
    invalidate();
  }

  public void setProgressColor(@ColorInt int paramInt)
  {
    this.progressLineColor = paramInt;
    invalidate();
  }

  public void setProgressLineWidth(int paramInt)
  {
    this.progressLineWidth = paramInt;
    invalidate();
  }

  public void setProgressType(ProgressType paramProgressType)
  {
    this.mProgressType = paramProgressType;
    resetProgress();
    invalidate();
  }

  public void setTimeMillis(long paramLong)
  {
    this.timeMillis = paramLong;
    invalidate();
  }

  public void start()
  {
    stop();
    post(this.progressChangeTask);
  }

  public void stop()
  {
    removeCallbacks(this.progressChangeTask);
  }

  public static abstract interface OnCountdownProgressListener
  {
    public abstract void onProgress(int paramInt1, int paramInt2);
  }

  public static enum ProgressType
  {
    static
    {
      ProgressType[] arrayOfProgressType = new ProgressType[2];
      arrayOfProgressType[0] = COUNT;
      arrayOfProgressType[1] = COUNT_BACK;
      $VALUES = arrayOfProgressType;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.CircleTextProgressbar
 * JD-Core Version:    0.6.0
 */