package com.sportq.fit.fitmoudle3.video.widget;

import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;

class AdjustVolumeView$8
  implements SeekBar.OnSeekBarChangeListener
{
  public void onProgressChanged(SeekBar paramSeekBar, int paramInt, boolean paramBoolean)
  {
    if (AdjustVolumeView.access$1400(this.this$0) != null)
      AdjustVolumeView.access$1400(this.this$0).onProgressChanged(paramSeekBar, paramInt, paramBoolean);
  }

  public void onStartTrackingTouch(SeekBar paramSeekBar)
  {
  }

  @Instrumented
  public void onStopTrackingTouch(SeekBar paramSeekBar)
  {
    VdsAgent.onStopTrackingTouch(this, paramSeekBar);
    if (AdjustVolumeView.access$1400(this.this$0) != null)
      AdjustVolumeView.access$1400(this.this$0).onStopTrackingTouch(paramSeekBar);
    this.this$0.save();
    AdjustVolumeView.access$500(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.AdjustVolumeView.8
 * JD-Core Version:    0.6.0
 */