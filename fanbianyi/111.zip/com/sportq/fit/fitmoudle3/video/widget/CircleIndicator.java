package com.sportq.fit.fitmoudle3.video.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.support.annotation.RequiresApi;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.view.View;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle3.video.R.color;

public class CircleIndicator extends View
{
  private int count = 2;
  private Paint mPaint = new Paint();
  private ViewPager.OnPageChangeListener onPageChangeListener = new ViewPager.OnPageChangeListener()
  {
    public void onPageScrollStateChanged(int paramInt)
    {
    }

    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
    {
    }

    public void onPageSelected(int paramInt)
    {
      if (CircleIndicator.this.viewPager != null)
      {
        CircleIndicator.access$102(CircleIndicator.this, CircleIndicator.this.viewPager.getCurrentItem());
        CircleIndicator.this.requestLayout();
      }
    }
  };
  private float radius = 3.5F;
  private int selectIndex = 0;
  private float space = 10.0F;
  private ViewPager viewPager;

  public CircleIndicator(Context paramContext)
  {
    this(paramContext, null);
  }

  public CircleIndicator(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public CircleIndicator(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  @RequiresApi(api=21)
  public CircleIndicator(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    this.mPaint.setStyle(Paint.Style.FILL);
    this.mPaint.setAntiAlias(true);
    float f1 = CompDeviceInfoUtils.convertOfDip(getContext(), this.radius);
    int i = CompDeviceInfoUtils.convertOfDip(getContext(), this.space);
    float f2 = 2.0F * (f1 * this.count) + i * (-1 + this.count);
    float f3 = (getMeasuredWidth() - f2) / 2.0F;
    int j = 0;
    if (j < this.count)
    {
      if (this.selectIndex == j)
        this.mPaint.setColor(ResourcesCompat.getColor(getResources(), R.color.color_313131, null));
      while (true)
      {
        paramCanvas.drawCircle(f3 + f1, getMeasuredHeight() / 2.0F, f1, this.mPaint);
        f3 += f1 + i;
        j++;
        break;
        this.mPaint.setColor(ResourcesCompat.getColor(getResources(), R.color.color_e7e7e7, null));
      }
    }
    super.onDraw(paramCanvas);
  }

  public void setViewPager(ViewPager paramViewPager)
  {
    this.viewPager = paramViewPager;
    if (this.viewPager != null)
    {
      this.count = this.viewPager.getAdapter().getCount();
      this.selectIndex = this.viewPager.getCurrentItem();
      this.viewPager.addOnPageChangeListener(this.onPageChangeListener);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.CircleIndicator
 * JD-Core Version:    0.6.0
 */