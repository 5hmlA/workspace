package com.sportq.fit.fitmoudle3.video.widget;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.SeekBar;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.kyleduo.switchbutton.SwitchButton;
import com.sportq.fit.fitmoudle3.video.common.constant.Constant3;
import com.sportq.fit.fitmoudle3.video.presenter.BgMusicMediaPlayerHelper;

class AdjustVolumeView$7
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    AdjustVolumeView.access$600(this.this$0).setProgress((int)(Constant3.MAX_VOLUME_VALUE * Constant3.DEFAULT_VOLUME_VALUE));
    AdjustVolumeView.access$700(this.this$0).setProgress((int)(Constant3.MAX_VOLUME_VALUE * Constant3.DEFAULT_VOLUME_VALUE));
    AdjustVolumeView.access$800(this.this$0).setProgress((int)(Constant3.MAX_VOLUME_VALUE * Constant3.DEFAULT_VOLUME_VALUE));
    AdjustVolumeView.access$900(this.this$0).setChecked(true);
    AdjustVolumeView.access$1000(this.this$0).setChecked(true);
    AdjustVolumeView.access$300(this.this$0, true);
    AdjustVolumeView.access$1100(this.this$0);
    AdjustVolumeView.access$1200(this.this$0);
    if (AdjustVolumeView.access$1300(this.this$0) != null)
      AdjustVolumeView.access$1300(this.this$0).onClick(paramView);
    BgMusicMediaPlayerHelper.getInstance().setVolume(Constant3.DEFAULT_VOLUME_VALUE);
    this.this$0.save();
    AdjustVolumeView.access$500(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.AdjustVolumeView.7
 * JD-Core Version:    0.6.0
 */