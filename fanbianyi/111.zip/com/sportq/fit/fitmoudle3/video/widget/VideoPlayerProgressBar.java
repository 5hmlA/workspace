package com.sportq.fit.fitmoudle3.video.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import com.sportq.fit.fitmoudle3.video.R.color;
import java.util.ArrayList;
import java.util.Iterator;

public class VideoPlayerProgressBar extends ProgressBar
{
  private Paint mPaint = new Paint();
  private ArrayList<Float> proRatio;
  private ArrayList<RectF> rectFs = new ArrayList();

  public VideoPlayerProgressBar(Context paramContext)
  {
    this(paramContext, null);
  }

  public VideoPlayerProgressBar(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public VideoPlayerProgressBar(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  @RequiresApi(api=21)
  public VideoPlayerProgressBar(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }

  protected void onDraw(Canvas paramCanvas)
  {
    monitorenter;
    try
    {
      this.mPaint.setStyle(Paint.Style.FILL);
      this.mPaint.setColor(getResources().getColor(R.color.color_313131));
      Iterator localIterator = this.rectFs.iterator();
      while (localIterator.hasNext())
        paramCanvas.drawRect((RectF)localIterator.next(), this.mPaint);
    }
    finally
    {
      monitorexit;
    }
    super.onDraw(paramCanvas);
    monitorexit;
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (this.rectFs != null)
      this.rectFs.clear();
    if (this.proRatio != null)
    {
      float f1 = 0.0F;
      float f2 = paramInt3;
      for (int i = 0; i < this.proRatio.size(); i++)
      {
        float f3 = 2.0F;
        if (i == 0.0F)
          f3 = 0.0F;
        float f4 = f1 + f3;
        f1 += f2 * ((Float)this.proRatio.get(i)).floatValue();
        RectF localRectF = new RectF(f4, 0.0F, f1, paramInt4 - paramInt2);
        this.rectFs.add(localRectF);
      }
    }
  }

  public void setRectFs(ArrayList<Float> paramArrayList)
  {
    this.proRatio = paramArrayList;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.VideoPlayerProgressBar
 * JD-Core Version:    0.6.0
 */