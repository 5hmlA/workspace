package com.sportq.fit.fitmoudle3.video.widget.videoplayer;

import rx.Subscriber;

public abstract class SubScriberOnCompleted<T> extends Subscriber<T>
{
  public abstract void onCompleted();

  public void onError(Throwable paramThrowable)
  {
  }

  public void onNext(T paramT)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.widget.videoplayer.SubScriberOnCompleted
 * JD-Core Version:    0.6.0
 */