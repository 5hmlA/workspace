package com.sportq.fit.fitmoudle3.video.interfaces;

import com.sportq.fit.common.constant.EnumConstant.PageType;
import com.sportq.fit.fitmoudle3.video.datatransform.reformer.TrainingReformer;
import rx.Observable;

public abstract interface VideoInterface
{
  public abstract void init();

  public abstract void onPageTurn(EnumConstant.PageType paramPageType, TrainingReformer paramTrainingReformer);

  public abstract void onPause();

  public abstract void pause();

  public abstract void play();

  public abstract Observable resume();

  public abstract void stop();
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.interfaces.VideoInterface
 * JD-Core Version:    0.6.0
 */