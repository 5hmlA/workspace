package com.sportq.fit.fitmoudle3.video.interfaces;

import com.sportq.fit.common.constant.EnumConstant.PageType;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.fitmoudle3.video.datatransform.reformer.TrainingReformer;

public abstract interface Video01View extends FitInterfaceUtils.UIInitListener
{
  public abstract void doStage(TrainingReformer paramTrainingReformer);

  public abstract void initVideoManager(TrainingReformer paramTrainingReformer);

  public abstract void setPageType(EnumConstant.PageType paramPageType, TrainingReformer paramTrainingReformer);

  public abstract void showCloseDialog();

  public abstract void showVolumeDialog();

  public abstract void trainToPosition(TrainingReformer paramTrainingReformer);

  public abstract void turnPositionChangeUI(int paramInt);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.interfaces.Video01View
 * JD-Core Version:    0.6.0
 */