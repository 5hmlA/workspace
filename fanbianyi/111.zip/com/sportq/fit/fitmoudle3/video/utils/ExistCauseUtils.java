package com.sportq.fit.fitmoudle3.video.utils;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.superView.RLinearLayout;
import com.sportq.fit.common.utils.superView.RRelativeLayout;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.widget.CustomFlipAnimation;
import com.sportq.fit.fitmoudle.widget.CustomFlipAnimation.AnimationListener;
import com.sportq.fit.fitmoudle3.video.R.id;
import com.sportq.fit.fitmoudle3.video.R.layout;
import com.sportq.fit.fitmoudle3.video.activity.Video01Activity;
import com.sportq.fit.fitmoudle3.video.presenter.Video02Presenter;

public class ExistCauseUtils
{
  public void showFinishTrainDialog(Context paramContext, OnExistCauseClickListener paramOnExistCauseClickListener)
  {
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(false);
    localDialog.setCancelable(false);
    localDialog.setCanceledOnTouchOutside(false);
    localDialog.setContentView(R.layout.finish_train_layout);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.7222D * Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight));
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
    RRelativeLayout localRRelativeLayout = (RRelativeLayout)localDialog.findViewById(R.id.finish_layout);
    RLinearLayout localRLinearLayout = (RLinearLayout)localDialog.findViewById(R.id.exist_cause_layout);
    ((RTextView)localDialog.findViewById(R.id.to_finish)).setOnClickListener(new View.OnClickListener(paramContext, localRRelativeLayout, localRLinearLayout)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        new CustomFlipAnimation(this.val$mContext, this.val$finish_layout, this.val$exist_cause_layout, new CustomFlipAnimation.AnimationListener()
        {
          public void finish()
          {
            ExistCauseUtils.1.this.val$finish_layout.setVisibility(8);
            ExistCauseUtils.1.this.val$exist_cause_layout.setVisibility(0);
          }
        }).flipAnimationStart();
      }
    });
    ((RTextView)localDialog.findViewById(R.id.to_continue)).setOnClickListener(new View.OnClickListener(localDialog, paramOnExistCauseClickListener)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        this.val$dialog.dismiss();
        if (this.val$listener != null)
          this.val$listener.onContinue();
      }
    });
    String[] arrayOfString = { "动作做不标准", "课程强度太大", "场地限制/没有器械", "随便看看，没打算练完", "其他原因" };
    LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(paramContext, 44.0F));
    int i = 0;
    if (i < arrayOfString.length)
    {
      View localView1 = LayoutInflater.from(paramContext).inflate(R.layout.train_exist_cause_item, null);
      ((TextView)localView1.findViewById(R.id.exist_cause_hint)).setText(arrayOfString[i]);
      View localView2 = localView1.findViewById(R.id.exist_split_line);
      if (i == -1 + arrayOfString.length);
      for (int j = 8; ; j = 0)
      {
        localView2.setVisibility(j);
        localRLinearLayout.addView(localView1, localLayoutParams1);
        localView1.setOnClickListener(new View.OnClickListener(localDialog, paramOnExistCauseClickListener, arrayOfString, i, paramContext)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            this.val$dialog.dismiss();
            if (this.val$listener != null)
              this.val$listener.onExistCauseClick(this.val$strHintList[this.val$index]);
            RequestModel localRequestModel = new RequestModel();
            localRequestModel.planId = ((Video01Activity)this.val$mContext).planReformer._individualInfo.planId;
            localRequestModel.feedCode = String.valueOf(this.val$index);
            new Video02Presenter((Video01Activity)this.val$mContext).trainExistCause(this.val$mContext, localRequestModel);
          }
        });
        i++;
        break;
      }
    }
  }

  public static abstract interface OnExistCauseClickListener
  {
    public abstract void onContinue();

    public abstract void onExistCauseClick(String paramString);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.utils.ExistCauseUtils
 * JD-Core Version:    0.6.0
 */