package com.sportq.fit.fitmoudle3.video.utils;

import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import java.io.File;
import java.util.ArrayList;

public class FileUtils3
{
  public static ArrayList<File> getBgMusicList(String paramString)
  {
    File localFile1 = new File(VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME);
    ArrayList localArrayList = new ArrayList();
    File[] arrayOfFile;
    if (localFile1.isDirectory())
    {
      arrayOfFile = localFile1.listFiles();
      if (arrayOfFile != null)
        break label37;
    }
    label37: 
    do
      return localArrayList;
    while (arrayOfFile.length == 0);
    int i = arrayOfFile.length;
    int j = 0;
    label49: File localFile2;
    if (j < i)
    {
      localFile2 = arrayOfFile[j];
      if (("1".equals(BaseApplication.userModel.isVip)) || (!isVipMusic(localFile2.getName())))
        break label93;
    }
    while (true)
    {
      j++;
      break label49;
      break;
      label93: if (paramString.equals(FileUtils.convertBgMusicName(localFile2.getName())))
        continue;
      localArrayList.add(localFile2);
    }
  }

  public static boolean isVipMusic(String paramString)
  {
    try
    {
      String[] arrayOfString = paramString.split("&");
      int i = arrayOfString.length;
      int j = 0;
      if (i == 6)
      {
        boolean bool = "1".equals(arrayOfString[5]);
        j = 0;
        if (bool)
          j = 1;
      }
      return j;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.utils.FileUtils3
 * JD-Core Version:    0.6.0
 */