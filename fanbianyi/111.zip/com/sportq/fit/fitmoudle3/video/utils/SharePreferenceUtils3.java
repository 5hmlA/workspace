package com.sportq.fit.fitmoudle3.video.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.google.gson.Gson;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle3.video.datatransform.reformer.TrainingReformer;

public class SharePreferenceUtils3
{
  private static final String KEY_MUSCLE_IS_OPEN = "key.muscle.is.open";
  private static final String KEY_NEW_TRAIN_SETTING_UNREAD = "key.new.train.setting.unread";
  private static final String KEY_PLAN_DATA_BE_KILLED = "key.plan.data.be.killed";
  private static final String KEY_PUNCHCARD_FIRST_HINT = "key.punchCard.first.hint";
  private static final String KEY_TRAIN_DATA_BE_KILLED = "key.train.data.be.killed";
  private static final String KEY_TRAIN_DATA_SYN_HINT = "key.train.data.syn.hint";
  private static final String TABLE_VIDEO = "table.video";

  public static boolean getMuscleIsOpen(Context paramContext)
  {
    if (paramContext == null)
      return false;
    return paramContext.getSharedPreferences("table.video", 0).getBoolean(BaseApplication.userModel.userId + "key.muscle.is.open", true);
  }

  public static PlanReformer getPlanDataBeKilled(Context paramContext)
  {
    if (paramContext == null)
      return null;
    String str = paramContext.getSharedPreferences("table.video", 0).getString("key.plan.data.be.killed", "");
    if (StringUtils.isNull(str))
      return null;
    try
    {
      PlanReformer localPlanReformer = (PlanReformer)FitGsonFactory.create().fromJson(str, PlanReformer.class);
      return localPlanReformer;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return null;
  }

  public static boolean getPunchCardFirstHint(Context paramContext)
  {
    if (paramContext == null)
      return false;
    return paramContext.getSharedPreferences("table.video", 0).getBoolean("key.punchCard.first.hint", false);
  }

  public static TrainingReformer getTrainDataBeKilled(Context paramContext)
  {
    if (paramContext == null)
      return null;
    String str = paramContext.getSharedPreferences("table.video", 0).getString("key.train.data.be.killed", "");
    if (StringUtils.isNull(str))
      return null;
    try
    {
      TrainingReformer localTrainingReformer = (TrainingReformer)FitGsonFactory.create().fromJson(str, TrainingReformer.class);
      return localTrainingReformer;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return null;
  }

  public static String getTrainDataSynHint(Context paramContext)
  {
    if (paramContext == null)
      return null;
    return paramContext.getSharedPreferences("table.video", 0).getString("key.train.data.syn.hint", "");
  }

  public static boolean getTrainSettingUnReadTag(Context paramContext)
  {
    if (paramContext == null)
      return false;
    return paramContext.getSharedPreferences("table.video", 0).getBoolean("key.new.train.setting.unread", false);
  }

  public static void putMuscleIsOpen(Context paramContext, boolean paramBoolean)
  {
    if (paramContext != null)
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("table.video", 0).edit();
      localEditor.putBoolean(BaseApplication.userModel.userId + "key.muscle.is.open", paramBoolean);
      localEditor.apply();
    }
  }

  public static void putPlanDataBeKilled(Context paramContext, PlanReformer paramPlanReformer)
  {
    if ((paramContext != null) && (paramPlanReformer != null))
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("table.video", 0).edit();
      localEditor.putString("key.plan.data.be.killed", FitGsonFactory.create().toJson(paramPlanReformer));
      localEditor.apply();
    }
  }

  public static void putPunchCardFirstHint(Context paramContext)
  {
    if (paramContext != null)
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("table.video", 0).edit();
      localEditor.putBoolean("key.punchCard.first.hint", true);
      localEditor.apply();
    }
  }

  public static void putTrainDataBeKilled(Context paramContext, TrainingReformer paramTrainingReformer)
  {
    if ((paramContext != null) && (paramTrainingReformer != null))
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("table.video", 0).edit();
      localEditor.putString("key.train.data.be.killed", FitGsonFactory.create().toJson(paramTrainingReformer));
      localEditor.apply();
    }
  }

  public static void putTrainDataSynHint(Context paramContext, String paramString)
  {
    if ((paramContext != null) && (!StringUtils.isNull(paramString)))
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("table.video", 0).edit();
      localEditor.putString("key.train.data.syn.hint", paramString);
      localEditor.apply();
    }
  }

  public static void putTrainSettingUnReadTag(Context paramContext, boolean paramBoolean)
  {
    if (paramContext != null)
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("table.video", 0).edit();
      localEditor.putBoolean("key.new.train.setting.unread", paramBoolean);
      localEditor.apply();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.utils.SharePreferenceUtils3
 * JD-Core Version:    0.6.0
 */