package com.sportq.fit.fitmoudle3.video.adapter;

import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public class Video02FinishPagerAdapter extends PagerAdapter
{
  private ArrayList<View> viewList;

  public Video02FinishPagerAdapter(ArrayList<View> paramArrayList)
  {
    this.viewList = paramArrayList;
  }

  public void destroyItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    paramViewGroup.removeView((View)this.viewList.get(paramInt));
  }

  public int getCount()
  {
    if (this.viewList == null)
      return 0;
    return this.viewList.size();
  }

  public int getItemPosition(Object paramObject)
  {
    return super.getItemPosition(paramObject);
  }

  public CharSequence getPageTitle(int paramInt)
  {
    return "";
  }

  public Object instantiateItem(ViewGroup paramViewGroup, int paramInt)
  {
    paramViewGroup.addView((View)this.viewList.get(paramInt));
    return this.viewList.get(paramInt);
  }

  public boolean isViewFromObject(View paramView, Object paramObject)
  {
    return paramView == paramObject;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.adapter.Video02FinishPagerAdapter
 * JD-Core Version:    0.6.0
 */