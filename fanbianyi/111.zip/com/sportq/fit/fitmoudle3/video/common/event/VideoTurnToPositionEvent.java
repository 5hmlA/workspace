package com.sportq.fit.fitmoudle3.video.common.event;

public class VideoTurnToPositionEvent
{
  public int actIndex;

  public VideoTurnToPositionEvent(int paramInt)
  {
    this.actIndex = paramInt;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.common.event.VideoTurnToPositionEvent
 * JD-Core Version:    0.6.0
 */