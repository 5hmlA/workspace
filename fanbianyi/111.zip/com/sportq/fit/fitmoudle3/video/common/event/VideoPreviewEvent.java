package com.sportq.fit.fitmoudle3.video.common.event;

import com.sportq.fit.common.model.ActionModel;

public class VideoPreviewEvent
{
  public ActionModel mActionModel;

  public VideoPreviewEvent(ActionModel paramActionModel)
  {
    this.mActionModel = paramActionModel;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.common.event.VideoPreviewEvent
 * JD-Core Version:    0.6.0
 */