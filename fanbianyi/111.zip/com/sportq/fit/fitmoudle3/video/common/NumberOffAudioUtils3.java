package com.sportq.fit.fitmoudle3.video.common;

import com.sportq.fit.common.model.StageModel;
import com.sportq.fit.common.utils.NumberOffAudioUtils;
import com.sportq.fit.common.utils.StringUtils;

public class NumberOffAudioUtils3 extends NumberOffAudioUtils
{
  private static String getActionIndexLast()
  {
    switch (StringUtils.getRandom(1, 4))
    {
    default:
      return "Sounds/ProgressAudio/zhjcz";
    case 1:
      return "Sounds/ProgressAudio/zh";
    case 2:
      return "Sounds/ProgressAudio/zhjy";
    case 3:
      return "Sounds/ProgressAudio/zhjyjy";
    case 4:
    }
    return "Sounds/ProgressAudio/zhjcz";
  }

  public static String getEndingTimeAudioCount(int paramInt)
  {
    if (paramInt == 3)
      return "Sounds/ProgressAudio/zwc3";
    return "Sounds/ProgressAudio/zwc5";
  }

  public static String getEndingTimeAudioSecond(int paramInt)
  {
    if (paramInt == 3)
      return "Sounds/ProgressAudio/zh3m";
    switch (StringUtils.getRandom(1, 2))
    {
    default:
      return "Sounds/ProgressAudio/zh5m";
    case 1:
      return "Sounds/ProgressAudio/zh5m";
    case 2:
    }
    return "Sounds/ProgressAudio/jc5m";
  }

  public static String getFinishAudio()
  {
    switch (StringUtils.getRandom(1, 2))
    {
    default:
      return "Sounds/ProgressAudio/tblwc";
    case 1:
      return "Sounds/ProgressAudio/tblwc";
    case 2:
    }
    return "Sounds/ProgressAudio/gxwc";
  }

  public static String getGoAudio()
  {
    return "Sounds/ProgressAudio/ks";
  }

  public static String getKeep5Seconds()
  {
    switch (StringUtils.getRandom(1, 3))
    {
    default:
      return "Sounds/ProgressAudio/zh5m";
    case 1:
      return "Sounds/ProgressAudio/zh5m";
    case 2:
      return "Sounds/ProgressAudio/zh5m_op2";
    case 3:
    }
    return "Sounds/ProgressAudio/jc5m";
  }

  public static String getMedalSound(String paramString)
  {
    if ("MED01".equals(paramString))
      return "Sounds/ProgressAudio/jackpot_win";
    return "Sounds/ProgressAudio/big_bonus";
  }

  public static String getMedalVoice(String paramString)
  {
    if ("MED01".equals(paramString))
      return "Sounds/ProgressAudio/gxmr";
    return "Sounds/ProgressAudio/gxcj";
  }

  public static String getNumAudio(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return "Sounds/emptySound";
    case -1:
      return "Sounds/timer_stop1";
    case 0:
      return "Sounds/emptySound";
    case 1:
      return "Sounds/ProgressAudio/1";
    case 2:
      return "Sounds/ProgressAudio/2";
    case 3:
      return "Sounds/ProgressAudio/3";
    case 4:
      return "Sounds/ProgressAudio/4";
    case 5:
      return "Sounds/ProgressAudio/5";
    case 6:
      return "Sounds/ProgressAudio/6";
    case 7:
      return "Sounds/ProgressAudio/7";
    case 8:
      return "Sounds/ProgressAudio/8";
    case 9:
      return "Sounds/ProgressAudio/9";
    case 10:
      return "Sounds/ProgressAudio/10";
    case 11:
      return "Sounds/ProgressAudio/11";
    case 12:
      return "Sounds/ProgressAudio/12";
    case 13:
      return "Sounds/ProgressAudio/13";
    case 14:
      return "Sounds/ProgressAudio/14";
    case 15:
      return "Sounds/ProgressAudio/15";
    case 16:
      return "Sounds/ProgressAudio/16";
    case 17:
      return "Sounds/ProgressAudio/17";
    case 18:
      return "Sounds/ProgressAudio/18";
    case 19:
      return "Sounds/ProgressAudio/19";
    case 20:
      return "Sounds/ProgressAudio/20";
    case 21:
      return "Sounds/ProgressAudio/21";
    case 22:
      return "Sounds/ProgressAudio/22";
    case 23:
      return "Sounds/ProgressAudio/23";
    case 24:
      return "Sounds/ProgressAudio/24";
    case 25:
      return "Sounds/ProgressAudio/25";
    case 26:
      return "Sounds/ProgressAudio/26";
    case 27:
      return "Sounds/ProgressAudio/27";
    case 28:
      return "Sounds/ProgressAudio/28";
    case 29:
      return "Sounds/ProgressAudio/29";
    case 30:
      return "Sounds/ProgressAudio/30";
    case 31:
      return "Sounds/ProgressAudio/31";
    case 32:
      return "Sounds/ProgressAudio/32";
    case 33:
      return "Sounds/ProgressAudio/33";
    case 34:
      return "Sounds/ProgressAudio/34";
    case 35:
      return "Sounds/ProgressAudio/35";
    case 36:
      return "Sounds/ProgressAudio/36";
    case 37:
      return "Sounds/ProgressAudio/37";
    case 38:
      return "Sounds/ProgressAudio/38";
    case 39:
      return "Sounds/ProgressAudio/39";
    case 40:
      return "Sounds/ProgressAudio/40";
    case 41:
      return "Sounds/ProgressAudio/41";
    case 42:
      return "Sounds/ProgressAudio/42";
    case 43:
      return "Sounds/ProgressAudio/43";
    case 44:
      return "Sounds/ProgressAudio/44";
    case 45:
      return "Sounds/ProgressAudio/45";
    case 46:
      return "Sounds/ProgressAudio/46";
    case 47:
      return "Sounds/ProgressAudio/47";
    case 48:
      return "Sounds/ProgressAudio/48";
    case 49:
      return "Sounds/ProgressAudio/49";
    case 50:
      return "Sounds/ProgressAudio/50";
    case 51:
      return "Sounds/ProgressAudio/51";
    case 52:
      return "Sounds/ProgressAudio/52";
    case 53:
      return "Sounds/ProgressAudio/53";
    case 54:
      return "Sounds/ProgressAudio/54";
    case 55:
      return "Sounds/ProgressAudio/55";
    case 56:
      return "Sounds/ProgressAudio/56";
    case 57:
      return "Sounds/ProgressAudio/57";
    case 58:
      return "Sounds/ProgressAudio/58";
    case 59:
      return "Sounds/ProgressAudio/59";
    case 60:
      return "Sounds/ProgressAudio/60";
    case 61:
      return "Sounds/ProgressAudio/61";
    case 62:
      return "Sounds/ProgressAudio/62";
    case 63:
      return "Sounds/ProgressAudio/63";
    case 64:
      return "Sounds/ProgressAudio/64";
    case 65:
      return "Sounds/ProgressAudio/65";
    case 66:
      return "Sounds/ProgressAudio/66";
    case 67:
      return "Sounds/ProgressAudio/67";
    case 68:
      return "Sounds/ProgressAudio/68";
    case 69:
      return "Sounds/ProgressAudio/69";
    case 70:
      return "Sounds/ProgressAudio/70";
    case 71:
      return "Sounds/ProgressAudio/71";
    case 72:
      return "Sounds/ProgressAudio/72";
    case 73:
      return "Sounds/ProgressAudio/73";
    case 74:
      return "Sounds/ProgressAudio/74";
    case 75:
      return "Sounds/ProgressAudio/75";
    case 76:
      return "Sounds/ProgressAudio/76";
    case 77:
      return "Sounds/ProgressAudio/77";
    case 78:
      return "Sounds/ProgressAudio/78";
    case 79:
      return "Sounds/ProgressAudio/79";
    case 80:
      return "Sounds/ProgressAudio/80";
    case 81:
      return "Sounds/ProgressAudio/81";
    case 82:
      return "Sounds/ProgressAudio/82";
    case 83:
      return "Sounds/ProgressAudio/83";
    case 84:
      return "Sounds/ProgressAudio/84";
    case 85:
      return "Sounds/ProgressAudio/85";
    case 86:
      return "Sounds/ProgressAudio/86";
    case 87:
      return "Sounds/ProgressAudio/87";
    case 88:
      return "Sounds/ProgressAudio/88";
    case 89:
      return "Sounds/ProgressAudio/89";
    case 90:
      return "Sounds/ProgressAudio/90";
    case 91:
      return "Sounds/ProgressAudio/91";
    case 92:
      return "Sounds/ProgressAudio/92";
    case 93:
      return "Sounds/ProgressAudio/93";
    case 94:
      return "Sounds/ProgressAudio/94";
    case 95:
      return "Sounds/ProgressAudio/95";
    case 96:
      return "Sounds/ProgressAudio/96";
    case 97:
      return "Sounds/ProgressAudio/97";
    case 98:
      return "Sounds/ProgressAudio/98";
    case 99:
      return "Sounds/ProgressAudio/99";
    case 100:
    }
    return "Sounds/ProgressAudio/100";
  }

  public static String getPlayActionIndexType(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return "Sounds/ProgressAudio/xgdz";
    case 1:
      return "Sounds/ProgressAudio/dygdz";
    case 2:
      return "Sounds/ProgressAudio/xgdz";
    case 3:
    }
    return getActionIndexLast();
  }

  public static String getReadyEncourage()
  {
    switch (StringUtils.getRandom(1, 9))
    {
    default:
      return "Sounds/Rest/byz";
    case 1:
      return "Sounds/Rest/byz";
    case 2:
      return "Sounds/Rest/byzz";
    case 3:
      return "Sounds/Rest/cch";
    case 4:
      return "Sounds/Rest/fmhx";
    case 5:
      return "Sounds/Rest/gjbl";
    case 6:
      return "Sounds/Rest/gjl";
    case 7:
      return "Sounds/Rest/rgc";
    case 8:
      return "Sounds/Rest/shx";
    case 9:
    }
    return "Sounds/Rest/stl";
  }

  public static String getReadyGo()
  {
    return "Sounds/ProgressAudio/zbjt";
  }

  public static String getRestEndAudio()
  {
    return "Sounds/ProgressAudio/xxjs";
  }

  public static String getSecond()
  {
    return "Sounds/ProgressAudio/m_op1";
  }

  public static String getStageSound(StageModel paramStageModel)
  {
    if (paramStageModel.isTrainStage())
    {
      switch (StringUtils.getRandom(1, 3))
      {
      default:
        return "Sounds/ProgressAudio/xzjr";
      case 1:
        return "Sounds/ProgressAudio/zbzs";
      case 2:
        return "Sounds/ProgressAudio/mszs";
      case 3:
      }
      return "Sounds/ProgressAudio/xzjr";
    }
    switch (StringUtils.getRandom(1, 5))
    {
    default:
      return "Sounds/ProgressAudio/ksls";
    case 1:
      return "Sounds/ProgressAudio/ksls";
    case 2:
      return "Sounds/ProgressAudio/bzhj";
    case 3:
      return "Sounds/ProgressAudio/hjxl";
    case 4:
      return "Sounds/ProgressAudio/xzksls";
    case 5:
    }
    return "Sounds/ProgressAudio/xzjrls";
  }

  public static String getTime()
  {
    return "Sounds/ProgressAudio/c_op1";
  }

  public static String getTimer()
  {
    return "Sounds/timer";
  }

  public static String getTimer2()
  {
    return "Sounds/timer2";
  }

  public static String getTimer_stop1()
  {
    return "Sounds/timer_stop1";
  }

  public static String getTimer_stop11()
  {
    return "Sounds/timer_stop11";
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.common.NumberOffAudioUtils3
 * JD-Core Version:    0.6.0
 */