package com.sportq.fit.fitmoudle3.video.common;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.widget.ProgressBar;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TrainVideoDownLoadTool
{
  private static final String STR_LAODER_MSG_HINT = "当前网络环境为非Wi-Fi状态，确定要下载吗？";
  private static final String STR_LAODER_TITLE_HINT = "提示";
  private static final String STR_NO_NETWORK_HINT = "当前没有网络，请稍后再试";
  private static final String STR_TAG = "TrainVideoDownLoadTool";
  public static int callbackIndex = -1;
  private Context context;
  private ProgressBar download_pro;
  private LoaderListener listener;
  private int loadIndex = 0;
  private int loaderPro = 0;
  private String strTrainFileName;
  private String strTrainUrl;
  private ExecutorService threadPool;
  private HashMap<Integer, String> vHashMap = null;
  private ArrayList<String> vList;
  private ArrayList<ArrayList<String>> vMoreList;

  public TrainVideoDownLoadTool(LoaderListener paramLoaderListener, Context paramContext, String paramString, ProgressBar paramProgressBar, ArrayList<String> paramArrayList, ArrayList<ArrayList<String>> paramArrayList1)
  {
    this.context = paramContext;
    this.listener = paramLoaderListener;
    this.vList = paramArrayList;
    this.vMoreList = paramArrayList1;
    this.strTrainFileName = paramString;
    this.download_pro = paramProgressBar;
    this.vHashMap = new HashMap();
    this.threadPool = Executors.newFixedThreadPool(1 + Runtime.getRuntime().availableProcessors());
  }

  public static boolean checkHaveNoLoaderVideo(String paramString, ArrayList<String> paramArrayList)
  {
    if ((paramArrayList == null) || (paramArrayList.isEmpty()))
      return false;
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(VersionUpdateCheck.ALBUM_VIDEO_FILE_NAME);
    localStringBuilder.append(paramString);
    localStringBuilder.append("/");
    int i = 0;
    label45: String str1;
    if (i < paramArrayList.size())
    {
      str1 = (String)paramArrayList.get(i);
      if (!str1.contains("/storage"))
        break label81;
    }
    label81: String str2;
    do
    {
      i++;
      break label45;
      break;
      str2 = str1.substring(1 + str1.lastIndexOf("/"));
    }
    while (new File(localStringBuilder.toString() + str2).exists());
    return true;
  }

  private boolean checkUrlInvalid(String paramString1, String paramString2, ArrayList<String> paramArrayList)
  {
    return (StringUtils.isNull(paramString1)) || (paramArrayList.contains(paramString1)) || (checkVideoExists(paramString2, paramString1));
  }

  public static boolean checkVideoExists(String paramString1, String paramString2)
  {
    if (StringUtils.isNull(paramString2));
    String str3;
    do
    {
      do
        return false;
      while (paramString2.contains("/storage"));
      String str1 = VersionUpdateCheck.ALBUM_VIDEO_FILE_NAME + paramString1 + "/";
      String str2 = paramString2.substring(1 + paramString2.lastIndexOf("/"));
      if (str2.contains("?"))
        str2 = str2.substring(0, str2.lastIndexOf("?"));
      File localFile = new File(str1 + str2);
      boolean bool = localFile.exists();
      str3 = null;
      if (!bool)
        continue;
      str3 = localFile.getAbsolutePath();
    }
    while (str3 == null);
    return true;
  }

  public static String convertTrainName()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("fitFile");
    return localStringBuilder.toString();
  }

  public static String getAlbumTrainPath(String paramString)
  {
    return getAlbumTrainPath(convertTrainName(), paramString);
  }

  public static String getAlbumTrainPath(String paramString1, String paramString2)
  {
    String str1 = VersionUpdateCheck.ALBUM_VIDEO_FILE_NAME + paramString1 + "/";
    if (paramString2.contains("?"))
      paramString2 = paramString2.substring(0, paramString2.lastIndexOf("?"));
    boolean bool1 = paramString2.contains("/storage");
    String str2 = null;
    if (!bool1)
    {
      String str3 = paramString2.substring(1 + paramString2.lastIndexOf("/"));
      File localFile = new File(str1 + str3);
      boolean bool2 = localFile.exists();
      str2 = null;
      if (bool2)
        str2 = localFile.getAbsolutePath();
    }
    return str2;
  }

  private void loopDownload(int paramInt)
  {
    if (this.loadIndex >= this.vList.size())
      return;
    this.strTrainUrl = ((String)this.vList.get(this.loadIndex));
    String str = (String)this.vHashMap.get(Integer.valueOf(this.loadIndex));
    if (!StringUtils.isNull(str));
    while (true)
    {
      this.strTrainFileName = str;
      this.loadIndex = (1 + this.loadIndex);
      this.threadPool.submit(new Thread(new Runnable(paramInt)
      {
        public void run()
        {
          TrainVideoDownLoadTool localTrainVideoDownLoadTool = TrainVideoDownLoadTool.this;
          if (TrainVideoDownLoadTool.this.download_pro != null);
          for (int i = 0; ; i = 1)
          {
            localTrainVideoDownLoadTool.requestNetwork(i, TrainVideoDownLoadTool.this.strTrainUrl, TrainVideoDownLoadTool.this.strTrainFileName, new TrainVideoDownLoadTool.RequestListener()
            {
              public void onRequestPro(int paramInt)
              {
                int i = 360;
                if (TrainVideoDownLoadTool.this.loaderPro > TrainVideoDownLoadTool.1.this.val$maxPro);
                label262: label268: label294: 
                while (true)
                {
                  return;
                  int j;
                  if (TrainVideoDownLoadTool.this.download_pro == null)
                  {
                    j = i;
                    if (paramInt == j)
                    {
                      TrainVideoDownLoadTool localTrainVideoDownLoadTool = TrainVideoDownLoadTool.this;
                      int m = TrainVideoDownLoadTool.this.loadIndex;
                      if (TrainVideoDownLoadTool.this.download_pro != null)
                        break label262;
                      label79: TrainVideoDownLoadTool.access$302(localTrainVideoDownLoadTool, -1 + i * m);
                      TrainVideoDownLoadTool.this.loopDownload(TrainVideoDownLoadTool.1.this.val$maxPro);
                    }
                    TrainVideoDownLoadTool.access$308(TrainVideoDownLoadTool.this);
                    if (TrainVideoDownLoadTool.this.download_pro == null)
                      break label268;
                    int k = TrainVideoDownLoadTool.this.download_pro.getProgress();
                    if (TrainVideoDownLoadTool.this.loaderPro > k)
                      TrainVideoDownLoadTool.this.download_pro.setProgress(TrainVideoDownLoadTool.this.loaderPro);
                  }
                  while (true)
                  {
                    if ((TrainVideoDownLoadTool.this.loaderPro != TrainVideoDownLoadTool.1.this.val$maxPro) || (TrainVideoDownLoadTool.this.loadIndex != TrainVideoDownLoadTool.this.vList.size()))
                      break label294;
                    ((AppCompatActivity)TrainVideoDownLoadTool.this.context).runOnUiThread(new Runnable()
                    {
                      public void run()
                      {
                        TrainVideoDownLoadTool.this.listener.loaderFinish();
                      }
                    });
                    return;
                    j = 100;
                    break;
                    i = 100;
                    break label79;
                    TrainVideoDownLoadTool.this.listener.loaderPro(TrainVideoDownLoadTool.this.loaderPro);
                  }
                }
              }
            });
            return;
          }
        }
      }));
      return;
      str = this.strTrainFileName;
    }
  }

  private void requestNetwork(int paramInt, String paramString1, String paramString2, RequestListener paramRequestListener)
  {
    FileUtils.makeRootTrainDirectory(paramString2);
    String str1 = VersionUpdateCheck.ALBUM_VIDEO_FILE_NAME + paramString2 + "/";
    callbackIndex = -1;
    String str2 = paramString1.substring(1 + paramString1.lastIndexOf("/"));
    String str3 = str1 + str2;
    while (true)
    {
      InputStream localInputStream;
      FileOutputStream localFileOutputStream;
      int i;
      float f;
      try
      {
        File localFile = new File(str3);
        if (!localFile.exists())
          continue;
        localFile.delete();
        URLConnection localURLConnection = new URL(paramString1).openConnection();
        localInputStream = localURLConnection.getInputStream();
        byte[] arrayOfByte = new byte[1024];
        localFileOutputStream = new FileOutputStream(str3);
        i = 0;
        int j = localURLConnection.getContentLength();
        int k = 0;
        int m = localInputStream.read(arrayOfByte);
        if (m == -1)
          break label255;
        k += m;
        f = k / j;
        if (paramInt == 0)
        {
          n = 100;
          break label280;
          if ((i >= i1) || (callbackIndex == i))
            continue;
          paramRequestListener.onRequestPro(i);
          callbackIndex = i;
          localFileOutputStream.write(arrayOfByte, 0, m);
          continue;
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return;
      }
      int n = 360;
      label255: 
      do
      {
        i1 = 360;
        break;
        localFileOutputStream.close();
        localInputStream.close();
        paramRequestListener.onRequestPro(i);
        callbackIndex = i;
        return;
        i = (int)(f * n);
      }
      while (paramInt != 0);
      label280: int i1 = 100;
    }
  }

  private void startLoadTrainVideo()
  {
    this.listener.onReadyToDownload();
    int i = this.vList.size();
    int j;
    int k;
    if (this.download_pro == null)
    {
      j = 360;
      k = i * j;
      if (k == 0)
        break label84;
      if (this.download_pro == null)
        break label71;
      this.download_pro.setMax(k);
      this.download_pro.setProgress(0);
    }
    while (true)
    {
      loopDownload(k);
      return;
      j = 100;
      break;
      label71: this.listener.loaderMaxPro(k);
    }
    label84: this.listener.loaderFinish();
  }

  public static abstract interface LoaderListener
  {
    public abstract void loaderFinish();

    public abstract void loaderMaxPro(int paramInt);

    public abstract void loaderPro(int paramInt);

    public abstract void onReadyToDownload();
  }

  static abstract interface RequestListener
  {
    public abstract void onRequestPro(int paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.common.TrainVideoDownLoadTool
 * JD-Core Version:    0.6.0
 */