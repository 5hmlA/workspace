package com.sportq.fit.fitmoudle3.video.common.constant;

import com.sportq.fit.common.constant.Constant;

public class Constant3 extends Constant
{
  public static final String ENCOURAGE_DIR = "Sounds/Encourage";
  public static final String PROGRESSAUDIO_DIR = "Sounds/ProgressAudio";
  public static final String REST_DIR = "Sounds/Rest";
  public static final String SOUNDS_DIR = "Sounds";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.common.constant.Constant3
 * JD-Core Version:    0.6.0
 */