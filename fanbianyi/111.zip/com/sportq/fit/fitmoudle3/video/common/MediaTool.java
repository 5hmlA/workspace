package com.sportq.fit.fitmoudle3.video.common;

import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.fitmoudle3.video.common.constant.Constant3;

public class MediaTool
{
  public static boolean isMusicOn()
  {
    return Constant3.MUSIC_ON == PreferencesTools.getFloatValueToKey("tbl_volume_info", Constant3.KEY_MUSIC_TOGGLE);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.common.MediaTool
 * JD-Core Version:    0.6.0
 */