package com.sportq.fit.fitmoudle3.video.presenter;

import android.app.Activity;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.widget.AppCompatTextView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.presenter.video.Callback;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnCompletionListener;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnErrorListener;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnPreparedListener;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.StageModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.fitmoudle3.video.R.anim;
import com.sportq.fit.fitmoudle3.video.R.mipmap;
import com.sportq.fit.fitmoudle3.video.R.string;
import com.sportq.fit.fitmoudle3.video.activity.Video01Activity;
import com.sportq.fit.fitmoudle3.video.common.NumberOffAudioUtils3;
import com.sportq.fit.fitmoudle3.video.common.event.VideoPreviewEvent;
import com.sportq.fit.fitmoudle3.video.datatransform.reformer.TrainingReformer;
import com.sportq.fit.fitmoudle3.video.utils.SharePreferenceUtils3;
import com.sportq.fit.fitmoudle3.video.widget.CircleTextProgressbar;
import com.sportq.fit.fitmoudle3.video.widget.CircleTextProgressbar.OnCountdownProgressListener;
import com.sportq.fit.fitmoudle3.video.widget.CircleTextProgressbar.ProgressType;
import com.sportq.fit.fitmoudle3.video.widget.videoplayer.MediaController;
import com.sportq.fit.fitmoudle3.video.widget.videoplayer.MediaController.PlayState;
import com.sportq.fit.videopresenter.SptVideoView;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.greenrobot.eventbus.EventBus;
import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class SptVideoPlayerPresenter extends BaseSptVideoPlayerPresenter
{
  private int startTime = 0;

  public SptVideoPlayerPresenter(Video01Activity paramVideo01Activity, View paramView, Video01Presenter paramVideo01Presenter)
  {
    super(paramVideo01Activity, paramView, paramVideo01Presenter);
  }

  private void playActionCount(Subscriber<? super Object> paramSubscriber)
  {
    this.mCountSubscription = Observable.interval(()this.video01Presenter.getTrainingReformer().oneTimeActionTime, TimeUnit.MILLISECONDS).subscribe(new Action1(paramSubscriber)
    {
      public void call(Long paramLong)
      {
        if (StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration) >= StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration))
        {
          ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable()
          {
            public void run()
            {
              SptVideoPlayerPresenter.this.singleActTime.setText("");
            }
          });
          SptVideoPlayerPresenter.this.unSubscription();
          this.val$subscriber.onCompleted();
          LogUtils.d("SptVideoPlayerPresenter->playActionCount", "完成当前动作");
          return;
        }
        SptVideoPlayerPresenter.this.setCountText();
      }
    });
  }

  private void playActionSecond(Subscriber<? super Object> paramSubscriber)
  {
    int i = StringUtils.string2Int(this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration);
    int j = StringUtils.string2Int(this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration);
    if (j == 0)
      ((Activity)this.context).runOnUiThread(new Runnable(i)
      {
        public void run()
        {
          SptVideoPlayerPresenter.this.singleActTime.setVisibility(0);
          SptVideoPlayerPresenter.this.singleActTime.setText(String.valueOf(this.val$actionDuration));
        }
      });
    this.subscription = Observable.interval(1L, TimeUnit.SECONDS).subscribe(new Action1(j, i, paramSubscriber)
    {
      public void call(Long paramLong)
      {
        if (SptVideoPlayerPresenter.this.isPause())
          return;
        int i = 1 + paramLong.intValue() + this.val$tempStartTime;
        SptVideoPlayerPresenter.this.video01Presenter.playActionGuideSoundSecond(SptVideoPlayerPresenter.this.actionMediaPlayerHelper, i);
        SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().curTimeCount = (this.val$actionDuration - i);
        SptVideoPlayerPresenter.this.video01Presenter.playEndingCount(new Callback()
        {
          public void callback(String paramString)
          {
            SptVideoPlayerPresenter.this.actionMediaPlayerHelper.playGuideAudio(NumberOffAudioUtils3.getEndingTimeAudioSecond(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.endingTime), null);
          }
        });
        if ((SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().curTimeCount <= SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.endingTime) && (SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.endingTime > 0))
          SptVideoPlayerPresenter.this.countMediaPlayerHelper.playCount((int)SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().curTimeCount);
        while (true)
        {
          LogUtils.d("SptVideoPlayerPresenter-currentTrainTime", String.valueOf(i));
          LogUtils.d("SptVideoPlayerPresenter-actionDuration+2", String.valueOf(2 + this.val$actionDuration));
          if (i < 2 + this.val$actionDuration)
            break;
          LogUtils.d("SptVideoPlayerPresenter----", "动作完成");
          ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable()
          {
            public void run()
            {
              SptVideoPlayerPresenter.this.singleActTime.setText("");
              SptVideoPlayerPresenter.this.videoView.stopPlayback();
              SptVideoPlayerPresenter.this.unSubscription();
              SptVideoPlayerPresenter.18.this.val$subscriber.onCompleted();
            }
          });
          return;
          if (this.val$actionDuration - i <= 0)
          {
            SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getNumAudio(this.val$actionDuration - i));
            continue;
          }
          SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getTimer2());
        }
        SptVideoPlayerPresenter.this.updateProgressWithTrain();
        SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration = String.valueOf(i);
        if ((this.val$actionDuration > 30) && (!SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().isPlayingTipsAudio) && (this.val$actionDuration - i == 6) && (SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.endingTime == 0))
          SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getKeep5Seconds());
        ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable(i)
        {
          public void run()
          {
            if (SptVideoPlayerPresenter.18.this.val$actionDuration >= this.val$currentTrainTime)
              SptVideoPlayerPresenter.this.singleActTime.setText(String.valueOf(SptVideoPlayerPresenter.18.this.val$actionDuration - this.val$currentTrainTime));
          }
        });
      }
    });
  }

  private void setCountText()
  {
    ((Activity)this.context).runOnUiThread(new Runnable()
    {
      public void run()
      {
        LogUtils.d("trainDuration1:", SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration);
        ActionModel localActionModel = SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel;
        if (StringUtils.isNull(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration));
        for (String str = "1"; ; str = String.valueOf(1 + StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration)))
        {
          localActionModel.trainDuration = str;
          LogUtils.d("trainDuration2:", SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration);
          SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().curActNum = StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration);
          SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().curTimeCount = (SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actTotTime - SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().curActNum * SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().oneTimeActionTime);
          SptVideoPlayerPresenter.this.singleActTime.setVisibility(0);
          SptVideoPlayerPresenter.this.singleActTime.setText(SptVideoPlayerPresenter.this.video01Presenter.getActionTimeStr(SptVideoPlayerPresenter.this.context, SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration));
          SptVideoPlayerPresenter.this.video01Presenter.playEndingCount(new Callback()
          {
            public void callback(String paramString)
            {
              SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().isPlayingTipsAudio = true;
              SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(paramString, null);
            }
          });
          LogUtils.d("trainDuration3:", SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().isPlayingTipsAudio + "");
          if (!SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().isPlayingTipsAudio)
            break;
          return;
        }
        SptVideoPlayerPresenter.this.countMediaPlayerHelper.playCount(StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration));
      }
    });
    this.video01Presenter.playActionGuideSoundCount(this.actionMediaPlayerHelper);
  }

  public Observable backCountDown()
  {
    unSubscription();
    setMediaPlayerHelperShouldPlay(false);
    this.isBackCountDowning = true;
    hideController();
    hideCenterView();
    this.controller.setPlayState(MediaController.PlayState.PLAY);
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber paramSubscriber)
      {
        if ((SptVideoPlayerPresenter.this.rest_time_tv.getTag() != null) && ("add.rest.time".equals(SptVideoPlayerPresenter.this.rest_time_tv.getTag())))
        {
          SptVideoPlayerPresenter.this.rest_time_tv.setTag(null);
          SptVideoPlayerPresenter.this.countDownFinish();
          paramSubscriber.onCompleted();
          return;
        }
        SptVideoPlayerPresenter.this.videoPlayerBackProgress.setVisibility(0);
        SptVideoPlayerPresenter.this.videoPlayerBackProgress.setProgress(100);
        SptVideoPlayerPresenter.this.videoPlayerBackProgress.setProgressType(CircleTextProgressbar.ProgressType.COUNT_BACK);
        SptVideoPlayerPresenter.this.videoPlayerBackProgress.setText("3");
        SptVideoPlayerPresenter.this.videoPlayerBackProgress.setTimeMillis(3000L);
        SptVideoPlayerPresenter.this.videoPlayerBackProgress.setCountdownProgressListener(0, new CircleTextProgressbar.OnCountdownProgressListener(paramSubscriber)
        {
          public void onProgress(int paramInt1, int paramInt2)
          {
            if (paramInt2 == 0)
            {
              SptVideoPlayerPresenter.this.countDownFinish();
              this.val$subscriber.onCompleted();
            }
            if (paramInt2 % 33 == 0);
            for (int i = 1; ; i = 0)
            {
              if (i != 0)
                SptVideoPlayerPresenter.this.videoPlayerBackProgress.setText(String.valueOf(paramInt2 / 33));
              return;
            }
          }
        });
        SptVideoPlayerPresenter.this.videoPlayerBackProgress.start();
      }
    });
  }

  public void countDownFinish()
  {
    this.videoPlayerBackProgress.setVisibility(8);
    this.blackLayout.setVisibility(8);
    if (this.add_rest_icon.getTag() == null)
    {
      this.controller.setPauseBtnClickable(true);
      this.controller.setPlayState(MediaController.PlayState.PLAY);
    }
    setMediaPlayerHelperShouldPlay(true);
    this.isBackCountDowning = false;
    unSubscription();
  }

  public void hideMuscleLinear(long paramLong)
  {
    new Handler().postDelayed(new Runnable()
    {
      public void run()
      {
        Animation localAnimation = AnimationUtils.loadAnimation(SptVideoPlayerPresenter.this.context, R.anim.sideslip_hide);
        SptVideoPlayerPresenter.this.muscle_linear.startAnimation(localAnimation);
        localAnimation.setAnimationListener(new Animation.AnimationListener()
        {
          public void onAnimationEnd(Animation paramAnimation)
          {
            SptVideoPlayerPresenter.this.muscle_linear.setVisibility(8);
            SptVideoPlayerPresenter.this.totalTrainTimeLayout.startAnimation(AnimationUtils.loadAnimation(SptVideoPlayerPresenter.this.context, R.anim.fade_in01));
            SptVideoPlayerPresenter.this.totalTrainTimeLayout.setVisibility(0);
          }

          public void onAnimationRepeat(Animation paramAnimation)
          {
          }

          public void onAnimationStart(Animation paramAnimation)
          {
          }
        });
      }
    }
    , paramLong);
  }

  public Observable playAction(boolean paramBoolean)
  {
    unSubscription();
    this.totalTrainTimeLayout.setVisibility(0);
    if ((isLandscape()) && (SharePreferenceUtils3.getMuscleIsOpen(this.context)) && (this.muscle_linear.getVisibility() == 0))
      this.muscle_linear.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.sideslip_hide));
    this.muscle_linear.setVisibility(8);
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber paramSubscriber)
      {
        if (StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration) >= StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration))
        {
          ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable()
          {
            public void run()
            {
              SptVideoPlayerPresenter.this.singleActTime.setText("");
            }
          });
          SptVideoPlayerPresenter.this.unSubscription();
          paramSubscriber.onCompleted();
          LogUtils.d("SptVideoPlayerPresenter", "完成当前动作:" + SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration);
          return;
        }
        ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable(paramSubscriber)
        {
          public void run()
          {
            SptVideoPlayerPresenter.this.actTrainTime.setVisibility(8);
            SptVideoPlayerPresenter.this.videoView.seekTo(SptVideoPlayerPresenter.this.currentVideoPosition);
            SptVideoPlayerPresenter.this.videoView.start();
            SptVideoPlayerPresenter.this.hideActInfo();
            if (!SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.isSecond())
            {
              if (SptVideoPlayerPresenter.this.subscription == null)
                SptVideoPlayerPresenter.this.subscription = Observable.interval(1L, TimeUnit.SECONDS).subscribe(new Action1()
                {
                  public void call(Long paramLong)
                  {
                    if (SptVideoPlayerPresenter.this.isPause())
                      return;
                    SptVideoPlayerPresenter.this.updateProgressWithTrain();
                  }
                });
              if ((SptVideoPlayerPresenter.this.currentVideoPosition == 0) && (SptVideoPlayerPresenter.this.isTrainDurationEquals0()))
                SptVideoPlayerPresenter.this.setCountText();
              SptVideoPlayerPresenter.this.playActionCount(this.val$subscriber);
            }
            SptVideoPlayerPresenter.this.currentVideoPosition = 0;
            if (SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.isSecond())
              SptVideoPlayerPresenter.this.playActionSecond(this.val$subscriber);
            SptVideoPlayerPresenter.this.videoView.setOnCompletionListener(new FitMediaPlayer.OnCompletionListener()
            {
              public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
              {
                SptVideoPlayerPresenter.this.currentVideoPosition = 0;
              }
            });
          }
        });
      }
    }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
  }

  public void playActionGuideVolumePreview()
  {
    unSubscription();
    this.actionMediaPlayerHelper.setPreview(true);
    this.actionMediaPlayerHelper.playGuideAudio(String.format("%s/jy2", new Object[] { "Sounds/Encourage" }), null);
  }

  public void playActionPreview()
  {
    if (StringUtils.isNull(this.video01Presenter.getTrainingReformer().actionLocalVideoUrl))
      return;
    ((Activity)this.context).runOnUiThread(new Runnable()
    {
      public void run()
      {
        SptVideoPlayerPresenter.this.videoView.setVideoPath(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actionLocalVideoUrl);
        SptVideoPlayerPresenter.this.videoView.requestFocus();
        SptVideoPlayerPresenter.this.videoView.seekTo(SptVideoPlayerPresenter.this.currentVideoPosition);
        SptVideoPlayerPresenter.this.videoView.setOnErrorListener(new FitMediaPlayer.OnErrorListener()
        {
          public boolean onError(FitMediaPlayer paramFitMediaPlayer, int paramInt1, int paramInt2)
          {
            try
            {
              File localFile = new File(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actionLocalVideoUrl);
              if (localFile.exists())
              {
                SptVideoPlayerPresenter.this.videoView.stopPlayback();
                System.gc();
                localFile.delete();
              }
              return false;
            }
            catch (Exception localException)
            {
              while (true)
              {
                LogUtils.e(localException);
                if (StringUtils.isNull(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actionNetVideoUrl))
                  continue;
                SptVideoPlayerPresenter.this.videoView.setVideoURI(Uri.parse(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actionNetVideoUrl));
                SptVideoPlayerPresenter.this.videoView.seekTo(SptVideoPlayerPresenter.this.currentVideoPosition);
                if (SptVideoPlayerPresenter.this.isPause())
                  continue;
                SptVideoPlayerPresenter.this.videoView.start();
              }
            }
            finally
            {
              if (!StringUtils.isNull(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actionNetVideoUrl))
              {
                SptVideoPlayerPresenter.this.videoView.setVideoURI(Uri.parse(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actionNetVideoUrl));
                SptVideoPlayerPresenter.this.videoView.seekTo(SptVideoPlayerPresenter.this.currentVideoPosition);
                if (!SptVideoPlayerPresenter.this.isPause())
                  SptVideoPlayerPresenter.this.videoView.start();
              }
            }
            throw localObject;
          }
        });
        SptVideoPlayerPresenter.this.currentVideoPosition = 0;
        SptVideoPlayerPresenter.this.videoView.start();
        SptVideoPlayerPresenter.this.videoView.setOnPreparedListener(new FitMediaPlayer.OnPreparedListener()
        {
          public void onPrepared(FitMediaPlayer paramFitMediaPlayer)
          {
            paramFitMediaPlayer.setLooping(true);
            paramFitMediaPlayer.start();
            if ((SptVideoPlayerPresenter.this.isPause()) || (SptVideoPlayerPresenter.this.isBackCountDowning) || (SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().isDialogShowing))
            {
              SptVideoPlayerPresenter.this.videoView.seekTo(SptVideoPlayerPresenter.this.currentVideoPosition);
              SptVideoPlayerPresenter.this.videoView.pause();
            }
          }
        });
        SptVideoPlayerPresenter.this.videoView.setOnCompletionListener(null);
      }
    });
  }

  public Observable playActionPreviewCountDown()
  {
    unSubscription();
    ((Activity)this.context).runOnUiThread(new Runnable()
    {
      public void run()
      {
        SptVideoPlayerPresenter.this.videoPlayerPreview.setVisibility(0);
        if (SptVideoPlayerPresenter.this.isLandscape())
        {
          SptVideoPlayerPresenter.this.actTitleLayout.setVisibility(0);
          SptVideoPlayerPresenter.this.showMuscleUI(true);
        }
        while (true)
        {
          SptVideoPlayerPresenter.this.singleActTime.setVisibility(8);
          return;
          SptVideoPlayerPresenter.this.muscle_linear.setVisibility(8);
          SptVideoPlayerPresenter.this.totalTrainTimeLayout.setVisibility(0);
        }
      }
    });
    if (!this.videoView.isPlaying())
      playActionPreview();
    if (StringUtils.isNull(this.singleActTime.getText().toString()));
    for (int i = 0; ; i = StringUtils.string2Int(this.singleActTime.getText().toString()))
      return Observable.create(new Observable.OnSubscribe(i)
      {
        public void call(Subscriber paramSubscriber)
        {
          SptVideoPlayerPresenter.this.subscription = Observable.interval(1L, TimeUnit.SECONDS).onBackpressureBuffer().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1(paramSubscriber)
          {
            public void call(Long paramLong)
            {
              int i = paramLong.intValue() + SptVideoPlayerPresenter.7.this.val$startTime;
              SptVideoPlayerPresenter.this.singleActTime.setText(String.valueOf(i));
              if (i >= 4)
              {
                SptVideoPlayerPresenter.this.videoPlayerPreview.setVisibility(8);
                SptVideoPlayerPresenter.this.singleActTime.setText("");
                SptVideoPlayerPresenter.this.unSubscription();
                this.val$subscriber.onCompleted();
              }
              if ((SptVideoPlayerPresenter.this.isLandscape()) && (i == 4) && (SharePreferenceUtils3.getMuscleIsOpen(SptVideoPlayerPresenter.this.context)) && (SptVideoPlayerPresenter.this.muscle_linear.getVisibility() == 0))
                SptVideoPlayerPresenter.this.hideMuscleLinear(1300L);
            }
          });
        }
      });
  }

  public Observable playActionTime()
  {
    unSubscription();
    if (!this.videoView.isPlaying())
      playActionPreview();
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber paramSubscriber)
      {
        ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable()
        {
          public void run()
          {
            SptVideoPlayerPresenter.this.singleActTime.setVisibility(0);
            if (SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().totTimeCount == 0.0F)
              SptVideoPlayerPresenter.this.totalTrainTimeLayout.setVisibility(0);
            if (!SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.isSecond())
            {
              SptVideoPlayerPresenter.this.singleActTime.setText(SptVideoPlayerPresenter.this.video01Presenter.getActionTimeStr(SptVideoPlayerPresenter.this.context, "0"));
              return;
            }
            SptVideoPlayerPresenter.this.singleActTime.setVisibility(0);
            SptVideoPlayerPresenter.this.singleActTime.setText(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration);
          }
        });
        String str1 = NumberOffAudioUtils3.getNumAudio(StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration));
        String str2 = NumberOffAudioUtils3.getTime();
        if (SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.isSecond())
          str2 = NumberOffAudioUtils3.getSecond();
        String str3 = str2;
        SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(str1, new FitMediaPlayer.OnCompletionListener(str3, paramSubscriber)
        {
          public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
          {
            SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(this.val$finalAudio, new FitMediaPlayer.OnCompletionListener()
            {
              public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
              {
                SptVideoPlayerPresenter.this.unSubscription();
                SptVideoPlayerPresenter.9.2.this.val$subscriber.onCompleted();
              }
            });
          }
        });
      }
    });
  }

  public Observable playActionTitle(int paramInt)
  {
    unSubscription();
    totalTrainTimeSubscriptionStart();
    this.controller.actionIndexType(paramInt);
    this.actTitleLayout.setVisibility(8);
    if ((isLandscape()) && (SharePreferenceUtils3.getMuscleIsOpen(this.context)) && (this.muscle_linear.getVisibility() == 0))
      this.muscle_linear.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.sideslip_hide));
    this.muscle_linear.setVisibility(8);
    return Observable.create(new Observable.OnSubscribe(paramInt)
    {
      public void call(Subscriber paramSubscriber)
      {
        ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable()
        {
          public void run()
          {
            SptVideoPlayerPresenter.this.blackLayout.setVisibility(0);
            SptVideoPlayerPresenter.this.nextAct.setText(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionName);
            SptVideoPlayerPresenter.this.nextAct.setVisibility(0);
            SptVideoPlayerPresenter.this.blackView.setVisibility(8);
            SptVideoPlayerPresenter.this.totalTrainTimeLayout.setVisibility(0);
          }
        });
        SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getPlayActionIndexType(this.val$actIndexType), new FitMediaPlayer.OnCompletionListener(paramSubscriber)
        {
          public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
          {
            SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actionVoiceURL, new FitMediaPlayer.OnCompletionListener()
            {
              public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
              {
                SptVideoPlayerPresenter.this.hideActInfo();
                ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable()
                {
                  public void run()
                  {
                    SptVideoPlayerPresenter.this.singleActTime.setText("");
                  }
                });
                SptVideoPlayerPresenter.this.unSubscription();
                SptVideoPlayerPresenter.4.2.this.val$subscriber.onCompleted();
              }
            });
          }
        });
      }
    });
  }

  public Observable playCountDown()
  {
    unSubscription();
    if (!this.videoView.isPlaying())
      playActionPreview();
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber paramSubscriber)
      {
        int i = StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration);
        SptVideoPlayerPresenter.this.subscription = Observable.interval(1L, TimeUnit.MILLISECONDS).subscribe(new Action1(i, paramSubscriber)
        {
          public void call(Long paramLong)
          {
            int i = this.val$startTime + paramLong.intValue();
            if (i >= 3000)
            {
              ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable()
              {
                public void run()
                {
                  SptVideoPlayerPresenter.this.countdown.setText("");
                }
              });
              SptVideoPlayerPresenter.this.unSubscription();
              SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getGoAudio(), new FitMediaPlayer.OnCompletionListener()
              {
                public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
                {
                  SptVideoPlayerPresenter.this.currentVideoPosition = 0;
                  SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration = "";
                  SptVideoPlayerPresenter.10.1.this.val$subscriber.onCompleted();
                }
              });
              return;
            }
            if (i % 1000 == 0)
            {
              SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getTimer());
              ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable(i)
              {
                public void run()
                {
                  if (SptVideoPlayerPresenter.this.countdown.getVisibility() == 8)
                    SptVideoPlayerPresenter.this.countdown.setVisibility(0);
                  if (SptVideoPlayerPresenter.this.isLandscape())
                    SptVideoPlayerPresenter.this.countdown.setTextSize(100.0F);
                  while (true)
                  {
                    SptVideoPlayerPresenter.this.countdown.setText(String.valueOf(3 - this.val$time / 1000));
                    SptVideoPlayerPresenter.this.countdown.clearAnimation();
                    SptVideoPlayerPresenter.this.scaleAnimation(SptVideoPlayerPresenter.this.countdown);
                    return;
                    SptVideoPlayerPresenter.this.countdown.setTextSize(60.0F);
                  }
                }
              });
            }
            SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration = String.valueOf(i);
          }
        });
      }
    });
  }

  public void playCountVolumePreview()
  {
    if (this.subscription != null)
    {
      this.subscription.unsubscribe();
      this.subscription = null;
    }
    this.subscription = Observable.interval(500L, TimeUnit.MILLISECONDS).take(3).subscribe(new Action1()
    {
      public void call(Long paramLong)
      {
        LogUtils.d("洗涤：", String.valueOf(paramLong.intValue()));
        SptVideoPlayerPresenter.this.countMediaPlayerHelper.setPreview(true);
        SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getTimer2());
        if (paramLong.longValue() == 1000L)
          SptVideoPlayerPresenter.this.unSubscription();
      }
    });
  }

  public Observable playFinish()
  {
    unSubscription();
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber paramSubscriber)
      {
        paramSubscriber.onCompleted();
      }
    }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
  }

  public Observable playRest()
  {
    unSubscription();
    totalTrainTimeSubscriptionStart();
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber paramSubscriber)
      {
        SptVideoPlayerPresenter.access$302(SptVideoPlayerPresenter.this, 1 + StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration));
        int i = StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration);
        if (SptVideoPlayerPresenter.this.startTime >= i)
        {
          SptVideoPlayerPresenter.this.unSubscription();
          SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getRestEndAudio(), new FitMediaPlayer.OnCompletionListener(paramSubscriber)
          {
            public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
            {
              SptVideoPlayerPresenter.this.restFinishUI();
              SptVideoPlayerPresenter.this.new_rest_base_layout.setVisibility(8);
              this.val$subscriber.onCompleted();
            }
          });
          return;
        }
        ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable(i)
        {
          public void run()
          {
            if (1 == SptVideoPlayerPresenter.this.startTime)
              SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actionVoiceURL);
            SptVideoPlayerPresenter.this.hideActInfo();
            SptVideoPlayerPresenter.this.restBackground.setVisibility(0);
            if (SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionName.contains("呼吸"))
              SptVideoPlayerPresenter.this.restBackground.setImageResource(R.mipmap.breathe);
            while (true)
            {
              if (SptVideoPlayerPresenter.this.add_rest_icon.getTag() == null)
                SptVideoPlayerPresenter.this.add_rest_icon.setVisibility(0);
              SptVideoPlayerPresenter.this.new_rest_base_layout.setVisibility(0);
              SptVideoPlayerPresenter.this.totalTrainTimeLayout.setVisibility(8);
              SptVideoPlayerPresenter.this.singleActTime.setVisibility(8);
              SptVideoPlayerPresenter.this.resetTitle.setVisibility(8);
              SptVideoPlayerPresenter.this.actTitle.setVisibility(8);
              SptVideoPlayerPresenter.this.blackLayout.setVisibility(0);
              SptVideoPlayerPresenter.this.actInfoIcon.setVisibility(8);
              SptVideoPlayerPresenter.this.leftBottomLayout.setOnClickListener(null);
              SptVideoPlayerPresenter.this.rest_time_tv.setVisibility(0);
              SptVideoPlayerPresenter.this.rest_time_tv.setText(String.valueOf(1 + (this.val$actionDuration - SptVideoPlayerPresenter.this.startTime)));
              SptVideoPlayerPresenter.this.videoView.setVideoPath(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().actionLocalVideoUrl);
              SptVideoPlayerPresenter.this.videoView.requestFocus();
              SptVideoPlayerPresenter.this.videoView.seekTo(SptVideoPlayerPresenter.this.currentVideoPosition);
              SptVideoPlayerPresenter.this.currentVideoPosition = 0;
              SptVideoPlayerPresenter.this.rest_hint_tv.setText(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionName);
              SptVideoPlayerPresenter.this.rest_next_act_title.setText(String.valueOf("接下来：" + SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionNameDown));
              SptVideoPlayerPresenter.this.rest_next_title_layout.setOnClickListener(new View.OnClickListener()
              {
                @Instrumented
                public void onClick(View paramView)
                {
                  VdsAgent.onClick(this, paramView);
                  EventBus.getDefault().post(new VideoPreviewEvent(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel));
                }
              });
              SptVideoPlayerPresenter.this.add_rest_icon.setOnClickListener(new View.OnClickListener()
              {
                @Instrumented
                public void onClick(View paramView)
                {
                  VdsAgent.onClick(this, paramView);
                  SptVideoPlayerPresenter.this.add_rest_icon.setVisibility(4);
                  SptVideoPlayerPresenter.this.add_rest_icon.setTag("is.add");
                  SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration = String.valueOf(20 + SptVideoPlayerPresenter.12.2.this.val$actionDuration);
                  SptVideoPlayerPresenter.access$302(SptVideoPlayerPresenter.this, 20 + SptVideoPlayerPresenter.this.startTime);
                  if (SptVideoPlayerPresenter.this.controller.pauseIcon.getTag() == null)
                  {
                    SptVideoPlayerPresenter.this.rest_time_tv.setTag("add.rest.time");
                    EventBus.getDefault().post("BaseSptVideoPlayerPresenter.pause");
                    new Handler().postDelayed(new Runnable()
                    {
                      public void run()
                      {
                        EventBus.getDefault().post("BaseSptVideoPlayerPresenter.play");
                      }
                    }
                    , 50L);
                    return;
                  }
                  SptVideoPlayerPresenter.this.rest_time_tv.setTag("pause.add.rest.time");
                }
              });
              return;
              SptVideoPlayerPresenter.this.restBackground.setImageResource(R.mipmap.drink);
            }
          }
        });
        SptVideoPlayerPresenter.this.subscription = Observable.interval(1L, TimeUnit.SECONDS).subscribe(new Action1(paramSubscriber)
        {
          public void call(Long paramLong)
          {
            if (SptVideoPlayerPresenter.this.isPause())
              return;
            int i = paramLong.intValue() + SptVideoPlayerPresenter.this.startTime;
            SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration = String.valueOf(i);
            if (i >= 1 + StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration))
            {
              SptVideoPlayerPresenter.this.unSubscription();
              SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getRestEndAudio(), new FitMediaPlayer.OnCompletionListener()
              {
                public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
                {
                  SptVideoPlayerPresenter.this.restFinishUI();
                  SptVideoPlayerPresenter.this.new_rest_base_layout.setVisibility(8);
                  SptVideoPlayerPresenter.12.3.this.val$subscriber.onCompleted();
                }
              });
              return;
            }
            if ((20 < StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration)) && (StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration) - i == 11))
              SptVideoPlayerPresenter.this.actionMediaPlayerHelper.playGuideAudio(NumberOffAudioUtils3.getReadyEncourage());
            ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable(i)
            {
              public void run()
              {
                if (this.val$time <= StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration))
                  SptVideoPlayerPresenter.this.rest_time_tv.setText(String.valueOf(StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration) - this.val$time));
              }
            });
          }
        });
      }
    });
  }

  public Observable playStageAudio()
  {
    unSubscription();
    totalTrainTimeSubscriptionStart();
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber paramSubscriber)
      {
        ((Activity)SptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable()
        {
          public void run()
          {
            SptVideoPlayerPresenter.this.blackLayout.setVisibility(0);
            SptVideoPlayerPresenter.this.nextAct.setText(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionName);
            SptVideoPlayerPresenter.this.nextAct.setVisibility(0);
            SptVideoPlayerPresenter.this.actTitleLayout.setVisibility(8);
            SptVideoPlayerPresenter.this.totalTrainTimeLayout.setVisibility(0);
          }
        });
        String str = NumberOffAudioUtils3.getStageSound(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentStageModel);
        SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(str, new FitMediaPlayer.OnCompletionListener(paramSubscriber)
        {
          public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
          {
            this.val$subscriber.onCompleted();
          }
        });
      }
    });
  }

  public Observable playToDayTrainStart()
  {
    totalTrainTimeSubscriptionStop();
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber paramSubscriber)
      {
        SptVideoPlayerPresenter.this.actTitleLayout.setVisibility(8);
        SptVideoPlayerPresenter.this.blackLayout.setVisibility(0);
        SptVideoPlayerPresenter.this.blackView.setVisibility(0);
        SptVideoPlayerPresenter.this.nextAct.setVisibility(0);
        SptVideoPlayerPresenter.this.nextAct.setText(R.string.e_1_1);
        SptVideoPlayerPresenter.this.countMediaPlayerHelper.playSound(NumberOffAudioUtils3.getReadyGo(), new FitMediaPlayer.OnCompletionListener(paramSubscriber)
        {
          public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
          {
            this.val$subscriber.onCompleted();
          }
        });
      }
    });
  }

  public Observable playToDayTrainStartCountDown()
  {
    totalTrainTimeSubscriptionStop();
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber paramSubscriber)
      {
        int i = StringUtils.string2Int(SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration);
        SptVideoPlayerPresenter.this.subscription = Observable.interval(1L, TimeUnit.SECONDS).onBackpressureBuffer().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1(i, paramSubscriber)
        {
          public void call(Long paramLong)
          {
            int i = this.val$startTime + paramLong.intValue();
            SptVideoPlayerPresenter.this.nextAct.setVisibility(8);
            if (i >= 3)
            {
              SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration = "";
              if ((SptVideoPlayerPresenter.this.videoView != null) && (SptVideoPlayerPresenter.this.videoView.isPlaying()))
                SptVideoPlayerPresenter.this.videoView.stopPlayback();
              SptVideoPlayerPresenter.this.unSubscription();
              SptVideoPlayerPresenter.this.hideActInfo();
              this.val$subscriber.onCompleted();
              return;
            }
            SptVideoPlayerPresenter.this.countMediaPlayerHelper.playCount(3 - i);
            if (SptVideoPlayerPresenter.this.countdown.getVisibility() == 8)
              SptVideoPlayerPresenter.this.countdown.setVisibility(0);
            if (SptVideoPlayerPresenter.this.isLandscape())
              SptVideoPlayerPresenter.this.countdown.setTextSize(100.0F);
            while (true)
            {
              SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration = String.valueOf(i + 1);
              LogUtils.d("trainDuration:", SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration);
              SptVideoPlayerPresenter.this.countdown.setText(String.valueOf(3 - i));
              SptVideoPlayerPresenter.this.countdown.clearAnimation();
              AnimationUtil.scaleAnim(SptVideoPlayerPresenter.this.countdown);
              return;
              SptVideoPlayerPresenter.this.countdown.setTextSize(60.0F);
            }
          }
        });
      }
    });
  }

  public void totalTime()
  {
    if (isPause())
      return;
    ActionModel localActionModel = this.video01Presenter.getTrainingReformer().currentActionModel;
    localActionModel.duration = (1.0F + localActionModel.duration);
    Long localLong = Long.valueOf(1L + getTotalTimeStartTime().longValue());
    if (localLong.longValue() == 120L)
      EventBus.getDefault().post("开始训练两分钟打点");
    ((Activity)this.context).runOnUiThread(new Runnable(localLong)
    {
      public void run()
      {
        if (this.val$time.longValue() >= 3600L)
          ((LinearLayout.LayoutParams)SptVideoPlayerPresenter.this.totalTrainTime.getLayoutParams()).weight = 1.5F;
        SptVideoPlayerPresenter.this.totalTrainTime.setText(StringUtils.timeLong2Str(this.val$time));
        SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().totTimeCount = this.val$time.floatValue();
        if ((SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentStageModel != null) && (SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentStageModel.isTrainStage()))
          SptVideoPlayerPresenter.this.video01Presenter.playProgressSound(SptVideoPlayerPresenter.this.context, SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer(), new Callback()
          {
            public void callback(String paramString)
            {
              SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().isPlayingProgressAudio = true;
              SptVideoPlayerPresenter.this.actionMediaPlayerHelper.playGuideAudio(paramString, new FitMediaPlayer.OnCompletionListener()
              {
                public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
                {
                  SptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().isPlayingProgressAudio = false;
                }
              });
            }
          });
      }
    });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.presenter.SptVideoPlayerPresenter
 * JD-Core Version:    0.6.0
 */