package com.sportq.fit.fitmoudle3.video.presenter;

import android.content.Context;
import android.graphics.Bitmap;
import com.google.gson.Gson;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.StageModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.reformer.BannerReformer;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.MD5Util;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.findpresenter.FindPresenter;
import com.sportq.fit.fitmoudle.compdevicemanager.SharePreferenceUtils2;
import com.sportq.fit.fitmoudle.event.NoPuchEvent;
import com.sportq.fit.fitmoudle.event.PubAddWeightEvent;
import com.sportq.fit.fitmoudle.network.data.CoursePhotoData;
import com.sportq.fit.fitmoudle3.video.reformer.PunchCardReformer;
import com.sportq.fit.middlelib.DexManager;
import com.sportq.fit.supportlib.http.reformer.AddLikeReformerImpl;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;
import com.tencent.bugly.crashreport.CrashReport;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import rx.Observable;
import rx.Subscriber;

public class Video02Presenter extends FindPresenter
{
  private PunchCardReformer punchCardReformer;
  private FitInterfaceUtils.UIInitListener view02;

  public Video02Presenter(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.view02 = paramUIInitListener;
    this.apiInterface = DexManager.getInstance().getApi();
  }

  public void addTrainPhoto(String paramString1, String paramString2, String paramString3, Context paramContext)
  {
  }

  public void delPlanReformerData(PlanReformer paramPlanReformer)
  {
    SharePreferenceUtils2.delLocalTrainDataPlanReformer(paramPlanReformer.startDate);
    com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.delAlbumCoursePhotoData(paramPlanReformer.startDate, BaseApplication.appliContext);
    EventBus.getDefault().post(new NoPuchEvent(NoPuchEvent.DELETDO));
    EventBus.getDefault().post(new NoPuchEvent(NoPuchEvent.SUCCED));
  }

  public void feedBackAct(Context paramContext, RequestModel paramRequestModel)
  {
    ReformerImpl localReformerImpl = new ReformerImpl(new AddLikeReformerImpl());
    String str = localReformerImpl.getURL(EnumConstant.FitUrl.FeedBackAct);
    localReformerImpl.getReformerInterface(EnumConstant.FitUrl.FeedBackAct);
    this.apiInterface.getHttp(str, paramContext, this.view02, localReformerImpl, paramRequestModel);
  }

  public String getFeelingCode()
  {
    if ((this.punchCardReformer == null) || (this.punchCardReformer.requestModel == null))
      return "";
    return this.punchCardReformer.requestModel.feelingCode;
  }

  public void getFinishData(PlanReformer paramPlanReformer, String paramString, Context paramContext)
    throws Exception
  {
    PlanModel localPlanModel1 = paramPlanReformer._individualInfo;
    paramPlanReformer.costCalorie = getTotalConsumeKaluri(paramPlanReformer.costTime, localPlanModel1);
    this.punchCardReformer = new PunchCardReformer();
    this.punchCardReformer.requestModel = new RequestModel();
    if (!com.sportq.fit.common.utils.StringUtils.isNull(paramString))
      this.punchCardReformer.requestModel.loseFatId = paramString;
    PlanModel localPlanModel2 = new PlanModel();
    String str1;
    if ("2".equals(paramPlanReformer._dataType))
    {
      localPlanModel2.planImageURL = localPlanModel1.planImageURL;
      this.punchCardReformer.requestModel.individualId = localPlanModel1.planId;
      localPlanModel2.planId = localPlanModel1.planId;
      localPlanModel2.planName = localPlanModel1.planName;
      localPlanModel2.finishSection = String.valueOf(1 + com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.string2Int(localPlanModel1.finishSection));
      RequestModel localRequestModel1 = this.punchCardReformer.requestModel;
      if (!com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.isNull(paramPlanReformer._customDetailId))
        break label372;
      str1 = "";
      label170: localRequestModel1.customDetailId = str1;
      RequestModel localRequestModel2 = this.punchCardReformer.requestModel;
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = Float.valueOf(paramPlanReformer.costCalorie);
      localRequestModel2.calorie = String.format("%.0f", arrayOfObject1);
      if ((com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.isNull(paramPlanReformer._customDetailId)) && (paramPlanReformer._planInfo == null))
        break label381;
    }
    String str2;
    ArrayList localArrayList;
    label372: label381: for (this.punchCardReformer.requestModel.isNeedJoin = "0"; ; this.punchCardReformer.requestModel.isNeedJoin = "1")
    {
      str2 = "";
      if (paramPlanReformer.mActionModelArrayList == null)
        break label715;
      localArrayList = new ArrayList();
      for (int i = 0; i < localPlanModel1.stageArray.size(); i++)
      {
        ((StageModel)localPlanModel1.stageArray.get(i)).duration = 0;
        ((StageModel)localPlanModel1.stageArray.get(i)).actionArray.clear();
        localArrayList.add(localPlanModel1.stageArray.get(i));
      }
      this.punchCardReformer.requestModel.planId = paramPlanReformer._planInfo.planId;
      localPlanModel2.planImageURL = paramPlanReformer._planInfo.planImageURL;
      break;
      str1 = paramPlanReformer._customDetailId;
      break label170;
    }
    localPlanModel1.stageArray.clear();
    Iterator localIterator = paramPlanReformer.mActionModelArrayList.iterator();
    int j = -1;
    if (localIterator.hasNext())
    {
      ActionModel localActionModel1 = (ActionModel)localIterator.next();
      ActionModel localActionModel2 = new ActionModel();
      StringBuilder localStringBuilder2 = new StringBuilder().append(localActionModel1.actionDuration);
      if (localActionModel1.isSecond());
      for (String str4 = "s"; ; str4 = "x")
      {
        localActionModel2.actionDuration = str4;
        localActionModel2.duration = localActionModel1.duration;
        localActionModel2.actionName = localActionModel1.actionName;
        localActionModel2.actionIndex = localActionModel1.actionIndex;
        localActionModel2.actionGroupIndex = localActionModel1.actionGroupIndex;
        localActionModel2.actionInGroupIndex = localActionModel1.actionInGroupIndex;
        localActionModel2.trainDuration = com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.timeFloat2Str(localActionModel1.duration);
        if ((!localActionModel1.isStage()) && (localActionModel2.duration > 0.0F) && (localArrayList.size() > localActionModel2.actionGroupIndex))
        {
          StageModel localStageModel = (StageModel)localArrayList.get(localActionModel2.actionGroupIndex);
          localStageModel.duration = (int)(localStageModel.duration + localActionModel2.duration);
          if (j != localActionModel2.actionGroupIndex)
          {
            j = localActionModel2.actionGroupIndex;
            localPlanModel1.stageArray.add(localStageModel);
          }
          ((StageModel)localPlanModel1.stageArray.get(-1 + localPlanModel1.stageArray.size())).actionArray.add(localActionModel2);
        }
        if (!com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.isNull(str2))
          break;
        str2 = localActionModel1.actionImageURL;
        localActionModel2.actionImageURL = str2;
        break;
      }
    }
    label715: this.punchCardReformer.requestModel.customDetailId = paramPlanReformer._customDetailId;
    String str3 = com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.compress(new JSONArray(new Gson().toJson(localPlanModel1.stageArray)).toString());
    this.punchCardReformer.requestModel.detailedData = str3;
    LogUtils.d("FindPresenter", "detailedData:" + this.punchCardReformer.requestModel.detailedData);
    this.punchCardReformer.requestModel.time = String.valueOf(paramPlanReformer.costTime);
    this.punchCardReformer.requestModel.moveTime = paramPlanReformer.startDate;
    StringBuilder localStringBuilder1 = new StringBuilder();
    localStringBuilder1.append(DateUtils.getCurDateTime());
    localStringBuilder1.append(",");
    localStringBuilder1.append(CompDeviceInfoUtils.getNetType());
    localStringBuilder1.append(",");
    localStringBuilder1.append("[FOLAPCMT]");
    localStringBuilder1.append(",");
    localStringBuilder1.append(BaseApplication.strAPIName);
    localStringBuilder1.append(",");
    localStringBuilder1.append("p.c.tan|!||!||!|");
    this.punchCardReformer.requestModel.keySign = MD5Util.MD5(BaseApplication.userModel.userId + this.punchCardReformer.requestModel.moveTime + NdkUtils.getSignBaseUrl());
    this.punchCardReformer.requestModel.folap1 = localStringBuilder1.toString();
    this.punchCardReformer.requestModel.folap2 = com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.getFixedField();
    localPlanModel2.stageArray = localPlanModel1.stageArray;
    localPlanModel2.planTrainDuration = com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.timeInt2Str(paramPlanReformer.costTime);
    Object[] arrayOfObject2 = new Object[1];
    arrayOfObject2[0] = Float.valueOf(paramPlanReformer.costCalorie);
    localPlanModel2.planKaluri = String.format("%.0f", arrayOfObject2);
    localPlanModel2.planState = localPlanModel1.planState;
    localPlanModel2.shareImgUrl = localPlanModel1.shareImgUrl;
    localPlanModel2.energyFlag = localPlanModel1.energyFlag;
    localPlanModel2.feelingCode = localPlanModel1.feelingCode;
    localPlanModel2.campFlag = localPlanModel1.campFlag;
    this.punchCardReformer.planModel = localPlanModel2;
    this.punchCardReformer.planReformer = paramPlanReformer;
    LogUtils.d("FindPresenter", "保存训练数据到本地");
    savePlanReformerData(this.punchCardReformer.planReformer);
    if (this.view02 != null)
      this.view02.getDataSuccess(localPlanModel2);
  }

  public void getMission(Context paramContext)
  {
  }

  public void getMissionDet(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public void getMissionPlan(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public void getPoster(Context paramContext)
  {
  }

  public void getRelatedCourses(String paramString, Context paramContext)
  {
  }

  public void getSystemTime(Context paramContext)
  {
  }

  public void getWinners(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public boolean gradeToast(Context paramContext)
  {
    return false;
  }

  public void gradeToastClick(Context paramContext, String paramString)
  {
  }

  public void joinMission(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public boolean noticeToast(Context paramContext)
  {
    return false;
  }

  public void noticeToastClick(Context paramContext)
  {
  }

  public void savePlanReformerData(PlanReformer paramPlanReformer)
  {
    paramPlanReformer.mActionModelArrayList = null;
    SharePreferenceUtils2.putLocalTrainDataPlanReformer(paramPlanReformer.startDate, paramPlanReformer);
  }

  public void setCoursePhotoData(CoursePhotoData paramCoursePhotoData)
  {
    RequestModel localRequestModel;
    if ((paramCoursePhotoData != null) && (this.punchCardReformer != null) && (this.punchCardReformer.requestModel != null))
    {
      if (!com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.isNull(paramCoursePhotoData.feeling))
        this.punchCardReformer.requestModel.comment = paramCoursePhotoData.feeling;
      if (!com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.isNull(paramCoursePhotoData.strImgPath))
        this.punchCardReformer.requestModel.imageURL = paramCoursePhotoData.strImgPath;
      if (!com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.isNull(paramCoursePhotoData.strImageType))
        this.punchCardReformer.requestModel.imageType = paramCoursePhotoData.strImageType;
      if (!com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.isNull(paramCoursePhotoData.bodyDirection))
      {
        localRequestModel = this.punchCardReformer.requestModel;
        if (!"-1".equals(paramCoursePhotoData.bodyDirection))
          break label157;
      }
    }
    label157: for (String str = "0"; ; str = "1")
    {
      localRequestModel.photoType = str;
      if (!com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.isNull(paramCoursePhotoData.currentWeight))
        this.punchCardReformer.requestModel.currentWeight = paramCoursePhotoData.currentWeight;
      return;
    }
  }

  public void setFeelingCode(String paramString)
  {
    if ((this.punchCardReformer != null) && (this.punchCardReformer.requestModel != null))
    {
      this.punchCardReformer.requestModel.feelingCode = paramString;
      this.punchCardReformer.planReformer._individualInfo.feelingCode = paramString;
      savePlanReformerData(this.punchCardReformer.planReformer);
    }
  }

  public void statsCustomizedExit(String paramString)
  {
  }

  public void statsPlanRelatedCoursesClick(String paramString)
  {
  }

  public void statsPlanRelatedCoursesClick02(String paramString)
  {
  }

  public void statsPublishFinishBtnClick(String paramString1, String paramString2)
  {
  }

  public void statsRecommendItemClick(String paramString)
  {
  }

  public void statsRelatedCoursesItemClick(String paramString)
  {
  }

  public void statsSaveLocalClick()
  {
  }

  public void statsSingleRelatedCoursesClick(String paramString)
  {
  }

  public void statsTakePhotoPermission(String paramString1, String paramString2)
  {
  }

  public void statsTrainFinishCameraClick(String paramString)
  {
  }

  public void statsTrainInfoImgClick(String paramString)
  {
  }

  public void statsTrainInfoMoreDeleteClick(String paramString)
  {
  }

  public void statsTrainRecordAlbumClick(String paramString)
  {
  }

  public void statsVideoDownLoadFinish(String paramString1, String paramString2, String paramString3)
  {
  }

  public void trainExistCause(Context paramContext, RequestModel paramRequestModel)
  {
    ReformerImpl localReformerImpl = new ReformerImpl(new AddLikeReformerImpl());
    String str = localReformerImpl.getURL(EnumConstant.FitUrl.ExitPlanReason);
    localReformerImpl.getReformerInterface(EnumConstant.FitUrl.ExitPlanReason);
    this.apiInterface.getHttp(str, paramContext, this.view02, localReformerImpl, paramRequestModel);
  }

  public void uploadData(Context paramContext)
  {
    if ((CompDeviceInfoUtils.checkNetwork()) && (this.punchCardReformer.requestModel != null))
    {
      Bitmap localBitmap = ImageUtils.getImageBitmap(this.punchCardReformer.requestModel.imageURL, 2);
      if (localBitmap != null)
        this.punchCardReformer.requestModel.imageURL = QiniuManager.uploadData(localBitmap);
      this.apiInterface.finishPlan(this.punchCardReformer.requestModel, paramContext).subscribe(new Subscriber()
      {
        public void onCompleted()
        {
        }

        public void onError(Throwable paramThrowable)
        {
          EventBus.getDefault().post(new NoPuchEvent(NoPuchEvent.DELETDO));
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = paramThrowable.getMessage();
          String str = String.format("finishPlan%s", arrayOfObject);
          if (Video02Presenter.this.view02 != null)
          {
            Video02Presenter.this.view02.getDataFail(str);
            CrashReport.postCatchedException(new Throwable("打卡失败：" + str));
          }
        }

        public void onNext(ResponseModel paramResponseModel)
        {
          BannerReformer localBannerReformer = new BannerReformer();
          Video02Presenter.this.delPlanReformerData(Video02Presenter.this.punchCardReformer.planReformer);
          if (Video02Presenter.this.view02 != null)
            Video02Presenter.this.view02.getDataSuccess(localBannerReformer);
          if ((!com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.isNull(Video02Presenter.this.punchCardReformer.requestModel.currentWeight)) && (Float.parseFloat(Video02Presenter.this.punchCardReformer.requestModel.currentWeight) > 0.0F))
            EventBus.getDefault().post(new PubAddWeightEvent(Float.parseFloat(Video02Presenter.this.punchCardReformer.requestModel.currentWeight), Video02Presenter.this.punchCardReformer.requestModel.moveTime));
        }
      });
    }
    String str;
    do
    {
      return;
      EventBus.getDefault().post(new NoPuchEvent(NoPuchEvent.DELETDO));
      str = String.format("finishPlan%s", new Object[] { "" });
    }
    while (this.view02 == null);
    this.view02.getDataFail(str);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.presenter.Video02Presenter
 * JD-Core Version:    0.6.0
 */