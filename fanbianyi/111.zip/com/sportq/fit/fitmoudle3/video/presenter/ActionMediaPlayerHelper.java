package com.sportq.fit.fitmoudle3.video.presenter;

import com.sportq.fit.common.interfaces.video.FitMediaPlayer;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnCompletionListener;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnPreparedListener;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.videopresenter.AndroidPlay;
import com.sportq.fit.videopresenter.event.ActionMediaPlayerVolumeChangeEvent;
import org.greenrobot.eventbus.EventBus;

public class ActionMediaPlayerHelper extends BaseMediaPlayerHelper
{
  public static final String EVENT_COMPLETION = "event.completion";
  public static final String EVENT_START = "event.start";
  private static final String TAG = ActionMediaPlayerHelper.class.getName();
  private static ActionMediaPlayerHelper instance;

  public ActionMediaPlayerHelper()
  {
    super("key_action_volume", true);
    this.mediaPlayer.setOnCompletionListener(new FitMediaPlayer.OnCompletionListener()
    {
      public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
      {
        EventBus.getDefault().post(new ActionMediaPlayerVolumeChangeEvent(false, ActionMediaPlayerHelper.this.volume));
        if (ActionMediaPlayerHelper.this.isPreview())
          ActionMediaPlayerHelper.this.isPreview = false;
        if (!ActionMediaPlayerHelper.this.isShouldPlay())
          return;
        ActionMediaPlayerHelper.this.completion();
      }
    });
    this.mediaPlayer.setOnPreparedListener(new FitMediaPlayer.OnPreparedListener()
    {
      public void onPrepared(FitMediaPlayer paramFitMediaPlayer)
      {
        EventBus.getDefault().post(new ActionMediaPlayerVolumeChangeEvent(true, ActionMediaPlayerHelper.this.volume));
        if ((!ActionMediaPlayerHelper.this.isShouldPlay()) && (!ActionMediaPlayerHelper.this.isPreview()))
          return;
        paramFitMediaPlayer.start();
        ActionMediaPlayerHelper.this.isPreview = false;
      }
    });
    setShouldPlay(true);
  }

  public static ActionMediaPlayerHelper getInstance()
  {
    if (instance == null)
      instance = new ActionMediaPlayerHelper();
    return instance;
  }

  public void destroy()
  {
    super.destroy();
    instance = null;
  }

  public void initAndPlay(String paramString)
  {
  }

  public void playDidi(int paramInt)
  {
  }

  public void playGuideAudio(String paramString)
  {
    LogUtils.d("播放指导语音", paramString);
    setDataAndPlay(paramString);
  }

  public void playGuideAudio(String paramString, FitMediaPlayer.OnCompletionListener paramOnCompletionListener)
  {
    this.onCompletionListener = paramOnCompletionListener;
    this.canComplete = true;
    setDataAndPlay(paramString);
  }

  public void setShouldPlay(boolean paramBoolean)
  {
    super.setShouldPlay(paramBoolean);
    if (paramBoolean)
    {
      setVolume(this.volume);
      return;
    }
    setMediaPlayerVolume(0.01F);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.presenter.ActionMediaPlayerHelper
 * JD-Core Version:    0.6.0
 */