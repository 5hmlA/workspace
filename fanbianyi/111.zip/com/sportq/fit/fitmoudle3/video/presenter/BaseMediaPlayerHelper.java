package com.sportq.fit.fitmoudle3.video.presenter;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.sound.SoundInterface;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnCompletionListener;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnPreparedListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.videopresenter.AndroidPlay;
import com.sportq.fit.videopresenter.VideoUtils;
import java.io.File;
import java.io.IOException;
import org.greenrobot.eventbus.EventBus;

public abstract class BaseMediaPlayerHelper
  implements SoundInterface
{
  public static final String EVENT_FILE_ERROR = "event.mediaplayer.error.unknow";
  private static final String TAG = BaseMediaPlayerHelper.class.getName();
  private final String TABLENAME = "tbl_volume_info";
  protected boolean canComplete = true;
  private boolean isPause = false;
  protected boolean isPreview = false;
  protected AndroidPlay mediaPlayer;
  protected FitMediaPlayer.OnCompletionListener onCompletionListener;
  protected boolean shouldPlay;
  protected float volume;
  private String volumeKey;

  public BaseMediaPlayerHelper(String paramString, boolean paramBoolean)
  {
    this.volumeKey = paramString;
    this.shouldPlay = paramBoolean;
    this.mediaPlayer = new AndroidPlay();
    this.mediaPlayer.setAudioStreamType(3);
    this.mediaPlayer.setOnCompletionListener(new FitMediaPlayer.OnCompletionListener()
    {
      public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
      {
        if (BaseMediaPlayerHelper.this.isPreview())
          BaseMediaPlayerHelper.this.isPreview = false;
        if (!BaseMediaPlayerHelper.this.isShouldPlay())
          return;
        BaseMediaPlayerHelper.this.completion();
      }
    });
    this.mediaPlayer.setOnPreparedListener(new FitMediaPlayer.OnPreparedListener()
    {
      public void onPrepared(FitMediaPlayer paramFitMediaPlayer)
      {
        if ((!BaseMediaPlayerHelper.this.isShouldPlay()) && (!BaseMediaPlayerHelper.this.isPreview()))
          return;
        paramFitMediaPlayer.start();
        BaseMediaPlayerHelper.this.isPreview = false;
      }
    });
    initVolume("tbl_volume_info", paramString);
  }

  private void initVolume(String paramString1, String paramString2)
  {
    this.volume = PreferencesTools.getFloatValueToKey(paramString1, paramString2);
    float f;
    if (this.volume == -1.0F)
      f = 0.8F;
    while (true)
    {
      this.volume = f;
      setVolume(this.volume);
      return;
      f = this.volume;
    }
  }

  private void setMediaDataInTry(String paramString)
    throws IOException
  {
    LogUtils.d("播放语音的url:", paramString);
    if (StringUtils.isNull(paramString))
      completion();
    while (true)
    {
      return;
      if ((paramString.startsWith("actionVoice")) || (paramString.startsWith("Sounds")) || (paramString.startsWith("Sounds/Encourage")) || (paramString.startsWith("Sounds/ProgressAudio")))
        break;
      if ((!CompDeviceInfoUtils.checkNetwork()) && (VideoUtils.isNetworkPath(paramString)))
        continue;
      this.mediaPlayer.setDataSource(paramString);
      return;
    }
    AssetFileDescriptor localAssetFileDescriptor = BaseApplication.appliContext.getAssets().openFd(getAssetUrl(paramString));
    this.mediaPlayer.setDataSource(localAssetFileDescriptor.getFileDescriptor(), localAssetFileDescriptor.getStartOffset(), localAssetFileDescriptor.getLength());
  }

  protected void completion()
  {
    if ((this.onCompletionListener != null) && (this.canComplete))
    {
      LogUtils.d(TAG, "执行completion方法");
      this.canComplete = false;
      this.onCompletionListener.onCompletion(this.mediaPlayer);
    }
  }

  public void destroy()
  {
    if (this.mediaPlayer != null)
    {
      this.mediaPlayer.release();
      this.mediaPlayer = null;
    }
  }

  public String getAssetUrl(String paramString)
  {
    if (paramString.contains(".mp3"))
    {
      LogUtils.d("CountMediaPlayerHelper.getAssetUrl：", paramString);
      return paramString;
    }
    return String.format("%s.mp3", new Object[] { paramString });
  }

  public float getVolume()
  {
    return this.volume;
  }

  public boolean isPause()
  {
    return this.isPause;
  }

  public boolean isPreview()
  {
    return this.isPreview;
  }

  public boolean isShouldPlay()
  {
    return (this.shouldPlay) && (!isPause());
  }

  public void pause()
  {
    this.isPause = true;
    if ((this.mediaPlayer == null) || (!this.mediaPlayer.isPlaying()))
      return;
    this.mediaPlayer.pause();
  }

  public void playCount(int paramInt)
  {
  }

  public void playFinish()
  {
  }

  public void playSound(String paramString)
  {
  }

  public void playSound(String paramString, FitMediaPlayer.OnCompletionListener paramOnCompletionListener)
  {
  }

  public void resetMediaPlayer()
  {
    this.mediaPlayer = null;
    this.mediaPlayer = new AndroidPlay();
    this.mediaPlayer.setAudioStreamType(3);
    setVolume(this.volume);
    this.mediaPlayer.setOnCompletionListener(new FitMediaPlayer.OnCompletionListener()
    {
      public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
      {
        if (BaseMediaPlayerHelper.this.isPreview())
          BaseMediaPlayerHelper.this.isPreview = false;
        if (!BaseMediaPlayerHelper.this.isShouldPlay())
          return;
        BaseMediaPlayerHelper.this.completion();
      }
    });
    this.mediaPlayer.setOnPreparedListener(new FitMediaPlayer.OnPreparedListener()
    {
      public void onPrepared(FitMediaPlayer paramFitMediaPlayer)
      {
        if ((!BaseMediaPlayerHelper.this.isShouldPlay()) && (!BaseMediaPlayerHelper.this.isPreview()))
          return;
        paramFitMediaPlayer.start();
        BaseMediaPlayerHelper.this.isPreview = false;
      }
    });
  }

  public void resume()
  {
    this.isPause = false;
    if (this.mediaPlayer == null)
      return;
    this.mediaPlayer.start();
  }

  public void setDataAndPlay(String paramString)
  {
    try
    {
      LogUtils.d("设置数据源并且播放", paramString);
      setDataSource(paramString);
      this.mediaPlayer.prepareAsync();
      return;
    }
    catch (IOException localIOException)
    {
      if ((!paramString.startsWith("actionVoice")) && (!paramString.startsWith("Sounds")) && (!paramString.startsWith("Sounds/Encourage")) && (!paramString.startsWith("Sounds/ProgressAudio")))
      {
        File localFile = new File(paramString);
        if (localFile.exists())
        {
          System.gc();
          localFile.delete();
        }
        EventBus.getDefault().post("event.mediaplayer.error.unknow");
      }
      LogUtils.e(localIOException);
      LogUtils.d("设置数据源并且播放error", paramString);
      resetMediaPlayer();
      completion();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      LogUtils.d("设置数据源并且播放error", paramString);
      resetMediaPlayer();
      completion();
    }
  }

  public void setDataSource(String paramString)
    throws IOException
  {
    this.mediaPlayer.reset();
    setMediaDataInTry(paramString);
  }

  public void setIsPause(boolean paramBoolean)
  {
    this.isPause = paramBoolean;
  }

  public void setMediaPlayerVolume(float paramFloat)
  {
    if (this.mediaPlayer != null)
      this.mediaPlayer.setVolume(paramFloat, paramFloat);
  }

  public void setPreview(boolean paramBoolean)
  {
    this.isPreview = paramBoolean;
  }

  public void setShouldPlay(boolean paramBoolean)
  {
    this.shouldPlay = paramBoolean;
  }

  public void setVolume(float paramFloat)
  {
    LogUtils.d("音量：", String.valueOf(paramFloat));
    this.volume = paramFloat;
    if (this.mediaPlayer != null)
      this.mediaPlayer.setVolume(this.volume, this.volume);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.presenter.BaseMediaPlayerHelper
 * JD-Core Version:    0.6.0
 */