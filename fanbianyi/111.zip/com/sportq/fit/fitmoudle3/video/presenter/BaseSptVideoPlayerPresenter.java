package com.sportq.fit.fitmoudle3.video.presenter;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v7.widget.AppCompatTextView;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.PageType;
import com.sportq.fit.common.interfaces.presenter.video.ISptVideoPlayer;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnErrorListener;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.glidecache.GlideApp;
import com.sportq.fit.common.utils.glidecache.GlideRequest;
import com.sportq.fit.common.utils.glidecache.GlideRequests;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.fitmoudle3.video.R.anim;
import com.sportq.fit.fitmoudle3.video.R.id;
import com.sportq.fit.fitmoudle3.video.R.string;
import com.sportq.fit.fitmoudle3.video.activity.Video01Activity;
import com.sportq.fit.fitmoudle3.video.datatransform.reformer.TrainingReformer;
import com.sportq.fit.fitmoudle3.video.interfaces.VideoInterface;
import com.sportq.fit.fitmoudle3.video.utils.SharePreferenceUtils3;
import com.sportq.fit.fitmoudle3.video.widget.CircleTextProgressbar;
import com.sportq.fit.fitmoudle3.video.widget.VideoPlayerProgressBar;
import com.sportq.fit.fitmoudle3.video.widget.videoplayer.MediaController;
import com.sportq.fit.fitmoudle3.video.widget.videoplayer.MediaController.MediaControllListener;
import com.sportq.fit.fitmoudle3.video.widget.videoplayer.MediaController.PlayState;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.videopresenter.SptVideoView;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import org.greenrobot.eventbus.EventBus;
import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action1;

public abstract class BaseSptVideoPlayerPresenter
  implements VideoInterface, ISptVideoPlayer, View.OnClickListener
{
  private static final int CONTROLLER_SHOW_TIME = 2000;
  public static final String EVENT_ADD_REST = "BaseSptVideoPlayerPresenter.add.rest";
  public static final String EVENT_LAST = "上一个动作";
  public static final String EVENT_NEXT = "下一个动作";
  public static final String EVENT_PAUSE = "BaseSptVideoPlayerPresenter.pause";
  public static final String EVENT_PLAY = "BaseSptVideoPlayerPresenter.play";
  public static final String EVENT_PREVIEW = "视频预览";
  public static final String EVENT_TRAIN_2_MINS = "开始训练两分钟打点";
  private static final String TAG = BaseSptVideoPlayerPresenter.class.getName();
  ImageView actInfoIcon;
  CustomTextView actTitle;
  LinearLayout actTitleLayout;
  CustomTextView actTrainTime;
  ActionMediaPlayerHelper actionMediaPlayerHelper;
  ImageView add_rest_icon;
  RelativeLayout blackLayout;
  View blackView;
  private RelativeLayout closeLayout;
  Context context;
  public MediaController controller;
  private Timer controllerHideTimer;
  CountMediaPlayerHelper countMediaPlayerHelper;
  CustomTextView countdown;
  int currentVideoPosition;
  boolean isBackCountDowning = false;
  LinearLayout leftBottomLayout;
  Subscription mCountSubscription;
  private EnumConstant.PageType mCurrPageType = EnumConstant.PageType.EXPAND;
  private View.OnTouchListener mOnTouchVideoListener = new View.OnTouchListener()
  {
    public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
    {
      if (paramMotionEvent.getAction() == 0)
      {
        BaseSptVideoPlayerPresenter.this.showOrHideController();
        BaseSptVideoPlayerPresenter.this.resetHideTimer();
      }
      return BaseSptVideoPlayerPresenter.this.mCurrPageType == EnumConstant.PageType.EXPAND;
    }
  };
  private VideoPlayCallbackImpl mVideoPlayCallback;
  private MediaController.MediaControllListener mediaControllListener = new MediaController.MediaControllListener()
  {
    public void hide()
    {
      BaseSptVideoPlayerPresenter.this.resetHideTimer();
    }

    public void last()
    {
      EventBus.getDefault().post("上一个动作");
    }

    public void next()
    {
      EventBus.getDefault().post("下一个动作");
    }

    public void onMediaCloseLayoutClick()
    {
      BaseSptVideoPlayerPresenter.this.closeLayout.callOnClick();
    }

    public void onPageTurn()
    {
      BaseSptVideoPlayerPresenter.this.mVideoPlayCallback.onSwitchPageType();
    }

    public void onPlayTurn()
    {
      BaseSptVideoPlayerPresenter.this.showOrHideController();
      if (MediaController.PlayState.PLAY.equals(BaseSptVideoPlayerPresenter.this.controller.getCurrentPlayState()))
      {
        EventBus.getDefault().post("BaseSptVideoPlayerPresenter.pause");
        return;
      }
      EventBus.getDefault().post("BaseSptVideoPlayerPresenter.play");
      BaseSptVideoPlayerPresenter.this.hideController();
    }

    public void volumeController()
    {
      BaseSptVideoPlayerPresenter.this.video01Presenter.showVolumeDialog();
    }
  };
  private ImageView muscle_img01;
  private ImageView muscle_img02;
  private ImageView muscle_img03;
  private LinearLayout muscle_item_linear02;
  public LinearLayout muscle_linear;
  RelativeLayout new_rest_base_layout;
  CustomTextView nextAct;
  private CustomTextView resetActTitle;
  private LinearLayout resetActTitleLayout;
  AppCompatTextView resetTitle;
  ImageView restBackground;
  TextView rest_hint_tv;
  CustomTextView rest_next_act_title;
  LinearLayout rest_next_title_layout;
  TextView rest_time_tv;
  CustomTextView singleActTime;
  Subscription subscription;
  CustomTextView totalTrainTime;
  private CustomTextView totalTrainTimeLabel;
  public LinearLayout totalTrainTimeLayout;
  private Subscription totalTrainTimeSubscription;
  private VideoPlayerProgressBar trainProgress;
  Video01Presenter video01Presenter;
  public CircleTextProgressbar videoPlayerBackProgress;
  public CustomTextView videoPlayerPreview;
  SptVideoView videoView;

  BaseSptVideoPlayerPresenter(Video01Activity paramVideo01Activity, View paramView, Video01Presenter paramVideo01Presenter)
  {
    this.video01Presenter = paramVideo01Presenter;
    this.context = paramVideo01Activity;
    this.countMediaPlayerHelper = CountMediaPlayerHelper.getInstance();
    this.actionMediaPlayerHelper = ActionMediaPlayerHelper.getInstance();
    initView(paramView);
    paramView.post(new Runnable(paramView)
    {
      public void run()
      {
        if (BaseSptVideoPlayerPresenter.this.videoView != null)
          BaseSptVideoPlayerPresenter.this.videoView.setCurrentSize(this.val$view.getWidth(), this.val$view.getHeight());
      }
    });
  }

  private void bindViews(View paramView)
  {
    this.videoView = ((SptVideoView)paramView.findViewById(R.id.video_view));
    this.blackView = paramView.findViewById(R.id.black_view);
    this.restBackground = ((ImageView)paramView.findViewById(R.id.rest_background));
    this.blackLayout = ((RelativeLayout)paramView.findViewById(R.id.black_layout));
    this.nextAct = ((CustomTextView)paramView.findViewById(R.id.next_act));
    this.resetTitle = ((AppCompatTextView)paramView.findViewById(R.id.reset_title));
    this.resetActTitleLayout = ((LinearLayout)paramView.findViewById(R.id.reset_act_title_layout));
    this.resetActTitle = ((CustomTextView)paramView.findViewById(R.id.reset_act_title));
    this.leftBottomLayout = ((LinearLayout)paramView.findViewById(R.id.left_bottom_layout));
    this.actTitleLayout = ((LinearLayout)paramView.findViewById(R.id.act_title_layout));
    this.actTitle = ((CustomTextView)paramView.findViewById(R.id.act_title));
    this.actInfoIcon = ((ImageView)paramView.findViewById(R.id.act_info_icon));
    this.videoPlayerPreview = ((CustomTextView)paramView.findViewById(R.id.video_player_preview));
    this.actTrainTime = ((CustomTextView)paramView.findViewById(R.id.act_train_time));
    this.singleActTime = ((CustomTextView)paramView.findViewById(R.id.single_act_time));
    this.singleActTime.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.totalTrainTimeLabel = ((CustomTextView)paramView.findViewById(R.id.total_train_time_label));
    this.totalTrainTimeLabel.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.totalTrainTime = ((CustomTextView)paramView.findViewById(R.id.total_train_time));
    this.totalTrainTime.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.totalTrainTimeLayout = ((LinearLayout)paramView.findViewById(R.id.total_train_time_layout));
    this.controller = ((MediaController)paramView.findViewById(R.id.controller));
    this.controller.initFeedbackView();
    this.countdown = ((CustomTextView)paramView.findViewById(R.id.countdown));
    this.countdown.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.videoPlayerBackProgress = ((CircleTextProgressbar)paramView.findViewById(R.id.video_player_back_progress));
    this.videoPlayerBackProgress.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.closeLayout = ((RelativeLayout)paramView.findViewById(R.id.close_layout));
    this.trainProgress = ((VideoPlayerProgressBar)paramView.findViewById(R.id.video_player_train_progress));
    this.trainProgress.setRectFs(this.video01Presenter.getTrainingReformer().proRatios);
    this.trainProgress.requestLayout();
    this.new_rest_base_layout = ((RelativeLayout)paramView.findViewById(R.id.new_rest_base_layout));
    this.rest_hint_tv = ((TextView)paramView.findViewById(R.id.rest_hint_tv));
    this.rest_time_tv = ((TextView)paramView.findViewById(R.id.rest_time_tv));
    this.rest_time_tv.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.add_rest_icon = ((ImageView)paramView.findViewById(R.id.add_rest_icon));
    this.rest_next_title_layout = ((LinearLayout)paramView.findViewById(R.id.rest_next_title_layout));
    this.rest_next_act_title = ((CustomTextView)paramView.findViewById(R.id.rest_next_act_title));
    this.muscle_item_linear02 = ((LinearLayout)paramView.findViewById(R.id.muscle_item_linear02));
    this.muscle_linear = ((LinearLayout)paramView.findViewById(R.id.muscle_linear));
    this.muscle_img01 = ((ImageView)paramView.findViewById(R.id.muscle_img01));
    this.muscle_img02 = ((ImageView)paramView.findViewById(R.id.muscle_img02));
    this.muscle_img03 = ((ImageView)paramView.findViewById(R.id.muscle_img03));
    this.muscle_linear.getLayoutParams().width = (int)(0.171875D * Math.max(BaseApplication.screenWidth, BaseApplication.screenHeight));
    this.muscle_img01.getLayoutParams().height = (Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight) / 2 - CompDeviceInfoUtils.convertOfDip(this.context, 27.5F));
    this.muscle_img01.getLayoutParams().width = (int)(this.muscle_img01.getLayoutParams().height / 0.6800000000000001D);
    this.muscle_img02.getLayoutParams().height = (Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight) / 2 - CompDeviceInfoUtils.convertOfDip(this.context, 27.5F));
    this.muscle_img02.getLayoutParams().width = (int)(this.muscle_img01.getLayoutParams().height / 0.6800000000000001D);
    ((LinearLayout.LayoutParams)this.muscle_img03.getLayoutParams()).topMargin = (int)(0.1971D * Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight));
    this.muscle_img03.getLayoutParams().height = (Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight) / 2 - CompDeviceInfoUtils.convertOfDip(this.context, 27.5F));
    this.muscle_img03.getLayoutParams().width = (int)(this.muscle_img03.getLayoutParams().height / 0.6800000000000001D);
    int i = (int)(0.2706D * this.muscle_img01.getLayoutParams().width);
    int j = (int)(0.724D * this.muscle_img02.getLayoutParams().width);
    int k = this.muscle_linear.getLayoutParams().width / 2;
    ((LinearLayout.LayoutParams)this.muscle_img01.getLayoutParams()).leftMargin = (k - i);
    ((LinearLayout.LayoutParams)this.muscle_img02.getLayoutParams()).leftMargin = (k - j);
    ((LinearLayout.LayoutParams)this.muscle_img03.getLayoutParams()).leftMargin = (k - (int)(0.5D * this.muscle_img03.getLayoutParams().width));
  }

  private void initData()
  {
    float f = this.video01Presenter.getTrainingReformer().totTimeCount;
    this.totalTrainTime.setText(StringUtils.timeFloat2Str(f));
  }

  private void initView(View paramView)
  {
    bindViews(paramView);
    initData();
    this.videoView.setOnTouchListener(this.mOnTouchVideoListener);
    this.videoView.setOnErrorListener(new FitMediaPlayer.OnErrorListener()
    {
      public boolean onError(FitMediaPlayer paramFitMediaPlayer, int paramInt1, int paramInt2)
      {
        paramFitMediaPlayer.reset();
        return false;
      }
    });
    this.closeLayout.setOnClickListener(this);
    this.controller.setMediaControllListener(this.mediaControllListener);
    new Handler().postDelayed(new Runnable()
    {
      public void run()
      {
        if (BaseSptVideoPlayerPresenter.this.controller.getVisibility() != 8)
        {
          BaseSptVideoPlayerPresenter.this.controller.startAnimation(AnimationUtils.loadAnimation(BaseSptVideoPlayerPresenter.this.context, R.anim.fade_out));
          BaseSptVideoPlayerPresenter.this.controller.setVisibility(8);
        }
      }
    }
    , 500L);
  }

  private boolean isControllerShowing()
  {
    return (this.controller != null) && (this.controller.getVisibility() == 0);
  }

  private void resetHideTimer()
  {
    if (!isControllerShowing())
      return;
    if (this.controllerHideTimer != null)
    {
      this.controllerHideTimer.cancel();
      this.controllerHideTimer = null;
    }
    this.controllerHideTimer = new Timer();
    this.controllerHideTimer.schedule(new TimerTask()
    {
      public void run()
      {
        new Handler(BaseSptVideoPlayerPresenter.this.context.getMainLooper()).post(new Runnable()
        {
          public void run()
          {
            if ((BaseSptVideoPlayerPresenter.this.controller.feed_back_base_layout.getVisibility() != 0) && (!"is.pause".equals(BaseSptVideoPlayerPresenter.this.controller.pauseIcon.getTag())))
              BaseSptVideoPlayerPresenter.this.hideController();
          }
        });
      }
    }
    , 2000L);
  }

  public void clearAddRestTime()
  {
    this.new_rest_base_layout.setVisibility(8);
    if (this.add_rest_icon.getTag() != null)
    {
      this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration = String.valueOf(-20 + StringUtils.string2Int(this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration));
      this.add_rest_icon.setTag(null);
    }
  }

  public Long getTotalTimeStartTime()
  {
    return StringUtils.timeStr2Long(this.totalTrainTime.getText().toString().trim());
  }

  public void hideActInfo()
  {
    LogUtils.d(TAG, "hideActInfo");
    ((Activity)this.context).runOnUiThread(new Runnable()
    {
      public void run()
      {
        BaseSptVideoPlayerPresenter.this.blackLayout.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.nextAct.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.countdown.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.resetTitle.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.actTrainTime.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.resetActTitleLayout.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.videoPlayerPreview.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.videoPlayerBackProgress.setVisibility(8);
      }
    });
  }

  void hideCenterView()
  {
    this.nextAct.setVisibility(8);
    this.countdown.setVisibility(8);
    this.resetTitle.setVisibility(8);
    this.resetActTitleLayout.setVisibility(8);
  }

  void hideController()
  {
    if (this.controller.getVisibility() != 8)
    {
      this.controller.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.fade_out));
      this.controller.setVisibility(8);
    }
  }

  public void init()
  {
    ((Activity)this.context).runOnUiThread(new Runnable()
    {
      public void run()
      {
        BaseSptVideoPlayerPresenter.this.actTrainTime.setText(BaseSptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionDuration);
        BaseSptVideoPlayerPresenter.this.actTitle.setText(BaseSptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.actionName);
        BaseSptVideoPlayerPresenter.this.actTitle.setVisibility(0);
      }
    });
    if (!this.video01Presenter.getTrainingReformer().currentActionModel.isRest())
      resetState();
    if (this.video01Presenter.isLandscape(this.context))
      this.actInfoIcon.setVisibility(0);
    this.controller.setPauseBtnClickable(true);
    this.controller.setPlayState(MediaController.PlayState.PLAY);
    this.actionMediaPlayerHelper.setIsPause(false);
    this.countMediaPlayerHelper.setIsPause(false);
    BgMusicMediaPlayerHelper.getInstance().setIsPause(false);
    this.controller.setLastActBtnTag(StringUtils.getStringResources(R.string.stats_e1_1_lastBtn));
    this.controller.setNextActBtnTag(StringUtils.getStringResources(R.string.stats_e1_1_nextBtn));
  }

  public boolean isLandscape()
  {
    return this.video01Presenter.isLandscape(this.context);
  }

  public boolean isPause()
  {
    return this.controller.getCurrentPlayState() == MediaController.PlayState.PAUSE;
  }

  boolean isTrainDurationEquals0()
  {
    return StringUtils.string2Int(this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration) == 0;
  }

  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    int i = paramView.getId();
    if (i == R.id.close_layout)
    {
      FitAction.temporaryPCC(this.context.getResources().getString(R.string.stats_e1_1_exitBtn));
      this.video01Presenter.showCloseDialog();
    }
    do
      return;
    while (i != R.id.left_bottom_layout);
    EventBus.getDefault().post("视频预览");
  }

  public void onPageTurn(EnumConstant.PageType paramPageType, TrainingReformer paramTrainingReformer)
  {
    this.controller.setPageType(paramPageType);
    if (EnumConstant.PageType.EXPAND == paramPageType)
    {
      this.nextAct.setTextSize(50.0F);
      this.videoPlayerPreview.setTextSize(28.0F);
      this.videoPlayerPreview.setPadding(CompDeviceInfoUtils.convertOfDip(this.context, 20.0F), 0, 0, CompDeviceInfoUtils.convertOfDip(this.context, 41.0F));
      this.singleActTime.setTextSize(38.0F);
      this.singleActTime.setPadding(CompDeviceInfoUtils.convertOfDip(this.context, 20.0F), 0, 0, CompDeviceInfoUtils.convertOfDip(this.context, 41.0F));
      if (this.actTrainTime.getVisibility() == 0)
      {
        this.singleActTime.setVisibility(0);
        this.singleActTime.setText(this.video01Presenter.getActionTimeStr(this.context, "0"));
      }
      this.actTrainTime.setVisibility(8);
      this.totalTrainTime.setTextSize(19.0F);
      this.totalTrainTimeLabel.setTextSize(16.0F);
      LinearLayout.LayoutParams localLayoutParams3 = (LinearLayout.LayoutParams)this.totalTrainTimeLabel.getLayoutParams();
      localLayoutParams3.topMargin = CompDeviceInfoUtils.convertOfDip(this.context, -1.5F);
      this.totalTrainTimeLabel.setLayoutParams(localLayoutParams3);
      this.totalTrainTimeLayout.setMinimumWidth(CompDeviceInfoUtils.convertOfDip(this.context, 195.0F));
      RelativeLayout.LayoutParams localLayoutParams4 = (RelativeLayout.LayoutParams)this.videoPlayerBackProgress.getLayoutParams();
      localLayoutParams4.width = CompDeviceInfoUtils.convertOfDip(this.context, 102.0F);
      localLayoutParams4.height = CompDeviceInfoUtils.convertOfDip(this.context, 102.0F);
      this.videoPlayerBackProgress.setLayoutParams(localLayoutParams4);
      this.videoPlayerBackProgress.setTextSize(40.0F);
      if (this.video01Presenter.getTrainingReformer().currentPlayStage == 5)
      {
        this.actTitle.setText("");
        this.resetTitle.setTextSize(50.0F);
        if (this.video01Presenter.getTrainingReformer().currentPlayStage == 5)
          this.resetActTitleLayout.setVisibility(0);
        if (this.video01Presenter.getTrainingReformer().currentPlayStage != 7)
          this.actTitleLayout.setVisibility(0);
        this.leftBottomLayout.setVisibility(0);
        this.leftBottomLayout.setOnClickListener(this);
        this.closeLayout.setVisibility(8);
        this.rest_hint_tv.setTextSize(24.0F);
        this.rest_time_tv.setTextSize(100.0F);
        this.add_rest_icon.getLayoutParams().width = CompDeviceInfoUtils.convertOfDip(this.context, 55.0F);
        this.add_rest_icon.getLayoutParams().height = CompDeviceInfoUtils.convertOfDip(this.context, 30.0F);
        this.rest_next_title_layout.setVisibility(0);
        this.controller.setTopRightOperateIconSize(1);
        showMuscleUI(false);
      }
    }
    while (true)
    {
      this.videoPlayerBackProgress.requestLayout();
      return;
      this.actTitle.setVisibility(0);
      this.actTitle.setText(this.video01Presenter.getTrainingReformer().currentActionModel.actionName);
      break;
      this.nextAct.setTextSize(28.0F);
      this.videoPlayerPreview.setTextSize(20.0F);
      this.videoPlayerPreview.setPadding(CompDeviceInfoUtils.convertOfDip(this.context, 11.0F), 0, 0, CompDeviceInfoUtils.convertOfDip(this.context, 9.0F));
      this.singleActTime.setTextSize(28.0F);
      this.singleActTime.setPadding(CompDeviceInfoUtils.convertOfDip(this.context, 10.0F), 0, 0, CompDeviceInfoUtils.convertOfDip(this.context, 12.0F));
      this.actTrainTime.setTextSize(28.0F);
      this.actTrainTime.setPadding(CompDeviceInfoUtils.convertOfDip(this.context, 11.0F), 0, 0, CompDeviceInfoUtils.convertOfDip(this.context, 9.0F));
      this.totalTrainTime.setTextSize(12.0F);
      this.totalTrainTimeLabel.setTextSize(12.0F);
      LinearLayout.LayoutParams localLayoutParams1 = (LinearLayout.LayoutParams)this.totalTrainTimeLabel.getLayoutParams();
      localLayoutParams1.topMargin = CompDeviceInfoUtils.convertOfDip(this.context, -1.0F);
      this.totalTrainTimeLabel.setLayoutParams(localLayoutParams1);
      this.totalTrainTimeLayout.setMinimumWidth(CompDeviceInfoUtils.convertOfDip(this.context, 120.0F));
      RelativeLayout.LayoutParams localLayoutParams2 = (RelativeLayout.LayoutParams)this.videoPlayerBackProgress.getLayoutParams();
      localLayoutParams2.width = CompDeviceInfoUtils.convertOfDip(this.context, 68.0F);
      localLayoutParams2.height = CompDeviceInfoUtils.convertOfDip(this.context, 68.0F);
      this.videoPlayerBackProgress.setLayoutParams(localLayoutParams2);
      this.videoPlayerBackProgress.setTextSize(28.0F);
      this.resetTitle.setTextSize(28.0F);
      this.resetActTitleLayout.setVisibility(8);
      this.actTitleLayout.setVisibility(8);
      this.leftBottomLayout.setVisibility(8);
      this.closeLayout.setVisibility(0);
      this.rest_hint_tv.setTextSize(16.0F);
      this.rest_time_tv.setTextSize(65.0F);
      this.add_rest_icon.getLayoutParams().width = CompDeviceInfoUtils.convertOfDip(this.context, 45.0F);
      this.add_rest_icon.getLayoutParams().height = CompDeviceInfoUtils.convertOfDip(this.context, 25.0F);
      this.rest_next_title_layout.setVisibility(8);
      this.controller.setTopRightOperateIconSize(0);
      this.muscle_linear.setVisibility(8);
    }
  }

  public void onPause()
  {
    if (!isPause())
    {
      this.currentVideoPosition = this.videoView.getCurrentPosition();
      this.videoView.pause();
    }
    this.videoPlayerBackProgress.stop();
    unSubscription();
    totalTrainTimeSubscriptionStop();
    this.countMediaPlayerHelper.pause();
    this.actionMediaPlayerHelper.pause();
  }

  public void pause()
  {
    onPause();
    this.controller.setPlayState(MediaController.PlayState.PAUSE);
    if (this.add_rest_icon.getTag() == null)
      showOrHideController();
  }

  public void play()
  {
    this.videoView.start();
    this.countMediaPlayerHelper.resume();
    this.actionMediaPlayerHelper.resume();
  }

  public void resetState()
  {
    ((Activity)this.context).runOnUiThread(new Runnable()
    {
      public void run()
      {
        BaseSptVideoPlayerPresenter.this.singleActTime.setText("");
        BaseSptVideoPlayerPresenter.this.countdown.setText("");
        BaseSptVideoPlayerPresenter.this.actTrainTime.setText("");
        BaseSptVideoPlayerPresenter.this.restBackground.setVisibility(8);
      }
    });
    this.isBackCountDowning = false;
    hideActInfo();
    unSubscription();
    this.currentVideoPosition = 0;
    this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration = "";
    this.controller.setPlayState(MediaController.PlayState.PLAY);
    this.videoPlayerBackProgress.stop();
    LogUtils.d(TAG, "执行resetState");
  }

  void restFinishUI()
  {
    ((Activity)this.context).runOnUiThread(new Runnable()
    {
      public void run()
      {
        BaseSptVideoPlayerPresenter.this.clearAddRestTime();
        BaseSptVideoPlayerPresenter.this.video01Presenter.getTrainingReformer().currentActionModel.trainDuration = "";
        BaseSptVideoPlayerPresenter.this.restBackground.setVisibility(0);
        BaseSptVideoPlayerPresenter.this.resetActTitleLayout.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.resetTitle.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.resetActTitle.setVisibility(8);
        BaseSptVideoPlayerPresenter.this.actInfoIcon.setVisibility(0);
        BaseSptVideoPlayerPresenter.this.leftBottomLayout.setOnClickListener(BaseSptVideoPlayerPresenter.this);
      }
    });
  }

  public Observable resume()
  {
    if (this.video01Presenter.getTrainingReformer().isDialogShowing)
      return Observable.create(new Observable.OnSubscribe()
      {
        public void call(Subscriber paramSubscriber)
        {
        }
      });
    this.countMediaPlayerHelper.setIsPause(false);
    this.actionMediaPlayerHelper.setIsPause(false);
    return backCountDown();
  }

  void scaleAnimation(View paramView)
  {
    ScaleAnimation localScaleAnimation = new ScaleAnimation(2.0F, 1.0F, 2.0F, 1.0F, 1, 0.5F, 1, 0.5F);
    localScaleAnimation.setInterpolator(new AccelerateInterpolator());
    localScaleAnimation.setDuration(300L);
    paramView.startAnimation(localScaleAnimation);
  }

  public void setActionVolume(float paramFloat)
  {
    this.actionMediaPlayerHelper.setVolume(paramFloat);
  }

  public void setCountVolume(float paramFloat)
  {
    this.countMediaPlayerHelper.setVolume(paramFloat);
  }

  public void setCurrentActionProgress(int paramInt)
  {
    LogUtils.d(SptVideoPlayerPresenter.class.getSimpleName(), "progress:" + paramInt);
    this.trainProgress.setProgress(paramInt);
  }

  void setMediaPlayerHelperShouldPlay(boolean paramBoolean)
  {
    this.countMediaPlayerHelper.setShouldPlay(paramBoolean);
    this.actionMediaPlayerHelper.setShouldPlay(paramBoolean);
  }

  public void setPageType(EnumConstant.PageType paramPageType, TrainingReformer paramTrainingReformer)
  {
    this.controller.setPageType(paramPageType);
    this.mCurrPageType = paramPageType;
    onPageTurn(paramPageType, paramTrainingReformer);
  }

  public void setSecondProgress(int paramInt)
  {
    this.trainProgress.setSecondaryProgress(paramInt);
  }

  public void setTrainProgressTotalTime()
  {
    LogUtils.d(SptVideoPlayerPresenter.class.getSimpleName(), "progressMax:" + (int)this.video01Presenter.getTrainingReformer().progressMax);
    this.trainProgress.setMax((int)this.video01Presenter.getTrainingReformer().progressMax);
  }

  public void setmVideoPlayCallback(VideoPlayCallbackImpl paramVideoPlayCallbackImpl)
  {
    this.mVideoPlayCallback = paramVideoPlayCallbackImpl;
  }

  public void showMuscleUI(boolean paramBoolean)
  {
    if ((!StringUtils.isNull(this.video01Presenter.getTrainingReformer().currentActionModel.muscleImage)) && (this.videoPlayerPreview.getVisibility() == 0) && (SharePreferenceUtils3.getMuscleIsOpen(this.context)) && (this.muscle_linear.getVisibility() != 0) && ((CompDeviceInfoUtils.checkNetwork()) || (GlideUtils.getCacheFile(this.video01Presenter.getTrainingReformer().currentActionModel.muscleImage) != null)))
    {
      if (paramBoolean)
      {
        Animation localAnimation = AnimationUtils.loadAnimation(this.context, R.anim.sideslip_show);
        this.muscle_linear.startAnimation(localAnimation);
      }
      this.muscle_linear.setVisibility(0);
      if (!"1".equals(this.video01Presenter.getTrainingReformer().currentActionModel.isWholeBody))
        break label232;
      this.muscle_img01.setVisibility(8);
      this.muscle_img02.setVisibility(8);
      this.muscle_item_linear02.setVisibility(0);
      GlideApp.with(this.context).asBitmap().load(this.video01Presenter.getTrainingReformer().currentActionModel.muscleImage).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(this.muscle_img03);
    }
    while (true)
    {
      if (this.totalTrainTimeLayout.getVisibility() == 0)
      {
        this.totalTrainTimeLayout.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.fade_out));
        this.totalTrainTimeLayout.setVisibility(8);
      }
      return;
      label232: this.muscle_img01.setVisibility(0);
      this.muscle_img02.setVisibility(0);
      this.muscle_item_linear02.setVisibility(8);
      GlideApp.with(this.context).asBitmap().load(this.video01Presenter.getTrainingReformer().currentActionModel.muscleImage).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(this.muscle_img01);
      GlideApp.with(this.context).asBitmap().load(this.video01Presenter.getTrainingReformer().currentActionModel.muscleImage).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(this.muscle_img02);
    }
  }

  void showOrHideController()
  {
    if (this.controller.getVisibility() == 0)
    {
      new Handler().postDelayed(new Runnable()
      {
        public void run()
        {
          if ((BaseSptVideoPlayerPresenter.this.controller.feed_back_base_layout.getVisibility() != 0) && (!"is.pause".equals(BaseSptVideoPlayerPresenter.this.controller.pauseIcon.getTag())) && (BaseSptVideoPlayerPresenter.this.controller.getVisibility() != 8))
          {
            BaseSptVideoPlayerPresenter.this.controller.startAnimation(AnimationUtils.loadAnimation(BaseSptVideoPlayerPresenter.this.context, R.anim.fade_out));
            BaseSptVideoPlayerPresenter.this.controller.setVisibility(8);
          }
        }
      }
      , 10L);
      return;
    }
    this.controller.setVisibility(0);
    this.controller.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.fade_in));
  }

  public void stop()
  {
    this.videoView.stopPlayback();
    this.countMediaPlayerHelper.destroy();
    this.actionMediaPlayerHelper.destroy();
  }

  public void totalTrainTimeSubscriptionStart()
  {
    totalTrainTimeSubscriptionStop();
    this.totalTrainTimeSubscription = Observable.interval(1L, TimeUnit.SECONDS).subscribe(new Action1()
    {
      public void call(Long paramLong)
      {
        ((Activity)BaseSptVideoPlayerPresenter.this.context).runOnUiThread(new Runnable(paramLong)
        {
          public void run()
          {
            LogUtils.d("BaseSptVideoPlayerPresenter->totalTrainTimeSubscriptionStart->", String.valueOf(this.val$aLong));
            BaseSptVideoPlayerPresenter.this.totalTime();
          }
        });
      }
    });
  }

  void totalTrainTimeSubscriptionStop()
  {
    if ((this.totalTrainTimeSubscription != null) && (!this.totalTrainTimeSubscription.isUnsubscribed()))
      this.totalTrainTimeSubscription.unsubscribe();
    this.totalTrainTimeSubscription = null;
  }

  public void unSubscription()
  {
    if ((this.subscription != null) && (!this.subscription.isUnsubscribed()))
    {
      this.subscription.unsubscribe();
      this.subscription = null;
    }
    if ((this.mCountSubscription != null) && (!this.mCountSubscription.isUnsubscribed()))
    {
      this.mCountSubscription.unsubscribe();
      this.mCountSubscription = null;
    }
  }

  void updateProgressWithTrain()
  {
    if (!this.video01Presenter.getTrainingReformer().currentActionModel.isRest())
      setCurrentActionProgress(this.trainProgress.getProgress() + this.video01Presenter.getTrainingReformer().perSecondProgress);
  }

  public static abstract interface VideoPlayCallbackImpl
  {
    public abstract void onSwitchPageType();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.presenter.BaseSptVideoPlayerPresenter
 * JD-Core Version:    0.6.0
 */