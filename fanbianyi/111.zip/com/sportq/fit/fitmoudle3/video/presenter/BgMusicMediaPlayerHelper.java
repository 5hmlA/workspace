package com.sportq.fit.fitmoudle3.video.presenter;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnCompletionListener;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnErrorListener;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnPreparedListener;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.videopresenter.AndroidPlay;
import java.io.File;
import java.io.IOException;
import org.greenrobot.eventbus.EventBus;

public class BgMusicMediaPlayerHelper extends BaseMediaPlayerHelper
{
  private static BgMusicMediaPlayerHelper instance;
  private String mUrl;

  public BgMusicMediaPlayerHelper()
  {
    super("key_music_volume", true);
    this.mediaPlayer.setOnErrorListener(new FitMediaPlayer.OnErrorListener()
    {
      public boolean onError(FitMediaPlayer paramFitMediaPlayer, int paramInt1, int paramInt2)
      {
        if (paramInt1 == 1);
        try
        {
          File localFile = new File(BgMusicMediaPlayerHelper.this.mUrl);
          if (localFile.exists())
          {
            System.gc();
            localFile.delete();
          }
          EventBus.getDefault().post("event.mediaplayer.error.unknow");
          return false;
        }
        catch (Exception localException)
        {
          while (true)
            LogUtils.e(localException);
        }
      }
    });
  }

  public static BgMusicMediaPlayerHelper getInstance()
  {
    if (instance == null)
      instance = new BgMusicMediaPlayerHelper();
    return instance;
  }

  private void playBgMusic()
  {
    this.mediaPlayer.reset();
    this.mediaPlayer.setLooping(false);
    try
    {
      setBgMusicAndStart();
      return;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  private void setBgMusicAndStart()
    throws IOException
  {
    if (StringUtils.isNull(this.mUrl))
      return;
    this.mediaPlayer.reset();
    try
    {
      this.mediaPlayer.setDataSource(this.mUrl);
      this.mediaPlayer.setVolume(this.volume, this.volume);
      this.mediaPlayer.prepareAsync();
      this.mediaPlayer.setOnPreparedListener(new FitMediaPlayer.OnPreparedListener()
      {
        public void onPrepared(FitMediaPlayer paramFitMediaPlayer)
        {
          if (!BgMusicMediaPlayerHelper.this.isShouldPlay())
            return;
          BgMusicMediaPlayerHelper.this.mediaPlayer.setVolume(BgMusicMediaPlayerHelper.this.volume, BgMusicMediaPlayerHelper.this.volume);
          BgMusicMediaPlayerHelper.this.mediaPlayer.start();
          BgMusicMediaPlayerHelper.this.mediaPlayer.seekTo(0L);
        }
      });
      this.mediaPlayer.setOnCompletionListener(new FitMediaPlayer.OnCompletionListener()
      {
        public void onCompletion(FitMediaPlayer paramFitMediaPlayer)
        {
          BgMusicMediaPlayerHelper.this.mediaPlayer.seekTo(0L);
        }
      });
      return;
    }
    catch (IllegalStateException localIllegalStateException)
    {
      this.mediaPlayer = null;
      this.mediaPlayer = new AndroidPlay();
      this.mediaPlayer.reset();
      this.mediaPlayer.setVolume(this.volume, this.volume);
      try
      {
        this.mediaPlayer.setDataSource(this.mUrl);
        return;
      }
      catch (IOException localIOException)
      {
        LogUtils.e(localIllegalStateException);
      }
    }
  }

  public void destroy()
  {
    super.destroy();
    instance = null;
  }

  public String getAssetUrl(String paramString)
  {
    LogUtils.d("背景音乐url", paramString);
    return String.format("%S/%s.mp3", new Object[] { "Sounds", paramString });
  }

  public void initAndPlay(String paramString)
  {
    LogUtils.d("BgMusicMediaPlayerHelper", "初始化背景音乐播放器:" + this.mUrl);
    if (StringUtils.isNull(paramString))
      return;
    try
    {
      this.mUrl = paramString;
      this.mediaPlayer.reset();
      this.mediaPlayer.setLooping(true);
      if (StringUtils.isNull(this.mUrl))
      {
        AssetManager localAssetManager = BaseApplication.appliContext.getAssets();
        this.mediaPlayer.setDataSource(localAssetManager.openFd(getAssetUrl("03- Gym-1.mp3")).getFileDescriptor());
      }
      while (true)
      {
        this.mediaPlayer.setOnErrorListener(new FitMediaPlayer.OnErrorListener()
        {
          public boolean onError(FitMediaPlayer paramFitMediaPlayer, int paramInt1, int paramInt2)
          {
            BgMusicMediaPlayerHelper.this.mediaPlayer.reset();
            return false;
          }
        });
        this.mediaPlayer.prepareAsync();
        return;
        this.mediaPlayer.setDataSource(this.mUrl);
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      this.mediaPlayer = null;
      this.mediaPlayer = new AndroidPlay();
      this.mediaPlayer.reset();
      this.mediaPlayer.setVolume(this.volume, this.volume);
      try
      {
        this.mediaPlayer.setDataSource(this.mUrl);
        return;
      }
      catch (IOException localIOException)
      {
        LogUtils.e(localException);
      }
    }
  }

  public void pause()
  {
    super.pause();
  }

  public void playDidi(int paramInt)
  {
  }

  public void playGuideAudio(String paramString)
  {
  }

  public void playGuideAudio(String paramString, FitMediaPlayer.OnCompletionListener paramOnCompletionListener)
  {
  }

  public void resume()
  {
    super.resume();
  }

  public void setShouldPlay(boolean paramBoolean)
  {
    if (paramBoolean == this.shouldPlay)
      return;
    super.setShouldPlay(paramBoolean);
    if (paramBoolean)
    {
      playBgMusic();
      return;
    }
    this.mediaPlayer.reset();
  }

  public void setVolume(float paramFloat)
  {
    super.setVolume(paramFloat);
    LogUtils.d("背景音乐url", "音量：" + this.volume);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.presenter.BgMusicMediaPlayerHelper
 * JD-Core Version:    0.6.0
 */