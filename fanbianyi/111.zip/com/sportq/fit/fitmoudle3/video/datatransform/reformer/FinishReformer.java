package com.sportq.fit.fitmoudle3.video.datatransform.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.StageModel;
import java.util.ArrayList;
import java.util.Iterator;

public class FinishReformer extends BaseReformer
{
  private ArrayList<Object> actionDatas = new ArrayList();

  public void dataToReformer(PlanModel paramPlanModel)
  {
    if (paramPlanModel == null);
    while (true)
    {
      return;
      if (paramPlanModel.stageArray == null)
        continue;
      Iterator localIterator = paramPlanModel.stageArray.iterator();
      while (localIterator.hasNext())
      {
        StageModel localStageModel = (StageModel)localIterator.next();
        this.actionDatas.add(localStageModel);
        this.actionDatas.addAll(localStageModel.actionArray);
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.datatransform.reformer.FinishReformer
 * JD-Core Version:    0.6.0
 */