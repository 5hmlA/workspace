package com.sportq.fit.fitmoudle3.video.datatransform.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.StageModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle3.video.common.TrainVideoDownLoadTool;
import com.sportq.fit.fitmoudle3.video.utils.FileUtils3;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TrainingReformer extends BaseReformer
  implements Serializable
{
  public int actIndexType;
  public float actTotTime;
  public List<String> actionGuideVoice;
  public String actionLocalVideoUrl;
  public ArrayList<ActionModel> actionModels;
  public String actionNetVideoUrl;
  public int actionNumber;
  public String actionVoiceURL;
  public boolean autorotateFlg;
  public ArrayList<File> bgMusicList;
  public boolean btnsHideEnable;
  public boolean clearFlg;
  public int curActNum;
  public int curGrpIndex;
  public int curIndex;
  public float curTimeCount;
  public ActionModel currentActionModel;
  public String currentBgMShowName;
  public String currentBgUrl;
  public int currentPlayStage = 0;
  public StageModel currentStageModel;
  public String defaultBgMName;
  public String defaultBgUrl;
  public boolean endingCountDown;
  public boolean isBackCountDowning = false;
  public boolean isDialogShowing = false;
  public boolean isPlayingProgressAudio = false;
  public boolean isPlayingTipsAudio = false;
  public float lastBtnAlpha;
  public int leftActCount;
  public boolean needWillEndAudio;
  public float nextBtnAlpha;
  public String olapInfo;
  public float oneTimeActionTime;
  public int perSecondProgress;
  public boolean playStageChangeAd;
  public boolean playedProgressAudio = false;
  public ArrayList<Float> proRatios;
  public float progressMax;
  public int selectBgIndex;
  public ArrayList<StageModel> stageArr;
  public String startDate;
  public ArrayList<Integer> timingA;
  public int tipsSoundCount;
  public float totTimeCount;
  public float trainDuration;

  private ArrayList<Float> getProgressRatio(float paramFloat, ArrayList<ActionModel> paramArrayList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
    {
      ActionModel localActionModel = (ActionModel)localIterator.next();
      if (localActionModel.isRest())
        continue;
      if (localActionModel.isSecond())
      {
        localArrayList.add(Float.valueOf(Float.valueOf(localActionModel.actionDuration).floatValue() / paramFloat));
        continue;
      }
      localArrayList.add(Float.valueOf(Float.valueOf(localActionModel.videoTime).floatValue() / 4.0F * StringUtils.string2Int(localActionModel.actionDuration) / paramFloat));
    }
    return localArrayList;
  }

  private int getSelectedIndex()
  {
    Iterator localIterator = this.bgMusicList.iterator();
    while (localIterator.hasNext())
    {
      File localFile = (File)localIterator.next();
      if (localFile.getAbsolutePath().equals(this.currentBgUrl))
        return this.bgMusicList.indexOf(localFile);
    }
    return -1;
  }

  public void planReformerToTrainingReformer(PlanReformer paramPlanReformer)
  {
    this.startDate = "";
    this.stageArr = paramPlanReformer._individualInfo.stageArray;
    this.actionModels = paramPlanReformer.mActionModelArrayList;
    this.olapInfo = paramPlanReformer._individualInfo.olapInfo;
    this.progressMax = paramPlanReformer.progressMax;
    if (!StringUtils.isNull(paramPlanReformer._individualInfo.actionNum))
      this.actionNumber = Integer.parseInt(paramPlanReformer._individualInfo.actionNum);
    if (!StringUtils.isNull(paramPlanReformer._individualInfo.duration))
      this.trainDuration = Float.valueOf(paramPlanReformer._individualInfo.duration).floatValue();
    this.proRatios = getProgressRatio(paramPlanReformer.progressMax, this.actionModels);
    this.defaultBgMName = paramPlanReformer._individualInfo.musicName;
    String str = TrainVideoDownLoadTool.getAlbumTrainPath(paramPlanReformer._individualInfo.bgmUrl);
    if (StringUtils.isNull(str))
      str = paramPlanReformer._individualInfo.bgmUrl;
    this.defaultBgUrl = str;
    this.currentBgUrl = SharePreferenceUtils.getCourseBgMusicName(paramPlanReformer._individualInfo.planId);
    if (StringUtils.isNull(this.currentBgUrl))
      this.currentBgMShowName = this.defaultBgMName;
    for (this.currentBgUrl = this.defaultBgUrl; ; this.currentBgUrl = (VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME + this.currentBgUrl))
    {
      this.bgMusicList = FileUtils3.getBgMusicList(this.defaultBgMName);
      this.selectBgIndex = getSelectedIndex();
      return;
      this.currentBgMShowName = FileUtils.convertBgMusicName(this.currentBgUrl);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle3.video.datatransform.reformer.TrainingReformer
 * JD-Core Version:    0.6.0
 */