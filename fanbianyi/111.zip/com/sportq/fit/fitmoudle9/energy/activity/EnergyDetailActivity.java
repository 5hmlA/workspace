package com.sportq.fit.fitmoudle9.energy.activity;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.stickrecycleradapter.StickyRecyclerHeadersDecoration;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.superloadmore.SuperLoadMoreAdapter.OnLoadMoreListener;
import com.sportq.fit.fitmoudle9.R.color;
import com.sportq.fit.fitmoudle9.R.id;
import com.sportq.fit.fitmoudle9.R.layout;
import com.sportq.fit.fitmoudle9.R.mipmap;
import com.sportq.fit.fitmoudle9.R.string;
import com.sportq.fit.fitmoudle9.energy.adapter.EnergyDetailAdapter;
import com.sportq.fit.fitmoudle9.energy.persenter.EnergyPresenterImpl;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyDetailModel.EnergyTradesDetailModel;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer;
import java.util.ArrayList;

public class EnergyDetailActivity extends BaseActivity
{
  private EnergyDetailAdapter adapter;
  private EnergyReformer energyReformer;
  private RelativeLayout headerView;
  private RecyclerView recyclerView;

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    this.dialog.closeDialog();
    if ((paramT instanceof EnergyReformer))
    {
      this.energyReformer = ((EnergyReformer)paramT);
      if ((this.energyReformer.lstUserEnergy != null) && (this.energyReformer.lstUserEnergy.size() != 0))
        break label99;
      if (this.adapter != null)
        break label77;
      this.headerView.setVisibility(0);
      this.recyclerView.setVisibility(8);
    }
    while (true)
    {
      return;
      label77: ToastUtils.makeToast("没有更多数据了");
      this.adapter.setEnd(true);
      this.adapter.setLoadingMore(false);
      return;
      label99: if (this.adapter == null)
      {
        this.adapter = new EnergyDetailAdapter(this, this.energyReformer.lstUserEnergy, R.layout.energy_detail_item_view);
        this.adapter.addHeaderView(View.inflate(this, R.layout.energy_detail_itemhead_view, null));
        this.recyclerView.addItemDecoration(new StickyRecyclerHeadersDecoration(this.adapter));
        this.recyclerView.setAdapter(this.adapter);
        this.adapter.setOnLoadMoreListener(new SuperLoadMoreAdapter.OnLoadMoreListener()
        {
          public void onLoadFailed()
          {
          }

          public void onLoadMore()
          {
            RequestModel localRequestModel = new RequestModel();
            localRequestModel.tradeTime = ((EnergyDetailModel.EnergyTradesDetailModel)EnergyDetailActivity.this.energyReformer.lstUserEnergy.get(-1 + EnergyDetailActivity.this.energyReformer.lstUserEnergy.size())).tradeTime;
            new EnergyPresenterImpl(EnergyDetailActivity.this).getUserEnergyDet(EnergyDetailActivity.this, localRequestModel);
          }

          public void onLoadSucceed()
          {
          }
        });
      }
      while (this.adapter != null)
      {
        this.adapter.setEnd(false);
        this.adapter.setLoadingMore(false);
        return;
        this.adapter.addAll(this.energyReformer.lstUserEnergy);
      }
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.energy_detail_activity);
    this.dialog = new DialogManager();
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    this.recyclerView = ((RecyclerView)findViewById(R.id.swipe_target));
    this.headerView = ((RelativeLayout)findViewById(R.id.header_view));
    localCustomToolBar.setTitle(getString(R.string.c_92_1));
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    localCustomToolBar.setBackgroundResource(R.color.white);
    setSupportActionBar(localCustomToolBar);
    this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
    this.dialog.createProgressDialog(this, "请稍后...");
    new EnergyPresenterImpl(this).getUserEnergyDet(this, new RequestModel());
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  protected void onResume()
  {
    super.onResume();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.activity.EnergyDetailActivity
 * JD-Core Version:    0.6.0
 */