package com.sportq.fit.fitmoudle9.energy.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.EnergyInvitSuccess;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle9.R.color;
import com.sportq.fit.fitmoudle9.R.id;
import com.sportq.fit.fitmoudle9.R.layout;
import com.sportq.fit.fitmoudle9.R.mipmap;
import com.sportq.fit.fitmoudle9.R.string;
import com.sportq.fit.fitmoudle9.energy.persenter.EnergyPresenterImpl;
import com.sportq.fit.fitmoudle9.energy.reformer.model.ExchangeModel;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;

public class EnergyInvitCodeActivity extends BaseActivity
{
  AnimationSet animationSet;
  TextView code_type;
  EditText energyInviteCodeEdit;
  TextView energyInviteCodeError;
  RTextView energyInviteCodePush;
  private EnergyPresenterImpl energyPresenter;
  CustomToolBar toolbar;
  private String type;

  private void closeDialog()
  {
    try
    {
      if (this.dialog != null)
        this.dialog.closeDialog();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void fillInviteCode(String paramString)
  {
    if (this.energyPresenter != null);
    for (EnergyPresenterImpl localEnergyPresenterImpl = this.energyPresenter; ; localEnergyPresenterImpl = new EnergyPresenterImpl(this))
    {
      this.energyPresenter = localEnergyPresenterImpl;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.inviteCode = paramString;
      this.energyPresenter.fillInviteCode(this, localRequestModel);
      return;
    }
  }

  private void fillRedeemCode(String paramString)
  {
    if (this.energyPresenter != null);
    for (EnergyPresenterImpl localEnergyPresenterImpl = this.energyPresenter; ; localEnergyPresenterImpl = new EnergyPresenterImpl(this))
    {
      this.energyPresenter = localEnergyPresenterImpl;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.redeemCode = paramString;
      localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + paramString + NdkUtils.getSignBaseUrl()).toUpperCase();
      this.energyPresenter.fillRedeemCode(this, localRequestModel);
      return;
    }
  }

  private boolean inviteCodeFormatCheck(String paramString)
  {
    if (paramString.length() == 6)
    {
      int i = 0;
      int j = 0;
      int k = 0;
      int m = 0;
      if (m < paramString.length())
      {
        int n = paramString.charAt(m);
        if ((n >= 48) && (n <= 57))
          i++;
        while (true)
        {
          m++;
          break;
          if ((n >= 65) && (n <= 90))
          {
            j++;
            continue;
          }
          k++;
        }
      }
      return (i == 1) && (j == 5) && (k == 0);
    }
    return false;
  }

  private boolean redeemCodeCheck(String paramString)
  {
    int i = paramString.length();
    int j = 0;
    if (i == 12)
    {
      int k = 0;
      int m = 0;
      for (int n = 0; n < paramString.length(); n++)
      {
        if (Character.isDigit(paramString.charAt(n)))
          k = 1;
        if (!Character.isLetter(paramString.charAt(n)))
          continue;
        m = 1;
      }
      j = 0;
      if (k != 0)
      {
        j = 0;
        if (m != 0)
          j = 1;
      }
    }
    return j;
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.energy_invita_code_push)
    {
      if (CompDeviceInfoUtils.checkNetwork())
        break label46;
      this.energyInviteCodeError.setText(StringUtils.getStringResources(R.string.g_20_1));
      this.energyInviteCodeError.startAnimation(this.animationSet);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      label46: 
      do
        return;
      while ((this.energyInviteCodeEdit.getText() == null) || (StringUtils.isNull(this.energyInviteCodeEdit.getText().toString())));
      this.dialog.createProgressDialog(this, StringUtils.getStringResources(R.string.wait_hint));
      if ("0".equals(this.type))
      {
        fillInviteCode(String.valueOf(this.energyInviteCodeEdit.getText()));
        continue;
      }
      fillRedeemCode(String.valueOf(this.energyInviteCodeEdit.getText()));
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    closeDialog();
    this.energyInviteCodeError.setText("当前网络不佳，请稍后尝试");
    this.energyInviteCodeError.startAnimation(this.animationSet);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    closeDialog();
    EnergyReformer localEnergyReformer;
    if ((paramT instanceof EnergyReformer))
    {
      localEnergyReformer = (EnergyReformer)paramT;
      if (!"N".equals(localEnergyReformer.result))
        break label316;
      if (!StringUtils.isNull(localEnergyReformer.message));
    }
    else
    {
      return;
    }
    if ("0".equals(this.type))
    {
      this.energyInviteCodeError.setText(localEnergyReformer.message);
      this.energyInviteCodeError.startAnimation(this.animationSet);
      return;
    }
    if ("MESSAGE_3".equals(localEnergyReformer.message))
    {
      this.energyInviteCodeError.setText(getString(R.string.c_131_1));
      this.energyInviteCodeError.startAnimation(this.animationSet);
      return;
    }
    if ("MESSAGE_4".equals(localEnergyReformer.message))
    {
      this.energyInviteCodeError.setText(getString(R.string.c_131_2));
      this.energyInviteCodeError.startAnimation(this.animationSet);
      return;
    }
    if ("MESSAGE_5".equals(localEnergyReformer.message))
    {
      this.energyInviteCodeError.setText(getString(R.string.c_131_3));
      this.energyInviteCodeError.startAnimation(this.animationSet);
      return;
    }
    if ("MESSAGE_21".equals(localEnergyReformer.message))
    {
      this.energyInviteCodeError.setText("你已达活动兑换上限");
      this.energyInviteCodeError.startAnimation(this.animationSet);
      return;
    }
    if ("MESSAGE_29".equals(localEnergyReformer.message))
    {
      this.energyInviteCodeError.setText("你已参加0元购活动，无法再次参加，退款请联系客服");
      this.energyInviteCodeError.startAnimation(this.animationSet);
      return;
    }
    if ("MESSAGE_31".equals(localEnergyReformer.message))
    {
      this.energyInviteCodeError.setText("当前训练营无排期，详情请咨询客服");
      this.energyInviteCodeError.startAnimation(this.animationSet);
      return;
    }
    this.energyInviteCodeError.setText(localEnergyReformer.message);
    this.energyInviteCodeError.startAnimation(this.animationSet);
    return;
    label316: if ((localEnergyReformer.entMessage != null) && (!StringUtils.isNull(localEnergyReformer.entMessage.message)))
      EventBus.getDefault().post(localEnergyReformer);
    while (true)
    {
      finish();
      return;
      if ("0".equals(this.type))
      {
        EventBus.getDefault().post(new EnergyInvitSuccess(localEnergyReformer.energyValue, localEnergyReformer.classifyId));
        continue;
      }
      EventBus.getDefault().post("redeem.success");
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.energy_invita_code_activity);
    this.dialog = new DialogManager();
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.energyInviteCodeEdit = ((EditText)findViewById(R.id.energy_invita_code_edit));
    this.energyInviteCodePush = ((RTextView)findViewById(R.id.energy_invita_code_push));
    this.energyInviteCodeError = ((TextView)findViewById(R.id.energy_invita_code_error));
    this.code_type = ((TextView)findViewById(R.id.code_type));
    this.type = getIntent().getStringExtra("from.type");
    CustomToolBar localCustomToolBar = this.toolbar;
    String str1;
    String str2;
    label201: TextView localTextView;
    if ("0".equals(this.type))
    {
      str1 = getString(R.string.c_102_1);
      localCustomToolBar.setTitle(str1);
      this.toolbar.setNavIcon(R.mipmap.btn_back_black);
      this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
      this.toolbar.setBackgroundResource(R.color.white);
      setSupportActionBar(this.toolbar);
      RTextView localRTextView = this.energyInviteCodePush;
      if (!"0".equals(this.type))
        break label394;
      str2 = getString(R.string.c_102_3);
      localRTextView.setText(str2);
      localTextView = this.code_type;
      if (!"0".equals(this.type))
        break label406;
    }
    label394: label406: for (String str3 = getString(R.string.c_102_2); ; str3 = getString(R.string.c_129_2))
    {
      localTextView.setText(str3);
      this.energyInviteCodePush.setOnClickListener(new FitAction(this));
      String str4 = TextUtils.getClipboardValue();
      if ((StringUtils.isNull(str4)) || ((!redeemCodeCheck(str4)) && (!inviteCodeFormatCheck(str4))))
        break label418;
      this.energyInviteCodeEdit.setText(str4);
      this.energyInviteCodeEdit.setSelection(str4.length());
      this.animationSet = new AnimationSet(true);
      TranslateAnimation localTranslateAnimation = new TranslateAnimation(1, 0.0F, 1, 0.0F, 1, 0.0F, 1, 1.0F);
      localTranslateAnimation.setDuration(700L);
      localTranslateAnimation.setRepeatCount(1);
      localTranslateAnimation.setRepeatMode(2);
      localTranslateAnimation.setAnimationListener(new Animation.AnimationListener(localTranslateAnimation)
      {
        public void onAnimationEnd(Animation paramAnimation)
        {
          this.val$translateAnimation.setStartOffset(0L);
        }

        public void onAnimationRepeat(Animation paramAnimation)
        {
          this.val$translateAnimation.setStartOffset(1000L);
        }

        public void onAnimationStart(Animation paramAnimation)
        {
        }
      });
      this.animationSet.addAnimation(localTranslateAnimation);
      return;
      str1 = getString(R.string.c_129_1);
      break;
      str2 = getString(R.string.c_129_4);
      break label201;
    }
    label418: EditText localEditText = this.energyInviteCodeEdit;
    if ("0".equals(this.type));
    for (String str5 = "请输入邀请码"; ; str5 = getString(R.string.c_129_3))
    {
      localEditText.setHint(str5);
      break;
    }
  }

  protected void onDestroy()
  {
    TextUtils.copyToClipboard("");
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.activity.EnergyInvitCodeActivity
 * JD-Core Version:    0.6.0
 */