package com.sportq.fit.fitmoudle9.energy.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyActionModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyCustomModel;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyData;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer;
import java.util.ArrayList;
import java.util.Iterator;

public class GetEnergyActionReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    EnergyReformer localEnergyReformer;
    if (paramBaseData == null)
      localEnergyReformer = null;
    while (true)
    {
      return localEnergyReformer;
      EnergyData localEnergyData = (EnergyData)paramBaseData;
      localEnergyReformer = new EnergyReformer();
      localEnergyReformer.entCus = new EnergyCustomModel();
      localEnergyReformer.entCus.stateCode = localEnergyData.entCus.stateCode;
      localEnergyReformer.entCus.hasCusFlag = localEnergyData.entCus.hasCusFlag;
      localEnergyReformer.entCus.hasHistoryFlag = localEnergyData.entCus.hasHistoryFlag;
      localEnergyReformer.lstAction = new ArrayList();
      Iterator localIterator = localEnergyData.lstAction.iterator();
      while (localIterator.hasNext())
      {
        EnergyActionModel localEnergyActionModel1 = (EnergyActionModel)localIterator.next();
        EnergyActionModel localEnergyActionModel2 = new EnergyActionModel();
        localEnergyActionModel2.ownNumber = localEnergyActionModel1.ownNumber;
        localEnergyActionModel2.totalNumber = localEnergyActionModel1.totalNumber;
        localEnergyActionModel2.comment = localEnergyActionModel1.comment;
        localEnergyReformer.lstAction.add(localEnergyActionModel2);
      }
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (EnergyData)FitGsonFactory.create().fromJson(paramString2, EnergyData.class), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.GetEnergyActionReformerImpl
 * JD-Core Version:    0.6.0
 */