package com.sportq.fit.fitmoudle9.energy.reformer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyActionModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyCustomModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyDetailModel.EnergyTradesDetailModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyGoodsModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.ExchangeModel;
import java.util.ArrayList;

public class EnergyReformer extends BaseReformer
{
  public String activeId;
  public String classifyId;
  public String energyValue;
  public EnergyCustomModel entCus;
  public ExchangeModel entMessage;
  public String isDisplay;
  public String isDisplayRedeem;
  public ArrayList<EnergyActionModel> lstAction;
  public ArrayList<EnergyGoodsModel> lstCommodity;
  public ArrayList<EnergyDetailModel.EnergyTradesDetailModel> lstUserEnergy;
  public String message;
  public String result;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer
 * JD-Core Version:    0.6.0
 */