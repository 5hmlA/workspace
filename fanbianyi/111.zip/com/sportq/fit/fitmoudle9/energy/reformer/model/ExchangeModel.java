package com.sportq.fit.fitmoudle9.energy.reformer.model;

import java.io.Serializable;

public class ExchangeModel
  implements Serializable
{
  public String code;
  public String linkUrl;
  public String message;
  public String title;
  public String type;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.model.ExchangeModel
 * JD-Core Version:    0.6.0
 */