package com.sportq.fit.fitmoudle9.energy.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyData;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer;

public class FillInviteCodeReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    if (paramBaseData == null)
      return null;
    EnergyData localEnergyData = (EnergyData)paramBaseData;
    EnergyReformer localEnergyReformer = new EnergyReformer();
    localEnergyReformer.energyValue = localEnergyData.energyValue;
    localEnergyReformer.classifyId = localEnergyData.classifyId;
    localEnergyReformer.result = localEnergyData.result;
    localEnergyReformer.message = localEnergyData.message;
    return localEnergyReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (EnergyData)FitGsonFactory.create().fromJson(paramString2, EnergyData.class), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.FillInviteCodeReformerImpl
 * JD-Core Version:    0.6.0
 */