package com.sportq.fit.fitmoudle9.energy.widget.HeaderAndFooterRecycler;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.GridLayoutManager.SpanSizeLookup;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.LayoutManager;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.support.v7.widget.StaggeredGridLayoutManager.LayoutParams;
import android.view.View;
import android.view.ViewGroup.LayoutParams;

public class WrapperUtils
{
  public static void onAttachedToRecyclerView(RecyclerView.Adapter paramAdapter, RecyclerView paramRecyclerView, SpanSizeCallback paramSpanSizeCallback)
  {
    paramAdapter.onAttachedToRecyclerView(paramRecyclerView);
    RecyclerView.LayoutManager localLayoutManager = paramRecyclerView.getLayoutManager();
    if ((localLayoutManager instanceof GridLayoutManager))
    {
      GridLayoutManager localGridLayoutManager = (GridLayoutManager)localLayoutManager;
      localGridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup(paramSpanSizeCallback, localGridLayoutManager, localGridLayoutManager.getSpanSizeLookup())
      {
        public int getSpanSize(int paramInt)
        {
          return this.val$callback.getSpanSize(this.val$gridLayoutManager, this.val$spanSizeLookup, paramInt);
        }
      });
      localGridLayoutManager.setSpanCount(localGridLayoutManager.getSpanCount());
    }
  }

  public static void setFullSpan(RecyclerView.ViewHolder paramViewHolder)
  {
    ViewGroup.LayoutParams localLayoutParams = paramViewHolder.itemView.getLayoutParams();
    if ((localLayoutParams != null) && ((localLayoutParams instanceof StaggeredGridLayoutManager.LayoutParams)))
      ((StaggeredGridLayoutManager.LayoutParams)localLayoutParams).setFullSpan(true);
  }

  public static abstract interface SpanSizeCallback
  {
    public abstract int getSpanSize(GridLayoutManager paramGridLayoutManager, GridLayoutManager.SpanSizeLookup paramSpanSizeLookup, int paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.widget.HeaderAndFooterRecycler.WrapperUtils
 * JD-Core Version:    0.6.0
 */