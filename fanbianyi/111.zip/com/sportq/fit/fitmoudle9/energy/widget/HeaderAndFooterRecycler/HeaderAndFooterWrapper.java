package com.sportq.fit.fitmoudle9.energy.widget.HeaderAndFooterRecycler;

import android.support.v4.util.SparseArrayCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.GridLayoutManager.SpanSizeLookup;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;
import android.view.ViewGroup;

public class HeaderAndFooterWrapper<T> extends RecyclerView.Adapter<RecyclerView.ViewHolder>
{
  private static final int BASE_ITEM_TYPE_FOOTER = 200000;
  private static final int BASE_ITEM_TYPE_HEADER = 100000;
  private SparseArrayCompat<View> mFootViews = new SparseArrayCompat();
  private SparseArrayCompat<View> mHeaderViews = new SparseArrayCompat();
  private RecyclerView.Adapter mInnerAdapter;

  public HeaderAndFooterWrapper(RecyclerView.Adapter paramAdapter)
  {
    this.mInnerAdapter = paramAdapter;
  }

  private int getRealItemCount()
  {
    return this.mInnerAdapter.getItemCount();
  }

  private boolean isFooterViewPos(int paramInt)
  {
    return paramInt >= getHeadersCount() + getRealItemCount();
  }

  private boolean isHeaderViewPos(int paramInt)
  {
    return paramInt < getHeadersCount();
  }

  public void addFootView(View paramView)
  {
    this.mFootViews.put(200000 + this.mFootViews.size(), paramView);
  }

  public void addHeaderView(View paramView)
  {
    this.mHeaderViews.put(100000 + this.mHeaderViews.size(), paramView);
  }

  public int getFootersCount()
  {
    return this.mFootViews.size();
  }

  public int getHeadersCount()
  {
    return this.mHeaderViews.size();
  }

  public int getItemCount()
  {
    return getHeadersCount() + getFootersCount() + getRealItemCount();
  }

  public int getItemViewType(int paramInt)
  {
    if (isHeaderViewPos(paramInt))
      return this.mHeaderViews.keyAt(paramInt);
    if (isFooterViewPos(paramInt))
      return this.mFootViews.keyAt(paramInt - getHeadersCount() - getRealItemCount());
    return this.mInnerAdapter.getItemViewType(paramInt - getHeadersCount());
  }

  public SparseArrayCompat<View> getmFootViews()
  {
    return this.mFootViews;
  }

  public SparseArrayCompat<View> getmHeaderViews()
  {
    return this.mHeaderViews;
  }

  public void onAttachedToRecyclerView(RecyclerView paramRecyclerView)
  {
    WrapperUtils.onAttachedToRecyclerView(this.mInnerAdapter, paramRecyclerView, new WrapperUtils.SpanSizeCallback()
    {
      public int getSpanSize(GridLayoutManager paramGridLayoutManager, GridLayoutManager.SpanSizeLookup paramSpanSizeLookup, int paramInt)
      {
        int i = HeaderAndFooterWrapper.this.getItemViewType(paramInt);
        if (HeaderAndFooterWrapper.this.mHeaderViews.get(i) != null)
          return paramGridLayoutManager.getSpanCount();
        if (HeaderAndFooterWrapper.this.mFootViews.get(i) != null)
          return paramGridLayoutManager.getSpanCount();
        if (paramSpanSizeLookup != null)
          return paramSpanSizeLookup.getSpanSize(paramInt);
        return 1;
      }
    });
  }

  public void onBindViewHolder(RecyclerView.ViewHolder paramViewHolder, int paramInt)
  {
    if (isHeaderViewPos(paramInt));
    do
      return;
    while (isFooterViewPos(paramInt));
    this.mInnerAdapter.onBindViewHolder(paramViewHolder, paramInt - getHeadersCount());
  }

  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt)
  {
    if (this.mHeaderViews.get(paramInt) != null)
      return ViewHolder.createViewHolder(paramViewGroup.getContext(), (View)this.mHeaderViews.get(paramInt));
    if (this.mFootViews.get(paramInt) != null)
      return ViewHolder.createViewHolder(paramViewGroup.getContext(), (View)this.mFootViews.get(paramInt));
    return this.mInnerAdapter.onCreateViewHolder(paramViewGroup, paramInt);
  }

  public void onViewAttachedToWindow(RecyclerView.ViewHolder paramViewHolder)
  {
    this.mInnerAdapter.onViewAttachedToWindow(paramViewHolder);
    int i = paramViewHolder.getLayoutPosition();
    if ((isHeaderViewPos(i)) || (isFooterViewPos(i)))
      WrapperUtils.setFullSpan(paramViewHolder);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.widget.HeaderAndFooterRecycler.HeaderAndFooterWrapper
 * JD-Core Version:    0.6.0
 */