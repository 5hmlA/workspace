package com.sportq.fit.fitmoudle9.energy.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle9.R.color;
import com.sportq.fit.fitmoudle9.R.id;
import com.sportq.fit.fitmoudle9.R.layout;
import com.sportq.fit.fitmoudle9.R.mipmap;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyActionModel;
import java.util.ArrayList;

public class EnergyActionRecycAdapter extends RecyclerView.Adapter
{
  private ArrayList<EnergyActionModel> lstAction;
  private Context mContext;

  public EnergyActionRecycAdapter(Context paramContext, ArrayList<EnergyActionModel> paramArrayList)
  {
    this.mContext = paramContext;
    this.lstAction = paramArrayList;
  }

  public int getItemCount()
  {
    return this.lstAction.size();
  }

  public void onBindViewHolder(RecyclerView.ViewHolder paramViewHolder, int paramInt)
  {
    TextView localTextView1 = ((ViewHolder)paramViewHolder).energyActionItemAcName;
    String str;
    int i;
    label89: int j;
    label128: int k;
    label200: ImageView localImageView;
    if (!StringUtils.isNull(((EnergyActionModel)this.lstAction.get(paramInt)).comment))
    {
      str = ((EnergyActionModel)this.lstAction.get(paramInt)).comment;
      localTextView1.setText(str);
      if (StringUtils.isNull(((EnergyActionModel)this.lstAction.get(paramInt)).ownNumber))
        break label248;
      i = Integer.parseInt(((EnergyActionModel)this.lstAction.get(paramInt)).ownNumber);
      if (StringUtils.isNull(((EnergyActionModel)this.lstAction.get(paramInt)).totalNumber))
        break label254;
      j = Integer.parseInt(((EnergyActionModel)this.lstAction.get(paramInt)).totalNumber);
      TextView localTextView2 = ((ViewHolder)paramViewHolder).energyActionItemProgress;
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(i);
      arrayOfObject[1] = Integer.valueOf(j);
      localTextView2.setText(String.format("(%d/%d)", arrayOfObject));
      TextView localTextView3 = ((ViewHolder)paramViewHolder).energyActionItemProgress;
      Context localContext = this.mContext;
      if (i != j)
        break label260;
      k = R.color.color_2ac77d;
      localTextView3.setTextColor(ContextCompat.getColor(localContext, k));
      localImageView = ((ViewHolder)paramViewHolder).energyActionItemIsFinish;
      if (i != j)
        break label268;
    }
    label260: label268: for (int m = R.mipmap.icn_finished_2x; ; m = R.mipmap.icn_unfinished_2x)
    {
      localImageView.setImageResource(m);
      return;
      str = "";
      break;
      label248: i = 0;
      break label89;
      label254: j = 0;
      break label128;
      k = R.color.color_ff6a49;
      break label200;
    }
  }

  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt)
  {
    return new ViewHolder(LayoutInflater.from(this.mContext).inflate(R.layout.energy_action_item_view, null));
  }

  static class ViewHolder extends RecyclerView.ViewHolder
  {
    TextView energyActionItemAcName;
    ImageView energyActionItemIsFinish;
    TextView energyActionItemProgress;

    ViewHolder(View paramView)
    {
      super();
      this.energyActionItemAcName = ((TextView)paramView.findViewById(R.id.energy_action_item_AcName));
      this.energyActionItemProgress = ((TextView)paramView.findViewById(R.id.energy_action_item_progress));
      this.energyActionItemIsFinish = ((ImageView)paramView.findViewById(R.id.energy_action_item_isFinish));
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.adapter.EnergyActionRecycAdapter
 * JD-Core Version:    0.6.0
 */