package com.sportq.fit.fitmoudle9.energy.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.stickrecycleradapter.StickyRecyclerHeadersAdapter;
import com.sportq.fit.fitmoudle.widget.superloadmore.SuperLoadMoreAdapter;
import com.sportq.fit.fitmoudle9.R.color;
import com.sportq.fit.fitmoudle9.R.id;
import com.sportq.fit.fitmoudle9.R.layout;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyDetailModel.EnergyTradesDetailModel;
import java.util.List;
import org.byteam.superadapter.SuperViewHolder;

public class EnergyDetailAdapter extends SuperLoadMoreAdapter<EnergyDetailModel.EnergyTradesDetailModel>
  implements StickyRecyclerHeadersAdapter
{
  public EnergyDetailAdapter(Context paramContext, List paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public long getHeaderId(int paramInt)
  {
    if ((hasHeaderView()) && (paramInt == 0))
      return -1L;
    List localList = getData();
    if (hasHeaderView())
      paramInt--;
    return ((EnergyDetailModel.EnergyTradesDetailModel)localList.get(paramInt)).headIndex;
  }

  public int getItemCount()
  {
    return getData().size();
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, EnergyDetailModel.EnergyTradesDetailModel paramEnergyTradesDetailModel)
  {
    String str1 = paramEnergyTradesDetailModel.formatTime;
    String str2 = paramEnergyTradesDetailModel.energyValue;
    String str3 = paramEnergyTradesDetailModel.comment;
    TextView localTextView1 = (TextView)paramSuperViewHolder.findViewById(R.id.energy_detail_item_date);
    String str4;
    label80: label107: TextView localTextView4;
    Context localContext;
    if (!StringUtils.isNull(str1))
    {
      localTextView1.setText(str1);
      TextView localTextView2 = (TextView)paramSuperViewHolder.findViewById(R.id.energy_detail_item_detailValue);
      if (StringUtils.isNull(str2))
        break label198;
      if (Integer.parseInt(str2) >= 0)
        break label173;
      str4 = str2;
      localTextView2.setText(str4);
      TextView localTextView3 = (TextView)paramSuperViewHolder.findViewById(R.id.energy_detail_item_reason);
      if (StringUtils.isNull(str3))
        break label205;
      localTextView3.setText(str3);
      if (StringUtils.isNull(str2))
        break label220;
      localTextView4 = (TextView)paramSuperViewHolder.findViewById(R.id.energy_detail_item_detailValue);
      localContext = getContext();
      if (Integer.parseInt(str2) < 0)
        break label212;
    }
    label173: label198: label205: label212: for (int i = R.color.color_2ac77d; ; i = R.color.color_ff6a49)
    {
      localTextView4.setTextColor(ContextCompat.getColor(localContext, i));
      return;
      str1 = "";
      break;
      str4 = "+" + str2;
      break label80;
      str4 = "";
      break label80;
      str3 = "";
      break label107;
    }
    label220: ((TextView)paramSuperViewHolder.findViewById(R.id.energy_detail_item_detailValue)).setTextColor(ContextCompat.getColor(getContext(), R.color.color_2ac77d));
  }

  public void onBindHeaderViewHolder(RecyclerView.ViewHolder paramViewHolder, int paramInt)
  {
    TextView localTextView = ((EnergyDetailTitleViewHolder)paramViewHolder).titleView;
    List localList = getData();
    if (hasHeaderView())
      paramInt--;
    localTextView.setText(((EnergyDetailModel.EnergyTradesDetailModel)localList.get(paramInt)).tradeMonth);
  }

  public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup paramViewGroup)
  {
    return new EnergyDetailTitleViewHolder(LayoutInflater.from(getContext()).inflate(R.layout.energy_detail_itemtitle_view, paramViewGroup, false));
  }

  private class EnergyDetailTitleViewHolder extends RecyclerView.ViewHolder
  {
    TextView titleView;

    EnergyDetailTitleViewHolder(View arg2)
    {
      super();
      this.titleView = ((TextView)localView);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.adapter.EnergyDetailAdapter
 * JD-Core Version:    0.6.0
 */