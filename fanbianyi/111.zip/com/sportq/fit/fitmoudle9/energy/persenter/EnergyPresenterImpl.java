package com.sportq.fit.fitmoudle9.energy.persenter;

import android.content.Context;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle9.energy.reformer.APIName;
import com.sportq.fit.fitmoudle9.energy.reformer.APIName.ApiEnum;
import com.sportq.fit.fitmoudle9.energy.reformer.FillInviteCodeReformerImpl;
import com.sportq.fit.fitmoudle9.energy.reformer.GetCommodityReformerImpl;
import com.sportq.fit.fitmoudle9.energy.reformer.GetEnergyActionReformerImpl;
import com.sportq.fit.fitmoudle9.energy.reformer.GetUserEnergyDetReformerImpl;
import com.sportq.fit.fitmoudle9.energy.reformer.RedeemReformerImpl;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.CommonUtils;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;

public class EnergyPresenterImpl
  implements EnergyPresenterInterface
{
  private ApiInterface api = new ApiImpl();
  private ReformerInterface reformerInterface;
  private FitInterfaceUtils.UIInitListener uiListener;

  public EnergyPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.uiListener = paramUIInitListener;
  }

  public void fillInviteCode(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.FillInviteCode);
      ReformerImpl localReformerImpl = new ReformerImpl(new FillInviteCodeReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.FillInviteCode);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("EnergyPresenterImpl.fillInviteCode", localException);
    }
  }

  public void fillRedeemCode(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.FillRedeemCode);
      ReformerImpl localReformerImpl = new ReformerImpl(new RedeemReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.FillRedeemCode);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("EnergyPresenterImpl.fillInviteCode", localException);
    }
  }

  public void getCommodity(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GetCommodityReformerImpl());
      String str = APIName.getAPIName(APIName.ApiEnum.GET_COMMODITY);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("EnergyPresenterImpl.getCommodity", localException);
    }
  }

  public void getEnergyAction(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GetEnergyActionReformerImpl());
      String str = APIName.getAPIName(APIName.ApiEnum.GET_ENERGY_ACTION);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("EnergyPresenterImpl.getEnergyAction", localException);
    }
  }

  public void getUserEnergyDet(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GetUserEnergyDet);
      ReformerImpl localReformerImpl = new ReformerImpl(new GetUserEnergyDetReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetUserEnergyDet);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("EnergyPresenterImpl.getUserEnergyDet", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.persenter.EnergyPresenterImpl
 * JD-Core Version:    0.6.0
 */