package com.sportq.fit.fitmoudle9.energy.persenter;

import android.content.Context;
import com.sportq.fit.common.model.request.RequestModel;

public abstract interface EnergyPresenterInterface
{
  public abstract void fillInviteCode(Context paramContext, RequestModel paramRequestModel);

  public abstract void fillRedeemCode(Context paramContext, RequestModel paramRequestModel);

  public abstract void getCommodity(Context paramContext, RequestModel paramRequestModel);

  public abstract void getEnergyAction(Context paramContext, RequestModel paramRequestModel);

  public abstract void getUserEnergyDet(Context paramContext, RequestModel paramRequestModel);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.persenter.EnergyPresenterInterface
 * JD-Core Version:    0.6.0
 */