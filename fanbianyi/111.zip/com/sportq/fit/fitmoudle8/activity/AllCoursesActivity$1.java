package com.sportq.fit.fitmoudle8.activity;

import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.middlelib.MiddleManager;

class AllCoursesActivity$1
  implements Runnable
{
  public void run()
  {
    MiddleManager.getInstance().getFindPresenterImpl(this.this$0, null).sereenCurriculumInfo(AllCoursesActivity.access$000(this.this$0), this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.AllCoursesActivity.1
 * JD-Core Version:    0.6.0
 */