package com.sportq.fit.fitmoudle8.activity;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle8.widget.allcourse.CourseTitleView;

class AllCoursesActivity$5
  implements View.OnTouchListener
{
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    CompDeviceInfoUtils.hideSoftInput(this.this$0, AllCoursesActivity.access$200(this.this$0).getEdit_text());
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.AllCoursesActivity.5
 * JD-Core Version:    0.6.0
 */