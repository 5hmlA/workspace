package com.sportq.fit.fitmoudle8.activity;

import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import com.sportq.fit.common.utils.CustomLoad.FeedbackLoadDialog;
import com.sportq.fit.fitmoudle8.R.anim;

class Find03GenTrainListActivity$1
  implements Runnable
{
  public void run()
  {
    if (!this.this$0.isFinishing())
    {
      Find03GenTrainListActivity.access$000(this.this$0).closeDialog();
      Find03GenTrainListActivity.access$002(this.this$0, null);
      if (Find03GenTrainListActivity.access$100(this.this$0))
      {
        if (Find03GenTrainListActivity.access$200(this.this$0) != null)
        {
          Animation localAnimation = AnimationUtils.loadAnimation(this.this$0, R.anim.roll_up);
          localAnimation.setFillAfter(true);
          Find03GenTrainListActivity.access$200(this.this$0).setAnimation(localAnimation);
          Find03GenTrainListActivity.access$200(this.this$0).setVisibility(0);
          new Handler().postDelayed(new Runnable()
          {
            public void run()
            {
              Animation localAnimation = AnimationUtils.loadAnimation(Find03GenTrainListActivity.1.this.this$0, R.anim.roll_down);
              Find03GenTrainListActivity.access$200(Find03GenTrainListActivity.1.this.this$0).startAnimation(localAnimation);
              Find03GenTrainListActivity.access$200(Find03GenTrainListActivity.1.this.this$0).setVisibility(8);
            }
          }
          , 2000L);
        }
        Find03GenTrainListActivity.access$300(this.this$0);
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity.1
 * JD-Core Version:    0.6.0
 */