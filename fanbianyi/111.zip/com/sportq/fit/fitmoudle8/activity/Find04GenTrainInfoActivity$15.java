package com.sportq.fit.fitmoudle8.activity;

import com.sportq.fit.fitmoudle8.util.CourseSharePreUtils;
import com.sportq.fit.fitmoudle8.widget.DrawCenterButton;
import com.sportq.fit.fitmoudle8.widget.guide.UpgradeGuide;
import com.sportq.fit.fitmoudle8.widget.guide.UpgradeGuide.OnGuideCloseListener;

class Find04GenTrainInfoActivity$15
  implements UpgradeGuide.OnGuideCloseListener
{
  public void onClose(String paramString)
  {
    if ((Find04GenTrainInfoActivity.access$2500(this.this$0).getVisibility() == 0) && ("参加课程".equals(Find04GenTrainInfoActivity.access$2500(this.this$0).getText().toString())) && (!CourseSharePreUtils.getGuideIsShowFlg02()))
    {
      CourseSharePreUtils.putGuideIsShowFlg02();
      UpgradeGuide.showGuideUi1(Find04GenTrainInfoActivity.access$2600(this.this$0), this.this$0, 4, new UpgradeGuide.OnGuideCloseListener()
      {
        public void onClose(String paramString)
        {
        }
      });
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.15
 * JD-Core Version:    0.6.0
 */