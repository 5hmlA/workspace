package com.sportq.fit.fitmoudle8.activity;

import android.widget.TextView;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.widget.CustomScrollView;
import com.sportq.fit.fitmoudle8.widget.CustomScrollView.ScrollViewListener;

class FitLocalMusicActivity$1
  implements CustomScrollView.ScrollViewListener
{
  public void onScrollChanged(CustomScrollView paramCustomScrollView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int[] arrayOfInt1 = new int[2];
    int[] arrayOfInt2 = new int[2];
    FitLocalMusicActivity.access$000(this.this$0).getLocationInWindow(arrayOfInt1);
    FitLocalMusicActivity.access$100(this.this$0).getLocationInWindow(arrayOfInt2);
    if (arrayOfInt2[1] <= arrayOfInt1[1])
    {
      FitLocalMusicActivity.access$000(this.this$0).setVisibility(0);
      FitLocalMusicActivity.access$000(this.this$0).setText(StringUtils.getStringResources(R.string.b_84_2));
      return;
    }
    FitLocalMusicActivity.access$000(this.this$0).setVisibility(4);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitLocalMusicActivity.1
 * JD-Core Version:    0.6.0
 */