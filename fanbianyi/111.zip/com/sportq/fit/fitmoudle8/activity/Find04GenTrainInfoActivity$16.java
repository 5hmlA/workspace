package com.sportq.fit.fitmoudle8.activity;

import com.sportq.fit.fitmoudle8.widget.guide.UpgradeGuide.OnGuideCloseListener;

class Find04GenTrainInfoActivity$16
  implements UpgradeGuide.OnGuideCloseListener
{
  public void onClose(String paramString)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.16
 * JD-Core Version:    0.6.0
 */