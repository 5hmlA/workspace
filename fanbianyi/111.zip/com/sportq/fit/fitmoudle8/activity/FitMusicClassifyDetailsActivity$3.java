package com.sportq.fit.fitmoudle8.activity;

import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.reformer.model.MusicModel;
import java.util.ArrayList;

class FitMusicClassifyDetailsActivity$3
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    if ("2".equals(((MusicModel)FitMusicClassifyDetailsActivity.access$200(this.this$0).get(this.val$index)).musicType))
      return;
    String str = CompDeviceInfoUtils.getAPNType(this.this$0);
    if ("-1".equals(str))
    {
      ToastUtils.makeToast(this.this$0, com.sportq.fit.common.utils.StringUtils.getStringResources(R.string.network_useless_check_settings));
      return;
    }
    CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener(str)
    {
      public void result(boolean paramBoolean)
      {
        int i;
        if (paramBoolean)
        {
          if ("1".equals(this.val$strNetType))
            break label167;
          i = com.sportq.fit.common.utils.StringUtils.string2Int(((MusicModel)FitMusicClassifyDetailsActivity.access$200(FitMusicClassifyDetailsActivity.3.this.this$0).get(FitMusicClassifyDetailsActivity.3.this.val$index)).musicSize);
          if (i <= 1024)
            break label144;
        }
        label144: for (String str1 = com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.getM(i) + "MB"; ; str1 = i + "KB")
        {
          String str2 = String.format(com.sportq.fit.common.utils.StringUtils.getStringResources(R.string.down_music_hint), new Object[] { str1 });
          FitMusicClassifyDetailsActivity.3.this.this$0.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
          {
            public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
            {
              if (paramInt == -1)
                FitMusicClassifyDetailsActivity.access$300(FitMusicClassifyDetailsActivity.3.this.this$0, FitMusicClassifyDetailsActivity.access$200(FitMusicClassifyDetailsActivity.3.this.this$0), FitMusicClassifyDetailsActivity.3.this.val$index);
            }
          }
          , FitMusicClassifyDetailsActivity.3.this.this$0, "", str2, com.sportq.fit.common.utils.StringUtils.getStringResources(R.string.make_sure), com.sportq.fit.common.utils.StringUtils.getStringResources(R.string.cancel_hint));
          return;
        }
        label167: FitMusicClassifyDetailsActivity.access$300(FitMusicClassifyDetailsActivity.3.this.this$0, FitMusicClassifyDetailsActivity.access$200(FitMusicClassifyDetailsActivity.3.this.this$0), FitMusicClassifyDetailsActivity.3.this.val$index);
      }
    }
    , this.this$0, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitMusicClassifyDetailsActivity.3
 * JD-Core Version:    0.6.0
 */