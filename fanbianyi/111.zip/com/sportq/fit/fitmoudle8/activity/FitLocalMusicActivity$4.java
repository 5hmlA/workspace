package com.sportq.fit.fitmoudle8.activity;

import java.util.Comparator;

class FitLocalMusicActivity$4
  implements Comparator<String>
{
  public int compare(String paramString1, String paramString2)
  {
    return Double.valueOf(paramString2).compareTo(Double.valueOf(paramString1));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitLocalMusicActivity.4
 * JD-Core Version:    0.6.0
 */