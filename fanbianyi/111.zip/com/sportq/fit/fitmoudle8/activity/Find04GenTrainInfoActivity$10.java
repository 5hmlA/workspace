package com.sportq.fit.fitmoudle8.activity;

import android.content.Intent;
import android.widget.ImageView;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.StringUtils;
import org.greenrobot.eventbus.EventBus;

class Find04GenTrainInfoActivity$10
  implements Runnable
{
  public void run()
  {
    int i = 8;
    if ((Find04GenTrainInfoActivity.access$1200(this.this$0) == null) || ((this.this$0.more_image == null) && (this.this$0.share_image == null)))
      return;
    Find04GenTrainInfoActivity.access$1400(this.this$0, this.this$0.share_image);
    Find04GenTrainInfoActivity.access$1400(this.this$0, this.this$0.more_image);
    if (!StringUtils.isNull(this.this$0.getIntent().getStringExtra("customized.id")))
    {
      this.this$0.more_image.setVisibility(i);
      EventBus.getDefault().post("showGuide_2.0.2");
      return;
    }
    if ("0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)));
    for (PlanModel localPlanModel = Find04GenTrainInfoActivity.access$1200(this.this$0)._individualInfo; ; localPlanModel = Find04GenTrainInfoActivity.access$1200(this.this$0)._planInfo)
    {
      ImageView localImageView = this.this$0.more_image;
      if ((("1".equals(localPlanModel.planStateCode)) || (StringUtils.isNull(Find04GenTrainInfoActivity.access$200(this.this$0)))) && (!"hide".equals(Find04GenTrainInfoActivity.access$1500(this.this$0))))
        i = 0;
      localImageView.setVisibility(i);
      break;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.10
 * JD-Core Version:    0.6.0
 */