package com.sportq.fit.fitmoudle8.activity;

import android.content.DialogInterface;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle8.R.string;

class Find04GenTrainInfoActivity$17
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt != -1)
    {
      if (!CompDeviceInfoUtils.checkNetwork())
      {
        ToastUtils.makeToast(this.this$0, StringUtils.getStringResources(R.string.network_useless_check_settings));
        return;
      }
      Find04GenTrainInfoActivity.access$2700(this.this$0, "1");
    }
    Find04GenTrainInfoActivity.access$2802(this.this$0, false);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.17
 * JD-Core Version:    0.6.0
 */