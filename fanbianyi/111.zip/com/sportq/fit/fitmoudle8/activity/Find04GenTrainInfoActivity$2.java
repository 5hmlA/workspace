package com.sportq.fit.fitmoudle8.activity;

import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;

class Find04GenTrainInfoActivity$2
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -2)
      Find04GenTrainInfoActivity.access$100(this.this$0, this.val$v);
    do
      return;
    while ("0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)));
    CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
    {
      public void result(boolean paramBoolean)
      {
        if (paramBoolean)
        {
          Find04GenTrainInfoActivity.access$300(Find04GenTrainInfoActivity.2.this.this$0).setTag("jump.video.play");
          Find04GenTrainInfoActivity.access$400(Find04GenTrainInfoActivity.2.this.this$0);
        }
      }
    }
    , this.this$0, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.2
 * JD-Core Version:    0.6.0
 */