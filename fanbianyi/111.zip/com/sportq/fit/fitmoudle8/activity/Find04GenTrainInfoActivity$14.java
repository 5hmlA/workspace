package com.sportq.fit.fitmoudle8.activity;

import android.content.Intent;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.fitmoudle.AnimationUtil;

class Find04GenTrainInfoActivity$14
  implements CompDeviceInfoUtils.applyPerListener
{
  public void result(boolean paramBoolean)
  {
    Intent localIntent = new Intent(this.this$0, FitMusicSettingActivity.class);
    localIntent.putExtra("plan.id", Find04GenTrainInfoActivity.access$2100(this.this$0));
    localIntent.putExtra("recommend.url", Find04GenTrainInfoActivity.access$2200(this.this$0));
    localIntent.putExtra("recommend.name", Find04GenTrainInfoActivity.access$2300(this.this$0));
    localIntent.putExtra("recommend.music.id", Find04GenTrainInfoActivity.access$2400(this.this$0));
    this.this$0.startActivity(localIntent);
    AnimationUtil.pageJumpAnim(this.this$0, 0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.14
 * JD-Core Version:    0.6.0
 */