package com.sportq.fit.fitmoudle8.activity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.view.View;
import android.widget.ImageView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

class FitMusicSettingActivity$6 extends FitAction
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    if (this.val$position == -1 + FitMusicSettingActivity.access$800(this.this$0))
    {
      FitMusicSettingActivity.access$902(this.this$0, FitMusicSettingActivity.access$1000(this.this$0));
      Intent localIntent = new Intent(this.this$0, FitMusicLibraryActivity.class);
      localIntent.putStringArrayListExtra("download.music.list", FitMusicSettingActivity.access$1100(this.this$0));
      localIntent.putExtra("default.url", FitMusicSettingActivity.access$1200(this.this$0));
      this.this$0.startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this.this$0, 0);
      return;
    }
    FitMusicSettingActivity.access$902(this.this$0, ((String)FitMusicSettingActivity.access$600(this.this$0).get(this.val$position)).split("&")[3]);
    FitMusicSettingActivity.access$1302(this.this$0, (AnimationDrawable)this.val$mImg1.getDrawable());
    if ((this.this$0.img01 == this.val$mImg1) && (this.this$0.img02 == this.val$mImg2))
      if (this.val$mImg1.getVisibility() == 0)
      {
        this.val$mImg1.setVisibility(8);
        FitMusicSettingActivity.access$1300(this.this$0).stop();
      }
    while (true)
    {
      this.this$0.img01 = this.val$mImg1;
      this.this$0.img02 = this.val$mImg2;
      String str = VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME + (String)FitMusicSettingActivity.access$600(this.this$0).get(this.val$position);
      FitMusicSettingActivity.access$1400(this.this$0, str, this.val$position);
      return;
      this.val$mImg1.setVisibility(0);
      FitMusicSettingActivity.access$1300(this.this$0).start();
      continue;
      if (this.this$0.img01 != null)
      {
        ((AnimationDrawable)this.this$0.img01.getDrawable()).stop();
        this.this$0.img01.setVisibility(8);
      }
      if (this.this$0.img02 != null)
        this.this$0.img02.setVisibility(8);
      this.val$mImg1.setVisibility(0);
      this.val$mImg2.setVisibility(0);
      FitMusicSettingActivity.access$1300(this.this$0).start();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitMusicSettingActivity.6
 * JD-Core Version:    0.6.0
 */