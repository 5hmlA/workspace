package com.sportq.fit.fitmoudle8.activity;

import android.os.Build.VERSION;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.mipmap;
import com.sportq.fit.fitmoudle8.widget.CustomScrollView;
import com.sportq.fit.fitmoudle8.widget.CustomScrollView.ScrollViewListener;

class FitMusicClassifyDetailsActivity$1
  implements CustomScrollView.ScrollViewListener
{
  public void onScrollChanged(CustomScrollView paramCustomScrollView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int[] arrayOfInt = new int[2];
    FitMusicClassifyDetailsActivity.access$000(this.this$0).getLocationInWindow(arrayOfInt);
    int i = this.this$0.toolbar_layout.getHeight() + CompDeviceInfoUtils.getStatusBarHeight(this.this$0);
    int j = (int)(0.5597D * BaseApplication.screenWidth) - this.this$0.toolbar_layout.getHeight();
    if (paramInt2 > 0)
    {
      float f;
      if (arrayOfInt[1] <= i)
        f = 1.0F;
      while (true)
      {
        FitMusicClassifyDetailsActivity.access$100(this.this$0).setNavIcon(R.mipmap.btn_back_black);
        FitMusicClassifyDetailsActivity.access$100(this.this$0).setTitleTextColor(ContextCompat.getColor(this.this$0, R.color.color_313131));
        this.this$0.toolbar_layout.setBackgroundResource(R.color.white);
        this.this$0.toolbar_layout.setAlpha(f);
        if (Build.VERSION.SDK_INT >= 21)
          this.this$0.toolbar_layout.setElevation(CompDeviceInfoUtils.convertOfDip(this.this$0, 3.0F));
        this.this$0.toolbar_layout.getChildAt(1).setVisibility(0);
        return;
        f = paramInt2 / j;
      }
    }
    FitMusicClassifyDetailsActivity.access$100(this.this$0).setNavIcon(R.mipmap.btn_back_white);
    FitMusicClassifyDetailsActivity.access$100(this.this$0).setTitleTextColor(ContextCompat.getColor(this.this$0, R.color.white));
    FitMusicClassifyDetailsActivity.access$100(this.this$0).setBackgroundResource(R.color.transparent);
    if (Build.VERSION.SDK_INT >= 21)
      this.this$0.toolbar_layout.setElevation(0.0F);
    this.this$0.toolbar_layout.setBackgroundResource(R.color.transparent);
    this.this$0.toolbar_layout.setAlpha(1.0F);
    this.this$0.toolbar_layout.getChildAt(1).setVisibility(8);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitMusicClassifyDetailsActivity.1
 * JD-Core Version:    0.6.0
 */