package com.sportq.fit.fitmoudle8.activity;

import android.content.res.Resources;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools;
import org.greenrobot.eventbus.EventBus;

class Find04GenTrainInfoActivity$13
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -1)
    {
      EventBus.getDefault().post("参加退出计划");
      this.this$0.dialog.createProgressDialog(this.this$0, this.this$0.getResources().getString(R.string.wait_hint));
      Find04GenTrainInfoActivity.access$000(this.this$0).joinPlan("1");
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.13
 * JD-Core Version:    0.6.0
 */