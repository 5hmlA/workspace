package com.sportq.fit.fitmoudle8.activity;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;

class FitMusicSettingActivity$7
  implements MediaPlayer.OnPreparedListener
{
  public void onPrepared(MediaPlayer paramMediaPlayer)
  {
    FitMusicSettingActivity.access$1500(this.this$0).setLooping(true);
    FitMusicSettingActivity.access$1500(this.this$0).start();
    FitMusicSettingActivity.access$1602(this.this$0, this.val$strPath);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitMusicSettingActivity.7
 * JD-Core Version:    0.6.0
 */