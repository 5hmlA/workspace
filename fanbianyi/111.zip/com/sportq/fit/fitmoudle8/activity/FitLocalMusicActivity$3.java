package com.sportq.fit.fitmoudle8.activity;

import android.view.animation.AlphaAnimation;
import android.widget.RelativeLayout;
import java.util.ArrayList;

class FitLocalMusicActivity$3
  implements Runnable
{
  public void run()
  {
    if (FitLocalMusicActivity.access$300(this.this$0).size() > 0)
    {
      FitLocalMusicActivity.access$400(this.this$0).setVisibility(0);
      if (this.val$delayTime != 0)
      {
        AlphaAnimation localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
        localAlphaAnimation.setDuration(500L);
        FitLocalMusicActivity.access$400(this.this$0).setAnimation(localAlphaAnimation);
      }
    }
    while (true)
    {
      FitLocalMusicActivity.access$500(this.this$0);
      return;
      FitLocalMusicActivity.access$400(this.this$0).setVisibility(8);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitLocalMusicActivity.3
 * JD-Core Version:    0.6.0
 */