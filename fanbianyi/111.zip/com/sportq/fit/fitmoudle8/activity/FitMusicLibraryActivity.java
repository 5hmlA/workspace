package com.sportq.fit.fitmoudle8.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.layout;
import com.sportq.fit.fitmoudle8.R.menu;
import com.sportq.fit.fitmoudle8.R.mipmap;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.adapter.FitMusicLibraryAdapter;
import com.sportq.fit.fitmoudle8.presenter.PresenterImpl;
import com.sportq.fit.fitmoudle8.reformer.model.MusicModel;
import com.sportq.fit.fitmoudle8.reformer.reformer.MusicReformer;
import com.sportq.fit.supportlib.CommonUtils;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class FitMusicLibraryActivity extends BaseActivity
{
  FitMusicLibraryAdapter adapter;
  private ArrayList<String> downList = new ArrayList();
  private boolean isFromTab = false;
  private MusicReformer musicReformer;
  private RecyclerView recyclerView;
  CustomToolBar toolbar;

  private void getLocalMusicList()
  {
    this.downList = getIntent().getStringArrayListExtra("download.music.list");
    if (this.downList == null)
    {
      this.isFromTab = true;
      File localFile1 = new File(VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME);
      this.downList = new ArrayList();
      if (localFile1.exists())
      {
        String[] arrayOfString = localFile1.list();
        int i;
        ArrayList localArrayList1;
        ArrayList localArrayList2;
        int k;
        label95: String str3;
        if (arrayOfString != null)
        {
          i = arrayOfString.length;
          if (i <= 0)
            return;
          localArrayList1 = new ArrayList();
          localArrayList2 = new ArrayList();
          int j = arrayOfString.length;
          k = 0;
          if (k >= j)
            break label199;
          str3 = arrayOfString[k];
          if (!str3.contains("&"))
            break label152;
          localArrayList1.add(str3.split("&")[0]);
          localArrayList2.add(str3);
        }
        while (true)
        {
          k++;
          break label95;
          i = 0;
          break;
          label152: File localFile2 = new File(VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME + str3);
          if (!localFile2.exists())
            continue;
          localFile2.delete();
        }
        label199: Collections.sort(localArrayList1, new Comparator()
        {
          public int compare(String paramString1, String paramString2)
          {
            return Double.valueOf(paramString2).compareTo(Double.valueOf(paramString1));
          }
        });
        Iterator localIterator1 = localArrayList1.iterator();
        while (localIterator1.hasNext())
        {
          String str1 = (String)localIterator1.next();
          Iterator localIterator2 = localArrayList2.iterator();
          while (localIterator2.hasNext())
          {
            String str2 = (String)localIterator2.next();
            if (!str1.equals(str2.split("&")[0]))
              continue;
            this.downList.add(str2);
          }
        }
      }
    }
  }

  private void init()
  {
    this.recyclerView = ((RecyclerView)findViewById(R.id.recyclerView));
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    getLocalMusicList();
    this.toolbar.setTitle(getResources().getString(R.string.music_library_hint));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundResource(R.color.white);
    setSupportActionBar(this.toolbar);
    CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GetMusicCategoryList);
    new PresenterImpl(this).getMusicLibraryInfo(this);
  }

  private void initData(MusicReformer paramMusicReformer)
  {
    if (paramMusicReformer.lstMusicCategory == null)
      return;
    Iterator localIterator1 = paramMusicReformer.lstMusicCategory.iterator();
    while (localIterator1.hasNext())
      ((MusicModel)localIterator1.next()).down_num = 0;
    if (this.downList.size() != 0)
    {
      Iterator localIterator2 = this.downList.iterator();
      while (true)
      {
        if (!localIterator2.hasNext())
          break label248;
        String str1 = ((String)localIterator2.next()).split("&")[2];
        if (!str1.contains(","))
        {
          Iterator localIterator4 = paramMusicReformer.lstMusicCategory.iterator();
          if (!localIterator4.hasNext())
            continue;
          MusicModel localMusicModel2 = (MusicModel)localIterator4.next();
          if (!str1.equals(localMusicModel2.categoryId))
            break;
          localMusicModel2.down_num = (1 + localMusicModel2.down_num);
          continue;
        }
        for (String str2 : str1.split(","))
        {
          Iterator localIterator3 = paramMusicReformer.lstMusicCategory.iterator();
          while (localIterator3.hasNext())
          {
            MusicModel localMusicModel1 = (MusicModel)localIterator3.next();
            if (!str2.equals(localMusicModel1.categoryId))
              continue;
            localMusicModel1.down_num = (1 + localMusicModel1.down_num);
          }
        }
      }
    }
    label248: if (this.adapter == null)
    {
      this.adapter = new FitMusicLibraryAdapter(this, paramMusicReformer.lstMusicCategory, R.layout.music_library_item, this.downList);
      this.recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, 1));
      this.recyclerView.setAdapter(this.adapter);
      return;
    }
    this.adapter.setMusicModels(paramMusicReformer.lstMusicCategory);
    this.adapter.setDownLoadList(this.downList);
    this.adapter.notifyDataSetChanged();
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if ((paramT instanceof MusicReformer))
    {
      this.musicReformer = ((MusicReformer)paramT);
      initData(this.musicReformer);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.music_library_layout);
    init();
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    if (this.isFromTab)
    {
      getMenuInflater().inflate(R.menu.local_music_menu, paramMenu);
      TextView localTextView = (TextView)MenuItemCompat.getActionView(paramMenu.findItem(R.id.local_music));
      localTextView.setTextSize(16.0F);
      localTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_626262, null));
      localTextView.setText(getString(R.string.b_24_8_1));
      int i = CompDeviceInfoUtils.convertOfDip(this, 16.0F);
      localTextView.setPadding(i, 0, i, 0);
      localTextView.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          FitMusicLibraryActivity.this.startActivity(new Intent(FitMusicLibraryActivity.this, FitLocalMusicActivity.class));
          AnimationUtil.pageJumpAnim(FitMusicLibraryActivity.this, 0);
        }
      });
    }
    return super.onCreateOptionsMenu(paramMenu);
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (4 == paramInt)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }

  protected void onResume()
  {
    super.onResume();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitMusicLibraryActivity
 * JD-Core Version:    0.6.0
 */