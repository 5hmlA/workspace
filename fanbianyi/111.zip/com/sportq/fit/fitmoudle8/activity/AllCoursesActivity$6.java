package com.sportq.fit.fitmoudle8.activity;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.reformer.CurriculumReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.middlelib.MiddleManager;

class AllCoursesActivity$6
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    if (CompDeviceInfoUtils.checkNetwork())
    {
      AllCoursesActivity.access$300(this.this$0).setVisibility(4);
      AllCoursesActivity.access$100(this.this$0).setVisibility(0);
      FindPresenterInterface localFindPresenterInterface = MiddleManager.getInstance().getFindPresenterImpl(this.this$0, null);
      CurriculumReformer localCurriculumReformer1 = AllCoursesActivity.access$000(this.this$0);
      CurriculumReformer localCurriculumReformer2 = null;
      if (localCurriculumReformer1 == null);
      while (true)
      {
        localFindPresenterInterface.sereenCurriculumInfo(localCurriculumReformer2, this.this$0);
        return;
        localCurriculumReformer2 = AllCoursesActivity.access$000(this.this$0);
      }
    }
    ToastUtils.makeToast(this.this$0, StringUtils.getStringResources(R.string.current_network_again_later));
    AllCoursesActivity.access$300(this.this$0).setVisibility(0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.AllCoursesActivity.6
 * JD-Core Version:    0.6.0
 */