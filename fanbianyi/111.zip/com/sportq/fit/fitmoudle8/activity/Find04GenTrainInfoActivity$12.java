package com.sportq.fit.fitmoudle8.activity;

import android.content.Intent;
import android.view.View;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.dialogmanager.PopWindowMenu.OnPopViewClickListener;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.util.CourseSharePreUtils;
import org.greenrobot.eventbus.EventBus;

class Find04GenTrainInfoActivity$12
  implements PopWindowMenu.OnPopViewClickListener
{
  public void onPopViewClick(View paramView)
  {
    PlanModel localPlanModel;
    if (paramView.getId() == 2 + R.id.menu_content)
      if ("0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)))
      {
        localPlanModel = Find04GenTrainInfoActivity.access$1200(this.this$0)._individualInfo;
        FitJumpImpl.getInstance().findJumpSecActivity(this.this$0, Constant.STR_1, localPlanModel.planName, localPlanModel.planId);
        AnimationUtil.pageJumpAnim(this.this$0, 0);
      }
    label220: label370: 
    do
    {
      do
      {
        do
        {
          return;
          localPlanModel = Find04GenTrainInfoActivity.access$1200(this.this$0)._planInfo;
          break;
          if (paramView.getId() != 3 + R.id.menu_content)
            break label220;
          if (!"0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)))
            continue;
          CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
          {
            public void result(boolean paramBoolean)
            {
              if (paramBoolean)
              {
                Find04GenTrainInfoActivity.access$1702(Find04GenTrainInfoActivity.12.this.this$0, false);
                if ((!"1".equals(Find04GenTrainInfoActivity.access$1200(Find04GenTrainInfoActivity.12.this.this$0)._individualInfo.energyFlag)) || (!"0".equals(Find04GenTrainInfoActivity.access$1200(Find04GenTrainInfoActivity.12.this.this$0)._individualInfo.restTime)) || ("1".equals(BaseApplication.userModel.isVip)) || ("1".equals(BaseApplication.userModel.isHasLosFat)))
                  break label182;
                Find04GenTrainInfoActivity.access$602(Find04GenTrainInfoActivity.12.this.this$0, "1");
                if (StringUtils.isNull(CourseSharePreUtils.getUnlockEnergyHintState(Find04GenTrainInfoActivity.12.this.this$0)))
                  Find04GenTrainInfoActivity.12.this.this$0.dialog.createEnergyHintDialog(new FitInterfaceUtils.DialogListener()
                  {
                    public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
                    {
                      Find04GenTrainInfoActivity.access$500(Find04GenTrainInfoActivity.12.this.this$0);
                      if (paramInt == -1)
                        CourseSharePreUtils.putUnlockEnergyHintState(Find04GenTrainInfoActivity.12.this.this$0, "0");
                    }
                  }
                  , Find04GenTrainInfoActivity.12.this.this$0, "0", Find04GenTrainInfoActivity.access$1200(Find04GenTrainInfoActivity.12.this.this$0)._individualInfo.useTime);
              }
              else
              {
                return;
              }
              Find04GenTrainInfoActivity.access$500(Find04GenTrainInfoActivity.12.this.this$0);
              return;
              label182: Find04GenTrainInfoActivity.access$1300(Find04GenTrainInfoActivity.12.this.this$0, "1");
            }
          }
          , this.this$0, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
          return;
        }
        while ("0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)));
        Intent localIntent3 = new Intent(this.this$0, Find05ChoiceTrainProActivity.class);
        localIntent3.putExtra("plan.id", Find04GenTrainInfoActivity.access$1800(this.this$0));
        localIntent3.putExtra("train.pro", Find04GenTrainInfoActivity.access$1900(this.this$0));
        this.this$0.startActivityForResult(localIntent3, 12);
        AnimationUtil.pageJumpAnim(this.this$0, 0);
        return;
        if (paramView.getId() != 4 + R.id.menu_content)
          break label370;
        if (!"0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)))
          continue;
        Intent localIntent2 = new Intent(this.this$0, Find05RelatedCoursesActivity.class);
        localIntent2.putExtra("related.course.id", Find04GenTrainInfoActivity.access$1800(this.this$0));
        localIntent2.putExtra("intent.from", this.this$0.getIntent().getStringExtra("intent.from"));
        this.this$0.startActivity(localIntent2);
        AnimationUtil.pageJumpAnim(this.this$0, 0);
        EventBus.getDefault().post("finish.train.info.page02");
        PreferencesTools.delValueToTable("jionexitplan", "jionexitkey");
        return;
      }
      while ("0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)));
      CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
      {
        public void result(boolean paramBoolean)
        {
          if (paramBoolean)
            Find04GenTrainInfoActivity.access$400(Find04GenTrainInfoActivity.12.this.this$0);
        }
      }
      , this.this$0, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
      return;
      if (paramView.getId() != 5 + R.id.menu_content)
        continue;
      if ("0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)))
      {
        Find04GenTrainInfoActivity.access$2000(this.this$0);
        return;
      }
      Intent localIntent1 = new Intent(this.this$0, Find05RelatedCoursesActivity.class);
      localIntent1.putExtra("related.course.id", Find04GenTrainInfoActivity.access$1800(this.this$0));
      localIntent1.putExtra("intent.from", this.this$0.getIntent().getStringExtra("intent.from"));
      this.this$0.startActivity(localIntent1);
      AnimationUtil.pageJumpAnim(this.this$0, 0);
      EventBus.getDefault().post("finish.train.info.page02");
      PreferencesTools.delValueToTable("jionexitplan", "jionexitkey");
      return;
    }
    while (paramView.getId() != 6 + R.id.menu_content);
    Find04GenTrainInfoActivity.access$2000(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.12
 * JD-Core Version:    0.6.0
 */