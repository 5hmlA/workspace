package com.sportq.fit.fitmoudle8.activity;

import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools;

class Find04GenTrainInfoActivity$1
  implements Runnable
{
  public void run()
  {
    Find04GenTrainInfoActivity.access$000(this.this$0).joinPlan("0");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.1
 * JD-Core Version:    0.6.0
 */