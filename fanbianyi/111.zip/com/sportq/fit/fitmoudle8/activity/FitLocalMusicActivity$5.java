package com.sportq.fit.fitmoudle8.activity;

import android.content.Intent;
import android.view.View;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.activity.VipCenterActivity;
import com.sportq.fit.middlelib.statistics.FitAction;

class FitLocalMusicActivity$5 extends FitAction
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    SharePreferenceUtils.putBuyVipFromPage("2");
    Intent localIntent = new Intent(this.this$0, VipCenterActivity.class);
    this.this$0.startActivity(localIntent);
    AnimationUtil.pageJumpAnim(this.this$0, 0);
    super.onClick(paramView);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitLocalMusicActivity.5
 * JD-Core Version:    0.6.0
 */