package com.sportq.fit.fitmoudle8.activity;

import com.sportq.fit.fitmoudle8.adapter.Find04GenTrainInfoAdapter;
import com.sportq.fit.fitmoudle8.widget.CourseCommentTitleView;
import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools.InitFinishListener;

class Find04GenTrainInfoActivity$7
  implements Find04TrainInfoTools.InitFinishListener
{
  public void initFinished()
  {
    if (Find04GenTrainInfoActivity.access$700(this.this$0)[1] == 0)
    {
      Find04GenTrainInfoActivity.access$800(this.this$0).getCourseCommentTitleView().getLocationInWindow(Find04GenTrainInfoActivity.access$700(this.this$0));
      Find04GenTrainInfoActivity.access$902(this.this$0, Find04GenTrainInfoActivity.access$1000(this.this$0));
      Find04GenTrainInfoActivity.access$1100(this.this$0).setTag(null);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.7
 * JD-Core Version:    0.6.0
 */