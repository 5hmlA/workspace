package com.sportq.fit.fitmoudle8.activity;

import android.widget.ProgressBar;
import com.sportq.fit.common.utils.ToastUtils;

class AllCoursesActivity$2
  implements Runnable
{
  public void run()
  {
    if ((this.val$strMsg != null) && ((this.val$strMsg instanceof String)))
      ToastUtils.makeToast(this.this$0, (String)this.val$strMsg);
    if (AllCoursesActivity.access$100(this.this$0) != null)
      AllCoursesActivity.access$100(this.this$0).setVisibility(4);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.AllCoursesActivity.2
 * JD-Core Version:    0.6.0
 */