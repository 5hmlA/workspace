package com.sportq.fit.fitmoudle8.activity;

import android.content.Intent;
import android.os.Build.VERSION;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.mipmap;
import com.sportq.fit.fitmoudle8.adapter.Find04GenTrainInfoAdapter;
import com.sportq.fit.fitmoudle8.widget.CourseCommentTitleView;

class Find04GenTrainInfoActivity$19 extends RecyclerView.OnScrollListener
{
  public void onScrollStateChanged(RecyclerView paramRecyclerView, int paramInt)
  {
    if (paramInt == 0)
      Find04GenTrainInfoActivity.access$1100(this.this$0).setTag(null);
  }

  public void onScrolled(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    Find04GenTrainInfoActivity.access$3002(this.this$0, paramInt2 + Find04GenTrainInfoActivity.access$3000(this.this$0));
    int j;
    label189: int i;
    if ((Find04GenTrainInfoActivity.access$800(this.this$0) != null) && (Find04GenTrainInfoActivity.access$800(this.this$0).getCourseCommentTitleView() != null))
    {
      Find04GenTrainInfoActivity.access$800(this.this$0).getCourseCommentTitleView().getLocationInWindow(this.val$titleLocation);
      CourseCommentTitleView localCourseCommentTitleView = Find04GenTrainInfoActivity.access$1100(this.this$0);
      if (this.val$titleLocation[1] <= Find04GenTrainInfoActivity.access$2900(this.this$0))
      {
        j = 0;
        localCourseCommentTitleView.setVisibility(j);
      }
    }
    else
    {
      if ((Find04GenTrainInfoActivity.access$1100(this.this$0).getTag() == null) && (Find04GenTrainInfoActivity.access$800(this.this$0).getCourseCommentTitleView() != null))
      {
        if (Find04GenTrainInfoActivity.access$900(this.this$0) - Find04GenTrainInfoActivity.access$3000(this.this$0) > Find04GenTrainInfoActivity.access$2900(this.this$0) + CompDeviceInfoUtils.convertOfDip(this.this$0, 50.0F))
          break label262;
        Find04GenTrainInfoActivity.access$800(this.this$0).getCourseCommentTitleView().setCurrentPos(1);
        Find04GenTrainInfoActivity.access$1100(this.this$0).setCurrentPos(1);
        Find04GenTrainInfoActivity.access$800(this.this$0).setCurrentIndex(1);
      }
      Find04GenTrainInfoActivity.access$3100(this.this$0).getLocationInWindow(this.val$location);
      i = this.val$location[1] - CompDeviceInfoUtils.getStatusBarHeight(this.this$0);
      if (this.val$location[1] != 0)
        break label301;
      if (this.this$0.toolbar_layout.getAlpha() < 1.0F)
        this.this$0.toolbar_layout.setAlpha(1.0F);
    }
    label262: label301: 
    do
    {
      do
      {
        return;
        j = 8;
        break;
        Find04GenTrainInfoActivity.access$800(this.this$0).getCourseCommentTitleView().setCurrentPos(0);
        Find04GenTrainInfoActivity.access$1100(this.this$0).setCurrentPos(0);
        Find04GenTrainInfoActivity.access$800(this.this$0).setCurrentIndex(0);
        break label189;
        if (i < 0)
        {
          float f = Math.abs(i / CompDeviceInfoUtils.convertOfDip(this.this$0, 100.0F));
          CustomToolBar localCustomToolBar = this.this$0.toolbar;
          if ("0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)));
          for (String str = "单节课程"; ; str = "多节课程")
          {
            localCustomToolBar.setTitle(str);
            this.this$0.toolbar.setNavIcon(R.mipmap.btn_back_black);
            this.this$0.toolbar.setTitleTextColor(ContextCompat.getColor(this.this$0, R.color.color_313131));
            this.this$0.toolbar_layout.setBackgroundResource(R.color.white);
            this.this$0.toolbar_layout.setAlpha(f);
            if (Build.VERSION.SDK_INT >= 21)
              this.this$0.toolbar_layout.setElevation(CompDeviceInfoUtils.convertOfDip(this.this$0, 3.0F));
            this.this$0.toolbar_layout.getChildAt(1).setVisibility(0);
            if (Find04GenTrainInfoActivity.access$3200(this.this$0) == null)
              break;
            if (this.this$0.share_image != null)
            {
              MenuItem localMenuItem4 = Find04GenTrainInfoActivity.access$3200(this.this$0).getItem(0);
              this.this$0.share_image = ((ImageView)localMenuItem4.getActionView());
              this.this$0.share_image.setImageDrawable(ContextCompat.getDrawable(this.this$0, R.mipmap.btn_share_black));
            }
            if ((this.this$0.more_image == null) || (!StringUtils.isNull(this.this$0.getIntent().getStringExtra("customized.id"))))
              break;
            MenuItem localMenuItem3 = Find04GenTrainInfoActivity.access$3200(this.this$0).getItem(1);
            this.this$0.more_image = ((ImageView)localMenuItem3.getActionView());
            this.this$0.more_image.setImageDrawable(ContextCompat.getDrawable(this.this$0, R.mipmap.btn_more_black));
            return;
          }
        }
        this.this$0.toolbar.setTitle("");
        this.this$0.toolbar.setNavIcon(R.mipmap.btn_back_white);
        this.this$0.toolbar.setTitleTextColor(ContextCompat.getColor(this.this$0, R.color.white));
        this.this$0.toolbar.setBackgroundResource(R.color.transparent);
        if (Build.VERSION.SDK_INT >= 21)
          this.this$0.toolbar_layout.setElevation(0.0F);
        this.this$0.toolbar_layout.setBackgroundResource(R.color.transparent);
        this.this$0.toolbar_layout.setAlpha(1.0F);
        this.this$0.toolbar_layout.getChildAt(1).setVisibility(8);
      }
      while (Find04GenTrainInfoActivity.access$3200(this.this$0) == null);
      if (this.this$0.share_image == null)
        continue;
      MenuItem localMenuItem2 = Find04GenTrainInfoActivity.access$3200(this.this$0).getItem(0);
      this.this$0.share_image = ((ImageView)localMenuItem2.getActionView());
      this.this$0.share_image.setImageDrawable(ContextCompat.getDrawable(this.this$0, R.mipmap.btn_share_white));
    }
    while ((this.this$0.more_image == null) || (!StringUtils.isNull(this.this$0.getIntent().getStringExtra("customized.id"))));
    MenuItem localMenuItem1 = Find04GenTrainInfoActivity.access$3200(this.this$0).getItem(1);
    this.this$0.more_image = ((ImageView)localMenuItem1.getActionView());
    this.this$0.more_image.setImageDrawable(ContextCompat.getDrawable(this.this$0, R.mipmap.btn_more_white));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.19
 * JD-Core Version:    0.6.0
 */