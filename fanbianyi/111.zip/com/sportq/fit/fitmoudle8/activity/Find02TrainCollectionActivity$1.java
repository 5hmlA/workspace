package com.sportq.fit.fitmoudle8.activity;

import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.reformer.GrpReformer;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle8.R.color;

class Find02TrainCollectionActivity$1 extends RecyclerView.OnScrollListener
{
  private int totalDy = 0;

  public void onScrollStateChanged(RecyclerView paramRecyclerView, int paramInt)
  {
    super.onScrollStateChanged(paramRecyclerView, paramInt);
  }

  public void onScrolled(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    super.onScrolled(paramRecyclerView, paramInt1, paramInt2);
    this.totalDy -= paramInt2;
    if (Math.abs(this.totalDy) > 300)
    {
      Find02TrainCollectionActivity.access$000(this.this$0).setAppTitle(this.val$grpReformer._planModel.planName);
      Find02TrainCollectionActivity.access$000(this.this$0).setToolbarBg(R.color.color_313131);
      return;
    }
    Find02TrainCollectionActivity.access$000(this.this$0).setAppTitle("");
    Find02TrainCollectionActivity.access$000(this.this$0).setToolbarBg(17170445);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find02TrainCollectionActivity.1
 * JD-Core Version:    0.6.0
 */