package com.sportq.fit.fitmoudle8.activity;

import android.widget.TextView;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.widget.CustomScrollView;
import com.sportq.fit.fitmoudle8.widget.CustomScrollView.ScrollViewListener;

class FitMusicSettingActivity$1
  implements CustomScrollView.ScrollViewListener
{
  public void onScrollChanged(CustomScrollView paramCustomScrollView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int[] arrayOfInt1 = new int[2];
    int[] arrayOfInt2 = new int[2];
    int[] arrayOfInt3 = new int[2];
    int[] arrayOfInt4 = new int[2];
    FitMusicSettingActivity.access$000(this.this$0).getLocationInWindow(arrayOfInt1);
    FitMusicSettingActivity.access$100(this.this$0).getLocationInWindow(arrayOfInt2);
    FitMusicSettingActivity.access$200(this.this$0).getLocationInWindow(arrayOfInt3);
    FitMusicSettingActivity.access$300(this.this$0).getLocationInWindow(arrayOfInt4);
    if (arrayOfInt2[1] <= arrayOfInt1[1])
    {
      if (arrayOfInt4[1] <= arrayOfInt1[1])
      {
        if (arrayOfInt3[1] <= arrayOfInt1[1])
        {
          FitMusicSettingActivity.access$000(this.this$0).setVisibility(0);
          FitMusicSettingActivity.access$000(this.this$0).setText(StringUtils.getStringResources(R.string.b_84_2));
          FitMusicSettingActivity.access$100(this.this$0).setVisibility(4);
          FitMusicSettingActivity.access$300(this.this$0).setVisibility(4);
          return;
        }
        FitMusicSettingActivity.access$300(this.this$0).setVisibility(0);
        FitMusicSettingActivity.access$000(this.this$0).setVisibility(4);
        return;
      }
      FitMusicSettingActivity.access$000(this.this$0).setVisibility(0);
      FitMusicSettingActivity.access$000(this.this$0).setText(StringUtils.getStringResources(R.string.b_84_1));
      FitMusicSettingActivity.access$100(this.this$0).setVisibility(4);
      FitMusicSettingActivity.access$300(this.this$0).setVisibility(4);
      return;
    }
    FitMusicSettingActivity.access$000(this.this$0).setVisibility(4);
    FitMusicSettingActivity.access$100(this.this$0).setVisibility(0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitMusicSettingActivity.1
 * JD-Core Version:    0.6.0
 */