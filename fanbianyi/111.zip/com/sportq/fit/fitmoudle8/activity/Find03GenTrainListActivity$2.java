package com.sportq.fit.fitmoudle8.activity;

import android.content.res.Resources;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.widget.DrawCenterButton;
import com.sportq.fit.fitmoudle8.widget.guide.UpgradeGuide;
import com.sportq.fit.fitmoudle8.widget.guide.UpgradeGuide.OnGuideCloseListener;

class Find03GenTrainListActivity$2
  implements Runnable
{
  public void run()
  {
    String str1 = SharePreferenceUtils.getGuideName(this.this$0, "moreCourse_head_guide");
    String str2 = SharePreferenceUtils.getGuideName(this.this$0, "joinCourse_guide");
    if (StringUtils.isNull(str1))
      UpgradeGuide.showGuideUi1(Find03GenTrainListActivity.access$400(this.this$0), this.this$0, 3, new UpgradeGuide.OnGuideCloseListener(str2)
      {
        public void onClose(String paramString)
        {
          SharePreferenceUtils.putGuideName(Find03GenTrainListActivity.2.this.this$0, "moreCourse_head_guide", "moreCourse_head_guide");
          if ((StringUtils.isNull(this.val$JoinClassGuide)) && (Find03GenTrainListActivity.access$500(Find03GenTrainListActivity.2.this.this$0).getVisibility() == 0) && (Find03GenTrainListActivity.2.this.this$0.getResources().getString(R.string.join_train_hint).equals(Find03GenTrainListActivity.access$500(Find03GenTrainListActivity.2.this.this$0).getText())))
            UpgradeGuide.showGuideUi1(Find03GenTrainListActivity.access$500(Find03GenTrainListActivity.2.this.this$0), Find03GenTrainListActivity.2.this.this$0, 4, new UpgradeGuide.OnGuideCloseListener()
            {
              public void onClose(String paramString)
              {
                SharePreferenceUtils.putGuideName(Find03GenTrainListActivity.2.this.this$0, "joinCourse_guide", "joinCourse_guide");
              }
            });
        }
      });
    do
      return;
    while ((!StringUtils.isNull(str2)) || (Find03GenTrainListActivity.access$500(this.this$0).getVisibility() != 0) || (!this.this$0.getResources().getString(R.string.join_train_hint).equals(Find03GenTrainListActivity.access$500(this.this$0).getText())));
    UpgradeGuide.showGuideUi1(Find03GenTrainListActivity.access$500(this.this$0), this.this$0, 4, new UpgradeGuide.OnGuideCloseListener()
    {
      public void onClose(String paramString)
      {
        SharePreferenceUtils.putGuideName(Find03GenTrainListActivity.2.this.this$0, "joinCourse_guide", "joinCourse_guide");
      }
    });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity.2
 * JD-Core Version:    0.6.0
 */