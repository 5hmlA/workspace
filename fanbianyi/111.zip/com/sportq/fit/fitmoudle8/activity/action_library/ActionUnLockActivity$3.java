package com.sportq.fit.fitmoudle8.activity.action_library;

import android.content.res.Resources;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.presenter.PresenterImpl;

class ActionUnLockActivity$3
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -2)
    {
      if (!CompDeviceInfoUtils.checkNetwork())
        ToastUtils.makeToast(this.this$0, StringUtils.getStringResources(R.string.g_20_1));
    }
    else
      return;
    this.this$0.dialog.createProgressDialog(this.this$0, this.this$0.getResources().getString(R.string.wait_hint));
    new PresenterImpl(this.this$0).unlockAction(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionUnLockActivity.3
 * JD-Core Version:    0.6.0
 */