package com.sportq.fit.fitmoudle8.activity.action_library;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle8.R.layout;
import com.sportq.fit.fitmoudle8.adapter.ActionSearchHistoryAdapter;
import com.sportq.fit.fitmoudle8.util.CourseSharePreUtils;
import java.util.ArrayList;

class ActionSearchActivity$8
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    CourseSharePreUtils.putActionHistoryArray(new ArrayList());
    ActionSearchActivity.access$500(this.this$0).setAdapter(new ActionSearchHistoryAdapter(this.this$0, new ArrayList(), R.layout.search_history_item));
    ActionSearchActivity.access$500(this.this$0).removeFooterView(ActionSearchActivity.access$400(this.this$0));
    ActionSearchActivity.access$702(this.this$0, null);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionSearchActivity.8
 * JD-Core Version:    0.6.0
 */