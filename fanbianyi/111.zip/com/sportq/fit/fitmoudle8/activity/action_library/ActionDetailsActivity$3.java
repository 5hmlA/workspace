package com.sportq.fit.fitmoudle8.activity.action_library;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.fitmoudle.widget.PreviewContentLayout;

class ActionDetailsActivity$3
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    this.this$0.detailedDescription.setSelected(false);
    this.this$0.frequentFault.setSelected(true);
    this.this$0.muscleTipsHint.setVisibility(8);
    this.this$0.muscleImg.setVisibility(8);
    this.this$0.commentLayout.setContents(ActionDetailsActivity.access$000(this.this$0).lstError, false);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionDetailsActivity.3
 * JD-Core Version:    0.6.0
 */