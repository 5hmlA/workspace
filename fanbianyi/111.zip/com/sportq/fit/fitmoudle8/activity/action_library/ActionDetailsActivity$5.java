package com.sportq.fit.fitmoudle8.activity.action_library;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Handler;
import android.view.View;
import android.widget.ProgressBar;

class ActionDetailsActivity$5
  implements MediaPlayer.OnPreparedListener
{
  public void onPrepared(MediaPlayer paramMediaPlayer)
  {
    paramMediaPlayer.start();
    new Handler().postDelayed(new Runnable()
    {
      public void run()
      {
        if (ActionDetailsActivity.5.this.this$0.v_blind_flange != null)
          ActionDetailsActivity.5.this.this$0.v_blind_flange.setVisibility(8);
        if (ActionDetailsActivity.5.this.this$0.loader_icon != null)
          ActionDetailsActivity.5.this.this$0.loader_icon.setVisibility(8);
      }
    }
    , 0L);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionDetailsActivity.5
 * JD-Core Version:    0.6.0
 */