package com.sportq.fit.fitmoudle8.activity.action_library;

import com.rong.map.mylibrary.SlidingFinishLayout.OnSlidingFinishListener;
import com.sportq.fit.fitmoudle.AnimationUtil;

class ActionDetailsActivity$1
  implements SlidingFinishLayout.OnSlidingFinishListener
{
  public void onSlidingFinish()
  {
    this.this$0.finish();
    AnimationUtil.pagePopNotAnim(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionDetailsActivity.1
 * JD-Core Version:    0.6.0
 */