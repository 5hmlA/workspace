package com.sportq.fit.fitmoudle8.activity.action_library;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;

class ActionSearchActivity$4
  implements View.OnTouchListener
{
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    CompDeviceInfoUtils.hideSoftInput(this.this$0, ActionSearchActivity.access$000(this.this$0));
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionSearchActivity.4
 * JD-Core Version:    0.6.0
 */