package com.sportq.fit.fitmoudle8.activity.action_library;

import com.sportq.fit.common.event.UnLockActionEvent;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle8.reformer.reformer.UnLockActionReformer;
import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools.UnLockDismissListener;
import org.greenrobot.eventbus.EventBus;

class ActionUnLockActivity$1
  implements Find04TrainInfoTools.UnLockDismissListener
{
  public void dialogDismiss()
  {
    EventBus.getDefault().post(new UnLockActionEvent(this.val$unLockActionReformer.endTime));
    this.this$0.finish();
    AnimationUtil.pageJumpAnim(this.this$0, 1);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionUnLockActivity.1
 * JD-Core Version:    0.6.0
 */