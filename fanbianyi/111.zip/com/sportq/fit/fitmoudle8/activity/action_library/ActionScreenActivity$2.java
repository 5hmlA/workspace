package com.sportq.fit.fitmoudle8.activity.action_library;

import com.sportq.fit.fitmoudle8.presenter.PresenterImpl;
import com.sportq.fit.fitmoudle8.reformer.reformer.SelActionReformer;

class ActionScreenActivity$2
  implements Runnable
{
  public void run()
  {
    new PresenterImpl(this.this$0).selectActionList(this.this$0, this.val$mSelActionReformer);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionScreenActivity.2
 * JD-Core Version:    0.6.0
 */