package com.sportq.fit.fitmoudle8.activity.action_library;

import android.content.Intent;
import android.view.View;
import android.widget.RelativeLayout;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle8.reformer.model.EntactClassifyInfoData;
import com.sportq.fit.fitmoudle8.reformer.reformer.ActionClassifyReformer;
import java.util.ArrayList;
import org.byteam.superadapter.OnItemClickListener;

class ActionClassifyActivity$1
  implements OnItemClickListener
{
  public void onItemClick(View paramView, int paramInt1, int paramInt2)
  {
    Intent localIntent = new Intent(this.this$0, ActionScreenActivity.class);
    localIntent.putExtra("ACTION_NAME", ((EntactClassifyInfoData)ActionClassifyActivity.access$000(this.this$0).lstActClassifyInfo.get(paramInt2)).actClassifyName);
    localIntent.putExtra("ACTION_ID", ((EntactClassifyInfoData)ActionClassifyActivity.access$000(this.this$0).lstActClassifyInfo.get(paramInt2)).actClassifyId);
    if (ActionClassifyActivity.access$100(this.this$0).getVisibility() == 0);
    for (String str = "1"; ; str = "0")
    {
      localIntent.putExtra("ACTION_TYPE", str);
      this.this$0.startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this.this$0, 0);
      return;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionClassifyActivity.1
 * JD-Core Version:    0.6.0
 */