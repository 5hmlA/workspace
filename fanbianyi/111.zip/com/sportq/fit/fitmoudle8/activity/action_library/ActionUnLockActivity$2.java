package com.sportq.fit.fitmoudle8.activity.action_library;

import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;

class ActionUnLockActivity$2
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -2)
    {
      this.this$0.dialog.createProgressDialog(this.this$0, "请稍后...");
      new PresenterImpl(this.this$0).signSearch(this.this$0);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionUnLockActivity.2
 * JD-Core Version:    0.6.0
 */