package com.sportq.fit.fitmoudle8.activity.action_library;

import android.support.v4.view.ViewPager.OnPageChangeListener;

class ActionRelatedActivity$ActionRelatedViewChangeListener
  implements ViewPager.OnPageChangeListener
{
  private ActionRelatedActivity$ActionRelatedViewChangeListener(ActionRelatedActivity paramActionRelatedActivity)
  {
  }

  public void onPageScrollStateChanged(int paramInt)
  {
  }

  public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
  {
  }

  public void onPageSelected(int paramInt)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionRelatedActivity.ActionRelatedViewChangeListener
 * JD-Core Version:    0.6.0
 */