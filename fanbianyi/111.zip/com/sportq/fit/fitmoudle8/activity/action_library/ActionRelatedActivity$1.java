package com.sportq.fit.fitmoudle8.activity.action_library;

import android.content.DialogInterface;
import android.content.Intent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.fitmoudle.AnimationUtil;

class ActionRelatedActivity$1
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -2)
    {
      Intent localIntent = new Intent(this.this$0, ActionUnLockActivity.class);
      this.this$0.startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this.this$0, 0);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionRelatedActivity.1
 * JD-Core Version:    0.6.0
 */