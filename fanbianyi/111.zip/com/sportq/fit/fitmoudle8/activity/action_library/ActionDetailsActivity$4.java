package com.sportq.fit.fitmoudle8.activity.action_library;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import com.sportq.fit.common.utils.LogUtils;

class ActionDetailsActivity$4
  implements MediaPlayer.OnErrorListener
{
  public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2)
  {
    LogUtils.d("ActionDetailsActivity->onError->", String.valueOf(paramInt1));
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionDetailsActivity.4
 * JD-Core Version:    0.6.0
 */