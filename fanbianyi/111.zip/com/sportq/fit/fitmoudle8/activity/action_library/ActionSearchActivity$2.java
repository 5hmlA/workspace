package com.sportq.fit.fitmoudle8.activity.action_library;

import android.text.Editable;
import android.text.TextWatcher;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;

class ActionSearchActivity$2
  implements TextWatcher
{
  public void afterTextChanged(Editable paramEditable)
  {
    ActionSearchActivity.access$102(this.this$0, paramEditable.toString());
    if (!StringUtils.isNull(ActionSearchActivity.access$100(this.this$0)))
    {
      ActionSearchActivity.access$200(this.this$0);
      return;
    }
    ActionSearchActivity.access$300(this.this$0);
  }

  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionSearchActivity.2
 * JD-Core Version:    0.6.0
 */