package com.sportq.fit.fitmoudle8.activity.action_library;

import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import java.util.ArrayList;

class ActionSearchActivity$7
  implements AdapterView.OnItemClickListener
{
  @Instrumented
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    VdsAgent.onItemClick(this, paramAdapterView, paramView, paramInt, paramLong);
    if ((paramInt >= 0) && (paramInt < ActionSearchActivity.access$600(this.this$0).size()))
    {
      ActionSearchActivity.access$102(this.this$0, (String)ActionSearchActivity.access$600(this.this$0).get(paramInt));
      ActionSearchActivity.access$000(this.this$0).setText(ActionSearchActivity.access$100(this.this$0));
      ActionSearchActivity.access$000(this.this$0).setSelection(ActionSearchActivity.access$100(this.this$0).length());
      ActionSearchActivity.access$200(this.this$0);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionSearchActivity.7
 * JD-Core Version:    0.6.0
 */