package com.sportq.fit.fitmoudle8.activity.action_library;

import android.content.Intent;
import android.view.View;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import com.sportq.fit.common.reformer.SystemTimeReformer;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle8.reformer.reformer.SelActionReformer;
import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools;
import java.util.ArrayList;
import org.byteam.superadapter.OnItemClickListener;

class ActionScreenActivity$1
  implements OnItemClickListener
{
  public void onItemClick(View paramView, int paramInt1, int paramInt2)
  {
    if ((ActionScreenActivity.access$200(this.this$0).checkIsUnLock(ActionScreenActivity.access$000(this.this$0).timeKey, (ResponseModel.ActionData)ActionScreenActivity.access$100(this.this$0).lstActDetInfo.get(paramInt2 - 1))) || ("1".equals(BaseApplication.userModel.isVip)))
    {
      Intent localIntent1 = new Intent(this.this$0, ActionDetailsActivity.class);
      localIntent1.putExtra("intent.current.actionModel", paramInt2 - 1);
      localIntent1.putExtra("original.data", ActionScreenActivity.access$100(this.this$0).lstActDetInfo);
      localIntent1.putExtra("system.time", ActionScreenActivity.access$000(this.this$0).timeKey);
      this.this$0.startActivity(localIntent1);
      AnimationUtil.pageJumpAnim(this.this$0, 0);
      return;
    }
    Intent localIntent2 = new Intent(this.this$0, ActionUnLockActivity.class);
    this.this$0.startActivity(localIntent2);
    AnimationUtil.pageJumpAnim(this.this$0, 0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.action_library.ActionScreenActivity.1
 * JD-Core Version:    0.6.0
 */