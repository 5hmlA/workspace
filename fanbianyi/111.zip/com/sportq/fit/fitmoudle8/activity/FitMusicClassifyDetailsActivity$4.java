package com.sportq.fit.fitmoudle8.activity;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.reformer.model.MusicModel;
import java.util.ArrayList;

class FitMusicClassifyDetailsActivity$4
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    String str1 = CompDeviceInfoUtils.getAPNType(this.this$0);
    if (("-1".equals(str1)) && (!"2".equals(((MusicModel)FitMusicClassifyDetailsActivity.access$200(this.this$0).get(this.val$index)).musicType)))
    {
      ToastUtils.makeToast(this.this$0, com.sportq.fit.common.utils.StringUtils.getStringResources(R.string.network_useless_check_settings));
      return;
    }
    if (!FitMusicClassifyDetailsActivity.access$400(this.this$0))
    {
      FitMusicClassifyDetailsActivity.access$500(this.this$0, this.val$mImg01, this.val$index);
      return;
    }
    if ((!"1".equals(str1)) && (!"2".equals(((MusicModel)FitMusicClassifyDetailsActivity.access$200(this.this$0).get(this.val$index)).musicType)))
    {
      int i = com.sportq.fit.common.utils.StringUtils.string2Int(((MusicModel)FitMusicClassifyDetailsActivity.access$200(this.this$0).get(this.val$index)).musicSize);
      if (i > 1024);
      for (String str2 = com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.getM(i) + "MB"; ; str2 = i + "KB")
      {
        String str3 = String.format(com.sportq.fit.common.utils.StringUtils.getStringResources(R.string.play_music_hint), new Object[] { str2 });
        this.this$0.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
        {
          public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
          {
            if (paramInt == -1)
            {
              FitMusicClassifyDetailsActivity.access$402(FitMusicClassifyDetailsActivity.4.this.this$0, false);
              FitMusicClassifyDetailsActivity.access$500(FitMusicClassifyDetailsActivity.4.this.this$0, FitMusicClassifyDetailsActivity.4.this.val$mImg01, FitMusicClassifyDetailsActivity.4.this.val$index);
            }
          }
        }
        , this.this$0, "", str3, com.sportq.fit.common.utils.StringUtils.getStringResources(R.string.make_sure), com.sportq.fit.common.utils.StringUtils.getStringResources(R.string.cancel_hint));
        return;
      }
    }
    FitMusicClassifyDetailsActivity.access$500(this.this$0, this.val$mImg01, this.val$index);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitMusicClassifyDetailsActivity.4
 * JD-Core Version:    0.6.0
 */