package com.sportq.fit.fitmoudle8.activity;

import android.view.animation.AlphaAnimation;
import android.widget.RelativeLayout;

class FitMusicSettingActivity$3
  implements Runnable
{
  public void run()
  {
    FitMusicSettingActivity.access$500(this.this$0).setVisibility(0);
    if (this.val$delayTime != 0)
    {
      AlphaAnimation localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
      localAlphaAnimation.setDuration(500L);
      FitMusicSettingActivity.access$500(this.this$0).setAnimation(localAlphaAnimation);
    }
    if (FitMusicSettingActivity.access$600(this.this$0) == null)
      FitMusicSettingActivity.access$700(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitMusicSettingActivity.3
 * JD-Core Version:    0.6.0
 */