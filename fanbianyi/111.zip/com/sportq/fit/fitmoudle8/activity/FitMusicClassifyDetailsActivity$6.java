package com.sportq.fit.fitmoudle8.activity;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;

class FitMusicClassifyDetailsActivity$6
  implements MediaPlayer.OnErrorListener
{
  public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2)
  {
    if (FitMusicClassifyDetailsActivity.access$600(this.this$0) != null)
    {
      FitMusicClassifyDetailsActivity.access$600(this.this$0).stop();
      FitMusicClassifyDetailsActivity.access$600(this.this$0).release();
      FitMusicClassifyDetailsActivity.access$602(this.this$0, null);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitMusicClassifyDetailsActivity.6
 * JD-Core Version:    0.6.0
 */