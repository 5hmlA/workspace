package com.sportq.fit.fitmoudle8.activity;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.util.CourseSharePreUtils;

class Find02TrainCategoryActivity$1
  implements Runnable
{
  public void run()
  {
    if (Find02TrainCategoryActivity.access$000(this.this$0).getHeight() + this.val$intro_linear.getHeight() < BaseApplication.screenHeight - CompDeviceInfoUtils.convertOfDip(this.this$0, 55.0F))
    {
      ((RelativeLayout.LayoutParams)this.val$intro_linear.getLayoutParams()).addRule(3, R.id.energy_course_intro_icn);
      ((RelativeLayout.LayoutParams)this.val$intro_linear.getLayoutParams()).height = -1;
      if (("4".equals(Find02TrainCategoryActivity.access$100(this.this$0))) && (StringUtils.isNull(CourseSharePreUtils.getEnergyIntroShowState(this.this$0))))
      {
        Find02TrainCategoryActivity.access$200(this.this$0).setVisibility(0);
        Find02TrainCategoryActivity.access$300(this.this$0).setVisibility(4);
        CourseSharePreUtils.putEnergyIntroShowState(this.this$0, "0");
      }
    }
    while (true)
    {
      this.val$intro_linear.requestLayout();
      return;
      ((RelativeLayout.LayoutParams)this.val$intro_linear.getLayoutParams()).addRule(8, -1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find02TrainCategoryActivity.1
 * JD-Core Version:    0.6.0
 */