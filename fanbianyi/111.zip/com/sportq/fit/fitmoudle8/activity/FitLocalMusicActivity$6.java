package com.sportq.fit.fitmoudle8.activity;

import android.graphics.drawable.AnimationDrawable;
import android.view.View;
import android.widget.ImageView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

class FitLocalMusicActivity$6 extends FitAction
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    FitLocalMusicActivity.access$602(this.this$0, (AnimationDrawable)this.val$mImg1.getDrawable());
    if (this.this$0.img01 == this.val$mImg1)
      if (this.val$mImg1.getVisibility() == 0)
      {
        this.val$mImg1.setVisibility(8);
        FitLocalMusicActivity.access$600(this.this$0).stop();
      }
    while (true)
    {
      this.this$0.img01 = this.val$mImg1;
      String str = VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME + (String)FitLocalMusicActivity.access$300(this.this$0).get(this.val$position);
      FitLocalMusicActivity.access$700(this.this$0, str);
      return;
      this.val$mImg1.setVisibility(0);
      FitLocalMusicActivity.access$600(this.this$0).start();
      continue;
      if (this.this$0.img01 != null)
      {
        ((AnimationDrawable)this.this$0.img01.getDrawable()).stop();
        this.this$0.img01.setVisibility(8);
      }
      this.val$mImg1.setVisibility(0);
      FitLocalMusicActivity.access$600(this.this$0).start();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.FitLocalMusicActivity.6
 * JD-Core Version:    0.6.0
 */