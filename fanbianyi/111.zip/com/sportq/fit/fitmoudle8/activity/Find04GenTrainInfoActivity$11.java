package com.sportq.fit.fitmoudle8.activity;

import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.fitmoudle8.adapter.Find04GenTrainInfoAdapter;
import com.sportq.fit.middlelib.statistics.FitAction;

class Find04GenTrainInfoActivity$11
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    if ("more_image".equals(paramView.getTag()))
    {
      FitAction.temporaryPCB("p.c.toolBar|!||!||!|", "btn_more");
      Find04GenTrainInfoActivity.access$1600(this.this$0);
    }
    do
      return;
    while (!"share_image".equals(paramView.getTag()));
    PlanModel localPlanModel = Find04GenTrainInfoActivity.access$800(this.this$0).getPlanModel();
    if ("0".equals(Find04GenTrainInfoActivity.access$200(this.this$0)));
    for (String str = "0"; ; str = "1")
    {
      localPlanModel.trainType = str;
      if (Find04GenTrainInfoActivity.access$1200(this.this$0)._planInfo == null)
        break;
      this.this$0.dialog.showShareChoiseDialog(this.this$0, 7, localPlanModel, this.this$0.dialog);
      return;
    }
    this.this$0.dialog.showShareChoiseDialog(this.this$0, 6, localPlanModel, this.this$0.dialog);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.11
 * JD-Core Version:    0.6.0
 */