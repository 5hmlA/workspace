package com.sportq.fit.fitmoudle8.activity;

import android.os.Build.VERSION;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.mipmap;

class Find03GenTrainListActivity$4 extends RecyclerView.OnScrollListener
{
  public void onScrolled(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    int[] arrayOfInt = new int[2];
    Find03GenTrainListActivity.access$400(this.this$0).getLocationInWindow(arrayOfInt);
    int i = arrayOfInt[1] - CompDeviceInfoUtils.getStatusBarHeight(this.this$0);
    if (arrayOfInt[1] == 0);
    do
    {
      while (true)
      {
        return;
        if (i >= 0)
          break;
        float f = Math.abs(i / CompDeviceInfoUtils.convertOfDip(this.this$0, 100.0F));
        Find03GenTrainListActivity.access$700(this.this$0).setTitle("多节课程");
        Find03GenTrainListActivity.access$700(this.this$0).setNavIcon(R.mipmap.btn_back_black);
        Find03GenTrainListActivity.access$700(this.this$0).setTitleTextColor(ContextCompat.getColor(this.this$0, R.color.color_313131));
        this.this$0.toolbar_layout.setBackgroundResource(R.color.white);
        this.this$0.toolbar_layout.setAlpha(f);
        if (Build.VERSION.SDK_INT >= 21)
          this.this$0.toolbar_layout.setElevation(CompDeviceInfoUtils.convertOfDip(this.this$0, 3.0F));
        this.this$0.toolbar_layout.getChildAt(1).setVisibility(0);
        if ((Find03GenTrainListActivity.access$800(this.this$0) == null) || (Find03GenTrainListActivity.access$900(this.this$0) == null))
          continue;
        MenuItem localMenuItem2 = Find03GenTrainListActivity.access$800(this.this$0).getItem(0);
        Find03GenTrainListActivity.access$902(this.this$0, (ImageView)localMenuItem2.getActionView());
        Find03GenTrainListActivity.access$900(this.this$0).setImageDrawable(ContextCompat.getDrawable(this.this$0, R.mipmap.btn_share_black));
        return;
      }
      Find03GenTrainListActivity.access$700(this.this$0).setTitle("");
      Find03GenTrainListActivity.access$700(this.this$0).setNavIcon(R.mipmap.btn_back_white);
      Find03GenTrainListActivity.access$700(this.this$0).setTitleTextColor(ContextCompat.getColor(this.this$0, R.color.white));
      Find03GenTrainListActivity.access$700(this.this$0).setBackgroundResource(R.color.transparent);
      if (Build.VERSION.SDK_INT >= 21)
        this.this$0.toolbar_layout.setElevation(0.0F);
      this.this$0.toolbar_layout.setBackgroundResource(R.color.transparent);
      this.this$0.toolbar_layout.setAlpha(1.0F);
      this.this$0.toolbar_layout.getChildAt(1).setVisibility(8);
    }
    while ((Find03GenTrainListActivity.access$800(this.this$0) == null) || (Find03GenTrainListActivity.access$900(this.this$0) == null));
    MenuItem localMenuItem1 = Find03GenTrainListActivity.access$800(this.this$0).getItem(0);
    Find03GenTrainListActivity.access$902(this.this$0, (ImageView)localMenuItem1.getActionView());
    Find03GenTrainListActivity.access$900(this.this$0).setImageDrawable(ContextCompat.getDrawable(this.this$0, R.mipmap.btn_share_white));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity.4
 * JD-Core Version:    0.6.0
 */