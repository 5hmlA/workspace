package com.sportq.fit.fitmoudle8.activity;

import android.content.res.Resources;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle8.R.string;

class Find04GenTrainInfoActivity$9
  implements CompDeviceInfoUtils.applyPerListener
{
  public void result(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      this.this$0.dialog.createProgressDialog(this.this$0, this.this$0.getResources().getString(R.string.wait_hint));
      if ((!CompDeviceInfoUtils.checkNetwork()) && ("1".equals(Find04GenTrainInfoActivity.access$1200(this.this$0)._individualInfo.energyFlag)) && (!"1".equals(BaseApplication.userModel.isVip)) && ("0".equals(BaseApplication.userModel.isHasLosFat)))
      {
        ToastUtils.makeToast(this.this$0, StringUtils.getStringResources(R.string.g_20_1));
        this.this$0.dialog.closeDialog();
      }
    }
    else
    {
      return;
    }
    Find04GenTrainInfoActivity.access$1300(this.this$0, "0");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity.9
 * JD-Core Version:    0.6.0
 */