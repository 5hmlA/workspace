package com.sportq.fit.fitmoudle8.widget;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MusicDownLoadTool
{
  private MusicDownLoadListener listener;
  private Context mContext;
  private ExecutorService threadPool;

  public MusicDownLoadTool(MusicDownLoadListener paramMusicDownLoadListener, Context paramContext)
  {
    this.mContext = paramContext;
    this.listener = paramMusicDownLoadListener;
    this.threadPool = Executors.newFixedThreadPool(1 + Runtime.getRuntime().availableProcessors());
  }

  // ERROR //
  private void makeMusicDirectory(String paramString)
  {
    // Byte code:
    //   0: new 53	java/io/File
    //   3: dup
    //   4: getstatic 59	com/sportq/fit/common/version/VersionUpdateCheck:ALBUM_FILE_BASE_PATH	Ljava/lang/String;
    //   7: invokespecial 61	java/io/File:<init>	(Ljava/lang/String;)V
    //   10: astore_2
    //   11: aload_2
    //   12: invokevirtual 65	java/io/File:exists	()Z
    //   15: ifne +57 -> 72
    //   18: aload_2
    //   19: invokevirtual 68	java/io/File:mkdir	()Z
    //   22: pop
    //   23: new 53	java/io/File
    //   26: dup
    //   27: new 70	java/lang/StringBuilder
    //   30: dup
    //   31: invokespecial 71	java/lang/StringBuilder:<init>	()V
    //   34: getstatic 59	com/sportq/fit/common/version/VersionUpdateCheck:ALBUM_FILE_BASE_PATH	Ljava/lang/String;
    //   37: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: aload_1
    //   41: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: ldc 77
    //   46: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: invokevirtual 81	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   52: invokespecial 61	java/io/File:<init>	(Ljava/lang/String;)V
    //   55: astore 5
    //   57: aload 5
    //   59: invokevirtual 65	java/io/File:exists	()Z
    //   62: ifne +67 -> 129
    //   65: aload 5
    //   67: invokevirtual 68	java/io/File:mkdir	()Z
    //   70: pop
    //   71: return
    //   72: aload_2
    //   73: invokevirtual 84	java/io/File:isDirectory	()Z
    //   76: ifne -53 -> 23
    //   79: aload_2
    //   80: invokevirtual 87	java/io/File:delete	()Z
    //   83: pop
    //   84: aload_0
    //   85: aload_1
    //   86: invokespecial 89	com/sportq/fit/fitmoudle8/widget/MusicDownLoadTool:makeMusicDirectory	(Ljava/lang/String;)V
    //   89: return
    //   90: astore_3
    //   91: aload_3
    //   92: invokestatic 95	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   95: new 70	java/lang/StringBuilder
    //   98: dup
    //   99: invokespecial 71	java/lang/StringBuilder:<init>	()V
    //   102: getstatic 59	com/sportq/fit/common/version/VersionUpdateCheck:ALBUM_FILE_BASE_PATH	Ljava/lang/String;
    //   105: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: aload_1
    //   109: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: ldc 77
    //   114: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: invokevirtual 81	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   120: invokestatic 100	com/sportq/fit/common/utils/FileUtils:delAllFile	(Ljava/lang/String;)V
    //   123: aload_0
    //   124: aload_1
    //   125: invokespecial 89	com/sportq/fit/fitmoudle8/widget/MusicDownLoadTool:makeMusicDirectory	(Ljava/lang/String;)V
    //   128: return
    //   129: aload 5
    //   131: invokevirtual 84	java/io/File:isDirectory	()Z
    //   134: ifne -63 -> 71
    //   137: aload 5
    //   139: invokevirtual 87	java/io/File:delete	()Z
    //   142: pop
    //   143: aload_0
    //   144: aload_1
    //   145: invokespecial 89	com/sportq/fit/fitmoudle8/widget/MusicDownLoadTool:makeMusicDirectory	(Ljava/lang/String;)V
    //   148: goto -77 -> 71
    //   151: astore_3
    //   152: goto -61 -> 91
    //
    // Exception table:
    //   from	to	target	type
    //   11	23	90	java/lang/Exception
    //   23	57	90	java/lang/Exception
    //   72	89	90	java/lang/Exception
    //   57	71	151	java/lang/Exception
    //   129	148	151	java/lang/Exception
  }

  private void requestNetwork(int paramInt, String paramString1, String paramString2, RequestListener paramRequestListener)
  {
    makeMusicDirectory(paramString2);
    String str1 = VersionUpdateCheck.ALBUM_FILE_BASE_PATH + paramString2 + "/";
    String str2 = str1 + paramString1.substring(1 + paramString1.lastIndexOf("/"));
    int i;
    do
    {
      InputStream localInputStream;
      FileOutputStream localFileOutputStream;
      try
      {
        File localFile = new File(str2);
        if (localFile.exists())
          localFile.delete();
        URLConnection localURLConnection = new URL(paramString1).openConnection();
        localInputStream = localURLConnection.getInputStream();
        byte[] arrayOfByte = new byte[1024];
        localFileOutputStream = new FileOutputStream(str2);
        i = 0;
        int j = localURLConnection.getContentLength();
        int k = 0;
        while (true)
        {
          int m = localInputStream.read(arrayOfByte);
          if (m == -1)
            break;
          k += m;
          i = (int)(100.0F * (k / j));
          paramRequestListener.onRequestPro(paramInt, i);
          localFileOutputStream.write(arrayOfByte, 0, m);
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return;
      }
      localFileOutputStream.close();
      localInputStream.close();
    }
    while (i == 100);
    paramRequestListener.onRequestPro(paramInt, 100);
  }

  public void startDownLoadMusic(String paramString, int paramInt)
  {
    this.threadPool.submit(new Runnable(paramInt, paramString)
    {
      public void run()
      {
        MusicDownLoadTool.this.requestNetwork(this.val$position, this.val$strMusicPath, "fitMusic", new MusicDownLoadTool.RequestListener()
        {
          public void onRequestPro(int paramInt1, int paramInt2)
          {
            ((AppCompatActivity)MusicDownLoadTool.this.mContext).runOnUiThread(new Runnable(paramInt2, paramInt1)
            {
              public void run()
              {
                if (this.val$pro != 100)
                {
                  MusicDownLoadTool.this.listener.loaderPro(this.val$pos, this.val$pro);
                  return;
                }
                MusicDownLoadTool.this.listener.loaderFinish(this.val$pos);
              }
            });
          }
        });
      }
    });
  }

  public static abstract interface MusicDownLoadListener
  {
    public abstract void loaderFinish(int paramInt);

    public abstract void loaderPro(int paramInt1, int paramInt2);

    public abstract void onLoad();
  }

  static abstract interface RequestListener
  {
    public abstract void onRequestPro(int paramInt1, int paramInt2);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.MusicDownLoadTool
 * JD-Core Version:    0.6.0
 */