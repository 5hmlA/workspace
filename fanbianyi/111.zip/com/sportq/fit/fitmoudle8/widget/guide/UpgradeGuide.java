package com.sportq.fit.fitmoudle8.widget.guide;

import android.app.Activity;
import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.View;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle8.R.color;

public class UpgradeGuide
{
  public static TourGuide showGuideUi(View paramView, Context paramContext, OnGuideCloseListener paramOnGuideCloseListener)
  {
    if (paramView == null)
      return null;
    Overlay localOverlay = new Overlay().setBackgroundColor(ContextCompat.getColor(paramContext, R.color.color_80000000)).disableClick(true).setStyle(Overlay.Style.CIRCLE);
    localOverlay.mHoleRadius = 70;
    return TourGuide.init((Activity)paramContext, paramOnGuideCloseListener).with(TourGuide.Technique.CLICK).setPointer(null).motionType(TourGuide.MotionType.CLICK_ONLY).setOverlay(localOverlay).playOn(paramView);
  }

  public static TourGuide showGuideUi1(View paramView, Context paramContext, int paramInt, OnGuideCloseListener paramOnGuideCloseListener)
  {
    if (paramView == null)
      return null;
    Overlay localOverlay = new Overlay().setStyle(Overlay.Style.JUST_FULL);
    localOverlay.mHoleRadius = 0;
    ToolTip localToolTip = new ToolTip();
    int i = (int)(0.647D * BaseApplication.screenWidth);
    String str;
    switch (paramInt)
    {
    default:
      str = "";
      localOverlay.setmFlag(2).setHolePadding(0);
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    }
    while (true)
    {
      localOverlay.setBackgroundColor(ContextCompat.getColor(paramContext, R.color.color_80000000)).disableClick(true);
      localToolTip.setWidth(i).setDescription(str);
      return TourGuide.init((Activity)paramContext, paramOnGuideCloseListener).with(TourGuide.Technique.CLICK).setPointer(null).motionType(TourGuide.MotionType.CLICK_ONLY).setToolTip(localToolTip).setOverlay(localOverlay).playOn(paramView);
      str = "Fit根据你的健身目标和基础，为你度身定制个人专属训练计划，结合训练反馈，助你获得最佳训练效果";
      localToolTip.setGravity(80).setMarginLeft(CompDeviceInfoUtils.convertOfDip(paramContext, 20.0F));
      localOverlay.setmFlag(0).setHolePadding(4);
      continue;
      str = "Fit根据你现在的身体状况，为你推荐了适合的多节和单节课程，来看看合不合你心意吧";
      localToolTip.setGravity(80).setMarginLeft(CompDeviceInfoUtils.convertOfDip(paramContext, 20.0F));
      localOverlay.setmFlag(1).setHolePadding(4);
      continue;
      str = "Fit里有超过200个「单节课程」任你训练，4－30分钟的长度，方便你随时随地开启训练模式";
      i = (int)(0.6933D * BaseApplication.screenWidth);
      localToolTip.setGravity(80);
      localOverlay.setmFlag(2).setHolePadding(0);
      continue;
      str = "通过科学合理的课程组合，Fit的「多节课程」满足你短期以及局部训练的需求，提升训练效率";
      i = (int)(0.8333D * BaseApplication.screenWidth);
      localToolTip.setGravity(80).setMarginLeft(CompDeviceInfoUtils.convertOfDip(paramContext, 30.0F));
      localOverlay.setmFlag(3).setHolePadding(0);
      continue;
      str = "点击「参加课程」按钮后，该课程将会添加至你的训练列表中，方便你进行训练";
      localToolTip.setGravity(49);
      i = (int)(0.6933D * BaseApplication.screenWidth);
      localOverlay.setmFlag(4).setHolePadding(0);
    }
  }

  public static abstract interface OnGuideCloseListener
  {
    public abstract void onClose(String paramString);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.UpgradeGuide
 * JD-Core Version:    0.6.0
 */