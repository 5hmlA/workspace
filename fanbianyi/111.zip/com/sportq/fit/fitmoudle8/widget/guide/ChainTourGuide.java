package com.sportq.fit.fitmoudle8.widget.guide;

import android.app.Activity;
import android.view.View;

public class ChainTourGuide extends TourGuide
{
  private Sequence mSequence;

  public ChainTourGuide(Activity paramActivity, UpgradeGuide.OnGuideCloseListener paramOnGuideCloseListener)
  {
    super(paramActivity, paramOnGuideCloseListener);
  }

  public static ChainTourGuide init(Activity paramActivity, UpgradeGuide.OnGuideCloseListener paramOnGuideCloseListener)
  {
    return new ChainTourGuide(paramActivity, paramOnGuideCloseListener);
  }

  public ChainTourGuide motionType(TourGuide.MotionType paramMotionType)
  {
    return (ChainTourGuide)super.motionType(paramMotionType);
  }

  public ChainTourGuide next()
  {
    if (this.mFrameLayout != null)
      cleanUp();
    if (this.mSequence.mCurrentSequence < this.mSequence.mTourGuideArray.length)
    {
      setToolTip(this.mSequence.getToolTip());
      setPointer(this.mSequence.getPointer());
      setOverlay(this.mSequence.getOverlay());
      this.mHighlightedView = this.mSequence.getNextTourGuide().mHighlightedView;
      setupView();
      Sequence localSequence = this.mSequence;
      localSequence.mCurrentSequence = (1 + localSequence.mCurrentSequence);
    }
    return this;
  }

  public ChainTourGuide playInSequence(Sequence paramSequence)
  {
    setSequence(paramSequence);
    next();
    return this;
  }

  public ChainTourGuide playLater(View paramView)
  {
    this.mHighlightedView = paramView;
    return this;
  }

  public TourGuide playOn(View paramView)
  {
    throw new RuntimeException("playOn() should not be called ChainTourGuide, ChainTourGuide is meant to be used with Sequence. Use TourGuide class for playOn() for single TourGuide. Only use ChainTourGuide if you intend to run TourGuide in consecutively.");
  }

  public ChainTourGuide setOverlay(Overlay paramOverlay)
  {
    return (ChainTourGuide)super.setOverlay(paramOverlay);
  }

  public ChainTourGuide setPointer(Pointer paramPointer)
  {
    return (ChainTourGuide)super.setPointer(paramPointer);
  }

  public ChainTourGuide setSequence(Sequence paramSequence)
  {
    this.mSequence = paramSequence;
    this.mSequence.setParentTourGuide(this);
    ChainTourGuide[] arrayOfChainTourGuide = paramSequence.mTourGuideArray;
    int i = arrayOfChainTourGuide.length;
    for (int j = 0; j < i; j++)
    {
      if (arrayOfChainTourGuide[j].mHighlightedView != null)
        continue;
      throw new NullPointerException("Please specify the view using 'playLater' method");
    }
    return this;
  }

  public ChainTourGuide setToolTip(ToolTip paramToolTip)
  {
    return (ChainTourGuide)super.setToolTip(paramToolTip);
  }

  public ChainTourGuide with(TourGuide.Technique paramTechnique)
  {
    return (ChainTourGuide)super.with(paramTechnique);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.ChainTourGuide
 * JD-Core Version:    0.6.0
 */