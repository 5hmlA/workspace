package com.sportq.fit.fitmoudle8.widget.guide;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.AnimatorSet.Builder;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.Build.VERSION;
import android.support.v4.view.ViewCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.Window;
import android.view.animation.Animation;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.layout;
import com.sportq.fit.fitmoudle8.R.string;
import net.i2p.android.ext.floatingactionbutton.FloatingActionButton;

public class TourGuide
{
  private UpgradeGuide.OnGuideCloseListener listener;
  private Activity mActivity;
  FrameLayoutWithHole mFrameLayout;
  View mHighlightedView;
  private MotionType mMotionType;
  Overlay mOverlay;
  Pointer mPointer;
  private Technique mTechnique;
  ToolTip mToolTip;
  private View mToolTipViewGroup;

  TourGuide(Activity paramActivity, UpgradeGuide.OnGuideCloseListener paramOnGuideCloseListener)
  {
    this.mActivity = paramActivity;
    if (paramOnGuideCloseListener != null)
      this.listener = paramOnGuideCloseListener;
  }

  private void addGuideHintView()
  {
    this.mFrameLayout.setClickable(true);
    View localView = LayoutInflater.from(this.mActivity).inflate(R.layout.guide_item, null);
    RelativeLayout localRelativeLayout = (RelativeLayout)localView.findViewById(R.id.guide_item_layout);
    String str1 = String.valueOf(this.mHighlightedView.getTag());
    Activity localActivity1 = this.mActivity;
    float f1;
    float f2;
    label194: TextView localTextView;
    if (("more_image".equals(str1)) || ("main.store".equals(str1)) || ("action_camera".equals(str1)))
    {
      f1 = 14.0F;
      int i = CompDeviceInfoUtils.convertOfDip(localActivity1, f1);
      localView.findViewById(R.id.guide_top).setPadding(0, 0, i, 0);
      int[] arrayOfInt = new int[2];
      this.mHighlightedView.getLocationOnScreen(arrayOfInt);
      RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams((int)(0.55D * BaseApplication.screenWidth), -2);
      localLayoutParams.addRule(11, -1);
      localLayoutParams.addRule(3, R.id.guide_top);
      Activity localActivity2 = this.mActivity;
      if ((!"more_image".equals(str1)) && (!"main.store".equals(str1)) && (!"action_camera".equals(str1)))
        break label306;
      f2 = 3.0F;
      localLayoutParams.rightMargin = CompDeviceInfoUtils.convertOfDip(localActivity2, f2);
      localRelativeLayout.setLayoutParams(localLayoutParams);
      localTextView = (TextView)localView.findViewById(R.id.guide_hint);
      if (!"action_feedback".equals(str1))
        break label329;
    }
    for (String str2 = this.mActivity.getResources().getString(R.string.feedback_hint); ; str2 = this.mActivity.getResources().getString(R.string.camera_guide_hint))
    {
      localTextView.setText(str2);
      localView.findViewById(R.id.guide_ok_hint).setOnClickListener(new View.OnClickListener(str1)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (TourGuide.this.listener != null)
            TourGuide.this.listener.onClose(this.val$strTag);
          while (true)
          {
            TourGuide.this.cleanUp();
            return;
            SharePreferenceUtils.putStoreGuideName(TourGuide.this.mActivity, "store.guide");
          }
        }
      });
      this.mFrameLayout.addView(localView);
      return;
      if ("action_feedback".equals(str1))
      {
        f1 = 70.0F;
        break;
      }
      f1 = 64.0F;
      break;
      label306: if ("action_feedback".equals(str1))
      {
        f2 = 45.0F;
        break label194;
      }
      f2 = 40.0F;
      break label194;
      label329: if (!"action_camera".equals(str1))
        break label356;
    }
    label356: Resources localResources = this.mActivity.getResources();
    int j;
    if ("more_image".equals(str1))
      j = R.string.share_hint;
    while (true)
    {
      str2 = localResources.getString(j);
      break;
      if ("main.store".equals(str1))
      {
        j = R.string.main_store_hint;
        continue;
      }
      j = R.string.store_hint;
    }
  }

  private int getScreenWidth()
  {
    if (this.mActivity != null)
      return this.mActivity.getResources().getDisplayMetrics().widthPixels;
    return 0;
  }

  private int getXBasedOnGravity(int paramInt)
  {
    int[] arrayOfInt = new int[2];
    this.mHighlightedView.getLocationOnScreen(arrayOfInt);
    int i = arrayOfInt[0];
    if ((0x5 & this.mPointer.mGravity) == 5)
      i = i + this.mHighlightedView.getWidth() - paramInt;
    do
      return i;
    while ((0x3 & this.mPointer.mGravity) == 3);
    return i + this.mHighlightedView.getWidth() / 2 - paramInt / 2;
  }

  private int getXForTooTip(int paramInt1, int paramInt2, int paramInt3, float paramFloat)
  {
    if ((paramInt1 & 0x3) == 3)
      return this.mToolTip.marginLeft;
    if ((paramInt1 & 0x5) == 5)
      return BaseApplication.screenWidth - paramInt2 - this.mToolTip.marginRight;
    return paramInt3 + this.mHighlightedView.getWidth() / 2 - paramInt2 / 2;
  }

  private int getYBasedOnGravity(int paramInt)
  {
    int[] arrayOfInt = new int[2];
    this.mHighlightedView.getLocationInWindow(arrayOfInt);
    int i = arrayOfInt[1];
    if ((0x50 & this.mPointer.mGravity) == 80)
      i = i + this.mHighlightedView.getHeight() - paramInt;
    do
      return i;
    while ((0x30 & this.mPointer.mGravity) == 48);
    return i + this.mHighlightedView.getHeight() / 2 - paramInt / 2;
  }

  private int getYForTooTip(int paramInt1, int paramInt2, int paramInt3, float paramFloat)
  {
    if (paramInt1 == 49)
      return paramInt3 - paramInt2 - CompDeviceInfoUtils.convertOfDip(this.mActivity, 10.0F);
    return paramInt3 + this.mHighlightedView.getHeight() + CompDeviceInfoUtils.convertOfDip(this.mActivity, 3.0F);
  }

  private void handleDisableClicking(FrameLayoutWithHole paramFrameLayoutWithHole)
  {
    if ((this.mOverlay != null) && (this.mOverlay.mOnClickListener != null))
    {
      paramFrameLayoutWithHole.setClickable(true);
      paramFrameLayoutWithHole.setOnClickListener(this.mOverlay.mOnClickListener);
    }
    do
      return;
    while ((this.mOverlay == null) || (!this.mOverlay.mDisableClick));
    Log.w("tourguide", "Overlay's default OnClickListener is null, it will proceed to next tourguide when it is clicked");
    paramFrameLayoutWithHole.setViewHole(this.mHighlightedView);
    paramFrameLayoutWithHole.setSoundEffectsEnabled(false);
    paramFrameLayoutWithHole.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (TourGuide.this.listener != null)
          TourGuide.this.listener.onClose("");
        TourGuide.this.cleanUp();
      }
    });
  }

  public static TourGuide init(Activity paramActivity, UpgradeGuide.OnGuideCloseListener paramOnGuideCloseListener)
  {
    return new TourGuide(paramActivity, paramOnGuideCloseListener);
  }

  private void performAnimationOn(View paramView)
  {
    if ((this.mTechnique != null) && (this.mTechnique == Technique.HORIZONTAL_LEFT))
    {
      AnimatorSet localAnimatorSet3 = new AnimatorSet();
      AnimatorSet localAnimatorSet4 = new AnimatorSet();
      5 local5 = new Animator.AnimatorListener(paramView, localAnimatorSet4)
      {
        public void onAnimationCancel(Animator paramAnimator)
        {
        }

        public void onAnimationEnd(Animator paramAnimator)
        {
          this.val$view.setScaleX(1.0F);
          this.val$view.setScaleY(1.0F);
          this.val$view.setTranslationX(0.0F);
          this.val$animatorSet2.start();
        }

        public void onAnimationRepeat(Animator paramAnimator)
        {
        }

        public void onAnimationStart(Animator paramAnimator)
        {
        }
      };
      6 local6 = new Animator.AnimatorListener(paramView, localAnimatorSet3)
      {
        public void onAnimationCancel(Animator paramAnimator)
        {
        }

        public void onAnimationEnd(Animator paramAnimator)
        {
          this.val$view.setScaleX(1.0F);
          this.val$view.setScaleY(1.0F);
          this.val$view.setTranslationX(0.0F);
          this.val$animatorSet.start();
        }

        public void onAnimationRepeat(Animator paramAnimator)
        {
        }

        public void onAnimationStart(Animator paramAnimator)
        {
        }
      };
      float f = getScreenWidth() / 2;
      ObjectAnimator localObjectAnimator15 = ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 0.0F, 1.0F });
      localObjectAnimator15.setDuration(800L);
      ObjectAnimator localObjectAnimator16 = ObjectAnimator.ofFloat(paramView, "scaleX", new float[] { 1.0F, 0.85F });
      localObjectAnimator16.setDuration(800L);
      ObjectAnimator localObjectAnimator17 = ObjectAnimator.ofFloat(paramView, "scaleY", new float[] { 1.0F, 0.85F });
      localObjectAnimator17.setDuration(800L);
      float[] arrayOfFloat1 = new float[1];
      arrayOfFloat1[0] = (-f);
      ObjectAnimator localObjectAnimator18 = ObjectAnimator.ofFloat(paramView, "translationX", arrayOfFloat1);
      localObjectAnimator18.setDuration(2000L);
      ObjectAnimator localObjectAnimator19 = ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 1.0F, 0.0F });
      localObjectAnimator19.setDuration(2000L);
      ObjectAnimator localObjectAnimator20 = ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 0.0F, 1.0F });
      localObjectAnimator20.setDuration(800L);
      ObjectAnimator localObjectAnimator21 = ObjectAnimator.ofFloat(paramView, "scaleX", new float[] { 1.0F, 0.85F });
      localObjectAnimator21.setDuration(800L);
      ObjectAnimator localObjectAnimator22 = ObjectAnimator.ofFloat(paramView, "scaleY", new float[] { 1.0F, 0.85F });
      localObjectAnimator22.setDuration(800L);
      float[] arrayOfFloat2 = new float[1];
      arrayOfFloat2[0] = (-f);
      ObjectAnimator localObjectAnimator23 = ObjectAnimator.ofFloat(paramView, "translationX", arrayOfFloat2);
      localObjectAnimator23.setDuration(2000L);
      ObjectAnimator localObjectAnimator24 = ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 1.0F, 0.0F });
      localObjectAnimator24.setDuration(2000L);
      localAnimatorSet3.play(localObjectAnimator15);
      localAnimatorSet3.play(localObjectAnimator16).with(localObjectAnimator17).after(localObjectAnimator15);
      localAnimatorSet3.play(localObjectAnimator18).with(localObjectAnimator19).after(localObjectAnimator17);
      localAnimatorSet4.play(localObjectAnimator20);
      localAnimatorSet4.play(localObjectAnimator21).with(localObjectAnimator22).after(localObjectAnimator20);
      localAnimatorSet4.play(localObjectAnimator23).with(localObjectAnimator24).after(localObjectAnimator22);
      localAnimatorSet3.addListener(local5);
      localAnimatorSet4.addListener(local6);
      localAnimatorSet3.start();
      this.mFrameLayout.addAnimatorSet(localAnimatorSet3);
      this.mFrameLayout.addAnimatorSet(localAnimatorSet4);
    }
    do
      return;
    while (((this.mTechnique != null) && (this.mTechnique == Technique.HORIZONTAL_RIGHT)) || ((this.mTechnique != null) && (this.mTechnique == Technique.VERTICAL_UPWARD)) || ((this.mTechnique != null) && (this.mTechnique == Technique.VERTICAL_DOWNWARD)));
    AnimatorSet localAnimatorSet1 = new AnimatorSet();
    AnimatorSet localAnimatorSet2 = new AnimatorSet();
    7 local7 = new Animator.AnimatorListener(paramView, localAnimatorSet2)
    {
      public void onAnimationCancel(Animator paramAnimator)
      {
      }

      public void onAnimationEnd(Animator paramAnimator)
      {
        this.val$view.setScaleX(1.0F);
        this.val$view.setScaleY(1.0F);
        this.val$view.setTranslationX(0.0F);
        this.val$animatorSet2.start();
      }

      public void onAnimationRepeat(Animator paramAnimator)
      {
      }

      public void onAnimationStart(Animator paramAnimator)
      {
      }
    };
    8 local8 = new Animator.AnimatorListener(paramView, localAnimatorSet1)
    {
      public void onAnimationCancel(Animator paramAnimator)
      {
      }

      public void onAnimationEnd(Animator paramAnimator)
      {
        this.val$view.setScaleX(1.0F);
        this.val$view.setScaleY(1.0F);
        this.val$view.setTranslationX(0.0F);
        this.val$animatorSet.start();
      }

      public void onAnimationRepeat(Animator paramAnimator)
      {
      }

      public void onAnimationStart(Animator paramAnimator)
      {
      }
    };
    ObjectAnimator localObjectAnimator1 = ObjectAnimator.ofFloat(paramView, "translationX", new float[] { 0.0F });
    localObjectAnimator1.setDuration(1000L);
    ObjectAnimator localObjectAnimator2 = ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 0.0F, 1.0F });
    localObjectAnimator2.setDuration(800L);
    ObjectAnimator localObjectAnimator3 = ObjectAnimator.ofFloat(paramView, "scaleX", new float[] { 1.0F, 0.85F });
    localObjectAnimator3.setDuration(800L);
    ObjectAnimator localObjectAnimator4 = ObjectAnimator.ofFloat(paramView, "scaleY", new float[] { 1.0F, 0.85F });
    localObjectAnimator4.setDuration(800L);
    ObjectAnimator localObjectAnimator5 = ObjectAnimator.ofFloat(paramView, "scaleX", new float[] { 0.85F, 1.0F });
    localObjectAnimator5.setDuration(800L);
    ObjectAnimator localObjectAnimator6 = ObjectAnimator.ofFloat(paramView, "scaleY", new float[] { 0.85F, 1.0F });
    localObjectAnimator6.setDuration(800L);
    ObjectAnimator localObjectAnimator7 = ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 1.0F, 0.0F });
    localObjectAnimator7.setDuration(800L);
    ObjectAnimator localObjectAnimator8 = ObjectAnimator.ofFloat(paramView, "translationX", new float[] { 0.0F });
    localObjectAnimator8.setDuration(1000L);
    ObjectAnimator localObjectAnimator9 = ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 0.0F, 1.0F });
    localObjectAnimator9.setDuration(800L);
    ObjectAnimator localObjectAnimator10 = ObjectAnimator.ofFloat(paramView, "scaleX", new float[] { 1.0F, 0.85F });
    localObjectAnimator10.setDuration(800L);
    ObjectAnimator localObjectAnimator11 = ObjectAnimator.ofFloat(paramView, "scaleY", new float[] { 1.0F, 0.85F });
    localObjectAnimator11.setDuration(800L);
    ObjectAnimator localObjectAnimator12 = ObjectAnimator.ofFloat(paramView, "scaleX", new float[] { 0.85F, 1.0F });
    localObjectAnimator12.setDuration(800L);
    ObjectAnimator localObjectAnimator13 = ObjectAnimator.ofFloat(paramView, "scaleY", new float[] { 0.85F, 1.0F });
    localObjectAnimator13.setDuration(800L);
    ObjectAnimator localObjectAnimator14 = ObjectAnimator.ofFloat(paramView, "alpha", new float[] { 1.0F, 0.0F });
    localObjectAnimator14.setDuration(800L);
    paramView.setAlpha(0.0F);
    long l;
    if (this.mToolTip != null)
      l = this.mToolTip.mEnterAnimation.getDuration();
    while (true)
    {
      localAnimatorSet1.setStartDelay(l);
      localAnimatorSet1.play(localObjectAnimator2);
      localAnimatorSet1.play(localObjectAnimator3).with(localObjectAnimator4).after(localObjectAnimator2);
      localAnimatorSet1.play(localObjectAnimator5).with(localObjectAnimator6).with(localObjectAnimator7).after(localObjectAnimator4);
      localAnimatorSet1.play(localObjectAnimator1).after(localObjectAnimator6);
      localAnimatorSet2.play(localObjectAnimator9);
      localAnimatorSet2.play(localObjectAnimator10).with(localObjectAnimator11).after(localObjectAnimator9);
      localAnimatorSet2.play(localObjectAnimator12).with(localObjectAnimator13).with(localObjectAnimator14).after(localObjectAnimator11);
      localAnimatorSet2.play(localObjectAnimator8).after(localObjectAnimator13);
      localAnimatorSet1.addListener(local7);
      localAnimatorSet2.addListener(local8);
      localAnimatorSet1.start();
      this.mFrameLayout.addAnimatorSet(localAnimatorSet1);
      this.mFrameLayout.addAnimatorSet(localAnimatorSet2);
      return;
      l = 0L;
    }
  }

  private FloatingActionButton setupAndAddFABToFrameLayout(FrameLayoutWithHole paramFrameLayoutWithHole)
  {
    FloatingActionButton localFloatingActionButton1 = new FloatingActionButton(this.mActivity);
    localFloatingActionButton1.setSize(1);
    localFloatingActionButton1.setVisibility(4);
    ((ViewGroup)this.mActivity.getWindow().getDecorView()).addView(localFloatingActionButton1);
    FloatingActionButton localFloatingActionButton2 = new FloatingActionButton(this.mActivity);
    localFloatingActionButton2.setBackgroundColor(-16776961);
    localFloatingActionButton2.setSize(1);
    localFloatingActionButton2.setColorNormal(this.mPointer.mColor);
    localFloatingActionButton2.setStrokeVisible(false);
    localFloatingActionButton2.setClickable(false);
    localFloatingActionButton1.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(localFloatingActionButton1, paramFrameLayoutWithHole, localFloatingActionButton2)
    {
      public void onGlobalLayout()
      {
        if (Build.VERSION.SDK_INT < 16)
          this.val$invisFab.getViewTreeObserver().removeGlobalOnLayoutListener(this);
        while (true)
        {
          FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-2, -2);
          this.val$frameLayoutWithHole.addView(this.val$fab, localLayoutParams);
          localLayoutParams.setMargins(TourGuide.this.getXBasedOnGravity(this.val$invisFab.getWidth()), TourGuide.this.getYBasedOnGravity(this.val$invisFab.getHeight()), 0, 0);
          return;
          this.val$invisFab.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        }
      }
    });
    return localFloatingActionButton2;
  }

  private void setupFrameLayout()
  {
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-1, -1);
    ViewGroup localViewGroup = (ViewGroup)this.mActivity.getWindow().getDecorView().findViewById(16908290);
    int[] arrayOfInt = new int[2];
    localViewGroup.getLocationOnScreen(arrayOfInt);
    localLayoutParams.setMargins(0, -arrayOfInt[1], 0, 0);
    if (this.mFrameLayout.getParent() == null)
      localViewGroup.addView(this.mFrameLayout, localLayoutParams);
  }

  private void setupToolTip()
  {
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-2, -2);
    ViewGroup localViewGroup;
    int i;
    int j;
    int k;
    label248: Point localPoint;
    float f;
    if (this.mToolTip != null)
    {
      localViewGroup = (ViewGroup)this.mActivity.getWindow().getDecorView();
      LayoutInflater localLayoutInflater = this.mActivity.getLayoutInflater();
      if (this.mToolTip.getCustomView() != null)
        break label333;
      this.mToolTipViewGroup = localLayoutInflater.inflate(R.layout.custom_guide_tooltip, null);
      LinearLayout localLinearLayout = (LinearLayout)this.mToolTipViewGroup.findViewById(R.id.guide_Content);
      View localView = this.mToolTipViewGroup.findViewById(R.id.guide_top);
      ((RTextView)this.mToolTipViewGroup.findViewById(R.id.guide_hint)).setText(this.mToolTip.mDescription);
      if (this.mOverlay.mFlag == 4)
      {
        localLinearLayout.removeView(localView);
        localView.setRotation(180.0F);
        localLinearLayout.addView(localView);
      }
      if (this.mToolTip.mWidth != -1)
        localLayoutParams.width = this.mToolTip.mWidth;
      this.mToolTipViewGroup.startAnimation(this.mToolTip.mEnterAnimation);
      localViewGroup.addView(this.mToolTipViewGroup, localLayoutParams);
      int[] arrayOfInt = new int[2];
      this.mHighlightedView.getLocationOnScreen(arrayOfInt);
      i = arrayOfInt[0];
      j = arrayOfInt[1];
      this.mToolTipViewGroup.measure(-2, -2);
      if (this.mToolTip.mWidth == -1)
        break label347;
      k = this.mToolTip.mWidth;
      localPoint = new Point();
      f = 3.0F * this.mActivity.getResources().getDisplayMetrics().density;
      if (k <= localViewGroup.getWidth())
        break label359;
    }
    label333: label347: label359: for (localPoint.x = getXForTooTip(this.mToolTip.mGravity, localViewGroup.getWidth(), i, f); ; localPoint.x = getXForTooTip(this.mToolTip.mGravity, k, i, f))
    {
      this.mToolTipViewGroup.post(new Runnable(localPoint, j, f, localViewGroup, localLayoutParams)
      {
        public void run()
        {
          this.val$resultPoint.y = TourGuide.this.getYForTooTip(TourGuide.this.mToolTip.mGravity, TourGuide.this.mToolTipViewGroup.getHeight(), this.val$targetViewY, this.val$adjustment);
          if (this.val$resultPoint.x < 0)
            this.val$resultPoint.x = TourGuide.this.mToolTip.marginLeft;
          if (this.val$resultPoint.x + TourGuide.this.mToolTipViewGroup.getWidth() > this.val$parent.getWidth())
            TourGuide.this.mToolTipViewGroup.getLayoutParams().width = (this.val$parent.getWidth() - this.val$resultPoint.x);
          this.val$layoutParams.setMargins(this.val$resultPoint.x, this.val$resultPoint.y, 0, 0);
          TourGuide.this.mToolTipViewGroup.setLayoutParams(this.val$layoutParams);
        }
      });
      return;
      this.mToolTipViewGroup = this.mToolTip.getCustomView();
      break;
      k = this.mToolTipViewGroup.getMeasuredWidth();
      break label248;
    }
  }

  private void startView()
  {
    if (this.mFrameLayout == null)
      this.mFrameLayout = new FrameLayoutWithHole(this.mActivity, this.mHighlightedView, this.mMotionType, this.mOverlay);
    handleDisableClicking(this.mFrameLayout);
    if (this.mPointer != null)
      performAnimationOn(setupAndAddFABToFrameLayout(this.mFrameLayout));
    setupFrameLayout();
    setupToolTip();
    if (this.mToolTip == null)
      addGuideHintView();
  }

  void cleanUp()
  {
    if (this.mFrameLayout != null)
      this.mFrameLayout.cleanUp();
    if (this.mToolTipViewGroup != null)
      ((ViewGroup)this.mActivity.getWindow().getDecorView()).removeView(this.mToolTipViewGroup);
    this.mFrameLayout = null;
  }

  public UpgradeGuide.OnGuideCloseListener getListener()
  {
    return this.listener;
  }

  public FrameLayoutWithHole getOverlay()
  {
    return this.mFrameLayout;
  }

  public View getToolTip()
  {
    return this.mToolTipViewGroup;
  }

  public TourGuide motionType(MotionType paramMotionType)
  {
    this.mMotionType = paramMotionType;
    return this;
  }

  public TourGuide playOn(View paramView)
  {
    this.mHighlightedView = paramView;
    setupView();
    return this;
  }

  public TourGuide setOverlay(Overlay paramOverlay)
  {
    this.mOverlay = paramOverlay;
    return this;
  }

  public void setOverlay(FrameLayoutWithHole paramFrameLayoutWithHole)
  {
    this.mFrameLayout = paramFrameLayoutWithHole;
  }

  public TourGuide setPointer(Pointer paramPointer)
  {
    this.mPointer = paramPointer;
    return this;
  }

  public TourGuide setToolTip(ToolTip paramToolTip)
  {
    this.mToolTip = paramToolTip;
    return this;
  }

  void setupView()
  {
    if (ViewCompat.isAttachedToWindow(this.mHighlightedView))
    {
      startView();
      return;
    }
    this.mHighlightedView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener()
    {
      public void onGlobalLayout()
      {
        if (Build.VERSION.SDK_INT < 16)
          TourGuide.this.mHighlightedView.getViewTreeObserver().removeGlobalOnLayoutListener(this);
        while (true)
        {
          TourGuide.this.startView();
          return;
          TourGuide.this.mHighlightedView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        }
      }
    });
  }

  public TourGuide with(Technique paramTechnique)
  {
    this.mTechnique = paramTechnique;
    return this;
  }

  public static enum MotionType
  {
    static
    {
      MotionType[] arrayOfMotionType = new MotionType[3];
      arrayOfMotionType[0] = ALLOW_ALL;
      arrayOfMotionType[1] = CLICK_ONLY;
      arrayOfMotionType[2] = SWIPE_ONLY;
      $VALUES = arrayOfMotionType;
    }
  }

  public static enum Technique
  {
    static
    {
      VERTICAL_DOWNWARD = new Technique("VERTICAL_DOWNWARD", 4);
      Technique[] arrayOfTechnique = new Technique[5];
      arrayOfTechnique[0] = CLICK;
      arrayOfTechnique[1] = HORIZONTAL_LEFT;
      arrayOfTechnique[2] = HORIZONTAL_RIGHT;
      arrayOfTechnique[3] = VERTICAL_UPWARD;
      arrayOfTechnique[4] = VERTICAL_DOWNWARD;
      $VALUES = arrayOfTechnique;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.TourGuide
 * JD-Core Version:    0.6.0
 */