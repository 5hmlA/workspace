package com.sportq.fit.fitmoudle8.widget.guide;

import android.annotation.TargetApi;
import android.support.v4.view.ViewPager.PageTransformer;
import android.view.View;

public class ScaleInTransformer extends BasePageTransformer
{
  private static final float DEFAULT_MIN_SCALE = 0.85F;
  private float mMinScale = 0.85F;

  public ScaleInTransformer()
  {
  }

  public ScaleInTransformer(float paramFloat)
  {
    this(paramFloat, NonPageTransformer.INSTANCE);
  }

  public ScaleInTransformer(float paramFloat, ViewPager.PageTransformer paramPageTransformer)
  {
    this.mMinScale = paramFloat;
    this.mPageTransformer = paramPageTransformer;
  }

  public ScaleInTransformer(ViewPager.PageTransformer paramPageTransformer)
  {
    this(0.85F, paramPageTransformer);
  }

  @TargetApi(11)
  public void pageTransform(View paramView, float paramFloat)
  {
    int i = paramView.getWidth();
    paramView.setPivotY(paramView.getHeight() / 2);
    paramView.setPivotX(i / 2);
    if (paramFloat < -1.0F)
    {
      paramView.setScaleX(this.mMinScale);
      paramView.setScaleY(this.mMinScale);
      paramView.setPivotX(i);
      return;
    }
    if (paramFloat <= 1.0F)
    {
      if (paramFloat < 0.0F)
      {
        float f2 = (1.0F + paramFloat) * (1.0F - this.mMinScale) + this.mMinScale;
        paramView.setScaleX(f2);
        paramView.setScaleY(f2);
        paramView.setPivotX(i * (0.5F + 0.5F * -paramFloat));
        return;
      }
      float f1 = (1.0F - paramFloat) * (1.0F - this.mMinScale) + this.mMinScale;
      paramView.setScaleX(f1);
      paramView.setScaleY(f1);
      paramView.setPivotX(i * (0.5F * (1.0F - paramFloat)));
      return;
    }
    paramView.setPivotX(0.0F);
    paramView.setScaleX(this.mMinScale);
    paramView.setScaleY(this.mMinScale);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.ScaleInTransformer
 * JD-Core Version:    0.6.0
 */