package com.sportq.fit.fitmoudle8.widget.guide;

import android.graphics.Color;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;

public class ToolTip
{
  public int mBackgroundColor = Color.parseColor("#3498db");
  public ViewGroup mCustomView;
  public String mDescription = "";
  public Animation mEnterAnimation = new AlphaAnimation(0.0F, 1.0F);
  public Animation mExitAnimation;
  public int mGravity;
  public View.OnClickListener mOnClickListener;
  public int mTextColor = Color.parseColor("#FFFFFF");
  public String mTitle = "";
  public int mWidth;
  public int marginLeft;
  public int marginRight;

  public ToolTip()
  {
    this.mEnterAnimation.setDuration(400L);
    this.mEnterAnimation.setFillAfter(true);
    this.mEnterAnimation.setInterpolator(new AccelerateInterpolator());
    this.mWidth = -1;
    this.marginLeft = 50;
    this.marginRight = 6;
    this.mGravity = 17;
  }

  public ViewGroup getCustomView()
  {
    return this.mCustomView;
  }

  public ToolTip setBackgroundColor(int paramInt)
  {
    this.mBackgroundColor = paramInt;
    return this;
  }

  public ToolTip setCustomView(ViewGroup paramViewGroup)
  {
    this.mCustomView = paramViewGroup;
    return this;
  }

  public ToolTip setDescription(String paramString)
  {
    this.mDescription = paramString;
    return this;
  }

  public ToolTip setEnterAnimation(Animation paramAnimation)
  {
    this.mEnterAnimation = paramAnimation;
    return this;
  }

  public ToolTip setGravity(int paramInt)
  {
    this.mGravity = paramInt;
    return this;
  }

  public ToolTip setMarginLeft(int paramInt)
  {
    this.marginLeft = paramInt;
    return this;
  }

  public void setMarginRight(int paramInt)
  {
    this.marginRight = paramInt;
  }

  public ToolTip setOnClickListener(View.OnClickListener paramOnClickListener)
  {
    this.mOnClickListener = paramOnClickListener;
    return this;
  }

  public ToolTip setTextColor(int paramInt)
  {
    this.mTextColor = paramInt;
    return this;
  }

  public ToolTip setTitle(String paramString)
  {
    this.mTitle = paramString;
    return this;
  }

  public ToolTip setWidth(int paramInt)
  {
    if (paramInt >= 0)
      this.mWidth = paramInt;
    return this;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.ToolTip
 * JD-Core Version:    0.6.0
 */