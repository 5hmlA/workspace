package com.sportq.fit.fitmoudle8.widget.guide;

import android.annotation.TargetApi;
import android.support.v4.view.ViewPager.PageTransformer;
import android.view.View;

public abstract class BasePageTransformer
  implements ViewPager.PageTransformer
{
  public static final float DEFAULT_CENTER = 0.5F;
  protected ViewPager.PageTransformer mPageTransformer = NonPageTransformer.INSTANCE;

  protected abstract void pageTransform(View paramView, float paramFloat);

  @TargetApi(11)
  public void transformPage(View paramView, float paramFloat)
  {
    if (this.mPageTransformer != null)
      this.mPageTransformer.transformPage(paramView, paramFloat);
    pageTransform(paramView, paramFloat);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.BasePageTransformer
 * JD-Core Version:    0.6.0
 */