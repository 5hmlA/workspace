package com.sportq.fit.fitmoudle8.widget.guide;

import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;

public class Sequence
{
  ContinueMethod mContinueMethod;
  public int mCurrentSequence;
  Overlay mDefaultOverlay;
  Pointer mDefaultPointer;
  ToolTip mDefaultToolTip;
  boolean mDisableTargetButton;
  ChainTourGuide mParentTourGuide;
  ChainTourGuide[] mTourGuideArray;

  private Sequence(SequenceBuilder paramSequenceBuilder)
  {
    this.mTourGuideArray = paramSequenceBuilder.mTourGuideArray;
    this.mDefaultOverlay = paramSequenceBuilder.mDefaultOverlay;
    this.mDefaultToolTip = paramSequenceBuilder.mDefaultToolTip;
    this.mDefaultPointer = paramSequenceBuilder.mDefaultPointer;
    this.mContinueMethod = paramSequenceBuilder.mContinueMethod;
    this.mCurrentSequence = paramSequenceBuilder.mCurrentSequence;
    this.mDisableTargetButton = paramSequenceBuilder.mDisableTargetButton;
  }

  public ContinueMethod getContinueMethod()
  {
    return this.mContinueMethod;
  }

  public Overlay getDefaultOverlay()
  {
    return this.mDefaultOverlay;
  }

  public ToolTip getDefaultToolTip()
  {
    return this.mDefaultToolTip;
  }

  public ChainTourGuide getNextTourGuide()
  {
    return this.mTourGuideArray[this.mCurrentSequence];
  }

  public Overlay getOverlay()
  {
    return this.mTourGuideArray[this.mCurrentSequence].mOverlay;
  }

  public Pointer getPointer()
  {
    if (this.mTourGuideArray[this.mCurrentSequence].mPointer != null)
      return this.mTourGuideArray[this.mCurrentSequence].mPointer;
    return this.mDefaultPointer;
  }

  public ToolTip getToolTip()
  {
    if (this.mTourGuideArray[this.mCurrentSequence].mToolTip != null)
      return this.mTourGuideArray[this.mCurrentSequence].mToolTip;
    return this.mDefaultToolTip;
  }

  public ChainTourGuide[] getTourGuideArray()
  {
    return this.mTourGuideArray;
  }

  protected void setParentTourGuide(ChainTourGuide paramChainTourGuide)
  {
    this.mParentTourGuide = paramChainTourGuide;
    if (this.mContinueMethod == ContinueMethod.OVERLAY)
    {
      ChainTourGuide[] arrayOfChainTourGuide = this.mTourGuideArray;
      int i = arrayOfChainTourGuide.length;
      for (int j = 0; j < i; j++)
        arrayOfChainTourGuide[j].mOverlay.mOnClickListener = new View.OnClickListener()
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            Sequence.this.mParentTourGuide.next();
          }
        };
    }
  }

  public static enum ContinueMethod
  {
    static
    {
      ContinueMethod[] arrayOfContinueMethod = new ContinueMethod[2];
      arrayOfContinueMethod[0] = OVERLAY;
      arrayOfContinueMethod[1] = OVERLAY_LISTENER;
      $VALUES = arrayOfContinueMethod;
    }
  }

  public static class SequenceBuilder
  {
    Sequence.ContinueMethod mContinueMethod;
    int mCurrentSequence;
    Overlay mDefaultOverlay;
    Pointer mDefaultPointer;
    ToolTip mDefaultToolTip;
    boolean mDisableTargetButton;
    ChainTourGuide[] mTourGuideArray;

    private void checkAtLeastTwoTourGuideSupplied()
    {
      if ((this.mTourGuideArray == null) || (this.mTourGuideArray.length <= 1))
        throw new IllegalArgumentException("In order to run a sequence, you must at least supply 2 TourGuide into Sequence using add()");
    }

    private void checkIfContinueMethodNull()
    {
      if (this.mContinueMethod == null)
        throw new IllegalArgumentException("Continue Method is not set. Please provide ContinueMethod in setContinueMethod");
    }

    private void checkOverlayListener(Sequence.ContinueMethod paramContinueMethod)
    {
      int i = 0;
      if (paramContinueMethod == Sequence.ContinueMethod.OVERLAY_LISTENER)
      {
        int i1 = 1;
        ChainTourGuide[] arrayOfChainTourGuide4;
        int i3;
        if ((this.mDefaultOverlay != null) && (this.mDefaultOverlay.mOnClickListener != null))
        {
          i1 = 1;
          arrayOfChainTourGuide4 = this.mTourGuideArray;
          i3 = arrayOfChainTourGuide4.length;
        }
        ChainTourGuide[] arrayOfChainTourGuide3;
        int i2;
        while (i < i3)
        {
          ChainTourGuide localChainTourGuide4 = arrayOfChainTourGuide4[i];
          if (localChainTourGuide4.mOverlay == null)
            localChainTourGuide4.mOverlay = this.mDefaultOverlay;
          if ((localChainTourGuide4.mOverlay != null) && (localChainTourGuide4.mOverlay.mOnClickListener == null))
            localChainTourGuide4.mOverlay.mOnClickListener = this.mDefaultOverlay.mOnClickListener;
          i++;
          continue;
          arrayOfChainTourGuide3 = this.mTourGuideArray;
          i2 = arrayOfChainTourGuide3.length;
        }
        while (true)
        {
          ChainTourGuide localChainTourGuide3;
          if (i < i2)
          {
            localChainTourGuide3 = arrayOfChainTourGuide3[i];
            if ((localChainTourGuide3.mOverlay == null) || (localChainTourGuide3.mOverlay.mOnClickListener != null))
              break label172;
          }
          for (i1 = 0; ; i1 = 0)
          {
            if (i1 != 0)
              return;
            throw new IllegalArgumentException("ContinueMethod.OVERLAY_LISTENER is chosen as the ContinueMethod, but no Default Overlay Listener is set, or not all OVERLAY.mListener is set for all the TourGuide passed in.");
            label172: if (localChainTourGuide3.mOverlay != null)
              break;
          }
          i++;
        }
      }
      if (paramContinueMethod == Sequence.ContinueMethod.OVERLAY)
      {
        int j = 1;
        if ((this.mDefaultOverlay != null) && (this.mDefaultOverlay.mOnClickListener != null))
          j = 0;
        label329: 
        while (this.mDefaultOverlay != null)
        {
          ChainTourGuide[] arrayOfChainTourGuide2 = this.mTourGuideArray;
          int n = arrayOfChainTourGuide2.length;
          while (i < n)
          {
            ChainTourGuide localChainTourGuide2 = arrayOfChainTourGuide2[i];
            if (localChainTourGuide2.mOverlay == null)
              localChainTourGuide2.mOverlay = this.mDefaultOverlay;
            i++;
          }
          ChainTourGuide[] arrayOfChainTourGuide1 = this.mTourGuideArray;
          int k = arrayOfChainTourGuide1.length;
          for (int m = 0; ; m++)
          {
            if (m >= k)
              break label329;
            ChainTourGuide localChainTourGuide1 = arrayOfChainTourGuide1[m];
            if ((localChainTourGuide1.mOverlay == null) || (localChainTourGuide1.mOverlay.mOnClickListener == null))
              continue;
            j = 0;
            break;
          }
        }
        if (j == 0)
          throw new IllegalArgumentException("ContinueMethod.OVERLAY is chosen as the ContinueMethod, but either default overlay listener is still set OR individual overlay listener is still set, make sure to clear all Overlay listener");
      }
    }

    private SequenceBuilder setDisableButton(boolean paramBoolean)
    {
      this.mDisableTargetButton = paramBoolean;
      return this;
    }

    public SequenceBuilder add(ChainTourGuide[] paramArrayOfChainTourGuide)
    {
      this.mTourGuideArray = paramArrayOfChainTourGuide;
      return this;
    }

    public Sequence build()
    {
      this.mCurrentSequence = 0;
      checkIfContinueMethodNull();
      checkAtLeastTwoTourGuideSupplied();
      checkOverlayListener(this.mContinueMethod);
      return new Sequence(this, null);
    }

    public SequenceBuilder setContinueMethod(Sequence.ContinueMethod paramContinueMethod)
    {
      this.mContinueMethod = paramContinueMethod;
      return this;
    }

    public SequenceBuilder setDefaultOverlay(Overlay paramOverlay)
    {
      this.mDefaultOverlay = paramOverlay;
      return this;
    }

    public SequenceBuilder setDefaultPointer(Pointer paramPointer)
    {
      this.mDefaultPointer = paramPointer;
      return this;
    }

    public SequenceBuilder setDefaultToolTip(ToolTip paramToolTip)
    {
      this.mDefaultToolTip = paramToolTip;
      return this;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.Sequence
 * JD-Core Version:    0.6.0
 */