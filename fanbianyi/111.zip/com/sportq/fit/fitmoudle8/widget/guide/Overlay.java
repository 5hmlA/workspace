package com.sportq.fit.fitmoudle8.widget.guide;

import android.graphics.Color;
import android.view.View.OnClickListener;
import android.view.animation.Animation;

public class Overlay
{
  public static final int NOT_SET = -1;
  public int mBackgroundColor;
  public boolean mDisableClick;
  public boolean mDisableClickThroughHole;
  public Animation mEnterAnimation;
  public Animation mExitAnimation;
  public int mFlag = 2;
  public int mHoleOffsetLeft = 0;
  public int mHoleOffsetTop = 0;
  public int mHoleRadius = -1;
  public View.OnClickListener mOnClickListener;
  public int mPaddingDp = 10;
  public int mRoundedCornerRadiusDp = 0;
  public Style mStyle;

  public Overlay()
  {
    this(true, Color.parseColor("#55000000"), Style.CIRCLE);
  }

  public Overlay(boolean paramBoolean, int paramInt, Style paramStyle)
  {
    this.mDisableClick = paramBoolean;
    this.mBackgroundColor = paramInt;
    this.mStyle = paramStyle;
  }

  public Overlay disableClick(boolean paramBoolean)
  {
    this.mDisableClick = paramBoolean;
    return this;
  }

  public Overlay disableClickThroughHole(boolean paramBoolean)
  {
    this.mDisableClickThroughHole = paramBoolean;
    return this;
  }

  public Overlay setBackgroundColor(int paramInt)
  {
    this.mBackgroundColor = paramInt;
    return this;
  }

  public Overlay setEnterAnimation(Animation paramAnimation)
  {
    this.mEnterAnimation = paramAnimation;
    return this;
  }

  public Overlay setExitAnimation(Animation paramAnimation)
  {
    this.mExitAnimation = paramAnimation;
    return this;
  }

  public Overlay setHoleOffsets(int paramInt1, int paramInt2)
  {
    this.mHoleOffsetLeft = paramInt1;
    this.mHoleOffsetTop = paramInt2;
    return this;
  }

  public Overlay setHolePadding(int paramInt)
  {
    this.mPaddingDp = paramInt;
    return this;
  }

  public Overlay setHoleRadius(int paramInt)
  {
    this.mHoleRadius = paramInt;
    return this;
  }

  public Overlay setOnClickListener(View.OnClickListener paramOnClickListener)
  {
    this.mOnClickListener = paramOnClickListener;
    return this;
  }

  public Overlay setRoundedCornerRadius(int paramInt)
  {
    this.mRoundedCornerRadiusDp = paramInt;
    return this;
  }

  public Overlay setStyle(Style paramStyle)
  {
    this.mStyle = paramStyle;
    return this;
  }

  public Overlay setmFlag(int paramInt)
  {
    this.mFlag = paramInt;
    return this;
  }

  public static enum Style
  {
    static
    {
      NO_HOLE = new Style("NO_HOLE", 3);
      JUST_FULL = new Style("JUST_FULL", 4);
      Style[] arrayOfStyle = new Style[5];
      arrayOfStyle[0] = CIRCLE;
      arrayOfStyle[1] = RECTANGLE;
      arrayOfStyle[2] = ROUNDED_RECTANGLE;
      arrayOfStyle[3] = NO_HOLE;
      arrayOfStyle[4] = JUST_FULL;
      $VALUES = arrayOfStyle;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.Overlay
 * JD-Core Version:    0.6.0
 */