package com.sportq.fit.fitmoudle8.widget.guide;

import android.animation.AnimatorSet;
import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.support.v4.content.ContextCompat;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle8.R.color;
import java.util.ArrayList;

public class FrameLayoutWithHole extends FrameLayout
{
  private Activity mActivity;
  private ArrayList<AnimatorSet> mAnimatorSetArrayList;
  private boolean mCleanUpLock = false;
  private float mDensity;
  private Paint mEraser;
  Bitmap mEraserBitmap;
  private Canvas mEraserCanvas;
  private Canvas mEraserCanvasBack;
  private TourGuide.MotionType mMotionType;
  private Overlay mOverlay;
  private Paint mPaint;
  private int[] mPos;
  private int mRadius;
  private RectF mRectF;
  private TextPaint mTextPaint;
  private View mViewHole;

  public FrameLayoutWithHole(Activity paramActivity, View paramView)
  {
    this(paramActivity, paramView, TourGuide.MotionType.ALLOW_ALL);
  }

  public FrameLayoutWithHole(Activity paramActivity, View paramView, TourGuide.MotionType paramMotionType)
  {
    this(paramActivity, paramView, paramMotionType, new Overlay());
  }

  public FrameLayoutWithHole(Activity paramActivity, View paramView, TourGuide.MotionType paramMotionType, Overlay paramOverlay)
  {
    super(paramActivity);
    this.mActivity = paramActivity;
    this.mViewHole = paramView;
    init(null, 0);
    enforceMotionType();
    this.mOverlay = paramOverlay;
    int[] arrayOfInt = new int[2];
    this.mViewHole.getLocationOnScreen(arrayOfInt);
    this.mPos = arrayOfInt;
    this.mDensity = paramActivity.getResources().getDisplayMetrics().density;
    int i = (int)(20.0F * this.mDensity);
    if (this.mViewHole.getHeight() > this.mViewHole.getWidth());
    for (this.mRadius = (i + this.mViewHole.getHeight() / 2); ; this.mRadius = (i + this.mViewHole.getWidth() / 2))
    {
      this.mMotionType = paramMotionType;
      if ((this.mOverlay != null) && (this.mOverlay.mStyle == Overlay.Style.ROUNDED_RECTANGLE))
      {
        int j = (int)(this.mOverlay.mPaddingDp * this.mDensity);
        this.mRectF = new RectF(this.mPos[0] - j + this.mOverlay.mHoleOffsetLeft, this.mPos[1] - j + this.mOverlay.mHoleOffsetTop, j + (this.mPos[0] + this.mViewHole.getWidth()) + this.mOverlay.mHoleOffsetLeft, j + (this.mPos[1] + this.mViewHole.getHeight()) + this.mOverlay.mHoleOffsetTop);
      }
      return;
    }
  }

  private static void dumpEvent(MotionEvent paramMotionEvent)
  {
    String[] arrayOfString = { "DOWN", "UP", "MOVE", "CANCEL", "OUTSIDE", "POINTER_DOWN", "POINTER_UP", "7?", "8?", "9?" };
    StringBuilder localStringBuilder = new StringBuilder();
    int i = paramMotionEvent.getAction();
    int j = i & 0xFF;
    localStringBuilder.append("event ACTION_").append(arrayOfString[j]);
    if ((j == 5) || (j == 6))
    {
      localStringBuilder.append("(pid ").append(i >> 8);
      localStringBuilder.append(")");
    }
    localStringBuilder.append("[");
    for (int k = 0; k < paramMotionEvent.getPointerCount(); k++)
    {
      localStringBuilder.append("#").append(k);
      localStringBuilder.append("(pid ").append(paramMotionEvent.getPointerId(k));
      localStringBuilder.append(")=").append((int)paramMotionEvent.getX(k));
      localStringBuilder.append(",").append((int)paramMotionEvent.getY(k));
      if (k + 1 >= paramMotionEvent.getPointerCount())
        continue;
      localStringBuilder.append(";");
    }
    localStringBuilder.append("]");
    Log.d("tourguide", localStringBuilder.toString());
  }

  private void enforceMotionType()
  {
    Log.d("tourguide", "enforceMotionType 1");
    if (this.mViewHole != null)
    {
      Log.d("tourguide", "enforceMotionType 2");
      if ((this.mMotionType == null) || (this.mMotionType != TourGuide.MotionType.CLICK_ONLY))
        break label72;
      Log.d("tourguide", "enforceMotionType 3");
      Log.d("tourguide", "only Clicking");
      this.mViewHole.setOnTouchListener(new View.OnTouchListener()
      {
        public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
        {
          FrameLayoutWithHole.this.mViewHole.getParent().requestDisallowInterceptTouchEvent(true);
          return false;
        }
      });
    }
    label72: 
    do
      return;
    while ((this.mMotionType == null) || (this.mMotionType != TourGuide.MotionType.SWIPE_ONLY));
    Log.d("tourguide", "enforceMotionType 4");
    Log.d("tourguide", "only Swiping");
    this.mViewHole.setClickable(false);
  }

  private void init(AttributeSet paramAttributeSet, int paramInt)
  {
    setWillNotDraw(false);
    this.mTextPaint = new TextPaint();
    this.mTextPaint.setFlags(1);
    this.mTextPaint.setTextAlign(Paint.Align.LEFT);
    Point localPoint = new Point();
    DisplayMetrics localDisplayMetrics = new DisplayMetrics();
    if (Build.VERSION.SDK_INT >= 17)
      this.mActivity.getWindowManager().getDefaultDisplay().getRealMetrics(localDisplayMetrics);
    while (true)
    {
      localPoint.x = localDisplayMetrics.widthPixels;
      localPoint.y = localDisplayMetrics.heightPixels;
      this.mEraserBitmap = Bitmap.createBitmap(localPoint.x, localPoint.y, Bitmap.Config.ARGB_8888);
      this.mEraserCanvas = new Canvas(this.mEraserBitmap);
      this.mEraserCanvasBack = new Canvas(this.mEraserBitmap);
      this.mPaint = new Paint();
      this.mPaint.setColor(-872415232);
      this.mEraser = new Paint();
      this.mEraser.setColor(-1);
      this.mEraser.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
      this.mEraser.setFlags(1);
      return;
      this.mActivity.getWindowManager().getDefaultDisplay().getMetrics(localDisplayMetrics);
    }
  }

  private boolean isWithinButton(MotionEvent paramMotionEvent)
  {
    int[] arrayOfInt = new int[2];
    this.mViewHole.getLocationOnScreen(arrayOfInt);
    return (paramMotionEvent.getRawY() >= arrayOfInt[1]) && (paramMotionEvent.getRawY() <= arrayOfInt[1] + this.mViewHole.getHeight()) && (paramMotionEvent.getRawX() >= arrayOfInt[0]) && (paramMotionEvent.getRawX() <= arrayOfInt[0] + this.mViewHole.getWidth());
  }

  private void performOverlayExitAnimation()
  {
    if (!this.mCleanUpLock)
    {
      this.mCleanUpLock = true;
      Log.d("tourguide", "Overlay exit animation listener is overwritten...");
      this.mOverlay.mExitAnimation.setAnimationListener(new Animation.AnimationListener(this)
      {
        public void onAnimationEnd(Animation paramAnimation)
        {
          ((ViewGroup)this.val$_pointerToFrameLayout.getParent()).removeView(this.val$_pointerToFrameLayout);
        }

        public void onAnimationRepeat(Animation paramAnimation)
        {
        }

        public void onAnimationStart(Animation paramAnimation)
        {
        }
      });
      startAnimation(this.mOverlay.mExitAnimation);
    }
  }

  public void addAnimatorSet(AnimatorSet paramAnimatorSet)
  {
    if (this.mAnimatorSetArrayList == null)
      this.mAnimatorSetArrayList = new ArrayList();
    this.mAnimatorSetArrayList.add(paramAnimatorSet);
  }

  protected void cleanUp()
  {
    if (getParent() != null)
    {
      if ((this.mOverlay != null) && (this.mOverlay.mExitAnimation != null))
        performOverlayExitAnimation();
    }
    else
      return;
    ((ViewGroup)getParent()).removeView(this);
  }

  public int getScreenHeight(Activity paramActivity)
  {
    return paramActivity.getResources().getDisplayMetrics().heightPixels;
  }

  public int getScreenWidth(Activity paramActivity)
  {
    return paramActivity.getResources().getDisplayMetrics().widthPixels;
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    if ((this.mOverlay != null) && (this.mOverlay.mEnterAnimation != null))
      startAnimation(this.mOverlay.mEnterAnimation);
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    this.mEraserCanvas.setBitmap(null);
    this.mEraserCanvasBack.setBitmap(null);
    this.mEraserBitmap = null;
    if ((this.mAnimatorSetArrayList != null) && (!this.mAnimatorSetArrayList.isEmpty()))
      for (int i = 0; i < this.mAnimatorSetArrayList.size(); i++)
      {
        ((AnimatorSet)this.mAnimatorSetArrayList.get(i)).end();
        ((AnimatorSet)this.mAnimatorSetArrayList.get(i)).removeAllListeners();
      }
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    this.mEraserBitmap.eraseColor(0);
    int i;
    if (this.mOverlay != null)
    {
      this.mEraserCanvasBack.drawColor(this.mOverlay.mBackgroundColor);
      i = (int)(this.mOverlay.mPaddingDp * this.mDensity);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(i);
      Log.i("TOURGUIDE", String.format("**********PADDING: %s**********", arrayOfObject));
      if (this.mOverlay.mStyle != Overlay.Style.RECTANGLE)
        break label195;
      this.mEraserCanvas.drawRect(this.mPos[0] - i + this.mOverlay.mHoleOffsetLeft, this.mPos[1] - i + this.mOverlay.mHoleOffsetTop, i + (this.mPos[0] + this.mViewHole.getWidth()) + this.mOverlay.mHoleOffsetLeft, i + (this.mPos[1] + this.mViewHole.getHeight()) + this.mOverlay.mHoleOffsetTop, this.mEraser);
    }
    while (true)
    {
      paramCanvas.drawBitmap(this.mEraserBitmap, 0.0F, 0.0F, null);
      return;
      label195: if (this.mOverlay.mStyle == Overlay.Style.NO_HOLE)
      {
        this.mEraserCanvas.drawCircle(this.mPos[0] + this.mViewHole.getWidth() / 2 + this.mOverlay.mHoleOffsetLeft, this.mPos[1] + this.mViewHole.getHeight() / 2 + this.mOverlay.mHoleOffsetTop, 0.0F, this.mEraser);
        continue;
      }
      if (this.mOverlay.mStyle == Overlay.Style.ROUNDED_RECTANGLE)
      {
        if (this.mOverlay.mRoundedCornerRadiusDp != 0);
        int n;
        for (int m = (int)(this.mOverlay.mRoundedCornerRadiusDp * this.mDensity); ; n = (int)(10.0F * this.mDensity))
        {
          this.mEraserCanvas.drawRoundRect(this.mRectF, m, m, this.mEraser);
          break;
        }
      }
      if (this.mOverlay.mStyle == Overlay.Style.CIRCLE)
      {
        if (this.mOverlay.mHoleRadius != -1);
        int k;
        for (int j = this.mOverlay.mHoleRadius; ; k = this.mRadius)
        {
          this.mEraserCanvas.drawCircle(this.mPos[0] + this.mViewHole.getWidth() / 2 + this.mOverlay.mHoleOffsetLeft, this.mPos[1] + this.mViewHole.getHeight() / 2 + this.mOverlay.mHoleOffsetTop, j, this.mEraser);
          Paint localPaint3 = new Paint();
          localPaint3.setColor(ContextCompat.getColor(this.mActivity, R.color.white));
          localPaint3.setStyle(Paint.Style.STROKE);
          localPaint3.setAntiAlias(true);
          localPaint3.setDither(true);
          localPaint3.setStrokeWidth(CompDeviceInfoUtils.convertOfDip(this.mActivity, 1.5F));
          this.mEraserCanvas.drawCircle(this.mPos[0] + this.mViewHole.getWidth() / 2 + this.mOverlay.mHoleOffsetLeft, this.mPos[1] + this.mViewHole.getHeight() / 2 + this.mOverlay.mHoleOffsetTop, j, localPaint3);
          break;
        }
      }
      if (this.mOverlay.mStyle != Overlay.Style.JUST_FULL)
        continue;
      if ((this.mOverlay.mFlag == 0) || (this.mOverlay.mFlag == 1))
      {
        float f = CompDeviceInfoUtils.convertOfDip(this.mActivity, 1.5F);
        new RectF(this.mPos[0] - i + this.mOverlay.mHoleOffsetLeft + f / 2.0F, this.mPos[1] + this.mOverlay.mHoleOffsetTop + f / 2.0F, i + (this.mPos[0] + this.mViewHole.getWidth()) + this.mOverlay.mHoleOffsetLeft - f / 2.0F, this.mPos[1] + this.mViewHole.getHeight() + this.mOverlay.mHoleOffsetTop - f / 2.0F);
        if (!(this.mViewHole instanceof TextView))
          continue;
        TextView localTextView = (TextView)this.mViewHole;
        localTextView.getBaseline();
        Paint localPaint1 = new Paint();
        localPaint1.setAntiAlias(true);
        localPaint1.setColor(ContextCompat.getColor(this.mActivity, R.color.white));
        localPaint1.setTextSize(localTextView.getTextSize());
        this.mEraserCanvas.drawText(localTextView.getText().toString(), this.mPos[0] + this.mOverlay.mHoleOffsetLeft, this.mPos[1] + localTextView.getBaseline(), localPaint1);
        continue;
      }
      Paint localPaint2 = new Paint();
      localPaint2.setColor(ContextCompat.getColor(this.mActivity, R.color.white));
      localPaint2.setStyle(Paint.Style.STROKE);
      localPaint2.setStrokeWidth(CompDeviceInfoUtils.convertOfDip(this.mActivity, 1.5F));
      this.mEraser.setStyle(Paint.Style.FILL);
      this.mEraserCanvas.drawRect(this.mPos[0] - i + this.mOverlay.mHoleOffsetLeft, this.mPos[1] - i + this.mOverlay.mHoleOffsetTop, i + (this.mPos[0] + this.mViewHole.getWidth()) + this.mOverlay.mHoleOffsetLeft, i + (this.mPos[1] + this.mViewHole.getHeight()) + this.mOverlay.mHoleOffsetTop, this.mEraser);
    }
  }

  public void setViewHole(View paramView)
  {
    this.mViewHole = paramView;
    enforceMotionType();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.FrameLayoutWithHole
 * JD-Core Version:    0.6.0
 */