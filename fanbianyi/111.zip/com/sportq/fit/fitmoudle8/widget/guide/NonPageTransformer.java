package com.sportq.fit.fitmoudle8.widget.guide;

import android.support.v4.view.ViewPager.PageTransformer;
import android.view.View;

public class NonPageTransformer
  implements ViewPager.PageTransformer
{
  public static final ViewPager.PageTransformer INSTANCE = new NonPageTransformer();

  public void transformPage(View paramView, float paramFloat)
  {
    paramView.setScaleX(0.999F);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.NonPageTransformer
 * JD-Core Version:    0.6.0
 */