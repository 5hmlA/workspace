package com.sportq.fit.fitmoudle8.widget.guide;

import android.graphics.Color;

public class Pointer
{
  public int mColor = -1;
  public int mGravity = 17;

  public Pointer()
  {
    this(17, Color.parseColor("#FFFFFF"));
  }

  public Pointer(int paramInt1, int paramInt2)
  {
    this.mGravity = paramInt1;
    this.mColor = paramInt2;
  }

  public Pointer setColor(int paramInt)
  {
    this.mColor = paramInt;
    return this;
  }

  public Pointer setGravity(int paramInt)
  {
    this.mGravity = paramInt;
    return this;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.guide.Pointer
 * JD-Core Version:    0.6.0
 */