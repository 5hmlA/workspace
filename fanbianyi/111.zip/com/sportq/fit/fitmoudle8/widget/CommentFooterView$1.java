package com.sportq.fit.fitmoudle8.widget;

import android.view.View;
import com.sportq.fit.browsepresenter.BrowsePresenter;
import com.sportq.fit.common.model.NewHotCommentModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.ContentCommentView.CommentClickListener;
import java.util.ArrayList;
import java.util.Iterator;

class CommentFooterView$1
  implements ContentCommentView.CommentClickListener
{
  public void onItemClick(View paramView, NewHotCommentModel paramNewHotCommentModel, int paramInt, String paramString)
  {
    FitJumpImpl.getInstance().jumpCommentList(this.this$0.getContext(), CommentFooterView.access$000(this.this$0).planId, "2", "", StringUtils.string2Int(CommentFooterView.access$000(this.this$0).commentNumber));
  }

  public void onLikeClick(NewHotCommentModel paramNewHotCommentModel)
  {
    Iterator localIterator = CommentFooterView.access$000(this.this$0).lstNewComment.iterator();
    NewHotCommentModel localNewHotCommentModel;
    String str;
    int i;
    while (localIterator.hasNext())
    {
      localNewHotCommentModel = (NewHotCommentModel)localIterator.next();
      if (!localNewHotCommentModel.commentId.equals(paramNewHotCommentModel.commentId))
        continue;
      if (!"0".equals(localNewHotCommentModel.isLike))
        break label169;
      str = "1";
      localNewHotCommentModel.isLike = str;
      if (!CompDeviceInfoUtils.checkNetwork())
        break;
      i = StringUtils.string2Int(localNewHotCommentModel.likeNum);
      if (!"1".equals(localNewHotCommentModel.isLike))
        break label176;
    }
    label169: label176: for (int j = 1; ; j = -1)
    {
      localNewHotCommentModel.likeNum = String.valueOf(i + j);
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.contentId = localNewHotCommentModel.commentId;
      localRequestModel.likeType = "2";
      localRequestModel.flg = localNewHotCommentModel.isLike;
      new BrowsePresenter(this.this$0).addLike(localRequestModel, this.this$0.getContext());
      return;
      str = "0";
      break;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.CommentFooterView.1
 * JD-Core Version:    0.6.0
 */