package com.sportq.fit.fitmoudle8.widget;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.data.VideoInfoData;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DownLoadListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.ActionModel.CommentErrorEntity;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.StageModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import com.sportq.fit.common.model.response.ResponseModel.ActionData.LstComment;
import com.sportq.fit.common.model.response.ResponseModel.ActionData.LstError;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle8.R.anim;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.fitmoudle8.presenter.PresenterImpl;
import com.sportq.fit.fitmoudle8.util.CourseSharePreUtils;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.supportlib.CommonUtils;
import com.sportq.fit.uicommon.R.color;
import com.sportq.fit.uicommon.R.layout;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

public class Find04TrainInfoTools
{
  private Find04GenTrainInfoActivity activity;
  private FitInterfaceUtils.DownLoadListener dListener;
  private String individualId;
  private Context mContext;
  private RequestModel requestModel;
  private String strPlanId;
  private String strType;
  private FitInterfaceUtils.UIInitListener uListener;

  public Find04TrainInfoTools()
  {
  }

  public Find04TrainInfoTools(Context paramContext, FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.mContext = paramContext;
    this.uListener = paramUIInitListener;
  }

  public Find04TrainInfoTools(Context paramContext, String paramString1, String paramString2, FitInterfaceUtils.UIInitListener paramUIInitListener, FitInterfaceUtils.DownLoadListener paramDownLoadListener)
  {
    this.mContext = paramContext;
    this.strPlanId = paramString1;
    this.strType = paramString2;
    this.uListener = paramUIInitListener;
    this.dListener = paramDownLoadListener;
    this.activity = ((Find04GenTrainInfoActivity)this.mContext);
  }

  public static ArrayList<ActionModel> actionPreview(PlanModel paramPlanModel)
  {
    if (paramPlanModel == null)
    {
      localArrayList = null;
      return localArrayList;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator1 = paramPlanModel.stageArray.iterator();
    while (localIterator1.hasNext())
    {
      Iterator localIterator2 = ((StageModel)localIterator1.next()).actionArray.iterator();
      while (localIterator2.hasNext())
      {
        ActionModel localActionModel = (ActionModel)localIterator2.next();
        if (!"0".equals(localActionModel.actionType))
          continue;
        localArrayList.add(localActionModel);
      }
    }
  }

  private boolean checkInitData(ArrayList<ActionModel> paramArrayList)
  {
    int i = 0;
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
    {
      if (((ActionModel)localIterator.next()).isRest())
        continue;
      i++;
    }
    return i == 6;
  }

  public static boolean checkVideoExists(String paramString1, String paramString2)
  {
    if (StringUtils.isNull(paramString2));
    String str3;
    do
    {
      do
        return false;
      while (paramString2.contains("/storage"));
      String str1 = VersionUpdateCheck.ALBUM_VIDEO_FILE_NAME + paramString1 + "/";
      String str2 = paramString2.substring(1 + paramString2.lastIndexOf("/"));
      if (str2.contains("?"))
        str2 = str2.substring(0, str2.lastIndexOf("?"));
      File localFile = new File(str1 + str2);
      boolean bool = localFile.exists();
      str3 = null;
      if (!bool)
        continue;
      str3 = localFile.getAbsolutePath();
    }
    while (str3 == null);
    return true;
  }

  public static String convertTrainName()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("fitFile");
    return localStringBuilder.toString();
  }

  public static String getAlbumTrainPath(String paramString)
  {
    return getAlbumTrainPath(convertTrainName(), paramString);
  }

  public static String getAlbumTrainPath(String paramString1, String paramString2)
  {
    String str1 = VersionUpdateCheck.ALBUM_VIDEO_FILE_NAME + paramString1 + "/";
    if (paramString2.contains("?"))
      paramString2 = paramString2.substring(0, paramString2.lastIndexOf("?"));
    boolean bool1 = paramString2.contains("/storage");
    String str2 = null;
    if (!bool1)
    {
      String str3 = paramString2.substring(1 + paramString2.lastIndexOf("/"));
      File localFile = new File(str1 + str3);
      boolean bool2 = localFile.exists();
      str2 = null;
      if (bool2)
        str2 = localFile.getAbsolutePath();
    }
    return str2;
  }

  private String getUrlName(String paramString)
  {
    String str1 = "";
    try
    {
      if (StringUtils.isNull(paramString))
        return "";
      if (!StringUtils.isNull(paramString))
      {
        if (paramString.contains("/"))
          return paramString.substring(1 + paramString.lastIndexOf("/"));
        if (paramString.contains("&"))
        {
          String str2 = paramString.split("&")[(-1 + paramString.split("&").length)];
          return str2;
        }
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      str1 = "";
    }
    return str1;
  }

  private void showUnlockSuccessDialog(UnLockDismissListener paramUnLockDismissListener, Context paramContext, String paramString)
  {
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setCancelable(true);
    localDialog.setContentView(R.layout.energy_unlock_success_layout);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.6944D * BaseApplication.screenWidth);
    localLayoutParams.height = (int)(0.6944D * BaseApplication.screenWidth);
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    ((GradientDrawable)((LinearLayout)localDialog.findViewById(com.sportq.fit.uicommon.R.id.load_bg_layout)).getBackground()).setColor(ContextCompat.getColor(paramContext, R.color.color_00b88a));
    if (!StringUtils.isNull(paramString))
      ((TextView)localDialog.findViewById(com.sportq.fit.fitmoudle8.R.id.state_hint)).setText(paramString);
    AnimationDrawable localAnimationDrawable = (AnimationDrawable)((ImageView)localDialog.findViewById(com.sportq.fit.uicommon.R.id.unlock_anim_view)).getDrawable();
    new Handler().postDelayed(new Runnable(paramContext, localAnimationDrawable)
    {
      public void run()
      {
        ((Activity)this.val$context).runOnUiThread(new Runnable()
        {
          public void run()
          {
            Find04TrainInfoTools.2.this.val$animationDrawable.start();
          }
        });
      }
    }
    , 200L);
    new Handler().postDelayed(new Runnable(paramContext, localAnimationDrawable, localDialog)
    {
      public void run()
      {
        ((Activity)this.val$context).runOnUiThread(new Runnable()
        {
          public void run()
          {
            if ((Find04TrainInfoTools.3.this.val$animationDrawable != null) && (Find04TrainInfoTools.3.this.val$animationDrawable.isRunning()))
              Find04TrainInfoTools.3.this.val$animationDrawable.stop();
            Find04TrainInfoTools.3.this.val$dialog.dismiss();
          }
        });
      }
    }
    , 2000L);
    localDialog.setOnDismissListener(new DialogInterface.OnDismissListener(paramUnLockDismissListener)
    {
      public void onDismiss(DialogInterface paramDialogInterface)
      {
        if (this.val$unLockDismissListener != null)
          this.val$unLockDismissListener.dialogDismiss();
      }
    });
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public void actionLibraryUnlockSuccessAnim(UnLockDismissListener paramUnLockDismissListener, Context paramContext, String paramString)
  {
    showUnlockSuccessDialog(paramUnLockDismissListener, paramContext, paramString);
  }

  public void checkCourseBgMusic(String paramString)
  {
    String[] arrayOfString = SharePreferenceUtils.getCourseBgMusicName(paramString).split("&");
    if ((arrayOfString.length == 6) && ("1".equals(arrayOfString[5])) && (!"1".equals(BaseApplication.userModel.isVip)))
      SharePreferenceUtils.putCourseBgMusicName(paramString, "");
  }

  public boolean checkIsUnLock(String paramString, ResponseModel.ActionData paramActionData)
  {
    if ("0".equals(paramActionData.energyActFlag));
    do
    {
      return true;
      if (StringUtils.isNull(paramActionData.endTime))
        return false;
    }
    while (Long.valueOf(DateUtils.date2TimeStamp(paramString, "yyyy-MM-dd HH:mm:ss")).longValue() < Long.valueOf(paramActionData.endTime).longValue());
    return false;
  }

  public ArrayList<ActionModel> convertActionData(ArrayList<ResponseModel.ActionData> paramArrayList)
  {
    int i = 0;
    int j = 0;
    int k = 0;
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator1 = paramArrayList.iterator();
    while (localIterator1.hasNext())
    {
      ResponseModel.ActionData localActionData = (ResponseModel.ActionData)localIterator1.next();
      if (!"0".equals(localActionData.type))
        continue;
      ActionModel localActionModel = new ActionModel();
      int m = i + 1;
      localActionModel.actionIndex = i;
      int n = k + 1;
      localActionModel.actionInGroupIndex = k;
      localActionModel.actionId = localActionData.actionId;
      localActionModel.actionName = localActionData.name;
      localActionModel.actionNameUp = String.valueOf(-1 + localActionModel.actionIndex);
      localActionModel.actionNameDown = String.valueOf(1 + localActionModel.actionIndex);
      localActionModel.actionType = localActionData.type;
      if ("0".equals(localActionModel.actionType))
      {
        int i1 = j + 1;
        localActionModel.indexWithOutRest = j;
        j = i1;
      }
      localActionModel.actionDuration = localActionData.duration;
      localActionModel.actionImageURL = localActionData.imageURL;
      localActionModel.actionVideoURL = localActionData.actionVideoURL;
      localActionModel.actionVoiceURL = localActionData.actionVoiceURL;
      localActionModel.difficultyLevel = StringUtils.difficultyLevel(localActionData.difficultyLevel);
      localActionModel.apparatus = localActionData.apparatus;
      localActionModel.part = localActionData.part;
      localActionModel.olapInfo = localActionData.olapInfo;
      localActionModel.isLike = localActionData.isLike;
      localActionModel.inputDate = localActionData.inputDate;
      localActionModel.energyActFlag = localActionData.energyActFlag;
      localActionModel.endTime = localActionData.endTime;
      localActionModel.lstComment = new ArrayList();
      localActionModel.lstError = new ArrayList();
      Iterator localIterator2 = localActionData.lstComment.iterator();
      while (localIterator2.hasNext())
      {
        ResponseModel.ActionData.LstComment localLstComment = (ResponseModel.ActionData.LstComment)localIterator2.next();
        ActionModel.CommentErrorEntity localCommentErrorEntity2 = new ActionModel.CommentErrorEntity();
        localCommentErrorEntity2.comment = localLstComment.comment;
        localCommentErrorEntity2.commentTitle = localLstComment.commentTitle;
        localActionModel.lstComment.add(localCommentErrorEntity2);
      }
      Iterator localIterator3 = localActionData.lstError.iterator();
      while (localIterator3.hasNext())
      {
        ResponseModel.ActionData.LstError localLstError = (ResponseModel.ActionData.LstError)localIterator3.next();
        ActionModel.CommentErrorEntity localCommentErrorEntity1 = new ActionModel.CommentErrorEntity();
        localCommentErrorEntity1.comment = localLstError.comment;
        localActionModel.lstError.add(localCommentErrorEntity1);
      }
      localActionModel.muscleImage = localActionData.muscleImage;
      localActionModel.hasActionInfo = localActionData.promptState;
      localActionModel.actionDurationUnit = localActionData.durationUnit;
      localActionModel.videoTime = localActionData.videoTime;
      localArrayList.add(localActionModel);
      k = n;
      i = m;
    }
    return localArrayList;
  }

  public ArrayList<ActionModel> convertData(PlanReformer paramPlanReformer, boolean paramBoolean)
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; ; i++)
      while (true)
      {
        int j;
        try
        {
          if (i >= paramPlanReformer._individualInfo.stageArray.size())
            continue;
          StageModel localStageModel = (StageModel)paramPlanReformer._individualInfo.stageArray.get(i);
          j = 0;
          if (j >= localStageModel.actionArray.size())
            break;
          ActionModel localActionModel1 = new ActionModel();
          ActionModel localActionModel2 = (ActionModel)localStageModel.actionArray.get(j);
          if (j == 0)
          {
            bool = true;
            localActionModel1.isFirst = bool;
            localActionModel1.stageName = localStageModel.stageName;
            localActionModel1.actionCount = localStageModel.actionCount;
            localActionModel1.actionIndex = localActionModel2.actionIndex;
            localActionModel1.actionInGroupIndex = localActionModel2.actionInGroupIndex;
            localActionModel1.actionGroupIndex = localActionModel2.actionGroupIndex;
            localActionModel1.actionId = localActionModel2.actionId;
            localActionModel1.actionName = localActionModel2.actionName;
            localActionModel1.actionNameUp = localActionModel2.actionNameUp;
            localActionModel1.actionNameDown = localActionModel2.actionNameDown;
            localActionModel1.actionType = localActionModel2.actionType;
            localActionModel1.indexWithOutRest = localActionModel2.indexWithOutRest;
            localActionModel1.actionDuration = localActionModel2.actionDuration;
            localActionModel1.actionImageURL = localActionModel2.actionImageURL;
            localActionModel1.actionVideoURL = localActionModel2.actionVideoURL;
            localActionModel1.actionVoiceURL = localActionModel2.actionVoiceURL;
            localActionModel1.difficultyLevel = localActionModel2.difficultyLevel;
            localActionModel1.apparatus = localActionModel2.apparatus;
            localActionModel1.part = localActionModel2.part;
            localActionModel1.olapInfo = localActionModel2.olapInfo;
            localActionModel1.lstComment = localActionModel2.lstComment;
            localActionModel1.lstError = localActionModel2.lstError;
            localActionModel1.muscleImage = localActionModel2.muscleImage;
            localActionModel1.hasActionInfo = localActionModel2.hasActionInfo;
            localActionModel1.actionDurationUnit = localActionModel2.actionDurationUnit;
            localActionModel1.videoTime = localActionModel2.videoTime;
            localActionModel1.videoSize = localActionModel2.videoSize;
            localActionModel1.voiceSize = localActionModel2.voiceSize;
            localActionModel1.endTime = localActionModel2.endTime;
            localActionModel1.energyActFlag = localActionModel2.energyActFlag;
            localActionModel1.inputDate = localActionModel2.inputDate;
            localActionModel1.isLike = localActionModel2.isLike;
            localArrayList.add(localActionModel1);
            if ((!checkInitData(localArrayList)) || (!paramBoolean))
              break label470;
            localArrayList.add(new ActionModel());
            return localArrayList;
            localArrayList.add(new ActionModel());
            return localArrayList;
          }
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
          return localArrayList;
        }
        boolean bool = false;
        continue;
        label470: j++;
      }
  }

  public void copyDefaultBgToMusicFile(ArrayList<VideoInfoData> paramArrayList, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    ArrayList localArrayList;
    File localFile1;
    int m;
    try
    {
      if (!CompDeviceInfoUtils.checkPermission(this.mContext, "android.permission.WRITE_EXTERNAL_STORAGE"))
        return;
      if (paramArrayList.size() == 0)
      {
        VideoInfoData localVideoInfoData1 = new VideoInfoData();
        localVideoInfoData1.musicId = paramString1;
        localVideoInfoData1.musicName = paramString2;
        localVideoInfoData1.categoryId = paramString3;
        localVideoInfoData1.linkUrl = paramString4;
        paramArrayList.add(localVideoInfoData1);
      }
      localArrayList = new ArrayList(paramArrayList);
      localFile1 = new File(VersionUpdateCheck.ALBUM_VIDEO_FILE_NAME + "fitFile/");
      File localFile2 = new File(VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME);
      if (localFile2.exists())
      {
        String[] arrayOfString = localFile2.list();
        if (arrayOfString != null)
        {
          int k = arrayOfString.length;
          m = 0;
          if (m < k)
          {
            String str4 = arrayOfString[m];
            if (str4.contains("&"))
            {
              Iterator localIterator2 = paramArrayList.iterator();
              VideoInfoData localVideoInfoData3;
              do
              {
                if (!localIterator2.hasNext())
                  break;
                localVideoInfoData3 = (VideoInfoData)localIterator2.next();
              }
              while (!localVideoInfoData3.musicName.equals(FileUtils.convertBgMusicName(str4)));
              localArrayList.remove(localVideoInfoData3);
              break label557;
            }
            File localFile5 = new File(VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME + str4);
            if (!localFile5.exists())
              break label557;
            localFile5.delete();
          }
        }
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      return;
    }
    File[] arrayOfFile;
    int i;
    if ((localFile1.exists()) && (localArrayList.size() > 0))
    {
      arrayOfFile = localFile1.listFiles();
      if (arrayOfFile != null)
        i = arrayOfFile.length;
    }
    for (int j = 0; ; j++)
    {
      if (j < i)
      {
        File localFile3 = arrayOfFile[j];
        Iterator localIterator1 = localArrayList.iterator();
        VideoInfoData localVideoInfoData2;
        do
        {
          if (!localIterator1.hasNext())
            break;
          localVideoInfoData2 = (VideoInfoData)localIterator1.next();
        }
        while (!getUrlName(localVideoInfoData2.linkUrl).equals(localFile3.getName()));
        File localFile4 = new File(VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME);
        if (!localFile4.exists())
          localFile4.mkdir();
        while (true)
        {
          String str1 = String.valueOf(System.currentTimeMillis());
          String str2 = localVideoInfoData2.musicName.replace(" ", "^");
          String str3 = str1 + "&" + str2 + "&" + localVideoInfoData2.categoryId + "&" + localVideoInfoData2.musicId + "&" + getUrlName(localVideoInfoData2.linkUrl);
          FileUtils.copyFolder(localFile3, new File(VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME + str3));
          break;
          if (localFile4.isDirectory())
            continue;
          localFile4.delete();
          localFile4.mkdir();
        }
      }
      return;
      label557: m++;
      break;
    }
  }

  public void courseProducts(RequestModel paramRequestModel)
  {
    new PresenterImpl(this.uListener).courseProducts(this.mContext, paramRequestModel);
  }

  public void energyUnlockSuccessAnim(Context paramContext, UnLockDismissListener paramUnLockDismissListener)
  {
    showUnlockSuccessDialog(paramUnLockDismissListener, paramContext, null);
  }

  public void getPlanDet()
  {
    this.requestModel = new RequestModel();
    this.requestModel.planId = this.strPlanId;
    RequestModel localRequestModel = this.requestModel;
    if ("0".equals(this.strType));
    for (String str = "0"; ; str = "1")
    {
      localRequestModel.flg = str;
      MiddleManager.getInstance().getFindPresenterImpl(this.uListener, this.dListener).getPlanInfoWithPlanId(this.requestModel, this.mContext);
      return;
    }
  }

  public void getVideoURL()
  {
    this.requestModel = new RequestModel();
    this.requestModel.planId = this.strPlanId;
    RequestModel localRequestModel = this.requestModel;
    if ("0".equals(this.strType));
    for (String str = "0"; ; str = "1")
    {
      localRequestModel.flg = str;
      MiddleManager.getInstance().getFindPresenterImpl(this.uListener, this.dListener).getVideoURL(this.requestModel, this.mContext);
      return;
    }
  }

  public void joinPlan(String paramString)
  {
    this.requestModel = new RequestModel();
    this.requestModel.planId = this.strPlanId;
    this.requestModel.flg = paramString;
    RequestModel localRequestModel = this.requestModel;
    if ("0".equals(this.strType));
    for (String str = "0"; ; str = "1")
    {
      localRequestModel.planType = str;
      new PresenterImpl(this.uListener).joinPlan(this.requestModel, this.mContext);
      return;
    }
  }

  public boolean recordDownloadedSingleId(boolean paramBoolean, ArrayList<String> paramArrayList)
  {
    String str = SharePreferenceUtils.getDownLoadedSinglePlanId(this.mContext);
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(str);
    if (paramBoolean)
    {
      if (StringUtils.isNull(str))
      {
        Iterator localIterator = paramArrayList.iterator();
        while (localIterator.hasNext())
        {
          localStringBuilder.append((String)localIterator.next());
          localStringBuilder.append(",");
        }
      }
      for (int i = 0; i < paramArrayList.size(); i++)
      {
        if (str.contains((CharSequence)paramArrayList.get(i)))
          continue;
        localStringBuilder.append((String)paramArrayList.get(i));
        localStringBuilder.append(",");
      }
      CourseSharePreUtils.putDownloadDialogStatus(this.mContext, CourseSharePreUtils.getDownloadDialogStatus(this.mContext) + this.strPlanId + ",");
    }
    while (true)
    {
      SharePreferenceUtils.putDownLoadedSinglePlanId(this.mContext, localStringBuilder.toString());
      CourseSharePreUtils.putDownloadDialogStatus(this.mContext, CourseSharePreUtils.getDownloadDialogStatus(this.mContext) + localStringBuilder.toString());
      return true;
      if ((!StringUtils.isNull(str)) && (str.contains(this.individualId)))
        continue;
      localStringBuilder.append(this.individualId);
      localStringBuilder.append(",");
    }
  }

  public void setIndividualId(String paramString)
  {
    this.individualId = paramString;
  }

  public void showAddCourseUI()
  {
    RelativeLayout localRelativeLayout = (RelativeLayout)((Activity)this.mContext).findViewById(com.sportq.fit.fitmoudle8.R.id.add_course_layout);
    if (localRelativeLayout != null)
    {
      Animation localAnimation = AnimationUtils.loadAnimation(this.mContext, R.anim.roll_up);
      localAnimation.setFillAfter(true);
      localRelativeLayout.setAnimation(localAnimation);
      localRelativeLayout.setVisibility(0);
      new Handler().postDelayed(new Runnable(localRelativeLayout)
      {
        public void run()
        {
          Animation localAnimation = AnimationUtils.loadAnimation(Find04TrainInfoTools.this.mContext, R.anim.roll_down);
          this.val$add_course_layout.startAnimation(localAnimation);
          this.val$add_course_layout.setVisibility(8);
        }
      }
      , 2000L);
    }
  }

  public void startPlan()
  {
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.planId = this.strPlanId;
    localRequestModel.individualId = this.individualId;
    MiddleManager.getInstance().getFindPresenterImpl(this.uListener, this.dListener).startPlan(localRequestModel, this.mContext);
  }

  public void unlockEnergyPlan()
  {
    CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.UnlockEnergyPlan);
    this.requestModel = new RequestModel();
    this.requestModel.planId = this.strPlanId;
    this.requestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.strPlanId + NdkUtils.getSignBaseUrl()).toUpperCase();
    new PresenterImpl(this.uListener).unlockEnergyPlan(this.mContext, this.requestModel);
  }

  public static abstract interface EquipmentItemClick
  {
    public abstract void equipItemClick();
  }

  public static abstract interface InitFinishListener
  {
    public abstract void initFinished();
  }

  public static abstract interface TrainMusicItemClick
  {
    public abstract void trainMusicItemClick();
  }

  public static abstract interface UnLockDismissListener
  {
    public abstract void dialogDismiss();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools
 * JD-Core Version:    0.6.0
 */