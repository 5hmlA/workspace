package com.sportq.fit.fitmoudle8.widget.allcourse;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.TranslateAnimation;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.ScreenModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.RView;
import com.sportq.fit.common.utils.superView.helper.RBaseHelper;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.mipmap;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;

public class CourseSiftingTitleView extends RelativeLayout
{
  private TextView auto_sort_tv;
  private Context context;
  private RTextView defSelSiftingView;
  private RTextView filter_icon;
  private HorizontalScrollView hor_scrollview;
  private RelativeLayout recomm_for_you_layout;
  private RView scroll_sifting_bg;
  private RelativeLayout search_title_layout;
  private OnDefSiftingItemClickListener siftingItemClickListener;
  private ImageView sifting_icon;
  private LinearLayout sifting_type_layout;
  private ImageView sort_arrow_icon;
  private OnDefaultSiftingValueSetListener valueSetListener;

  public CourseSiftingTitleView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public TextView getAuto_sort_tv()
  {
    return this.auto_sort_tv;
  }

  public void initSiftingHint(ArrayList<ArrayList<ScreenModel>> paramArrayList)
  {
    if (this.sifting_type_layout.getChildCount() != 0);
    do
      return;
    while ((paramArrayList == null) || (paramArrayList.size() == 0) || (paramArrayList.get(3) == null) || (((ArrayList)paramArrayList.get(3)).size() == 0));
    int i = CompDeviceInfoUtils.convertOfDip(this.context, 35.0F);
    this.sifting_type_layout.removeAllViews();
    Iterator localIterator = ((ArrayList)paramArrayList.get(3)).iterator();
    label73: ScreenModel localScreenModel;
    LinearLayout.LayoutParams localLayoutParams;
    if (localIterator.hasNext())
    {
      localScreenModel = (ScreenModel)localIterator.next();
      localLayoutParams = new LinearLayout.LayoutParams(-2, i);
      if (((ArrayList)paramArrayList.get(3)).indexOf(localScreenModel) != 0)
        break label396;
      localLayoutParams.leftMargin = CompDeviceInfoUtils.convertOfDip(this.context, 16.0F);
    }
    while (true)
    {
      localLayoutParams.bottomMargin = CompDeviceInfoUtils.convertOfDip(this.context, 5.0F);
      localLayoutParams.topMargin = CompDeviceInfoUtils.convertOfDip(this.context, 5.0F);
      RTextView localRTextView = new RTextView(this.context);
      localRTextView.setLayoutParams(localLayoutParams);
      int j = CompDeviceInfoUtils.convertOfDip(this.context, 18.0F);
      localRTextView.setPadding(j, 0, j, 0);
      localRTextView.setGravity(17);
      localRTextView.setText(localScreenModel.name);
      localRTextView.setTextSize(15.0F);
      localRTextView.setTextColor(ContextCompat.getColor(this.context, R.color.color_828282));
      if (((ArrayList)paramArrayList.get(3)).indexOf(localScreenModel) == 0)
      {
        this.defSelSiftingView = localRTextView;
        localRTextView.setTextSize(16.0F);
        if (this.valueSetListener != null)
          this.valueSetListener.onValueSet(localScreenModel.code, localScreenModel.olapInfo);
        localRTextView.setTextColor(ContextCompat.getColor(this.context, R.color.color_313131));
        localRTextView.getHelper().setBackgroundColorNormal(getResources().getColor(R.color.color_ffd208));
        localRTextView.getHelper().setCornerRadius(360.0F);
      }
      localRTextView.setOnClickListener(new DefaultSiftingItemClickListener(((ArrayList)paramArrayList.get(3)).indexOf(localScreenModel), localScreenModel.name, localScreenModel.code, localScreenModel.olapInfo));
      this.sifting_type_layout.addView(localRTextView);
      break label73;
      break;
      label396: if (((ArrayList)paramArrayList.get(3)).indexOf(localScreenModel) == -1 + ((ArrayList)paramArrayList.get(3)).size())
      {
        localLayoutParams.leftMargin = CompDeviceInfoUtils.convertOfDip(this.context, 10.0F);
        localLayoutParams.rightMargin = CompDeviceInfoUtils.convertOfDip(this.context, 16.0F);
        continue;
      }
      localLayoutParams.leftMargin = CompDeviceInfoUtils.convertOfDip(this.context, 10.0F);
    }
  }

  public void initUIElements(Context paramContext, View.OnClickListener paramOnClickListener, OnDefSiftingItemClickListener paramOnDefSiftingItemClickListener, OnDefaultSiftingValueSetListener paramOnDefaultSiftingValueSetListener, int paramInt)
  {
    this.context = paramContext;
    this.siftingItemClickListener = paramOnDefSiftingItemClickListener;
    this.valueSetListener = paramOnDefaultSiftingValueSetListener;
    findViewById(R.id.sifting_layout).setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        EventBus.getDefault().post("screen.click");
      }
    });
    this.sifting_icon = ((ImageView)findViewById(R.id.sifting_icon));
    this.scroll_sifting_bg = ((RView)findViewById(R.id.scroll_sifting_bg));
    this.scroll_sifting_bg.getHelper().setBackgroundColorNormal(getResources().getColor(R.color.color_ffd208));
    this.scroll_sifting_bg.getHelper().setCornerRadius(360.0F);
    View localView = findViewById(R.id.space_line);
    LinearLayout localLinearLayout = (LinearLayout)findViewById(R.id.search_child_layout);
    this.sifting_type_layout = ((LinearLayout)findViewById(R.id.sifting_type_layout));
    this.hor_scrollview = ((HorizontalScrollView)findViewById(R.id.hor_scrollview));
    this.search_title_layout = ((RelativeLayout)findViewById(R.id.search_title_layout));
    this.recomm_for_you_layout = ((RelativeLayout)findViewById(R.id.recomm_for_you_layout));
    this.recomm_for_you_layout.setOnClickListener(paramOnClickListener);
    RelativeLayout localRelativeLayout = (RelativeLayout)findViewById(R.id.auto_sort_layout);
    localRelativeLayout.setMinimumWidth(BaseApplication.screenWidth / 2);
    localRelativeLayout.setOnClickListener(paramOnClickListener);
    ((RelativeLayout)findViewById(R.id.filter_layout)).setOnClickListener(paramOnClickListener);
    this.filter_icon = ((RTextView)findViewById(R.id.filter_icon));
    this.sort_arrow_icon = ((ImageView)findViewById(R.id.sort_arrow_icon));
    this.auto_sort_tv = ((TextView)findViewById(R.id.auto_sort_tv));
    if (paramInt == 0)
    {
      findViewById(R.id.sifting_layout).setVisibility(8);
      localView.setVisibility(0);
      localLinearLayout.setVisibility(0);
      return;
    }
    findViewById(R.id.sifting_layout).setVisibility(0);
    localView.setVisibility(8);
    localLinearLayout.setVisibility(8);
  }

  public void setSiftingIcon(boolean paramBoolean)
  {
    ImageView localImageView = this.sifting_icon;
    if (paramBoolean);
    for (int i = R.mipmap.sifting_press_status_icon; ; i = R.mipmap.sifting_default_status_icon)
    {
      localImageView.setImageResource(i);
      return;
    }
  }

  public void setSiftingIconStatus(boolean paramBoolean1, boolean paramBoolean2, int paramInt)
  {
    int k;
    Drawable localDrawable;
    ImageView localImageView;
    if (paramBoolean1)
    {
      Resources localResources2 = getResources();
      if (paramBoolean2)
      {
        k = R.mipmap.select_filter_up;
        localDrawable = localResources2.getDrawable(k);
        localDrawable.setBounds(0, 0, localDrawable.getMinimumWidth(), localDrawable.getMinimumHeight());
        if (paramInt != 0)
          break label123;
        localImageView = this.sort_arrow_icon;
        if (!paramBoolean1)
          break label115;
      }
    }
    label115: for (int j = R.mipmap.default_filter_up; ; j = R.mipmap.default_filter_down)
    {
      localImageView.setImageResource(j);
      return;
      k = R.mipmap.default_filter_up;
      break;
      Resources localResources1 = getResources();
      if (paramBoolean2);
      for (int i = R.mipmap.select_filter_down; ; i = R.mipmap.default_filter_down)
      {
        localDrawable = localResources1.getDrawable(i);
        break;
      }
    }
    label123: this.filter_icon.getHelper().setIconNormal(localDrawable);
  }

  public void showSearchOrNewArrivalView(String paramString)
  {
    int i = 8;
    RelativeLayout localRelativeLayout1 = this.search_title_layout;
    int j;
    RelativeLayout localRelativeLayout2;
    if ("0".equals(paramString))
    {
      j = 0;
      localRelativeLayout1.setVisibility(j);
      localRelativeLayout2 = this.recomm_for_you_layout;
      if (!"0".equals(paramString))
        break label56;
    }
    while (true)
    {
      localRelativeLayout2.setVisibility(i);
      return;
      j = i;
      break;
      label56: i = 0;
    }
  }

  private class DefaultSiftingItemClickListener
    implements View.OnClickListener
  {
    private String code;
    private int curIndex;
    private String name;
    private String olaInfo;

    DefaultSiftingItemClickListener(int paramString1, String paramString2, String paramString3, String arg5)
    {
      this.curIndex = paramString1;
      this.name = paramString2;
      this.code = paramString3;
      Object localObject;
      this.olaInfo = localObject;
    }

    @Instrumented
    public void onClick(View paramView)
    {
      VdsAgent.onClick(this, paramView);
      if ((CourseSiftingTitleView.this.scroll_sifting_bg.getTag() != null) && (this.curIndex == Integer.valueOf(String.valueOf(CourseSiftingTitleView.this.scroll_sifting_bg.getTag())).intValue()))
        return;
      CourseSiftingTitleView.this.scroll_sifting_bg.setTag(Integer.valueOf(this.curIndex));
      if (this.curIndex > 0)
      {
        int i = CompDeviceInfoUtils.convertOfDip(CourseSiftingTitleView.this.context, 76.0F);
        CourseSiftingTitleView.this.hor_scrollview.smoothScrollTo(i * (-1 + this.curIndex), 0);
      }
      while (true)
      {
        CourseSiftingTitleView.this.defSelSiftingView.setTextSize(15.0F);
        CourseSiftingTitleView.this.defSelSiftingView.setTypeface(Typeface.defaultFromStyle(0));
        CourseSiftingTitleView.this.defSelSiftingView.setBackgroundColor(ContextCompat.getColor(CourseSiftingTitleView.this.context, 17170445));
        CourseSiftingTitleView.this.defSelSiftingView.setTextColor(ContextCompat.getColor(CourseSiftingTitleView.this.context, R.color.color_828282));
        CourseSiftingTitleView.this.scroll_sifting_bg.setLayoutParams(new RelativeLayout.LayoutParams(paramView.getWidth(), paramView.getHeight()));
        ((RelativeLayout.LayoutParams)CourseSiftingTitleView.this.scroll_sifting_bg.getLayoutParams()).topMargin = ((LinearLayout.LayoutParams)paramView.getLayoutParams()).topMargin;
        ((RelativeLayout.LayoutParams)CourseSiftingTitleView.this.scroll_sifting_bg.getLayoutParams()).leftMargin = 0;
        ((RelativeLayout.LayoutParams)CourseSiftingTitleView.this.scroll_sifting_bg.getLayoutParams()).bottomMargin = ((LinearLayout.LayoutParams)paramView.getLayoutParams()).bottomMargin;
        TranslateAnimation localTranslateAnimation = new TranslateAnimation(CourseSiftingTitleView.this.defSelSiftingView.getX(), paramView.getX(), 0.0F, 0.0F);
        localTranslateAnimation.setDuration(280L);
        localTranslateAnimation.setFillAfter(true);
        CourseSiftingTitleView.this.scroll_sifting_bg.startAnimation(localTranslateAnimation);
        ((RTextView)paramView).setTextColor(ContextCompat.getColor(CourseSiftingTitleView.this.context, R.color.color_313131));
        ((TextView)paramView).setTextSize(16.0F);
        CourseSiftingTitleView.access$302(CourseSiftingTitleView.this, (RTextView)paramView);
        new Handler().postDelayed(new Runnable()
        {
          public void run()
          {
            if (CourseSiftingTitleView.this.siftingItemClickListener != null)
              CourseSiftingTitleView.this.siftingItemClickListener.onDefSiftingItemClick(CourseSiftingTitleView.DefaultSiftingItemClickListener.this.name, CourseSiftingTitleView.DefaultSiftingItemClickListener.this.code, CourseSiftingTitleView.DefaultSiftingItemClickListener.this.olaInfo);
          }
        }
        , 300L);
        return;
        CourseSiftingTitleView.this.hor_scrollview.smoothScrollTo(0, 0);
      }
    }
  }

  public static abstract interface OnDefSiftingItemClickListener
  {
    public abstract void onDefSiftingItemClick(String paramString1, String paramString2, String paramString3);
  }

  public static abstract interface OnDefaultSiftingValueSetListener
  {
    public abstract void onValueSet(String paramString1, String paramString2);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.allcourse.CourseSiftingTitleView
 * JD-Core Version:    0.6.0
 */