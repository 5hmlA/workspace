package com.sportq.fit.fitmoudle8.widget.allcourse;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import android.widget.GridView;

public class SiftingGridView extends GridView
{
  public SiftingGridView(Context paramContext)
  {
    super(paramContext);
  }

  public SiftingGridView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, View.MeasureSpec.makeMeasureSpec(536870911, -2147483648));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.allcourse.SiftingGridView
 * JD-Core Version:    0.6.0
 */