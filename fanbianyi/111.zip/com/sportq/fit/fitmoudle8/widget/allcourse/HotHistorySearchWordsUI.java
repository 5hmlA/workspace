package com.sportq.fit.fitmoudle8.widget.allcourse;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.layout;
import com.sportq.fit.fitmoudle8.reformer.model.HotWordsModel;
import com.sportq.fit.fitmoudle8.util.CourseSharePreUtils;
import java.util.ArrayList;
import java.util.Iterator;

public class HotHistorySearchWordsUI extends ScrollView
{
  private Context context;
  private FlowLayout flow_layout;
  private LinearLayout history_search;
  private RelativeLayout hot_search_layout;
  private CourseTitleView.OnSearchListener searchListener;
  private int searchType = -1;
  private RelativeLayout search_history_layout;

  public HotHistorySearchWordsUI(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public int getSearchType()
  {
    return this.searchType;
  }

  public HotHistorySearchWordsUI initElements(Context paramContext, View.OnClickListener paramOnClickListener, CourseTitleView.OnSearchListener paramOnSearchListener)
  {
    this.context = paramContext;
    this.searchListener = paramOnSearchListener;
    this.hot_search_layout = ((RelativeLayout)findViewById(R.id.hot_search_layout));
    this.flow_layout = ((FlowLayout)findViewById(R.id.flow_layout));
    this.history_search = ((LinearLayout)findViewById(R.id.history_search));
    ((TextView)findViewById(R.id.clear_search_record)).setOnClickListener(paramOnClickListener);
    this.search_history_layout = ((RelativeLayout)findViewById(R.id.search_history_layout));
    return this;
  }

  public void setHistoryData()
  {
    int i = 0;
    String str1 = CourseSharePreUtils.getHistorySearchHint(this.context);
    if (StringUtils.isNull(str1))
      this.search_history_layout.setVisibility(8);
    while (true)
    {
      return;
      this.search_history_layout.setVisibility(0);
      String[] arrayOfString = str1.split("±");
      if (arrayOfString.length <= 0)
        break;
      this.history_search.removeAllViews();
      int j = arrayOfString.length;
      while (i < j)
      {
        String str2 = arrayOfString[i];
        View localView = LayoutInflater.from(this.context).inflate(R.layout.search_history_item, null);
        ImageView localImageView = (ImageView)localView.findViewById(R.id.search_close);
        ((TextView)localView.findViewById(R.id.history_name)).setText(str2);
        localImageView.setOnClickListener(new View.OnClickListener(str2)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            CourseSharePreUtils.putHistorySearchHint(HotHistorySearchWordsUI.this.context, this.val$strSearchWord, true);
            HotHistorySearchWordsUI.this.setHistoryData();
          }
        });
        localView.setOnClickListener(new View.OnClickListener(str2)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            if (HotHistorySearchWordsUI.this.searchListener != null)
              HotHistorySearchWordsUI.this.searchListener.onSetText(this.val$strSearchWord);
          }
        });
        this.history_search.addView(localView);
        i++;
      }
    }
    this.history_search.removeAllViews();
    this.search_history_layout.setVisibility(8);
  }

  public void setHotSearchWords(ArrayList<HotWordsModel> paramArrayList)
  {
    Iterator localIterator;
    if ((paramArrayList != null) && (paramArrayList.size() > 0))
    {
      this.hot_search_layout.setVisibility(0);
      this.flow_layout.removeAllViews();
      localIterator = paramArrayList.iterator();
    }
    while (localIterator.hasNext())
    {
      HotWordsModel localHotWordsModel = (HotWordsModel)localIterator.next();
      RTextView localRTextView = new RTextView(this.context);
      localRTextView.setTextSize(14.0F);
      localRTextView.setText(localHotWordsModel.wordName);
      localRTextView.setTextColor(ContextCompat.getColor(this.context, R.color.color_313131));
      localRTextView.getHelper().setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_f7f7f7));
      localRTextView.getHelper().setCornerRadius(CompDeviceInfoUtils.convertOfDip(getContext(), 180.0F));
      int i = CompDeviceInfoUtils.convertOfDip(this.context, 8.0F);
      int j = CompDeviceInfoUtils.convertOfDip(this.context, 15.0F);
      localRTextView.setPadding(j, i, j, i);
      ViewGroup.MarginLayoutParams localMarginLayoutParams = new ViewGroup.MarginLayoutParams(-2, -2);
      localMarginLayoutParams.rightMargin = CompDeviceInfoUtils.convertOfDip(this.context, 10.0F);
      localMarginLayoutParams.topMargin = CompDeviceInfoUtils.convertOfDip(this.context, 5.0F);
      localMarginLayoutParams.bottomMargin = CompDeviceInfoUtils.convertOfDip(this.context, 5.0F);
      this.flow_layout.addView(localRTextView, localMarginLayoutParams);
      localRTextView.setOnClickListener(new View.OnClickListener(localHotWordsModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (HotHistorySearchWordsUI.this.searchListener != null)
          {
            HotHistorySearchWordsUI.access$202(HotHistorySearchWordsUI.this, 1);
            HotHistorySearchWordsUI.this.searchListener.onSetText(this.val$model.wordName);
            CourseSharePreUtils.putHistorySearchHint(HotHistorySearchWordsUI.this.context, this.val$model.wordName, false);
          }
        }
      });
      continue;
      this.hot_search_layout.setVisibility(8);
    }
  }

  public void setSearchType(int paramInt)
  {
    this.searchType = paramInt;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.allcourse.HotHistorySearchWordsUI
 * JD-Core Version:    0.6.0
 */