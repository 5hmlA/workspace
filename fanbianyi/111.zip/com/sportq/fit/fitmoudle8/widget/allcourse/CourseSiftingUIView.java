package com.sportq.fit.fitmoudle8.widget.allcourse;

import android.content.Context;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.ScrollView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.ScreenModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.R.anim;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.drawable;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.layout;
import com.sportq.fit.fitmoudle8.adapter.SiftingGridViewAdapter;
import java.util.ArrayList;
import java.util.HashMap;

public class CourseSiftingUIView extends RelativeLayout
{
  public RelativeLayout all_sifting_layout;
  private SiftingGridViewAdapter apparatusAdapter;
  private SiftingGridView apparatus_gridview;
  private Context context;
  private SiftingGridViewAdapter diffAdapter;
  private SiftingGridView diff_gridview;
  private View drop_view_bg;
  private SiftingGridViewAdapter partAdapter;
  private SiftingGridView part_gridview;
  private HashMap<String, String> searchMap;
  private boolean siftingChangeFlg = false;
  private ScrollView sifting_scrollview;
  private LinearLayout sort_linear;
  public ScrollView sort_scrollview;

  public CourseSiftingUIView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  private void checkScrollViewMaxHeight(ArrayList<ArrayList<ScreenModel>> paramArrayList)
  {
    int i;
    int j;
    int k;
    label89: int m;
    int n;
    label151: int i1;
    if (((ArrayList)paramArrayList.get(0)).size() % 4 == 0)
    {
      i = ((ArrayList)paramArrayList.get(0)).size() / 4;
      j = (int)(i * (0.09259249999999999D * BaseApplication.screenWidth) + (i + 3) * CompDeviceInfoUtils.convertOfDip(this.context, 8.0F));
      if (((ArrayList)paramArrayList.get(1)).size() % 4 != 0)
        break label313;
      k = ((ArrayList)paramArrayList.get(1)).size() / 4;
      m = (int)(k * (0.09259249999999999D * BaseApplication.screenWidth) + (k + 3) * CompDeviceInfoUtils.convertOfDip(this.context, 8.0F));
      if (((ArrayList)paramArrayList.get(2)).size() % 2 != 0)
        break label333;
      n = ((ArrayList)paramArrayList.get(2)).size() / 2;
      i1 = (int)(n * (0.166666D * BaseApplication.screenWidth) + (n + 3) * CompDeviceInfoUtils.convertOfDip(this.context, 8.0F));
      if (((ArrayList)paramArrayList.get(3)).size() % 2 != 0)
        break label353;
    }
    label313: label333: label353: for (int i2 = ((ArrayList)paramArrayList.get(3)).size() / 2; ; i2 = 1 + ((ArrayList)paramArrayList.get(3)).size() / 2)
    {
      if ((int)(i2 * (0.09259249999999999D * BaseApplication.screenWidth) + (i1 + 3) * CompDeviceInfoUtils.convertOfDip(this.context, 8.0F)) + (i1 + (j + m)) > 0.58D * BaseApplication.screenHeight)
      {
        RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(BaseApplication.screenWidth, (int)(0.58D * BaseApplication.screenHeight));
        this.sifting_scrollview.setLayoutParams(localLayoutParams);
      }
      return;
      i = 1 + ((ArrayList)paramArrayList.get(0)).size() / 4;
      break;
      k = 1 + ((ArrayList)paramArrayList.get(1)).size() / 4;
      break label89;
      n = 1 + ((ArrayList)paramArrayList.get(2)).size() / 2;
      break label151;
    }
  }

  private String convertString(String paramString, View paramView)
  {
    String[] arrayOfString = paramString.split(",");
    StringBuilder localStringBuilder = new StringBuilder();
    int i = arrayOfString.length;
    for (int j = 0; j < i; j++)
    {
      String str = arrayOfString[j];
      if (str.equals(paramView.getTag()))
        continue;
      localStringBuilder.append(str);
      localStringBuilder.append(",");
    }
    return localStringBuilder.toString();
  }

  private void siftingOnItemClickAction(SiftingGridView paramSiftingGridView, int paramInt, ArrayList<ScreenModel> paramArrayList)
  {
    paramSiftingGridView.setOnItemClickListener(new AdapterView.OnItemClickListener(paramInt, paramArrayList)
    {
      @Instrumented
      public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
      {
        VdsAgent.onItemClick(this, paramAdapterView, paramView, paramInt, paramLong);
        TextView localTextView = (TextView)paramView.findViewById(R.id.sifting_itemview02);
        if (StringUtils.isNull(String.valueOf(localTextView.getTag())))
        {
          paramView.setBackgroundResource(R.drawable.sifting_select_bg);
          if (this.val$type == 2)
            localTextView.setTextColor(ContextCompat.getColor(CourseSiftingUIView.this.context, R.color.color_313131));
          if (this.val$type == 0)
            if (!StringUtils.isNull((String)CourseSiftingUIView.this.searchMap.get("2")))
              CourseSiftingUIView.this.searchMap.put("2", (String)CourseSiftingUIView.this.searchMap.get("2") + ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
          while (true)
          {
            localTextView.setTag(((ScreenModel)this.val$screenList.get(paramInt)).code);
            CourseSiftingUIView.access$502(CourseSiftingUIView.this, true);
            return;
            CourseSiftingUIView.this.searchMap.put("2", ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
            continue;
            if (this.val$type == 1)
            {
              if (!StringUtils.isNull((String)CourseSiftingUIView.this.searchMap.get("1")))
              {
                CourseSiftingUIView.this.searchMap.put("1", (String)CourseSiftingUIView.this.searchMap.get("1") + ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
                continue;
              }
              CourseSiftingUIView.this.searchMap.put("1", ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
              continue;
            }
            if (this.val$type != 2)
              continue;
            if (!StringUtils.isNull((String)CourseSiftingUIView.this.searchMap.get("0")))
            {
              CourseSiftingUIView.this.searchMap.put("0", (String)CourseSiftingUIView.this.searchMap.get("0") + ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
              continue;
            }
            CourseSiftingUIView.this.searchMap.put("0", ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
          }
        }
        paramView.setBackgroundResource(R.drawable.sifting_item_bg);
        if (this.val$type == 2)
          localTextView.setTextColor(ContextCompat.getColor(CourseSiftingUIView.this.context, R.color.color_828282));
        if (this.val$type == 0)
          CourseSiftingUIView.this.searchMap.put("2", CourseSiftingUIView.this.convertString((String)CourseSiftingUIView.this.searchMap.get("2"), localTextView));
        while (true)
        {
          localTextView.setTag(null);
          break;
          if (this.val$type == 1)
          {
            CourseSiftingUIView.this.searchMap.put("1", CourseSiftingUIView.this.convertString((String)CourseSiftingUIView.this.searchMap.get("1"), localTextView));
            continue;
          }
          if (this.val$type != 2)
            continue;
          CourseSiftingUIView.this.searchMap.put("0", CourseSiftingUIView.this.convertString((String)CourseSiftingUIView.this.searchMap.get("0"), localTextView));
        }
      }
    });
  }

  public void closeDropSiftingView(int paramInt)
  {
    Object localObject;
    Animation localAnimation;
    if (paramInt == 0)
    {
      localObject = this.sort_scrollview.getTag();
      if (localObject != null)
      {
        this.siftingChangeFlg = false;
        localAnimation = AnimationUtils.loadAnimation(this.context, R.anim.roll_up);
        if (paramInt != 0)
          break label85;
        this.sort_scrollview.setTag(null);
        this.sort_scrollview.startAnimation(localAnimation);
      }
    }
    while (true)
    {
      this.drop_view_bg.setVisibility(4);
      localAnimation.setAnimationListener(new Animation.AnimationListener(paramInt)
      {
        public void onAnimationEnd(Animation paramAnimation)
        {
          if (this.val$initType == 0)
            CourseSiftingUIView.this.sort_scrollview.setVisibility(4);
          while (true)
          {
            CourseSiftingUIView.this.setVisibility(4);
            return;
            CourseSiftingUIView.this.all_sifting_layout.setVisibility(4);
          }
        }

        public void onAnimationRepeat(Animation paramAnimation)
        {
        }

        public void onAnimationStart(Animation paramAnimation)
        {
        }
      });
      return;
      localObject = this.all_sifting_layout.getTag();
      break;
      label85: this.all_sifting_layout.setTag(null);
      this.all_sifting_layout.startAnimation(localAnimation);
    }
  }

  public int getDropDownType()
  {
    if (this.sort_scrollview.getTag() != null)
      return 0;
    return 1;
  }

  public HashMap<String, String> getSearchMap()
  {
    return this.searchMap;
  }

  public void initDropDownUI(ArrayList<ArrayList<ScreenModel>> paramArrayList, OnSortItemClickListener paramOnSortItemClickListener)
  {
    if (this.diff_gridview.getChildCount() == 0)
    {
      checkScrollViewMaxHeight(paramArrayList);
      this.diffAdapter = new SiftingGridViewAdapter(this.context, 1, (ArrayList)paramArrayList.get(2));
      siftingOnItemClickAction(this.diff_gridview, 0, (ArrayList)paramArrayList.get(2));
      this.diff_gridview.setAdapter(this.diffAdapter);
      this.apparatusAdapter = new SiftingGridViewAdapter(this.context, 2, (ArrayList)paramArrayList.get(1));
      siftingOnItemClickAction(this.apparatus_gridview, 1, (ArrayList)paramArrayList.get(1));
      this.apparatus_gridview.setAdapter(this.apparatusAdapter);
      this.partAdapter = new SiftingGridViewAdapter(this.context, 3, (ArrayList)paramArrayList.get(0));
      siftingOnItemClickAction(this.part_gridview, 2, (ArrayList)paramArrayList.get(0));
      this.part_gridview.setAdapter(this.partAdapter);
    }
    if (this.sort_linear.getChildCount() == 0)
    {
      this.sort_linear.removeAllViews();
      int i;
      int j;
      label218: int k;
      View localView1;
      View localView2;
      TextView localTextView;
      int m;
      label295: Context localContext;
      if (this.sort_linear.getTag() != null)
      {
        i = Integer.valueOf(String.valueOf(this.sort_linear.getTag())).intValue();
        j = 0;
        if (j >= ((ArrayList)paramArrayList.get(4)).size())
          return;
        k = j;
        localView1 = LayoutInflater.from(this.context).inflate(R.layout.course_sort_item, null);
        this.sort_linear.addView(localView1);
        localView2 = localView1.findViewById(R.id.space_view);
        localTextView = (TextView)localView1.findViewById(R.id.sort_hint);
        if (j != i)
          break label387;
        m = 0;
        localView2.setVisibility(m);
        localContext = this.context;
        if (j != i)
          break label393;
      }
      label387: label393: for (int n = R.color.color_313131; ; n = R.color.color_828282)
      {
        localTextView.setTextColor(ContextCompat.getColor(localContext, n));
        localTextView.setText(((ScreenModel)((ArrayList)paramArrayList.get(4)).get(j)).name);
        localView1.setOnClickListener(new View.OnClickListener(localView2, localTextView, paramArrayList, k, paramOnSortItemClickListener)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            Object localObject = CourseSiftingUIView.this.sort_linear.getTag();
            int i = 0;
            if (localObject != null)
              i = Integer.valueOf(String.valueOf(CourseSiftingUIView.this.sort_linear.getTag())).intValue();
            View localView = CourseSiftingUIView.this.sort_linear.getChildAt(i).findViewById(R.id.space_view);
            TextView localTextView = (TextView)CourseSiftingUIView.this.sort_linear.getChildAt(i).findViewById(R.id.sort_hint);
            if ((localView != null) && (localTextView != null))
            {
              localView.setVisibility(4);
              localTextView.setTextColor(ContextCompat.getColor(CourseSiftingUIView.this.context, R.color.color_828282));
            }
            this.val$space_view.setVisibility(0);
            this.val$sort_hint.setTextColor(ContextCompat.getColor(CourseSiftingUIView.this.context, R.color.color_313131));
            CourseSiftingUIView.this.searchMap.put("4", ((ScreenModel)((ArrayList)this.val$screenList.get(4)).get(this.val$curIndex)).code);
            if ((this.val$sortItemClickListener != null) && (this.val$curIndex != i))
              this.val$sortItemClickListener.onSortItemClick(((ScreenModel)((ArrayList)this.val$screenList.get(4)).get(this.val$curIndex)).name);
            CourseSiftingUIView.this.sort_linear.setTag(Integer.valueOf(this.val$curIndex));
          }
        });
        j++;
        break label218;
        i = 0;
        break;
        m = 4;
        break label295;
      }
    }
  }

  public void initSiftingTypeUI(int paramInt)
  {
    if (paramInt == 0);
    for (Object localObject = this.sort_scrollview.getTag(); localObject == null; localObject = this.all_sifting_layout.getTag())
    {
      new Handler().postDelayed(new Runnable(paramInt)
      {
        public void run()
        {
          Animation localAnimation = AnimationUtils.loadAnimation(CourseSiftingUIView.this.context, R.anim.roll_down);
          if (this.val$initType == 0)
          {
            if (CourseSiftingUIView.this.all_sifting_layout.getTag() != null)
            {
              CourseSiftingUIView.this.all_sifting_layout.setVisibility(4);
              CourseSiftingUIView.this.all_sifting_layout.setTag(null);
            }
            CourseSiftingUIView.this.sort_scrollview.setTag("show.status");
            CourseSiftingUIView.this.sort_scrollview.setVisibility(0);
            CourseSiftingUIView.this.sort_scrollview.setAnimation(localAnimation);
          }
          while (true)
          {
            CourseSiftingUIView.this.setVisibility(0);
            CourseSiftingUIView.this.drop_view_bg.setVisibility(0);
            return;
            if (CourseSiftingUIView.this.sort_scrollview.getTag() != null)
            {
              CourseSiftingUIView.this.sort_scrollview.setVisibility(4);
              CourseSiftingUIView.this.sort_scrollview.setTag(null);
            }
            CourseSiftingUIView.this.all_sifting_layout.setTag("show.status");
            CourseSiftingUIView.this.all_sifting_layout.setVisibility(0);
            CourseSiftingUIView.this.all_sifting_layout.setAnimation(localAnimation);
          }
        }
      }
      , 100L);
      return;
    }
    closeDropSiftingView(paramInt);
  }

  public void initUIElement(Context paramContext, View.OnClickListener paramOnClickListener)
  {
    this.context = paramContext;
    this.searchMap = new HashMap();
    this.drop_view_bg = findViewById(R.id.drop_view_bg);
    this.drop_view_bg.setOnClickListener(paramOnClickListener);
    ((TextView)findViewById(R.id.reset_text)).setOnClickListener(paramOnClickListener);
    ((TextView)findViewById(R.id.confirm_text)).setOnClickListener(paramOnClickListener);
    this.diff_gridview = ((SiftingGridView)findViewById(R.id.diff_gridview));
    this.part_gridview = ((SiftingGridView)findViewById(R.id.part_gridview));
    this.apparatus_gridview = ((SiftingGridView)findViewById(R.id.apparatus_gridview));
    this.sifting_scrollview = ((ScrollView)findViewById(R.id.sifting_scrollview));
    this.all_sifting_layout = ((RelativeLayout)findViewById(R.id.all_sifting_layout));
    this.sort_scrollview = ((ScrollView)findViewById(R.id.sort_scrollview));
    this.sort_linear = ((LinearLayout)findViewById(R.id.sort_linear));
  }

  public boolean isAnyOneSelect()
  {
    if (this.sort_scrollview.getTag() != null)
      return (this.searchMap != null) && (this.searchMap.size() != 0) && (!StringUtils.isNull((String)this.searchMap.get("4")));
    return isSelectByFilter();
  }

  public boolean isSelectByFilter()
  {
    return (this.searchMap != null) && (this.searchMap.size() != 0) && ((!StringUtils.isNull((String)this.searchMap.get("0"))) || (!StringUtils.isNull((String)this.searchMap.get("1"))) || (!StringUtils.isNull((String)this.searchMap.get("2"))));
  }

  public boolean isSiftingChangeFlg()
  {
    return this.siftingChangeFlg;
  }

  public void resetAction()
  {
    this.diffAdapter.notifyDataSetChanged();
    this.apparatusAdapter.notifyDataSetChanged();
    this.partAdapter.notifyDataSetChanged();
    this.searchMap.put("0", "");
    this.searchMap.put("1", "");
    this.searchMap.put("2", "");
  }

  public void setSiftingChangeFlg()
  {
    this.siftingChangeFlg = true;
  }

  public static abstract interface OnSortItemClickListener
  {
    public abstract void onSortItemClick(String paramString);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.allcourse.CourseSiftingUIView
 * JD-Core Version:    0.6.0
 */