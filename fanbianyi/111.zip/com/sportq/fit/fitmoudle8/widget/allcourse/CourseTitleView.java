package com.sportq.fit.fitmoudle8.widget.allcourse;

import android.app.Activity;
import android.content.Context;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.adapter.Find02AllCourseAdapter.OnSaveSearchWordsListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CourseTitleView extends RelativeLayout
{
  private Context context;
  private EditText edit_text;
  private Find02AllCourseAdapter.OnSaveSearchWordsListener saveListener;
  private OnSearchListener searchListener;
  private ImageView search_close_btn;
  private RelativeLayout search_layout;
  private RelativeLayout searching_layout;
  private String strLastSearchHint;
  private TextView title;

  public CourseTitleView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  private int[] checkSearchInputLength(String paramString, int paramInt)
  {
    if (StringUtils.isNull(paramString))
      return new int[] { 0, 0 };
    int[] arrayOfInt = new int[2];
    int i = paramString.length();
    int j = 0;
    int k = 0;
    for (int m = 0; m < i; m++)
    {
      j += checkStringType(paramString.substring(m, m + 1));
      if (j != paramInt)
        continue;
      k = m + 1;
    }
    arrayOfInt[0] = j;
    if ((j > paramInt) && (k == 0))
      k = -1 + paramString.length();
    arrayOfInt[1] = k;
    return arrayOfInt;
  }

  private int checkStringType(String paramString)
  {
    if (Pattern.compile("[一-龥]").matcher(paramString).matches())
      return 2;
    return 1;
  }

  public EditText getEdit_text()
  {
    return this.edit_text;
  }

  public RelativeLayout getSearching_layout()
  {
    return this.searching_layout;
  }

  public void hideSearchUI()
  {
    this.searching_layout.setVisibility(8);
    this.search_layout.setVisibility(0);
    this.title.setVisibility(0);
    this.edit_text.setText("");
    CompDeviceInfoUtils.hideSoftInput(this.context, this.edit_text);
  }

  public CourseTitleView initElements(Context paramContext, View.OnClickListener paramOnClickListener, Find02AllCourseAdapter.OnSaveSearchWordsListener paramOnSaveSearchWordsListener)
  {
    this.context = paramContext;
    this.saveListener = paramOnSaveSearchWordsListener;
    this.title = ((TextView)findViewById(R.id.title));
    this.edit_text = ((EditText)findViewById(R.id.edit_text));
    ((RelativeLayout)findViewById(R.id.back_layout)).setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        ((Activity)CourseTitleView.this.context).finish();
        AnimationUtil.pageJumpAnim((Activity)CourseTitleView.this.context, 1);
      }
    });
    this.search_layout = ((RelativeLayout)findViewById(R.id.search_layout));
    this.search_layout.setOnClickListener(paramOnClickListener);
    this.searching_layout = ((RelativeLayout)findViewById(R.id.searching_layout));
    this.search_close_btn = ((ImageView)findViewById(R.id.search_close_btn));
    this.search_close_btn.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        CourseTitleView.this.edit_text.setText("");
      }
    });
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        int[] arrayOfInt = CourseTitleView.this.checkSearchInputLength(paramString, 64);
        if (arrayOfInt[0] > 64)
        {
          CourseTitleView.this.edit_text.setText(paramString.substring(0, arrayOfInt[1]));
          CourseTitleView.this.edit_text.setSelection(CourseTitleView.this.edit_text.getText().length());
        }
        if ((paramString != null) && (!paramString.equals(CourseTitleView.this.strLastSearchHint)))
        {
          CourseTitleView.access$302(CourseTitleView.this, paramString);
          if (CourseTitleView.this.searchListener != null)
            CourseTitleView.this.searchListener.onSearch(paramString);
          ImageView localImageView = CourseTitleView.this.search_close_btn;
          boolean bool = StringUtils.isNull(paramString);
          int i = 0;
          if (bool)
            i = 8;
          localImageView.setVisibility(i);
        }
      }
    }
    , this.edit_text);
    this.edit_text.setOnKeyListener(new View.OnKeyListener()
    {
      public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
      {
        if (paramInt == 66)
        {
          CompDeviceInfoUtils.hideSoftInput(CourseTitleView.this.context, CourseTitleView.this.edit_text);
          if (CourseTitleView.this.saveListener != null)
            CourseTitleView.this.saveListener.onSaveSearchWords();
        }
        return false;
      }
    });
    return this;
  }

  public void setSearchListener(OnSearchListener paramOnSearchListener)
  {
    this.searchListener = paramOnSearchListener;
  }

  public void setTitle(String paramString)
  {
    this.title.setText(paramString);
  }

  public void showSearchUI(String paramString)
  {
    this.searching_layout.setVisibility(0);
    this.search_layout.setVisibility(8);
    this.title.setVisibility(8);
    this.edit_text.requestFocus();
    this.edit_text.setFocusableInTouchMode(true);
    this.edit_text.setHint(paramString);
    CompDeviceInfoUtils.openKeyboard(this.context, this.edit_text);
  }

  public static abstract interface OnSearchListener
  {
    public abstract void onSearch(String paramString);

    public abstract void onSetText(String paramString);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.allcourse.CourseTitleView
 * JD-Core Version:    0.6.0
 */