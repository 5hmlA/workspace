package com.sportq.fit.fitmoudle8.widget.allcourse;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import java.util.ArrayList;
import java.util.List;

public class FlowLayout extends ViewGroup
{
  private List<List<View>> mAllViews = new ArrayList();
  private List<Integer> mLineHeight = new ArrayList();

  public FlowLayout(Context paramContext)
  {
    this(paramContext, null);
  }

  public FlowLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public FlowLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.mAllViews.clear();
    this.mLineHeight.clear();
    int i = getWidth();
    int j = 0;
    int k = 0;
    ArrayList localArrayList = new ArrayList();
    int m = getChildCount();
    for (int n = 0; n < m; n++)
    {
      View localView2 = getChildAt(n);
      ViewGroup.MarginLayoutParams localMarginLayoutParams2 = (ViewGroup.MarginLayoutParams)localView2.getLayoutParams();
      int i9 = localView2.getMeasuredWidth();
      int i10 = localView2.getMeasuredHeight();
      if (i9 + j + localMarginLayoutParams2.leftMargin + localMarginLayoutParams2.rightMargin > i - getPaddingLeft() - getPaddingRight())
      {
        this.mLineHeight.add(Integer.valueOf(k));
        this.mAllViews.add(localArrayList);
        j = 0;
        k = i10 + localMarginLayoutParams2.topMargin + localMarginLayoutParams2.bottomMargin;
        localArrayList = new ArrayList();
      }
      j += i9 + localMarginLayoutParams2.leftMargin + localMarginLayoutParams2.rightMargin;
      k = Math.max(k, i10 + localMarginLayoutParams2.topMargin + localMarginLayoutParams2.bottomMargin);
      localArrayList.add(localView2);
    }
    this.mLineHeight.add(Integer.valueOf(k));
    this.mAllViews.add(localArrayList);
    int i1 = getPaddingLeft();
    int i2 = getPaddingTop();
    int i3 = this.mAllViews.size();
    for (int i4 = 0; i4 < i3; i4++)
    {
      List localList = (List)this.mAllViews.get(i4);
      int i5 = ((Integer)this.mLineHeight.get(i4)).intValue();
      int i6 = 0;
      if (i6 < localList.size())
      {
        View localView1 = (View)localList.get(i6);
        if (localView1.getVisibility() == 8);
        while (true)
        {
          i6++;
          break;
          ViewGroup.MarginLayoutParams localMarginLayoutParams1 = (ViewGroup.MarginLayoutParams)localView1.getLayoutParams();
          int i7 = i1 + localMarginLayoutParams1.leftMargin;
          int i8 = i2 + localMarginLayoutParams1.topMargin;
          localView1.layout(i7, i8, i7 + localView1.getMeasuredWidth(), i8 + localView1.getMeasuredHeight());
          i1 += localView1.getMeasuredWidth() + localMarginLayoutParams1.leftMargin + localMarginLayoutParams1.rightMargin;
        }
      }
      i1 = getPaddingLeft();
      i2 += i5;
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.getMode(paramInt1);
    int k = View.MeasureSpec.getSize(paramInt2);
    int m = View.MeasureSpec.getMode(paramInt2);
    int n = 0;
    int i1 = 0;
    int i2 = 0;
    int i3 = 0;
    int i4 = getChildCount();
    int i5 = 0;
    if (i5 < i4)
    {
      View localView = getChildAt(i5);
      measureChild(localView, paramInt1, paramInt2);
      ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)localView.getLayoutParams();
      int i6 = localView.getMeasuredWidth() + localMarginLayoutParams.leftMargin + localMarginLayoutParams.rightMargin;
      int i7 = localView.getMeasuredHeight() + localMarginLayoutParams.topMargin + localMarginLayoutParams.bottomMargin;
      if (i2 + i6 > i - getPaddingLeft() - getPaddingRight())
      {
        n = Math.max(n, i2);
        i2 = i6;
        i1 += i3;
      }
      for (i3 = i7; ; i3 = Math.max(i3, i7))
      {
        if (i5 == i4 - 1)
        {
          n = Math.max(i2, n);
          i1 += i3;
        }
        i5++;
        break;
        i2 += i6;
      }
    }
    if (j == 1073741824)
      if (m != 1073741824)
        break label246;
    while (true)
    {
      setMeasuredDimension(i, k);
      return;
      i = n + getPaddingLeft() + getPaddingRight();
      break;
      label246: k = i1 + getPaddingTop() + getPaddingBottom();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.allcourse.FlowLayout
 * JD-Core Version:    0.6.0
 */