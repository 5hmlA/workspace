package com.sportq.fit.fitmoudle8.widget;

import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;

class CommentFooterView$3
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    FitJumpImpl.getInstance().jumpCommentList(this.this$0.getContext(), CommentFooterView.access$000(this.this$0).planId, "2", "", StringUtils.string2Int(CommentFooterView.access$000(this.this$0).commentNumber), true);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.CommentFooterView.3
 * JD-Core Version:    0.6.0
 */