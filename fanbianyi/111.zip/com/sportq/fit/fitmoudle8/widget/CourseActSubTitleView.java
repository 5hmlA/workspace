package com.sportq.fit.fitmoudle8.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.TranslateAnimation;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.model.CourseActItemModel;
import com.sportq.fit.common.model.CourseActModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.drawable;
import com.sportq.fit.fitmoudle8.R.id;
import java.util.ArrayList;
import java.util.Iterator;

public class CourseActSubTitleView extends RelativeLayout
{
  private Context context;
  private TextView defSelSiftingView;
  private HorizontalScrollView hor_scrollview;
  private View scroll_sifting_bg;
  private OnDefSiftingItemClickListener siftingItemClickListener;
  private LinearLayout sifting_type_layout;

  public CourseActSubTitleView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public void initSiftingHint(CourseActModel paramCourseActModel, int paramInt)
  {
    if (this.sifting_type_layout.getChildCount() != 0);
    do
      return;
    while ((paramCourseActModel.lstplateDet == null) || (paramCourseActModel.lstplateDet.size() == 0));
    int i = CompDeviceInfoUtils.convertOfDip(this.context, 35.0F);
    this.sifting_type_layout.removeAllViews();
    Iterator localIterator = paramCourseActModel.lstplateDet.iterator();
    label54: CourseActItemModel localCourseActItemModel;
    LinearLayout.LayoutParams localLayoutParams;
    if (localIterator.hasNext())
    {
      localCourseActItemModel = (CourseActItemModel)localIterator.next();
      localLayoutParams = new LinearLayout.LayoutParams(-2, i);
      if (paramCourseActModel.lstplateDet.indexOf(localCourseActItemModel) != 0)
        break label333;
      localLayoutParams.leftMargin = CompDeviceInfoUtils.convertOfDip(this.context, 16.0F);
    }
    while (true)
    {
      localLayoutParams.bottomMargin = CompDeviceInfoUtils.convertOfDip(this.context, 5.0F);
      localLayoutParams.topMargin = CompDeviceInfoUtils.convertOfDip(this.context, 5.0F);
      TextView localTextView = new TextView(this.context);
      localTextView.setLayoutParams(localLayoutParams);
      int j = CompDeviceInfoUtils.convertOfDip(this.context, 18.0F);
      localTextView.setPadding(j, 0, j, 0);
      localTextView.setGravity(17);
      localTextView.setText(localCourseActItemModel.selectedTitle);
      localTextView.setTextSize(16.0F);
      localTextView.setTextColor(ContextCompat.getColor(this.context, R.color.color_313131));
      if (paramCourseActModel.lstplateDet.indexOf(localCourseActItemModel) == paramInt)
      {
        this.defSelSiftingView = localTextView;
        localTextView.setTextSize(16.0F);
        localTextView.setTypeface(Typeface.defaultFromStyle(0));
        localTextView.setBackgroundResource(R.drawable.sifting_select_bg);
        new Handler().postDelayed(new Runnable(paramInt)
        {
          public void run()
          {
            int i = CompDeviceInfoUtils.convertOfDip(CourseActSubTitleView.this.context, 90.0F);
            CourseActSubTitleView.this.hor_scrollview.smoothScrollTo(i * this.val$clickIndex, 0);
          }
        }
        , 700L);
      }
      localTextView.setOnClickListener(new DefaultSiftingItemClickListener(paramCourseActModel.lstplateDet.indexOf(localCourseActItemModel), localCourseActItemModel.selectedTitle, localCourseActItemModel.selectedId));
      this.sifting_type_layout.addView(localTextView);
      break label54;
      break;
      label333: if (paramCourseActModel.lstplateDet.indexOf(localCourseActItemModel) == -1 + paramCourseActModel.lstplateDet.size())
      {
        localLayoutParams.leftMargin = CompDeviceInfoUtils.convertOfDip(this.context, 10.0F);
        localLayoutParams.rightMargin = CompDeviceInfoUtils.convertOfDip(this.context, 16.0F);
        continue;
      }
      localLayoutParams.leftMargin = CompDeviceInfoUtils.convertOfDip(this.context, 10.0F);
    }
  }

  public CourseActSubTitleView initUIElements(Context paramContext, OnDefSiftingItemClickListener paramOnDefSiftingItemClickListener)
  {
    this.context = paramContext;
    this.siftingItemClickListener = paramOnDefSiftingItemClickListener;
    this.scroll_sifting_bg = findViewById(R.id.scroll_sifting_bg);
    this.hor_scrollview = ((HorizontalScrollView)findViewById(R.id.hor_scrollview));
    this.sifting_type_layout = ((LinearLayout)findViewById(R.id.sifting_type_layout));
    return this;
  }

  private class DefaultSiftingItemClickListener
    implements View.OnClickListener
  {
    private String code;
    private int curIndex;
    private String name;

    DefaultSiftingItemClickListener(int paramString1, String paramString2, String arg4)
    {
      this.curIndex = paramString1;
      this.name = paramString2;
      Object localObject;
      this.code = localObject;
    }

    @Instrumented
    public void onClick(View paramView)
    {
      VdsAgent.onClick(this, paramView);
      while (true)
      {
        try
        {
          if (CourseActSubTitleView.this.defSelSiftingView == null)
            break;
          if ((CourseActSubTitleView.this.scroll_sifting_bg.getTag() != null) && (this.curIndex == Integer.valueOf(String.valueOf(CourseActSubTitleView.this.scroll_sifting_bg.getTag())).intValue()))
            return;
          CourseActSubTitleView.this.scroll_sifting_bg.setTag(Integer.valueOf(this.curIndex));
          CourseActSubTitleView.this.defSelSiftingView.setTextSize(16.0F);
          CourseActSubTitleView.this.defSelSiftingView.setTypeface(Typeface.defaultFromStyle(0));
          CourseActSubTitleView.this.defSelSiftingView.setBackgroundColor(ContextCompat.getColor(CourseActSubTitleView.this.context, 17170445));
          CourseActSubTitleView.this.scroll_sifting_bg.setLayoutParams(new RelativeLayout.LayoutParams(paramView.getWidth(), paramView.getHeight()));
          ((RelativeLayout.LayoutParams)CourseActSubTitleView.this.scroll_sifting_bg.getLayoutParams()).topMargin = ((LinearLayout.LayoutParams)paramView.getLayoutParams()).topMargin;
          ((RelativeLayout.LayoutParams)CourseActSubTitleView.this.scroll_sifting_bg.getLayoutParams()).leftMargin = 0;
          ((RelativeLayout.LayoutParams)CourseActSubTitleView.this.scroll_sifting_bg.getLayoutParams()).bottomMargin = ((LinearLayout.LayoutParams)paramView.getLayoutParams()).bottomMargin;
          TranslateAnimation localTranslateAnimation = new TranslateAnimation(CourseActSubTitleView.this.defSelSiftingView.getX(), paramView.getX(), 0.0F, 0.0F);
          localTranslateAnimation.setDuration(180L);
          localTranslateAnimation.setFillAfter(true);
          CourseActSubTitleView.this.scroll_sifting_bg.startAnimation(localTranslateAnimation);
          ((TextView)paramView).setTextSize(16.0F);
          ((TextView)paramView).setTypeface(Typeface.defaultFromStyle(0));
          CourseActSubTitleView.access$202(CourseActSubTitleView.this, (TextView)paramView);
          if (this.curIndex > 0)
          {
            int i = CompDeviceInfoUtils.convertOfDip(CourseActSubTitleView.this.context, 90.0F);
            CourseActSubTitleView.this.hor_scrollview.smoothScrollTo(i * this.curIndex, 0);
            new Handler().postDelayed(new Runnable()
            {
              public void run()
              {
                if (CourseActSubTitleView.this.siftingItemClickListener != null)
                  CourseActSubTitleView.this.siftingItemClickListener.onDefSiftingItemClick(CourseActSubTitleView.DefaultSiftingItemClickListener.this.name, CourseActSubTitleView.DefaultSiftingItemClickListener.this.code);
              }
            }
            , 400L);
            return;
          }
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
          return;
        }
        CourseActSubTitleView.this.hor_scrollview.smoothScrollTo(0, 0);
      }
    }
  }

  public static abstract interface OnDefSiftingItemClickListener
  {
    public abstract void onDefSiftingItemClick(String paramString1, String paramString2);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.CourseActSubTitleView
 * JD-Core Version:    0.6.0
 */