package com.sportq.fit.fitmoudle8.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatButton;
import android.text.TextPaint;
import android.util.AttributeSet;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;

public class DrawCenterButton extends AppCompatButton
{
  public DrawCenterButton(Context paramContext)
  {
    super(paramContext);
  }

  public DrawCenterButton(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public DrawCenterButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  protected void onDraw(Canvas paramCanvas)
  {
    Drawable localDrawable = getCompoundDrawables()[0];
    if (localDrawable != null)
    {
      localDrawable.setBounds(0, 0, CompDeviceInfoUtils.convertOfDip(getContext(), 15.0F), CompDeviceInfoUtils.convertOfDip(getContext(), 15.0F));
      setCompoundDrawables(localDrawable, null, null, null);
      float f1 = getPaint().measureText(getText().toString());
      int i = getCompoundDrawablePadding();
      float f2 = f1 + localDrawable.getIntrinsicWidth() + i;
      paramCanvas.translate((getWidth() - f2) / 2.0F, 0.0F);
    }
    super.onDraw(paramCanvas);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.DrawCenterButton
 * JD-Core Version:    0.6.0
 */