package com.sportq.fit.fitmoudle8.widget.action;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import com.sportq.fit.common.reformer.SystemTimeReformer;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseNavView;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.layout;
import com.sportq.fit.fitmoudle8.activity.action_library.ActionDetailsActivity;
import com.sportq.fit.fitmoudle8.activity.action_library.ActionUnLockActivity;
import com.sportq.fit.fitmoudle8.adapter.ActionScreenAdapter;
import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools;
import java.util.ArrayList;
import org.byteam.superadapter.OnItemClickListener;

public class ActionRelatedView extends BaseNavView
{
  private ActionScreenAdapter adapter;
  private RecyclerView recyclerView;
  private Find04TrainInfoTools trainInfoTools;

  public ActionRelatedView(Context paramContext)
  {
    super(paramContext);
    addView(onCreateView());
  }

  private View onCreateView()
  {
    this.recyclerView = new RecyclerView(getContext());
    this.recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
    this.trainInfoTools = new Find04TrainInfoTools();
    return this.recyclerView;
  }

  public ActionScreenAdapter getAdapter()
  {
    return this.adapter;
  }

  public void initData(ArrayList<ResponseModel.ActionData> paramArrayList, String paramString1, SystemTimeReformer paramSystemTimeReformer, String paramString2)
  {
    this.adapter = new ActionScreenAdapter(getContext(), paramArrayList, R.layout.action_item_view, paramSystemTimeReformer);
    this.adapter.setStrCurrentId(paramString2);
    View localView = View.inflate(getContext(), R.layout.stage_item, null);
    ((TextView)localView.findViewById(R.id.stage_name)).setText(paramString1);
    this.adapter.addHeaderView(localView);
    this.adapter.setOnItemClickListener(new OnItemClickListener(paramSystemTimeReformer, paramArrayList)
    {
      public void onItemClick(View paramView, int paramInt1, int paramInt2)
      {
        if ((ActionRelatedView.this.trainInfoTools.checkIsUnLock(this.val$systemTimeReformer.timeKey, (ResponseModel.ActionData)this.val$lstActDetInfo.get(paramInt2 - 1))) || ("1".equals(BaseApplication.userModel.isVip)))
        {
          Intent localIntent1 = new Intent(ActionRelatedView.this.getContext(), ActionDetailsActivity.class);
          localIntent1.putExtra("original.data", this.val$lstActDetInfo);
          localIntent1.putExtra("intent.current.actionModel", paramInt2 - 1);
          localIntent1.putExtra("system.time", this.val$systemTimeReformer.timeKey);
          ActionRelatedView.this.getContext().startActivity(localIntent1);
          AnimationUtil.pageJumpAnim((Activity)ActionRelatedView.this.getContext(), 0);
          return;
        }
        Intent localIntent2 = new Intent(ActionRelatedView.this.getContext(), ActionUnLockActivity.class);
        ActionRelatedView.this.getContext().startActivity(localIntent2);
        AnimationUtil.pageJumpAnim((Activity)ActionRelatedView.this.getContext(), 0);
      }
    });
    this.recyclerView.setAdapter(this.adapter);
  }

  public void refreshData(ArrayList<ResponseModel.ActionData> paramArrayList)
  {
    if (this.adapter != null)
      this.adapter.replaceAll(paramArrayList);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.action.ActionRelatedView
 * JD-Core Version:    0.6.0
 */