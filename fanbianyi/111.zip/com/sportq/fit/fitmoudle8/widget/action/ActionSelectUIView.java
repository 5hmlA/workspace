package com.sportq.fit.fitmoudle8.widget.action;

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.ScrollView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.ScreenModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.R.anim;
import com.sportq.fit.fitmoudle8.R.drawable;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.adapter.SiftingGridViewAdapter;
import com.sportq.fit.fitmoudle8.widget.allcourse.SiftingGridView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class ActionSelectUIView extends RelativeLayout
{
  private SiftingGridViewAdapter apparatusAdapter;
  private SiftingGridView apparatus_gridview;
  private Context context;
  private SiftingGridViewAdapter diffAdapter;
  private SiftingGridView diff_gridview;
  private View drop_view_bg;
  private HashMap<String, String> olaInfoMap;
  private HashMap<String, String> searchMap;
  private boolean siftingChangeFlg = false;
  private ScrollView sifting_scrollview;

  public ActionSelectUIView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  private void checkScrollViewMaxHeight(ArrayList<ArrayList<ScreenModel>> paramArrayList)
  {
    int i;
    int j;
    if (((ArrayList)paramArrayList.get(0)).size() % 4 == 0)
    {
      i = ((ArrayList)paramArrayList.get(0)).size() / 4;
      j = (int)(i * (0.09259249999999999D * BaseApplication.screenWidth) + (i + 3) * CompDeviceInfoUtils.convertOfDip(this.context, 8.0F));
      if (((ArrayList)paramArrayList.get(2)).size() % 2 != 0)
        break label183;
    }
    label183: for (int k = ((ArrayList)paramArrayList.get(2)).size() / 2; ; k = 1 + ((ArrayList)paramArrayList.get(2)).size() / 2)
    {
      if (j + (int)(k * (0.166666D * BaseApplication.screenWidth) + (k + 3) * CompDeviceInfoUtils.convertOfDip(this.context, 8.0F)) > 0.63D * BaseApplication.screenHeight)
      {
        RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(BaseApplication.screenWidth, (int)(0.63D * BaseApplication.screenHeight));
        this.sifting_scrollview.setLayoutParams(localLayoutParams);
      }
      return;
      i = 1 + ((ArrayList)paramArrayList.get(0)).size() / 4;
      break;
    }
  }

  private String convertString(String paramString, View paramView)
  {
    String[] arrayOfString = paramString.split(",");
    StringBuilder localStringBuilder = new StringBuilder();
    int i = arrayOfString.length;
    for (int j = 0; j < i; j++)
    {
      String str = arrayOfString[j];
      if (str.equals(paramView.getTag()))
        continue;
      localStringBuilder.append(str);
      localStringBuilder.append(",");
    }
    return localStringBuilder.toString();
  }

  private void siftingOnItemClickAction(SiftingGridView paramSiftingGridView, int paramInt, ArrayList<ScreenModel> paramArrayList)
  {
    paramSiftingGridView.setOnItemClickListener(new AdapterView.OnItemClickListener(paramInt, paramArrayList)
    {
      @Instrumented
      public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
      {
        VdsAgent.onItemClick(this, paramAdapterView, paramView, paramInt, paramLong);
        TextView localTextView = (TextView)paramView.findViewById(R.id.sifting_itemview02);
        if (StringUtils.isNull(String.valueOf(localTextView.getTag())))
        {
          paramView.setBackgroundResource(R.drawable.sifting_select_bg);
          if (this.val$type == 0)
            if (!StringUtils.isNull((String)ActionSelectUIView.this.searchMap.get("2")))
            {
              ActionSelectUIView.this.searchMap.put("2", (String)ActionSelectUIView.this.searchMap.get("2") + ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
              ActionSelectUIView.this.olaInfoMap.put("2", (String)ActionSelectUIView.this.olaInfoMap.get("2") + ((ScreenModel)this.val$screenList.get(paramInt)).olapInfo + ",");
            }
          while (true)
          {
            localTextView.setTag(((ScreenModel)this.val$screenList.get(paramInt)).code);
            ActionSelectUIView.access$502(ActionSelectUIView.this, true);
            return;
            ActionSelectUIView.this.searchMap.put("2", ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
            ActionSelectUIView.this.olaInfoMap.put("2", ((ScreenModel)this.val$screenList.get(paramInt)).olapInfo + ",");
            continue;
            if (this.val$type != 1)
              continue;
            if (!StringUtils.isNull((String)ActionSelectUIView.this.searchMap.get("1")))
            {
              ActionSelectUIView.this.searchMap.put("1", (String)ActionSelectUIView.this.searchMap.get("1") + ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
              ActionSelectUIView.this.olaInfoMap.put("1", (String)ActionSelectUIView.this.olaInfoMap.get("1") + ((ScreenModel)this.val$screenList.get(paramInt)).olapInfo + ",");
              continue;
            }
            ActionSelectUIView.this.searchMap.put("1", ((ScreenModel)this.val$screenList.get(paramInt)).code + ",");
            ActionSelectUIView.this.olaInfoMap.put("1", ((ScreenModel)this.val$screenList.get(paramInt)).olapInfo + ",");
          }
        }
        paramView.setBackgroundResource(R.drawable.sifting_item_bg);
        if (this.val$type == 0)
        {
          ActionSelectUIView.this.searchMap.put("2", ActionSelectUIView.this.convertString((String)ActionSelectUIView.this.searchMap.get("2"), localTextView));
          ActionSelectUIView.this.olaInfoMap.put("2", ((String)ActionSelectUIView.this.olaInfoMap.get("2")).replace(((ScreenModel)this.val$screenList.get(paramInt)).olapInfo + ",", ""));
        }
        while (true)
        {
          localTextView.setTag(null);
          break;
          if (this.val$type != 1)
            continue;
          ActionSelectUIView.this.searchMap.put("1", ActionSelectUIView.this.convertString((String)ActionSelectUIView.this.searchMap.get("1"), localTextView));
          ActionSelectUIView.this.olaInfoMap.put("1", ((String)ActionSelectUIView.this.olaInfoMap.get("1")).replace(((ScreenModel)this.val$screenList.get(paramInt)).olapInfo + ",", ""));
        }
      }
    });
  }

  public boolean checkSiftingIconStatus()
  {
    int i = 1;
    if ((this.searchMap == null) || (this.searchMap.size() == 0))
      i = 0;
    int j;
    do
    {
      return i;
      Iterator localIterator = this.searchMap.entrySet().iterator();
      j = 0;
      while (localIterator.hasNext())
      {
        if (StringUtils.isNull(String.valueOf(((Map.Entry)localIterator.next()).getValue())))
          continue;
        j++;
      }
    }
    while (j != i);
    return false;
  }

  public void closeDropSiftingView()
  {
    if (getTag() != null)
    {
      setTag(null);
      this.siftingChangeFlg = false;
      Animation localAnimation = AnimationUtils.loadAnimation(this.context, R.anim.roll_up);
      findViewById(R.id.all_sifting_layout).startAnimation(localAnimation);
      this.drop_view_bg.setVisibility(4);
      localAnimation.setAnimationListener(new Animation.AnimationListener()
      {
        public void onAnimationEnd(Animation paramAnimation)
        {
          ActionSelectUIView.this.setVisibility(4);
        }

        public void onAnimationRepeat(Animation paramAnimation)
        {
        }

        public void onAnimationStart(Animation paramAnimation)
        {
        }
      });
    }
  }

  public HashMap<String, String> getOlaInfoMap()
  {
    return this.olaInfoMap;
  }

  public HashMap<String, String> getSearchMap()
  {
    return this.searchMap;
  }

  public void initSiftingTypeUI(ArrayList<ArrayList<ScreenModel>> paramArrayList)
  {
    if (getTag() == null)
    {
      setTag("show.status");
      if (this.diff_gridview.getChildCount() == 0)
      {
        checkScrollViewMaxHeight(paramArrayList);
        this.diffAdapter = new SiftingGridViewAdapter(this.context, 1, (ArrayList)paramArrayList.get(1));
        siftingOnItemClickAction(this.diff_gridview, 0, (ArrayList)paramArrayList.get(1));
        this.diff_gridview.setAdapter(this.diffAdapter);
        this.apparatusAdapter = new SiftingGridViewAdapter(this.context, 2, (ArrayList)paramArrayList.get(0));
        siftingOnItemClickAction(this.apparatus_gridview, 1, (ArrayList)paramArrayList.get(0));
        this.apparatus_gridview.setAdapter(this.apparatusAdapter);
        new Handler().postDelayed(new Runnable()
        {
          public void run()
          {
            Animation localAnimation = AnimationUtils.loadAnimation(ActionSelectUIView.this.context, R.anim.roll_down);
            ActionSelectUIView.this.findViewById(R.id.all_sifting_layout).setAnimation(localAnimation);
            ActionSelectUIView.this.setVisibility(0);
            ActionSelectUIView.this.drop_view_bg.setVisibility(0);
          }
        }
        , 200L);
        return;
      }
      Animation localAnimation = AnimationUtils.loadAnimation(this.context, R.anim.roll_down);
      findViewById(R.id.all_sifting_layout).setAnimation(localAnimation);
      setVisibility(0);
      this.drop_view_bg.setVisibility(0);
      return;
    }
    closeDropSiftingView();
  }

  public ActionSelectUIView initUIElement(Context paramContext, View.OnClickListener paramOnClickListener)
  {
    this.context = paramContext;
    this.searchMap = new HashMap();
    this.olaInfoMap = new HashMap();
    this.drop_view_bg = findViewById(R.id.drop_view_bg);
    this.drop_view_bg.setOnClickListener(paramOnClickListener);
    ((TextView)findViewById(R.id.reset_text)).setOnClickListener(paramOnClickListener);
    ((TextView)findViewById(R.id.confirm_text)).setOnClickListener(paramOnClickListener);
    this.diff_gridview = ((SiftingGridView)findViewById(R.id.diff_gridview));
    this.apparatus_gridview = ((SiftingGridView)findViewById(R.id.apparatus_gridview));
    this.sifting_scrollview = ((ScrollView)findViewById(R.id.sifting_scrollview));
    return this;
  }

  public boolean isSiftingChangeFlg()
  {
    return this.siftingChangeFlg;
  }

  public void resetAction()
  {
    this.diffAdapter.notifyDataSetChanged();
    this.apparatusAdapter.notifyDataSetChanged();
    this.searchMap.put("1", "");
    this.searchMap.put("2", "");
    this.olaInfoMap.put("1", "");
    this.olaInfoMap.put("2", "");
  }

  public void setSiftingChangeFlg(boolean paramBoolean)
  {
    this.siftingChangeFlg = paramBoolean;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.action.ActionSelectUIView
 * JD-Core Version:    0.6.0
 */