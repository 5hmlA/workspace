package com.sportq.fit.fitmoudle8.widget.action;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import com.sportq.fit.fitmoudle8.R.color;

public class ShadowRelativeLayout extends RelativeLayout
{
  private OnDrawChangeListener onDrawChangeListener;
  private View shadowView;

  public ShadowRelativeLayout(Context paramContext)
  {
    this(paramContext, null);
  }

  public ShadowRelativeLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public ShadowRelativeLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramContext);
  }

  @TargetApi(21)
  public ShadowRelativeLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    init(paramContext);
  }

  public void init(Context paramContext)
  {
    if ((paramContext instanceof Activity))
    {
      ViewGroup localViewGroup = (ViewGroup)((Activity)paramContext).getWindow().getDecorView();
      this.shadowView = new View(paramContext);
      this.shadowView.setBackgroundColor(getResources().getColor(R.color.black));
      this.shadowView.setAlpha(0.8F);
      RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(-1, -1);
      this.shadowView.setLayoutParams(localLayoutParams);
      localViewGroup.addView(this.shadowView, 0);
    }
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    if ((this.onDrawChangeListener != null) && (this.shadowView != null))
      this.onDrawChangeListener.onDrawChangeListener(this.shadowView);
  }

  public void setOnDrawChangeListener(OnDrawChangeListener paramOnDrawChangeListener)
  {
    this.onDrawChangeListener = paramOnDrawChangeListener;
  }

  public static abstract interface OnDrawChangeListener
  {
    public abstract void onDrawChangeListener(View paramView);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.action.ShadowRelativeLayout
 * JD-Core Version:    0.6.0
 */