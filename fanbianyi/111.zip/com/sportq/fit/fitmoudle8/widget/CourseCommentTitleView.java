package com.sportq.fit.fitmoudle8.widget;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout.OnTabSelectListener;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.layout;
import java.util.ArrayList;

public class CourseCommentTitleView extends FrameLayout
{
  private CourseTitleItemClickListener courseTitleItemClickListener;
  private CustomTabLayout customTabLayout;
  ViewPager viewPager;

  public CourseCommentTitleView(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public CourseCommentTitleView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public CourseCommentTitleView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), R.layout.course_comment_title_layout, null);
    this.customTabLayout = ((CustomTabLayout)localView.findViewById(R.id.custom_tab_layout));
    this.viewPager = ((ViewPager)localView.findViewById(R.id.view_pager));
    return localView;
  }

  private void setCurrentTextInfo(int paramInt, boolean paramBoolean)
  {
    SpannableString localSpannableString = new SpannableString(this.customTabLayout.getTitleView(paramInt).getText().toString());
    int i = localSpannableString.toString().indexOf(" ");
    if (paramBoolean)
    {
      localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getContext(), R.color.color_313131)), 0, i, 17);
      localSpannableString.setSpan(new AbsoluteSizeSpan(CompDeviceInfoUtils.spTopx(14.0F)), 0, i, 17);
      localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getContext(), R.color.color_ffd208)), i, localSpannableString.length(), 34);
      localSpannableString.setSpan(new AbsoluteSizeSpan(CompDeviceInfoUtils.spTopx(17.0F)), i, localSpannableString.length(), 34);
      localSpannableString.setSpan(new StyleSpan(1), i, localSpannableString.length(), 34);
    }
    while (true)
    {
      this.customTabLayout.getTitleView(paramInt).setText(localSpannableString);
      return;
      localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getContext(), R.color.color_828282)), 0, i, 17);
      localSpannableString.setSpan(new AbsoluteSizeSpan(CompDeviceInfoUtils.spTopx(14.0F)), 0, i, 17);
      localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getContext(), R.color.color_c8c8c8)), i, localSpannableString.length(), 34);
      localSpannableString.setSpan(new AbsoluteSizeSpan(CompDeviceInfoUtils.spTopx(17.0F)), i, localSpannableString.length(), 34);
      localSpannableString.setSpan(new StyleSpan(1), i, localSpannableString.length(), 34);
    }
  }

  public void initData(int paramInt, PlanModel paramPlanModel)
  {
    int i = 1;
    String[] arrayOfString = new String[2];
    Object[] arrayOfObject1 = new Object[i];
    arrayOfObject1[0] = paramPlanModel.actionNum;
    arrayOfString[0] = String.format("动作 %s", arrayOfObject1);
    Object[] arrayOfObject2 = new Object[i];
    arrayOfObject2[0] = paramPlanModel.commentNumber;
    arrayOfString[i] = String.format("课程评论 %s", arrayOfObject2);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(new View(getContext()));
    localArrayList.add(new View(getContext()));
    this.viewPager.setAdapter(new CustomViewPagerAdapter(localArrayList));
    this.customTabLayout.setViewPager(this.viewPager, arrayOfString);
    this.customTabLayout.setOnTabSelectListener(new CustomTabLayout.OnTabSelectListener()
    {
      public void onTabReselect(int paramInt)
      {
        if (CourseCommentTitleView.this.courseTitleItemClickListener != null)
          CourseCommentTitleView.this.courseTitleItemClickListener.itemClick(paramInt);
      }

      public void onTabSelect(int paramInt)
      {
        if (CourseCommentTitleView.this.courseTitleItemClickListener != null)
          CourseCommentTitleView.this.courseTitleItemClickListener.itemClick(paramInt);
      }
    });
    this.customTabLayout.setCurrentTab(paramInt, false);
    setCurrentTextInfo(paramInt, i);
    if (paramInt == 0);
    while (true)
    {
      setCurrentTextInfo(i, false);
      return;
      int j = 0;
    }
  }

  public void setCourseTitleItemClickListener(CourseTitleItemClickListener paramCourseTitleItemClickListener)
  {
    this.courseTitleItemClickListener = paramCourseTitleItemClickListener;
  }

  public void setCurrentPos(int paramInt)
  {
    int i = 1;
    if (this.customTabLayout.getCurrentTab() == paramInt)
      return;
    this.customTabLayout.setCurrentTab(paramInt, false);
    setCurrentTextInfo(paramInt, i);
    if (paramInt == 0);
    while (true)
    {
      setCurrentTextInfo(i, false);
      return;
      int j = 0;
    }
  }

  public static abstract interface CourseTitleItemClickListener
  {
    public abstract void itemClick(int paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.widget.CourseCommentTitleView
 * JD-Core Version:    0.6.0
 */