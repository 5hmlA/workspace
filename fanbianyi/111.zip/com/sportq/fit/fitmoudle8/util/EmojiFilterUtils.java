package com.sportq.fit.fitmoudle8.util;

public class EmojiFilterUtils
{
  private boolean containsEmoji(String paramString)
  {
    int i = paramString.length();
    for (int j = 0; j < i; j++)
      if (isEmojiCharacter(paramString.charAt(j)))
        return true;
    return false;
  }

  private boolean isEmojiCharacter(char paramChar)
  {
    return (paramChar != 0) && (paramChar != '\t') && (paramChar != '\n') && (paramChar != '\r') && ((paramChar < ' ') || (paramChar > 55295)) && ((paramChar < 57344) || (paramChar > 65533)) && ((paramChar < 65536) || (paramChar > 1114111));
  }

  public String filterEmoji(String paramString)
  {
    if (!containsEmoji(paramString))
      return paramString;
    StringBuilder localStringBuilder = new StringBuilder();
    int i = paramString.length();
    int j = 0;
    if (j < i)
    {
      if (isEmojiCharacter(paramString.charAt(j)));
      while (true)
      {
        j++;
        break;
        localStringBuilder.append(String.valueOf(paramString.charAt(j)));
      }
    }
    if (localStringBuilder.length() > 0);
    for (String str = localStringBuilder.toString(); ; str = "")
      return str;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.util.EmojiFilterUtils
 * JD-Core Version:    0.6.0
 */