package com.sportq.fit.fitmoudle8.util;

public class FindConstant
{
  public static final String BG_MUSIC_DOWN_FINISH = "music.down.finish";
  public static final String JOINCOURSE_GUIDE = "joinCourse_guide";
  public static final String MORECOURSE_HEAD_GUIDE = "moreCourse_head_guide";
  public static final String SCREEN_CLICK = "screen.click";
  public static final String SHOWGUIDE202 = "showGuide_2.0.2";
  public static final String SINGLECOURSE_HEAD_GUIDE = "singleCourse_head_guide";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.util.FindConstant
 * JD-Core Version:    0.6.0
 */