package com.sportq.fit.fitmoudle8.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import java.util.ArrayList;
import java.util.Iterator;

public class CourseSharePreUtils
{
  public static void deleteActionSearchHistory(String paramString)
  {
    try
    {
      ArrayList localArrayList = getActionHistoryArray();
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (!str.equals(paramString))
          continue;
        localArrayList.remove(str);
      }
      putActionHistoryArray(localArrayList);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public static ArrayList<String> getActionHistoryArray()
  {
    ArrayList localArrayList = new ArrayList();
    SharedPreferences localSharedPreferences = BaseApplication.appliContext.getSharedPreferences("actionHistoryArray", 0);
    int i = localSharedPreferences.getInt("Status_size", 0);
    int j = 0;
    if (j < i)
    {
      String str = localSharedPreferences.getString("Status_" + j, null);
      if (StringUtils.isNull(str));
      while (true)
      {
        j++;
        break;
        localArrayList.add(str);
      }
    }
    return localArrayList;
  }

  public static String getActionLikeState(Context paramContext)
  {
    if (paramContext == null)
      return "";
    return paramContext.getSharedPreferences("action.like", 0).getString("action.like.state", "");
  }

  public static String getDownloadDialogStatus(Context paramContext)
  {
    if (paramContext == null)
      return "";
    return paramContext.getSharedPreferences("download.name", 0).getString("downloaded.planId", "");
  }

  public static String getEnergyIntroShowState(Context paramContext)
  {
    if (paramContext == null)
      return "";
    return paramContext.getSharedPreferences("energy.intro", 0).getString("energy.intro.state", "");
  }

  public static boolean getGuideIsShowFlg01()
  {
    return BaseApplication.appliContext.getSharedPreferences("detail.guide01", 0).getBoolean(BaseApplication.userModel.userId + "guide.show01", false);
  }

  public static boolean getGuideIsShowFlg02()
  {
    return BaseApplication.appliContext.getSharedPreferences("detail.guide02", 0).getBoolean(BaseApplication.userModel.userId + "guide.show02", false);
  }

  public static String getHistorySearchHint(Context paramContext)
  {
    if (paramContext == null)
      return "";
    return paramContext.getSharedPreferences("history.search.name", 0).getString("history.search.hint", "");
  }

  public static String getUnlockEnergyHintState(Context paramContext)
  {
    if (paramContext == null)
      return "";
    return paramContext.getSharedPreferences("unlock.energy.hint", 0).getString("unlock.energy.hint.state", "");
  }

  public static boolean putActionHistoryArray(ArrayList<String> paramArrayList)
  {
    SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("actionHistoryArray", 0).edit();
    localEditor.putInt("Status_size", paramArrayList.size());
    for (int i = 0; i < paramArrayList.size(); i++)
    {
      localEditor.remove("Status_" + i);
      localEditor.putString("Status_" + i, (String)paramArrayList.get(i));
    }
    return localEditor.commit();
  }

  public static void putActionLikeState(Context paramContext, String paramString)
  {
    if (paramContext == null)
      return;
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("action.like", 0).edit();
    localEditor.putString("action.like.state", paramString);
    localEditor.apply();
  }

  public static void putDownloadDialogStatus(Context paramContext, String paramString)
  {
    if (paramContext == null)
      return;
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("download.name", 0).edit();
    localEditor.putString("downloaded.planId", paramString);
    localEditor.apply();
  }

  public static void putEnergyIntroShowState(Context paramContext, String paramString)
  {
    if (paramContext == null)
      return;
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("energy.intro", 0).edit();
    localEditor.putString("energy.intro.state", paramString);
    localEditor.apply();
  }

  public static void putGuideIsShowFlg01()
  {
    SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("detail.guide01", 0).edit();
    localEditor.putBoolean(BaseApplication.userModel.userId + "guide.show01", true);
    localEditor.apply();
  }

  public static void putGuideIsShowFlg02()
  {
    SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("detail.guide02", 0).edit();
    localEditor.putBoolean(BaseApplication.userModel.userId + "guide.show02", true);
    localEditor.apply();
  }

  public static void putHistorySearchHint(Context paramContext, String paramString, boolean paramBoolean)
  {
    if (paramContext == null)
      return;
    String str2;
    if (StringUtils.isNull(paramString))
      str2 = paramString;
    while (true)
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("history.search.name", 0).edit();
      localEditor.putString("history.search.hint", str2);
      localEditor.apply();
      return;
      String str1 = getHistorySearchHint(paramContext);
      if (StringUtils.isNull(str1))
      {
        str2 = paramString + "±";
        continue;
      }
      String[] arrayOfString = str1.split("±");
      if (arrayOfString.length > 0)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        int i = 0;
        while (i < arrayOfString.length)
        {
          if (paramString.equals(arrayOfString[i]))
          {
            i++;
            continue;
          }
          int j;
          if (!paramBoolean)
            if (str1.contains(paramString))
              j = 4;
          while (true)
          {
            if (i > j)
              break label193;
            localStringBuilder.append(arrayOfString[i]);
            localStringBuilder.append("±");
            break;
            j = 3;
            continue;
            j = 4;
          }
        }
        label193: if (!paramBoolean)
        {
          str2 = paramString + "±" + localStringBuilder.toString();
          continue;
        }
        str2 = localStringBuilder.toString();
        continue;
      }
      str2 = paramString + "±";
    }
  }

  public static void putUnlockEnergyHintState(Context paramContext, String paramString)
  {
    if (paramContext == null)
      return;
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("unlock.energy.hint", 0).edit();
    localEditor.putString("unlock.energy.hint.state", paramString);
    localEditor.apply();
  }

  public static void saveActionSearchHistory(String paramString)
  {
    try
    {
      ArrayList localArrayList = getActionHistoryArray();
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (!str.equals(paramString))
          continue;
        localArrayList.remove(str);
      }
      localArrayList.add(0, paramString);
      putActionHistoryArray(localArrayList);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.util.CourseSharePreUtils
 * JD-Core Version:    0.6.0
 */