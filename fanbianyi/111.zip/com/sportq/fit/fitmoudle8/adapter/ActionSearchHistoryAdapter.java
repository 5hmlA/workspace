package com.sportq.fit.fitmoudle8.adapter;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.util.CourseSharePreUtils;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class ActionSearchHistoryAdapter extends SuperAdapter<String>
{
  private View.OnClickListener delBtnOnClickListener;

  public ActionSearchHistoryAdapter(Context paramContext, List<String> paramList, @LayoutRes int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, String paramString)
  {
    paramSuperViewHolder.setText(R.id.history_name, paramString);
    paramSuperViewHolder.setOnClickListener(R.id.search_close, new View.OnClickListener(paramString, paramInt2)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        CourseSharePreUtils.deleteActionSearchHistory(this.val$item);
        ActionSearchHistoryAdapter.this.remove(this.val$layoutPosition);
        if ((ActionSearchHistoryAdapter.this.getCount() == 0) && (ActionSearchHistoryAdapter.this.delBtnOnClickListener != null))
          ActionSearchHistoryAdapter.this.delBtnOnClickListener.onClick(paramView);
      }
    });
  }

  public void setDelBtnOnClickListener(View.OnClickListener paramOnClickListener)
  {
    this.delBtnOnClickListener = paramOnClickListener;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.ActionSearchHistoryAdapter
 * JD-Core Version:    0.6.0
 */