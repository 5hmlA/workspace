package com.sportq.fit.fitmoudle8.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseFitAdapter;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.mipmap;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.activity.FitMusicClassifyDetailsActivity;
import com.sportq.fit.fitmoudle8.reformer.model.MusicModel;
import java.util.ArrayList;
import java.util.List;
import org.byteam.superadapter.SuperViewHolder;

public class FitMusicLibraryAdapter extends BaseFitAdapter
{
  private ArrayList<String> downLoadList = new ArrayList();
  private Context mContext;
  private List musicModels;

  public FitMusicLibraryAdapter(Context paramContext, List paramList, int paramInt, ArrayList<String> paramArrayList)
  {
    super(paramContext, paramList, paramInt);
    this.musicModels = paramList;
    this.mContext = paramContext;
    this.downLoadList = paramArrayList;
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, Object paramObject)
  {
    MusicModel localMusicModel = (MusicModel)this.musicModels.get(paramInt2);
    LinearLayout localLinearLayout = (LinearLayout)paramSuperViewHolder.findViewById(R.id.music_item_layout);
    ImageView localImageView = (ImageView)paramSuperViewHolder.findViewById(R.id.music_library_item_bg);
    TextView localTextView1 = (TextView)paramSuperViewHolder.findViewById(R.id.music_library_item_name);
    TextView localTextView2 = (TextView)paramSuperViewHolder.findViewById(R.id.music_download_num);
    LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)paramSuperViewHolder.findViewById(R.id.music_library_item_bg).getLayoutParams();
    int i = (int)(0.433333D * BaseApplication.screenWidth);
    localLayoutParams.width = i;
    localLayoutParams.height = i;
    localImageView.setLayoutParams(localLayoutParams);
    GlideUtils.loadImgByDefault(localMusicModel.imageURL, R.mipmap.img_fit_logo, localImageView);
    localTextView1.setText(localMusicModel.categoryName);
    String str = this.mContext.getResources().getString(R.string.have_been_down_num_hint);
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = String.valueOf(localMusicModel.down_num);
    localTextView2.setText(String.format(str, arrayOfObject));
    localLinearLayout.setOnClickListener(new View.OnClickListener(localMusicModel)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(FitMusicLibraryAdapter.this.mContext, FitMusicClassifyDetailsActivity.class);
        localIntent.putExtra("categoryId", this.val$model.categoryId);
        localIntent.putStringArrayListExtra("down.load.list", FitMusicLibraryAdapter.this.downLoadList);
        FitMusicLibraryAdapter.this.mContext.startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)FitMusicLibraryAdapter.this.mContext, 0);
      }
    });
  }

  public void setDownLoadList(ArrayList<String> paramArrayList)
  {
    this.downLoadList = paramArrayList;
  }

  public void setMusicModels(List paramList)
  {
    this.musicModels = paramList;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.FitMusicLibraryAdapter
 * JD-Core Version:    0.6.0
 */