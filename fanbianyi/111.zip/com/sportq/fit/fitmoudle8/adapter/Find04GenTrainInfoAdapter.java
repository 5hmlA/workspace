package com.sportq.fit.fitmoudle8.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.text.TextPaint;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.mipmap;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.widget.CourseCommentTitleView;
import com.sportq.fit.fitmoudle8.widget.CourseCommentTitleView.CourseTitleItemClickListener;
import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools.EquipmentItemClick;
import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools.InitFinishListener;
import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools.TrainMusicItemClick;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.List;
import org.byteam.superadapter.IMulItemViewType;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class Find04GenTrainInfoAdapter extends SuperAdapter<ActionModel>
{
  private CourseCommentTitleView courseCommentTitleView;
  private int currentIndex = 0;
  private Find04TrainInfoTools.EquipmentItemClick equipmentItemClick;
  private PlanModel individualInfo;
  private Find04TrainInfoTools.InitFinishListener initFinishListener;
  private Context mContext;
  private TextView musicNameView;
  private PlanModel planModel;
  private PlanReformer planReformer;
  private String strType;
  private CourseCommentTitleView.CourseTitleItemClickListener titleItemClickListener;
  private Find04TrainInfoTools.TrainMusicItemClick trainMusicItemClick;

  public Find04GenTrainInfoAdapter(Context paramContext, List<ActionModel> paramList, IMulItemViewType<ActionModel> paramIMulItemViewType, String paramString, PlanReformer paramPlanReformer)
  {
    super(paramContext, paramList, paramIMulItemViewType);
    this.mContext = paramContext;
    this.strType = paramString;
    this.planReformer = paramPlanReformer;
    this.individualInfo = paramPlanReformer._individualInfo;
    if ("0".equals(paramString));
    for (PlanModel localPlanModel = paramPlanReformer._individualInfo; ; localPlanModel = paramPlanReformer._planInfo)
    {
      this.planModel = localPlanModel;
      return;
    }
  }

  private void setDataForPage01(SuperViewHolder paramSuperViewHolder)
  {
    paramSuperViewHolder.findViewById(R.id.relafind04_general_trian_info_item02).setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));
    label124: FrameLayout localFrameLayout;
    if (("0".equals(this.strType)) && (StringUtils.isNull(((Activity)this.mContext).getIntent().getStringExtra("customized.id"))) && (StringUtils.isNull(((Activity)this.mContext).getIntent().getStringExtra("choice.pro"))))
      if (StringUtils.isNull(this.planModel.trainFrequency))
      {
        paramSuperViewHolder.findViewById(R.id.train_frequency_layout).setVisibility(8);
        if (!StringUtils.isNull(this.individualInfo.planApparatusName))
          break label368;
        paramSuperViewHolder.findViewById(R.id.equipment_layout).setVisibility(8);
        if (!"0".equals(this.strType))
          break label471;
        paramSuperViewHolder.findViewById(R.id.child_train_title).setVisibility(8);
        paramSuperViewHolder.findViewById(R.id.train_info_layout).setVisibility(8);
        label160: this.musicNameView = ((TextView)paramSuperViewHolder.findViewById(R.id.train_music_name));
        if (PreferencesTools.getFloatValueToKey("tbl_volume_info", Constant.KEY_MUSIC_TOGGLE) != Constant.MUSIC_OFF)
          break label958;
        this.musicNameView.setText("无");
        paramSuperViewHolder.findViewById(R.id.train_music_layout).setOnClickListener(new FitAction(null)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            if (Find04GenTrainInfoAdapter.this.trainMusicItemClick != null)
              Find04GenTrainInfoAdapter.this.trainMusicItemClick.trainMusicItemClick();
            super.onClick(paramView);
          }
        });
        localFrameLayout = (FrameLayout)paramSuperViewHolder.findViewById(R.id.recent_update_layout);
        if ((!StringUtils.isNull(this.individualInfo.updateTime)) && (!StringUtils.isNull(this.individualInfo.updateComment)))
          break label1006;
        localFrameLayout.setVisibility(8);
      }
    while (true)
    {
      this.courseCommentTitleView = ((CourseCommentTitleView)paramSuperViewHolder.findViewById(R.id.course_comment_title));
      this.courseCommentTitleView.initData(this.currentIndex, this.individualInfo);
      this.courseCommentTitleView.setCourseTitleItemClickListener(this.titleItemClickListener);
      this.courseCommentTitleView.post(new Runnable()
      {
        public void run()
        {
          if (Find04GenTrainInfoAdapter.this.initFinishListener != null)
            Find04GenTrainInfoAdapter.this.initFinishListener.initFinished();
        }
      });
      return;
      paramSuperViewHolder.findViewById(R.id.train_frequency_layout).setVisibility(0);
      ((TextView)paramSuperViewHolder.findViewById(R.id.train_frequency)).setText(this.planModel.trainFrequency);
      break;
      paramSuperViewHolder.findViewById(R.id.train_frequency_layout).setVisibility(8);
      break;
      label368: ((TextView)paramSuperViewHolder.findViewById(R.id.equipment_text)).setText(this.individualInfo.planApparatusName);
      paramSuperViewHolder.findViewById(R.id.equipment_layout).setVisibility(0);
      String str1 = SharePreferenceUtils.getEliminateComment();
      if ((!StringUtils.isNull(str1)) && (str1.contains(this.individualInfo.planApparatusName)))
      {
        paramSuperViewHolder.findViewById(R.id.icn_right_arrow).setVisibility(8);
        break label124;
      }
      paramSuperViewHolder.findViewById(R.id.icn_right_arrow).setVisibility(0);
      paramSuperViewHolder.findViewById(R.id.equipment_layout).setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (Find04GenTrainInfoAdapter.this.equipmentItemClick != null)
            Find04GenTrainInfoAdapter.this.equipmentItemClick.equipItemClick();
        }
      });
      break label124;
      label471: ((TextView)paramSuperViewHolder.findViewById(R.id.child_train_title)).setText(this.individualInfo.planName);
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_train_duration_desc)).setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_train_duration_desc)).setText(this.individualInfo.planTrainDuration.substring(0, -2 + this.individualInfo.planTrainDuration.length()));
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_train_duration_desc)).setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_train_duration)).setText(this.individualInfo.planTrainDuration.substring(-2 + this.individualInfo.planTrainDuration.length(), this.individualInfo.planTrainDuration.length()));
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_train_duration)).setTextColor(ContextCompat.getColor(this.mContext, R.color.color_828282));
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_calorie_desc)).setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_calorie_desc)).setText(this.individualInfo.planKaluri.substring(0, -2 + this.individualInfo.planKaluri.length()));
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_calorie_desc)).setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_calorie)).setText(this.individualInfo.planKaluri.substring(-2 + this.individualInfo.planKaluri.length(), this.individualInfo.planKaluri.length()));
      ((TextView)paramSuperViewHolder.findViewById(R.id.all_calorie)).setTextColor(ContextCompat.getColor(this.mContext, R.color.color_828282));
      ((TextView)paramSuperViewHolder.findViewById(R.id.diff_desc)).setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
      ((TextView)paramSuperViewHolder.findViewById(R.id.diff_desc)).setText(this.individualInfo.planDifficultyLevel);
      ((TextView)paramSuperViewHolder.findViewById(R.id.diff_desc)).getPaint().setFakeBoldText(true);
      ((TextView)paramSuperViewHolder.findViewById(R.id.diff_desc)).setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
      ((TextView)paramSuperViewHolder.findViewById(R.id.diff_hint)).setText(this.mContext.getResources().getString(R.string.diff_hint));
      ((TextView)paramSuperViewHolder.findViewById(R.id.diff_hint)).setTextColor(ContextCompat.getColor(this.mContext, R.color.color_828282));
      paramSuperViewHolder.findViewById(R.id.child_train_title).setVisibility(0);
      paramSuperViewHolder.findViewById(R.id.train_info_layout).setVisibility(0);
      break label160;
      label958: String str2 = SharePreferenceUtils.getCourseBgMusicName(this.individualInfo.planId);
      if (StringUtils.isNull(str2));
      for (String str3 = this.individualInfo.musicName; ; str3 = FileUtils.convertBgMusicName(str2))
      {
        this.musicNameView.setText(str3);
        break;
      }
      label1006: localFrameLayout.setVisibility(0);
      TextView localTextView = (TextView)paramSuperViewHolder.findViewById(R.id.recent_update_date);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = this.individualInfo.updateTime;
      localTextView.setText(String.format("近期更新（%s）", arrayOfObject));
      ((TextView)paramSuperViewHolder.findViewById(R.id.recent_update_content)).setText(("根据Fit团队对课程专业度的持续测试及Fitters的训练反馈，对此课程进行了如下优化调整：[br]" + this.individualInfo.updateComment).replace("[br]", "\n"));
    }
  }

  private void setDataForPage02(SuperViewHolder paramSuperViewHolder, int paramInt)
  {
    ActionModel localActionModel = (ActionModel)getData().get(paramInt);
    View localView = paramSuperViewHolder.findViewById(R.id.stage_name_layout);
    int i;
    if (localActionModel.isFirst)
    {
      i = 0;
      localView.setVisibility(i);
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(localActionModel.stageName.replaceAll(this.mContext.getResources().getString(R.string.stage_hint), ""));
      localStringBuilder.append("  ·  ");
      localStringBuilder.append(localActionModel.actionCount);
      ((TextView)paramSuperViewHolder.findViewById(R.id.stage_name)).setText(localStringBuilder.toString());
      if ((!"1".equals(this.individualInfo.energyFlag)) || (!"0".equals(this.individualInfo.restTime)) || (paramInt != -1 + getData().size()))
        break label333;
      paramSuperViewHolder.findViewById(R.id.stage_act_layout).setPadding(0, 0, 0, CompDeviceInfoUtils.convertOfDip(this.mContext, 50.0F));
      label184: if (!localActionModel.isRest())
        break label350;
      paramSuperViewHolder.findViewById(R.id.rest_layout).setVisibility(0);
      paramSuperViewHolder.findViewById(R.id.train_layout).setVisibility(8);
      ((TextView)paramSuperViewHolder.findViewById(R.id.rest_hint)).setText(localActionModel.actionName);
      ((TextView)paramSuperViewHolder.findViewById(R.id.rest_sec_hint)).setText(String.valueOf(localActionModel.actionDuration + localActionModel.getActionDurationUnit()));
      label271: if (paramInt != -1 + getData().size())
        break label453;
      paramSuperViewHolder.findViewById(R.id.split_line).setVisibility(8);
    }
    while (true)
    {
      if (localActionModel.isRest())
        break label467;
      paramSuperViewHolder.findViewById(R.id.train_layout).setOnClickListener(new FitAction(null, localActionModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
          {
            public void result(boolean paramBoolean)
            {
              if (paramBoolean)
                FitJumpImpl.getInstance().findJumpFind07TrainPreviewActivity(Find04GenTrainInfoAdapter.this.mContext, 1, Find04GenTrainInfoAdapter.this.planReformer, Find04GenTrainInfoAdapter.4.this.val$actionModel);
            }
          }
          , Find04GenTrainInfoAdapter.this.mContext, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
          super.onClick(paramView);
        }
      });
      return;
      i = 8;
      break;
      label333: paramSuperViewHolder.findViewById(R.id.stage_act_layout).setPadding(0, 0, 0, 0);
      break label184;
      label350: paramSuperViewHolder.findViewById(R.id.train_layout).setVisibility(0);
      paramSuperViewHolder.findViewById(R.id.rest_layout).setVisibility(8);
      GlideUtils.loadImgByDefault(localActionModel.actionImageURL, R.mipmap.img_fit_logo, (ImageView)paramSuperViewHolder.findViewById(R.id.act_image));
      ((TextView)paramSuperViewHolder.findViewById(R.id.act_title)).setText(localActionModel.actionName);
      ((TextView)paramSuperViewHolder.findViewById(R.id.act_duration)).setText(String.valueOf(localActionModel.actionDuration + localActionModel.getActionDurationUnit()));
      break label271;
      label453: paramSuperViewHolder.findViewById(R.id.split_line).setVisibility(0);
    }
    label467: paramSuperViewHolder.findViewById(R.id.train_layout).setBackgroundColor(ContextCompat.getColor(this.mContext, 17170445));
  }

  public CourseCommentTitleView getCourseCommentTitleView()
  {
    return this.courseCommentTitleView;
  }

  public PlanModel getIndividualInfo()
  {
    return this.individualInfo;
  }

  public TextView getMusicNameView()
  {
    return this.musicNameView;
  }

  public PlanModel getPlanModel()
  {
    return this.planModel;
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, ActionModel paramActionModel)
  {
    if (paramInt1 == 0)
    {
      setDataForPage01(paramSuperViewHolder);
      return;
    }
    setDataForPage02(paramSuperViewHolder, paramInt2 - 2);
  }

  public void setCurrentIndex(int paramInt)
  {
    this.currentIndex = paramInt;
  }

  public void setEquipmentItemClick(Find04TrainInfoTools.EquipmentItemClick paramEquipmentItemClick)
  {
    this.equipmentItemClick = paramEquipmentItemClick;
  }

  public void setInitFinishListener(Find04TrainInfoTools.InitFinishListener paramInitFinishListener)
  {
    this.initFinishListener = paramInitFinishListener;
  }

  public void setTitleItemClickListener(CourseCommentTitleView.CourseTitleItemClickListener paramCourseTitleItemClickListener)
  {
    this.titleItemClickListener = paramCourseTitleItemClickListener;
  }

  public void setTrainMusicItemClick(Find04TrainInfoTools.TrainMusicItemClick paramTrainMusicItemClick)
  {
    this.trainMusicItemClick = paramTrainMusicItemClick;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.Find04GenTrainInfoAdapter
 * JD-Core Version:    0.6.0
 */