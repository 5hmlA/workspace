package com.sportq.fit.fitmoudle8.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.ScreenModel;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.R.drawable;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.layout;
import java.util.ArrayList;

public class SiftingGridViewAdapter extends BaseAdapter
{
  private int fillType;
  private LayoutInflater lInflater = null;
  private ArrayList<ScreenModel> list;

  public SiftingGridViewAdapter(Context paramContext, int paramInt, ArrayList<ScreenModel> paramArrayList)
  {
    this.list = paramArrayList;
    this.fillType = paramInt;
    this.lInflater = LayoutInflater.from(paramContext);
  }

  public int getCount()
  {
    return this.list.size();
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    double d1;
    label96: double d2;
    label124: float f3;
    label171: String str;
    if (paramView == null)
    {
      localViewHolder = new ViewHolder(null);
      paramView = this.lInflater.inflate(R.layout.sifting_gridview_item, null);
      localViewHolder.sifting_itemview = ((TextView)paramView.findViewById(R.id.sifting_itemview));
      localViewHolder.sifting_itemview02 = ((TextView)paramView.findViewById(R.id.sifting_itemview02));
      localViewHolder.gridview_item = ((RelativeLayout)paramView.findViewById(R.id.gridview_item));
      paramView.setTag(localViewHolder);
      float f1 = BaseApplication.screenWidth;
      if (this.fillType == 3)
        break label272;
      d1 = 0.212962D;
      int i = (int)(f1 * (float)d1);
      float f2 = BaseApplication.screenWidth;
      if (this.fillType == 3)
        break label280;
      d2 = 0.09259249999999999D;
      RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(i, (int)(f2 * (float)d2));
      localViewHolder.gridview_item.setLayoutParams(localLayoutParams);
      TextView localTextView1 = localViewHolder.sifting_itemview;
      if (this.fillType == 3)
        break label288;
      f3 = 14.0F;
      localTextView1.setTextSize(f3);
      TextView localTextView2 = localViewHolder.sifting_itemview;
      if (this.fillType == 3)
        break label295;
      str = ((ScreenModel)this.list.get(paramInt)).name;
      label209: localTextView2.setText(str);
      if (this.fillType == 3)
        break label314;
      localViewHolder.sifting_itemview02.setVisibility(8);
    }
    while (true)
    {
      paramView.setId(666666 + paramInt);
      localViewHolder.sifting_itemview02.setTag(null);
      paramView.setBackgroundResource(R.drawable.sifting_item_bg);
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
      break;
      label272: d1 = 0.446296D;
      break label96;
      label280: d2 = 0.166666D;
      break label124;
      label288: f3 = 16.0F;
      break label171;
      label295: str = ((ScreenModel)this.list.get(paramInt)).intr;
      break label209;
      label314: if (!StringUtils.isNull(((ScreenModel)this.list.get(paramInt)).name))
      {
        localViewHolder.sifting_itemview02.setVisibility(0);
        localViewHolder.sifting_itemview02.setText(((ScreenModel)this.list.get(paramInt)).name);
        continue;
      }
      localViewHolder.sifting_itemview02.setVisibility(8);
    }
  }

  private static final class ViewHolder
  {
    RelativeLayout gridview_item;
    TextView sifting_itemview;
    TextView sifting_itemview02;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.SiftingGridViewAdapter
 * JD-Core Version:    0.6.0
 */