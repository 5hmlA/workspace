package com.sportq.fit.fitmoudle8.adapter;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import com.sportq.fit.common.reformer.SystemTimeReformer;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.mipmap;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class ActionScreenAdapter extends SuperAdapter<ResponseModel.ActionData>
{
  private String strCurrentId;
  private SystemTimeReformer systemTimeReformer;

  public ActionScreenAdapter(Context paramContext, List<ResponseModel.ActionData> paramList, @LayoutRes int paramInt, SystemTimeReformer paramSystemTimeReformer)
  {
    super(paramContext, paramList, paramInt);
    this.systemTimeReformer = paramSystemTimeReformer;
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, ResponseModel.ActionData paramActionData)
  {
    int i;
    if ("0".equals(paramActionData.energyActFlag))
    {
      paramSuperViewHolder.findViewById(R.id.action_lock_img).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.energy_hint_icon).setVisibility(8);
      View localView = paramSuperViewHolder.findViewById(R.id.vertical_hint_view);
      boolean bool = paramActionData.actionId.equals(this.strCurrentId);
      i = 0;
      if (!bool)
        break label317;
      label68: localView.setVisibility(i);
      ((TextView)paramSuperViewHolder.findViewById(R.id.action_title)).setText(paramActionData.name);
      if (!StringUtils.isNull(paramActionData.apparatus))
        break label324;
    }
    label317: label324: for (String str = StringUtils.difficultyLevel(paramActionData.difficultyLevel); ; str = StringUtils.difficultyLevel(paramActionData.difficultyLevel) + " • " + paramActionData.apparatus)
    {
      ((TextView)paramSuperViewHolder.findViewById(R.id.action_difficult)).setText(str);
      GlideUtils.loadImgByDefault(paramActionData.imageURL, R.mipmap.img_fit_logo, (ImageView)(ImageView)paramSuperViewHolder.findViewById(R.id.action_image));
      return;
      if ((StringUtils.isNull(paramActionData.endTime)) && (!"1".equals(BaseApplication.userModel.isVip)))
        paramSuperViewHolder.findViewById(R.id.action_lock_img).setVisibility(0);
      while (true)
      {
        paramSuperViewHolder.findViewById(R.id.energy_hint_icon).setVisibility(8);
        break;
        if ("1".equals(BaseApplication.userModel.isVip))
        {
          paramSuperViewHolder.findViewById(R.id.action_lock_img).setVisibility(8);
          continue;
        }
        long l1 = Long.valueOf(DateUtils.date2TimeStamp(this.systemTimeReformer.timeKey, "yyyy-MM-dd HH:mm:ss")).longValue();
        long l2 = Long.valueOf(paramActionData.endTime).longValue();
        if (("1".equals(paramActionData.energyActFlag)) && (l1 > l2))
        {
          paramSuperViewHolder.findViewById(R.id.action_lock_img).setVisibility(0);
          continue;
        }
        paramSuperViewHolder.findViewById(R.id.action_lock_img).setVisibility(8);
      }
      i = 8;
      break label68;
    }
  }

  public void setStrCurrentId(String paramString)
  {
    this.strCurrentId = paramString;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.ActionScreenAdapter
 * JD-Core Version:    0.6.0
 */