package com.sportq.fit.fitmoudle8.adapter;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.widget.CustomTypefaceSpan;
import com.sportq.fit.fitmoudle8.R.color;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.mipmap;
import com.sportq.fit.fitmoudle8.reformer.model.EntactClassifyInfoData;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class ActionClassifyAdapter extends SuperAdapter<EntactClassifyInfoData>
{
  private boolean isNeedShowFlg;
  private String strCountDown;

  public ActionClassifyAdapter(Context paramContext, List<EntactClassifyInfoData> paramList, @LayoutRes int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, EntactClassifyInfoData paramEntactClassifyInfoData)
  {
    GlideUtils.loadImgByDefault(paramEntactClassifyInfoData.actClassifyImg, R.mipmap.img_fit_logo, (ImageView)paramSuperViewHolder.findViewById(R.id.action_img));
    ((TextView)paramSuperViewHolder.findViewById(R.id.action_name)).setText(paramEntactClassifyInfoData.actClassifyName);
    if (paramInt2 == -1 + getItemCount())
    {
      if (!this.isNeedShowFlg)
        break label217;
      paramSuperViewHolder.findViewById(R.id.countdown_hint_layout).setVisibility(0);
      ForegroundColorSpan localForegroundColorSpan = new ForegroundColorSpan(ContextCompat.getColor(getContext(), R.color.color_828282));
      SpannableString localSpannableString = new SpannableString(this.strCountDown);
      localSpannableString.setSpan(localForegroundColorSpan, 6, this.strCountDown.lastIndexOf(" "), 33);
      localSpannableString.setSpan(new AbsoluteSizeSpan(15, true), 6, this.strCountDown.lastIndexOf(" "), 33);
      localSpannableString.setSpan(new CustomTypefaceSpan(TextUtils.getFontFaceImpact()), 6, this.strCountDown.lastIndexOf(" "), 33);
      ((TextView)paramSuperViewHolder.findViewById(R.id.countdown_hint_view)).setText(localSpannableString);
    }
    while (true)
    {
      if ("1".equals(BaseApplication.userModel.isVip))
        paramSuperViewHolder.findViewById(R.id.countdown_hint_layout).setVisibility(8);
      return;
      label217: paramSuperViewHolder.findViewById(R.id.countdown_hint_layout).setVisibility(8);
    }
  }

  public void setNeedShowFlg(boolean paramBoolean)
  {
    this.isNeedShowFlg = paramBoolean;
  }

  public void setStrCountDown(String paramString)
  {
    this.strCountDown = paramString;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.ActionClassifyAdapter
 * JD-Core Version:    0.6.0
 */