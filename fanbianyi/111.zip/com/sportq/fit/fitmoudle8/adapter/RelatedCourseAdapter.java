package com.sportq.fit.fitmoudle8.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.View;
import android.widget.TextView;
import cn.iwgang.countdownview.CountdownView.OnCountdownEndListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.RelatedCoursesEntity;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseFitAdapter;
import com.sportq.fit.fitmoudle.widget.PlanTrainUnJoinView;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import org.byteam.superadapter.SuperViewHolder;
import org.greenrobot.eventbus.EventBus;

public class RelatedCourseAdapter extends BaseFitAdapter
{
  private CountdownView.OnCountdownEndListener cListener;
  private Context context;
  private ArrayList<RelatedCoursesEntity> dataList;
  private FitInterfaceUtils.UIInitListener listener;
  private ArrayList<RelatedCoursesEntity> planList;

  public RelatedCourseAdapter(Context paramContext, ArrayList<RelatedCoursesEntity> paramArrayList, int paramInt, FitInterfaceUtils.UIInitListener paramUIInitListener, CountdownView.OnCountdownEndListener paramOnCountdownEndListener)
  {
    super(paramContext, paramArrayList, paramInt);
    this.dataList = paramArrayList;
    this.context = paramContext;
    this.listener = paramUIInitListener;
    this.cListener = paramOnCountdownEndListener;
  }

  private PlanModel convertData(RelatedCoursesEntity paramRelatedCoursesEntity, int paramInt)
  {
    PlanModel localPlanModel = new PlanModel();
    localPlanModel.planName = paramRelatedCoursesEntity.planName;
    localPlanModel.planImageURL = paramRelatedCoursesEntity.imageURL;
    StringBuilder localStringBuilder;
    String str;
    if (paramInt == 1)
    {
      localStringBuilder = new StringBuilder().append(paramRelatedCoursesEntity.trainDuration).append(this.context.getResources().getString(R.string.jie_hint)).append(" · ").append(StringUtils.difficultyLevel(paramRelatedCoursesEntity.difficultyLevel));
      if (StringUtils.isNull(paramRelatedCoursesEntity.apparatus))
        str = "";
    }
    for (localPlanModel.courseInfo = str; ; localPlanModel.courseInfo = (paramRelatedCoursesEntity.trainDuration + this.context.getResources().getString(R.string.min_hint) + " · " + paramRelatedCoursesEntity.calorie + this.context.getString(R.string.kilocalorie) + " · " + StringUtils.difficultyLevel(paramRelatedCoursesEntity.difficultyLevel)))
    {
      localPlanModel.planNumberOfParticipants = (paramRelatedCoursesEntity.numberOfParticipants + this.context.getResources().getString(R.string.people_hint));
      localPlanModel.planStateCode = paramRelatedCoursesEntity.stateCode;
      localPlanModel.isNewTag = paramRelatedCoursesEntity.isNewTag;
      localPlanModel.isUpdate = paramRelatedCoursesEntity.isUpdate;
      localPlanModel.energyFlag = paramRelatedCoursesEntity.energyFlag;
      localPlanModel.effectTime = paramRelatedCoursesEntity.effectTime;
      localPlanModel.restTime = paramRelatedCoursesEntity.restTime;
      return localPlanModel;
      str = " · " + paramRelatedCoursesEntity.apparatus;
      break;
    }
  }

  private void singleTrainClickAction(SinglePlanTrainView paramSinglePlanTrainView, RelatedCoursesEntity paramRelatedCoursesEntity, int paramInt)
  {
    paramSinglePlanTrainView.setOnClickListener(new FitAction(this, paramRelatedCoursesEntity, paramInt)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        MiddleManager.getInstance().getFindPresenterImpl(RelatedCourseAdapter.this.listener, null).statsRelatedCoursesItemClick(this.val$entity.olapInfo);
        Intent localIntent;
        if ("0".equals(this.val$entity.type))
        {
          localIntent = new Intent(RelatedCourseAdapter.this.context, Find04GenTrainInfoActivity.class);
          localIntent.putExtra("single.type", "0");
          localIntent.putExtra("plan.id", this.val$entity.planId);
        }
        while (true)
        {
          EventBus.getDefault().post("finish.train.info.page");
          RelatedCourseAdapter.this.context.startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)RelatedCourseAdapter.this.context, 0);
          super.onClick(paramView);
          return;
          if (("0".equals(this.val$entity.stateCode)) || ("2".equals(this.val$entity.stateCode)))
          {
            localIntent = new Intent(RelatedCourseAdapter.this.context, Find03GenTrainListActivity.class);
            localIntent.putExtra("plan.id", this.val$entity.planId);
            localIntent.putExtra("position", String.valueOf(this.val$position));
            localIntent.putExtra("refresh.status", "refresh");
            localIntent.putExtra("plan.stateCode", this.val$entity.stateCode);
            continue;
          }
          localIntent = new Intent(RelatedCourseAdapter.this.context, Find04GenTrainInfoActivity.class);
          localIntent.putExtra("plan.id", this.val$entity.planId);
          localIntent.putExtra("position", String.valueOf(this.val$position));
          localIntent.putExtra("intent.from", "from.challenge");
        }
      }
    });
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, Object paramObject)
  {
    PlanTrainUnJoinView localPlanTrainUnJoinView = (PlanTrainUnJoinView)paramSuperViewHolder.findViewById(R.id.course_info);
    SinglePlanTrainView localSinglePlanTrainView = (SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.single_course_info);
    int i = this.planList.size();
    if (paramInt2 < i)
    {
      if (paramInt2 == 0)
      {
        paramSuperViewHolder.findViewById(R.id.course_title).setVisibility(0);
        ((TextView)paramSuperViewHolder.findViewById(R.id.course_title)).setText(this.context.getResources().getString(R.string.more_train_hint));
      }
      while (true)
      {
        paramSuperViewHolder.findViewById(R.id.split_line01).setVisibility(8);
        RelatedCoursesEntity localRelatedCoursesEntity2 = (RelatedCoursesEntity)this.dataList.get(paramInt2);
        localPlanTrainUnJoinView.setVisibility(0);
        localSinglePlanTrainView.setVisibility(4);
        localPlanTrainUnJoinView.initView(convertData(localRelatedCoursesEntity2, 1));
        localPlanTrainUnJoinView.setOnClickListener(new FitAction(this, localRelatedCoursesEntity2, paramInt2)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            MiddleManager.getInstance().getFindPresenterImpl(RelatedCourseAdapter.this.listener, null).statsRelatedCoursesItemClick(this.val$entity.olapInfo);
            Intent localIntent;
            if ("0".equals(this.val$entity.type))
            {
              localIntent = new Intent(RelatedCourseAdapter.this.context, Find04GenTrainInfoActivity.class);
              localIntent.putExtra("single.type", "0");
              localIntent.putExtra("plan.id", this.val$entity.planId);
              localIntent.putExtra("intent.from", ((Activity)RelatedCourseAdapter.this.context).getIntent().getStringExtra("intent.from"));
            }
            while (true)
            {
              EventBus.getDefault().post("finish.train.info.page");
              RelatedCourseAdapter.this.context.startActivity(localIntent);
              AnimationUtil.pageJumpAnim((Activity)RelatedCourseAdapter.this.context, 0);
              super.onClick(paramView);
              return;
              if (("0".equals(this.val$entity.stateCode)) || ("2".equals(this.val$entity.stateCode)))
              {
                localIntent = new Intent(RelatedCourseAdapter.this.context, Find03GenTrainListActivity.class);
                localIntent.putExtra("plan.id", this.val$entity.planId);
                localIntent.putExtra("position", String.valueOf(this.val$position));
                localIntent.putExtra("refresh.status", "refresh");
                localIntent.putExtra("plan.stateCode", this.val$entity.stateCode);
                continue;
              }
              localIntent = new Intent(RelatedCourseAdapter.this.context, Find04GenTrainInfoActivity.class);
              localIntent.putExtra("plan.id", this.val$entity.planId);
              localIntent.putExtra("position", String.valueOf(this.val$position));
              localIntent.putExtra("intent.from", ((Activity)RelatedCourseAdapter.this.context).getIntent().getStringExtra("intent.from"));
            }
          }
        });
        if (paramInt2 != i - 1)
          paramSuperViewHolder.findViewById(R.id.space_view).setVisibility(0);
        paramSuperViewHolder.findViewById(R.id.single_space_view).setVisibility(8);
        return;
        paramSuperViewHolder.findViewById(R.id.course_title).setVisibility(8);
      }
    }
    if (paramInt2 == i)
    {
      paramSuperViewHolder.findViewById(R.id.course_title).setVisibility(0);
      ((TextView)paramSuperViewHolder.findViewById(R.id.course_title)).setText(this.context.getResources().getString(R.string.single_course_hint));
    }
    while (true)
    {
      localPlanTrainUnJoinView.setVisibility(8);
      localSinglePlanTrainView.setVisibility(0);
      RelatedCoursesEntity localRelatedCoursesEntity1 = (RelatedCoursesEntity)this.dataList.get(paramInt2 - i);
      localSinglePlanTrainView.initView(convertData(localRelatedCoursesEntity1, 0), 0);
      localSinglePlanTrainView.setCourseStyleBold();
      singleTrainClickAction(localSinglePlanTrainView, localRelatedCoursesEntity1, paramInt2);
      paramSuperViewHolder.findViewById(R.id.space_view).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.single_space_view).setVisibility(0);
      return;
      paramSuperViewHolder.findViewById(R.id.course_title).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.split_line01).setVisibility(0);
    }
  }

  public void onViewAttachedToWindow(SuperViewHolder paramSuperViewHolder)
  {
    try
    {
      int i = paramSuperViewHolder.getAdapterPosition();
      SinglePlanTrainView localSinglePlanTrainView = (SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.single_course_info);
      int j = this.planList.size();
      if (i >= j)
        localSinglePlanTrainView.setCountDownTime(convertData((RelatedCoursesEntity)this.dataList.get(i - j), 0), this.cListener);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void onViewDetachedFromWindow(SuperViewHolder paramSuperViewHolder)
  {
    try
    {
      ((SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.single_course_info)).stopCountDown();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void setDataList(ArrayList<RelatedCoursesEntity> paramArrayList)
  {
    this.dataList = paramArrayList;
  }

  public void setPlanList(ArrayList<RelatedCoursesEntity> paramArrayList)
  {
    this.planList = paramArrayList;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.RelatedCourseAdapter
 * JD-Core Version:    0.6.0
 */