package com.sportq.fit.fitmoudle8.adapter;

import android.content.Context;
import android.view.View;
import cn.iwgang.countdownview.CountdownView.OnCountdownEndListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle.BaseFitAdapter;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView.OnDetailsBtnClickListener;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.List;
import org.byteam.superadapter.SuperViewHolder;

public class Find05ChoiceTrainProAdapter extends BaseFitAdapter
{
  private ArrayList<PlanModel> itemList;
  private TrainItemClickListener listener;
  private CountdownView.OnCountdownEndListener mListener;
  private String strTrainPro;

  public Find05ChoiceTrainProAdapter(Context paramContext, List paramList, int paramInt, String paramString, TrainItemClickListener paramTrainItemClickListener, CountdownView.OnCountdownEndListener paramOnCountdownEndListener)
  {
    super(paramContext, paramList, paramInt);
    this.listener = paramTrainItemClickListener;
    this.strTrainPro = paramString;
    this.mListener = paramOnCountdownEndListener;
  }

  private void controlClickAction(String paramString, View paramView, PlanModel paramPlanModel)
  {
    if (paramView != null)
      paramView.setOnClickListener(new FitAction(null, paramString, paramPlanModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (Find05ChoiceTrainProAdapter.this.listener != null)
            Find05ChoiceTrainProAdapter.this.listener.onItemClick(this.val$strCurPosition, this.val$planModel, paramView);
          super.onClick(paramView);
        }
      });
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, Object paramObject)
  {
    PlanModel localPlanModel = (PlanModel)paramObject;
    SinglePlanTrainView localSinglePlanTrainView = (SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.choice_course_item);
    localSinglePlanTrainView.setDetailsBtnClickListener(new SinglePlanTrainView.OnDetailsBtnClickListener(paramInt2, localPlanModel)
    {
      public void detailBtnClick(View paramView)
      {
        if (Find05ChoiceTrainProAdapter.this.listener != null)
          Find05ChoiceTrainProAdapter.this.listener.onItemClick(String.valueOf(1 + this.val$position), this.val$planModel, paramView);
      }
    });
    if (this.strTrainPro.equals(String.valueOf(paramInt2 + 1)));
    for (localPlanModel.currentSection = this.strTrainPro; ; localPlanModel.currentSection = null)
    {
      localSinglePlanTrainView.initView(localPlanModel, 3);
      localSinglePlanTrainView.setCourseStyleBold();
      controlClickAction(String.valueOf(paramInt2 + 1), localSinglePlanTrainView, localPlanModel);
      return;
    }
  }

  public void onViewAttachedToWindow(SuperViewHolder paramSuperViewHolder)
  {
    try
    {
      int i = paramSuperViewHolder.getAdapterPosition();
      SinglePlanTrainView localSinglePlanTrainView = (SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.choice_course_item);
      if (i >= this.itemList.size())
        localSinglePlanTrainView.setCountDownTime((PlanModel)this.itemList.get(i), this.mListener);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void onViewDetachedFromWindow(SuperViewHolder paramSuperViewHolder)
  {
    try
    {
      ((SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.choice_course_item)).stopCountDown();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void setItemList(ArrayList<PlanModel> paramArrayList)
  {
    this.itemList = paramArrayList;
  }

  public void setStrTrainPro(String paramString)
  {
    this.strTrainPro = paramString;
  }

  public static abstract interface TrainItemClickListener
  {
    public abstract void onItemClick(String paramString, PlanModel paramPlanModel, View paramView);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.Find05ChoiceTrainProAdapter
 * JD-Core Version:    0.6.0
 */