package com.sportq.fit.fitmoudle8.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.GroupModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseFitAdapter;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.layout;
import com.sportq.fit.fitmoudle8.R.mipmap;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.List;
import org.byteam.superadapter.SuperViewHolder;

public class Find02TrainCollectionAdapter extends BaseFitAdapter
{
  private int allCount;
  private LayoutInflater inflater;
  private Context mContext;
  private RelativeLayout.LayoutParams params;

  public Find02TrainCollectionAdapter(Context paramContext, List paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
    this.mContext = paramContext;
    this.allCount = paramList.size();
    this.inflater = LayoutInflater.from(paramContext);
    int i = BaseApplication.screenWidth / 2;
    this.params = new RelativeLayout.LayoutParams(i, i);
  }

  private void addSingleTrain(SuperViewHolder paramSuperViewHolder, GroupModel paramGroupModel, int paramInt)
  {
    ArrayList localArrayList1 = convertData(paramGroupModel.individualArray);
    if ((localArrayList1 == null) || (localArrayList1.isEmpty()))
      return;
    LinearLayout localLinearLayout = (LinearLayout)paramSuperViewHolder.findViewById(R.id.train_layout);
    localLinearLayout.removeAllViews();
    int i = localArrayList1.size();
    int j = 0;
    if (j < i)
    {
      ArrayList localArrayList2 = (ArrayList)localArrayList1.get(j);
      PlanModel localPlanModel1 = (PlanModel)localArrayList2.get(0);
      View localView = this.inflater.inflate(R.layout.single_train_layout, null);
      localView.findViewById(R.id.single_train_layout01).setVisibility(0);
      ImageView localImageView1 = (ImageView)localView.findViewById(R.id.single_train_image01);
      localImageView1.setLayoutParams(this.params);
      GlideUtils.loadImgByDefault(localPlanModel1.planImageURL, R.mipmap.img_fit_logo, localImageView1);
      ((TextView)localView.findViewById(R.id.single_train_name01)).setText(localPlanModel1.planName);
      ((TextView)localView.findViewById(R.id.time_equipment_diff_hint01)).setText(localPlanModel1.planSummary);
      ((TextView)localView.findViewById(R.id.single_join_number01)).setText(localPlanModel1.planNumberOfParticipants);
      ImageView localImageView2 = (ImageView)localView.findViewById(R.id.single_new_icon01);
      int m;
      label226: int n;
      if ("1".equals(localPlanModel1.isNewTag))
      {
        m = 0;
        localImageView2.setVisibility(m);
        singleTrainClickAction(localImageView1, localPlanModel1);
        if (localArrayList2.size() <= 1)
          break label434;
        localView.findViewById(R.id.single_train_layout02).setVisibility(0);
        PlanModel localPlanModel2 = (PlanModel)localArrayList2.get(1);
        ImageView localImageView3 = (ImageView)localView.findViewById(R.id.single_train_image02);
        localImageView3.setLayoutParams(this.params);
        GlideUtils.loadImgByDefault(localPlanModel2.planImageURL, R.mipmap.img_fit_logo, localImageView3);
        ((TextView)localView.findViewById(R.id.single_train_name02)).setText(localPlanModel2.planName);
        ((TextView)localView.findViewById(R.id.time_equipment_diff_hint02)).setText(localPlanModel2.planSummary);
        ((TextView)localView.findViewById(R.id.single_join_number02)).setText(localPlanModel2.planNumberOfParticipants);
        ImageView localImageView4 = (ImageView)localView.findViewById(R.id.single_new_icon02);
        if (!"1".equals(localPlanModel2.isNewTag))
          break label428;
        n = 0;
        label394: localImageView4.setVisibility(n);
        singleTrainClickAction(localImageView3, localPlanModel2);
      }
      while (true)
      {
        localLinearLayout.addView(localView);
        j++;
        break;
        m = 4;
        break label226;
        label428: n = 4;
        break label394;
        label434: localView.findViewById(R.id.single_train_layout02).setVisibility(4);
      }
    }
    if (paramInt == -1 + this.allCount);
    for (int k = -5; ; k = 0)
    {
      localLinearLayout.setPadding(0, 0, 0, k);
      return;
    }
  }

  private static ArrayList<ArrayList<PlanModel>> convertData(ArrayList<PlanModel> paramArrayList)
  {
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    int i = paramArrayList.size();
    int j = 0;
    if (j < i)
    {
      localArrayList2.add(paramArrayList.get(j));
      if ((j + 1) % 2 == 0)
      {
        localArrayList1.add(localArrayList2);
        localArrayList2 = new ArrayList();
      }
      while (true)
      {
        j++;
        break;
        if (j != i - 1)
          continue;
        localArrayList1.add(localArrayList2);
        localArrayList2 = new ArrayList();
      }
    }
    return localArrayList1;
  }

  private void singleTrainClickAction(ImageView paramImageView, PlanModel paramPlanModel)
  {
    paramImageView.setOnClickListener(new View.OnClickListener(paramPlanModel)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(Find02TrainCollectionAdapter.this.mContext, Find04GenTrainInfoActivity.class);
        localIntent.putExtra("single.type", "0");
        localIntent.putExtra("plan.id", this.val$planModel.planId);
        Find02TrainCollectionAdapter.this.mContext.startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)Find02TrainCollectionAdapter.this.mContext, 0);
        FitAction.temporaryPCB(Find02TrainCollectionAdapter.this.mContext.getResources().getString(R.string.stats_b1_22_itemCell), this.val$planModel.olapInfo);
      }
    });
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, Object paramObject)
  {
    GroupModel localGroupModel = (GroupModel)paramObject;
    paramSuperViewHolder.findViewById(R.id.train_title_layout).setVisibility(0);
    paramSuperViewHolder.setText(R.id.train_name, localGroupModel.groupName);
    paramSuperViewHolder.setText(R.id.train_desc, localGroupModel.groupInstuduce);
    addSingleTrain(paramSuperViewHolder, localGroupModel, paramInt2);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.Find02TrainCollectionAdapter
 * JD-Core Version:    0.6.0
 */