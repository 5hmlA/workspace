package com.sportq.fit.fitmoudle8.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import cn.iwgang.countdownview.CountdownView;
import cn.iwgang.countdownview.CountdownView.OnCountdownEndListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.widget.PlanTrainUnJoinView;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.layout;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

public class Find02AllCourseAdapter extends BaseAdapter
{
  private CountdownView.OnCountdownEndListener cListener;
  private Context context;
  private ArrayList<PlanModel> dataList;
  private LayoutInflater inflater;
  private OnSaveSearchWordsListener saveListener;
  private int trainCount;

  public Find02AllCourseAdapter(Context paramContext, CountdownView.OnCountdownEndListener paramOnCountdownEndListener, ArrayList<PlanModel> paramArrayList, int paramInt, OnSaveSearchWordsListener paramOnSaveSearchWordsListener)
  {
    this.trainCount = paramInt;
    this.dataList = paramArrayList;
    this.context = paramContext;
    this.saveListener = paramOnSaveSearchWordsListener;
    this.cListener = paramOnCountdownEndListener;
    this.inflater = LayoutInflater.from(this.context);
  }

  private void dealWithLifeCycle(ViewHolder paramViewHolder)
  {
    paramViewHolder.single_course_info.getEnergy_course_countdown_view().addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(paramViewHolder)
    {
      public void onViewAttachedToWindow(View paramView)
      {
      }

      public void onViewDetachedFromWindow(View paramView)
      {
        try
        {
          Find02AllCourseAdapter.ViewHolder.access$600(this.val$holder).stopCountDown();
          return;
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
        }
      }
    });
  }

  private void initControl(View paramView, ViewHolder paramViewHolder)
  {
    ViewHolder.access$402(paramViewHolder, paramView.findViewById(R.id.split_line01));
    ViewHolder.access$302(paramViewHolder, (TextView)paramView.findViewById(R.id.course_title));
    ViewHolder.access$502(paramViewHolder, (PlanTrainUnJoinView)paramView.findViewById(R.id.course_info));
    ViewHolder.access$602(paramViewHolder, (SinglePlanTrainView)paramView.findViewById(R.id.single_course_info));
    ViewHolder.access$202(paramViewHolder, paramView.findViewById(R.id.space_view));
    ViewHolder.access$102(paramViewHolder, paramView.findViewById(R.id.single_space_view));
  }

  private void initLayout(ViewHolder paramViewHolder, int paramInt, PlanModel paramPlanModel)
  {
    String str;
    if (paramInt == 0)
    {
      paramViewHolder.course_title.setVisibility(0);
      paramViewHolder.split_line.setVisibility(8);
      TextView localTextView = paramViewHolder.course_title;
      if (this.trainCount == 0)
      {
        str = this.context.getResources().getString(R.string.single_course_hint);
        localTextView.setText(str);
      }
    }
    while (true)
    {
      paramPlanModel.planImageURL = QiniuManager.getImgUrl(paramPlanModel.planImageURL, (int)(0.25D * BaseApplication.screenWidth));
      if (paramInt >= this.trainCount)
        break label179;
      paramViewHolder.course_info.setVisibility(0);
      paramViewHolder.single_course_info.setVisibility(8);
      paramViewHolder.course_info.initView(paramPlanModel);
      return;
      str = this.context.getResources().getString(R.string.more_train_hint);
      break;
      if (this.trainCount == paramInt)
      {
        paramViewHolder.course_title.setVisibility(0);
        paramViewHolder.course_title.setText(this.context.getResources().getString(R.string.single_course_hint));
        continue;
      }
      paramViewHolder.course_title.setVisibility(8);
    }
    label179: paramViewHolder.split_line.setVisibility(0);
    paramViewHolder.course_info.setVisibility(8);
    paramViewHolder.single_course_info.setVisibility(0);
    paramViewHolder.single_course_info.initView(paramPlanModel, 0);
    paramViewHolder.single_course_info.setCourseStyleBold();
    try
    {
      paramViewHolder.single_course_info.setCountDownTime((PlanModel)this.dataList.get(paramInt), this.cListener);
      dealWithLifeCycle(paramViewHolder);
      return;
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
  }

  private void onItemClickAction(ViewHolder paramViewHolder, PlanModel paramPlanModel, int paramInt)
  {
    paramViewHolder.course_info.setOnClickListener(new FitAction(null, paramPlanModel, paramInt)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        String str1 = this.val$planModel.planId;
        String str2 = SharePreferenceUtils.getLoginStatus(Find02AllCourseAdapter.this.context);
        Intent localIntent;
        if ("0".equals(this.val$planModel.trainType))
        {
          localIntent = new Intent(Find02AllCourseAdapter.this.context, Find04GenTrainInfoActivity.class);
          localIntent.putExtra("single.type", "0");
          localIntent.putExtra("plan.id", str1);
        }
        while (true)
        {
          Find02AllCourseAdapter.this.context.startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)Find02AllCourseAdapter.this.context, 0);
          if (Find02AllCourseAdapter.this.saveListener != null)
            Find02AllCourseAdapter.this.saveListener.onSaveSearchWords();
          super.onClick(paramView);
          return;
          if ((StringUtils.isNull(this.val$planModel.planStateCode)) || ((("0".equals(this.val$planModel.planStateCode)) || ("2".equals(this.val$planModel.planStateCode))) && ("login".equals(str2))))
          {
            localIntent = new Intent(Find02AllCourseAdapter.this.context, Find03GenTrainListActivity.class);
            localIntent.putExtra("plan.id", str1);
            localIntent.putExtra("position", String.valueOf(this.val$position));
            continue;
          }
          localIntent = new Intent(Find02AllCourseAdapter.this.context, Find04GenTrainInfoActivity.class);
          localIntent.putExtra("plan.id", str1);
          localIntent.putExtra("position", String.valueOf(this.val$position));
        }
      }
    });
    paramViewHolder.single_course_info.setOnClickListener(new FitAction(null, paramPlanModel)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(Find02AllCourseAdapter.this.context, Find04GenTrainInfoActivity.class);
        localIntent.putExtra("single.type", "0");
        localIntent.putExtra("plan.id", this.val$planModel.planId);
        Find02AllCourseAdapter.this.context.startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)Find02AllCourseAdapter.this.context, 0);
        if (Find02AllCourseAdapter.this.saveListener != null)
          Find02AllCourseAdapter.this.saveListener.onSaveSearchWords();
        super.onClick(paramView);
      }
    });
  }

  public int getCount()
  {
    return this.dataList.size();
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    View localView;
    int k;
    if (paramView == null)
    {
      localViewHolder = new ViewHolder(null);
      paramView = this.inflater.inflate(R.layout.find02_all_course_item, null);
      initControl(paramView, localViewHolder);
      paramView.setTag(localViewHolder);
      PlanModel localPlanModel = (PlanModel)this.dataList.get(paramInt);
      initLayout(localViewHolder, paramInt, localPlanModel);
      onItemClickAction(localViewHolder, localPlanModel, paramInt);
      if ((this.trainCount <= 0) || (paramInt >= this.trainCount))
        break label152;
      localViewHolder.single_space_view.setVisibility(8);
      localView = localViewHolder.space_view;
      int i = paramInt + 1;
      int j = this.trainCount;
      k = 0;
      if (i == j)
        break label145;
    }
    while (true)
    {
      localView.setVisibility(k);
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
      break;
      label145: k = 8;
    }
    label152: localViewHolder.space_view.setVisibility(8);
    localViewHolder.single_space_view.setVisibility(0);
    return paramView;
  }

  public void setDataList(ArrayList<PlanModel> paramArrayList)
  {
    this.dataList = paramArrayList;
  }

  public static abstract interface OnSaveSearchWordsListener
  {
    public abstract void onSaveSearchWords();
  }

  private class ViewHolder
  {
    private PlanTrainUnJoinView course_info;
    private TextView course_title;
    private SinglePlanTrainView single_course_info;
    private View single_space_view;
    private View space_view;
    private View split_line;

    private ViewHolder()
    {
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.Find02AllCourseAdapter
 * JD-Core Version:    0.6.0
 */