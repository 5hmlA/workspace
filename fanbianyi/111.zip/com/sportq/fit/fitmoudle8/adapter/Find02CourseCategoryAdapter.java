package com.sportq.fit.fitmoudle8.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.View;
import android.widget.TextView;
import cn.iwgang.countdownview.CountdownView.OnCountdownEndListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseFitAdapter;
import com.sportq.fit.fitmoudle.widget.PlanTrainUnJoinView;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.List;
import org.byteam.superadapter.SuperViewHolder;

public class Find02CourseCategoryAdapter extends BaseFitAdapter
{
  private Context aContext;
  private ArrayList<PlanModel> dataList;
  private CountdownView.OnCountdownEndListener mListener;
  private ArrayList<PlanModel> planList;

  public Find02CourseCategoryAdapter(Context paramContext, CountdownView.OnCountdownEndListener paramOnCountdownEndListener, List paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
    this.aContext = paramContext;
    this.mListener = paramOnCountdownEndListener;
  }

  private void singleTrainClickAction(SinglePlanTrainView paramSinglePlanTrainView, String paramString)
  {
    paramSinglePlanTrainView.setOnClickListener(new FitAction(this, paramString)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(Find02CourseCategoryAdapter.this.aContext, Find04GenTrainInfoActivity.class);
        localIntent.putExtra("single.type", "0");
        localIntent.putExtra("plan.id", this.val$strPlanId);
        Find02CourseCategoryAdapter.this.aContext.startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)Find02CourseCategoryAdapter.this.aContext, 0);
        super.onClick(paramView);
      }
    });
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, Object paramObject)
  {
    PlanTrainUnJoinView localPlanTrainUnJoinView = (PlanTrainUnJoinView)paramSuperViewHolder.findViewById(R.id.course_info);
    SinglePlanTrainView localSinglePlanTrainView = (SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.single_course_info);
    int i = this.planList.size();
    if (paramInt2 < i)
    {
      if (paramInt2 == 0)
      {
        paramSuperViewHolder.findViewById(R.id.course_title).setVisibility(0);
        ((TextView)paramSuperViewHolder.findViewById(R.id.course_title)).setText(this.aContext.getResources().getString(R.string.more_train_hint));
      }
      while (true)
      {
        paramSuperViewHolder.findViewById(R.id.split_line01).setVisibility(8);
        PlanModel localPlanModel2 = (PlanModel)this.planList.get(paramInt2);
        localPlanTrainUnJoinView.setVisibility(0);
        localSinglePlanTrainView.setVisibility(4);
        localPlanTrainUnJoinView.initView(localPlanModel2);
        localPlanTrainUnJoinView.setOnClickListener(new FitAction(this, localPlanModel2, paramInt2)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            String str = SharePreferenceUtils.getLoginStatus(Find02CourseCategoryAdapter.this.aContext);
            if ((("0".equals(this.val$planModel.planStateCode)) || ("2".equals(this.val$planModel.planStateCode))) && ("login".equals(str)))
            {
              Intent localIntent1 = new Intent(Find02CourseCategoryAdapter.this.aContext, Find03GenTrainListActivity.class);
              localIntent1.putExtra("plan.id", this.val$planModel.planId);
              localIntent1.putExtra("position", String.valueOf(this.val$position));
              localIntent1.putExtra("refresh.status", "refresh");
              localIntent1.putExtra("plan.stateCode", this.val$planModel.planStateCode);
              Find02CourseCategoryAdapter.this.aContext.startActivity(localIntent1);
              AnimationUtil.pageJumpAnim((Activity)Find02CourseCategoryAdapter.this.aContext, 0);
            }
            while (true)
            {
              super.onClick(paramView);
              return;
              Intent localIntent2 = new Intent(Find02CourseCategoryAdapter.this.aContext, Find04GenTrainInfoActivity.class);
              localIntent2.putExtra("plan.id", this.val$planModel.planId);
              localIntent2.putExtra("position", String.valueOf(this.val$position));
              Find02CourseCategoryAdapter.this.aContext.startActivity(localIntent2);
              AnimationUtil.pageJumpAnim((Activity)Find02CourseCategoryAdapter.this.aContext, 0);
            }
          }
        });
        if (paramInt2 != i - 1)
          paramSuperViewHolder.findViewById(R.id.space_view).setVisibility(0);
        paramSuperViewHolder.findViewById(R.id.single_space_view).setVisibility(8);
        return;
        paramSuperViewHolder.findViewById(R.id.course_title).setVisibility(8);
      }
    }
    if (paramInt2 == i)
    {
      paramSuperViewHolder.findViewById(R.id.course_title).setVisibility(0);
      ((TextView)paramSuperViewHolder.findViewById(R.id.course_title)).setText(this.aContext.getResources().getString(R.string.single_course_hint));
    }
    while (true)
    {
      localPlanTrainUnJoinView.setVisibility(8);
      localSinglePlanTrainView.setVisibility(0);
      PlanModel localPlanModel1 = (PlanModel)this.dataList.get(paramInt2 - i);
      localSinglePlanTrainView.initView(localPlanModel1, 0);
      localSinglePlanTrainView.setCourseStyleBold();
      singleTrainClickAction(localSinglePlanTrainView, localPlanModel1.planId);
      paramSuperViewHolder.findViewById(R.id.space_view).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.single_space_view).setVisibility(0);
      return;
      paramSuperViewHolder.findViewById(R.id.course_title).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.split_line01).setVisibility(0);
    }
  }

  public void onViewAttachedToWindow(SuperViewHolder paramSuperViewHolder)
  {
    int i = paramSuperViewHolder.getAdapterPosition();
    SinglePlanTrainView localSinglePlanTrainView = (SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.single_course_info);
    int j = this.planList.size();
    if (i >= j)
      localSinglePlanTrainView.setCountDownTime((PlanModel)this.dataList.get(i - j), this.mListener);
  }

  public void onViewDetachedFromWindow(SuperViewHolder paramSuperViewHolder)
  {
    try
    {
      SinglePlanTrainView localSinglePlanTrainView = (SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.single_course_info);
      if (localSinglePlanTrainView != null)
        localSinglePlanTrainView.stopCountDown();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void setDataList(ArrayList<PlanModel> paramArrayList)
  {
    this.dataList = paramArrayList;
  }

  public void setPlanList(ArrayList<PlanModel> paramArrayList)
  {
    this.planList = paramArrayList;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.Find02CourseCategoryAdapter
 * JD-Core Version:    0.6.0
 */