package com.sportq.fit.fitmoudle8.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView;
import com.sportq.fit.fitmoudle8.R.id;
import com.sportq.fit.fitmoudle8.R.string;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.fitmoudle8.widget.Find04TrainInfoTools.EquipmentItemClick;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class Find03NotAttendPlanTrainInfoAdapter extends SuperAdapter<PlanModel>
{
  private Find04TrainInfoTools.EquipmentItemClick equipmentItemClick;
  private Context mContext;
  private PlanReformer planReformer;
  private String planStateCode;

  public Find03NotAttendPlanTrainInfoAdapter(Context paramContext, List paramList, int paramInt, PlanReformer paramPlanReformer)
  {
    super(paramContext, paramList, paramInt);
    this.mContext = paramContext;
    this.planReformer = paramPlanReformer;
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, PlanModel paramPlanModel)
  {
    int i = 1;
    if (paramInt2 == i)
    {
      paramSuperViewHolder.findViewById(R.id.course_item).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.single_space_view).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.line02).setVisibility(8);
      if (!StringUtils.isNull(this.planReformer._planInfo.planApparatusName))
      {
        paramSuperViewHolder.findViewById(R.id.equipment_layout).setVisibility(0);
        paramSuperViewHolder.setText(R.id.equipment_text, this.planReformer._planInfo.planApparatusName);
        String str = SharePreferenceUtils.getEliminateComment();
        if ((!StringUtils.isNull(str)) && (str.contains(this.planReformer._planInfo.planApparatusName)))
        {
          paramSuperViewHolder.findViewById(R.id.icn_right_arrow).setVisibility(8);
          if (StringUtils.isNull(this.planReformer._planInfo.trainFrequency))
            break label247;
          paramSuperViewHolder.findViewById(R.id.train_frequency_layout).setVisibility(0);
          paramSuperViewHolder.setText(R.id.train_frequency, this.planReformer._planInfo.trainFrequency);
        }
      }
    }
    while (true)
    {
      paramSuperViewHolder.findViewById(R.id.course_item).setOnClickListener(new FitAction(null, paramPlanModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          paramView.setTag(StringUtils.stitchingUserEvent(Find03NotAttendPlanTrainInfoAdapter.this.mContext.getResources().getString(R.string.stats_b1_6_trainCell), this.val$planModel.olapInfo));
          Intent localIntent = new Intent(Find03NotAttendPlanTrainInfoAdapter.this.mContext, Find04GenTrainInfoActivity.class);
          localIntent.putExtra("single.type", "0");
          localIntent.putExtra("show.join.btn.flg", "hide");
          localIntent.putExtra("plan.id", this.val$planModel.planId);
          Find03NotAttendPlanTrainInfoAdapter.this.mContext.startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)Find03NotAttendPlanTrainInfoAdapter.this.mContext, 0);
          super.onClick(paramView);
        }
      });
      return;
      paramSuperViewHolder.findViewById(R.id.icn_right_arrow).setVisibility(0);
      paramSuperViewHolder.findViewById(R.id.equipment_layout).setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (Find03NotAttendPlanTrainInfoAdapter.this.equipmentItemClick != null)
            Find03NotAttendPlanTrainInfoAdapter.this.equipmentItemClick.equipItemClick();
        }
      });
      break;
      paramSuperViewHolder.findViewById(R.id.equipment_layout).setVisibility(8);
      break;
      label247: paramSuperViewHolder.findViewById(R.id.train_frequency_layout).setVisibility(8);
      continue;
      paramSuperViewHolder.findViewById(R.id.equipment_layout).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.train_frequency_layout).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.course_item).setVisibility(0);
      paramSuperViewHolder.findViewById(R.id.single_space_view).setVisibility(0);
      paramSuperViewHolder.findViewById(R.id.line02).setVisibility(0);
      SinglePlanTrainView localSinglePlanTrainView = (SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.course_item);
      if ("2".equals(this.planStateCode))
        i = 2;
      localSinglePlanTrainView.initView(paramPlanModel, i);
      ((SinglePlanTrainView)paramSuperViewHolder.findViewById(R.id.course_item)).setCourseStyleBold();
    }
  }

  public void setEquipmentItemClick(Find04TrainInfoTools.EquipmentItemClick paramEquipmentItemClick)
  {
    this.equipmentItemClick = paramEquipmentItemClick;
  }

  public void setPlanStateCode(String paramString)
  {
    this.planStateCode = paramString;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.adapter.Find03NotAttendPlanTrainInfoAdapter
 * JD-Core Version:    0.6.0
 */