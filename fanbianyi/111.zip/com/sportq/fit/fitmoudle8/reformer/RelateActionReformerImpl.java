package com.sportq.fit.fitmoudle8.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle8.reformer.model.RelateActionData;
import com.sportq.fit.fitmoudle8.reformer.reformer.RelateActionReformer;

public class RelateActionReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    RelateActionData localRelateActionData = (RelateActionData)paramBaseData;
    RelateActionReformer localRelateActionReformer = new RelateActionReformer();
    localRelateActionReformer.relateComment = localRelateActionData.relateComment;
    localRelateActionReformer.lstActGroup = localRelateActionData.lstActGroup;
    return localRelateActionReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (RelateActionData)FitGsonFactory.create().fromJson(paramString2, RelateActionData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.RelateActionReformerImpl
 * JD-Core Version:    0.6.0
 */