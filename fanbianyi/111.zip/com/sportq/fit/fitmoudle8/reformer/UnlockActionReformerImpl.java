package com.sportq.fit.fitmoudle8.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.reformer.model.UnlockActionData;
import com.sportq.fit.fitmoudle8.reformer.reformer.UnLockActionReformer;

public class UnlockActionReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    UnlockActionData localUnlockActionData = (UnlockActionData)paramBaseData;
    UnLockActionReformer localUnLockActionReformer = new UnLockActionReformer();
    if (!StringUtils.isNull(localUnlockActionData.endTime))
    {
      localUnLockActionReformer.result = "Y";
      localUnLockActionReformer.endTime = localUnlockActionData.endTime;
      return localUnLockActionReformer;
    }
    localUnLockActionReformer.entError = localUnlockActionData.entError;
    localUnLockActionReformer.result = localUnlockActionData.result;
    return localUnLockActionReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (UnlockActionData)FitGsonFactory.create().fromJson(paramString2, UnlockActionData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.UnlockActionReformerImpl
 * JD-Core Version:    0.6.0
 */