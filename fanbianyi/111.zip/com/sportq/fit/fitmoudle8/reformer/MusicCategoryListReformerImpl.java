package com.sportq.fit.fitmoudle8.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle8.reformer.model.MusicData;
import com.sportq.fit.fitmoudle8.reformer.model.MusicModel;
import com.sportq.fit.fitmoudle8.reformer.reformer.MusicReformer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class MusicCategoryListReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    MusicData localMusicData = (MusicData)paramBaseData;
    MusicReformer localMusicReformer = new MusicReformer();
    if ((localMusicData.lstMusicCategory != null) && (localMusicData.lstMusicCategory.size() != 0))
    {
      ArrayList localArrayList = new ArrayList();
      Iterator localIterator = localMusicData.lstMusicCategory.iterator();
      while (localIterator.hasNext())
      {
        MusicModel localMusicModel1 = (MusicModel)localIterator.next();
        MusicModel localMusicModel2 = new MusicModel();
        localMusicModel2.categoryId = localMusicModel1.categoryId;
        localMusicModel2.imageURL = localMusicModel1.imageURL;
        localMusicModel2.categoryName = localMusicModel1.categoryName;
        localMusicModel2.olapInfo = localMusicModel1.olapInfo;
        localArrayList.add(localMusicModel2);
      }
      localMusicReformer.lstMusicCategory = localArrayList;
    }
    return localMusicReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    MusicData localMusicData = (MusicData)FitGsonFactory.create().fromJson(paramString2, MusicData.class);
    BaseApplication.dataCache.put(paramString1, localMusicData);
    return dataToReformer(paramString1, localMusicData, paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.MusicCategoryListReformerImpl
 * JD-Core Version:    0.6.0
 */