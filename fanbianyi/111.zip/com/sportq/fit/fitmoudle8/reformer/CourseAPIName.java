package com.sportq.fit.fitmoudle8.reformer;

public class CourseAPIName
{
  private static final String API_PREFIX = "/SFitWeb/sfit/";

  public static String getAPIName(ApiEnum paramApiEnum)
  {
    switch (1.$SwitchMap$com$sportq$fit$fitmoudle8$reformer$CourseAPIName$ApiEnum[paramApiEnum.ordinal()])
    {
    default:
      return "";
    case 1:
      return "/SFitWeb/sfit/getHotSearchWords";
    case 2:
      return "/SFitWeb/sfit/searchCourseByKey";
    case 3:
      return "/SFitWeb/sfit/getMusicCategoryList";
    case 4:
    }
    return "/SFitWeb/sfit/getMusicList";
  }

  public static enum ApiEnum
  {
    static
    {
      GET_MUSIC_LIST = new ApiEnum("GET_MUSIC_LIST", 2);
      GET_MUSIC_CATEGORY_LIST = new ApiEnum("GET_MUSIC_CATEGORY_LIST", 3);
      ApiEnum[] arrayOfApiEnum = new ApiEnum[4];
      arrayOfApiEnum[0] = GET_HOT_SEARCH_WORDS;
      arrayOfApiEnum[1] = SEARCH_COURSE_BY_KEY;
      arrayOfApiEnum[2] = GET_MUSIC_LIST;
      arrayOfApiEnum[3] = GET_MUSIC_CATEGORY_LIST;
      $VALUES = arrayOfApiEnum;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.CourseAPIName
 * JD-Core Version:    0.6.0
 */