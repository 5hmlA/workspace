package com.sportq.fit.fitmoudle8.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle8.reformer.model.HotWordsData;
import com.sportq.fit.fitmoudle8.reformer.model.HotWordsModel;
import com.sportq.fit.fitmoudle8.reformer.reformer.HotWordsReformer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class HotSearchWordsReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    HotWordsData localHotWordsData = (HotWordsData)paramBaseData;
    HotWordsReformer localHotWordsReformer = new HotWordsReformer();
    if ((localHotWordsData.lstHotWords != null) && (localHotWordsData.lstHotWords.size() > 0))
    {
      ArrayList localArrayList = new ArrayList();
      Iterator localIterator = localHotWordsData.lstHotWords.iterator();
      while (localIterator.hasNext())
      {
        HotWordsModel localHotWordsModel1 = (HotWordsModel)localIterator.next();
        HotWordsModel localHotWordsModel2 = new HotWordsModel();
        localHotWordsModel2.wordId = localHotWordsModel1.wordId;
        localHotWordsModel2.wordName = localHotWordsModel1.wordName;
        localHotWordsModel2.olapInfo = localHotWordsModel1.olapInfo;
        localArrayList.add(localHotWordsModel2);
      }
      localHotWordsReformer.hotWordsList = localArrayList;
    }
    return localHotWordsReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    HotWordsData localHotWordsData = (HotWordsData)FitGsonFactory.create().fromJson(paramString2, HotWordsData.class);
    BaseApplication.dataCache.put(paramString1, localHotWordsData);
    return dataToReformer(paramString1, localHotWordsData, paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.HotSearchWordsReformerImpl
 * JD-Core Version:    0.6.0
 */