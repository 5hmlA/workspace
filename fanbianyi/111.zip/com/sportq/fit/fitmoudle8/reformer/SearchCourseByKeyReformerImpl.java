package com.sportq.fit.fitmoudle8.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.reformer.model.CourseBySearchModel;
import com.sportq.fit.fitmoudle8.reformer.model.SearchCourseByKeyData;
import com.sportq.fit.fitmoudle8.reformer.reformer.SearchCourseByKeyReformer;
import com.sportq.fit.uicommon.R.string;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

public class SearchCourseByKeyReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    SearchCourseByKeyData localSearchCourseByKeyData = (SearchCourseByKeyData)paramBaseData;
    SearchCourseByKeyReformer localSearchCourseByKeyReformer = new SearchCourseByKeyReformer();
    if ((localSearchCourseByKeyData.lstTraint != null) && (localSearchCourseByKeyData.lstTraint.size() != 0))
    {
      ArrayList localArrayList1 = new ArrayList();
      ArrayList localArrayList2 = new ArrayList();
      Iterator localIterator = localSearchCourseByKeyData.lstTraint.iterator();
      while (localIterator.hasNext())
      {
        CourseBySearchModel localCourseBySearchModel = (CourseBySearchModel)localIterator.next();
        PlanModel localPlanModel = new PlanModel();
        localPlanModel.planId = localCourseBySearchModel.planId;
        localPlanModel.type = localCourseBySearchModel.type;
        localPlanModel.planName = localCourseBySearchModel.planName;
        localPlanModel.difficultyLevel = localCourseBySearchModel.difficultyLevel;
        localPlanModel.planNumberOfParticipants = (localCourseBySearchModel.numberOfParticipants + "人");
        localPlanModel.trainDuration = localCourseBySearchModel.trainDuration;
        localPlanModel.stateCode = localCourseBySearchModel.stateCode;
        localPlanModel.calorie = localCourseBySearchModel.calorie;
        localPlanModel.isNewTag = localCourseBySearchModel.isNewTag;
        localPlanModel.isUpdate = localCourseBySearchModel.isUpdate;
        localPlanModel.apparatus = localCourseBySearchModel.apparatus;
        localPlanModel.planImageURL = localCourseBySearchModel.imageURL;
        localPlanModel.olapInfo = localCourseBySearchModel.olapInfo;
        localPlanModel.energyFlag = localCourseBySearchModel.energyFlag;
        localPlanModel.effectTime = localCourseBySearchModel.effectTime;
        if ("0".equals(localCourseBySearchModel.type))
        {
          StringBuilder localStringBuilder2 = new StringBuilder().append(localCourseBySearchModel.trainDuration).append(StringUtils.getStringResources(R.string.min_hint)).append(" • ");
          String str2 = "%s" + StringUtils.getStringResources(R.string.kilocalorie);
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = localCourseBySearchModel.calorie;
          localPlanModel.courseInfo = (String.format(str2, arrayOfObject) + " • " + StringUtils.difficultyLevel(localCourseBySearchModel.difficultyLevel));
          localArrayList2.add(localPlanModel);
          continue;
        }
        StringBuilder localStringBuilder1 = new StringBuilder().append(localCourseBySearchModel.trainDuration).append(StringUtils.getStringResources(R.string.min_hint)).append(" • ").append(StringUtils.difficultyLevel(localCourseBySearchModel.difficultyLevel));
        if (StringUtils.isNull(localCourseBySearchModel.apparatus));
        for (String str1 = ""; ; str1 = " • " + localCourseBySearchModel.apparatus)
        {
          localPlanModel.courseInfo = str1;
          localArrayList1.add(localPlanModel);
          break;
        }
      }
      localSearchCourseByKeyReformer.singleTrainList = localArrayList2;
      localSearchCourseByKeyReformer.trainList = localArrayList1;
    }
    return localSearchCourseByKeyReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    Gson localGson = FitGsonFactory.create();
    try
    {
      JSONArray localJSONArray = new JSONObject(paramString2).optJSONArray("lstTraint");
      if ((localJSONArray != null) && (localJSONArray.length() > 0))
      {
        SearchCourseByKeyData localSearchCourseByKeyData = (SearchCourseByKeyData)localGson.fromJson(paramString2, SearchCourseByKeyData.class);
        BaseApplication.dataCache.put(paramString1, localSearchCourseByKeyData);
        return dataToReformer(paramString1, localSearchCourseByKeyData, false);
      }
      SearchCourseByKeyReformer localSearchCourseByKeyReformer = new SearchCourseByKeyReformer();
      return localSearchCourseByKeyReformer;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return new SearchCourseByKeyReformer();
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.SearchCourseByKeyReformerImpl
 * JD-Core Version:    0.6.0
 */