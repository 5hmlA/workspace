package com.sportq.fit.fitmoudle8.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle8.reformer.model.MusicData;
import com.sportq.fit.fitmoudle8.reformer.model.MusicModel;
import com.sportq.fit.fitmoudle8.reformer.reformer.MusicReformer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class MusicListReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    MusicData localMusicData = (MusicData)paramBaseData;
    MusicReformer localMusicReformer = new MusicReformer();
    MusicModel localMusicModel1 = new MusicModel();
    localMusicModel1.categoryId = localMusicData.entMusicCategory.categoryId;
    localMusicModel1.categoryName = localMusicData.entMusicCategory.categoryName;
    localMusicModel1.imageURL = localMusicData.entMusicCategory.imageURL;
    localMusicModel1.olapInfo = localMusicData.entMusicCategory.olapInfo;
    localMusicReformer.entMusicCategory = localMusicModel1;
    ArrayList localArrayList = new ArrayList();
    if ((localMusicData.lstMusic != null) && (localMusicData.lstMusic.size() > 0))
    {
      Iterator localIterator = localMusicData.lstMusic.iterator();
      while (localIterator.hasNext())
      {
        MusicModel localMusicModel2 = (MusicModel)localIterator.next();
        MusicModel localMusicModel3 = new MusicModel();
        localMusicModel3.musicId = localMusicModel2.musicId;
        localMusicModel3.musicName = localMusicModel2.musicName;
        localMusicModel3.musicURL = localMusicModel2.musicURL;
        localMusicModel3.musicSize = localMusicModel2.musicSize;
        localMusicModel3.isVip = localMusicModel2.isVip;
        localMusicModel3.auditionURL = localMusicModel2.auditionURL;
        localMusicModel3.olapInfo = localMusicModel2.olapInfo;
        localArrayList.add(localMusicModel3);
      }
      localMusicReformer.lstMusic = localArrayList;
    }
    return localMusicReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    MusicData localMusicData = (MusicData)FitGsonFactory.create().fromJson(paramString2, MusicData.class);
    BaseApplication.dataCache.put(paramString1, localMusicData);
    return dataToReformer(paramString1, localMusicData, paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.MusicListReformerImpl
 * JD-Core Version:    0.6.0
 */