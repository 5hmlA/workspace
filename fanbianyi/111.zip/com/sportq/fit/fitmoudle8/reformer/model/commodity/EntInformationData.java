package com.sportq.fit.fitmoudle8.reformer.model.commodity;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;

public class EntInformationData extends BaseData
  implements Serializable
{
  public String actType;
  public String brandCode;
  public String fitPrice;
  public String inventoryInstr;
  public String isSale;
  public String limitNumber;
  public String olapInfo;
  public String ordNumber;
  public String price;
  public String proCode;
  public String proName;
  public String proState;
  public String proUrl;
  public String protypeCode;
  public String sale;
  public String saleComment;

  public boolean hasAct()
  {
    return "1".equals(this.actType);
  }

  public boolean isSale()
  {
    return "1".equals(this.isSale);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.commodity.EntInformationData
 * JD-Core Version:    0.6.0
 */