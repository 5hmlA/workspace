package com.sportq.fit.fitmoudle8.reformer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;

public class UnlockActionData extends BaseData
  implements Serializable
{
  public String endTime;
  public ErrorModel entError;
  public String message;
  public String result;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.UnlockActionData
 * JD-Core Version:    0.6.0
 */