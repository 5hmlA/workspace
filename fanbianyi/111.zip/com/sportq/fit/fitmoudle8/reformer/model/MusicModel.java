package com.sportq.fit.fitmoudle8.reformer.model;

public class MusicModel
{
  public String auditionURL;
  public String categoryId;
  public String categoryName;
  public int downLoadPro;
  public int down_num;
  public String imageURL;
  public String isVip;
  public String musicId;
  public String musicName;
  public String musicSize;
  public String musicType;
  public String musicURL;
  public String olapInfo;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.MusicModel
 * JD-Core Version:    0.6.0
 */