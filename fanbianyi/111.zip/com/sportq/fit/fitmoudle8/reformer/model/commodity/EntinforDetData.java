package com.sportq.fit.fitmoudle8.reformer.model.commodity;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;
import java.util.ArrayList;

public class EntinforDetData extends BaseData
  implements Serializable
{
  public String endTime;
  public EntInformationData entInformation;
  public EntprostandInfoData entprostandInfo;
  public ArrayList<EntserInfoData> lstService;
  public ArrayList<String> lstimageUrl;
  public String proArgs;
  public String proDetail;
  public String proInstr;
  public String provideoInstr;
  public String provideoUrl;
  public String saleMax;
  public String saleScale;
  public String startTime;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.commodity.EntinforDetData
 * JD-Core Version:    0.6.0
 */