package com.sportq.fit.fitmoudle8.reformer.model.commodity;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;
import java.util.ArrayList;

public class EntcolorInfoData extends BaseData
  implements Serializable
{
  public String colorCode;
  public String colorComment;
  public String imgURL;
  public ArrayList<String> lstsizeCode;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.commodity.EntcolorInfoData
 * JD-Core Version:    0.6.0
 */