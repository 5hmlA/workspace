package com.sportq.fit.fitmoudle8.reformer.model;

public class CourseBySearchModel
{
  public String apparatus;
  public String calorie;
  public String difficultyLevel;
  public String effectTime;
  public String energyFlag;
  public String imageURL;
  public String isNewTag;
  public String isUpdate;
  public String numberOfParticipants;
  public String olapInfo;
  public String planId;
  public String planName;
  public String stateCode;
  public String trainDuration;
  public String type;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.CourseBySearchModel
 * JD-Core Version:    0.6.0
 */