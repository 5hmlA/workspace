package com.sportq.fit.fitmoudle8.reformer.model.commodity;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;
import java.util.ArrayList;

public class EntsizeInfoData extends BaseData
  implements Serializable
{
  public ArrayList<String> lstcolorCode;
  public String sizeCode;
  public String sizeComment;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.commodity.EntsizeInfoData
 * JD-Core Version:    0.6.0
 */