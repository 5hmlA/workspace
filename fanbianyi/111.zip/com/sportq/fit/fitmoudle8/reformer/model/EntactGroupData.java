package com.sportq.fit.fitmoudle8.reformer.model;

import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import java.io.Serializable;
import java.util.ArrayList;

public class EntactGroupData extends BaseData
  implements Serializable
{
  public String groupName;
  public ArrayList<ResponseModel.ActionData> lstActDetInfo;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.EntactGroupData
 * JD-Core Version:    0.6.0
 */