package com.sportq.fit.fitmoudle8.reformer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;
import java.util.ArrayList;

public class EntactClassifyData extends BaseData
  implements Serializable
{
  public String endTime;
  public ArrayList<EntactClassifyInfoData> lstActClassifyInfo;
  public String unlockValue;
  public String useComment;
  public String useDay;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.EntactClassifyData
 * JD-Core Version:    0.6.0
 */