package com.sportq.fit.fitmoudle8.reformer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;

public class EntactClassifyInfoData extends BaseData
  implements Serializable
{
  public String actClassifyId;
  public String actClassifyImg;
  public String actClassifyName;
  public String olapInfo;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.EntactClassifyInfoData
 * JD-Core Version:    0.6.0
 */