package com.sportq.fit.fitmoudle8.reformer.model;

import java.io.Serializable;

public class ErrorModel
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  public String errorCode;
  public String errorMessage;
  public String errorType;
  public String errtruth;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.model.ErrorModel
 * JD-Core Version:    0.6.0
 */