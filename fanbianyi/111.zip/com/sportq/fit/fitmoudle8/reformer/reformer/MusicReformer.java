package com.sportq.fit.fitmoudle8.reformer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle8.reformer.model.MusicModel;
import java.io.Serializable;
import java.util.ArrayList;

public class MusicReformer extends BaseReformer
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  public MusicModel entMusicCategory;
  public ArrayList<MusicModel> lstMusic;
  public ArrayList<MusicModel> lstMusicCategory;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.reformer.MusicReformer
 * JD-Core Version:    0.6.0
 */