package com.sportq.fit.fitmoudle8.reformer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle8.reformer.model.HotWordsModel;
import java.io.Serializable;
import java.util.ArrayList;

public class HotWordsReformer extends BaseReformer
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  public ArrayList<HotWordsModel> hotWordsList;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.reformer.HotWordsReformer
 * JD-Core Version:    0.6.0
 */