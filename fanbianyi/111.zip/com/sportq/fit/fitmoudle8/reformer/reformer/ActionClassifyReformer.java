package com.sportq.fit.fitmoudle8.reformer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle8.reformer.model.EntactClassifyInfoData;
import java.util.ArrayList;

public class ActionClassifyReformer extends BaseReformer
{
  public String endTime;
  public ArrayList<EntactClassifyInfoData> lstActClassifyInfo;
  public String unlockValue;
  public String useComment;
  public String useDay;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.reformer.ActionClassifyReformer
 * JD-Core Version:    0.6.0
 */