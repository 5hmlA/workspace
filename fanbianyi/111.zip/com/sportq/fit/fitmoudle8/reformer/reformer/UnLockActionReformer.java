package com.sportq.fit.fitmoudle8.reformer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle8.reformer.model.ErrorModel;

public class UnLockActionReformer extends BaseReformer
{
  public String endTime;
  public ErrorModel entError;
  public String message;
  public String result;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.reformer.UnLockActionReformer
 * JD-Core Version:    0.6.0
 */