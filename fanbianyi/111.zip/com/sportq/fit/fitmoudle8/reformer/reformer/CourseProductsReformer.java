package com.sportq.fit.fitmoudle8.reformer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle8.reformer.model.commodity.EntInformationData;
import com.sportq.fit.fitmoudle8.reformer.model.commodity.EntinforDetData;
import java.util.ArrayList;

public class CourseProductsReformer extends BaseReformer
{
  public EntinforDetData entinforDet;
  public ArrayList<EntInformationData> lstPro;
  public String strJson;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.reformer.CourseProductsReformer
 * JD-Core Version:    0.6.0
 */