package com.sportq.fit.fitmoudle8.reformer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import java.util.ArrayList;

public class SearchActionReformer extends BaseReformer
{
  public ArrayList<ResponseModel.ActionData> lstActDetInfo;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.reformer.SearchActionReformer
 * JD-Core Version:    0.6.0
 */