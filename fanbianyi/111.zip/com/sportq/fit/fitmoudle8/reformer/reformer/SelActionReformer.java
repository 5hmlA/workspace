package com.sportq.fit.fitmoudle8.reformer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.model.ScreenModel;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import com.sportq.fit.fitmoudle8.reformer.model.SelActionData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SelActionReformer extends BaseReformer
{
  public ArrayList<ArrayList<ScreenModel>> _screenArray;
  public Map<String, String> _screenDic;
  public ArrayList<ResponseModel.ActionData> lstActDetInfo;
  public ArrayList<ScreenModel> lstApparatus;
  public ArrayList<ScreenModel> lstDifficultyLevel;
  public ArrayList<ScreenModel> lstGoal;
  public String strActId;
  public String strFlg;

  private ArrayList<ScreenModel> makeScreenData(ArrayList<ScreenModel> paramArrayList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
    {
      ScreenModel localScreenModel1 = (ScreenModel)localIterator.next();
      ScreenModel localScreenModel2 = new ScreenModel();
      localScreenModel2.code = localScreenModel1.code;
      localScreenModel2.name = localScreenModel1.name;
      localScreenModel2.olapInfo = localScreenModel1.olapInfo;
      localArrayList.add(localScreenModel2);
    }
    return localArrayList;
  }

  public void convertReformer(SelActionData paramSelActionData)
  {
    if ("1".equals(this.strFlg))
      return;
    this._screenDic = new HashMap();
    this._screenDic.put("0", "0");
    this._screenDic.put("0", "1");
    this._screenDic.put("0", "2");
    this._screenDic.put("0", "3");
    this._screenArray = new ArrayList();
    this._screenArray.add(makeScreenData(paramSelActionData.lstApparatus));
    this._screenArray.add(makeScreenData(paramSelActionData.lstDifficultyLevel));
    this._screenArray.add(new ArrayList());
    this._screenArray.add(makeScreenData(paramSelActionData.lstGoal));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.reformer.SelActionReformer
 * JD-Core Version:    0.6.0
 */