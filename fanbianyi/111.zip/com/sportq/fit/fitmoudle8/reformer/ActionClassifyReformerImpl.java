package com.sportq.fit.fitmoudle8.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle8.reformer.model.EntClassifyData;
import com.sportq.fit.fitmoudle8.reformer.model.EntactClassifyData;
import com.sportq.fit.fitmoudle8.reformer.reformer.ActionClassifyReformer;

public class ActionClassifyReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    EntClassifyData localEntClassifyData = (EntClassifyData)paramBaseData;
    ActionClassifyReformer localActionClassifyReformer = new ActionClassifyReformer();
    localActionClassifyReformer.endTime = localEntClassifyData.entActClassify.endTime;
    localActionClassifyReformer.lstActClassifyInfo = localEntClassifyData.entActClassify.lstActClassifyInfo;
    localActionClassifyReformer.unlockValue = localEntClassifyData.entActClassify.unlockValue;
    localActionClassifyReformer.useComment = localEntClassifyData.entActClassify.useComment;
    localActionClassifyReformer.useDay = localEntClassifyData.entActClassify.useDay;
    return localActionClassifyReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (EntClassifyData)FitGsonFactory.create().fromJson(paramString2, EntClassifyData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.ActionClassifyReformerImpl
 * JD-Core Version:    0.6.0
 */