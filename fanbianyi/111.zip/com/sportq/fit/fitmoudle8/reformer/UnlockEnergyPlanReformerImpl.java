package com.sportq.fit.fitmoudle8.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.reformer.model.UnLockEnergyData;
import com.sportq.fit.fitmoudle8.reformer.reformer.UnLockEnergyPlanReformer;

public class UnlockEnergyPlanReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    UnLockEnergyData localUnLockEnergyData = (UnLockEnergyData)paramBaseData;
    UnLockEnergyPlanReformer localUnLockEnergyPlanReformer = new UnLockEnergyPlanReformer();
    localUnLockEnergyPlanReformer.message = localUnLockEnergyData.message;
    localUnLockEnergyPlanReformer.result = localUnLockEnergyData.result;
    return localUnLockEnergyPlanReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    Gson localGson = FitGsonFactory.create();
    UnLockEnergyData localUnLockEnergyData;
    if (StringUtils.isNull(paramString2))
    {
      localUnLockEnergyData = new UnLockEnergyData();
      localUnLockEnergyData.result = "Y";
    }
    while (true)
    {
      return dataToReformer(paramString1, localUnLockEnergyData, paramBoolean);
      localUnLockEnergyData = (UnLockEnergyData)localGson.fromJson(paramString2, UnLockEnergyData.class);
    }
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.UnlockEnergyPlanReformerImpl
 * JD-Core Version:    0.6.0
 */