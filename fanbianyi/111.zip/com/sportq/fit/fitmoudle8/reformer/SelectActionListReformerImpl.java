package com.sportq.fit.fitmoudle8.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle8.reformer.model.SelActionData;
import com.sportq.fit.fitmoudle8.reformer.reformer.SelActionReformer;

public class SelectActionListReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    SelActionData localSelActionData = (SelActionData)paramBaseData;
    SelActionReformer localSelActionReformer = new SelActionReformer();
    localSelActionReformer.lstApparatus = localSelActionData.lstApparatus;
    localSelActionReformer.lstDifficultyLevel = localSelActionData.lstDifficultyLevel;
    localSelActionReformer.lstGoal = localSelActionData.lstGoal;
    localSelActionReformer.lstActDetInfo = localSelActionData.lstActDetInfo;
    localSelActionReformer.convertReformer(localSelActionData);
    return localSelActionReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (SelActionData)FitGsonFactory.create().fromJson(paramString2, SelActionData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.reformer.SelectActionListReformerImpl
 * JD-Core Version:    0.6.0
 */