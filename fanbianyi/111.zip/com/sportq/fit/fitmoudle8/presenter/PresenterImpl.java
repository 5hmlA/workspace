package com.sportq.fit.fitmoudle8.presenter;

import android.content.Context;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle8.reformer.ActionClassifyReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.CourseAPIName;
import com.sportq.fit.fitmoudle8.reformer.CourseAPIName.ApiEnum;
import com.sportq.fit.fitmoudle8.reformer.CourseProductsReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.HotSearchWordsReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.MusicCategoryListReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.MusicListReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.RelateActionReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.SearchCourseByKeyReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.SearchReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.SelectActionListReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.UnlockActionReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.UnlockEnergyPlanReformerImpl;
import com.sportq.fit.fitmoudle8.reformer.reformer.SelActionReformer;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;
import com.sportq.fit.supportlib.http.reformer.TypeListReformerImpl;
import java.util.HashMap;
import java.util.Map;
import rx.Observable;
import rx.Subscriber;

public class PresenterImpl
  implements PresenterInterface
{
  private ApiInterface apiInterface = new ApiImpl();
  private FitInterfaceUtils.UIInitListener listener;

  public PresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.listener = paramUIInitListener;
  }

  public void courseProducts(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      this.apiInterface.getHttp("/SFitMallWeb/fitmall/courseProducts", paramContext, this.listener, new CourseProductsReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("searchAction", localException);
    }
  }

  public void getActionClassify(Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetActClassify);
      this.apiInterface.getHttp(str, paramContext, this.listener, new ActionClassifyReformerImpl(), new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("getActionClassify", localException);
    }
  }

  public void getHotSearchWords(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new HotSearchWordsReformerImpl());
      String str = CourseAPIName.getAPIName(CourseAPIName.ApiEnum.GET_HOT_SEARCH_WORDS);
      this.apiInterface.getHttp(str, paramContext, this.listener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MedalPresenterImpl.getHotSearchWords", localException);
    }
  }

  public void getMusicLibraryInfo(Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new MusicCategoryListReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetMusicCategoryList);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetMusicCategoryList);
      this.apiInterface.getHttp(str, paramContext, this.listener, localReformerImpl, new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MedalPresenterImpl.getMusicLibraryInfo", localException);
    }
  }

  public void getMusicListInfo(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new MusicListReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetMusicList);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetMusicList);
      this.apiInterface.getHttp(str, paramContext, this.listener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MedalPresenterImpl.getMusicListInfo", localException);
    }
  }

  public void getPhyPlan(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetPhyPlan);
      this.apiInterface.getHttp(str, paramContext, this.listener, new TypeListReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("getPhyPlan", localException);
    }
  }

  public void getSelectedPlanDet(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new TypeListReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.getSelectedPlanDet);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.getSelectedPlanDet);
      this.apiInterface.getHttp(str, paramContext, this.listener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("AppPresenterImpl.getBrowseArticleList", localException);
    }
  }

  public void joinPlan(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.joinPlan(paramRequestModel, paramContext).subscribe(new Subscriber(paramRequestModel)
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (PresenterImpl.this.listener != null)
          PresenterImpl.this.listener.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (BaseApplication.requestModelCache != null)
          BaseApplication.requestModelCache.clear();
        if (BaseApplication.dataCache != null)
          BaseApplication.dataCache.clear();
        PlanRecommendReformer localPlanRecommendReformer = new PlanRecommendReformer();
        localPlanRecommendReformer.dataToPlanRecommendReformer(paramResponseModel);
        if ("1".equals(this.val$requestModel.flg));
        for (String str = "8"; ; str = "1")
        {
          localPlanRecommendReformer.tag = str;
          if (PresenterImpl.this.listener != null)
            PresenterImpl.this.listener.getDataSuccess(localPlanRecommendReformer);
          return;
        }
      }
    });
  }

  public void newestCourse(Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl();
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetNewPlan);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetNewPlan);
      this.apiInterface.getHttp(str, paramContext, this.listener, localReformerImpl, new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MedalPresenterImpl.newestCourse", localException);
    }
  }

  public void relateAction(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.RelateAction);
      this.apiInterface.getHttp(str, paramContext, this.listener, new RelateActionReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("searchAction", localException);
    }
  }

  public void searchAction(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.SearchAction);
      this.apiInterface.getHttp(str, paramContext, this.listener, new SearchReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("searchAction", localException);
    }
  }

  public void searchCourseByKey(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new SearchCourseByKeyReformerImpl());
      String str = CourseAPIName.getAPIName(CourseAPIName.ApiEnum.SEARCH_COURSE_BY_KEY);
      this.apiInterface.getHttp(str, paramContext, this.listener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MedalPresenterImpl.searchCourseByKey", localException);
    }
  }

  public void selectActionList(Context paramContext, SelActionReformer paramSelActionReformer)
  {
    try
    {
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.flg = paramSelActionReformer.strFlg;
      localRequestModel.actClassifyId = paramSelActionReformer.strActId;
      String str2;
      String str3;
      if ("1".equals(paramSelActionReformer.strFlg))
      {
        if (!StringUtils.isNull((String)paramSelActionReformer._screenDic.get("1")))
          break label216;
        str2 = "";
        if (str2.contains(","))
          str2 = str2.substring(0, -1 + str2.length());
        localRequestModel.apparatus = str2;
        if (!StringUtils.isNull((String)paramSelActionReformer._screenDic.get("2")))
          break label235;
        str3 = "";
        label115: if (str3.contains(","))
          str3 = str3.substring(0, -1 + str3.length());
        localRequestModel.dfficultyLevel = str3;
        if (!StringUtils.isNull((String)paramSelActionReformer._screenDic.get("3")))
          break label254;
      }
      label216: label235: label254: for (String str4 = ""; ; str4 = (String)paramSelActionReformer._screenDic.get("3"))
      {
        localRequestModel.goal = str4;
        String str1 = new ReformerImpl().getURL(EnumConstant.FitUrl.SelAction);
        this.apiInterface.getHttp(str1, paramContext, this.listener, new SelectActionListReformerImpl(), localRequestModel);
        return;
        str2 = (String)paramSelActionReformer._screenDic.get("1");
        break;
        str3 = (String)paramSelActionReformer._screenDic.get("2");
        break label115;
      }
    }
    catch (Exception localException)
    {
      FitAction.upload_e("selectActionList", localException);
    }
  }

  public void unlockAction(Context paramContext)
  {
    try
    {
      RequestModel localRequestModel = new RequestModel();
      String str1 = new ReformerImpl().getURL(EnumConstant.FitUrl.UnlockAction);
      String str2 = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + CompDeviceInfoUtils.getVersionCode() + SharePreferenceUtils.getUserDeviceId(BaseApplication.appliContext) + str1 + NdkUtils.getSignBaseUrl()).toUpperCase();
      localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + str2 + NdkUtils.getSignBaseUrl()).toUpperCase();
      this.apiInterface.getHttp(str1, paramContext, this.listener, new UnlockActionReformerImpl(), localRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("unlockAction", localException);
    }
  }

  public void unlockEnergyPlan(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new UnlockEnergyPlanReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.UnlockEnergyPlan);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.UnlockEnergyPlan);
      this.apiInterface.getHttp(str, paramContext, this.listener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("unlockEnergyPlan", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.presenter.PresenterImpl
 * JD-Core Version:    0.6.0
 */