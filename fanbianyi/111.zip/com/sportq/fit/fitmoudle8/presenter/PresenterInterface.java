package com.sportq.fit.fitmoudle8.presenter;

import android.content.Context;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle8.reformer.reformer.SelActionReformer;

public abstract interface PresenterInterface
{
  public abstract void courseProducts(Context paramContext, RequestModel paramRequestModel);

  public abstract void getActionClassify(Context paramContext);

  public abstract void getHotSearchWords(RequestModel paramRequestModel, Context paramContext);

  public abstract void getMusicLibraryInfo(Context paramContext);

  public abstract void getMusicListInfo(Context paramContext, RequestModel paramRequestModel);

  public abstract void getPhyPlan(Context paramContext, RequestModel paramRequestModel);

  public abstract void getSelectedPlanDet(Context paramContext, RequestModel paramRequestModel);

  public abstract void joinPlan(RequestModel paramRequestModel, Context paramContext);

  public abstract void newestCourse(Context paramContext);

  public abstract void relateAction(Context paramContext, RequestModel paramRequestModel);

  public abstract void searchAction(Context paramContext, RequestModel paramRequestModel);

  public abstract void searchCourseByKey(RequestModel paramRequestModel, Context paramContext);

  public abstract void selectActionList(Context paramContext, SelActionReformer paramSelActionReformer);

  public abstract void unlockAction(Context paramContext);

  public abstract void unlockEnergyPlan(Context paramContext, RequestModel paramRequestModel);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle8.presenter.PresenterInterface
 * JD-Core Version:    0.6.0
 */