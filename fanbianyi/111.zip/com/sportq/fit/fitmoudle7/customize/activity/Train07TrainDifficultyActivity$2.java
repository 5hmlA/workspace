package com.sportq.fit.fitmoudle7.customize.activity;

import android.view.View;
import android.widget.RelativeLayout.LayoutParams;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;

class Train07TrainDifficultyActivity$2
  implements Runnable
{
  public void run()
  {
    this.val$view.getLocationInWindow(Train07TrainDifficultyActivity.access$400(this.this$0));
    RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)Train07TrainDifficultyActivity.access$300(this.this$0).getLayoutParams();
    localLayoutParams.height = Train07TrainDifficultyActivity.access$500(this.this$0).getHeight();
    Train07TrainDifficultyActivity.access$300(this.this$0).setLayoutParams(localLayoutParams);
    Train07TrainDifficultyActivity.access$300(this.this$0).setX(Train07TrainDifficultyActivity.access$400(this.this$0)[0]);
    Train07TrainDifficultyActivity.access$300(this.this$0).setY(Train07TrainDifficultyActivity.access$400(this.this$0)[1] - CompDeviceInfoUtils.getStatusBarHeight(this.this$0));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.Train07TrainDifficultyActivity.2
 * JD-Core Version:    0.6.0
 */