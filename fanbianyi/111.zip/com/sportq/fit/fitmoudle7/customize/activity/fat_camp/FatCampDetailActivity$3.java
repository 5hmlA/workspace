package com.sportq.fit.fitmoudle7.customize.activity.fat_camp;

import android.content.DialogInterface;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;

class FatCampDetailActivity$3
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -2)
      FitJumpImpl.getInstance().settingJumpWebView(this.this$0, "", VersionUpdateCheck.WEB_ADDRESS + "h5/2017FatOrder?id=1");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampDetailActivity.3
 * JD-Core Version:    0.6.0
 */