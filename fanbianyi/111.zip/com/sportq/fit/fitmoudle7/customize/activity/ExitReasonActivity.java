package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.NoResultReformer;
import com.sportq.fit.fitmoudle7.customize.widget.CustomScrollView;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;

public class ExitReasonActivity extends BaseActivity
{
  private CustomPresenterImpl customPresenter;
  private RelativeLayout edit_layout;
  private TextView exit_btn;
  private EditText exit_edit_layout;
  private LinearLayout exit_reason_layout;
  private InputMethodManager inputManager;
  private String[] reasonList;
  private RelativeLayout relayout;
  private CustomScrollView scrollView;
  private ArrayList<View> selectView = new ArrayList();
  CustomToolBar toolbar;

  private int convertOfDip(Context paramContext, float paramFloat)
  {
    return (int)(0.5F + paramFloat * paramContext.getResources().getDisplayMetrics().density);
  }

  private void initData()
  {
    this.exit_reason_layout.setWeightSum(this.reasonList.length);
    for (int i = 0; i < this.reasonList.length; i++)
    {
      View localView = LayoutInflater.from(this).inflate(R.layout.exit_reason_item_layout, null);
      localView.setTag(this.reasonList[i].split("#")[1]);
      ((TextView)localView.findViewById(R.id.exit_reason_info)).setText(this.reasonList[i].split("#")[0]);
      RelativeLayout localRelativeLayout = (RelativeLayout)localView.findViewById(R.id.item_layout);
      ImageView localImageView = (ImageView)localView.findViewById(R.id.reason_check_box);
      localRelativeLayout.setTag("default");
      localRelativeLayout.setOnClickListener(new View.OnClickListener(localRelativeLayout, localImageView, localView)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if ("default".equals(this.val$item_layout.getTag()))
          {
            this.val$reason_img.setImageResource(R.mipmap.checkbox_selected);
            this.val$item_layout.setTag("selected");
            if (ExitReasonActivity.this.selectView.size() == 0)
            {
              ExitReasonActivity.this.selectView.add(this.val$view);
              if ((ExitReasonActivity.this.selectView.size() == 0) || (!"1".equals(String.valueOf(((View)ExitReasonActivity.this.selectView.get(0)).getTag()))))
                break label422;
              ExitReasonActivity.this.edit_layout.setVisibility(0);
              ExitReasonActivity.this.exit_btn.setVisibility(8);
              ExitReasonActivity.this.exit_edit_layout.setFocusable(true);
              ExitReasonActivity.this.exit_edit_layout.setFocusableInTouchMode(true);
              ExitReasonActivity.this.exit_edit_layout.requestFocus();
              ExitReasonActivity.this.inputManager.showSoftInput(ExitReasonActivity.this.exit_edit_layout, 0);
              RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(-1, ExitReasonActivity.this.convertOfDip(ExitReasonActivity.this, 125.0F));
              localLayoutParams.addRule(3, R.id.exit_reason_layout);
              ExitReasonActivity.this.edit_layout.setLayoutParams(localLayoutParams);
            }
          }
          while (true)
          {
            if (ExitReasonActivity.this.selectView.size() != 0)
              break label481;
            ExitReasonActivity.this.exit_btn.setBackgroundColor(ContextCompat.getColor(ExitReasonActivity.this, R.color.color_f7f7f7));
            ExitReasonActivity.this.exit_btn.setTextColor(ContextCompat.getColor(ExitReasonActivity.this, R.color.color_e6e6e6));
            ExitReasonActivity.this.exit_btn.setClickable(false);
            return;
            ((ImageView)((View)ExitReasonActivity.this.selectView.get(0)).findViewById(R.id.reason_check_box)).setImageResource(R.mipmap.checkbox_default);
            ((RelativeLayout)((View)ExitReasonActivity.this.selectView.get(0)).findViewById(R.id.item_layout)).setTag("default");
            ExitReasonActivity.this.selectView.clear();
            ExitReasonActivity.this.selectView.add(this.val$view);
            break;
            this.val$reason_img.setImageResource(R.mipmap.checkbox_default);
            this.val$item_layout.setTag("default");
            if (ExitReasonActivity.this.selectView.size() == 0)
              break;
            ExitReasonActivity.this.selectView.clear();
            break;
            label422: ExitReasonActivity.this.exit_edit_layout.setText("");
            ExitReasonActivity.this.edit_layout.setVisibility(4);
            ExitReasonActivity.this.exit_btn.setVisibility(0);
            ExitReasonActivity.this.inputManager.hideSoftInputFromWindow(ExitReasonActivity.this.exit_edit_layout.getWindowToken(), 0);
          }
          label481: ExitReasonActivity.this.exit_btn.setBackgroundColor(ContextCompat.getColor(ExitReasonActivity.this, R.color.color_dbb76a));
          ExitReasonActivity.this.exit_btn.setTextColor(ContextCompat.getColor(ExitReasonActivity.this, R.color.color_313131));
          ExitReasonActivity.this.exit_btn.setClickable(true);
        }
      });
      LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, convertOfDip(this, 50.0F));
      localLayoutParams.weight = 1.0F;
      this.exit_reason_layout.addView(localView, localLayoutParams);
    }
  }

  private void layoutChangeListener()
  {
    this.relayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener()
    {
      public void onGlobalLayout()
      {
        if (ExitReasonActivity.this.relayout.getRootView().getHeight() - ExitReasonActivity.this.relayout.getHeight() > BaseApplication.screenHeight / 3)
        {
          ExitReasonActivity.this.exit_btn.setVisibility(8);
          new Handler().post(new Runnable()
          {
            public void run()
            {
              ExitReasonActivity.this.scrollView.fullScroll(130);
            }
          });
          return;
        }
        ExitReasonActivity.this.exit_btn.setVisibility(0);
        if (ExitReasonActivity.this.selectView.size() == 0)
        {
          ExitReasonActivity.this.exit_btn.setBackgroundColor(ContextCompat.getColor(ExitReasonActivity.this, R.color.color_e6e6e6));
          ExitReasonActivity.this.exit_btn.setTextColor(ContextCompat.getColor(ExitReasonActivity.this, R.color.color_c8c8c8));
          ExitReasonActivity.this.exit_btn.setClickable(false);
          return;
        }
        ExitReasonActivity.this.exit_btn.setBackgroundColor(ContextCompat.getColor(ExitReasonActivity.this, R.color.color_dbb76a));
        ExitReasonActivity.this.exit_btn.setTextColor(ContextCompat.getColor(ExitReasonActivity.this, R.color.color_313131));
        ExitReasonActivity.this.exit_btn.setClickable(true);
      }
    });
  }

  public void fitOnClick(View paramView)
  {
    super.fitOnClick(paramView);
    if (paramView.getId() == R.id.exit_btn)
    {
      String str = ((View)this.selectView.get(0)).getTag().toString();
      this.dialog.createProgressDialog(this, getString(R.string.exiting_custom));
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.exitCode = str;
      localRequestModel.exitComment = this.exit_edit_layout.getText().toString();
      this.customPresenter = new CustomPresenterImpl(this);
      this.customPresenter.exitMonthCus(localRequestModel, this);
    }
    do
      return;
    while (paramView.getId() != R.id.exit_edit_layout);
    this.exit_btn.setVisibility(8);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if ((paramT instanceof NoResultReformer))
    {
      this.dialog.closeDialog();
      if ((!"0".equals(BaseApplication.userModel.cusTrainFlg)) || (!"20:00".equals(BaseApplication.userModel.cusTrainTime)))
      {
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.cusTrainFlg = "0";
        localRequestModel.cusTrainTime = "20:00";
        MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(localRequestModel, this);
      }
      EventBus.getDefault().post("exi_MonthCus");
      BaseApplication.userModel.orderf = "0";
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.exit_reason_layout);
    String[] arrayOfString1 = new String[8];
    arrayOfString1[0] = getString(R.string.exit_custom_reason1);
    arrayOfString1[1] = getString(R.string.exit_custom_reason2);
    arrayOfString1[2] = getString(R.string.exit_custom_reason3);
    arrayOfString1[3] = getString(R.string.exit_custom_reason4);
    arrayOfString1[4] = getString(R.string.exit_custom_reason5);
    arrayOfString1[5] = getString(R.string.exit_custom_reason6);
    arrayOfString1[6] = getString(R.string.exit_custom_reason7);
    arrayOfString1[7] = getString(R.string.exit_custom_reason8);
    this.reasonList = arrayOfString1;
    this.dialog = new DialogManager();
    this.inputManager = ((InputMethodManager)getSystemService("input_method"));
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    String[] arrayOfString2 = new String[8];
    arrayOfString2[0] = getString(R.string.exit_custom_reason1);
    arrayOfString2[1] = getString(R.string.exit_custom_reason2);
    arrayOfString2[2] = getString(R.string.exit_custom_reason3);
    arrayOfString2[3] = getString(R.string.exit_custom_reason4);
    arrayOfString2[4] = getString(R.string.exit_custom_reason5);
    arrayOfString2[5] = getString(R.string.exit_custom_reason6);
    arrayOfString2[6] = getString(R.string.exit_custom_reason7);
    arrayOfString2[7] = getString(R.string.exit_custom_reason8);
    this.reasonList = arrayOfString2;
    this.exit_reason_layout = ((LinearLayout)findViewById(R.id.exit_reason_layout));
    this.exit_btn = ((TextView)findViewById(R.id.exit_btn));
    this.edit_layout = ((RelativeLayout)findViewById(R.id.edit_layout));
    this.relayout = ((RelativeLayout)findViewById(R.id.relayout));
    this.exit_edit_layout = ((EditText)findViewById(R.id.exit_edit_layout));
    this.scrollView = ((CustomScrollView)findViewById(R.id.exit_scrollview));
    this.scrollView.setOnTouchListener(new View.OnTouchListener()
    {
      public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
      {
        ExitReasonActivity.this.inputManager.hideSoftInputFromWindow(ExitReasonActivity.this.exit_edit_layout.getWindowToken(), 0);
        return false;
      }
    });
    this.toolbar.setTitle(getString(R.string.exit_custom));
    this.toolbar.setNavIcon(R.mipmap.btn_close_black);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundResource(R.color.white);
    setSupportActionBar(this.toolbar);
    this.exit_btn.setOnClickListener(new FitAction(this));
    this.exit_edit_layout.setOnClickListener(new FitAction(this));
    initData();
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        if (paramString.length() > 200)
        {
          ExitReasonActivity.this.exit_edit_layout.setText(paramString.substring(0, 200));
          ExitReasonActivity.this.exit_edit_layout.setSelection(paramString.substring(0, 200).length());
        }
      }
    }
    , this.exit_edit_layout);
    this.exit_edit_layout.setOnTouchListener(new View.OnTouchListener()
    {
      public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
      {
        if (paramView.getId() == R.id.exit_edit_layout)
          paramView.getParent().requestDisallowInterceptTouchEvent(true);
        switch (0xFF & paramMotionEvent.getAction())
        {
        default:
          return false;
        case 1:
        }
        paramView.getParent().requestDisallowInterceptTouchEvent(false);
        return false;
      }
    });
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  protected void onResume()
  {
    super.onResume();
    layoutChangeListener();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.ExitReasonActivity
 * JD-Core Version:    0.6.0
 */