package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.DialogInterface;
import android.content.Intent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomPlanReformer;

class CustomDetailActivity$8
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -1)
    {
      Intent localIntent = new Intent(this.this$0, ExitReasonActivity.class);
      if ((CustomDetailActivity.access$000(this.this$0) != null) && (CustomDetailActivity.access$000(this.this$0).entCusData != null))
        localIntent.putExtra("custom.info", CustomDetailActivity.access$000(this.this$0).entCusData.olapInfo);
      this.this$0.startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this.this$0, 0);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity.8
 * JD-Core Version:    0.6.0
 */