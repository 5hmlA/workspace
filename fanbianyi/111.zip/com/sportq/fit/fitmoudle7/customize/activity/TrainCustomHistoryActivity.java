package com.sportq.fit.fitmoudle7.customize.activity;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreAdapter;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper.OnLoadMoreWarpperListener;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.adapter.TrainCustomHistoryAdapter;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer;
import java.util.ArrayList;

public class TrainCustomHistoryActivity extends BaseActivity
  implements LoadMoreWrapper.OnLoadMoreWarpperListener
{
  private TrainCustomHistoryAdapter adapter;
  private ArrayList<PlanModel> allList;
  private RecyclerView cusHistoryRecyclerView;
  private CustomizeReformer customizeReformer;
  private String lastCustomId;
  private LoadMoreWrapper loadMoreWrapper;
  private CustomToolBar toolbar;

  private void initView()
  {
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.customId = this.lastCustomId;
    new CustomPresenterImpl(this).getCusHistory(localRequestModel, this);
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if ((paramT instanceof CustomizeReformer))
    {
      this.customizeReformer = ((CustomizeReformer)paramT);
      if (this.cusHistoryRecyclerView.getTag() != null)
        break label164;
      this.allList = this.customizeReformer.lstCusHistory;
      this.adapter = new TrainCustomHistoryAdapter(this);
      this.adapter.setList(this.allList);
      this.cusHistoryRecyclerView.setAdapter(this.adapter);
      this.loadMoreWrapper = new LoadMoreWrapper(new LoadMoreAdapter(this.adapter), this);
      this.loadMoreWrapper.setShowNoMoreEnabled(false);
      this.loadMoreWrapper.into(this.cusHistoryRecyclerView);
    }
    while (true)
    {
      if (this.allList.size() > 0)
        this.lastCustomId = ((PlanModel)this.allList.get(-1 + this.allList.size())).customDetailId;
      this.cusHistoryRecyclerView.setTag(null);
      return;
      label164: if (this.customizeReformer.lstCusHistory.size() > 0)
      {
        this.allList.addAll(this.customizeReformer.lstCusHistory);
        this.adapter.setList(this.allList);
        this.adapter.notifyDataSetChanged();
        continue;
      }
      this.loadMoreWrapper.setLoadMoreEnabled(false);
      this.adapter.notifyDataSetChanged();
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.traincus_history);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.cusHistoryRecyclerView = ((RecyclerView)findViewById(R.id.cusHistory_recyclerView));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(getString(R.string.a_28_4));
    this.toolbar.setBackgroundResource(R.color.white);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    setSupportActionBar(this.toolbar);
    this.cusHistoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    initView();
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  public void onLoadMore()
  {
    if ((this.cusHistoryRecyclerView == null) || (StringUtils.isNull(this.lastCustomId)))
      return;
    if (CompDeviceInfoUtils.checkNetwork())
    {
      this.cusHistoryRecyclerView.setTag("load.more");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.customId = this.lastCustomId;
      new CustomPresenterImpl(this).getCusHistory(localRequestModel, this);
      return;
    }
    ToastUtils.makeToast(this, getString(R.string.g_20_1));
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.TrainCustomHistoryActivity
 * JD-Core Version:    0.6.0
 */