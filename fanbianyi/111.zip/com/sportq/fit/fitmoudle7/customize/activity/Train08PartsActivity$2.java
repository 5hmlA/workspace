package com.sportq.fit.fitmoudle7.customize.activity;

import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.CustomLoad.FeedbackLoadDialog;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.widget.MyCountDownTimer;

class Train08PartsActivity$2
  implements Runnable
{
  public void run()
  {
    if (Train08PartsActivity.access$100(this.this$0))
    {
      Train08PartsActivity.access$000(this.this$0).startSuccessAnima(this.this$0.getString(R.string.adjust_success));
      return;
    }
    new MyCountDownTimer(5000L, 100L)
    {
      public void onFinish()
      {
        Train08PartsActivity.access$000(Train08PartsActivity.2.this.this$0).closeDialog();
        Train08PartsActivity.2.this.this$0.dialog = new DialogManager();
        Train08PartsActivity.2.this.this$0.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
        {
          public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
          {
            if (paramInt == -1)
            {
              Train08PartsActivity.2.this.this$0.dialog.closeDialog();
              Train08PartsActivity.access$200(Train08PartsActivity.2.this.this$0);
              return;
            }
            Train08PartsActivity.2.this.this$0.dialog.closeDialog();
          }
        }
        , Train08PartsActivity.2.this.this$0, "", Train08PartsActivity.2.this.this$0.getString(R.string.network_condition_submit_failure), Train08PartsActivity.2.this.this$0.getString(R.string.retry), Train08PartsActivity.2.this.this$0.getString(R.string.cancel_hint));
      }

      public void onTick(long paramLong)
      {
        if (Train08PartsActivity.access$100(Train08PartsActivity.2.this.this$0))
        {
          Train08PartsActivity.access$000(Train08PartsActivity.2.this.this$0).startSuccessAnima(Train08PartsActivity.2.this.this$0.getString(R.string.adjust_success));
          cancel();
        }
      }
    }
    .start();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.Train08PartsActivity.2
 * JD-Core Version:    0.6.0
 */