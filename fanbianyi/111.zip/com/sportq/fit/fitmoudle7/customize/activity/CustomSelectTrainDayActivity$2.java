package com.sportq.fit.fitmoudle7.customize.activity;

import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.CustomLoad.FeedbackLoadDialog;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.string;

class CustomSelectTrainDayActivity$2
  implements Runnable
{
  public void run()
  {
    try
    {
      if (this.this$0.isFinishing())
        return;
      CustomSelectTrainDayActivity.access$300(this.this$0).closeDialog();
      if (CustomSelectTrainDayActivity.access$400(this.this$0) != null)
      {
        this.this$0.DoneProgressFinish();
        return;
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      return;
    }
    this.this$0.dialog.createChoiceDialogWithColor(new FitInterfaceUtils.DialogListener()
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        if (paramInt == -1)
          CustomSelectTrainDayActivity.access$500(CustomSelectTrainDayActivity.2.this.this$0);
      }
    }
    , this.this$0, "", this.this$0.getString(R.string.a_13_1), this.this$0.getString(R.string.a_13_3), this.this$0.getString(R.string.a_13_2), R.color.color_dbb76a, R.color.color_e6e6e6, R.color.color_313131, R.color.color_626262);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomSelectTrainDayActivity.2
 * JD-Core Version:    0.6.0
 */