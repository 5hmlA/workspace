package com.sportq.fit.fitmoudle7.customize.activity;

import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.supportlib.CommonUtils;

class CustomDetailActivity$6
  implements Runnable
{
  public void run()
  {
    CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GetCusPlan);
    CustomDetailActivity.access$202(this.this$0, new CustomPresenterImpl(this.this$0));
    CustomDetailActivity.access$200(this.this$0).getCusPlan(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity.6
 * JD-Core Version:    0.6.0
 */