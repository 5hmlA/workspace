package com.sportq.fit.fitmoudle7.customize.activity;

import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import java.util.ArrayList;

class CustomSelectTrainDayActivity$1
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    if ("select".equals(paramView.getTag().toString()))
    {
      CustomSelectTrainDayActivity.access$010(this.this$0);
      paramView.setTag("unSelect");
      CustomSelectTrainDayActivity.access$100(this.this$0).set(this.val$index, Integer.valueOf(-1));
      ((TextView)paramView.findViewById(R.id.week_day)).setTextColor(ContextCompat.getColor(this.this$0, R.color.color_626262));
    }
    while (true)
    {
      CustomSelectTrainDayActivity.access$200(this.this$0);
      return;
      CustomSelectTrainDayActivity.access$008(this.this$0);
      paramView.setTag("select");
      CustomSelectTrainDayActivity.access$100(this.this$0).set(this.val$index, Integer.valueOf(1 + this.val$index));
      ((TextView)paramView.findViewById(R.id.week_day)).setTextColor(ContextCompat.getColor(this.this$0, R.color.color_dbb76a));
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomSelectTrainDayActivity.1
 * JD-Core Version:    0.6.0
 */