package com.sportq.fit.fitmoudle7.customize.activity;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.widget.RelativeLayout;

class Train10FitTimesActivity$1
  implements ValueAnimator.AnimatorUpdateListener
{
  public void onAnimationUpdate(ValueAnimator paramValueAnimator)
  {
    if (((Integer)paramValueAnimator.getAnimatedValue()).intValue() != this.this$0.selectColor)
    {
      RelativeLayout[] arrayOfRelativeLayout2 = Train10FitTimesActivity.access$000(this.this$0);
      int k = arrayOfRelativeLayout2.length;
      for (int m = 0; m < k; m++)
        arrayOfRelativeLayout2[m].setEnabled(false);
    }
    RelativeLayout[] arrayOfRelativeLayout1 = Train10FitTimesActivity.access$000(this.this$0);
    int i = arrayOfRelativeLayout1.length;
    for (int j = 0; j < i; j++)
      arrayOfRelativeLayout1[j].setEnabled(true);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.Train10FitTimesActivity.1
 * JD-Core Version:    0.6.0
 */