package com.sportq.fit.fitmoudle7.customize.activity;

import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.sportq.fit.fitmoudle7.customize.widget.CustomScrollView;
import com.sportq.fit.fitmoudle7.customize.widget.CustomScrollView.ScrollViewListener;
import com.sportq.fit.fitmoudle7.customize.widget.DietTitleView;

class DietRecommendActivity$1
  implements CustomScrollView.ScrollViewListener
{
  public void onScrollChanged(CustomScrollView paramCustomScrollView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = 4;
    if (DietRecommendActivity.access$000(this.this$0) == null)
      return;
    int[] arrayOfInt1 = new int[2];
    int[] arrayOfInt2 = new int[2];
    int[] arrayOfInt3 = new int[2];
    int[] arrayOfInt4 = new int[2];
    this.this$0.diet_title_view.getLocationInWindow(arrayOfInt1);
    DietRecommendActivity.access$100(this.this$0).getLocationInWindow(arrayOfInt2);
    this.this$0.diet_date_layout.getLocationInWindow(arrayOfInt3);
    DietRecommendActivity.access$200(this.this$0).getLocationInWindow(arrayOfInt4);
    RelativeLayout localRelativeLayout = this.this$0.diet_title_view;
    int j;
    DietTitleView localDietTitleView;
    if (arrayOfInt1[1] <= arrayOfInt3[1])
    {
      j = i;
      localRelativeLayout.setVisibility(j);
      localDietTitleView = DietRecommendActivity.access$100(this.this$0);
      if (arrayOfInt2[1] > arrayOfInt4[1])
        break label147;
    }
    while (true)
    {
      localDietTitleView.setVisibility(i);
      return;
      j = 0;
      break;
      label147: i = 0;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.DietRecommendActivity.1
 * JD-Core Version:    0.6.0
 */