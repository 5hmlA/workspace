package com.sportq.fit.fitmoudle7.customize.activity.fat_camp;

import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.supportlib.CommonUtils;

class FatCampDetailActivity$5
  implements Runnable
{
  public void run()
  {
    CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GetLoseFatPlan);
    FatCampDetailActivity.access$702(this.this$0, true);
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.loseFatId = FatCampDetailActivity.access$800(this.this$0);
    new CustomPresenterImpl(this.this$0).getLoseFatPlan(localRequestModel, this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampDetailActivity.5
 * JD-Core Version:    0.6.0
 */