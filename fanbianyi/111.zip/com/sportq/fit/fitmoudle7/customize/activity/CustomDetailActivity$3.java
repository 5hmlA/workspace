package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.DialogInterface;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;

class CustomDetailActivity$3
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -1)
      CustomDetailActivity.access$200(this.this$0).recoveryTraining(new RequestModel(), this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity.3
 * JD-Core Version:    0.6.0
 */