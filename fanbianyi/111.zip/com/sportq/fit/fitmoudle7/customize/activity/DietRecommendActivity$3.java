package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.DialogInterface;
import android.content.Intent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.fitmoudle.AnimationUtil;

class DietRecommendActivity$3
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == 0)
    {
      Intent localIntent = new Intent(this.this$0, PerfectDietActivity.class);
      localIntent.putExtra("cur.jump", "1");
      this.this$0.startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this.this$0, 0);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.DietRecommendActivity.3
 * JD-Core Version:    0.6.0
 */