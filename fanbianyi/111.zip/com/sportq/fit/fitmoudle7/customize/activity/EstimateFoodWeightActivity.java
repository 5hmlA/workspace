package com.sportq.fit.fitmoudle7.customize.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle7.R.drawable;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import java.util.ArrayList;

public class EstimateFoodWeightActivity extends BaseActivity
{
  private String[] foodNameList;
  private TextView food_name;
  private TextView food_weight;
  private int[] imgList;
  private LinearLayout indicator_layout;
  private String[] introList01;
  private String[] introList02;
  private LinearLayout intro_layout;
  private TextView introduce01;
  private TextView introduce02;
  ViewPager mViewPager;
  private String[] weightList;

  public EstimateFoodWeightActivity()
  {
    int[] arrayOfInt = new int[10];
    arrayOfInt[0] = R.mipmap.img_food_weight_1;
    arrayOfInt[1] = R.mipmap.img_food_weight_2;
    arrayOfInt[2] = R.mipmap.img_food_weight_3;
    arrayOfInt[3] = R.mipmap.img_food_weight_4;
    arrayOfInt[4] = R.mipmap.img_food_weight_5;
    arrayOfInt[5] = R.mipmap.img_food_weight_6;
    arrayOfInt[6] = R.mipmap.img_food_weight_7;
    arrayOfInt[7] = R.mipmap.img_food_weight_8;
    arrayOfInt[8] = R.mipmap.img_food_weight_9;
    arrayOfInt[9] = R.mipmap.img_food_weight_10;
    this.imgList = arrayOfInt;
  }

  private void initView()
  {
    String[] arrayOfString1 = new String[10];
    arrayOfString1[0] = getString(R.string.a_42_6_1);
    arrayOfString1[1] = getString(R.string.a_42_6_5);
    arrayOfString1[2] = getString(R.string.a_42_6_9);
    arrayOfString1[3] = getString(R.string.a_42_6_13);
    arrayOfString1[4] = getString(R.string.a_42_6_16);
    arrayOfString1[5] = getString(R.string.a_42_6_19);
    arrayOfString1[6] = getString(R.string.a_42_6_22);
    arrayOfString1[7] = getString(R.string.a_42_6_24);
    arrayOfString1[8] = getString(R.string.a_42_6_27);
    arrayOfString1[9] = getString(R.string.a_42_6_30);
    this.foodNameList = arrayOfString1;
    String[] arrayOfString2 = new String[10];
    arrayOfString2[0] = getString(R.string.a_42_6_2);
    arrayOfString2[1] = getString(R.string.a_42_6_6);
    arrayOfString2[2] = getString(R.string.a_42_6_10);
    arrayOfString2[3] = getString(R.string.a_42_6_14);
    arrayOfString2[4] = getString(R.string.a_42_6_17);
    arrayOfString2[5] = getString(R.string.a_42_6_20);
    arrayOfString2[6] = getString(R.string.a_42_6_23);
    arrayOfString2[7] = getString(R.string.a_42_6_25);
    arrayOfString2[8] = getString(R.string.a_42_6_28);
    arrayOfString2[9] = getString(R.string.a_42_6_31);
    this.introList01 = arrayOfString2;
    String[] arrayOfString3 = new String[10];
    arrayOfString3[0] = getString(R.string.a_42_6_3);
    arrayOfString3[1] = getString(R.string.a_42_6_11);
    arrayOfString3[2] = getString(R.string.a_42_6_11);
    arrayOfString3[3] = "";
    arrayOfString3[4] = getString(R.string.a_42_6_3);
    arrayOfString3[5] = getString(R.string.a_42_6_3);
    arrayOfString3[6] = "";
    arrayOfString3[7] = getString(R.string.a_42_6_3);
    arrayOfString3[8] = "";
    arrayOfString3[9] = "";
    this.introList02 = arrayOfString3;
    String[] arrayOfString4 = new String[10];
    arrayOfString4[0] = getString(R.string.a_42_6_4);
    arrayOfString4[1] = getString(R.string.a_42_6_8);
    arrayOfString4[2] = getString(R.string.a_42_6_12);
    arrayOfString4[3] = getString(R.string.a_42_6_15);
    arrayOfString4[4] = getString(R.string.a_42_6_18);
    arrayOfString4[5] = getString(R.string.a_42_6_21);
    arrayOfString4[6] = getString(R.string.a_42_6_18);
    arrayOfString4[7] = getString(R.string.a_42_6_26);
    arrayOfString4[8] = getString(R.string.a_42_6_29);
    arrayOfString4[9] = getString(R.string.a_42_6_32);
    this.weightList = arrayOfString4;
    this.mViewPager = ((ViewPager)findViewById(R.id.mViewPager));
    this.indicator_layout = ((LinearLayout)findViewById(R.id.indicator_layout));
    this.food_name = ((TextView)findViewById(R.id.food_name));
    this.introduce01 = ((TextView)findViewById(R.id.introduce01));
    this.introduce02 = ((TextView)findViewById(R.id.introduce02));
    this.food_weight = ((TextView)findViewById(R.id.food_weight));
    this.intro_layout = ((LinearLayout)findViewById(R.id.intro_layout));
    int i = (int)(0.08D * BaseApplication.screenWidth);
    this.mViewPager.setPadding(i, 0, i, 0);
    ((RelativeLayout.LayoutParams)this.indicator_layout.getLayoutParams()).topMargin = (int)(1.056D * BaseApplication.screenWidth);
    int j = (int)(0.7639D * BaseApplication.screenWidth);
    ArrayList localArrayList = new ArrayList();
    int k = 0;
    if (k < this.imgList.length)
    {
      View localView1 = View.inflate(this, R.layout.food_item_layout, null);
      ImageView localImageView = (ImageView)localView1.findViewById(R.id.food_img);
      localImageView.getLayoutParams().width = j;
      localImageView.getLayoutParams().height = j;
      localImageView.setImageResource(this.imgList[k]);
      localArrayList.add(localView1);
      View localView2 = new View(this);
      localView2.setBackgroundResource(R.drawable.food_indicator_bg01);
      LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(CompDeviceInfoUtils.convertOfDip(this, 6.0F), CompDeviceInfoUtils.convertOfDip(this, 6.0F));
      if (k == 0);
      for (int m = 0; ; m = CompDeviceInfoUtils.convertOfDip(this, 10.0F))
      {
        localLayoutParams.leftMargin = m;
        this.indicator_layout.addView(localView2, localLayoutParams);
        k++;
        break;
      }
    }
    this.mViewPager.setAdapter(new CustomViewPagerAdapter(localArrayList));
    this.mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
    {
      public void onPageScrollStateChanged(int paramInt)
      {
      }

      public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
      {
      }

      public void onPageSelected(int paramInt)
      {
        EstimateFoodWeightActivity.this.setIndicatorAndInfo(paramInt);
      }
    });
    this.mViewPager.setCurrentItem(0);
    setIndicatorAndInfo(0);
    this.intro_layout.post(new Runnable()
    {
      public void run()
      {
        EstimateFoodWeightActivity.this.intro_layout.getLayoutParams().height = EstimateFoodWeightActivity.this.intro_layout.getHeight();
      }
    });
  }

  private void setIndicatorAndInfo(int paramInt)
  {
    this.food_name.setText(this.foodNameList[paramInt]);
    this.introduce01.setText(this.introList01[paramInt]);
    TextView localTextView = this.introduce02;
    int i;
    int j;
    label80: View localView;
    if (StringUtils.isNull(this.introList02[paramInt]))
    {
      i = 8;
      localTextView.setVisibility(i);
      this.introduce02.setText(this.introList02[paramInt]);
      this.food_weight.setText(this.weightList[paramInt]);
      j = 0;
      if (j >= this.indicator_layout.getChildCount())
        return;
      localView = this.indicator_layout.getChildAt(j);
      if (j != paramInt)
        break label132;
    }
    label132: for (int k = R.drawable.food_indicator_bg02; ; k = R.drawable.food_indicator_bg01)
    {
      localView.setBackgroundResource(k);
      j++;
      break label80;
      i = 0;
      break;
    }
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.btn_close)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    super.fitOnClick(paramView);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.estimate_layout);
    initView();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.EstimateFoodWeightActivity
 * JD-Core Version:    0.6.0
 */