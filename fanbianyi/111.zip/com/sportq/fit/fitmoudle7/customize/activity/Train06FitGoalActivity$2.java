package com.sportq.fit.fitmoudle7.customize.activity;

import android.view.View;
import android.widget.RelativeLayout.LayoutParams;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;

class Train06FitGoalActivity$2
  implements Runnable
{
  public void run()
  {
    this.val$view.getLocationInWindow(Train06FitGoalActivity.access$400(this.this$0));
    RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)Train06FitGoalActivity.access$300(this.this$0).getLayoutParams();
    localLayoutParams.height = Train06FitGoalActivity.access$500(this.this$0).getHeight();
    Train06FitGoalActivity.access$300(this.this$0).setLayoutParams(localLayoutParams);
    Train06FitGoalActivity.access$300(this.this$0).setX(Train06FitGoalActivity.access$400(this.this$0)[0]);
    Train06FitGoalActivity.access$300(this.this$0).setY(Train06FitGoalActivity.access$400(this.this$0)[1] - CompDeviceInfoUtils.getStatusBarHeight(this.this$0));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.Train06FitGoalActivity.2
 * JD-Core Version:    0.6.0
 */