package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.eventbus.UpOrderInfoEvent;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.NoResultReformer;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.stub.StubApp;
import org.greenrobot.eventbus.EventBus;

public class TrainLeaveActivity extends BaseActivity
{
  public static final String KEY_CUSTOM_ID = "CUSTOM_ID";
  public static final String KEY_PAUSE_TIME = "PAUSE_TIME";
  public static String WEEKID;
  private String care_error_str;
  private CustomPresenterImpl customPresenter;
  private ImageView mAdd_img;
  private TextView mDays_tv;
  private TextView mError_info_tv;
  private TextView mLeave_error_tv;
  private TextView mLeave_tv;
  private ImageView mMinus_img;
  private String strCustomId;
  private String strPauseTime;
  private CustomToolBar toolbar;
  private String weekId;

  static
  {
    StubApp.interface11(12055);
    WEEKID = "weekid";
  }

  private void checkAddOrMinusState(int paramInt)
  {
    if (paramInt >= 7)
    {
      this.mAdd_img.setImageResource(R.mipmap.btn_order_add_grey);
      this.mMinus_img.setImageResource(R.mipmap.btn_order_minus_black);
      if (paramInt > 7)
      {
        ToastUtils.makeToast(this, UseStringUtils.getStr(R.string.a_9_3_1));
        return;
      }
      this.mDays_tv.setText(paramInt + "");
      return;
    }
    if (paramInt <= 1)
    {
      this.mAdd_img.setImageResource(R.mipmap.btn_order_add_black);
      this.mMinus_img.setImageResource(R.mipmap.btn_order_minus_grey);
      if (paramInt < 1)
      {
        ToastUtils.makeToast(this, "每次请假最少为1天");
        return;
      }
      this.mDays_tv.setText(paramInt + "");
      return;
    }
    this.mAdd_img.setImageResource(R.mipmap.btn_order_add_black);
    this.mMinus_img.setImageResource(R.mipmap.btn_order_minus_black);
    this.mDays_tv.setText(paramInt + "");
  }

  private String getCareErrorStr()
  {
    if ("0".equals(BaseApplication.userModel.userSex));
    for (int i = R.string.a_9_1_6; ; i = R.string.a_9_2_2)
      return UseStringUtils.getStr(i);
  }

  private void getInfo()
  {
    this.care_error_str = getCareErrorStr();
    this.weekId = getIntent().getStringExtra(WEEKID);
    this.strCustomId = getIntent().getStringExtra("CUSTOM_ID");
    this.strPauseTime = getIntent().getStringExtra("PAUSE_TIME");
  }

  private void init()
  {
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    this.toolbar.setTitle(UseStringUtils.getStr(R.string.a_9_1_1));
    setSupportActionBar(this.toolbar);
    this.mMinus_img = ((ImageView)findViewById(R.id.minus_img));
    this.mDays_tv = ((TextView)findViewById(R.id.days_tv));
    this.mAdd_img = ((ImageView)findViewById(R.id.add_img));
    this.mLeave_error_tv = ((TextView)findViewById(R.id.leave_error_tv));
    this.mError_info_tv = ((TextView)findViewById(R.id.error_info_tv));
    this.mLeave_tv = ((TextView)findViewById(R.id.leave_tv));
    this.dialog = new DialogManager();
  }

  private void setListener()
  {
    TextView localTextView = this.mLeave_error_tv;
    int i = R.string.a_9_1_3;
    String[] arrayOfString = new String[1];
    if (StringUtils.isNull(this.strPauseTime));
    for (String str = ""; ; str = this.strPauseTime)
    {
      arrayOfString[0] = str;
      localTextView.setText(UseStringUtils.getStr(i, arrayOfString));
      this.mError_info_tv.setText(this.care_error_str);
      Typeface localTypeface = Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf");
      this.mDays_tv.setTypeface(localTypeface);
      this.mDays_tv.setText("1");
      checkAddOrMinusState(1);
      this.mMinus_img.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          TrainLeaveActivity.this.checkAddOrMinusState(-1 + StringUtils.string2Int(TrainLeaveActivity.this.mDays_tv.getText().toString()));
        }
      });
      this.mAdd_img.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          TrainLeaveActivity.this.checkAddOrMinusState(1 + StringUtils.string2Int(TrainLeaveActivity.this.mDays_tv.getText().toString()));
        }
      });
      this.mLeave_tv.setOnClickListener(new FitAction(this));
      this.customPresenter = new CustomPresenterImpl(this);
      return;
    }
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.leave_tv)
    {
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.pauseDay = this.mDays_tv.getText().toString();
      if (CompDeviceInfoUtils.checkNetwork())
      {
        this.dialog.createProgressDialog(this, getString(R.string.load_data));
        localRequestModel.weekId = this.weekId;
        this.customPresenter.phyPause(localRequestModel, this);
      }
    }
    else
    {
      return;
    }
    ToastUtils.makeToast(this, getString(R.string.something_wrong_network));
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof NoResultReformer))
    {
      UpOrderInfoEvent localUpOrderInfoEvent = new UpOrderInfoEvent();
      localUpOrderInfoEvent.state = "0";
      EventBus.getDefault().post(localUpOrderInfoEvent);
      this.dialog.closeDialog();
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      ToastUtils.makeToast(BaseApplication.appliContext, UseStringUtils.getStr(R.string.a_8_4_1));
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.train_leave_activity);
    getInfo();
    init();
    setListener();
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.TrainLeaveActivity
 * JD-Core Version:    0.6.0
 */