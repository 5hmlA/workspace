package com.sportq.fit.fitmoudle7.customize.activity;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.widget.RelativeLayout;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle7.R.string;

class CustomDetailActivity$CustomNetWorkChangeReceiver extends BroadcastReceiver
{
  private CustomDetailActivity$CustomNetWorkChangeReceiver(CustomDetailActivity paramCustomDetailActivity)
  {
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    VdsAgent.onBroadcastReceiver(this, paramContext, paramIntent);
    String str = CompDeviceInfoUtils.getAPNType(this.this$0);
    if ("-1".equals(str))
      ToastUtils.makeToast(this.this$0, this.this$0.getResources().getString(R.string.network_useless_check_settings));
    if (!"1".equals(str))
      if (CustomDetailActivity.access$700(this.this$0).getVisibility() == 0)
      {
        CustomDetailActivity.access$1102(this.this$0, true);
        CustomDetailActivity.access$1200(this.this$0, "0");
        CustomDetailActivity.access$1302(this.this$0, this.this$0.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
        {
          public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
          {
            if (paramInt == -1)
            {
              if (!CompDeviceInfoUtils.checkNetwork())
              {
                ToastUtils.makeToast(CustomDetailActivity.CustomNetWorkChangeReceiver.this.this$0, StringUtils.getStringResources(R.string.network_useless_check_settings));
                CustomDetailActivity.access$1102(CustomDetailActivity.CustomNetWorkChangeReceiver.this.this$0, false);
                return;
              }
              CustomDetailActivity.access$1200(CustomDetailActivity.CustomNetWorkChangeReceiver.this.this$0, "1");
            }
            CustomDetailActivity.access$1102(CustomDetailActivity.CustomNetWorkChangeReceiver.this.this$0, false);
          }
        }
        , this.this$0, "", StringUtils.getStringResources(R.string.net_change_hint), StringUtils.getStringResources(R.string.continue_download), StringUtils.getStringResources(R.string.stop_download)));
        CustomDetailActivity.access$1300(this.this$0).setCanceledOnTouchOutside(false);
        CustomDetailActivity.access$1300(this.this$0).setCancelable(false);
      }
    do
      return;
    while (!CustomDetailActivity.access$1100(this.this$0));
    CustomDetailActivity.access$1102(this.this$0, false);
    CustomDetailActivity.access$1200(this.this$0, "1");
    CustomDetailActivity.access$1300(this.this$0).dismiss();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity.CustomNetWorkChangeReceiver
 * JD-Core Version:    0.6.0
 */