package com.sportq.fit.fitmoudle7.customize.activity.fat_camp;

import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.superView.RRelativeLayout;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.customize.activity.TrainCampShareActivity;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.LoseFatPlanReformer;
import com.sportq.fit.fitmoudle7.customize.widget.FatCampFlipAnimation;
import com.sportq.fit.fitmoudle7.customize.widget.FatCampFlipAnimation.AnimationListener;
import com.sportq.fit.fitmoudle7.customize.widget.FatCampWeekView;
import java.util.ArrayList;

class FatCampDetailActivity$2
  implements Runnable
{
  public void run()
  {
    try
    {
      int i = FatCampDetailActivity.access$100(this.this$0).getCurrentItem();
      LinearLayout localLinearLayout = (LinearLayout)((FatCampWeekView)FatCampDetailActivity.access$200(this.this$0).get(i)).findViewById(R.id.linearLayout);
      for (int j = 0; j < localLinearLayout.getChildCount(); j++)
      {
        View localView = localLinearLayout.getChildAt(j);
        RelativeLayout localRelativeLayout = (RelativeLayout)localView.findViewById(R.id.fat_camp_day_layout);
        ImageView localImageView = (ImageView)localView.findViewById(R.id.fat_camp_today_img);
        RRelativeLayout localRRelativeLayout = (RRelativeLayout)localView.findViewById(R.id.fat_camp_day_finished);
        if (localImageView.getVisibility() != 0)
          continue;
        new FatCampFlipAnimation(this.this$0, localRelativeLayout, localRRelativeLayout, new FatCampFlipAnimation.AnimationListener(localRRelativeLayout)
        {
          public void finish()
          {
            if (this.val$fat_camp_day_finished != null)
              this.val$fat_camp_day_finished.setVisibility(0);
            if (FatCampDetailActivity.access$300(FatCampDetailActivity.2.this.this$0))
            {
              Intent localIntent = new Intent(FatCampDetailActivity.2.this.this$0, TrainCampShareActivity.class);
              localIntent.putExtra("data.data", FatCampDetailActivity.access$000(FatCampDetailActivity.2.this.this$0).entLoseFatData);
              FatCampDetailActivity.2.this.this$0.startActivity(localIntent);
              AnimationUtil.pagePopAnim(FatCampDetailActivity.2.this.this$0, 0);
            }
          }
        }).flipAnimationStart();
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampDetailActivity.2
 * JD-Core Version:    0.6.0
 */