package com.sportq.fit.fitmoudle7.customize.activity.fat_camp;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle7.customize.activity.TrainCampShareActivity;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.LoseFatPlanReformer;

class FatCampDetailActivity$7
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    Intent localIntent = new Intent(this.this$0, TrainCampShareActivity.class);
    localIntent.putExtra("data.data", FatCampDetailActivity.access$000(this.this$0).entLoseFatData);
    this.this$0.startActivity(localIntent);
    AnimationUtil.pagePopAnim(this.this$0, 0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampDetailActivity.7
 * JD-Core Version:    0.6.0
 */