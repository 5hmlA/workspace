package com.sportq.fit.fitmoudle7.customize.activity;

import com.sportq.fit.common.utils.CustomLoad.FeedbackLoadDialog;
import com.sportq.fit.fitmoudle7.R.string;

class Train08PartsActivity$1
  implements Runnable
{
  public void run()
  {
    Train08PartsActivity.access$000(this.this$0).startSuccessAnima(this.this$0.getString(R.string.adjust_success));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.Train08PartsActivity.1
 * JD-Core Version:    0.6.0
 */