package com.sportq.fit.fitmoudle7.customize.activity.fat_camp;

import android.app.Dialog;
import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;

class FatCampDetailActivity$8
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    this.this$0.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        if (paramInt == -2)
          FatCampDetailActivity.access$1100(FatCampDetailActivity.8.this.this$0).dismiss();
      }
    }
    , this.this$0, "", "为了达到更理想的效果，大部分用户都倾向参加多期训练营哦~", "再想想", "取消");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampDetailActivity.8
 * JD-Core Version:    0.6.0
 */