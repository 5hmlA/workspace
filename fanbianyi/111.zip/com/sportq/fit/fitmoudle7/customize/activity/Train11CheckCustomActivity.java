package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.model.TrainCustomInfoEntity;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CustomLoad.DoneProgress.DoneProgressInterface;
import com.sportq.fit.common.utils.CustomLoad.FeedbackLoadDialog;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RLinearLayout;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.ReceiveMedalEvent;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.FinishMonthCusReformer;
import com.sportq.fit.fitmoudle7.customize.widget.Calendar.CustomizeCalendarView;
import com.sportq.fit.fitmoudle7.customize.widget.CustomScrollView;
import com.sportq.fit.fitmoudle7.customize.widget.CustomScrollView.ScrollViewListener;
import com.sportq.fit.fitmoudle7.customize.widget.CustomizePreviewHeadView;
import com.sportq.fit.fitmoudle7.customize.widget.CustomizeTrainingRemindView;
import com.sportq.fit.fitmoudle7.customize.widget.CustomizeWeekStatisticalView;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.CommonUtils;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;

public class Train11CheckCustomActivity extends BaseActivity
  implements DoneProgress.DoneProgressInterface
{
  private CustomizeCalendarView calendar;
  TextView completeCustom;
  private TrainCustomInfoEntity customInfoEntity;
  private CustomPresenterImpl customPresenter;
  private CustomizeReformer customizeReformer;
  private FinishMonthCusReformer finishMonthCusReformer;
  private FeedbackLoadDialog loadDialog;
  private CustomScrollView scrollView;
  private RLinearLayout showCourseView;
  private CustomToolBar toolbar;
  private CustomToolBar toolbar_transparent;
  private CustomizePreviewHeadView train11HeadView;
  private LinearLayout train11WeeksLinear;
  private TextView train11WeeksTitle;
  private CustomizeTrainingRemindView trainRemindView;

  private void checkNetWork()
  {
    if (!CompDeviceInfoUtils.checkNetwork())
      this.dialog.createChoiceDialogWithColor(new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          if (paramInt == -1)
            Train11CheckCustomActivity.this.checkNetWork();
        }
      }
      , this, "", getString(R.string.a_13_1), getString(R.string.a_13_3), getString(R.string.a_13_2), R.color.color_dbb76a, R.color.color_e6e6e6, R.color.color_313131, R.color.color_626262);
  }

  public void DoneProgressFinish()
  {
    this.loadDialog.closeDialog();
    CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GetCusPlan);
    startActivity(new Intent(this, CustomDetailActivity.class));
    AnimationUtil.pageJumpAnim(this, 0);
    EventBus.getDefault().post("finish.custom");
    BaseApplication.userModel.orderf = "1";
    if ((this.customInfoEntity != null) && (!StringUtils.isNull(this.customInfoEntity.getIsTryVip())) && ("1".equals(this.customInfoEntity.getIsTryVip())))
    {
      BaseApplication.userModel.isVip = this.finishMonthCusReformer.isVip;
      BaseApplication.userModel.hasTryVip = this.finishMonthCusReformer.hasTryVip;
      BaseApplication.userModel.vipEndComment = this.finishMonthCusReformer.vipEndComment;
    }
    EventBus.getDefault().post(new ReceiveMedalEvent("6"));
    finish();
  }

  public void fitOnClick(View paramView)
  {
    super.fitOnClick(paramView);
    if (paramView.getId() == R.id.train11_completeCustom)
      if (!CompDeviceInfoUtils.checkNetwork())
        ToastUtils.makeToast(this, getString(R.string.network_useless_check_settings));
    label93: label227: label233: label235: 
    do
    {
      return;
      CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.FinishMonthCus);
      this.dialog.createProgressDialog(this, getString(R.string.complete_customing));
      this.customPresenter = new CustomPresenterImpl(this);
      RequestModel localRequestModel1 = new RequestModel();
      String str1;
      String str3;
      RequestModel localRequestModel2;
      if (StringUtils.isNull(this.customInfoEntity.getIsTryVip()))
      {
        str1 = "0";
        localRequestModel1.isTryVip = str1;
        this.customPresenter.finishMonthCus(localRequestModel1, this);
        String str2 = BaseApplication.userModel.cusTrainFlg;
        if (!this.trainRemindView.getIsRemind())
          break label227;
        str3 = "1";
        if ((str2.equals(str3)) && (BaseApplication.userModel.cusTrainTime.equals(this.trainRemindView.getDialogTime())))
          break label233;
        localRequestModel2 = new RequestModel();
        if (!this.trainRemindView.getIsRemind())
          break label235;
      }
      for (String str4 = "1"; ; str4 = "0")
      {
        localRequestModel2.cusTrainFlg = str4;
        localRequestModel2.cusTrainTime = this.trainRemindView.getDialogTime();
        MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(localRequestModel2, this);
        return;
        str1 = this.customInfoEntity.getIsTryVip();
        break label93;
        str3 = "0";
        break label129;
        break;
      }
    }
    while (paramView.getId() != R.id.change_scrollY_view);
    label129: this.scrollView.scrollTo(0, (int)(this.train11WeeksLinear.getY() - CompDeviceInfoUtils.convertOfDip(this, 55.0F)));
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    this.dialog.closeDialog();
    checkNetWork();
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    this.dialog.closeDialog();
    if ((paramT instanceof FinishMonthCusReformer))
    {
      this.finishMonthCusReformer = ((FinishMonthCusReformer)paramT);
      this.loadDialog = new FeedbackLoadDialog(this);
      this.loadDialog.createDialog(this);
      this.loadDialog.startSuccessAnima(getString(R.string.custom_success));
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.train11checkcustomize);
    this.dialog = new DialogManager();
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.toolbar_transparent = ((CustomToolBar)findViewById(R.id.toolbar_transparent));
    this.scrollView = ((CustomScrollView)findViewById(R.id.train11_scrollView));
    this.train11HeadView = ((CustomizePreviewHeadView)findViewById(R.id.train11_headView));
    this.calendar = ((CustomizeCalendarView)findViewById(R.id.train11_calendar));
    this.trainRemindView = ((CustomizeTrainingRemindView)findViewById(R.id.train11_trainRemind));
    this.completeCustom = ((TextView)findViewById(R.id.train11_completeCustom));
    this.showCourseView = ((RLinearLayout)findViewById(R.id.change_scrollY_view));
    this.train11WeeksTitle = ((TextView)findViewById(R.id.train11_weeksTitle));
    this.train11WeeksLinear = ((LinearLayout)findViewById(R.id.sfullPlan_weeksLinear));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(getString(R.string.custom_plan));
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    this.toolbar.setAlpha(0.0F);
    setSupportActionBar(this.toolbar);
    this.toolbar_transparent.setNavIcon(R.mipmap.btn_back_white);
    this.toolbar_transparent.setTitle("");
    this.toolbar_transparent.setBackgroundColor(ContextCompat.getColor(this, R.color.transparent));
    Intent localIntent = getIntent();
    this.customizeReformer = ((CustomizeReformer)localIntent.getSerializableExtra("preview_data_customizereformer"));
    this.customInfoEntity = ((TrainCustomInfoEntity)localIntent.getSerializableExtra("custom_info_entity"));
    TrainCustomInfoEntity localTrainCustomInfoEntity;
    int i;
    label340: TextView localTextView;
    StringBuilder localStringBuilder;
    String str2;
    Object[] arrayOfObject;
    if (this.customInfoEntity == null)
    {
      localTrainCustomInfoEntity = new TrainCustomInfoEntity();
      this.customInfoEntity = localTrainCustomInfoEntity;
      CustomizeTrainingRemindView localCustomizeTrainingRemindView = this.trainRemindView;
      com.sportq.fit.common.interfaces.dialog.DialogInterface localDialogInterface = this.dialog;
      if (StringUtils.isNull(this.customInfoEntity.getKeepFlag()))
        break label629;
      i = 1;
      localCustomizeTrainingRemindView.setDialog(localDialogInterface, i);
      this.scrollView.setScrollViewListener(new CustomScrollView.ScrollViewListener()
      {
        public void onScrollChanged(CustomScrollView paramCustomScrollView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
        {
          if (paramInt2 <= CompDeviceInfoUtils.convertOfDip(Train11CheckCustomActivity.this, 50.0F))
          {
            float f = paramInt2 / CompDeviceInfoUtils.convertOfDip(Train11CheckCustomActivity.this, 50.0F);
            Train11CheckCustomActivity.this.toolbar.setAlpha(f);
          }
          while (true)
          {
            if ((paramInt2 > CompDeviceInfoUtils.convertOfDip(Train11CheckCustomActivity.this, 3.0F)) && (Train11CheckCustomActivity.this.showCourseView.getVisibility() == 0))
              Train11CheckCustomActivity.this.showCourseView.setVisibility(8);
            return;
            Train11CheckCustomActivity.this.toolbar.setAlpha(1.0F);
          }
        }
      });
      this.completeCustom.setOnClickListener(new FitAction(this));
      this.showCourseView.setOnClickListener(new FitAction(this));
      this.toolbar.setTitle(this.customizeReformer.entCusData.curriculumName);
      this.train11HeadView.setCustomizeHeadValue(this.customizeReformer.entCusData);
      this.calendar.onCreateCalendar(this.customizeReformer.lstCusCal, false);
      localTextView = this.train11WeeksTitle;
      localStringBuilder = new StringBuilder().append(this.customizeReformer.entCusData.trainNum);
      if (StringUtils.isNull(this.customizeReformer.entCusData.apparatus))
        break label635;
      str2 = getString(R.string.equipment_s);
      arrayOfObject = new Object[1];
      arrayOfObject[0] = this.customizeReformer.entCusData.apparatus;
    }
    label629: label635: for (String str1 = String.format(str2, arrayOfObject); ; str1 = "")
    {
      localTextView.setText(String.valueOf(str1));
      this.train11WeeksLinear.removeViews(1, -1 + this.train11WeeksLinear.getChildCount());
      for (int j = 0; j < this.customizeReformer.lstCusWeek.size(); j++)
      {
        CustomizeWeekStatisticalView localCustomizeWeekStatisticalView = new CustomizeWeekStatisticalView(this);
        localCustomizeWeekStatisticalView.setWeekStatValue((CustomizeModel.CustomDataEntity)this.customizeReformer.lstCusWeek.get(j), 0);
        this.train11WeeksLinear.addView(localCustomizeWeekStatisticalView);
      }
      localTrainCustomInfoEntity = this.customInfoEntity;
      break;
      i = 0;
      break label340;
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      this.dialog.createChoiceDialogWithColor(new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          if (paramInt == -1)
          {
            Train11CheckCustomActivity.this.finish();
            AnimationUtil.pageJumpAnim(Train11CheckCustomActivity.this, 1);
          }
        }
      }
      , this, "", getString(R.string.a_3_4_1), getString(R.string.a_3_4_3), getString(R.string.a_3_4_2), R.color.color_dbb76a, R.color.color_e6e6e6, R.color.color_313131, R.color.color_626262);
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      this.dialog.createChoiceDialogWithColor(new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          if (paramInt == -1)
          {
            Train11CheckCustomActivity.this.finish();
            AnimationUtil.pageJumpAnim(Train11CheckCustomActivity.this, 1);
          }
        }
      }
      , this, "", getString(R.string.a_3_4_1), getString(R.string.a_3_4_3), getString(R.string.a_3_4_2), R.color.color_dbb76a, R.color.color_e6e6e6, R.color.color_313131, R.color.color_626262);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.Train11CheckCustomActivity
 * JD-Core Version:    0.6.0
 */