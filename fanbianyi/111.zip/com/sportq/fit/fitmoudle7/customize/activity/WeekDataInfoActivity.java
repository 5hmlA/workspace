package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.CustomizeModel.CustomWeekEntity;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer;
import com.sportq.fit.fitmoudle7.customize.widget.CustomizeWeekOneDayView;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

public class WeekDataInfoActivity extends BaseActivity
{
  private String customId;
  private CustomizeReformer customizeReformer;
  private TextView feedBack_title;
  private TextView finishBtn;
  private TextView headText;
  private boolean isThisWeek;
  private String pageFlag;
  private String preFlag;
  private CustomToolBar toolbar;
  private RelativeLayout toolbar_Content;
  private String weekId;
  private String weekTitle;
  private RelativeLayout weekTrainHead;
  private LinearLayout week_data_info_layout;

  public void fitOnClick(View paramView)
  {
    super.fitOnClick(paramView);
    if (paramView.getId() == R.id.finishBtn)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof CustomizeReformer))
    {
      this.dialog.closeDialog();
      this.customizeReformer = ((CustomizeReformer)paramT);
      if (!StringUtils.isNull(this.customizeReformer.adjustComment))
        this.headText.setText(this.customizeReformer.adjustComment);
      this.week_data_info_layout.removeAllViews();
      for (int i = 0; i < this.customizeReformer.lstWeekPlan.size(); i++)
      {
        CustomizeWeekOneDayView localCustomizeWeekOneDayView = new CustomizeWeekOneDayView(this, this.preFlag);
        localCustomizeWeekOneDayView.initView((CustomizeModel.CustomWeekEntity)this.customizeReformer.lstWeekPlan.get(i), this.pageFlag);
        this.week_data_info_layout.addView(localCustomizeWeekOneDayView);
      }
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.week_data_info_layout);
    if (getIntent() != null)
    {
      this.weekId = getIntent().getStringExtra("custom_weekId");
      this.preFlag = getIntent().getStringExtra("custom_preFlag");
      this.pageFlag = getIntent().getStringExtra("custom_pageFlag");
      this.weekTitle = getIntent().getStringExtra("custom_weekNo");
      this.customId = getIntent().getStringExtra("custom_customId");
      this.isThisWeek = getIntent().getBooleanExtra("custom_this_week", false);
    }
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.toolbar_Content = ((RelativeLayout)findViewById(R.id.toolbar_Content));
    this.feedBack_title = ((TextView)findViewById(R.id.week_train_feedBackTitle));
    this.week_data_info_layout = ((LinearLayout)findViewById(R.id.week_data_info_layout));
    this.weekTrainHead = ((RelativeLayout)findViewById(R.id.week_train_hint));
    this.headText = ((TextView)findViewById(R.id.week_train_hint_Text));
    this.finishBtn = ((TextView)findViewById(R.id.finishBtn));
    this.dialog = new DialogManager();
    if (this.isThisWeek)
    {
      this.toolbar.setTitle(String.valueOf(getString(R.string.this_week) + "概况"));
      this.feedBack_title.setText(String.valueOf(getString(R.string.this_week) + "概况"));
      this.toolbar.setNavIcon(R.mipmap.btn_back_black);
      this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
      this.toolbar.setBackgroundResource(R.color.white);
      setSupportActionBar(this.toolbar);
      if ("1".equals(this.pageFlag))
        break label563;
      this.weekTrainHead.setVisibility(8);
      this.finishBtn.setVisibility(8);
      this.toolbar_Content.setVisibility(0);
      this.feedBack_title.setVisibility(8);
    }
    while (true)
    {
      this.finishBtn.setOnClickListener(new FitAction(this));
      if ((!StringUtils.isNull(this.preFlag)) && (!StringUtils.isNull(this.weekId)))
      {
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.weekId = this.weekId;
        localRequestModel.preFlag = this.preFlag;
        if ("2".equals(this.preFlag))
          localRequestModel.customId = this.customId;
        this.dialog.createProgressDialog(this, getString(R.string.load_data));
        new CustomPresenterImpl(this).getWeekCusPlan(localRequestModel, this);
      }
      return;
      StringBuilder localStringBuilder = new StringBuilder();
      if (this.weekTitle.contains("-"));
      for (String str1 = this.weekTitle.split("-")[0]; ; str1 = this.weekTitle)
      {
        String str2 = str1 + "概况";
        this.toolbar.setTitle(str2);
        this.feedBack_title.setText(str2);
        break;
      }
      label563: this.weekTrainHead.setVisibility(0);
      this.finishBtn.setVisibility(0);
      this.toolbar_Content.setVisibility(4);
      this.feedBack_title.setVisibility(0);
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (!"1".equals(this.pageFlag)))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if ((paramMenuItem.getItemId() == 16908332) && (!"1".equals(this.pageFlag)))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }

  protected void onResume()
  {
    super.onResume();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.WeekDataInfoActivity
 * JD-Core Version:    0.6.0
 */