package com.sportq.fit.fitmoudle7.customize.activity;

import android.animation.ArgbEvaluator;
import android.graphics.Color;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.widget.LinearLayout;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle7.R.id;

class CustomStartActivity$2
  implements ViewPager.OnPageChangeListener
{
  public void onPageScrollStateChanged(int paramInt)
  {
  }

  public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
  {
    if (CustomStartActivity.access$000(this.this$0))
      CustomStartActivity.access$002(this.this$0, false);
    do
      return;
    while (paramInt1 == 4);
    int i = StringUtils.string2Int(String.valueOf(this.this$0.evaluator.evaluate(paramFloat, Integer.valueOf(Color.parseColor("#ffdbb76a")), Integer.valueOf(Color.parseColor("#66ffffff")))));
    int j = StringUtils.string2Int(String.valueOf(this.this$0.evaluator02.evaluate(paramFloat, Integer.valueOf(Color.parseColor("#66ffffff")), Integer.valueOf(Color.parseColor("#ffdbb76a")))));
    View localView1 = CustomStartActivity.access$100(this.this$0).getChildAt(paramInt1);
    localView1.setRotation(45.0F + 45.0F * paramFloat);
    ((RTextView)localView1.findViewById(R.id.indicatorView)).getHelper().setBackgroundColorNormal(i);
    View localView2 = CustomStartActivity.access$100(this.this$0).getChildAt(paramInt1 + 1);
    localView2.setRotation(45.0F * paramFloat);
    ((RTextView)localView2.findViewById(R.id.indicatorView)).getHelper().setBackgroundColorNormal(j);
  }

  public void onPageSelected(int paramInt)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomStartActivity.2
 * JD-Core Version:    0.6.0
 */