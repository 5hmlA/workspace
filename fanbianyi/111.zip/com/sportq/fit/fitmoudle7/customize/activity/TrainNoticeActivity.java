package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.SelectTimeDialog;
import com.sportq.fit.fitmoudle.dialogmanager.SelectTimeDialog.TimeSelectorListener;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.stub.StubApp;

public class TrainNoticeActivity extends BaseActivity
{
  public static String ORDERTIME;
  public static String ORDERTIMEFLG;
  private boolean dialogFlg;
  private Switch mItem_switch;
  private TextView mNotice_tv;
  private ImageView mTi_icon_img;
  private RelativeLayout mTime_error_rl;
  private TextView mTime_item_title_tv;
  private TextView mTime_tv;
  private TextView mTrans_item_title_tv;
  private String setTime = "";
  private String switchFlg = "";
  CustomToolBar toolbar;

  static
  {
    StubApp.interface11(12058);
    ORDERTIME = "ordertime";
    ORDERTIMEFLG = "ordertimeflg";
  }

  private void checkTextColor()
  {
    TextView localTextView1 = this.mNotice_tv;
    int i;
    int j;
    label52: int k;
    label92: int m;
    label133: TextView localTextView5;
    Resources localResources4;
    if ("0".equals(this.switchFlg))
    {
      i = 0;
      localTextView1.setVisibility(i);
      TextView localTextView2 = this.mNotice_tv;
      Resources localResources1 = getResources();
      if (!"1".equals(this.switchFlg))
        break label193;
      j = R.color.color_313131;
      localTextView2.setTextColor(localResources1.getColor(j));
      TextView localTextView3 = this.mTrans_item_title_tv;
      Resources localResources2 = getResources();
      if (!"1".equals(this.switchFlg))
        break label201;
      k = R.color.color_313131;
      localTextView3.setTextColor(localResources2.getColor(k));
      TextView localTextView4 = this.mTime_item_title_tv;
      Resources localResources3 = getResources();
      if (!"1".equals(this.switchFlg))
        break label209;
      m = R.color.color_313131;
      localTextView4.setTextColor(localResources3.getColor(m));
      localTextView5 = this.mTime_tv;
      localResources4 = getResources();
      if (!"1".equals(this.switchFlg))
        break label217;
    }
    label193: label201: label209: label217: for (int n = R.color.color_313131; ; n = R.color.color_c8c8c8)
    {
      localTextView5.setTextColor(localResources4.getColor(n));
      return;
      i = 8;
      break;
      j = R.color.color_c8c8c8;
      break label52;
      k = R.color.color_c8c8c8;
      break label92;
      m = R.color.color_c8c8c8;
      break label133;
    }
  }

  private void getInfo()
  {
    String str1;
    if (StringUtils.isNull(getIntent().getStringExtra(ORDERTIME)))
    {
      str1 = "20:00";
      this.setTime = str1;
      if (!StringUtils.isNull(getIntent().getStringExtra(ORDERTIMEFLG)))
        break label63;
    }
    label63: for (String str2 = "0"; ; str2 = getIntent().getStringExtra(ORDERTIMEFLG))
    {
      this.switchFlg = str2;
      return;
      str1 = getIntent().getStringExtra(ORDERTIME);
      break;
    }
  }

  private void init()
  {
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    this.toolbar.setTitle("训练提醒");
    setSupportActionBar(this.toolbar);
    this.mItem_switch = ((Switch)findViewById(R.id.item_switch));
    this.mTime_error_rl = ((RelativeLayout)findViewById(R.id.time_error_rl));
    this.mTi_icon_img = ((ImageView)findViewById(R.id.ti_icon_img));
    this.mTime_tv = ((TextView)findViewById(R.id.time_tv));
    this.mNotice_tv = ((TextView)findViewById(R.id.notice_tv));
    this.mTrans_item_title_tv = ((TextView)findViewById(R.id.trans_item_title_tv));
    this.mTime_item_title_tv = ((TextView)findViewById(R.id.time_item_title_tv));
    this.dialog = new DialogManager();
    this.mItem_switch.setChecked("1".equals(this.switchFlg));
    this.mTime_tv.setText(this.setTime);
    checkTextColor();
  }

  private void setListener()
  {
    this.mTime_error_rl.setOnClickListener(new FitAction(this));
    this.mItem_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
    {
      @Instrumented
      public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
      {
        VdsAgent.onCheckedChanged(this, paramCompoundButton, paramBoolean);
        TrainNoticeActivity localTrainNoticeActivity = TrainNoticeActivity.this;
        if (paramBoolean);
        for (String str = "1"; ; str = "0")
        {
          TrainNoticeActivity.access$002(localTrainNoticeActivity, str);
          TrainNoticeActivity.this.checkTextColor();
          return;
        }
      }
    });
  }

  private void setTimeDialog(String paramString)
  {
    this.dialogFlg = true;
    new SelectTimeDialog(this).setColors(R.color.color_dbb76a, R.color.color_313131, R.color.color_e6e6e6, R.color.color_626262).createDialog(new SelectTimeDialog.TimeSelectorListener()
    {
      public void onSelect(String paramString)
      {
        if (TrainNoticeActivity.this.dialogFlg)
        {
          TrainNoticeActivity.access$202(TrainNoticeActivity.this, false);
          TrainNoticeActivity.this.mTime_tv.setText(paramString);
          TrainNoticeActivity.access$402(TrainNoticeActivity.this, paramString);
        }
      }
    }
    , paramString);
  }

  private void upDateUserInfo()
  {
    if ((!this.switchFlg.equals(BaseApplication.userModel.cusTrainFlg)) || (!this.setTime.equals(BaseApplication.userModel.cusTrainTime)))
    {
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.cusTrainFlg = this.switchFlg;
      localRequestModel.cusTrainTime = this.setTime;
      MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(localRequestModel, this);
    }
  }

  public void fitOnClick(View paramView)
  {
    if ((paramView.getId() == R.id.time_error_rl) && ("1".equals(this.switchFlg)))
      setTimeDialog(this.setTime);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.train_notice_activity);
    getInfo();
    init();
    setListener();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      upDateUserInfo();
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      upDateUserInfo();
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.TrainNoticeActivity
 * JD-Core Version:    0.6.0
 */