package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Intent;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.activity.VipCenterActivity;

class TrainStartNextCustomizeActivity$1
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -2)
    {
      if (!"1".equals(BaseApplication.userModel.isVip))
      {
        this.this$0.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
        {
          public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
          {
            if (paramInt == -1)
            {
              SharePreferenceUtils.putBuyVipFromPage("14");
              TrainStartNextCustomizeActivity.1.this.this$0.startActivity(new Intent(TrainStartNextCustomizeActivity.1.this.this$0, VipCenterActivity.class));
              AnimationUtil.pageJumpAnim(TrainStartNextCustomizeActivity.1.this.this$0, 0);
            }
          }
        }
        , this.this$0, "", "如需继续定制计划，请购买VIP会员。", "去购买", "取消");
        return;
      }
      Intent localIntent = new Intent(this.this$0, Train05LastCustomActivity.class);
      this.this$0.startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this.this$0, 0);
      this.this$0.finish();
      return;
    }
    this.this$0.finish();
    AnimationUtil.pageJumpAnim(this.this$0, 1);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.TrainStartNextCustomizeActivity.1
 * JD-Core Version:    0.6.0
 */