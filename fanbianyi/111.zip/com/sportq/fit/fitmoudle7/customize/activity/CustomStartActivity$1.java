package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Intent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;

class CustomStartActivity$1
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
  {
    this.this$0.dialog.closeDialog();
    switch (paramInt)
    {
    default:
      return;
    case -2:
      this.this$0.startActivity(new Intent(this.this$0, CustomDetailActivity.class));
      this.this$0.finish();
      AnimationUtil.pageJumpAnim(this.this$0, 0);
      return;
    case -1:
    }
    this.this$0.dialog.createProgressDialog(this.this$0, "请稍后...");
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.exitCode = "1";
    localRequestModel.exitComment = "";
    new CustomPresenterImpl(this.this$0).exitMonthCus(localRequestModel, this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomStartActivity.1
 * JD-Core Version:    0.6.0
 */