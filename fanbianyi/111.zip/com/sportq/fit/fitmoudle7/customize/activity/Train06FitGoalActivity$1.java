package com.sportq.fit.fitmoudle7.customize.activity;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.RelativeLayout;
import com.nineoldandroids.view.ViewHelper;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.middlelib.statistics.FitAction;

class Train06FitGoalActivity$1
  implements Animation.AnimationListener
{
  public void onAnimationEnd(Animation paramAnimation)
  {
    Train06FitGoalActivity.access$300(this.this$0).clearAnimation();
    ViewHelper.setTranslationX(Train06FitGoalActivity.access$300(this.this$0), this.val$clickViewLocation[0]);
    ViewHelper.setTranslationY(Train06FitGoalActivity.access$300(this.this$0), this.val$clickViewLocation[1] - CompDeviceInfoUtils.getStatusBarHeight(this.this$0));
    Train06FitGoalActivity.access$000(this.this$0).setOnClickListener(new FitAction(this.this$0));
    Train06FitGoalActivity.access$100(this.this$0).setOnClickListener(new FitAction(this.this$0));
    Train06FitGoalActivity.access$200(this.this$0).setOnClickListener(new FitAction(this.this$0));
  }

  public void onAnimationRepeat(Animation paramAnimation)
  {
  }

  public void onAnimationStart(Animation paramAnimation)
  {
    Train06FitGoalActivity.access$000(this.this$0).setOnClickListener(null);
    Train06FitGoalActivity.access$100(this.this$0).setOnClickListener(null);
    Train06FitGoalActivity.access$200(this.this$0).setOnClickListener(null);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.Train06FitGoalActivity.1
 * JD-Core Version:    0.6.0
 */