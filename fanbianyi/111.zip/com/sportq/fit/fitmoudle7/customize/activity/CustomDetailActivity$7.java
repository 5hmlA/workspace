package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.dialogmanager.PopWindowMenu.OnPopViewClickListener;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.widget.AboutCustomizeDialog;

class CustomDetailActivity$7
  implements PopWindowMenu.OnPopViewClickListener
{
  public void onPopViewClick(View paramView)
  {
    if (paramView.getId() == 2 + R.id.menu_content)
      new AboutCustomizeDialog(this.this$0).createDialog();
    do
    {
      return;
      if (paramView.getId() == 3 + R.id.menu_content)
      {
        switch (this.this$0.MORE_TYPE)
        {
        default:
          return;
        case 0:
        case 3:
          if (CompDeviceInfoUtils.checkNetwork())
          {
            if ((CustomDetailActivity.access$700(this.this$0).getVisibility() == 0) || (CustomDetailActivity.access$800(this.this$0).getVisibility() == 0))
            {
              ToastUtils.makeToast(this.this$0, this.this$0.getString(R.string.video_downloading));
              return;
            }
            CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
            {
              public void result(boolean paramBoolean)
              {
                if (paramBoolean)
                  CustomDetailActivity.access$900(CustomDetailActivity.7.this.this$0);
              }
            }
            , this.this$0, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
            return;
          }
          ToastUtils.makeToast(this.this$0, this.this$0.getString(R.string.something_wrong_network));
          return;
        case 1:
          CustomDetailActivity.access$1000(this.this$0);
          return;
        case 2:
        }
        Intent localIntent2 = new Intent(this.this$0, TrainCustomHistoryActivity.class);
        this.this$0.startActivity(localIntent2);
        AnimationUtil.pageJumpAnim(this.this$0, 0);
        return;
      }
      if (paramView.getId() != 4 + R.id.menu_content)
        continue;
      switch (this.this$0.MORE_TYPE)
      {
      case 1:
      default:
        return;
      case 0:
        Intent localIntent1 = new Intent(this.this$0, TrainCustomHistoryActivity.class);
        this.this$0.startActivity(localIntent1);
        AnimationUtil.pageJumpAnim(this.this$0, 0);
        return;
      case 2:
      case 3:
      }
      CustomDetailActivity.access$1000(this.this$0);
      return;
    }
    while (paramView.getId() != 5 + R.id.menu_content);
    CustomDetailActivity.access$1000(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity.7
 * JD-Core Version:    0.6.0
 */