package com.sportq.fit.fitmoudle7.customize.activity;

import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.widget.LinearLayout;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstMonthCusData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomPlanReformer;
import com.sportq.fit.fitmoudle7.customize.widget.CustomWeekItemView;
import java.util.ArrayList;

class CustomDetailActivity$5
  implements ViewPager.OnPageChangeListener
{
  public void onPageScrollStateChanged(int paramInt)
  {
  }

  public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
  {
  }

  public void onPageSelected(int paramInt)
  {
    CustomDetailActivity.access$300(this.this$0, paramInt);
    for (int i = 0; i < CustomDetailActivity.access$400(this.this$0).size(); i++)
    {
      LinearLayout localLinearLayout = (LinearLayout)((CustomWeekItemView)CustomDetailActivity.access$400(this.this$0).get(i)).getChildAt(0);
      int j = 0;
      if (j >= localLinearLayout.getChildCount())
        continue;
      View localView = localLinearLayout.getChildAt(j);
      if (localLinearLayout.getChildAt(j).getTag() == null);
      while (true)
      {
        j++;
        break;
        if (((EntlstMonthCusData)CustomDetailActivity.access$000(this.this$0).lstMonthCus.get(paramInt)).cusDate.equals(localView.getTag().toString()))
        {
          CustomDetailActivity.access$500(this.this$0, (EntlstMonthCusData)CustomDetailActivity.access$000(this.this$0).lstMonthCus.get(paramInt));
          if (CustomDetailActivity.access$600(this.this$0).getCurrentItem() != i)
            CustomDetailActivity.access$600(this.this$0).setCurrentItem(i);
          localView.findViewById(R.id.calendar_indicator).setVisibility(0);
          continue;
        }
        localView.findViewById(R.id.calendar_indicator).setVisibility(8);
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity.5
 * JD-Core Version:    0.6.0
 */