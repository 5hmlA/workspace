package com.sportq.fit.fitmoudle7.customize.activity;

import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;

class TrainSeeFullPlanActivity$1
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -1)
    {
      this.this$0.dialog.createProgressDialog(this.this$0, "请稍后");
      this.this$0.customPresenter.recoveryTraining(new RequestModel(), this.this$0);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.TrainSeeFullPlanActivity.1
 * JD-Core Version:    0.6.0
 */