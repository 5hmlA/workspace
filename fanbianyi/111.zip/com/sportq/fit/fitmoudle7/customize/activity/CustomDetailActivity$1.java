package com.sportq.fit.fitmoudle7.customize.activity;

import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomPlanReformer;
import com.sportq.fit.v25.design.AppBarLayout;
import com.sportq.fit.v25.design.AppBarLayout.OnOffsetChangedListener;
import com.sportq.fit.v25.design.CollapsingToolbarLayout;

class CustomDetailActivity$1
  implements AppBarLayout.OnOffsetChangedListener
{
  public void onOffsetChanged(AppBarLayout paramAppBarLayout, int paramInt)
  {
    if (Math.abs(paramInt) >= paramAppBarLayout.getTotalScrollRange())
      if ((CustomDetailActivity.access$000(this.this$0) != null) && ((this.val$collapsingToolbarLayout.getTitle() == null) || (StringUtils.isNull(this.val$collapsingToolbarLayout.getTitle().toString()))))
        this.val$collapsingToolbarLayout.setTitle(CustomDetailActivity.access$000(this.this$0).entCusData.curriculumName);
    do
      return;
    while ((this.val$collapsingToolbarLayout.getTitle() == null) || (StringUtils.isNull(this.val$collapsingToolbarLayout.getTitle().toString())));
    this.val$collapsingToolbarLayout.setTitle("");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity.1
 * JD-Core Version:    0.6.0
 */