package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.ThumbnailUtils;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.rong.map.mylibrary.SlidingFinishLayout;
import com.rong.map.mylibrary.SlidingFinishLayout.OnSlidingFinishListener;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.imageloader.QueueCallback;
import com.sportq.fit.common.utils.superView.RRelativeLayout;
import com.sportq.fit.common.utils.superView.RView;
import com.sportq.fit.common.utils.superView.helper.RBaseHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.sharemanager.ShareListenerFunction;
import com.sportq.fit.fitmoudle.sharemanager.ShareManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.PlayPointModel;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatData;
import com.sportq.fit.fitmoudle7.customize.widget.FatCampShareProgress;
import java.io.File;
import java.util.Calendar;

public class TrainCampShareActivity extends BaseActivity
{
  public static final String FAT_CAMP_DATA = "data.data";
  ImageView btn_close;
  Paint cPaint;
  FatCampShareProgress calorie_progress;
  TextView date_day_view;
  TextView date_month_unit;
  TextView date_month_view;
  TextView day_tips_content;
  private EntloseFatData entLoseFatData;
  TextView finished_calorie;
  TextView finished_day;
  private boolean isClickShare = false;
  ImageView shareImg;
  RRelativeLayout share_info_layout;
  SlidingFinishLayout sliding_finish_layout;
  ImageView tips_bg;
  FatCampShareProgress train_finish_progress;
  TextView train_name;
  ImageView user_img;
  TextView user_name;

  private int calculateInSampleSize(BitmapFactory.Options paramOptions, int paramInt1, int paramInt2)
  {
    int i = paramOptions.outHeight;
    int j = paramOptions.outWidth;
    int k = 1;
    if ((i > paramInt2) || (j > paramInt1))
    {
      int m = i / 2;
      int n = j / 2;
      while ((m / k > paramInt2) && (n / k > paramInt1))
        k *= 2;
    }
    return k;
  }

  private Bitmap decodeBitmapFromResource(Resources paramResources, int paramInt1, int paramInt2, int paramInt3)
  {
    BitmapFactory.Options localOptions = new BitmapFactory.Options();
    localOptions.inJustDecodeBounds = true;
    BitmapFactory.decodeResource(paramResources, paramInt1, localOptions);
    localOptions.inSampleSize = calculateInSampleSize(localOptions, paramInt2, paramInt3);
    localOptions.inJustDecodeBounds = false;
    return BitmapFactory.decodeResource(paramResources, paramInt1, localOptions);
  }

  private Bitmap drawCirclePro(int paramInt1, int paramInt2)
  {
    int i = Math.max(paramInt1, 1);
    Bitmap localBitmap = Bitmap.createBitmap(CompDeviceInfoUtils.dipToPx(90.0F), CompDeviceInfoUtils.dipToPx(90.0F), Bitmap.Config.ARGB_8888);
    Canvas localCanvas = new Canvas(localBitmap);
    localCanvas.drawColor(ContextCompat.getColor(this, R.color.transparent));
    localCanvas.setDrawFilter(new PaintFlagsDrawFilter(0, 3));
    RectF localRectF = new RectF();
    localRectF.top = (CompDeviceInfoUtils.dipToPx(7.0F) / 2);
    localRectF.left = (CompDeviceInfoUtils.dipToPx(7.0F) / 2);
    localRectF.right = (CompDeviceInfoUtils.dipToPx(90.0F) - CompDeviceInfoUtils.dipToPx(7.0F) / 2);
    localRectF.bottom = (CompDeviceInfoUtils.dipToPx(90.0F) - CompDeviceInfoUtils.dipToPx(7.0F) / 2);
    Paint localPaint1 = new Paint();
    localPaint1.setColor(ContextCompat.getColor(this, R.color.color_f7f7f7));
    localPaint1.setAntiAlias(true);
    localPaint1.setStyle(Paint.Style.STROKE);
    localPaint1.setStrokeWidth(CompDeviceInfoUtils.dipToPx(7.0F));
    localCanvas.drawArc(localRectF, 270.0F, 360.0F, false, localPaint1);
    Paint localPaint2 = new Paint();
    localPaint2.setColor(ContextCompat.getColor(this, paramInt2));
    localPaint2.setAntiAlias(true);
    localPaint2.setStyle(Paint.Style.STROKE);
    localPaint2.setStrokeWidth(CompDeviceInfoUtils.dipToPx(6.5F));
    localPaint2.setStrokeCap(Paint.Cap.ROUND);
    localCanvas.drawArc(localRectF, 270.0F, i, false, localPaint2);
    return localBitmap;
  }

  private void drawShareBitmap(Bitmap paramBitmap, Object paramObject)
  {
    Bitmap localBitmap = Bitmap.createBitmap(BaseApplication.screenWidth, BaseApplication.screenRealHeight, Bitmap.Config.ARGB_8888);
    Canvas localCanvas = new Canvas(localBitmap);
    localCanvas.setDrawFilter(new PaintFlagsDrawFilter(0, 3));
    localCanvas.drawBitmap(paramBitmap, 0.0F, 0.0F, null);
    Paint localPaint1 = getDefaultPaint();
    localPaint1.setTextSize(CompDeviceInfoUtils.spTopx(55.0F));
    localPaint1.setTypeface(TextUtils.getFontFaceImpact());
    Calendar localCalendar = Calendar.getInstance();
    float f1 = CompDeviceInfoUtils.dipToPx(37.5F);
    int i;
    int j;
    label433: int k;
    label553: int m;
    label1611: UseShareModel localUseShareModel;
    int n;
    label1810: ShareManager localShareManager;
    if (isBlack())
    {
      i = R.color.black;
      localPaint1.setColor(ContextCompat.getColor(this, i));
      Float[] arrayOfFloat1 = getBaseXY(localPaint1, String.valueOf(localCalendar.get(5)));
      float f2 = 2.0F * arrayOfFloat1[0].floatValue();
      float f3 = arrayOfFloat1[1].floatValue();
      localCanvas.drawText(String.valueOf(localCalendar.get(5)), f1, CompDeviceInfoUtils.dipToPx(53.200001F) + arrayOfFloat1[1].floatValue(), localPaint1);
      localPaint1.setTextSize(CompDeviceInfoUtils.spTopx(18.0F));
      float f4 = 2.0F * getBaseXY(localPaint1, String.valueOf(1 + localCalendar.get(2)))[0].floatValue();
      localCanvas.drawText(String.valueOf(1 + localCalendar.get(2)), f2 + CompDeviceInfoUtils.dipToPx(45.200001F), f3 + CompDeviceInfoUtils.dipToPx(53.200001F), localPaint1);
      localPaint1.setTextSize(CompDeviceInfoUtils.spTopx(18.0F));
      localCanvas.drawText("月", f4 + (f2 + CompDeviceInfoUtils.dipToPx(47.0F)), f3 + CompDeviceInfoUtils.dipToPx(52.5F), localPaint1);
      float f5 = f3 + CompDeviceInfoUtils.dipToPx(63.799999F);
      RectF localRectF1 = new RectF();
      localRectF1.left = f1;
      localRectF1.top = f5;
      localRectF1.right = (f1 + CompDeviceInfoUtils.dipToPx(20.0F));
      localRectF1.bottom = (f5 + CompDeviceInfoUtils.dipToPx(2.0F));
      localCanvas.drawRoundRect(localRectF1, 3.0F, 3.0F, localPaint1);
      float f6 = f5 + CompDeviceInfoUtils.dipToPx(13.3F);
      String str = this.entLoseFatData.imageComment;
      TextPaint localTextPaint = new TextPaint();
      localTextPaint.setAntiAlias(true);
      localTextPaint.setTextAlign(Paint.Align.LEFT);
      if (!isBlack())
        break label1887;
      j = R.color.black;
      localTextPaint.setColor(ContextCompat.getColor(this, j));
      localTextPaint.setTextSize(CompDeviceInfoUtils.spTopx(16.0F));
      StaticLayout localStaticLayout = new StaticLayout(str, localTextPaint, (int)(localCanvas.getWidth() - 2.0F * f1), Layout.Alignment.ALIGN_NORMAL, 1.2F, 0.0F, false);
      localCanvas.save();
      localCanvas.translate(f1, f6);
      localStaticLayout.draw(localCanvas);
      localCanvas.restore();
      float f7 = f6 + localStaticLayout.getHeight() + CompDeviceInfoUtils.dipToPx(12.9F);
      Resources localResources = getResources();
      if (!isBlack())
        break label1895;
      k = R.mipmap.icon_tips_black;
      localCanvas.drawBitmap(decodeBitmapFromResource(localResources, k, CompDeviceInfoUtils.dipToPx(19.0F), CompDeviceInfoUtils.dipToPx(69.0F)), f1, f7, null);
      RectF localRectF2 = new RectF();
      localRectF2.left = CompDeviceInfoUtils.dipToPx(20.0F);
      localRectF2.top = (BaseApplication.screenRealHeight - CompDeviceInfoUtils.dipToPx(355.0F));
      localRectF2.right = (BaseApplication.screenWidth - CompDeviceInfoUtils.dipToPx(20.0F));
      localRectF2.bottom = (BaseApplication.screenRealHeight - CompDeviceInfoUtils.dipToPx(30.0F));
      Paint localPaint2 = getDefaultPaint();
      localCanvas.drawRoundRect(localRectF2, 18.0F, 18.0F, localPaint2);
      localCanvas.drawBitmap(getUserImgBitmap(this, paramObject, CompDeviceInfoUtils.dipToPx(40.0F)), f1, localRectF2.top + CompDeviceInfoUtils.dipToPx(19.5F), null);
      localPaint2.setAlpha(255);
      localPaint2.setTextSize(CompDeviceInfoUtils.spTopx(15.0F));
      localPaint2.setFakeBoldText(true);
      localPaint2.setColor(ContextCompat.getColor(this, R.color.color_313131));
      Float[] arrayOfFloat2 = getBaseXY(localPaint2, BaseApplication.userModel.userName);
      localCanvas.drawText(BaseApplication.userModel.userName, CompDeviceInfoUtils.dipToPx(88.300003F), localRectF2.top + CompDeviceInfoUtils.dipToPx(22.299999F) + arrayOfFloat2[1].floatValue(), localPaint2);
      localPaint2.setTextSize(CompDeviceInfoUtils.spTopx(13.0F));
      localPaint2.setFakeBoldText(false);
      localPaint2.setColor(ContextCompat.getColor(this, R.color.color_828282));
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = this.entLoseFatData.finishTitle;
      Float[] arrayOfFloat3 = getBaseXY(localPaint2, String.format("已参加「%s」", arrayOfObject1));
      Object[] arrayOfObject2 = new Object[1];
      arrayOfObject2[0] = this.entLoseFatData.finishTitle;
      localCanvas.drawText(String.format("已参加「%s」", arrayOfObject2), CompDeviceInfoUtils.dipToPx(88.699997F), localRectF2.top + CompDeviceInfoUtils.dipToPx(44.5F) + arrayOfFloat3[1].floatValue(), localPaint2);
      Float[] arrayOfFloat4 = getBaseXY(localPaint2, "已训练");
      localCanvas.drawText("已训练", CompDeviceInfoUtils.dipToPx(89.199997F), localRectF2.top + CompDeviceInfoUtils.dipToPx(80.0F) + arrayOfFloat4[1].floatValue(), localPaint2);
      localCanvas.drawBitmap(drawCirclePro((int)(360.0F * (Float.parseFloat(this.entLoseFatData.finishDays) / Float.parseFloat(this.entLoseFatData.totalDays))), R.color.color_2ac77d), CompDeviceInfoUtils.dipToPx(62.5F), localRectF2.top + CompDeviceInfoUtils.dipToPx(104.5F), null);
      localPaint2.setColor(ContextCompat.getColor(this, R.color.color_313131));
      localPaint2.setTypeface(TextUtils.getFontFaceImpact());
      localPaint2.setTextSize(CompDeviceInfoUtils.spTopx(24.0F));
      Float[] arrayOfFloat5 = getBaseXY(localPaint2, this.entLoseFatData.finishDays);
      localCanvas.drawText(this.entLoseFatData.finishDays, CompDeviceInfoUtils.dipToPx(101.8F), localRectF2.top + CompDeviceInfoUtils.dipToPx(132.0F) + arrayOfFloat5[1].floatValue(), localPaint2);
      localPaint2.setTypeface(null);
      localPaint2.setTextSize(CompDeviceInfoUtils.spTopx(13.0F));
      Float[] arrayOfFloat6 = getBaseXY(localPaint2, "天");
      localCanvas.drawText("天", CompDeviceInfoUtils.dipToPx(101.6F), localRectF2.top + CompDeviceInfoUtils.dipToPx(158.10001F) + arrayOfFloat6[1].floatValue(), localPaint2);
      localPaint2.setColor(ContextCompat.getColor(this, R.color.color_828282));
      Float[] arrayOfFloat7 = getBaseXY(localPaint2, "共消耗");
      localCanvas.drawText("共消耗", BaseApplication.screenWidth - CompDeviceInfoUtils.dipToPx(88.0F) - 2.0F * arrayOfFloat7[0].floatValue(), localRectF2.top + CompDeviceInfoUtils.dipToPx(80.0F) + arrayOfFloat7[1].floatValue(), localPaint2);
      localCanvas.drawBitmap(drawCirclePro((int)(360.0F * (Float.parseFloat(this.entLoseFatData.finishCalorie) / Float.parseFloat(this.entLoseFatData.totalCalorie))), R.color.color_ff6a49), BaseApplication.screenWidth - CompDeviceInfoUtils.dipToPx(152.0F), localRectF2.top + CompDeviceInfoUtils.dipToPx(104.5F), null);
      localPaint2.setColor(ContextCompat.getColor(this, R.color.color_313131));
      localPaint2.setTypeface(TextUtils.getFontFaceImpact());
      localPaint2.setTextSize(CompDeviceInfoUtils.spTopx(24.0F));
      Float[] arrayOfFloat8 = getBaseXY(localPaint2, this.entLoseFatData.finishCalorie);
      localCanvas.drawText(this.entLoseFatData.finishCalorie, BaseApplication.screenWidth - CompDeviceInfoUtils.dipToPx(107.0F) - arrayOfFloat8[0].floatValue(), localRectF2.top + CompDeviceInfoUtils.dipToPx(132.0F) + arrayOfFloat8[1].floatValue(), localPaint2);
      localPaint2.setTypeface(null);
      localPaint2.setTextSize(CompDeviceInfoUtils.spTopx(13.0F));
      Float[] arrayOfFloat9 = getBaseXY(localPaint2, "千卡");
      localCanvas.drawText("千卡", BaseApplication.screenWidth - CompDeviceInfoUtils.dipToPx(107.0F) - arrayOfFloat9[0].floatValue(), localRectF2.top + CompDeviceInfoUtils.dipToPx(158.10001F) + arrayOfFloat9[1].floatValue(), localPaint2);
      Paint localPaint3 = getDefaultPaint();
      localPaint3.setStrokeWidth(0.5F);
      localPaint3.setColor(ContextCompat.getColor(this, R.color.color_e6e6e6));
      localCanvas.drawLine(f1, localRectF2.top + CompDeviceInfoUtils.dipToPx(209.5F), BaseApplication.screenWidth - f1, localRectF2.top + CompDeviceInfoUtils.dipToPx(209.5F), localPaint3);
      localCanvas.drawBitmap(getShareQRCode(), f1, localRectF2.top + CompDeviceInfoUtils.dipToPx(230.0F), null);
      if (!isBlack())
        break label1903;
      m = R.color.color_313131;
      localPaint3.setColor(ContextCompat.getColor(this, m));
      localPaint3.setAlpha(102);
      localPaint3.setTextSize(CompDeviceInfoUtils.spTopx(10.0F));
      Float[] arrayOfFloat10 = getBaseXY(localPaint3, "Fit . 海报");
      localCanvas.drawText("Fit . 海报", BaseApplication.screenWidth / 2 - arrayOfFloat10[0].floatValue(), localRectF2.bottom + CompDeviceInfoUtils.dipToPx(10.2F) + arrayOfFloat10[1].floatValue(), localPaint3);
      this.dialog.closeDialog();
      localUseShareModel = new UseShareModel();
      if ("0".equals(this.entLoseFatData.campType))
      {
        localUseShareModel.shareType = "2";
        localUseShareModel.folap1 = ("{\"targetId\":" + this.entLoseFatData.trainActId + "}");
      }
      localUseShareModel.cropBitmap = localBitmap;
      localUseShareModel.olapInfo = "1";
      if (!"2".equals(this.entLoseFatData.campType))
        break label1911;
      n = 31;
      PlayPointModel localPlayPointModel = ShareListenerFunction.pointPut(n, "2", new UseShareModel());
      localShareManager = new ShareManager(this, this.dialog);
      localShareManager.setPlayPointModel(localPlayPointModel);
      if (!"2".equals(this.entLoseFatData.campType))
        break label1918;
    }
    label1887: label1895: label1903: label1911: label1918: for (int i1 = 31; ; i1 = 26)
    {
      localShareManager.shareFitData(localUseShareModel, i1, 1);
      return;
      i = R.color.white;
      break;
      j = R.color.white;
      break label433;
      k = R.mipmap.icon_tips_white;
      break label553;
      m = R.color.white;
      break label1611;
      n = 26;
      break label1810;
    }
  }

  private Float[] getBaseXY(Paint paramPaint, String paramString)
  {
    Float[] arrayOfFloat = new Float[2];
    Rect localRect = new Rect();
    paramPaint.getTextBounds(paramString, 0, paramString.length(), localRect);
    arrayOfFloat[0] = Float.valueOf(localRect.width() / 2.0F);
    arrayOfFloat[1] = Float.valueOf(localRect.height());
    return arrayOfFloat;
  }

  private Paint getDefaultPaint()
  {
    this.cPaint = new Paint();
    this.cPaint.setTextAlign(Paint.Align.LEFT);
    this.cPaint.setColor(ContextCompat.getColor(this, R.color.white));
    return this.cPaint;
  }

  private Bitmap getIconBitmap(Bitmap paramBitmap)
  {
    Bitmap localBitmap = ImageUtils.getSqueBitmap(paramBitmap);
    float f1 = 150.0F / localBitmap.getWidth();
    float f2 = 150.0F / localBitmap.getHeight();
    Matrix localMatrix = new Matrix();
    localMatrix.postScale(f1, f2);
    return Bitmap.createBitmap(localBitmap, 0, 0, localBitmap.getWidth(), localBitmap.getHeight(), localMatrix, true);
  }

  private Bitmap getShareQRCode()
  {
    Bitmap localBitmap = Bitmap.createBitmap(BaseApplication.screenWidth - CompDeviceInfoUtils.dipToPx(75.0F), CompDeviceInfoUtils.dipToPx(75.0F), Bitmap.Config.ARGB_8888);
    Canvas localCanvas = new Canvas(localBitmap);
    localCanvas.setDrawFilter(new PaintFlagsDrawFilter(0, 3));
    localCanvas.drawColor(ContextCompat.getColor(this, R.color.transparent));
    Paint localPaint = getDefaultPaint();
    localPaint.setTextSize(CompDeviceInfoUtils.spTopx(18.0F));
    localPaint.setColor(ContextCompat.getColor(this, R.color.color_313131));
    localPaint.setFakeBoldText(true);
    String str1;
    String str2;
    label150: String str3;
    label210: String str4;
    label240: Resources localResources;
    if ("0".equals(this.entLoseFatData.campType))
    {
      str1 = "超级减脂营";
      Float[] arrayOfFloat1 = getBaseXY(localPaint, str1);
      float f = 2.0F * arrayOfFloat1[0].floatValue();
      if (!"0".equals(this.entLoseFatData.campType))
        break label430;
      str2 = "超级减脂营";
      localCanvas.drawText(str2, 0.0F, CompDeviceInfoUtils.dipToPx(4.1F) + arrayOfFloat1[1].floatValue(), localPaint);
      localPaint.setTextSize(CompDeviceInfoUtils.spTopx(14.0F));
      localPaint.setFakeBoldText(false);
      if (!"0".equals(this.entLoseFatData.campType))
        break label438;
      str3 = "已有5万学员成功减脂5-20斤";
      Float[] arrayOfFloat2 = getBaseXY(localPaint, str3);
      if (!"0".equals(this.entLoseFatData.campType))
        break label446;
      str4 = "已有5万学员成功减脂5-20斤";
      localCanvas.drawText(str4, 0.0F, CompDeviceInfoUtils.dipToPx(30.5F) + arrayOfFloat2[1].floatValue(), localPaint);
      if ("0".equals(this.entLoseFatData.campType))
        localCanvas.drawBitmap(decodeBitmapFromResource(getResources(), R.mipmap.train_camp_share_icon01, CompDeviceInfoUtils.dipToPx(51.0F), CompDeviceInfoUtils.dipToPx(16.0F)), f + CompDeviceInfoUtils.dipToPx(11.7F), 0.0F, null);
      localCanvas.drawBitmap(decodeBitmapFromResource(getResources(), R.mipmap.train_camp_share_icon02, CompDeviceInfoUtils.dipToPx(116.5F), CompDeviceInfoUtils.dipToPx(21.0F)), 0.0F, CompDeviceInfoUtils.dipToPx(54.0F), null);
      localResources = getResources();
      if (!"0".equals(this.entLoseFatData.campType))
        break label454;
    }
    label430: label438: label446: label454: for (int i = R.mipmap.train_camp_qrcode; ; i = R.mipmap.train_camp_qrcode02)
    {
      localCanvas.drawBitmap(ThumbnailUtils.extractThumbnail(BitmapFactory.decodeResource(localResources, i), CompDeviceInfoUtils.dipToPx(75.0F), CompDeviceInfoUtils.dipToPx(75.0F)), BaseApplication.screenWidth - CompDeviceInfoUtils.dipToPx(150.0F), 0.0F, null);
      return localBitmap;
      str1 = "超级训练营";
      break;
      str2 = "超级训练营";
      break label150;
      str3 = "每天15分钟，塑造完美身材";
      break label210;
      str4 = "每天15分钟，塑造完美身材";
      break label240;
    }
  }

  private Bitmap getUserImgBitmap(Context paramContext, Object paramObject, int paramInt)
  {
    if (paramObject != null);
    for (Bitmap localBitmap1 = getIconBitmap(ImageUtils.getSqueBitmap((Bitmap)paramObject)); ; localBitmap1 = getIconBitmap(ImageUtils.getSqueBitmap(ImageUtils.readBitMapBase(BaseApplication.appliContext, R.mipmap.avatar_default).copy(Bitmap.Config.ARGB_8888, true))))
    {
      Bitmap localBitmap2 = ImageUtils.getRoundedCornerBitmap(ThumbnailUtils.extractThumbnail(localBitmap1, paramInt, paramInt), CompDeviceInfoUtils.convertOfDip(paramContext, paramInt / 2));
      Paint localPaint = new Paint();
      localPaint.setAntiAlias(true);
      localPaint.setAlpha(128);
      Bitmap localBitmap3 = Bitmap.createBitmap(paramInt, paramInt, Bitmap.Config.ARGB_8888);
      Canvas localCanvas = new Canvas(localBitmap3);
      localCanvas.drawColor(ContextCompat.getColor(paramContext, R.color.transparent));
      localCanvas.drawBitmap(localBitmap2, 0.0F, 0.0F, null);
      return localBitmap3;
    }
  }

  private void initView()
  {
    this.btn_close = ((ImageView)findViewById(R.id.btn_close));
    ImageView localImageView1 = this.btn_close;
    int i;
    int j;
    label356: int k;
    label402: int m;
    label431: int n;
    label469: int i1;
    label513: ImageView localImageView2;
    if (isBlack())
    {
      i = R.mipmap.btn_close_black;
      localImageView1.setImageResource(i);
      this.shareImg = ((ImageView)findViewById(R.id.share_img));
      GlideUtils.loadCacheImg(this, this.entLoseFatData.currentShareImageUrl, this.shareImg);
      this.sliding_finish_layout = ((SlidingFinishLayout)findViewById(R.id.sliding_finish_layout));
      this.sliding_finish_layout.setBgShadow(true);
      this.date_day_view = ((TextView)findViewById(R.id.date_day_view));
      this.date_day_view.setTypeface(TextUtils.getFontFaceImpact());
      this.date_month_view = ((TextView)findViewById(R.id.date_month_view));
      this.date_month_view.setTypeface(TextUtils.getFontFaceImpact());
      this.date_month_unit = ((TextView)findViewById(R.id.date_month_unit));
      this.date_month_unit.setTypeface(TextUtils.getFontFaceImpact());
      this.day_tips_content = ((TextView)findViewById(R.id.day_tips_content));
      this.share_info_layout = ((RRelativeLayout)findViewById(R.id.share_info_layout));
      this.user_img = ((ImageView)findViewById(R.id.user_img));
      this.user_name = ((TextView)findViewById(R.id.user_name));
      this.train_name = ((TextView)findViewById(R.id.train_name));
      this.finished_day = ((TextView)findViewById(R.id.finished_day));
      this.finished_day.setTypeface(TextUtils.getFontFaceImpact());
      this.train_finish_progress = ((FatCampShareProgress)findViewById(R.id.train_finish_progress));
      this.finished_calorie = ((TextView)findViewById(R.id.finished_calorie));
      this.finished_calorie.setTypeface(TextUtils.getFontFaceImpact());
      this.calorie_progress = ((FatCampShareProgress)findViewById(R.id.calorie_progress));
      this.sliding_finish_layout.setOnSlidingFinishListener(new SlidingFinishLayout.OnSlidingFinishListener()
      {
        public void onSlidingFinish()
        {
          TrainCampShareActivity.this.finish();
          AnimationUtil.pagePopNotAnim(TrainCampShareActivity.this);
        }
      });
      Calendar localCalendar = Calendar.getInstance();
      this.date_day_view.setText(String.valueOf(localCalendar.get(5)));
      TextView localTextView1 = this.date_day_view;
      if (!isBlack())
        break label763;
      j = R.color.black;
      localTextView1.setTextColor(ContextCompat.getColor(this, j));
      this.date_month_view.setText(String.valueOf(1 + localCalendar.get(2)));
      TextView localTextView2 = this.date_month_view;
      if (!isBlack())
        break label771;
      k = R.color.black;
      localTextView2.setTextColor(ContextCompat.getColor(this, k));
      TextView localTextView3 = this.date_month_unit;
      if (!isBlack())
        break label779;
      m = R.color.black;
      localTextView3.setTextColor(ContextCompat.getColor(this, m));
      RBaseHelper localRBaseHelper = ((RView)findViewById(R.id.line)).getHelper();
      if (!isBlack())
        break label787;
      n = R.color.black;
      localRBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(this, n));
      this.day_tips_content.setText(this.entLoseFatData.imageComment);
      TextView localTextView4 = this.day_tips_content;
      if (!isBlack())
        break label795;
      i1 = R.color.black;
      localTextView4.setTextColor(ContextCompat.getColor(this, i1));
      this.tips_bg = ((ImageView)findViewById(R.id.tips_bg));
      localImageView2 = this.tips_bg;
      if (!isBlack())
        break label803;
    }
    label771: label779: label787: label795: label803: for (int i2 = R.mipmap.icon_tips_black; ; i2 = R.mipmap.icon_tips_white)
    {
      localImageView2.setImageResource(i2);
      this.share_info_layout.getLayoutParams().height = (int)(0.90278D * BaseApplication.screenWidth);
      GlideUtils.loadImgByCircle(BaseApplication.userModel.userImg, R.mipmap.avatar_default, this.user_img);
      this.user_name.setText(BaseApplication.userModel.userName);
      TextView localTextView5 = this.train_name;
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = this.entLoseFatData.finishTitle;
      localTextView5.setText(String.format("已参加「%s」", arrayOfObject));
      this.finished_day.setText(this.entLoseFatData.finishDays);
      int i3 = (int)(360.0F * (Float.parseFloat(this.entLoseFatData.finishDays) / Float.parseFloat(this.entLoseFatData.totalDays)));
      this.train_finish_progress.setValue(i3, R.color.color_2ac77d);
      this.finished_calorie.setText(this.entLoseFatData.finishCalorie);
      int i4 = (int)(360.0F * (Float.parseFloat(this.entLoseFatData.finishCalorie) / Float.parseFloat(this.entLoseFatData.totalCalorie)));
      this.calorie_progress.setValue(i4, R.color.color_ff6a49);
      return;
      i = R.mipmap.btn_close_white;
      break;
      label763: j = R.color.white;
      break label356;
      k = R.color.white;
      break label402;
      m = R.color.white;
      break label431;
      n = R.color.white;
      break label469;
      i1 = R.color.white;
      break label513;
    }
  }

  private boolean isBlack()
  {
    return this.entLoseFatData.commentColor.contains("#000000");
  }

  private void toShare()
  {
    GlideUtils.loadUrlToBitmap(this, BaseApplication.userModel.userImg, new QueueCallback()
    {
      public void onErrorResponse()
      {
        ToastUtils.makeToast(TrainCampShareActivity.this, "分享失败");
      }

      public void onResponse(Object paramObject)
      {
        if (GlideUtils.getCacheFile(TrainCampShareActivity.this.entLoseFatData.currentShareImageUrl) == null)
        {
          GlideUtils.loadUrlToBitmap(TrainCampShareActivity.this, TrainCampShareActivity.this.entLoseFatData.currentShareImageUrl, new QueueCallback(paramObject)
          {
            public void onErrorResponse()
            {
              ToastUtils.makeToast(TrainCampShareActivity.this, "分享失败");
            }

            public void onResponse(Object paramObject)
            {
              Bitmap localBitmap = ThumbnailUtils.extractThumbnail((Bitmap)paramObject, BaseApplication.screenWidth, BaseApplication.screenRealHeight);
              TrainCampShareActivity.this.drawShareBitmap(localBitmap, this.val$object);
            }
          });
          return;
        }
        Bitmap localBitmap = ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(GlideUtils.getCacheFile(TrainCampShareActivity.this.entLoseFatData.currentShareImageUrl).getAbsolutePath()), BaseApplication.screenWidth, BaseApplication.screenRealHeight);
        TrainCampShareActivity.this.drawShareBitmap(localBitmap, paramObject);
      }
    });
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.btn_close)
    {
      finish();
      AnimationUtil.pagePopAnim(this, 1);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() != R.id.share_btn)
        continue;
      this.isClickShare = true;
      this.dialog.createProgressDialog(this, "请稍后...");
      toShare();
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.train_camp_share_layout);
    this.dialog = new DialogManager();
    this.entLoseFatData = ((EntloseFatData)getIntent().getSerializableExtra("data.data"));
    initView();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pagePopAnim(this, 1);
    }
    return false;
  }

  protected void onResume()
  {
    super.onResume();
    if (this.isClickShare)
    {
      finish();
      AnimationUtil.pagePopAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.TrainCampShareActivity
 * JD-Core Version:    0.6.0
 */