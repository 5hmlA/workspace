package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.res.Resources;
import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusDietaryModel;
import com.sportq.fit.fitmoudle7.customize.refermer.model.LstDietaryModel;
import java.util.ArrayList;

class DietRecommendActivity$2
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    this.this$0.dialog.createProgressDialog(this.this$0, this.this$0.getResources().getString(R.string.wait_hint));
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.dietaryId = ((LstDietaryModel)DietRecommendActivity.access$400(this.this$0).lstDietary.get(DietRecommendActivity.access$300(this.this$0))).dietaryId;
    localRequestModel.cusDate = ((LstDietaryModel)DietRecommendActivity.access$400(this.this$0).lstDietary.get(DietRecommendActivity.access$300(this.this$0))).cusDate;
    new CustomPresenterImpl(this.this$0).changeCusDietary(localRequestModel, this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.DietRecommendActivity.2
 * JD-Core Version:    0.6.0
 */