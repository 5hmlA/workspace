package com.sportq.fit.fitmoudle7.customize.activity.fat_camp;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle7.R.mipmap;

class FatCampDetailActivity$10
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    FatCampDetailActivity.access$1202(this.this$0, "0");
    FatCampDetailActivity.access$1300(this.this$0).setImageResource(R.mipmap.btn_normal);
    FatCampDetailActivity.access$1400(this.this$0).setImageResource(R.mipmap.comm_icon_sucess);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampDetailActivity.10
 * JD-Core Version:    0.6.0
 */