package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.SelectDateDialog;
import com.sportq.fit.fitmoudle.dialogmanager.SelectDateDialog.DateSelectorListener;
import com.sportq.fit.fitmoudle.dialogmanager.SelectWeightDialog;
import com.sportq.fit.fitmoudle.dialogmanager.SelectWeightDialog.OnCitySelectorListener;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.widget.SelectPhyActLevelDialog;
import com.sportq.fit.fitmoudle7.customize.widget.SelectPhyActLevelDialog.OnActLevelSelectorListener;
import com.sportq.fit.middlelib.MiddleManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;

public class PerfectDietActivity extends BaseActivity
{
  public static final String CUR_JUMP = "cur.jump";
  TextView birth_select;
  private String currentDate;
  private String currentJump;
  private int getPos;
  private int height = 0;
  TextView height_select;
  private String[] itemList = { "取消", "确定" };
  TextView next_btn;
  private String phyLevel = "1";
  TextView power_level;
  CustomToolBar toolBar;
  private String userBirthday = "";
  private float weight = 0.0F;
  TextView weight_select;

  private void checkNextStep()
  {
    boolean bool;
    int i;
    label59: TextView localTextView2;
    if ((!StringUtils.isNull(this.userBirthday)) && (this.height > 0) && (this.weight > 0.0F) && (!StringUtils.isNull(this.power_level.getText().toString())))
    {
      bool = true;
      TextView localTextView1 = this.next_btn;
      if (!bool)
        break label104;
      i = R.color.color_dbb76a;
      localTextView1.setBackgroundResource(i);
      localTextView2 = this.next_btn;
      if (!bool)
        break label111;
    }
    label104: label111: for (int j = R.color.color_313131; ; j = R.color.color_828282)
    {
      localTextView2.setTextColor(ContextCompat.getColor(this, j));
      this.next_btn.setEnabled(bool);
      return;
      bool = false;
      break;
      i = R.color.color_1affffff;
      break label59;
    }
  }

  private void initView()
  {
    this.toolBar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.toolBar.setNavIcon(-1);
    this.toolBar.setTitle(getString(R.string.a_50_1_1));
    this.toolBar.setBackgroundResource(R.color.color_313131);
    this.toolBar.setTitleTextColor(-1);
    setSupportActionBar(this.toolBar);
    this.birth_select = ((TextView)findViewById(R.id.birth_select));
    this.height_select = ((TextView)findViewById(R.id.height_select));
    this.weight_select = ((TextView)findViewById(R.id.weight_select));
    this.power_level = ((TextView)findViewById(R.id.power_level));
    this.next_btn = ((TextView)findViewById(R.id.next_btn));
    TextView localTextView;
    String str2;
    if (!StringUtils.isNull(BaseApplication.userModel.phyLevel))
    {
      localTextView = this.power_level;
      if (!"1".equals(BaseApplication.userModel.phyLevel))
        break label398;
      str2 = "轻体力";
    }
    while (true)
    {
      localTextView.setText(str2);
      this.phyLevel = BaseApplication.userModel.phyLevel;
      if (!StringUtils.isNull(BaseApplication.userModel.currentWeight))
      {
        this.weight_select.setText(BaseApplication.userModel.currentWeight + "kg");
        this.weight = Float.valueOf(BaseApplication.userModel.currentWeight).floatValue();
      }
      if (!StringUtils.isNull(BaseApplication.userModel.height))
      {
        this.height_select.setText(BaseApplication.userModel.height + "cm");
        this.height = Integer.valueOf(BaseApplication.userModel.height).intValue();
      }
      if (!StringUtils.isNull(BaseApplication.userModel.birthday))
      {
        int[] arrayOfInt = splitAge(BaseApplication.userModel.birthday);
        String str1 = arrayOfInt[0] + "年" + arrayOfInt[1] + "月" + arrayOfInt[2] + "日";
        this.birth_select.setText(str1);
        this.userBirthday = BaseApplication.userModel.birthday;
      }
      this.next_btn.setTag(Boolean.valueOf(false));
      return;
      label398: if ("2".equals(BaseApplication.userModel.phyLevel))
      {
        str2 = "中体力";
        continue;
      }
      str2 = "重体力";
    }
  }

  private void showDataDialog()
  {
    SelectDateDialog localSelectDateDialog = new SelectDateDialog(this).setColors(R.color.color_dbb76a, R.color.color_313131, R.color.color_e6e6e6, R.color.color_626262);
    4 local4 = new SelectDateDialog.DateSelectorListener()
    {
      public void onSelect(String paramString)
      {
        int[] arrayOfInt = PerfectDietActivity.this.splitAge(paramString);
        String str1 = arrayOfInt[0] + "-" + arrayOfInt[1] + "-" + arrayOfInt[2];
        Date localDate = new Date();
        SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-M-d", new Locale("zh", "CN"));
        String str2 = localSimpleDateFormat.format(localDate);
        try
        {
          long l = localSimpleDateFormat.parse(str2).getTime();
          if (localSimpleDateFormat.parse(str1).getTime() <= l)
          {
            String str3 = arrayOfInt[0] + "年" + arrayOfInt[1] + "月" + arrayOfInt[2] + "日";
            PerfectDietActivity.this.birth_select.setText(str3);
            PerfectDietActivity.access$502(PerfectDietActivity.this, PerfectDietActivity.this.splitDate(str3));
            PerfectDietActivity.this.checkNextStep();
            return;
          }
          ToastUtils.makeToast(PerfectDietActivity.this, PerfectDietActivity.this.getString(R.string.re_enter_age));
          return;
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
        }
      }
    };
    if (StringUtils.isNull(this.userBirthday));
    for (String str = "1990.06.01"; ; str = this.userBirthday)
    {
      localSelectDateDialog.createDialog(local4, str);
      return;
    }
  }

  private int[] splitAge(String paramString)
  {
    int[] arrayOfInt = new int[3];
    String[] arrayOfString = paramString.split("\\.");
    arrayOfInt[0] = Integer.parseInt(arrayOfString[0]);
    arrayOfInt[1] = Integer.parseInt(arrayOfString[1]);
    arrayOfInt[2] = Integer.parseInt(arrayOfString[2]);
    return arrayOfInt;
  }

  private String splitDate(String paramString)
  {
    int[] arrayOfInt = splitAge(paramString.replace("年", ".").replace("月", ".").replace("日", "."));
    if (arrayOfInt[1] < 10)
    {
      if (arrayOfInt[2] < 10)
        return arrayOfInt[0] + "." + "0" + arrayOfInt[1] + "." + "0" + arrayOfInt[2];
      return arrayOfInt[0] + "." + "0" + arrayOfInt[1] + "." + arrayOfInt[2];
    }
    if (arrayOfInt[2] < 10)
      return arrayOfInt[0] + "." + arrayOfInt[1] + "." + "0" + arrayOfInt[2];
    return arrayOfInt[0] + "." + arrayOfInt[1] + "." + arrayOfInt[2];
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.birth_select)
      showDataDialog();
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() == R.id.height_select)
      {
        new SelectWeightDialog(this).createDialog(String.valueOf(this.height), 1, new SelectWeightDialog.OnCitySelectorListener()
        {
          public void onCancel()
          {
            PerfectDietActivity.this.checkNextStep();
          }

          public void onSelect(String paramString)
          {
            PerfectDietActivity.this.height_select.setText(String.valueOf(paramString + "cm"));
            PerfectDietActivity.access$002(PerfectDietActivity.this, StringUtils.string2Int(paramString));
            PerfectDietActivity.this.checkNextStep();
          }
        }
        , this.itemList);
        continue;
      }
      if (paramView.getId() == R.id.weight_select)
      {
        new SelectWeightDialog(this).createDialog(String.valueOf(this.weight), 0, new SelectWeightDialog.OnCitySelectorListener()
        {
          public void onCancel()
          {
            PerfectDietActivity.this.checkNextStep();
          }

          public void onSelect(String paramString)
          {
            PerfectDietActivity.this.weight_select.setText(String.valueOf(paramString + "kg"));
            PerfectDietActivity.access$202(PerfectDietActivity.this, Float.valueOf(paramString).floatValue());
            PerfectDietActivity.this.checkNextStep();
          }
        }
        , this.itemList);
        continue;
      }
      if (paramView.getId() == R.id.power_level)
      {
        new SelectPhyActLevelDialog().createDialog(new SelectPhyActLevelDialog.OnActLevelSelectorListener()
        {
          public void onSelect(String paramString)
          {
            TextView localTextView = PerfectDietActivity.this.power_level;
            String str;
            if ("1".equals(paramString))
              str = "轻体力";
            while (true)
            {
              localTextView.setText(str);
              PerfectDietActivity.access$302(PerfectDietActivity.this, paramString);
              PerfectDietActivity.this.checkNextStep();
              return;
              if ("2".equals(paramString))
              {
                str = "中体力";
                continue;
              }
              str = "重体力";
            }
          }
        }
        , this, this.phyLevel);
        continue;
      }
      if (paramView.getId() != R.id.next_btn)
        continue;
      RequestModel localRequestModel = new RequestModel();
      if (!this.userBirthday.equals(BaseApplication.userModel.birthday))
      {
        localRequestModel.birthday = splitDate(this.birth_select.getText().toString());
        this.next_btn.setTag(Boolean.valueOf(true));
      }
      if (!String.valueOf(this.height).equals(BaseApplication.userModel.height))
      {
        localRequestModel.height = String.valueOf(this.height);
        this.next_btn.setTag(Boolean.valueOf(true));
      }
      if (!String.valueOf(this.weight).equals(BaseApplication.userModel.currentWeight))
      {
        localRequestModel.currentWeight = String.valueOf(this.weight);
        this.next_btn.setTag(Boolean.valueOf(true));
      }
      if (!this.phyLevel.equals(BaseApplication.userModel.phyLevel))
      {
        localRequestModel.phyLevel = this.phyLevel;
        this.next_btn.setTag(Boolean.valueOf(true));
      }
      if (Boolean.valueOf(this.next_btn.getTag().toString()).booleanValue())
      {
        this.dialog.createProgressDialog(this, "请稍后...");
        MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(localRequestModel, this);
        continue;
      }
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      ToastUtils.makeToast(this, "完成更改");
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.next_btn.setTag(Boolean.valueOf(false));
    this.dialog.closeDialog();
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ("Y".equals(paramT));
    try
    {
      Thread.sleep(1000L);
      this.dialog.closeDialog();
      EventBus.getDefault().post("perfect_diet_info");
      if ("0".equals(this.currentJump))
      {
        Intent localIntent = new Intent(this, DietRecommendActivity.class);
        localIntent.putExtra("cur.date", this.currentDate);
        localIntent.putExtra("cur.pos", this.getPos);
        localIntent.putExtra("cur.jump", this.currentJump);
        startActivity(localIntent);
        finish();
        AnimationUtil.pageJumpAnim(this, 0);
      }
      while (true)
      {
        super.getDataSuccess(paramT);
        return;
        finish();
        AnimationUtil.pageJumpAnim(this, 1);
        ToastUtils.makeToast(this, "更改完成");
      }
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.perfect_diet_layout);
    this.dialog = new DialogManager();
    initView();
    this.currentDate = getIntent().getStringExtra("cur.date");
    this.getPos = getIntent().getIntExtra("cur.pos", 0);
    this.currentJump = getIntent().getStringExtra("cur.jump");
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.PerfectDietActivity
 * JD-Core Version:    0.6.0
 */