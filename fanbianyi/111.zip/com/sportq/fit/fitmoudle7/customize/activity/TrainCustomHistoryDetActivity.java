package com.sportq.fit.fitmoudle7.customize.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer;
import com.sportq.fit.fitmoudle7.customize.widget.CustomizeWeekStatisticalView;
import java.util.ArrayList;
import java.util.Iterator;

public class TrainCustomHistoryDetActivity extends BaseActivity
{
  private String customId;
  private ImageView hisDetBackImage;
  private RelativeLayout hisDetExitResContent;
  private TextView hisDetExitResText;
  private TextView hisDetFinishTrains;
  private RelativeLayout hisDetHead;
  private TextView hisDetTotalCom;
  private TextView hisDetTrainDays;
  private LinearLayout hisDetWeeksLinear;
  private TextView hisDetWeeksTitle;
  private CustomToolBar toolbar;

  private void initView()
  {
    if (!StringUtils.isNull(this.customId))
    {
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.customId = this.customId;
      new CustomPresenterImpl(this).getCusHistoryDet(localRequestModel, this);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if ((paramT instanceof CustomizeReformer))
    {
      CustomizeReformer localCustomizeReformer = (CustomizeReformer)paramT;
      this.toolbar.setTitle(localCustomizeReformer.entCusData.curriculumName);
      GlideUtils.loadImgByDefault(localCustomizeReformer.entCusData.imageURL, R.mipmap.img_default, this.hisDetBackImage);
      this.hisDetTrainDays.setText(localCustomizeReformer.entCusData.customDays);
      this.hisDetFinishTrains.setText(localCustomizeReformer.entCusData.finishNum);
      this.hisDetTotalCom.setText(localCustomizeReformer.entCusData.calorie);
      TextView localTextView = this.hisDetWeeksTitle;
      StringBuilder localStringBuilder = new StringBuilder().append(localCustomizeReformer.entCusData.trainNum);
      Object[] arrayOfObject;
      if (!StringUtils.isNull(localCustomizeReformer.entCusData.apparatus))
      {
        arrayOfObject = new Object[1];
        arrayOfObject[0] = localCustomizeReformer.entCusData.apparatus;
      }
      for (String str = String.format("（器械：%s）", arrayOfObject); ; str = "")
      {
        localTextView.setText(String.valueOf(str));
        this.hisDetWeeksLinear.removeViews(2, -2 + this.hisDetWeeksLinear.getChildCount());
        Iterator localIterator = localCustomizeReformer.lstCusWeek.iterator();
        while (localIterator.hasNext())
        {
          CustomizeModel.CustomDataEntity localCustomDataEntity = (CustomizeModel.CustomDataEntity)localIterator.next();
          CustomizeWeekStatisticalView localCustomizeWeekStatisticalView = new CustomizeWeekStatisticalView(this);
          localCustomizeWeekStatisticalView.setWeekStatValue(localCustomDataEntity, 2);
          localCustomizeWeekStatisticalView.setCustomId(this.customId);
          this.hisDetWeeksLinear.addView(localCustomizeWeekStatisticalView);
        }
      }
      if (!StringUtils.isNull(localCustomizeReformer.entCusData.exitComment))
      {
        this.hisDetExitResContent.setVisibility(0);
        this.hisDetExitResText.setText(localCustomizeReformer.entCusData.exitComment);
      }
    }
    else
    {
      return;
    }
    this.hisDetExitResContent.setVisibility(8);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.traincus_history_det);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.hisDetHead = ((RelativeLayout)findViewById(R.id.his_det_head));
    this.hisDetBackImage = ((ImageView)findViewById(R.id.his_det_backImage));
    this.hisDetTrainDays = ((TextView)findViewById(R.id.his_det_trainDays));
    this.hisDetFinishTrains = ((TextView)findViewById(R.id.his_det_finishTrains));
    this.hisDetTotalCom = ((TextView)findViewById(R.id.his_det_totalCom));
    this.hisDetWeeksTitle = ((TextView)findViewById(R.id.his_det_weeksTitle));
    this.hisDetWeeksLinear = ((LinearLayout)findViewById(R.id.his_det_weeksLinear));
    this.hisDetExitResText = ((TextView)findViewById(R.id.his_det_exitResText));
    this.hisDetExitResContent = ((RelativeLayout)findViewById(R.id.his_det_exitResContent));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle("");
    this.toolbar.setBackgroundResource(R.color.white);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    setSupportActionBar(this.toolbar);
    this.hisDetTrainDays.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.hisDetFinishTrains.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.hisDetTotalCom.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-1, (int)(0.638D * BaseApplication.screenWidth));
    this.hisDetHead.setLayoutParams(localLayoutParams);
    if (getIntent() != null)
      this.customId = getIntent().getStringExtra("his_click_customId");
    initView();
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.TrainCustomHistoryDetActivity
 * JD-Core Version:    0.6.0
 */