package com.sportq.fit.fitmoudle7.customize.activity.fat_camp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.UserCampReformer;
import com.sportq.fit.fitmoudle7.customize.widget.PrinterTextView;
import com.sportq.fit.fitmoudle7.customize.widget.PrinterTextView.TextAnimationListener;
import com.sportq.fit.middlelib.statistics.FitAction;

public class FatCampWelcomeActivity extends BaseActivity
{
  public static final String KEY_WELCOME_INTRODUCE = "WELCOME_INTRODUCE";
  public static final String LOSE_FAT_ID = "lose.fat.id";
  private ImageView fat_camp_go_img;
  private PrinterTextView fat_camp_introduce;
  private PrinterTextView fat_camp_ready;
  private PrinterTextView fat_camp_user_name;
  private ImageView fat_camp_welcome_img;
  private String strResult = "";

  private void iconAnimationShow(ImageView paramImageView)
  {
    ScaleAnimation localScaleAnimation = new ScaleAnimation(1.3F, 1.0F, 1.3F, 1.0F, 1, 0.5F, 1, 0.5F);
    localScaleAnimation.setDuration(700L);
    paramImageView.startAnimation(localScaleAnimation);
    localScaleAnimation.setAnimationListener(new Animation.AnimationListener(paramImageView)
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        this.val$view.setVisibility(0);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
  }

  private void transAnimation()
  {
    TranslateAnimation localTranslateAnimation = new TranslateAnimation(0.0F, 0.0F, -(int)(0.8694D * BaseApplication.screenWidth), 0.0F);
    localTranslateAnimation.setDuration(1000L);
    this.fat_camp_welcome_img.startAnimation(localTranslateAnimation);
    localTranslateAnimation.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        FatCampWelcomeActivity.this.fat_camp_welcome_img.clearAnimation();
        FatCampWelcomeActivity.this.fat_camp_user_name.setVisibility(0);
        PrinterTextView localPrinterTextView = FatCampWelcomeActivity.this.fat_camp_user_name;
        int i = R.string.a_29_1_1;
        String[] arrayOfString = new String[1];
        arrayOfString[0] = BaseApplication.userModel.userName;
        localPrinterTextView.setTextString(UseStringUtils.getStr(i, arrayOfString)).setDuration(1000).startFadeInAnimation().setTextAnimationListener(new PrinterTextView.TextAnimationListener()
        {
          public void animationFinish()
          {
            FatCampWelcomeActivity.this.fat_camp_introduce.setVisibility(0);
            FatCampWelcomeActivity.this.fat_camp_introduce.setTextString(FatCampWelcomeActivity.this.strResult).setDuration(1500).startFadeInAnimation().setTextAnimationListener(new PrinterTextView.TextAnimationListener()
            {
              public void animationFinish()
              {
                FatCampWelcomeActivity.this.fat_camp_ready.setVisibility(0);
                FatCampWelcomeActivity.this.fat_camp_ready.setTextString(FatCampWelcomeActivity.this.getString(R.string.a_29_1_3)).setDuration(500).startFadeInAnimation().setTextAnimationListener(new PrinterTextView.TextAnimationListener()
                {
                  public void animationFinish()
                  {
                    FatCampWelcomeActivity.this.iconAnimationShow(FatCampWelcomeActivity.this.fat_camp_go_img);
                  }
                });
              }
            });
          }
        });
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.fat_camp_welcome_back)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() != R.id.fat_camp_go_img)
        continue;
      new CustomPresenterImpl(this).getUserCampComplete(this);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (isFinishing());
    do
    {
      return;
      if (this.dialog == null)
        continue;
      this.dialog.closeDialog();
    }
    while (!(paramT instanceof UserCampReformer));
    if ("0".equals(((UserCampReformer)paramT).isComplete))
    {
      new DialogManager().appHintDialog(null, this, R.mipmap.fat_camp_icn_lovecapital, getString(R.string.a_30_2_1), getString(R.string.a_30_2_2));
      return;
    }
    Intent localIntent = new Intent(this, FatCampDetailActivity.class);
    if (getIntent() != null)
      localIntent.putExtra("lose.fat.id", getIntent().getStringExtra("lose.fat.id"));
    startActivity(localIntent);
    finish();
    AnimationUtil.pageJumpAnim(this, 0);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.fat_camp_welcome_layout);
    this.fat_camp_welcome_img = ((ImageView)findViewById(R.id.fat_camp_welcome_img));
    this.fat_camp_user_name = ((PrinterTextView)findViewById(R.id.fat_camp_user_name));
    this.fat_camp_introduce = ((PrinterTextView)findViewById(R.id.fat_camp_introduce));
    this.fat_camp_ready = ((PrinterTextView)findViewById(R.id.fat_camp_ready));
    this.fat_camp_go_img = ((ImageView)findViewById(R.id.fat_camp_go_img));
    this.fat_camp_go_img.setOnClickListener(new FitAction(this));
    this.dialog = new DialogManager();
    RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)this.fat_camp_welcome_img.getLayoutParams();
    localLayoutParams.width = (int)(0.8333D * BaseApplication.screenWidth);
    localLayoutParams.height = (int)(0.8694D * BaseApplication.screenWidth);
    String str = getIntent().getStringExtra("WELCOME_INTRODUCE");
    if (StringUtils.isNull(str))
      str = getString(R.string.a_29_1_2);
    this.fat_camp_introduce.setText(str);
    this.fat_camp_introduce.post(new Runnable()
    {
      public void run()
      {
        TextView localTextView = (TextView)FatCampWelcomeActivity.this.findViewById(R.id.fat_camp_introduce);
        Layout localLayout = localTextView.getLayout();
        int i = localTextView.getLayout().getLineCount();
        String str = localLayout.getText().toString();
        for (int j = 0; j < i - 1; j++)
        {
          int i1 = localLayout.getLineStart(j);
          int i2 = localLayout.getLineEnd(j);
          FatCampWelcomeActivity.access$002(FatCampWelcomeActivity.this, FatCampWelcomeActivity.this.strResult + str.substring(i1, i2) + "\n");
        }
        int k = localLayout.getLineStart(i - 1);
        int m = localLayout.getLineEnd(i - 1);
        FatCampWelcomeActivity.access$002(FatCampWelcomeActivity.this, FatCampWelcomeActivity.this.strResult + str.substring(k, m));
        int n = FatCampWelcomeActivity.this.fat_camp_introduce.getHeight();
        ((LinearLayout.LayoutParams)FatCampWelcomeActivity.this.fat_camp_introduce.getLayoutParams()).height = n;
      }
    });
    transAnimation();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampWelcomeActivity
 * JD-Core Version:    0.6.0
 */