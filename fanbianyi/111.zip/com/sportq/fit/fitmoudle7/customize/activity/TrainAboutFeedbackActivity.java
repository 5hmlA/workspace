package com.sportq.fit.fitmoudle7.customize.activity;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.MenuItem;
import android.widget.ImageView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;

public class TrainAboutFeedbackActivity extends BaseActivity
{
  private ImageView about_feedBack_bg;
  private CustomToolBar toolbar;

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.trainaboutfeedback);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.about_feedBack_bg = ((ImageView)findViewById(R.id.about_feedBack_bg));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(getString(R.string.a_26_1));
    this.toolbar.setBackgroundResource(R.color.white);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    setSupportActionBar(this.toolbar);
    ImageView localImageView = this.about_feedBack_bg;
    if ("0".equals(BaseApplication.userModel.userSex));
    for (int i = R.mipmap.bg_about_feedback_man; ; i = R.mipmap.bg_about_feedback_woman)
    {
      localImageView.setImageResource(i);
      return;
    }
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.TrainAboutFeedbackActivity
 * JD-Core Version:    0.6.0
 */