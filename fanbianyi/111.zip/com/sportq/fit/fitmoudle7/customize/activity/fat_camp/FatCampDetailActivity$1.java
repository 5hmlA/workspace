package com.sportq.fit.fitmoudle7.customize.activity.fat_camp;

import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.LoseFatPlanReformer;
import com.sportq.fit.v25.design.AppBarLayout;
import com.sportq.fit.v25.design.AppBarLayout.OnOffsetChangedListener;
import com.sportq.fit.v25.design.CollapsingToolbarLayout;

class FatCampDetailActivity$1
  implements AppBarLayout.OnOffsetChangedListener
{
  public void onOffsetChanged(AppBarLayout paramAppBarLayout, int paramInt)
  {
    if (Math.abs(paramInt) >= paramAppBarLayout.getTotalScrollRange())
      if ((FatCampDetailActivity.access$000(this.this$0) != null) && ((this.val$collapsingToolbarLayout.getTitle() == null) || (StringUtils.isNull(this.val$collapsingToolbarLayout.getTitle().toString()))))
        this.val$collapsingToolbarLayout.setTitle(FatCampDetailActivity.access$000(this.this$0).entLoseFatData.classTitle);
    do
      return;
    while ((this.val$collapsingToolbarLayout.getTitle() == null) || (StringUtils.isNull(this.val$collapsingToolbarLayout.getTitle().toString())));
    this.val$collapsingToolbarLayout.setTitle("");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampDetailActivity.1
 * JD-Core Version:    0.6.0
 */