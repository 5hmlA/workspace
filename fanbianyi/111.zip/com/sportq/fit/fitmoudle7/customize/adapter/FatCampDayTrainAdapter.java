package com.sportq.fit.fitmoudle7.customize.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.google.gson.Gson;
import com.sportq.fit.common.model.EntdayPlanData;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView.DetailsBtnInterface;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatPlanData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EnttrainPlanData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.LoseFatPlanReformer;
import java.util.ArrayList;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class FatCampDayTrainAdapter extends SuperAdapter<EnttrainPlanData>
{
  private EntloseFatPlanData entloseFatPlanData;
  public String fatCampId;
  public Context mContext;

  public FatCampDayTrainAdapter(Context paramContext, int paramInt1, LoseFatPlanReformer paramLoseFatPlanReformer, int paramInt2)
  {
    super(paramContext, ((EntloseFatPlanData)paramLoseFatPlanReformer.lstLoseFatPlan.get(paramInt2)).lstTrainPlan, paramInt1);
    this.fatCampId = paramLoseFatPlanReformer.entLoseFatData.loseFatId;
    this.entloseFatPlanData = ((EntloseFatPlanData)paramLoseFatPlanReformer.lstLoseFatPlan.get(paramInt2));
  }

  private PlanModel convertData(EntdayPlanData paramEntdayPlanData)
  {
    Gson localGson = new Gson();
    return (PlanModel)localGson.fromJson(localGson.toJson(paramEntdayPlanData), PlanModel.class);
  }

  public EntloseFatPlanData getEntloseFatPlanData()
  {
    return this.entloseFatPlanData;
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, EnttrainPlanData paramEnttrainPlanData)
  {
    LinearLayout localLinearLayout1 = (LinearLayout)paramSuperViewHolder.findViewById(R.id.train_layout);
    LinearLayout localLinearLayout2 = (LinearLayout)paramSuperViewHolder.findViewById(R.id.empty_layout);
    if ("3".equals(this.entloseFatPlanData.isTrainDay))
    {
      localLinearLayout2.setVisibility(0);
      localLinearLayout1.setVisibility(8);
      ((LinearLayout)paramSuperViewHolder.findViewById(R.id.parent_layout)).setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
      return;
    }
    ((TextView)paramSuperViewHolder.findViewById(R.id.train_title)).setText(paramEnttrainPlanData.trainTimeComment);
    LinearLayout localLinearLayout3 = (LinearLayout)paramSuperViewHolder.findViewById(R.id.train_view_layout);
    localLinearLayout3.removeAllViews();
    localLinearLayout3.setWeightSum(paramEnttrainPlanData.lstDayPlan.size());
    for (int i = 0; i < paramEnttrainPlanData.lstDayPlan.size(); i++)
    {
      SinglePlanTrainView localSinglePlanTrainView = new SinglePlanTrainView(getContext());
      EntdayPlanData localEntdayPlanData = (EntdayPlanData)paramEnttrainPlanData.lstDayPlan.get(i);
      PlanModel localPlanModel = convertData(localEntdayPlanData);
      localSinglePlanTrainView.initView(localPlanModel, 8);
      localSinglePlanTrainView.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));
      localSinglePlanTrainView.setTag(localEntdayPlanData.planId);
      localSinglePlanTrainView.setCountDownTime(localPlanModel, null);
      localSinglePlanTrainView.setDetailsBtnInterface(new SinglePlanTrainView.DetailsBtnInterface(localEntdayPlanData)
      {
        public void contentClick()
        {
          if ("0".equals(this.val$entdayPlanData.stateCode))
            FitJumpImpl.getInstance().fatCampJumpCourseDetail(FatCampDayTrainAdapter.this.getContext(), FatCampDayTrainAdapter.this.fatCampId, this.val$entdayPlanData.customDetailId, this.val$entdayPlanData.planId, FatCampDayTrainAdapter.this.entloseFatPlanData.weekId, "hide", this.val$entdayPlanData.trainableDay);
          do
          {
            return;
            if (!"1".equals(this.val$entdayPlanData.stateCode))
              continue;
            FitJumpImpl.getInstance().fatCampJumpCourseDetail(FatCampDayTrainAdapter.this.getContext(), FatCampDayTrainAdapter.this.fatCampId, this.val$entdayPlanData.customDetailId, this.val$entdayPlanData.planId, FatCampDayTrainAdapter.this.entloseFatPlanData.weekId, "", this.val$entdayPlanData.trainableDay);
            return;
          }
          while (!"2".equals(this.val$entdayPlanData.stateCode));
          FitJumpImpl.getInstance().jumpRecordDetail(FatCampDayTrainAdapter.this.getContext(), this.val$entdayPlanData, FatCampDayTrainAdapter.this.entloseFatPlanData.weekId, FatCampDayTrainAdapter.this.fatCampId);
        }

        public void detailBtnClick()
        {
        }
      });
      localLinearLayout3.addView(localSinglePlanTrainView);
      if (i == -1 + paramEnttrainPlanData.lstDayPlan.size())
        continue;
      View localView1 = new View(getContext());
      LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(getContext(), 0.5F));
      localView1.setBackgroundResource(R.color.color_e6e6e6);
      localView1.setLayoutParams(localLayoutParams1);
      localLinearLayout3.addView(localView1);
      View localView2 = new View(getContext());
      LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(getContext(), 10.0F));
      localView2.setBackgroundResource(R.color.transparent);
      localView2.setLayoutParams(localLayoutParams2);
      localLinearLayout3.addView(localView2);
    }
    localLinearLayout2.setVisibility(8);
    localLinearLayout1.setVisibility(0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.adapter.FatCampDayTrainAdapter
 * JD-Core Version:    0.6.0
 */