package com.sportq.fit.fitmoudle7.customize.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;
import android.view.ViewGroup;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstMonthCusData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomPlanReformer;
import com.sportq.fit.fitmoudle7.customize.widget.CustomDietView;
import com.sportq.fit.fitmoudle7.customize.widget.CustomKnowledgeView;
import com.sportq.fit.fitmoudle7.customize.widget.CustomTrainView;
import java.util.ArrayList;

public class CustomDayTrainAdapter extends RecyclerView.Adapter
{
  private int cPos;
  public String customId;
  public EntlstMonthCusData data;
  public Context mContext;
  public CustomPlanReformer reformer;

  public CustomDayTrainAdapter(Context paramContext, CustomPlanReformer paramCustomPlanReformer, int paramInt)
  {
    this.mContext = paramContext;
    this.reformer = paramCustomPlanReformer;
    this.data = ((EntlstMonthCusData)paramCustomPlanReformer.lstMonthCus.get(paramInt));
    this.customId = paramCustomPlanReformer.entCusData.customId;
    this.cPos = paramInt;
  }

  public EntlstMonthCusData getData()
  {
    return this.data;
  }

  public int getItemCount()
  {
    if (("3".equals(BaseApplication.userModel.isVip)) && (this.cPos > 6))
      return 1;
    return 3;
  }

  public int getItemViewType(int paramInt)
  {
    return paramInt;
  }

  public boolean getShowShareState()
  {
    return (this.data != null) && ("1".equals(this.data.isFinish)) && (this.data.cusDate.equals(DateUtils.StringToFormat(String.valueOf(System.currentTimeMillis()), "yyyy-MM-dd")));
  }

  public void onBindViewHolder(RecyclerView.ViewHolder paramViewHolder, int paramInt)
  {
    if ((paramViewHolder instanceof CustomOpenVipViewHolder))
      return;
    if ((paramViewHolder instanceof CustomTrainViewHolder))
    {
      CustomTrainViewHolder localCustomTrainViewHolder = (CustomTrainViewHolder)paramViewHolder;
      localCustomTrainViewHolder.customTrainView.initData(localCustomTrainViewHolder.customTrainView, this.data);
      return;
    }
    if ((paramViewHolder instanceof CustomDietViewHolder))
    {
      ((CustomDietViewHolder)paramViewHolder).customDietView.initData(this.data);
      return;
    }
    ((CustomDayKnowledgeViewHolder)paramViewHolder).customKnowledgeView.initData(this.data.lstCusTopic);
  }

  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt)
  {
    if (("3".equals(BaseApplication.userModel.isVip)) && (this.cPos > 6))
      return new CustomOpenVipViewHolder(View.inflate(this.mContext, R.layout.custom_open_vip_view, null));
    if (paramInt == 0)
    {
      CustomTrainView localCustomTrainView = new CustomTrainView(this.mContext, this.data, this.customId);
      localCustomTrainView.setClickListener((CustomDetailActivity)this.mContext);
      return new CustomTrainViewHolder(localCustomTrainView);
    }
    if (paramInt == 1)
      return new CustomDietViewHolder(new CustomDietView(this.mContext));
    return new CustomDayKnowledgeViewHolder(new CustomKnowledgeView(this.mContext));
  }

  public void setData(EntlstMonthCusData paramEntlstMonthCusData)
  {
    this.data = paramEntlstMonthCusData;
  }

  private static class CustomDayKnowledgeViewHolder extends RecyclerView.ViewHolder
  {
    private CustomKnowledgeView customKnowledgeView;

    CustomDayKnowledgeViewHolder(View paramView)
    {
      super();
      this.customKnowledgeView = ((CustomKnowledgeView)paramView);
    }
  }

  private static class CustomDietViewHolder extends RecyclerView.ViewHolder
  {
    private CustomDietView customDietView;

    CustomDietViewHolder(View paramView)
    {
      super();
      this.customDietView = ((CustomDietView)paramView);
    }
  }

  private static class CustomOpenVipViewHolder extends RecyclerView.ViewHolder
  {
    CustomOpenVipViewHolder(View paramView)
    {
      super();
    }
  }

  private static class CustomTrainViewHolder extends RecyclerView.ViewHolder
  {
    private CustomTrainView customTrainView;

    CustomTrainViewHolder(View paramView)
    {
      super();
      this.customTrainView = ((CustomTrainView)paramView);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.adapter.CustomDayTrainAdapter
 * JD-Core Version:    0.6.0
 */