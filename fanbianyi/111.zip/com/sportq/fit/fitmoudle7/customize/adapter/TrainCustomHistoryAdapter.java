package com.sportq.fit.fitmoudle7.customize.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView.DetailsBtnInterface;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.customize.activity.TrainCustomHistoryDetActivity;
import java.util.ArrayList;

public class TrainCustomHistoryAdapter extends RecyclerView.Adapter
{
  private ArrayList<PlanModel> list;
  private Context mContext;

  public TrainCustomHistoryAdapter(Context paramContext)
  {
    this.mContext = paramContext;
  }

  public int getItemCount()
  {
    return this.list.size();
  }

  public void onBindViewHolder(RecyclerView.ViewHolder paramViewHolder, int paramInt)
  {
    if ((paramViewHolder instanceof TrainViewHolder))
    {
      ((TrainViewHolder)paramViewHolder).singlePlanTrainView.initView((PlanModel)this.list.get(paramInt), 7);
      ((TrainViewHolder)paramViewHolder).singlePlanTrainView.setDetailsBtnInterface(new SinglePlanTrainView.DetailsBtnInterface(paramInt)
      {
        public void contentClick()
        {
          Intent localIntent = new Intent(TrainCustomHistoryAdapter.this.mContext, TrainCustomHistoryDetActivity.class);
          localIntent.putExtra("his_click_customId", ((PlanModel)TrainCustomHistoryAdapter.this.list.get(this.val$position)).customDetailId);
          TrainCustomHistoryAdapter.this.mContext.startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)TrainCustomHistoryAdapter.this.mContext, 0);
        }

        public void detailBtnClick()
        {
        }
      });
    }
  }

  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt)
  {
    return new TrainViewHolder(LayoutInflater.from(this.mContext).inflate(R.layout.custom_history_list_item, null));
  }

  public void setList(ArrayList<PlanModel> paramArrayList)
  {
    this.list = paramArrayList;
  }

  static class TrainViewHolder extends RecyclerView.ViewHolder
  {
    private SinglePlanTrainView singlePlanTrainView;

    TrainViewHolder(View paramView)
    {
      super();
      this.singlePlanTrainView = ((SinglePlanTrainView)paramView.findViewById(R.id.history_item_single));
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.adapter.TrainCustomHistoryAdapter
 * JD-Core Version:    0.6.0
 */