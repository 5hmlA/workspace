package com.sportq.fit.fitmoudle7.customize.widget.Calendar;

import com.sportq.fit.common.model.PlanModel;
import java.util.ArrayList;

public class CalendarDayEntity
{
  public String classifyId;
  public String dateString;
  public String dayNum;
  public String feedBackComment;
  public boolean isDaysOfTrainWeek;
  public boolean isFeedBack;
  public boolean isFeedBackDay;
  public boolean isFinish;
  public int isPastOrFurWeek;
  public boolean isToday;
  public String isTrainDay;
  public ArrayList<PlanModel> lstDayPlan;
  public String monthTitle;
  public String weekId;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.Calendar.CalendarDayEntity
 * JD-Core Version:    0.6.0
 */