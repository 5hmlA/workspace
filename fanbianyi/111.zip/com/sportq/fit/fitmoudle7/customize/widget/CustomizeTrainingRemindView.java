package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.Switch;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.SelectTimeDialog;
import com.sportq.fit.fitmoudle.dialogmanager.SelectTimeDialog.TimeSelectorListener;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;

public class CustomizeTrainingRemindView extends LinearLayout
{
  private Context mContext;
  private Switch remindSwitch;
  private TextView train11RemindTime;
  private TextView trainRemindText;

  public CustomizeTrainingRemindView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeTrainingRemindView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeTrainingRemindView(Context paramContext, DialogInterface paramDialogInterface)
  {
    super(paramContext);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(R.layout.train_remind_view, null);
    this.trainRemindText = ((TextView)localView.findViewById(R.id.train11_remind));
    this.train11RemindTime = ((TextView)localView.findViewById(R.id.train11_remindTime));
    this.remindSwitch = ((Switch)localView.findViewById(R.id.train11_remindSwitch));
    this.train11RemindTime.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        new SelectTimeDialog(CustomizeTrainingRemindView.this.mContext).setColors(R.color.color_dbb76a, R.color.color_313131, R.color.color_e6e6e6, R.color.color_626262).createDialog(new SelectTimeDialog.TimeSelectorListener()
        {
          public void onSelect(String paramString)
          {
            CustomizeTrainingRemindView.this.train11RemindTime.setText(paramString);
          }
        }
        , (String)CustomizeTrainingRemindView.this.train11RemindTime.getText());
      }
    });
    this.remindSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
    {
      @Instrumented
      public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
      {
        VdsAgent.onCheckedChanged(this, paramCompoundButton, paramBoolean);
        if (paramBoolean)
        {
          CustomizeTrainingRemindView.this.train11RemindTime.setTextColor(ContextCompat.getColor(CustomizeTrainingRemindView.this.mContext, R.color.color_313131));
          CustomizeTrainingRemindView.this.trainRemindText.setTextColor(ContextCompat.getColor(CustomizeTrainingRemindView.this.mContext, R.color.color_313131));
          CustomizeTrainingRemindView.this.train11RemindTime.setEnabled(true);
          return;
        }
        CustomizeTrainingRemindView.this.train11RemindTime.setTextColor(ContextCompat.getColor(CustomizeTrainingRemindView.this.mContext, R.color.color_c8c8c8));
        CustomizeTrainingRemindView.this.trainRemindText.setTextColor(ContextCompat.getColor(CustomizeTrainingRemindView.this.mContext, R.color.color_c8c8c8));
        CustomizeTrainingRemindView.this.train11RemindTime.setEnabled(false);
      }
    });
    if (this.remindSwitch.isChecked())
    {
      this.train11RemindTime.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
      this.trainRemindText.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
      this.train11RemindTime.setEnabled(true);
    }
    while (true)
    {
      localView.setLayoutParams(new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 60.0F)));
      return localView;
      this.train11RemindTime.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_c8c8c8));
      this.trainRemindText.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_c8c8c8));
      this.train11RemindTime.setEnabled(false);
    }
  }

  public String getDialogTime()
  {
    return String.valueOf(this.train11RemindTime.getText());
  }

  public boolean getIsRemind()
  {
    return this.remindSwitch.isChecked();
  }

  public void setDialog(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == 0)
    {
      this.remindSwitch.setChecked(false);
      this.train11RemindTime.setText(String.valueOf("20:00"));
      return;
    }
    this.remindSwitch.setChecked("1".equals(BaseApplication.userModel.cusTrainFlg));
    TextView localTextView = this.train11RemindTime;
    if (!StringUtils.isNull(BaseApplication.userModel.cusTrainTime));
    for (String str = BaseApplication.userModel.cusTrainTime; ; str = "20:00")
    {
      localTextView.setText(str);
      return;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomizeTrainingRemindView
 * JD-Core Version:    0.6.0
 */