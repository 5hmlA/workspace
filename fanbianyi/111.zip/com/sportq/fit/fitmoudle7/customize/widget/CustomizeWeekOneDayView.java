package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.sportq.fit.common.model.CustomizeModel.CustomWeekEntity;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.string;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class CustomizeWeekOneDayView extends RelativeLayout
{
  private LinearLayout dataInfoLinear;
  private View dataInfoYellowTag;
  private ImageView feedBackImage;
  private Context mContext;
  private String preFlag;

  public CustomizeWeekOneDayView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeWeekOneDayView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeWeekOneDayView(Context paramContext, String paramString)
  {
    super(paramContext);
    this.mContext = paramContext;
    this.preFlag = paramString;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(R.layout.week_oneday_item_layout, null);
    this.dataInfoYellowTag = localView.findViewById(R.id.data_info_yellowTag);
    this.dataInfoLinear = ((LinearLayout)localView.findViewById(R.id.data_info_linear));
    this.feedBackImage = ((ImageView)localView.findViewById(R.id.data_feedbackIcon));
    return localView;
  }

  public void initView(CustomizeModel.CustomWeekEntity paramCustomWeekEntity, String paramString)
  {
    ImageView localImageView = this.feedBackImage;
    boolean bool = "1".equals(paramCustomWeekEntity.isFeedBackDay);
    int i = 0;
    if (bool);
    while (true)
    {
      localImageView.setVisibility(i);
      this.dataInfoLinear.removeAllViews();
      if ("1".equals(paramCustomWeekEntity.isTrainDay))
      {
        for (int j = 0; j < paramCustomWeekEntity.lstDayPlan.size(); j++)
        {
          CustomizeWeekOneCourseView localCustomizeWeekOneCourseView2 = new CustomizeWeekOneCourseView(this.mContext);
          localCustomizeWeekOneCourseView2.initView(paramCustomWeekEntity, j, paramString);
          this.dataInfoLinear.addView(localCustomizeWeekOneCourseView2);
        }
        i = 4;
        continue;
      }
      CustomizeWeekOneCourseView localCustomizeWeekOneCourseView1 = new CustomizeWeekOneCourseView(this.mContext);
      localCustomizeWeekOneCourseView1.initView(paramCustomWeekEntity);
      this.dataInfoLinear.addView(localCustomizeWeekOneCourseView1);
    }
    if (!StringUtils.isNull(paramCustomWeekEntity.curriculumDate))
      try
      {
        String str = paramCustomWeekEntity.curriculumDate;
        Calendar localCalendar = Calendar.getInstance();
        localCalendar.set(11, 0);
        localCalendar.set(12, 0);
        localCalendar.set(13, 0);
        localCalendar.set(14, 0);
        if (!str.contains(this.mContext.getString(R.string.year)))
          str = localCalendar.get(1) + this.mContext.getString(R.string.year) + str;
        if ((new SimpleDateFormat("yyyy年MM月dd日").parse(str).compareTo(localCalendar.getTime()) == 0) && (!"0".equals(this.preFlag)))
        {
          this.dataInfoYellowTag.setVisibility(0);
          return;
        }
        this.dataInfoYellowTag.setVisibility(4);
        return;
      }
      catch (ParseException localParseException)
      {
        localParseException.printStackTrace();
      }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomizeWeekOneDayView
 * JD-Core Version:    0.6.0
 */