package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;

public class CustomizePreviewHeadView extends RelativeLayout
{
  private TextView customHeadConsumption;
  private TextView customHeadDateOfInterval;
  private TextView customHeadDifficulty;
  private TextView customHeadTitle;
  private TextView customHeadTrainLengthOfDay;
  private LinearLayout customHead_content;
  private View customHead_content_alpha;
  private ImageView customHead_image;
  private Context mContext;

  public CustomizePreviewHeadView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizePreviewHeadView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizePreviewHeadView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(R.layout.customize_preview_headview, null);
    this.customHeadTitle = ((TextView)localView.findViewById(R.id.customHead_title));
    this.customHeadDateOfInterval = ((TextView)localView.findViewById(R.id.customHead_dateOfInterval));
    this.customHeadTrainLengthOfDay = ((TextView)localView.findViewById(R.id.customHead_trainLengthOfDay));
    this.customHeadConsumption = ((TextView)localView.findViewById(R.id.customHead_consumption));
    this.customHeadDifficulty = ((TextView)localView.findViewById(R.id.customHead_difficulty));
    this.customHead_image = ((ImageView)localView.findViewById(R.id.customHead_image));
    this.customHead_content_alpha = localView.findViewById(R.id.customHead_content_alpha);
    this.customHead_content = ((LinearLayout)localView.findViewById(R.id.customHead_content));
    localView.setLayoutParams(new RelativeLayout.LayoutParams(-1, (int)(0.638D * BaseApplication.screenWidth)));
    return localView;
  }

  public void setCustomizeHeadValue(CustomizeModel.CustomDataEntity paramCustomDataEntity)
  {
    if (!StringUtils.isNull(paramCustomDataEntity.curriculumName))
      this.customHeadTitle.setText(paramCustomDataEntity.curriculumName);
    if (!StringUtils.isNull(paramCustomDataEntity.curriculumDate))
      this.customHeadDateOfInterval.setText(paramCustomDataEntity.curriculumDate);
    if (!StringUtils.isNull(paramCustomDataEntity.customDays))
      this.customHeadTrainLengthOfDay.setText(paramCustomDataEntity.customDays);
    if (!StringUtils.isNull(paramCustomDataEntity.calorie))
      this.customHeadConsumption.setText(paramCustomDataEntity.calorie);
    if (!StringUtils.isNull(paramCustomDataEntity.diffcultName))
      this.customHeadDifficulty.setText(paramCustomDataEntity.diffcultName);
    this.customHead_content_alpha.setVisibility(0);
    this.customHead_content.setVisibility(0);
    GlideUtils.loadImgByDefault(paramCustomDataEntity.imageURL, R.mipmap.img_default, this.customHead_image);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomizePreviewHeadView
 * JD-Core Version:    0.6.0
 */