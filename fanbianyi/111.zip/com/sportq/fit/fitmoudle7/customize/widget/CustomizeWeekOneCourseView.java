package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.CustomizeModel.CustomSinglePlanEntity;
import com.sportq.fit.common.model.CustomizeModel.CustomWeekEntity;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

public class CustomizeWeekOneCourseView extends RelativeLayout
{
  private String customizeId;
  private TextView dataView;
  private String histId;
  private Context mContext;
  private String olapInfo;
  private String planId;
  private View sSplitLine;
  private String stateCode;
  private TextView trainInfo;
  private TextView trainTitle;
  private ImageView train_isFinish;
  private String weekId;
  private TextView weekView;
  private RelativeLayout week_oneCourse;

  public CustomizeWeekOneCourseView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeWeekOneCourseView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeWeekOneCourseView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(R.layout.week_onecourse_item_layout, null);
    this.trainTitle = ((TextView)localView.findViewById(R.id.train_title));
    this.trainInfo = ((TextView)localView.findViewById(R.id.train_info));
    this.sSplitLine = localView.findViewById(R.id.s_split_line);
    this.weekView = ((TextView)localView.findViewById(R.id.week_view));
    this.dataView = ((TextView)localView.findViewById(R.id.data_view));
    this.week_oneCourse = ((RelativeLayout)localView.findViewById(R.id.week_oneCourse));
    this.train_isFinish = ((ImageView)localView.findViewById(R.id.train_isFinish));
    localView.setLayoutParams(new RelativeLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 99.5F)));
    return localView;
  }

  public void initView(CustomizeModel.CustomWeekEntity paramCustomWeekEntity)
  {
    this.weekView.setText(paramCustomWeekEntity.noDay);
    this.dataView.setText(paramCustomWeekEntity.curriculumDate);
    if ("0".equals(paramCustomWeekEntity.isTrainDay))
    {
      this.trainTitle.setText(this.mContext.getString(R.string.recovery));
      this.trainTitle.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_c8c8c8));
      this.trainInfo.setVisibility(8);
    }
    do
      return;
    while (!"2".equals(paramCustomWeekEntity.isTrainDay));
    this.trainTitle.setText("请假日");
    this.trainTitle.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_c8c8c8));
    this.trainInfo.setVisibility(8);
  }

  public void initView(CustomizeModel.CustomWeekEntity paramCustomWeekEntity, int paramInt, String paramString)
  {
    this.planId = ((CustomizeModel.CustomSinglePlanEntity)paramCustomWeekEntity.lstDayPlan.get(paramInt)).planId;
    this.histId = ((CustomizeModel.CustomSinglePlanEntity)paramCustomWeekEntity.lstDayPlan.get(paramInt)).histId;
    this.customizeId = ((CustomizeModel.CustomSinglePlanEntity)paramCustomWeekEntity.lstDayPlan.get(paramInt)).customDetailId;
    this.stateCode = ((CustomizeModel.CustomSinglePlanEntity)paramCustomWeekEntity.lstDayPlan.get(paramInt)).stateCode;
    this.olapInfo = ((CustomizeModel.CustomSinglePlanEntity)paramCustomWeekEntity.lstDayPlan.get(paramInt)).olapInfo;
    ImageView localImageView = this.train_isFinish;
    int i;
    if ("2".equals(this.stateCode))
    {
      i = 0;
      localImageView.setVisibility(i);
      this.weekView.setText(paramCustomWeekEntity.noDay);
      this.dataView.setText(paramCustomWeekEntity.curriculumDate);
      if (paramInt != 0)
        break label624;
      this.weekView.setVisibility(0);
      this.dataView.setVisibility(0);
    }
    while (true)
    {
      this.trainTitle.setText(((CustomizeModel.CustomSinglePlanEntity)paramCustomWeekEntity.lstDayPlan.get(paramInt)).planName);
      ForegroundColorSpan localForegroundColorSpan1 = new ForegroundColorSpan(ContextCompat.getColor(this.mContext, R.color.color_313131));
      ForegroundColorSpan localForegroundColorSpan2 = new ForegroundColorSpan(ContextCompat.getColor(this.mContext, R.color.color_c8c8c8));
      SpannableString localSpannableString1 = new SpannableString(((CustomizeModel.CustomSinglePlanEntity)paramCustomWeekEntity.lstDayPlan.get(paramInt)).trainDuration + this.mContext.getString(R.string.min_hint));
      localSpannableString1.setSpan(new StyleSpan(1), 0, localSpannableString1.length(), 33);
      localSpannableString1.setSpan(localForegroundColorSpan1, 0, localSpannableString1.length(), 33);
      SpannableString localSpannableString2 = new SpannableString(((CustomizeModel.CustomSinglePlanEntity)paramCustomWeekEntity.lstDayPlan.get(paramInt)).calorie + this.mContext.getString(R.string.kilocalorie));
      localSpannableString2.setSpan(localForegroundColorSpan1, 0, localSpannableString2.length(), 33);
      SpannableString localSpannableString3 = new SpannableString(StringUtils.difficultyLevel(((CustomizeModel.CustomSinglePlanEntity)paramCustomWeekEntity.lstDayPlan.get(paramInt)).difficultyLevel));
      localSpannableString3.setSpan(localForegroundColorSpan1, 0, localSpannableString3.length(), 33);
      SpannableString localSpannableString4 = new SpannableString(this.mContext.getString(R.string.dv_point));
      SpannableStringBuilder localSpannableStringBuilder = new SpannableStringBuilder();
      localSpannableStringBuilder.append(localSpannableString1);
      localSpannableStringBuilder.append(localSpannableString4);
      localSpannableStringBuilder.append(localSpannableString2);
      localSpannableStringBuilder.append(localSpannableString4);
      localSpannableStringBuilder.append(localSpannableString3);
      this.trainInfo.setText(localSpannableStringBuilder);
      setPointColor();
      if ((paramCustomWeekEntity.lstDayPlan.size() > 1) && (paramInt != -1 + paramCustomWeekEntity.lstDayPlan.size()))
        ((RelativeLayout.LayoutParams)this.sSplitLine.getLayoutParams()).leftMargin = CompDeviceInfoUtils.convertOfDip(this.mContext, 69.0F);
      this.week_oneCourse.setOnClickListener(new FitAction(null, paramCustomWeekEntity, paramInt)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (("0".equals(CustomizeWeekOneCourseView.this.stateCode)) || ("3".equals(CustomizeWeekOneCourseView.this.stateCode)) || ("1".equals(CustomizeWeekOneCourseView.this.stateCode)))
            FitJumpImpl.getInstance().customizeJumpCourse(CustomizeWeekOneCourseView.this.mContext, CustomizeWeekOneCourseView.this.planId, "hide", "88888", "", "", "");
          while (true)
          {
            super.onClick(paramView);
            return;
            if (!"2".equals(CustomizeWeekOneCourseView.this.stateCode))
              continue;
            FitJumpImpl.getInstance().jumpRecordDetailInfoActivity(CustomizeWeekOneCourseView.this.mContext, CustomizeWeekOneCourseView.this.histId, CustomizeWeekOneCourseView.this.olapInfo, ((CustomizeModel.CustomSinglePlanEntity)this.val$entity.lstDayPlan.get(this.val$i)).trainDuration, ((CustomizeModel.CustomSinglePlanEntity)this.val$entity.lstDayPlan.get(this.val$i)).calorie);
          }
        }
      });
      if (!"3".equals(this.stateCode))
        break label643;
      this.week_oneCourse.setEnabled(false);
      localSpannableStringBuilder.setSpan(localForegroundColorSpan2, 0, localSpannableStringBuilder.length(), 33);
      this.trainInfo.setText(localSpannableStringBuilder);
      this.trainTitle.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_c8c8c8));
      return;
      i = 4;
      break;
      label624: this.weekView.setVisibility(4);
      this.dataView.setVisibility(4);
    }
    label643: this.week_oneCourse.setEnabled(true);
  }

  public void setPointColor()
  {
    while (true)
    {
      int i;
      try
      {
        if (this.trainInfo != null)
        {
          if (StringUtils.isNull(this.trainInfo.getText().toString()))
            return;
          String str = this.trainInfo.getText().toString();
          SpannableString localSpannableString = new SpannableString(this.trainInfo.getText());
          i = 0;
          if (i >= str.length())
            continue;
          char c = str.charAt(i);
          if (!this.mContext.getString(R.string.sp_point).equals(String.valueOf(c)))
            break label142;
          localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(this.mContext, R.color.color_c8c8c8)), i, i + 1, 33);
          break label142;
          this.trainInfo.setText(localSpannableString);
          return;
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
      return;
      label142: i++;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomizeWeekOneCourseView
 * JD-Core Version:    0.6.0
 */