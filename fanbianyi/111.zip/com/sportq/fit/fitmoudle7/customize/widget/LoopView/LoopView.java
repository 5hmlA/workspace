package com.sportq.fit.fitmoudle7.customize.widget.LoopView;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class LoopView extends View
{
  int change;
  int colorBlack;
  int colorGray;
  int colorLightGray;
  Context context;
  int firstLineY;
  private GestureDetector gestureDetector;
  int halfCircumference;
  Handler handler;
  float inSize = 24.0F;
  int initPosition;
  boolean isLoop;
  List<String> items;
  int itemsVisible;
  float lineSpacingMultiplier;
  ScheduledExecutorService mExecutor = Executors.newSingleThreadScheduledExecutor();
  private ScheduledFuture<?> mFuture;
  private int mOffset = 0;
  int maxTextHeight;
  int maxTextWidth;
  int measuredHeight;
  int measuredWidth;
  OnItemSelectedListener onItemSelectedListener;
  float outSize = 22.0F;
  int paddingLeft = 0;
  int paddingRight = 0;
  Paint paintCenterText;
  Paint paintIndicator;
  Paint paintOuterText;
  int preCurrentIndex;
  private float previousY;
  int radius;
  private float scaleX = 1.05F;
  int secondLineY;
  private int selectedItem;
  long startTime = 0L;
  private Rect tempRect = new Rect();
  int totalScrollY;

  public LoopView(Context paramContext)
  {
    super(paramContext);
    initLoopView(paramContext);
  }

  public LoopView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    initLoopView(paramContext);
  }

  public LoopView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    initLoopView(paramContext);
  }

  private int getTextX(String paramString, Paint paramPaint, Rect paramRect)
  {
    paramPaint.getTextBounds(paramString, 0, paramString.length(), paramRect);
    int i = paramRect.width();
    return (this.measuredWidth - i) / 2;
  }

  private void initLoopView(Context paramContext)
  {
    this.context = paramContext;
    this.handler = new MessageHandler(this);
    this.gestureDetector = new GestureDetector(paramContext, new LoopViewGestureListener(this));
    this.gestureDetector.setIsLongpressEnabled(false);
    this.lineSpacingMultiplier = 1.5F;
    this.isLoop = true;
    this.itemsVisible = 9;
    this.colorGray = -10329502;
    this.colorBlack = -2377878;
    this.colorLightGray = 872415231;
    this.totalScrollY = 0;
    this.initPosition = -1;
    initPaints();
  }

  private void initPaints()
  {
    this.paintOuterText = new Paint();
    this.paintOuterText.setColor(this.colorGray);
    this.paintOuterText.setAntiAlias(true);
    this.paintOuterText.setTypeface(Typeface.MONOSPACE);
    this.paintOuterText.setTextSize(sp2px(this.context, this.outSize));
    this.paintCenterText = new Paint();
    this.paintCenterText.setColor(this.colorBlack);
    this.paintCenterText.setAntiAlias(true);
    this.paintCenterText.setTextScaleX(this.scaleX);
    this.paintCenterText.setTypeface(Typeface.MONOSPACE);
    this.paintCenterText.setTextSize(sp2px(this.context, this.inSize));
    Typeface localTypeface = Typeface.create(Typeface.SANS_SERIF, 1);
    this.paintCenterText.setTypeface(localTypeface);
    this.paintIndicator = new Paint();
    this.paintIndicator.setColor(this.colorLightGray);
    this.paintIndicator.setAntiAlias(true);
    if (Build.VERSION.SDK_INT >= 11)
      setLayerType(1, null);
  }

  private void measureTextWidthHeight()
  {
    for (int i = 0; i < this.items.size(); i++)
    {
      String str = (String)this.items.get(i);
      this.paintCenterText.getTextBounds(str, 0, str.length(), this.tempRect);
      int j = this.tempRect.width();
      if (j > this.maxTextWidth)
        this.maxTextWidth = (int)(j * this.scaleX);
      this.paintCenterText.getTextBounds("星期", 0, 2, this.tempRect);
      int k = this.tempRect.height();
      if (k <= this.maxTextHeight)
        continue;
      this.maxTextHeight = k;
    }
  }

  private void remeasure()
  {
    if (this.items == null)
      return;
    measureTextWidthHeight();
    this.halfCircumference = (int)(this.maxTextHeight * this.lineSpacingMultiplier * (-1 + this.itemsVisible));
    this.measuredHeight = (int)(2 * this.halfCircumference / 3.141592653589793D);
    this.radius = (int)(this.halfCircumference / 3.141592653589793D);
    this.measuredWidth = (this.maxTextWidth + this.paddingLeft + this.paddingRight);
    this.firstLineY = (int)((this.measuredHeight - this.lineSpacingMultiplier * this.maxTextHeight) / 2.0F);
    this.secondLineY = (int)((this.measuredHeight + this.lineSpacingMultiplier * this.maxTextHeight) / 2.0F);
    if (this.initPosition == -1)
      if (!this.isLoop)
        break label170;
    label170: for (this.initPosition = ((1 + this.items.size()) / 2); ; this.initPosition = 0)
    {
      this.preCurrentIndex = this.initPosition;
      return;
    }
  }

  private int sp2px(Context paramContext, float paramFloat)
  {
    return (int)(0.5F + paramFloat * paramContext.getResources().getDisplayMetrics().scaledDensity);
  }

  public void cancelFuture()
  {
    if ((this.mFuture != null) && (!this.mFuture.isCancelled()))
    {
      this.mFuture.cancel(true);
      this.mFuture = null;
    }
  }

  public int getPaddingLeft()
  {
    return this.paddingLeft;
  }

  public int getPaddingRight()
  {
    return this.paddingRight;
  }

  public final int getSelectedItem()
  {
    return this.selectedItem;
  }

  protected void onDraw(Canvas paramCanvas)
  {
    if (this.items == null);
    String[] arrayOfString;
    label370: int k;
    float f1;
    double d;
    while (true)
    {
      return;
      arrayOfString = new String[this.itemsVisible];
      this.change = (int)(this.totalScrollY / (this.lineSpacingMultiplier * this.maxTextHeight));
      this.preCurrentIndex = (this.initPosition + this.change % this.items.size());
      if (!this.isLoop)
      {
        if (this.preCurrentIndex < 0)
          this.preCurrentIndex = 0;
        if (this.preCurrentIndex > -1 + this.items.size())
          this.preCurrentIndex = (-1 + this.items.size());
      }
      int i;
      int j;
      int n;
      while (true)
      {
        i = (int)(this.totalScrollY % (this.lineSpacingMultiplier * this.maxTextHeight));
        j = 0;
        if (j >= this.itemsVisible)
          break label370;
        n = this.preCurrentIndex - (this.itemsVisible / 2 - j);
        if (!this.isLoop)
          break;
        while (true)
          if (n < 0)
          {
            n += this.items.size();
            continue;
            if (this.preCurrentIndex < 0)
              this.preCurrentIndex = (this.items.size() + this.preCurrentIndex);
            if (this.preCurrentIndex <= -1 + this.items.size())
              break;
            this.preCurrentIndex -= this.items.size();
            break;
          }
        while (n > -1 + this.items.size())
          n -= this.items.size();
        arrayOfString[j] = ((String)this.items.get(n));
      }
      while (true)
      {
        j++;
        break;
        if (n < 0)
        {
          arrayOfString[j] = "";
          continue;
        }
        if (n > -1 + this.items.size())
        {
          arrayOfString[j] = "";
          continue;
        }
        arrayOfString[j] = ((String)this.items.get(n));
      }
      (int)(0.254D * this.maxTextHeight);
      paramCanvas.drawLine(0.0F, this.firstLineY, this.measuredWidth, this.firstLineY, this.paintIndicator);
      paramCanvas.drawLine(0.0F, this.secondLineY, this.measuredWidth, this.secondLineY, this.paintIndicator);
      for (k = 0; k < this.itemsVisible; k++)
      {
        paramCanvas.save();
        f1 = this.maxTextHeight * this.lineSpacingMultiplier;
        d = 3.141592653589793D * (f1 * k - i) / this.halfCircumference;
        float f2 = (float)(90.0D - 180.0D * (d / 3.141592653589793D));
        if ((f2 < 90.0F) && (f2 > -90.0F))
          break label525;
        paramCanvas.restore();
      }
    }
    label525: int m = (int)(this.radius - Math.cos(d) * this.radius - Math.sin(d) * this.maxTextHeight / 2.0D);
    paramCanvas.translate(0.0F, m);
    paramCanvas.scale(1.0F, (float)Math.sin(d));
    if ((m <= this.firstLineY) && (m + this.maxTextHeight >= this.firstLineY))
    {
      paramCanvas.save();
      paramCanvas.clipRect(0, 0, this.measuredWidth, this.firstLineY - m);
      paramCanvas.drawText(arrayOfString[k], getTextX(arrayOfString[k], this.paintOuterText, this.tempRect), this.maxTextHeight, this.paintOuterText);
      paramCanvas.restore();
      paramCanvas.save();
      paramCanvas.clipRect(0, this.firstLineY - m, this.measuredWidth, (int)f1);
      paramCanvas.drawText(arrayOfString[k], getTextX(arrayOfString[k], this.paintCenterText, this.tempRect), this.maxTextHeight, this.paintCenterText);
      paramCanvas.restore();
    }
    while (true)
    {
      paramCanvas.restore();
      break;
      if ((m <= this.secondLineY) && (m + this.maxTextHeight >= this.secondLineY))
      {
        paramCanvas.save();
        paramCanvas.clipRect(0, 0, this.measuredWidth, this.secondLineY - m);
        paramCanvas.drawText(arrayOfString[k], getTextX(arrayOfString[k], this.paintCenterText, this.tempRect), this.maxTextHeight, this.paintCenterText);
        paramCanvas.restore();
        paramCanvas.save();
        paramCanvas.clipRect(0, this.secondLineY - m, this.measuredWidth, (int)f1);
        paramCanvas.drawText(arrayOfString[k], getTextX(arrayOfString[k], this.paintOuterText, this.tempRect), this.maxTextHeight, this.paintOuterText);
        paramCanvas.restore();
        continue;
      }
      if ((m >= this.firstLineY) && (m + this.maxTextHeight <= this.secondLineY))
      {
        paramCanvas.clipRect(0, 0, this.measuredWidth, (int)f1);
        paramCanvas.drawText(arrayOfString[k], getTextX(arrayOfString[k], this.paintCenterText, this.tempRect), this.maxTextHeight, this.paintCenterText);
        this.selectedItem = this.items.indexOf(arrayOfString[k]);
        continue;
      }
      paramCanvas.clipRect(0, 0, this.measuredWidth, (int)f1);
      paramCanvas.drawText(arrayOfString[k], getTextX(arrayOfString[k], this.paintOuterText, this.tempRect), this.maxTextHeight, this.paintOuterText);
    }
  }

  protected final void onItemSelected()
  {
    if (this.onItemSelectedListener != null)
      postDelayed(new OnItemSelectedRunnable(this), 200L);
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    remeasure();
    setMeasuredDimension(this.measuredWidth, this.measuredHeight);
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    boolean bool = this.gestureDetector.onTouchEvent(paramMotionEvent);
    float f1 = this.lineSpacingMultiplier * this.maxTextHeight;
    switch (paramMotionEvent.getAction())
    {
    case 1:
    default:
      if (bool)
        break;
      float f5 = paramMotionEvent.getY();
      int i = (int)((Math.acos((this.radius - f5) / this.radius) * this.radius + f1 / 2.0F) / f1);
      float f6 = (f1 + this.totalScrollY % f1) % f1;
      this.mOffset = (int)(f1 * (i - this.itemsVisible / 2) - f6);
      if (System.currentTimeMillis() - this.startTime <= 120L)
        break;
      smoothScroll(ACTION.DAGGLE);
    case 0:
    case 2:
    }
    while (true)
    {
      invalidate();
      return true;
      this.startTime = System.currentTimeMillis();
      cancelFuture();
      this.previousY = paramMotionEvent.getRawY();
      continue;
      float f2 = this.previousY - paramMotionEvent.getRawY();
      this.previousY = paramMotionEvent.getRawY();
      this.totalScrollY = (int)(f2 + this.totalScrollY);
      if (this.isLoop)
        continue;
      float f3 = f1 * -this.initPosition;
      float f4 = f1 * (-1 + this.items.size() - this.initPosition);
      if (this.totalScrollY < f3)
      {
        this.totalScrollY = (int)f3;
        continue;
      }
      if (this.totalScrollY <= f4)
        continue;
      this.totalScrollY = (int)f4;
    }
  }

  protected final void scrollBy(float paramFloat)
  {
    cancelFuture();
    this.mFuture = this.mExecutor.scheduleWithFixedDelay(new InertiaTimerTask(this, paramFloat), 0L, 10, TimeUnit.MILLISECONDS);
  }

  public final void setInitPosition(int paramInt)
  {
    if (paramInt < 0)
      this.initPosition = 0;
    do
      return;
    while ((this.items == null) || (this.items.size() <= paramInt));
    this.initPosition = paramInt;
  }

  public final void setItems(List<String> paramList)
  {
    this.items = paramList;
    remeasure();
    invalidate();
  }

  public final void setListener(OnItemSelectedListener paramOnItemSelectedListener)
  {
    this.onItemSelectedListener = paramOnItemSelectedListener;
  }

  public final void setNotLoop()
  {
    this.isLoop = false;
  }

  public void setScaleX(float paramFloat)
  {
    this.scaleX = paramFloat;
  }

  public void setViewPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.paddingLeft = paramInt1;
    this.paddingRight = paramInt3;
  }

  void smoothScroll(ACTION paramACTION)
  {
    cancelFuture();
    float f;
    if ((paramACTION == ACTION.FLING) || (paramACTION == ACTION.DAGGLE))
    {
      f = this.lineSpacingMultiplier * this.maxTextHeight;
      this.mOffset = (int)((f + this.totalScrollY % f) % f);
      if (this.mOffset <= f / 2.0F)
        break label102;
    }
    label102: for (this.mOffset = (int)(f - this.mOffset); ; this.mOffset = (-this.mOffset))
    {
      this.mFuture = this.mExecutor.scheduleWithFixedDelay(new SmoothScrollTimerTask(this, this.mOffset), 0L, 10L, TimeUnit.MILLISECONDS);
      return;
    }
  }

  public static enum ACTION
  {
    static
    {
      DAGGLE = new ACTION("DAGGLE", 2);
      ACTION[] arrayOfACTION = new ACTION[3];
      arrayOfACTION[0] = CLICK;
      arrayOfACTION[1] = FLING;
      arrayOfACTION[2] = DAGGLE;
      $VALUES = arrayOfACTION;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.LoopView.LoopView
 * JD-Core Version:    0.6.0
 */