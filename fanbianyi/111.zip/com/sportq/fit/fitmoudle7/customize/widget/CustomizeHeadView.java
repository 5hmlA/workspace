package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusData;

public class CustomizeHeadView extends RelativeLayout
{
  TextView customDateOfInterval;
  TextView customDayOfNow;
  TextView customDayOfTotal;
  TextView customTitle;
  TextView customTrainsOfNow;
  TextView customTrainsOfTotal;
  LinearLayout header_info_layout;
  private Context mContext;
  ImageView train_backImage;

  public CustomizeHeadView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeHeadView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeHeadView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(R.layout.customize_headview, null);
    this.train_backImage = ((ImageView)localView.findViewById(R.id.train_backImage));
    this.customTitle = ((TextView)localView.findViewById(R.id.custom_title));
    this.customDateOfInterval = ((TextView)localView.findViewById(R.id.custom_dateOfInterval));
    this.customDayOfNow = ((TextView)localView.findViewById(R.id.custom_dayOfNow));
    this.customDayOfTotal = ((TextView)localView.findViewById(R.id.custom_dayOfTotal));
    this.customTrainsOfNow = ((TextView)localView.findViewById(R.id.custom_trainsOfNow));
    this.customTrainsOfTotal = ((TextView)localView.findViewById(R.id.custom_trainsOfTotal));
    this.header_info_layout = ((LinearLayout)localView.findViewById(R.id.header_info_layout));
    setTextViewType(this.customDayOfNow);
    setTextViewType(this.customDayOfTotal);
    setTextViewType(this.customTrainsOfNow);
    setTextViewType(this.customTrainsOfTotal);
    localView.setLayoutParams(new RelativeLayout.LayoutParams(-1, (int)(0.638D * BaseApplication.screenWidth)));
    return localView;
  }

  private void setTextViewType(TextView paramTextView)
  {
    paramTextView.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
  }

  public void initView(EntCusData paramEntCusData)
  {
    this.header_info_layout.setVisibility(0);
    this.customTitle.setText(paramEntCusData.curriculumName);
    this.customDateOfInterval.setText(paramEntCusData.curriculumDate);
    this.customDayOfNow.setText(paramEntCusData.trainDays);
    this.customDayOfTotal.setText(paramEntCusData.customDays);
    this.customTrainsOfNow.setText(paramEntCusData.hasTrainNum);
    this.customTrainsOfTotal.setText(paramEntCusData.trainNum);
    GlideUtils.loadImgByDefault(paramEntCusData.imageURL, R.mipmap.img_default, this.train_backImage);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomizeHeadView
 * JD-Core Version:    0.6.0
 */