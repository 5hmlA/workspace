package com.sportq.fit.fitmoudle7.customize.widget.LoopView;

final class OnItemSelectedRunnable
  implements Runnable
{
  final LoopView loopView;

  OnItemSelectedRunnable(LoopView paramLoopView)
  {
    this.loopView = paramLoopView;
  }

  public final void run()
  {
    this.loopView.onItemSelectedListener.onItemSelected(this.loopView.getSelectedItem());
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.LoopView.OnItemSelectedRunnable
 * JD-Core Version:    0.6.0
 */