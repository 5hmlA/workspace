package com.sportq.fit.fitmoudle7.customize.widget;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.graphics.Canvas;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatTextView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.animation.LinearInterpolator;

public class PrinterTextView extends AppCompatTextView
{
  private String[] arr;
  private int currentIndex = -1;
  private int duration = 2000;
  private StringBuffer stringBuffer = new StringBuffer();
  private ValueAnimator textAnimation;
  private TextAnimationListener textAnimationListener;
  private int textCount;

  public PrinterTextView(Context paramContext)
  {
    this(paramContext, null);
  }

  public PrinterTextView(Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  private void initAnimation()
  {
    int[] arrayOfInt = new int[2];
    arrayOfInt[0] = 0;
    arrayOfInt[1] = (-1 + this.textCount);
    this.textAnimation = ValueAnimator.ofInt(arrayOfInt);
    this.textAnimation.setDuration(this.duration);
    this.textAnimation.setInterpolator(new LinearInterpolator());
    this.textAnimation.addUpdateListener(new ValueAnimator.AnimatorUpdateListener()
    {
      public void onAnimationUpdate(ValueAnimator paramValueAnimator)
      {
        int i = ((Integer)paramValueAnimator.getAnimatedValue()).intValue();
        if (PrinterTextView.this.currentIndex != i)
        {
          PrinterTextView.this.stringBuffer.append(PrinterTextView.this.arr[i]);
          Log.e("字符内容02---", PrinterTextView.this.stringBuffer.toString());
          PrinterTextView.access$002(PrinterTextView.this, i);
          if ((PrinterTextView.this.currentIndex == -1 + PrinterTextView.this.textCount) && (PrinterTextView.this.textAnimationListener != null))
            PrinterTextView.this.textAnimationListener.animationFinish();
          PrinterTextView.this.setText(PrinterTextView.this.stringBuffer.toString());
        }
      }
    });
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
  }

  public PrinterTextView setDuration(int paramInt)
  {
    this.duration = paramInt;
    return this;
  }

  public PrinterTextView setTextAnimationListener(TextAnimationListener paramTextAnimationListener)
  {
    this.textAnimationListener = paramTextAnimationListener;
    return this;
  }

  public PrinterTextView setTextString(String paramString)
  {
    if (paramString != null)
    {
      this.textCount = paramString.length();
      this.arr = new String[this.textCount];
      for (int i = 0; i < this.textCount; i++)
        this.arr[i] = paramString.substring(i, i + 1);
    }
    return this;
  }

  public PrinterTextView startFadeInAnimation()
  {
    initAnimation();
    if (this.textAnimation != null)
    {
      this.stringBuffer.setLength(0);
      this.currentIndex = -1;
      this.textAnimation.start();
    }
    return this;
  }

  public PrinterTextView stopFadeInAnimation()
  {
    if (this.textAnimation != null)
      this.textAnimation.end();
    return this;
  }

  public static abstract interface TextAnimationListener
  {
    public abstract void animationFinish();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.PrinterTextView
 * JD-Core Version:    0.6.0
 */