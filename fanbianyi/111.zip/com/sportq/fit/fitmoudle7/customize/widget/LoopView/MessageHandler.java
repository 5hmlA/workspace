package com.sportq.fit.fitmoudle7.customize.widget.LoopView;

import android.os.Handler;
import android.os.Message;

final class MessageHandler extends Handler
{
  public static final int WHAT_INVALIDATE_LOOP_VIEW = 1000;
  public static final int WHAT_ITEM_SELECTED = 3000;
  public static final int WHAT_SMOOTH_SCROLL = 2000;
  final LoopView loopview;

  MessageHandler(LoopView paramLoopView)
  {
    this.loopview = paramLoopView;
  }

  public final void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      return;
    case 1000:
      this.loopview.invalidate();
      return;
    case 2000:
      this.loopview.smoothScroll(LoopView.ACTION.FLING);
      return;
    case 3000:
    }
    this.loopview.onItemSelected();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.LoopView.MessageHandler
 * JD-Core Version:    0.6.0
 */