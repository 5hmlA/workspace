package com.sportq.fit.fitmoudle7.customize.widget;

import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;

public abstract class MyCountDownTimer
{
  private static final int MSG = 1;
  private boolean mCancelled = false;
  private final long mCountdownInterval;
  private Handler mHandler = new Handler()
  {
    public void handleMessage(Message paramMessage)
    {
      while (true)
      {
        long l1;
        synchronized (MyCountDownTimer.this)
        {
          l1 = MyCountDownTimer.this.mStopTimeInFuture - SystemClock.elapsedRealtime();
          if (l1 > 0L)
            continue;
          MyCountDownTimer.this.onFinish();
          return;
          if (l1 < MyCountDownTimer.this.mCountdownInterval)
            sendMessageDelayed(obtainMessage(1), l1);
        }
        long l2 = SystemClock.elapsedRealtime();
        MyCountDownTimer.this.onTick(l1);
        long l3 = l2 + MyCountDownTimer.this.mCountdownInterval - SystemClock.elapsedRealtime();
        while (l3 < 0L)
          l3 += MyCountDownTimer.this.mCountdownInterval;
        if (MyCountDownTimer.this.mCancelled)
          continue;
        sendMessageDelayed(obtainMessage(1), l3);
      }
    }
  };
  private final long mMillisInFuture;
  private long mStopTimeInFuture;

  public MyCountDownTimer(long paramLong1, long paramLong2)
  {
    this.mMillisInFuture = paramLong1;
    this.mCountdownInterval = paramLong2;
  }

  public final void cancel()
  {
    this.mHandler.removeMessages(1);
    this.mCancelled = true;
  }

  public abstract void onFinish();

  public abstract void onTick(long paramLong);

  public final MyCountDownTimer start()
  {
    monitorenter;
    try
    {
      if (this.mMillisInFuture <= 0L)
        onFinish();
      for (MyCountDownTimer localMyCountDownTimer = this; ; localMyCountDownTimer = this)
      {
        return localMyCountDownTimer;
        this.mStopTimeInFuture = (SystemClock.elapsedRealtime() + this.mMillisInFuture);
        this.mHandler.sendMessage(this.mHandler.obtainMessage(1));
        this.mCancelled = false;
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.MyCountDownTimer
 * JD-Core Version:    0.6.0
 */