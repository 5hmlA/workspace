package com.sportq.fit.fitmoudle7.customize.widget.LoopView;

import android.os.Handler;
import java.util.TimerTask;

final class SmoothScrollTimerTask extends TimerTask
{
  final LoopView loopView;
  int offset;
  int realOffset;
  int realTotalOffset;

  SmoothScrollTimerTask(LoopView paramLoopView, int paramInt)
  {
    this.loopView = paramLoopView;
    this.offset = paramInt;
    this.realTotalOffset = 2147483647;
    this.realOffset = 0;
  }

  public final void run()
  {
    if (this.realTotalOffset == 2147483647)
      this.realTotalOffset = this.offset;
    this.realOffset = (int)(0.1F * this.realTotalOffset);
    if (this.realOffset == 0)
      if (this.realTotalOffset >= 0)
        break label81;
    label81: for (this.realOffset = -1; Math.abs(this.realTotalOffset) <= 0; this.realOffset = 1)
    {
      this.loopView.cancelFuture();
      this.loopView.handler.sendEmptyMessage(3000);
      return;
    }
    this.loopView.totalScrollY += this.realOffset;
    this.loopView.handler.sendEmptyMessage(1000);
    this.realTotalOffset -= this.realOffset;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.LoopView.SmoothScrollTimerTask
 * JD-Core Version:    0.6.0
 */