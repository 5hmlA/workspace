package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout.OnTabSelectListener;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import java.util.ArrayList;

public class DietTitleView extends FrameLayout
{
  private CustomTabLayout customTabLayout;
  private MealItemClickListener mealItemClickListener;
  private String[] titleList = { "早餐", "午餐", "加餐", "晚餐" };
  ViewPager viewPager;

  public DietTitleView(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public DietTitleView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public DietTitleView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), R.layout.diet_title_layout, null);
    this.customTabLayout = ((CustomTabLayout)localView.findViewById(R.id.custom_tab_layout));
    this.viewPager = ((ViewPager)localView.findViewById(R.id.view_pager));
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < 4; i++)
      localArrayList.add(new View(getContext()));
    this.viewPager.setAdapter(new CustomViewPagerAdapter(localArrayList));
    this.customTabLayout.setViewPager(this.viewPager, this.titleList);
    this.customTabLayout.setOnTabSelectListener(new CustomTabLayout.OnTabSelectListener()
    {
      public void onTabReselect(int paramInt)
      {
      }

      public void onTabSelect(int paramInt)
      {
        DietTitleView.this.mealItemClickListener.itemClick(paramInt);
      }
    });
    this.viewPager.setCurrentItem(0);
    return localView;
  }

  public void setCurrentPos(int paramInt)
  {
    if (this.customTabLayout.getCurrentTab() == paramInt)
      return;
    this.customTabLayout.setCurrentTab(paramInt);
  }

  public void setMealItemClickListener(MealItemClickListener paramMealItemClickListener)
  {
    this.mealItemClickListener = paramMealItemClickListener;
  }

  public static abstract interface MealItemClickListener
  {
    public abstract void itemClick(int paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.DietTitleView
 * JD-Core Version:    0.6.0
 */