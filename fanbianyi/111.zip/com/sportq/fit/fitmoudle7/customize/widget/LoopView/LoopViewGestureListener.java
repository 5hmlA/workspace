package com.sportq.fit.fitmoudle7.customize.widget.LoopView;

import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;

final class LoopViewGestureListener extends GestureDetector.SimpleOnGestureListener
{
  final LoopView loopView;

  LoopViewGestureListener(LoopView paramLoopView)
  {
    this.loopView = paramLoopView;
  }

  public final boolean onFling(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2, float paramFloat1, float paramFloat2)
  {
    this.loopView.scrollBy(paramFloat2);
    return true;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.LoopView.LoopViewGestureListener
 * JD-Core Version:    0.6.0
 */