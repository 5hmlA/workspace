package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;

public class EntCusDietaryData extends BaseData
  implements Serializable
{
  public EntCusDietaryModel entCusDietary;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusDietaryData
 * JD-Core Version:    0.6.0
 */