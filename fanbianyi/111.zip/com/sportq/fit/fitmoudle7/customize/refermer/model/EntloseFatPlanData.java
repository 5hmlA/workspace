package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;
import java.util.ArrayList;

public class EntloseFatPlanData extends BaseData
  implements Serializable
{
  public String isFinish;
  public boolean isNextDay = false;
  public boolean isToday = false;
  public String isTrainDay;
  public String loseFatDate;
  public ArrayList<EnttrainPlanData> lstTrainPlan;
  public String trainWeekState;
  public String weekId;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatPlanData
 * JD-Core Version:    0.6.0
 */