package com.sportq.fit.fitmoudle7.customize.refermer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import java.io.Serializable;

public class CustomizeFinishReformer extends BaseReformer
  implements Serializable
{
  public CustomizeModel.CustomDataEntity entCusData;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeFinishReformer
 * JD-Core Version:    0.6.0
 */