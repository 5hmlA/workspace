package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;
import java.util.ArrayList;

public class EntlstMonthCusData extends BaseData
  implements Serializable
{
  public String classifyId;
  public String cusDate;
  public String cusIsFinish;
  public EntDietaryData entDietary;
  public String feedBackComment;
  public String isFeedBack;
  public String isFeedBackDay;
  public String isFinish;
  public boolean isToday = false;
  public String isTrainDay;
  public ArrayList<EntlstTopicData> lstCusTopic;
  public ArrayList<EntlstDayPlanData> lstDayPlan;
  public String trainWeekState;
  public String weekId;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstMonthCusData
 * JD-Core Version:    0.6.0
 */