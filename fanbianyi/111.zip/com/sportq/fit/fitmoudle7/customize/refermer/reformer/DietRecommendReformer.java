package com.sportq.fit.fitmoudle7.customize.refermer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusDietaryModel;
import java.io.Serializable;

public class DietRecommendReformer extends BaseReformer
  implements Serializable
{
  public EntCusDietaryModel entCusDietary;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.reformer.DietRecommendReformer
 * JD-Core Version:    0.6.0
 */