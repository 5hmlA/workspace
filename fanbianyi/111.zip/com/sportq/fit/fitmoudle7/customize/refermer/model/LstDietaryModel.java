package com.sportq.fit.fitmoudle7.customize.refermer.model;

import java.io.Serializable;
import java.util.ArrayList;

public class LstDietaryModel
  implements Serializable
{
  public String cusDate;
  public String dietaryId;
  public boolean isFirst;
  public boolean isLast;
  public ArrayList<LstDietaryDetModel> lstDietaryDet;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.LstDietaryModel
 * JD-Core Version:    0.6.0
 */