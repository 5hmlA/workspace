package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;

public class EntlstDayPlanData extends BaseData
  implements Serializable
{
  public String apparatus;
  public String calorie;
  public String customDetailId;
  public String difficultyLevel;
  public String histId;
  public String imageURL;
  public String isNewTag;
  public String isUpdate;
  public String olapInfo;
  public String planId;
  public String planName;
  public String stateCode;
  public String trainDuration;
  public String trainableDay;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstDayPlanData
 * JD-Core Version:    0.6.0
 */