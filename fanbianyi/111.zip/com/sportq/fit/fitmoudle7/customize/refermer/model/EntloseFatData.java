package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;

public class EntloseFatData extends BaseData
  implements Serializable
{
  public String campType;
  public String classFlag;
  public String classTitle;
  public String commentColor;
  public String currentShareImageUrl;
  public String finishCalorie;
  public String finishDays;
  public String finishTitle;
  public String firstInComment;
  public String imageComment;
  public String isFirstTime;
  public String isLastDay;
  public String isLastWeek;
  public String isRenewal;
  public String joinState;
  public String linkUrl;
  public String loseFatComment;
  public String loseFatDate;
  public String loseFatId;
  public String loseFatImg;
  public String loseFatIntr;
  public String loseFatPeriod;
  public String loseFatState;
  public String loseFatTitle;
  public String olapInfo;
  public String renewalLink;
  public String shareComment;
  public String shareImage;
  public String shareImage1;
  public String startTime;
  public String totalCalorie;
  public String totalDays;
  public String trainActId;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatData
 * JD-Core Version:    0.6.0
 */