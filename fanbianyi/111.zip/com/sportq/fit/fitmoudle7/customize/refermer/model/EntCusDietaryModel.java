package com.sportq.fit.fitmoudle7.customize.refermer.model;

import java.io.Serializable;
import java.util.ArrayList;

public class EntCusDietaryModel
  implements Serializable
{
  public String atComment;
  public String calorie;
  public ArrayList<LstDietaryModel> lstDietary;
  public ArrayList<String> lstMealComment;
  public String targetCode;
  public String tipComment;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusDietaryModel
 * JD-Core Version:    0.6.0
 */