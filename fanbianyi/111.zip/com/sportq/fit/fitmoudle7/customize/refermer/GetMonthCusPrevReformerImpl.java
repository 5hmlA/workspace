package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.CustomizeModel.CustomCalendarEntity;
import com.sportq.fit.common.model.CustomizeModel.CustomCalendarListEntity;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle7.customize.refermer.model.CustomizeData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer;
import java.util.ArrayList;
import java.util.Iterator;

public class GetMonthCusPrevReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    CustomizeReformer localCustomizeReformer;
    if (paramBaseData == null)
      localCustomizeReformer = null;
    while (true)
    {
      return localCustomizeReformer;
      CustomizeData localCustomizeData = (CustomizeData)paramBaseData;
      localCustomizeReformer = new CustomizeReformer();
      CustomizeModel.CustomDataEntity localCustomDataEntity1 = new CustomizeModel.CustomDataEntity();
      if (localCustomizeData.entCusData != null)
      {
        localCustomDataEntity1.curriculumName = localCustomizeData.entCusData.curriculumName;
        localCustomDataEntity1.curriculumDate = localCustomizeData.entCusData.curriculumDate;
        localCustomDataEntity1.customDays = localCustomizeData.entCusData.customDays;
        localCustomDataEntity1.calorie = (localCustomizeData.entCusData.calorie + "千卡");
        localCustomDataEntity1.diffcultName = localCustomizeData.entCusData.diffcultName;
        localCustomDataEntity1.trainNum = localCustomizeData.entCusData.trainNum;
        localCustomDataEntity1.apparatus = localCustomizeData.entCusData.apparatus;
        localCustomDataEntity1.imageURL = localCustomizeData.entCusData.imageURL;
        localCustomDataEntity1.customId = localCustomizeData.entCusData.customId;
        localCustomizeReformer.entCusData = localCustomDataEntity1;
      }
      localCustomizeReformer.lstCusCal = new ArrayList();
      Iterator localIterator1 = localCustomizeData.lstCusCal.iterator();
      while (localIterator1.hasNext())
      {
        CustomizeModel.CustomCalendarListEntity localCustomCalendarListEntity1 = (CustomizeModel.CustomCalendarListEntity)localIterator1.next();
        CustomizeModel.CustomCalendarListEntity localCustomCalendarListEntity2 = new CustomizeModel.CustomCalendarListEntity();
        localCustomCalendarListEntity2.lstMonthCus = new ArrayList();
        Iterator localIterator3 = localCustomCalendarListEntity1.lstMonthCus.iterator();
        while (localIterator3.hasNext())
        {
          CustomizeModel.CustomCalendarEntity localCustomCalendarEntity1 = (CustomizeModel.CustomCalendarEntity)localIterator3.next();
          CustomizeModel.CustomCalendarEntity localCustomCalendarEntity2 = new CustomizeModel.CustomCalendarEntity();
          localCustomCalendarEntity2.cusDate = localCustomCalendarEntity1.cusDate;
          localCustomCalendarEntity2.isTrainDay = localCustomCalendarEntity1.isTrainDay;
          localCustomCalendarEntity2.isFeedBackDay = localCustomCalendarEntity1.isFeedBackDay;
          localCustomCalendarListEntity2.lstMonthCus.add(localCustomCalendarEntity2);
        }
        localCustomizeReformer.lstCusCal.add(localCustomCalendarListEntity2);
      }
      localCustomizeReformer.lstCusWeek = new ArrayList();
      Iterator localIterator2 = localCustomizeData.lstCusWeek.iterator();
      while (localIterator2.hasNext())
      {
        CustomizeModel.CustomDataEntity localCustomDataEntity2 = (CustomizeModel.CustomDataEntity)localIterator2.next();
        CustomizeModel.CustomDataEntity localCustomDataEntity3 = new CustomizeModel.CustomDataEntity();
        localCustomDataEntity3.weekId = localCustomDataEntity2.weekId;
        localCustomDataEntity3.noWeek = localCustomDataEntity2.noWeek;
        localCustomDataEntity3.curriculumDate = localCustomDataEntity2.curriculumDate;
        localCustomDataEntity3.trainNum = localCustomDataEntity2.trainNum;
        localCustomizeReformer.lstCusWeek.add(localCustomDataEntity3);
      }
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (CustomizeData)FitGsonFactory.create().fromJson(paramString2, CustomizeData.class), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.GetMonthCusPrevReformerImpl
 * JD-Core Version:    0.6.0
 */