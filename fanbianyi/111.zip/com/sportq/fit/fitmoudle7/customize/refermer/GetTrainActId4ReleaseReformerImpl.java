package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle7.customize.refermer.model.GetTrainActData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.GetTrainActModel;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.GetTrainActReformer;
import java.util.ArrayList;

public class GetTrainActId4ReleaseReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    GetTrainActReformer localGetTrainActReformer = new GetTrainActReformer();
    localGetTrainActReformer.trainActModel = ((GetTrainActModel)((GetTrainActData)paramBaseData).lstTargetClasType.get(0));
    return localGetTrainActReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    Gson localGson = FitGsonFactory.create();
    GetTrainActData localGetTrainActData = (GetTrainActData)localGson.fromJson(paramString2, GetTrainActData.class);
    if ((localGetTrainActData == null) || (localGetTrainActData.lstTargetClasType == null))
      return (BaseReformer)localGson.fromJson(paramString2, GetTrainActReformer.class);
    return dataToReformer(paramString1, localGetTrainActData, paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.GetTrainActId4ReleaseReformerImpl
 * JD-Core Version:    0.6.0
 */