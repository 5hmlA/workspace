package com.sportq.fit.fitmoudle7.customize.refermer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.model.CustomizeModel.CustomCalendarEntity;
import com.sportq.fit.common.model.CustomizeModel.CustomCalendarListEntity;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.model.CustomizeModel.CustomSelEntity;
import com.sportq.fit.common.model.CustomizeModel.CustomWeekEntity;
import com.sportq.fit.common.model.PlanModel;
import java.io.Serializable;
import java.util.ArrayList;

public class CustomizeReformer extends BaseReformer
  implements Serializable
{
  public String adjustComment;
  public CustomizeModel.CustomDataEntity entCusData;
  public CustomizeModel.CustomSelEntity entCusSel;
  public ArrayList<CustomizeModel.CustomCalendarListEntity> lstCusCal;
  public ArrayList<PlanModel> lstCusHistory;
  public ArrayList<CustomizeModel.CustomDataEntity> lstCusWeek;
  public ArrayList<CustomizeModel.CustomCalendarEntity> lstMonthCus;
  public ArrayList<CustomizeModel.CustomWeekEntity> lstWeekPlan;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer
 * JD-Core Version:    0.6.0
 */