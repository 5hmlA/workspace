package com.sportq.fit.fitmoudle7.customize.refermer.reformer;

import com.sportq.fit.common.BaseReformer;

public class UserCampReformer extends BaseReformer
{
  public String isComplete;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.reformer.UserCampReformer
 * JD-Core Version:    0.6.0
 */