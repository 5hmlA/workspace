package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;

public class FinishMonthCusData extends BaseData
  implements Serializable
{
  public String hasTryVip;
  public String isVip;
  public String vipEndComment;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.FinishMonthCusData
 * JD-Core Version:    0.6.0
 */