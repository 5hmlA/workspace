package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle7.customize.refermer.model.CustomizeData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeFinishReformer;

public class GetCusDataReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    if (paramBaseData == null);
    CustomizeData localCustomizeData;
    do
    {
      return null;
      localCustomizeData = (CustomizeData)paramBaseData;
    }
    while (localCustomizeData.entCusData == null);
    CustomizeFinishReformer localCustomizeFinishReformer = new CustomizeFinishReformer();
    CustomizeModel.CustomDataEntity localCustomDataEntity = new CustomizeModel.CustomDataEntity();
    localCustomDataEntity.curriculumName = localCustomizeData.entCusData.curriculumName;
    localCustomDataEntity.customId = localCustomizeData.entCusData.customId;
    localCustomDataEntity.customDays = localCustomizeData.entCusData.customDays;
    localCustomDataEntity.trainNum = localCustomizeData.entCusData.trainNum;
    localCustomDataEntity.calorie = localCustomizeData.entCusData.calorie;
    localCustomDataEntity.numberOfParticipants = localCustomizeData.entCusData.numberOfParticipants;
    localCustomDataEntity.imageURL = localCustomizeData.entCusData.imageURL;
    localCustomizeFinishReformer.entCusData = localCustomDataEntity;
    return localCustomizeFinishReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (CustomizeData)FitGsonFactory.create().fromJson(paramString2, CustomizeData.class), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.GetCusDataReformerImpl
 * JD-Core Version:    0.6.0
 */