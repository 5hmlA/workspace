package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatPlanData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EnttrainPlanData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.GetLoseFatPlanData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.LoseFatPlanReformer;
import java.util.ArrayList;
import java.util.Iterator;

public class GetLoseFatPlanReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    if (paramBaseData == null)
    {
      localLoseFatPlanReformer = null;
      return localLoseFatPlanReformer;
    }
    LoseFatPlanReformer localLoseFatPlanReformer = new LoseFatPlanReformer();
    GetLoseFatPlanData localGetLoseFatPlanData = (GetLoseFatPlanData)paramBaseData;
    localLoseFatPlanReformer.entLoseFatData = localGetLoseFatPlanData.entLoseFatData;
    float f1 = BaseApplication.screenWidth / BaseApplication.screenRealHeight;
    float f2 = Math.abs(f1 - 0.4618227F);
    float f3 = Math.abs(f1 - 0.562219F);
    EntloseFatData localEntloseFatData = localLoseFatPlanReformer.entLoseFatData;
    if (f2 == Math.min(f2, f3));
    for (String str = localLoseFatPlanReformer.entLoseFatData.shareImage1; ; str = localLoseFatPlanReformer.entLoseFatData.shareImage)
    {
      localEntloseFatData.currentShareImageUrl = str;
      GlideUtils.downloadImgCache(localLoseFatPlanReformer.entLoseFatData.currentShareImageUrl);
      localLoseFatPlanReformer.lstLoseFatPlan = localGetLoseFatPlanData.lstLoseFatPlan;
      Iterator localIterator = localLoseFatPlanReformer.lstLoseFatPlan.iterator();
      while (localIterator.hasNext())
      {
        EntloseFatPlanData localEntloseFatPlanData = (EntloseFatPlanData)localIterator.next();
        if (!"3".equals(localEntloseFatPlanData.isTrainDay))
          continue;
        ArrayList localArrayList = new ArrayList();
        localArrayList.add(new EnttrainPlanData());
        localEntloseFatPlanData.lstTrainPlan = localArrayList;
      }
      break;
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (GetLoseFatPlanData)FitGsonFactory.create().fromJson(paramString2, GetLoseFatPlanData.class), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.GetLoseFatPlanReformerImpl
 * JD-Core Version:    0.6.0
 */