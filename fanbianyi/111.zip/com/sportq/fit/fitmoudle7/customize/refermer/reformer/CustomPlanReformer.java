package com.sportq.fit.fitmoudle7.customize.refermer.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstMonthCusData;
import java.io.Serializable;
import java.util.ArrayList;

public class CustomPlanReformer extends BaseReformer
  implements Serializable
{
  public EntCusData entCusData;
  public ArrayList<EntlstMonthCusData> lstMonthCus;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomPlanReformer
 * JD-Core Version:    0.6.0
 */