package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusDietaryData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.DietRecommendReformer;

public class DietRecommendReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    if (paramBaseData == null)
      return null;
    DietRecommendReformer localDietRecommendReformer = new DietRecommendReformer();
    localDietRecommendReformer.entCusDietary = ((EntCusDietaryData)paramBaseData).entCusDietary;
    return localDietRecommendReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (EntCusDietaryData)FitGsonFactory.create().fromJson(paramString2, EntCusDietaryData.class), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.DietRecommendReformerImpl
 * JD-Core Version:    0.6.0
 */