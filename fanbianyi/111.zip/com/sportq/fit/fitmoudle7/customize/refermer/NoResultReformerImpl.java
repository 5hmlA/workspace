package com.sportq.fit.fitmoudle7.customize.refermer;

import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.NoResultReformer;
import java.util.HashMap;

public class NoResultReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    return new NoResultReformer();
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    BaseApplication.requestModelCache.clear();
    BaseApplication.dataCache.clear();
    return dataToReformer(paramString1, new BaseData(), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.NoResultReformerImpl
 * JD-Core Version:    0.6.0
 */