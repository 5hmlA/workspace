package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.model.BaseModel;

public class GetTrainActModel extends BaseModel
{
  public String classType;
  public String classTypeNm;
  public String sprice;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.GetTrainActModel
 * JD-Core Version:    0.6.0
 */