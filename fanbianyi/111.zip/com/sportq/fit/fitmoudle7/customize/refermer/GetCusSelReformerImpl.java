package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.CustomizeModel.CustomSelEntity;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle7.customize.refermer.model.CustomizeData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer;

public class GetCusSelReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    if (paramBaseData == null)
      return null;
    CustomizeData localCustomizeData = (CustomizeData)paramBaseData;
    CustomizeReformer localCustomizeReformer = new CustomizeReformer();
    CustomizeModel.CustomSelEntity localCustomSelEntity = new CustomizeModel.CustomSelEntity();
    localCustomSelEntity.fitGoal = localCustomizeData.entCusSel.fitGoal;
    localCustomSelEntity.fitBase = localCustomizeData.entCusSel.fitBase;
    localCustomSelEntity.positionCode = localCustomizeData.entCusSel.positionCode;
    localCustomSelEntity.frequencyCode = localCustomizeData.entCusSel.frequencyCode;
    localCustomizeReformer.entCusSel = localCustomSelEntity;
    return localCustomizeReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (CustomizeData)FitGsonFactory.create().fromJson(paramString2, CustomizeData.class), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.GetCusSelReformerImpl
 * JD-Core Version:    0.6.0
 */