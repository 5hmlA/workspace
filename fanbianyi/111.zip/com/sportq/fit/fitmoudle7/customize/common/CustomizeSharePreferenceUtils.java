package com.sportq.fit.fitmoudle7.customize.common;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;

public class CustomizeSharePreferenceUtils
{
  private static final String CUSTOMIZE_SHARE_COPY = "customize.share.copy";
  private static final String FAT_CAMP_RENEW_FLG = "fat.camp.renew.flg";
  private static final String FAT_CAMP_SHARE_COPY = "fat.camp.share.copy";
  private static final String ZERO_HINT = "zero.hint";

  public static int getCustomizeShareCopy(String paramString)
  {
    if (BaseApplication.appliContext == null)
      return -1;
    return BaseApplication.appliContext.getSharedPreferences("customize.share.copy", 0).getInt(paramString, -1);
  }

  public static Boolean getFatCampRenewDialogState(String paramString)
  {
    if (BaseApplication.appliContext == null)
      return Boolean.valueOf(false);
    return Boolean.valueOf(BaseApplication.appliContext.getSharedPreferences("fat.camp.renew.flg", 0).getBoolean(paramString, false));
  }

  public static int getFatCampShareCopy(String paramString)
  {
    if (BaseApplication.appliContext == null)
      return -1;
    return BaseApplication.appliContext.getSharedPreferences("fat.camp.share.copy", 0).getInt(paramString, -1);
  }

  public static String getZeroHintTime()
  {
    if (BaseApplication.appliContext == null)
      return "";
    return BaseApplication.appliContext.getSharedPreferences("customize.share.copy", 0).getString(BaseApplication.userModel.userId, "");
  }

  public static void putCustomizeShareCopy(String paramString, int paramInt)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("customize.share.copy", 0).edit();
      localEditor.putInt(paramString, paramInt);
      localEditor.apply();
    }
  }

  public static void putFatCampRenewDialogState(String paramString, boolean paramBoolean)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("fat.camp.renew.flg", 0).edit();
      localEditor.putBoolean(paramString, paramBoolean);
      localEditor.apply();
    }
  }

  public static void putFatCampShareCopy(String paramString, int paramInt)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("fat.camp.share.copy", 0).edit();
      localEditor.putInt(paramString, paramInt);
      localEditor.apply();
    }
  }

  public static void putZeroHintTime(String paramString)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("customize.share.copy", 0).edit();
      localEditor.putString(BaseApplication.userModel.userId, paramString);
      localEditor.apply();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.common.CustomizeSharePreferenceUtils
 * JD-Core Version:    0.6.0
 */