package com.sportq.fit.fitmoudle7.customize.eventbus;

import java.util.ArrayList;

public class RefreshCusDietEvent
{
  public int cIndex;
  public ArrayList<String> lstDayDietary;

  public RefreshCusDietEvent(int paramInt, ArrayList<String> paramArrayList)
  {
    this.cIndex = paramInt;
    this.lstDayDietary = paramArrayList;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.eventbus.RefreshCusDietEvent
 * JD-Core Version:    0.6.0
 */