package com.sportq.fit.fitmoudle7.customize.eventbus;

public class CustomConstant
{
  public static final String CUSTOM_CUSTOMID = "custom_customId";
  public static final String CUSTOM_HASCUSFLAG = "custom_hascusflag";
  public static final String CUSTOM_HASHISTORYFLAG = "custom_hasHistoryFlag";
  public static final String CUSTOM_INFO_ENTITY = "custom_info_entity";
  public static final String CUSTOM_PAGEFLAG = "custom_pageFlag";
  public static final String CUSTOM_PREFLAG = "custom_preFlag";
  public static final String CUSTOM_THIS_WEEK = "custom_this_week";
  public static final String CUSTOM_WEEKID = "custom_weekId";
  public static final String CUSTOM_WEEKNO = "custom_weekNo";
  public static final String DETAILS_CUSTOMIZENAME = "details_customizeName";
  public static final String EXI_MONTHCUS = "exi_MonthCus";
  public static final String HIS_CLICK_CUSTOMID = "his_click_customId";
  public static final String PERFECT_DIET_INFO = "perfect_diet_info";
  public static final String PREVIEW_DATA_CUSTOMIZEREFORMER = "preview_data_customizereformer";
  public static final String SEE_FINISHED_TRAIN_SITUATION = "see_finished_train_situation";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.eventbus.CustomConstant
 * JD-Core Version:    0.6.0
 */