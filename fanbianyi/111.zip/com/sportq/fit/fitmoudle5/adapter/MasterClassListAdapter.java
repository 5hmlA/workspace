package com.sportq.fit.fitmoudle5.adapter;

import android.content.Context;
import android.support.constraint.Group;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle5.R.color;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.reformer.model.AllLessonModel;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class MasterClassListAdapter extends SuperAdapter<AllLessonModel>
{
  public MasterClassListAdapter(Context paramContext, List<AllLessonModel> paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, AllLessonModel paramAllLessonModel)
  {
    int i = 8;
    ImageView localImageView1 = (ImageView)paramSuperViewHolder.findViewById(R.id.master_class_img);
    GlideUtils.loadImgByRadius(paramAllLessonModel.imageUrl, R.mipmap.img_default, 3.0F, localImageView1);
    ((TextView)paramSuperViewHolder.findViewById(R.id.item_title)).setText(paramAllLessonModel.title);
    ((TextView)paramSuperViewHolder.findViewById(R.id.item_desc)).setText(paramAllLessonModel.intr);
    TextView localTextView = (TextView)paramSuperViewHolder.findViewById(R.id.item_info);
    String str;
    Group localGroup;
    RTextView localRTextView;
    label215: int j;
    label243: View localView;
    if (paramAllLessonModel.courseNumber.contains("节"))
    {
      str = paramAllLessonModel.courseNumber;
      localTextView.setText(str);
      ((TextView)paramSuperViewHolder.findViewById(R.id.price)).setText(paramAllLessonModel.price);
      localGroup = (Group)paramSuperViewHolder.findViewById(R.id.price_group);
      localRTextView = (RTextView)paramSuperViewHolder.findViewById(R.id.go_train_tv);
      if (!"1".equals(paramAllLessonModel.isBuy))
        break label320;
      localRTextView.setVisibility(0);
      localRTextView.getHelper().setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_313131));
      localRTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
      localRTextView.setText("去学习");
      localGroup.setVisibility(i);
      ImageView localImageView2 = (ImageView)paramSuperViewHolder.findViewById(R.id.new_icon);
      if (!"1".equals(paramAllLessonModel.isNewTag))
        break label399;
      j = 0;
      localImageView2.setVisibility(j);
      localView = paramSuperViewHolder.findViewById(R.id.master_item_split_line);
      if (hasHeaderView())
        paramInt2--;
      if (paramInt2 != -1 + getData().size())
        break label406;
    }
    while (true)
    {
      localView.setVisibility(i);
      return;
      str = paramAllLessonModel.courseNumber + "节课";
      break;
      label320: localGroup.setVisibility(0);
      if ("1".equals(paramAllLessonModel.freeFlg))
      {
        localRTextView.setVisibility(0);
        localRTextView.getHelper().setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_ffd208));
        localRTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_313131));
        localRTextView.setText("免费领取");
        break label215;
      }
      localRTextView.setVisibility(i);
      break label215;
      label399: j = i;
      break label243;
      label406: i = 0;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.adapter.MasterClassListAdapter
 * JD-Core Version:    0.6.0
 */