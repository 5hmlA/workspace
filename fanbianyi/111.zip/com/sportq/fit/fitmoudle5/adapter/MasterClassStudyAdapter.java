package com.sportq.fit.fitmoudle5.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.masterCache.MasterCacheDBManager;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.reformer.model.LstLesSectionModel;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class MasterClassStudyAdapter extends SuperAdapter<LstLesSectionModel>
{
  private Drawable drawable;
  private String isBuy;

  public MasterClassStudyAdapter(Context paramContext, List<LstLesSectionModel> paramList, int paramInt, String paramString)
  {
    super(paramContext, paramList, paramInt);
    this.isBuy = paramString;
    this.drawable = ContextCompat.getDrawable(paramContext, R.mipmap.btn_lock_master);
    this.drawable.setBounds(0, 0, CompDeviceInfoUtils.convertOfDip(paramContext, 20.0F), CompDeviceInfoUtils.convertOfDip(paramContext, 20.0F));
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, LstLesSectionModel paramLstLesSectionModel)
  {
    int i = 8;
    ((FrameLayout)paramSuperViewHolder.findViewById(R.id.parent_layout)).getLayoutParams().height = CompDeviceInfoUtils.convertOfDip(getContext(), 105.0F);
    GlideUtils.loadImgByDefault(paramLstLesSectionModel.imageUrl, R.mipmap.img_fit_logo, (ImageView)paramSuperViewHolder.findViewById(R.id.item_img));
    ((TextView)paramSuperViewHolder.findViewById(R.id.item_num)).setText(String.valueOf(paramInt2 + 1));
    ((TextView)paramSuperViewHolder.findViewById(R.id.class_name)).setText(paramLstLesSectionModel.title);
    TextView localTextView = (TextView)paramSuperViewHolder.findViewById(R.id.class_name);
    Drawable localDrawable;
    int j;
    label195: View localView2;
    if ("0".equals(this.isBuy))
    {
      localDrawable = this.drawable;
      localTextView.setCompoundDrawables(null, null, localDrawable, null);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = StringUtils.convertTimeByVideo(paramLstLesSectionModel.videoTime);
      String str = String.format("视频课程  •  %s", arrayOfObject);
      ((TextView)paramSuperViewHolder.findViewById(R.id.class_introduce)).setText(str);
      View localView1 = paramSuperViewHolder.findViewById(R.id.download_state);
      if (MasterCacheDBManager.getIntance().selectCache(paramLstLesSectionModel.sectionId) == null)
        break label240;
      j = 0;
      localView1.setVisibility(j);
      localView2 = paramSuperViewHolder.findViewById(R.id.split_line);
      if (paramInt2 != -1 + getData().size())
        break label247;
    }
    while (true)
    {
      localView2.setVisibility(i);
      return;
      localDrawable = null;
      break;
      label240: j = i;
      break label195;
      label247: i = 0;
    }
  }

  public void setIsBuy(String paramString)
  {
    this.isBuy = paramString;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.adapter.MasterClassStudyAdapter
 * JD-Core Version:    0.6.0
 */