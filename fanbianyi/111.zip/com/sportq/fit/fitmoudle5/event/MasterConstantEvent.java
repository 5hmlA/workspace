package com.sportq.fit.fitmoudle5.event;

public class MasterConstantEvent
{
  public static final String BUY_MASTER_SUCCESS = "buy.master.success";
  public static final String FCION_BUY_MASTER_SUCCESS = "fcoin.buy.master.success";
  public static final String MASTER_SHARE = "master.share";
  public static final String SHOW_ERROR_HINT = "show.error.hint";
  public static final String SUB_CLASS_CREATE = "sub.class.create";
  public static final String SUB_CLASS_DESTROY = "sub.class.destroy";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.event.MasterConstantEvent
 * JD-Core Version:    0.6.0
 */