package com.sportq.fit.fitmoudle5.widget;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.os.Build.VERSION;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StyleRes;
import android.support.percent.PercentRelativeLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.sharemanager.ShareListenerFunction;
import com.sportq.fit.fitmoudle.sharemanager.ShareManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.PlayPointModel;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.layout;
import com.sportq.fit.fitmoudle5.R.string;
import com.sportq.fit.fitmoudle5.adapter.MasterVideoShareDialogAdapter;
import com.sportq.fit.fitmoudle5.event.MasterPlayVideoEvent;
import com.sportq.fit.fitmoudle5.reformer.model.LesSectionDetModel;
import java.util.ArrayList;
import org.byteam.superadapter.OnItemClickListener;
import org.greenrobot.eventbus.EventBus;

public class MasterVideoShareDialog extends Dialog
  implements View.OnClickListener
{
  private MasterVideoShareDialogAdapter adapter;
  private PercentRelativeLayout contentLayout;
  private DialogInterface dialog;
  private boolean isCompletion = true;
  private RelativeLayout mCloseBtnLayout;
  private Context mContext;
  private LinearLayout mCopeLinkLayout;
  private ImageView mImageView;
  private View mLineTop;
  private LinearLayout mQqLayout;
  private LinearLayout mQqZonexinLayout;
  private RecyclerView mRecyclerView;
  private LinearLayout mShareBtnLayout;
  private TextView mTitle;
  private LinearLayout mWeiBoLayout;
  private LinearLayout mWeiChartLayout;
  private LinearLayout mWeiChatFriLayout;
  private UseShareModel model;
  private ArrayList<LesSectionDetModel> videoLists;

  public MasterVideoShareDialog(@NonNull Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
  }

  public MasterVideoShareDialog(@NonNull Context paramContext, @StyleRes int paramInt)
  {
    super(paramContext, paramInt);
    this.mContext = paramContext;
  }

  protected MasterVideoShareDialog(@NonNull Context paramContext, boolean paramBoolean, @Nullable DialogInterface.OnCancelListener paramOnCancelListener)
  {
    super(paramContext, paramBoolean, paramOnCancelListener);
    this.mContext = paramContext;
  }

  private void bindFinishViews()
  {
    this.mRecyclerView = ((RecyclerView)findViewById(R.id.recyclerView));
    if ((this.isCompletion) && (this.mRecyclerView != null))
    {
      LinearLayoutManager localLinearLayoutManager = new LinearLayoutManager(this.mContext);
      localLinearLayoutManager.setOrientation(0);
      this.mRecyclerView.setLayoutManager(localLinearLayoutManager);
      this.adapter = new MasterVideoShareDialogAdapter(this.mContext, this.videoLists, R.layout.item_master_share_dialog);
      this.adapter.setOnItemClickListener(new OnItemClickListener()
      {
        public void onItemClick(View paramView, int paramInt1, int paramInt2)
        {
          MasterVideoShareDialog.this.adapter.squareProgressViewStop();
          EventBus.getDefault().post(new MasterPlayVideoEvent(((LesSectionDetModel)MasterVideoShareDialog.this.videoLists.get(paramInt2)).sectionId));
        }
      });
      this.mRecyclerView.setAdapter(this.adapter);
      this.mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener()
      {
        public void onScrollStateChanged(RecyclerView paramRecyclerView, int paramInt)
        {
          if ((MasterVideoShareDialog.this.adapter != null) && (paramInt == 1))
            MasterVideoShareDialog.this.adapter.squareStopAndHide();
          super.onScrollStateChanged(paramRecyclerView, paramInt);
        }
      });
    }
    bindViews();
  }

  private void bindViews()
  {
    this.contentLayout = ((PercentRelativeLayout)findViewById(R.id.contentLayout));
    this.mCloseBtnLayout = ((RelativeLayout)findViewById(R.id.closeBtnLayout));
    this.mCloseBtnLayout.setOnClickListener(this);
    this.mImageView = ((ImageView)findViewById(R.id.imageView));
    this.mTitle = ((TextView)findViewById(R.id.title));
    this.mLineTop = findViewById(R.id.lineTop);
    this.mShareBtnLayout = ((LinearLayout)findViewById(R.id.shareBtnLayout));
    this.mWeiChatFriLayout = ((LinearLayout)findViewById(R.id.weiChatFriLayout));
    this.mWeiChatFriLayout.setOnClickListener(this);
    this.mWeiChartLayout = ((LinearLayout)findViewById(R.id.weiChartLayout));
    this.mWeiChartLayout.setOnClickListener(this);
    this.mWeiBoLayout = ((LinearLayout)findViewById(R.id.weiBoLayout));
    this.mWeiBoLayout.setOnClickListener(this);
    this.mQqLayout = ((LinearLayout)findViewById(R.id.qqLayout));
    this.mQqLayout.setOnClickListener(this);
    this.mQqZonexinLayout = ((LinearLayout)findViewById(R.id.qqZoneLayout));
    this.mQqZonexinLayout.setOnClickListener(this);
    this.mCopeLinkLayout = ((LinearLayout)findViewById(R.id.copyLinkLayout));
    this.mCopeLinkLayout.setOnClickListener(this);
  }

  private String getShareLink()
  {
    if (this.model == null)
      return "";
    return VersionUpdateCheck.WEB_ADDRESS + "h5/courseInfo?targetid=" + this.model.lessonId;
  }

  private void initView()
  {
    if ((Build.VERSION.SDK_INT >= 19) && (CompDeviceInfoUtils.hasNavigationBarFun((Activity)this.mContext)) && (BaseApplication.screenRealHeight > BaseApplication.screenHeight))
    {
      Window localWindow = getWindow();
      if (localWindow != null)
        localWindow.addFlags(134217728);
    }
    CompDeviceInfoUtils.getDeviceWidthHeight(this.mContext);
    int i = Math.max(BaseApplication.screenHeight, BaseApplication.screenWidth);
    int j = Math.min(BaseApplication.screenHeight, BaseApplication.screenWidth) - CompDeviceInfoUtils.getStatusBarHeight(getContext());
    if ((this.videoLists != null) && (this.videoLists.size() > 0) && (this.isCompletion))
    {
      setContentView(R.layout.masterl_finish_share_dialog);
      bindFinishViews();
      WindowManager.LayoutParams localLayoutParams = getWindow().getAttributes();
      localLayoutParams.gravity = 83;
      localLayoutParams.width = i;
      localLayoutParams.height = j;
      getWindow().setAttributes(localLayoutParams);
      if (!this.isCompletion)
        break label197;
      this.mCloseBtnLayout.setVisibility(0);
      this.contentLayout.setOnClickListener(null);
    }
    while (true)
    {
      setCancelable(true);
      setData();
      return;
      setContentView(R.layout.master_share_dialog);
      bindViews();
      break;
      label197: this.mCloseBtnLayout.setVisibility(8);
      this.contentLayout.setOnClickListener(this);
    }
  }

  public void dismiss()
  {
    if (this.adapter != null)
      this.adapter.squareProgressViewStop();
    super.dismiss();
  }

  public boolean isCompletion()
  {
    return this.isCompletion;
  }

  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    int i = paramView.getId();
    if (i == R.id.copyLinkLayout)
    {
      TextUtils.copyToClipboard(getShareLink());
      ToastUtils.makeToast(BaseApplication.appliContext, StringUtils.getStringResources(R.string.h_16_1));
    }
    if ((i == R.id.closeBtnLayout) || (i == R.id.contentLayout))
      dismiss();
    while (true)
    {
      if (this.adapter != null)
        this.adapter.squareStopAndHide();
      return;
      if (i == R.id.weiChatFriLayout)
      {
        shareAction(1, "2");
        continue;
      }
      if (i == R.id.weiChartLayout)
      {
        shareAction(0, "1");
        continue;
      }
      if (i == R.id.weiBoLayout)
      {
        shareAction(2, "0");
        continue;
      }
      if (i == R.id.qqLayout)
      {
        shareAction(3, "3");
        continue;
      }
      if (i != R.id.qqZoneLayout)
        continue;
      shareAction(4, "4");
    }
  }

  public void onPause()
  {
    if (this.adapter != null)
      this.adapter.squareProgressViewPause();
  }

  public void onResume()
  {
    if (this.adapter != null)
      this.adapter.squareProgressViewStart();
  }

  public void setCompletion(boolean paramBoolean)
  {
    this.isCompletion = paramBoolean;
  }

  public void setData()
  {
    if (this.model != null)
      this.mTitle.setText(this.model.lessonTitle);
    if (this.mCloseBtnLayout != null)
    {
      if (this.isCompletion)
        this.mCloseBtnLayout.setVisibility(0);
    }
    else
      return;
    this.mCloseBtnLayout.setVisibility(8);
  }

  public void setDialog(DialogInterface paramDialogInterface)
  {
    this.dialog = paramDialogInterface;
  }

  public void setModel(UseShareModel paramUseShareModel)
  {
    this.model = paramUseShareModel;
  }

  public void setVideoLists(ArrayList<LesSectionDetModel> paramArrayList)
  {
    this.videoLists = paramArrayList;
  }

  public void shareAction(int paramInt, String paramString)
  {
    PlayPointModel localPlayPointModel = ShareListenerFunction.pointPut(33, paramString, this.model);
    ShareManager localShareManager = new ShareManager(this.mContext, this.dialog);
    localShareManager.setPlayPointModel(localPlayPointModel);
    localShareManager.shareFitData(this.model, 33, paramInt);
  }

  public void show()
  {
    initView();
    super.show();
    VdsAgent.showDialog((Dialog)this);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.MasterVideoShareDialog
 * JD-Core Version:    0.6.0
 */