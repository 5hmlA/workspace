package com.sportq.fit.fitmoudle5.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout;
import com.sportq.fit.fitmoudle.widget.NoScrollViewPager;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.layout;
import com.sportq.fit.fitmoudle5.R.string;
import com.sportq.fit.fitmoudle5.activity.MasterSubClassDetailsActivity;
import com.sportq.fit.fitmoudle5.adapter.MasterClassStudyAdapter;
import com.sportq.fit.fitmoudle5.reformer.model.EntLessonDetModel;
import com.sportq.fit.fitmoudle5.reformer.model.LstLesSectionModel;
import java.util.ArrayList;
import org.byteam.superadapter.OnItemClickListener;
import org.greenrobot.eventbus.EventBus;

public class MasterViewPager extends NoScrollViewPager
{
  private ArrayList<View> viewList = new ArrayList();

  public MasterViewPager(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public MasterViewPager(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  private View getLeftView(EntLessonDetModel paramEntLessonDetModel)
  {
    View localView = View.inflate(getContext(), R.layout.master_class_introduce_layout, null);
    WebView localWebView = (WebView)localView.findViewById(R.id.web_introduce);
    localWebView.getSettings().setDomStorageEnabled(true);
    localWebView.getSettings().setJavaScriptEnabled(true);
    String str = paramEntLessonDetModel.intrUrl;
    localWebView.loadUrl(str);
    VdsAgent.loadUrl((View)localWebView, str);
    return localView;
  }

  private View getRightView(EntLessonDetModel paramEntLessonDetModel)
  {
    RecyclerView localRecyclerView = new RecyclerView(getContext());
    localRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
    MasterClassStudyAdapter localMasterClassStudyAdapter = new MasterClassStudyAdapter(getContext(), paramEntLessonDetModel.lstLesSection, R.layout.master_study_class_item_layout, paramEntLessonDetModel.isBuy);
    localMasterClassStudyAdapter.setOnItemClickListener(new OnItemClickListener(paramEntLessonDetModel)
    {
      public void onItemClick(View paramView, int paramInt1, int paramInt2)
      {
        if (!"1".equals(this.val$entLessonDet.isBuy))
        {
          EventBus.getDefault().post("show.error.hint");
          return;
        }
        Intent localIntent = new Intent(MasterViewPager.this.getContext(), MasterSubClassDetailsActivity.class);
        localIntent.putExtra("str.lessonId", this.val$entLessonDet.lessonId);
        localIntent.putExtra("str.sectionId", ((LstLesSectionModel)this.val$entLessonDet.lstLesSection.get(paramInt2)).sectionId);
        localIntent.putExtra("str.lessonTitle", this.val$entLessonDet.title);
        localIntent.putExtra("str.lessonDescribe", this.val$entLessonDet.intr);
        localIntent.putExtra("str.lessonImg", this.val$entLessonDet.imageUrl);
        MasterViewPager.this.getContext().startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)MasterViewPager.this.getContext(), 0);
      }
    });
    localMasterClassStudyAdapter.addFooterView(View.inflate(getContext(), R.layout.purchase_notice_layout, null));
    localRecyclerView.setAdapter(localMasterClassStudyAdapter);
    return localRecyclerView;
  }

  public void downloadSuccessRefresh()
  {
    ((MasterClassStudyAdapter)((RecyclerView)this.viewList.get(1)).getAdapter()).notifyDataSetChanged();
  }

  public void initView(CustomTabLayout paramCustomTabLayout, EntLessonDetModel paramEntLessonDetModel)
  {
    int i = 1;
    String[] arrayOfString = new String[2];
    arrayOfString[0] = getContext().getString(R.string.b_38_1_1);
    Object[] arrayOfObject = new Object[i];
    arrayOfObject[0] = paramEntLessonDetModel.courseNumber;
    arrayOfString[i] = String.format("上课学习（%s）", arrayOfObject);
    this.viewList.add(getLeftView(paramEntLessonDetModel));
    this.viewList.add(getRightView(paramEntLessonDetModel));
    setAdapter(new CustomViewPagerAdapter(this.viewList));
    paramCustomTabLayout.setViewPager(this, arrayOfString);
    if ("1".equals(paramEntLessonDetModel.isBuy));
    while (true)
    {
      paramCustomTabLayout.setCurrentTab(i);
      return;
      i = 0;
    }
  }

  public void refreshRightData()
  {
    if (getCurrentItem() != 1)
      setCurrentItem(1);
    MasterClassStudyAdapter localMasterClassStudyAdapter = (MasterClassStudyAdapter)((RecyclerView)this.viewList.get(1)).getAdapter();
    localMasterClassStudyAdapter.setIsBuy("1");
    localMasterClassStudyAdapter.notifyDataSetChanged();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.MasterViewPager
 * JD-Core Version:    0.6.0
 */