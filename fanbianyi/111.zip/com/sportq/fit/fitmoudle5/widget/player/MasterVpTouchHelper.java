package com.sportq.fit.fitmoudle5.widget.player;

import android.content.Context;
import android.content.res.Resources;
import android.media.AudioManager;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.stub.StubApp;

public class MasterVpTouchHelper
{
  public static final int MOVE_LEFT = 0;
  public static final int MOVE_RIGHT = 1;
  private MasterVpTouchHelperListener listener;
  public AudioManager mAudioManager;
  private boolean mBrightness = false;
  private float mBrightnessData = -1.0F;
  private boolean mChangePosition = false;
  private boolean mChangeVolume = false;
  private long mDownPosition;
  private float mDownX;
  private float mDownY;
  private boolean mFirstTouch = false;
  private int mGestureDownVolume;
  private boolean mHideKey = true;
  private int mScreenHeight;
  private int mScreenWidth;
  private int mSeekEndOffset;
  private long mSeekTimePosition;
  private boolean mShowVKey = false;
  private int mSpeedHold = 0;
  private int mThreshold = 50;
  boolean result = false;
  private VelocityTracker vTracker = null;

  public MasterVpTouchHelper(Context paramContext, MasterVpTouchHelperListener paramMasterVpTouchHelperListener)
  {
    this.mScreenWidth = paramContext.getResources().getDisplayMetrics().widthPixels;
    this.mScreenHeight = paramContext.getResources().getDisplayMetrics().heightPixels;
    this.mSeekEndOffset = CompDeviceInfoUtils.dipToPx(50.0F);
    this.listener = paramMasterVpTouchHelperListener;
    this.mAudioManager = ((AudioManager)StubApp.getOrigApplicationContext(paramContext.getApplicationContext()).getSystemService("audio"));
    CompDeviceInfoUtils.getDeviceWidthHeight(paramContext);
  }

  public boolean onTouch(Context paramContext, MotionEvent paramMotionEvent)
  {
    float f1 = paramMotionEvent.getX();
    float f2 = paramMotionEvent.getY();
    switch (paramMotionEvent.getAction())
    {
    default:
    case 0:
    case 2:
      while (true)
      {
        return this.result;
        this.mDownX = f1;
        this.mDownY = f2;
        this.mChangeVolume = false;
        this.mChangePosition = false;
        this.mShowVKey = false;
        this.mBrightness = false;
        this.mFirstTouch = true;
        this.result = false;
        LogUtils.d("MasterVpTouchHelper->onTouch->", "ACTION_DOWN");
        if (this.vTracker == null)
          this.vTracker = VelocityTracker.obtain();
        this.vTracker.addMovement(paramMotionEvent);
        continue;
        VelocityTracker localVelocityTracker = this.vTracker;
        float f3 = 0.0F;
        float f4 = 0.0F;
        if (localVelocityTracker != null)
        {
          this.vTracker.addMovement(paramMotionEvent);
          this.vTracker.computeCurrentVelocity(1000);
          f3 = Math.abs(this.vTracker.getXVelocity());
          f4 = Math.abs(this.vTracker.getYVelocity());
        }
        LogUtils.d("MasterVpTouchHelper->onTouch->speedX:", String.valueOf(f3));
        LogUtils.d("MasterVpTouchHelper->onTouch->speedY:", String.valueOf(f4));
        float f5 = f1 - this.mDownX;
        float f6 = f2 - this.mDownY;
        float f7 = Math.abs(f5);
        float f8 = Math.abs(f6);
        LogUtils.d("MasterVpTouchHelper->onTouch->absDeltaX:", String.valueOf(f7));
        LogUtils.d("MasterVpTouchHelper->onTouch->absDeltaY:", String.valueOf(f8));
        if ((!this.mChangePosition) && (!this.mChangeVolume) && (!this.mBrightness))
          if (((f7 > this.mThreshold) && (f3 > this.mSpeedHold)) || ((f8 > this.mThreshold) && (f4 > this.mSpeedHold)))
          {
            this.result = true;
            this.listener.progressTimerStop();
            if (f7 >= this.mThreshold)
              if (Math.abs(BaseApplication.screenWidth - this.mDownX) > this.mSeekEndOffset)
              {
                this.mChangePosition = true;
                this.mDownPosition = this.listener.getCurrentPosition();
                label377: if (!this.mChangePosition)
                  break label624;
                long l = this.listener.getDuration();
                this.mSeekTimePosition = ()((float)this.mDownPosition + 100.0F * f5);
                if (this.mSeekTimePosition > l)
                  this.mSeekTimePosition = l;
                if (f5 <= 0.0F)
                  break label618;
              }
          }
        label531: label590: label596: label618: for (int m = 1; ; m = 0)
        {
          this.listener.showProgressDialog(m, this.mSeekTimePosition);
          this.listener.setProgress(this.mSeekTimePosition);
          break;
          this.mShowVKey = true;
          break label377;
          boolean bool1;
          label500: boolean bool3;
          if (Math.abs(BaseApplication.screenHeight - this.mDownY) > this.mSeekEndOffset)
          {
            bool1 = true;
            if (this.mFirstTouch)
            {
              if ((this.mDownX >= 0.5F * this.mScreenWidth) || (!bool1))
                break label590;
              bool3 = true;
              this.mBrightness = bool3;
              this.mFirstTouch = false;
            }
            if (!this.mBrightness)
            {
              this.mChangeVolume = bool1;
              this.mGestureDownVolume = this.mAudioManager.getStreamVolume(3);
            }
            if (bool1)
              break label596;
          }
          for (boolean bool2 = true; ; bool2 = false)
          {
            this.mShowVKey = bool2;
            break;
            bool1 = false;
            break label500;
            bool3 = false;
            break label531;
          }
          this.result = false;
          break label377;
          this.result = true;
          break label377;
        }
        label624: if (this.mChangeVolume)
        {
          float f10 = -f6;
          int i = this.mAudioManager.getStreamMaxVolume(3);
          int j = (int)(3.0F * (f10 * i) / this.mScreenHeight);
          if ((j + this.mGestureDownVolume >= 0) && (this.mGestureDownVolume <= i))
          {
            this.mAudioManager.setStreamVolume(3, j + this.mGestureDownVolume, 0);
            int k = (int)(100 * this.mGestureDownVolume / i + 100.0F * (3.0F * f10) / this.mScreenHeight);
            this.listener.showVolumeDialog(-f10, k);
            continue;
          }
          if (j + this.mGestureDownVolume < 0)
          {
            this.mAudioManager.setStreamVolume(3, 0, 0);
            this.listener.showVolumeDialog(-f10, 0);
            continue;
          }
          if (j + this.mGestureDownVolume <= i)
            continue;
          this.mAudioManager.setStreamVolume(3, i, 0);
          this.listener.showVolumeDialog(-f10, 0);
          continue;
        }
        if ((this.mChangePosition) || (!this.mBrightness))
          continue;
        float f9 = -f6 / this.mScreenHeight;
        this.listener.showBrightnessDialog(f9);
        this.mDownY = f2;
      }
    case 1:
    }
    this.listener.dismissProgressDialog();
    this.listener.dismissVolumeDialog();
    this.listener.dismissBrightnessDialog();
    if (this.vTracker != null)
    {
      this.vTracker.recycle();
      this.vTracker = null;
    }
    if (this.mChangePosition)
      this.listener.seekTo(this.mSeekTimePosition);
    this.listener.progressTimerStart();
    LogUtils.d("MasterVpTouchHelper->onTouch->", "ACTION_UP");
    if ((this.mHideKey) && (this.mShowVKey))
      return true;
    return this.result;
  }

  public static abstract interface MasterVpTouchHelperListener
  {
    public abstract void dismissBrightnessDialog();

    public abstract void dismissProgressDialog();

    public abstract void dismissVolumeDialog();

    public abstract long getCurrentPosition();

    public abstract long getDuration();

    public abstract int getProgress(long paramLong);

    public abstract void progressTimerStart();

    public abstract void progressTimerStop();

    public abstract void seekTo(long paramLong);

    public abstract void setProgress(int paramInt);

    public abstract void setProgress(long paramLong);

    public abstract void showBrightnessDialog(float paramFloat);

    public abstract void showProgressDialog(int paramInt, long paramLong);

    public abstract void showVolumeDialog(float paramFloat, int paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.player.MasterVpTouchHelper
 * JD-Core Version:    0.6.0
 */