package com.sportq.fit.fitmoudle5.widget.player;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.TextureView;
import android.view.View.MeasureSpec;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;

public class MasterVideoView extends TextureView
{
  private Context mContext;

  public MasterVideoView(Context paramContext)
  {
    super(paramContext);
  }

  public MasterVideoView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
  }

  public MasterVideoView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
  }

  @RequiresApi(api=21)
  public MasterVideoView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.mContext = paramContext;
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    LogUtils.e("MasterVideoView---", "onMeasure");
    if (((this.mContext instanceof Activity)) && ((BaseApplication.screenRealHeight == 0) || (BaseApplication.screenWidth == 0)))
      CompDeviceInfoUtils.getDeviceWidthHeight(this.mContext);
    int j;
    int i;
    if (getResources().getConfiguration().orientation == 1)
    {
      j = Math.min(BaseApplication.screenRealHeight, BaseApplication.screenWidth);
      i = (int)(0.5625D * j);
    }
    while (true)
    {
      super.onMeasure(paramInt1, View.MeasureSpec.makeMeasureSpec(i, View.MeasureSpec.getMode(paramInt2)));
      setMeasuredDimension(j, i);
      return;
      i = Math.min(BaseApplication.screenRealHeight, BaseApplication.screenWidth) - CompDeviceInfoUtils.getStatusBarHeight(getContext());
      j = (int)(1.778D * i);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.player.MasterVideoView
 * JD-Core Version:    0.6.0
 */