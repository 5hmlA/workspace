package com.sportq.fit.fitmoudle5.widget.player;

import android.content.Context;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView.SurfaceTextureListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.danikula.videocache.CacheListener;
import com.danikula.videocache.HttpProxyCacheServer;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.PageType;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.masterCache.MasterCacheDBManager;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.layout;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.R.string;
import com.sportq.fit.fitmoudle5.R.style;
import com.sportq.fit.fitmoudle5.adapter.MasterSelectClassAdapter;
import com.sportq.fit.fitmoudle5.event.MasterPlayVideoEvent;
import com.sportq.fit.fitmoudle5.interfaces.MasterVideoListener;
import com.sportq.fit.fitmoudle5.presenter.MasterPlayerPresenter;
import com.sportq.fit.fitmoudle5.reformer.MasterVideoReformer;
import com.sportq.fit.fitmoudle5.reformer.model.LesSectionDetModel;
import com.sportq.fit.fitmoudle5.utils.CacheManager;
import com.sportq.fit.fitmoudle5.utils.DoubleClickUtils;
import com.sportq.fit.fitmoudle5.utils.SharePreferenceUtils5;
import com.sportq.fit.fitmoudle5.widget.CustomRecyclerView;
import com.sportq.fit.fitmoudle5.widget.MasterVideoShareDialog;
import com.tencent.bugly.crashreport.CrashReport;
import java.io.File;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import org.byteam.superadapter.OnItemClickListener;
import org.greenrobot.eventbus.EventBus;
import tv.danmaku.ijk.media.player.IMediaPlayer;
import tv.danmaku.ijk.media.player.IMediaPlayer.OnBufferingUpdateListener;
import tv.danmaku.ijk.media.player.IMediaPlayer.OnCompletionListener;
import tv.danmaku.ijk.media.player.IMediaPlayer.OnErrorListener;
import tv.danmaku.ijk.media.player.IMediaPlayer.OnInfoListener;
import tv.danmaku.ijk.media.player.IMediaPlayer.OnPreparedListener;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;

public abstract class BaseVideoPlayer extends FrameLayout
  implements CacheListener, TextureView.SurfaceTextureListener, View.OnClickListener, MasterVpTouchHelper.MasterVpTouchHelperListener
{
  protected static final int DEFAULT_HIDE_CONTROLLER_TIME = 5000;
  public static final String EVENT_NEXT_VIDEO = "event.next.video";
  public static final String MASTER_EVENT_FINISHED = "detail.event.finished";
  protected static final int PROGRESS_TIMER_TIME = 500;
  private String activityState;
  protected RTextView btn_try_again;
  protected Timer controllerHideTimer = new Timer();
  protected Timer controllerShowTimer = new Timer();
  protected MasterControllerView controllerView;
  protected DoubleClickUtils doubleClickUtils;
  protected LinearLayout guideView;
  protected boolean isProgressRunning = false;
  protected MasterVideoListener listener;
  protected LinearLayout load_fail_layout;
  protected View mBlackView;
  protected LinearLayout mBrightnessDialog;
  protected ProgressBar mBrightnessProgress;
  protected Context mContext;
  protected LottieAnimationView mLoadingView;
  protected RelativeLayout mProgressDialog;
  protected ImageView mProgressDialogImg;
  protected CustomTextView mProgressDialogTxt;
  protected MasterVideoView mVideoViewOL;
  protected LinearLayout mVolumeDialog;
  protected ProgressBar mVolumeProgress;
  protected Handler mainThreadHandler;
  protected TextView master_detail_intro;
  protected TextView master_detail_title;
  protected LinearLayout master_intro_layout;
  protected IMediaPlayer mediaPlayer;
  protected View.OnTouchListener onTouchListener = new View.OnTouchListener()
  {
    public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
    {
      if (BaseVideoPlayer.this.select_layout.getVisibility() == 0)
        BaseVideoPlayer.this.select_layout.setVisibility(8);
      do
        do
        {
          return true;
          if (BaseVideoPlayer.this.doubleClickUtils == null)
            BaseVideoPlayer.this.doubleClickUtils = new DoubleClickUtils();
          if ((BaseVideoPlayer.this.doubleClickUtils.onDoubleClick(paramMotionEvent)) && (!BaseVideoPlayer.this.isLoadFailed()) && (!BaseVideoPlayer.this.isInit()))
          {
            LogUtils.d("BaseSptVideoPlayerOL->onTouch->双击事件:", "双击成功");
            BaseVideoPlayer.this.cancelShowTimer();
            if (BaseVideoPlayer.this.isPlaying())
            {
              BaseVideoPlayer.this.pause();
              return true;
            }
            BaseVideoPlayer.this.play();
            return true;
          }
          if ((BaseVideoPlayer.this.touchHelper == null) || (BaseVideoPlayer.this.isLoadFailed()))
            break;
          BaseVideoPlayer.this.getParent().requestDisallowInterceptTouchEvent(BaseVideoPlayer.this.isPlaying());
        }
        while (BaseVideoPlayer.this.touchHelper.onTouch(BaseVideoPlayer.this.mContext, paramMotionEvent));
      while ((paramMotionEvent.getAction() != 1) || (BaseVideoPlayer.this.isInit()));
      if (BaseVideoPlayer.this.controllerView.isVisibility())
      {
        BaseVideoPlayer.this.hideController();
        return true;
      }
      LogUtils.d("BaseSptVideoPlayerOL->onTouch->双击事件:", "显示控制器");
      BaseVideoPlayer.this.resetShowTimer();
      return true;
    }
  };
  protected EnumConstant.PageType pageType;
  protected RelativeLayout parent_layout;
  public PlayState playState = PlayState.PAUSE;
  protected ImageView player_btn_back;
  protected ImageView preview_img;
  protected Timer progressTimer;
  protected ProgressTimerTask progressTimerTask;
  public MasterVideoReformer reformer;
  protected MasterSelectClassAdapter selectClassAdapter;
  protected FrameLayout select_layout;
  protected CustomRecyclerView select_recyclerView;
  protected MasterVideoShareDialog shareDialog;
  protected Surface surface;
  protected MasterVpTouchHelper touchHelper;

  public BaseVideoPlayer(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public BaseVideoPlayer(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public BaseVideoPlayer(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, @AttrRes int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    initView(paramContext);
  }

  private void cancelShowTimer()
  {
    if (this.controllerShowTimer != null)
    {
      this.controllerShowTimer.cancel();
      this.controllerShowTimer = null;
    }
  }

  private void initCacheParam(HttpProxyCacheServer paramHttpProxyCacheServer)
  {
    if (paramHttpProxyCacheServer.isCached(this.reformer.videoURL))
    {
      this.reformer.bufferPoint = 100;
      this.controllerView.setSecondProgress(this.reformer.duration);
    }
  }

  private void playVideo()
  {
    if (this.listener != null)
      this.listener.play();
    this.preview_img.setVisibility(8);
    this.mBlackView.setVisibility(0);
    this.controllerView.showController();
    this.controllerView.updatePlayBtnUI();
    this.controllerView.setPlayBtnState(false);
    this.controllerView.setPageData(this);
    resetHideTimer();
    hideIntroView();
    if (StringUtils.isNull(this.reformer.videoURL))
      return;
    if ((this.surface == null) && (this.mVideoViewOL.getSurfaceTexture() != null))
      this.surface = new Surface(this.mVideoViewOL.getSurfaceTexture());
    try
    {
      if (this.mediaPlayer == null)
      {
        this.mediaPlayer = new IjkMediaPlayer();
        this.mediaPlayer.setOnInfoListener(getOnInfoListener());
        ((IjkMediaPlayer)this.mediaPlayer).setOption(4, "mediacodec", 1L);
        ((IjkMediaPlayer)this.mediaPlayer).setOption(4, "mediacodec-auto-rotate", 1L);
        ((IjkMediaPlayer)this.mediaPlayer).setOption(4, "mediacodec-handle-resolution-change", 1L);
      }
      this.mediaPlayer.reset();
      this.mediaPlayer.setSurface(this.surface);
      if ((this.touchHelper != null) && (this.touchHelper.mAudioManager != null))
        this.touchHelper.mAudioManager.requestAudioFocus(getOnAudioFocusChangeListener(), 3, 2);
      this.mediaPlayer.setOnPreparedListener(new IMediaPlayer.OnPreparedListener()
      {
        public void onPrepared(IMediaPlayer paramIMediaPlayer)
        {
          LogUtils.d("BaseSptVideoPlayerOL->onPrepared->", "");
          BaseVideoPlayer.this.reformer.isPrepared = true;
          BaseVideoPlayer.this.seekTo(BaseVideoPlayer.this.reformer.currentPosition);
          BaseVideoPlayer.this.mediaPlayer.start();
          if ((!BaseVideoPlayer.this.isPlaying()) || (BaseVideoPlayer.this.reformer.isShareDialogShowing))
            BaseVideoPlayer.this.mediaPlayer.pause();
        }
      });
      this.mediaPlayer.setOnBufferingUpdateListener(new IMediaPlayer.OnBufferingUpdateListener()
      {
        public void onBufferingUpdate(IMediaPlayer paramIMediaPlayer, int paramInt)
        {
          LogUtils.d("BaseSptVideoPlayerOL->onBufferingUpdate->percent", String.valueOf(paramInt));
          BaseVideoPlayer.this.reformer.bufferUpdatePercent = paramInt;
        }
      });
      this.mediaPlayer.setOnCompletionListener(new IMediaPlayer.OnCompletionListener()
      {
        public void onCompletion(IMediaPlayer paramIMediaPlayer)
        {
          LogUtils.d("BaseSptVideoPlayerOL->mediaPlayer->onCompletion->", "onCompletion");
          if ((!BaseVideoPlayer.this.reformer.isCompleted) && (BaseVideoPlayer.this.reformer.isPrepared))
          {
            BaseVideoPlayer.this.reformer.isCompleted = true;
            EventBus.getDefault().post("detail.event.finished");
          }
        }
      });
      this.mediaPlayer.setOnErrorListener(new IMediaPlayer.OnErrorListener()
      {
        public boolean onError(IMediaPlayer paramIMediaPlayer, int paramInt1, int paramInt2)
        {
          String str1 = "";
          switch (paramInt1)
          {
          default:
            BaseVideoPlayer.this.loadFailed();
            if (BaseVideoPlayer.this.reformer == null)
              break;
          case -1004:
          case -1007:
          case 200:
          case 100:
          case -110:
          case 1:
          case -1010:
          case -10000:
          }
          for (String str2 = BaseVideoPlayer.this.reformer.videoURL; ; str2 = "")
          {
            CrashReport.postCatchedException(new Throwable("看看播放异常:" + str1 + "\n" + "视频链接：" + str2));
            return false;
            str1 = "IO异常";
            break;
            str1 = "MEDIA_ERROR_MALFORMED";
            break;
            str1 = "MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK";
            break;
            str1 = "MEDIA_ERROR_SERVER_DIED";
            break;
            ToastUtils.makeToast(BaseApplication.appliContext, "网络请求超时！");
            str1 = "网络请求超时";
            break;
            str1 = "未知错误";
            break;
            str1 = "不支持";
            break;
            BaseVideoPlayer.this.reformer.isCompleted = false;
            BaseVideoPlayer.this.reformer.isPrepared = false;
            str1 = "视频格式不支持或者链接有问题";
            if (!"".equals(CompDeviceInfoUtils.getNetType()))
              break;
            ToastUtils.makeToast(BaseApplication.appliContext, "请检查下您的网络连接");
            break;
          }
        }
      });
      startCacheVideo();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      CrashReport.postCatchedException(new Throwable("openVideo:" + localException.getMessage()));
    }
  }

  private void startCacheVideo()
  {
    HttpProxyCacheServer localHttpProxyCacheServer = CacheManager.getProxy();
    String str = localHttpProxyCacheServer.getProxyUrl(this.reformer.videoURL);
    localHttpProxyCacheServer.registerCacheListener(this, this.reformer.videoURL);
    try
    {
      Uri localUri = Uri.parse(str);
      this.mediaPlayer.setDataSource(this.mContext, localUri);
      this.mediaPlayer.prepareAsync();
      initCacheParam(localHttpProxyCacheServer);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      CrashReport.postCatchedException(new Throwable("startCacheVideo:" + localException.getMessage()));
      loadFailed();
    }
  }

  private long verifyPosition(long paramLong)
  {
    if (paramLong < 0L)
      paramLong = 0L;
    do
      return paramLong;
    while (paramLong <= getDuration());
    return getDuration();
  }

  protected void bindViews()
  {
    this.player_btn_back = ((ImageView)findViewById(R.id.player_btn_back));
    this.player_btn_back.setOnClickListener(this);
    this.select_layout = ((FrameLayout)findViewById(R.id.select_layout));
    this.select_recyclerView = ((CustomRecyclerView)findViewById(R.id.select_recyclerView));
    this.controllerView = ((MasterControllerView)findViewById(R.id.master_controller_view));
    this.controllerView.setListener(this, this);
    this.preview_img = ((ImageView)findViewById(R.id.preview_img));
    this.preview_img.setOnTouchListener(new View.OnTouchListener()
    {
      public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
      {
        return true;
      }
    });
    this.parent_layout = ((RelativeLayout)findViewById(R.id.parent_layout));
    this.master_intro_layout = ((LinearLayout)findViewById(R.id.master_intro_layout));
    this.master_detail_intro = ((TextView)findViewById(R.id.master_detail_intro));
    this.master_detail_title = ((TextView)findViewById(R.id.master_detail_title));
    this.mLoadingView = ((LottieAnimationView)findViewById(R.id.loadingView));
    this.mLoadingView.setAnimation("loading_anim.json");
    this.mLoadingView.loop(true);
    this.mBlackView = findViewById(R.id.blackView);
    this.mVideoViewOL = ((MasterVideoView)findViewById(R.id.videoViewOL));
    this.mVideoViewOL.setSurfaceTextureListener(this);
    this.guideView = ((LinearLayout)findViewById(R.id.guideView));
    this.guideView.setOnClickListener(this);
    this.load_fail_layout = ((LinearLayout)findViewById(R.id.load_fail_layout));
    this.btn_try_again = ((RTextView)findViewById(R.id.btn_try_again));
    this.btn_try_again.setOnClickListener(this);
    this.mProgressDialog = ((RelativeLayout)findViewById(R.id.progressDialog));
    this.mProgressDialogImg = ((ImageView)findViewById(R.id.progressDialogImg));
    this.mProgressDialogTxt = ((CustomTextView)findViewById(R.id.progressDialogTxt));
    this.mVideoViewOL.setOnTouchListener(this.onTouchListener);
    this.mBrightnessDialog = ((LinearLayout)findViewById(R.id.brightnessDialog));
    this.mBrightnessProgress = ((ProgressBar)findViewById(R.id.brightnessProgress));
    this.mVolumeDialog = ((LinearLayout)findViewById(R.id.volumeDialog));
    this.mVolumeProgress = ((ProgressBar)findViewById(R.id.volumeProgress));
    this.touchHelper = new MasterVpTouchHelper(getContext(), this);
  }

  public void cancelHideTimer()
  {
    if (this.controllerHideTimer != null)
    {
      this.controllerHideTimer.cancel();
      this.controllerHideTimer = null;
    }
  }

  public void destroy()
  {
    releaseMediaPlayer();
    progressTimerStop();
  }

  public void dismissProgressDialog()
  {
    if ((this.mProgressDialog != null) && (this.mProgressDialog.getVisibility() == 0))
    {
      this.mProgressDialog.setVisibility(8);
      if (!isPlaying())
        play();
    }
  }

  public long getCurrentPosition()
  {
    if (this.mediaPlayer != null)
      return this.mediaPlayer.getCurrentPosition();
    return 0L;
  }

  public long getDuration()
  {
    long l = 0L;
    if (this.mediaPlayer != null)
      l = this.mediaPlayer.getDuration();
    LogUtils.d("BaseSptVideoPlayerOL->getDuration->duration:", String.valueOf(l));
    return l;
  }

  public abstract AudioManager.OnAudioFocusChangeListener getOnAudioFocusChangeListener();

  public abstract IMediaPlayer.OnInfoListener getOnInfoListener();

  public int getProgress(long paramLong)
  {
    if (0L == getDuration())
      return 0;
    return (int)((float)verifyPosition(paramLong) / (float)getDuration() * this.reformer.duration);
  }

  public void hideController()
  {
    ImageView localImageView;
    if ((this.controllerView.isVisibility()) && (isPlaying()))
    {
      this.controllerView.hideController();
      if (!isLandScape())
      {
        localImageView = this.player_btn_back;
        if (isLandScape())
          break label51;
      }
    }
    label51: for (int i = 0; ; i = 8)
    {
      localImageView.setVisibility(i);
      return;
    }
  }

  public void hideIntroView()
  {
    if (this.master_intro_layout.getVisibility() == 0)
      this.master_intro_layout.setVisibility(8);
  }

  public void hideShareDialog()
  {
    if ((this.shareDialog != null) && (this.shareDialog.isShowing()));
    try
    {
      this.shareDialog.setCompletion(false);
      this.shareDialog.dismiss();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void initView(@NonNull Context paramContext)
  {
    View.inflate(paramContext, R.layout.master_videoplayer_layout, this);
    this.mainThreadHandler = new Handler();
    this.reformer = new MasterVideoReformer();
    bindViews();
    setTag("hint");
  }

  public boolean isInit()
  {
    return this.preview_img.getVisibility() == 0;
  }

  public boolean isLandScape()
  {
    return this.pageType == EnumConstant.PageType.EXPAND;
  }

  public boolean isLoadFailed()
  {
    return PlayState.RELOAD == this.playState;
  }

  public boolean isLoading()
  {
    return (this.mLoadingView != null) && (this.mLoadingView.getVisibility() == 0);
  }

  public boolean isPlaying()
  {
    return this.playState == PlayState.PLAY;
  }

  public void loadFailed()
  {
    if (isLoading())
    {
      this.mLoadingView.setVisibility(8);
      this.mLoadingView.cancelAnimation();
    }
    this.playState = PlayState.RELOAD;
    this.controllerView.updatePlayBtnUI();
    this.controllerView.loadFail();
    if ((!isLandScape()) && (this.load_fail_layout != null))
      this.load_fail_layout.setVisibility(0);
  }

  public void loadFinish()
  {
    if (isLoading())
    {
      this.mLoadingView.setVisibility(8);
      this.mLoadingView.cancelAnimation();
    }
    if (this.load_fail_layout != null)
      this.load_fail_layout.setVisibility(8);
    progressTimerStart();
  }

  public void loading()
  {
    if (this.mLoadingView.isAnimating())
      return;
    this.controllerView.setPlayBtnState(false);
    this.load_fail_layout.setVisibility(8);
    this.mLoadingView.setVisibility(0);
    this.mLoadingView.playAnimation();
    progressTimerStop();
  }

  public void onCacheAvailable(File paramFile, String paramString, int paramInt)
  {
    this.reformer.bufferPoint = paramInt;
    this.controllerView.setSecondProgress(paramInt * this.reformer.duration / 100);
  }

  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    int i = paramView.getId();
    if ((i == R.id.player_btn_back) || (i == R.id.btn_back))
      if (isLandScape())
        if (this.listener != null)
          this.listener.shrink();
    label47: 
    do
    {
      while (true)
      {
        break label47;
        do
          return;
        while (this.listener == null);
        this.listener.finished();
        return;
        if (i == R.id.playBtn)
        {
          if ((isInit()) || (this.mediaPlayer == null))
          {
            loading();
            openVideo();
            return;
          }
          playBtnClick();
          return;
        }
        if (i == R.id.portrait_pause_btn)
        {
          playBtnClick();
          return;
        }
        if (i == R.id.portrait_change_btn)
        {
          if (this.listener == null)
            continue;
          this.listener.expand();
          return;
        }
        if (i != R.id.master_share_btn)
          break;
        if ((this.shareDialog != null) && (this.shareDialog.isShowing()))
          continue;
        EventBus.getDefault().post("master.share");
        return;
      }
      if (i != R.id.btn_try_again)
        continue;
      reload();
      return;
    }
    while (i != R.id.select_class_btn);
    this.controllerView.hideController();
    this.select_layout.setVisibility(0);
    if (this.selectClassAdapter == null)
    {
      this.selectClassAdapter = new MasterSelectClassAdapter(this.mContext, this.reformer.selectList, R.layout.master_select_class_item_layout);
      this.selectClassAdapter.setCurrentIndex(this.reformer.currentIndex);
      this.select_recyclerView.setLayoutManager(new LinearLayoutManager(this.mContext));
      this.select_recyclerView.setAdapter(this.selectClassAdapter);
    }
    while (true)
    {
      this.selectClassAdapter.setOnItemClickListener(new OnItemClickListener()
      {
        public void onItemClick(View paramView, int paramInt1, int paramInt2)
        {
          BaseVideoPlayer.this.select_layout.setVisibility(8);
          EventBus.getDefault().post(new MasterPlayVideoEvent(((LesSectionDetModel)BaseVideoPlayer.this.reformer.selectList.get(paramInt2)).sectionId));
        }
      });
      return;
      this.selectClassAdapter.setCurrentIndex(this.reformer.currentIndex);
      this.selectClassAdapter.replaceAll(this.reformer.selectList);
    }
  }

  public void onPause()
  {
    if (this.mediaPlayer != null)
    {
      this.reformer.currentPosition = this.mediaPlayer.getCurrentPosition();
      this.mediaPlayer.pause();
      progressTimerStop();
    }
    if ((this.shareDialog != null) && (this.shareDialog.isShowing()))
      this.shareDialog.onPause();
  }

  public void onResume()
  {
    if ((this.mediaPlayer != null) && (isPlaying()))
      play();
    if ((this.shareDialog != null) && (this.shareDialog.isShowing()))
      this.shareDialog.onResume();
  }

  public void onSurfaceTextureAvailable(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2)
  {
    this.surface = new Surface(paramSurfaceTexture);
    if (isInit());
    while (true)
    {
      return;
      if (!"pause".equals(this.activityState))
        break;
      if (this.mediaPlayer == null)
        continue;
      this.mediaPlayer.setSurface(this.surface);
      return;
    }
    openVideo();
  }

  public boolean onSurfaceTextureDestroyed(SurfaceTexture paramSurfaceTexture)
  {
    return true;
  }

  public void onSurfaceTextureSizeChanged(SurfaceTexture paramSurfaceTexture, int paramInt1, int paramInt2)
  {
  }

  public void onSurfaceTextureUpdated(SurfaceTexture paramSurfaceTexture)
  {
    if ((this.mBlackView != null) && (this.mBlackView.getVisibility() == 0))
      this.mBlackView.setVisibility(8);
  }

  public void openVideo()
  {
    String str = ((LesSectionDetModel)this.reformer.selectList.get(this.reformer.currentIndex)).sectionId;
    if ((MasterCacheDBManager.getIntance().selectCache(str) != null) || ("no.hint".equals(getTag().toString())))
    {
      playVideo();
      return;
    }
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      ToastUtils.makeToast(this.mContext.getString(R.string.g_20_1));
      return;
    }
    if ("wifi".equals(CompDeviceInfoUtils.getNetType()))
    {
      playVideo();
      return;
    }
    new DialogManager().createChoiceDialog(new FitInterfaceUtils.DialogListener()
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        if (paramInt == -1)
        {
          BaseVideoPlayer.this.setTag("no.hint");
          BaseVideoPlayer.this.playVideo();
        }
      }
    }
    , this.mContext, "", "是否使用流量播放视频?");
  }

  public void pause()
  {
    if (this.mediaPlayer != null)
    {
      this.playState = PlayState.PAUSE;
      if (this.listener != null)
        this.listener.pause();
      this.controllerView.updatePlayBtnUI();
      onPause();
    }
  }

  public void play()
  {
    if (this.mediaPlayer == null);
    do
    {
      return;
      LogUtils.d("play_position:", String.valueOf(this.reformer.currentPosition));
      this.playState = PlayState.PLAY;
      this.controllerView.updatePlayBtnUI();
      this.mediaPlayer.start();
      if (this.listener == null)
        continue;
      this.listener.play();
    }
    while (this.progressTimerTask != null);
    progressTimerStart();
  }

  public void playBtnClick()
  {
    switch (13.$SwitchMap$com$sportq$fit$fitmoudle5$widget$player$BaseVideoPlayer$PlayState[this.playState.ordinal()])
    {
    default:
      pause();
      return;
    case 1:
      reload();
      return;
    case 2:
      play();
      return;
    case 3:
    }
    pause();
  }

  public void progressTimerStart()
  {
    progressTimerStop();
    this.isProgressRunning = true;
    this.progressTimer = new Timer();
    this.progressTimerTask = new ProgressTimerTask();
    this.progressTimer.schedule(this.progressTimerTask, 0L, 500L);
  }

  public void progressTimerStop()
  {
    this.isProgressRunning = false;
    if (this.progressTimer != null)
    {
      this.progressTimer.cancel();
      this.progressTimer = null;
    }
    if (this.progressTimerTask != null)
    {
      this.progressTimerTask.cancel();
      this.progressTimerTask = null;
    }
  }

  public void releaseMediaPlayer()
  {
    if (this.mediaPlayer != null)
    {
      this.mediaPlayer.stop();
      this.mediaPlayer.reset();
      this.mediaPlayer.release();
      this.mediaPlayer = null;
    }
  }

  public void reload()
  {
    this.playState = PlayState.PLAY;
    loading();
    openVideo();
  }

  public void resetHideTimer()
  {
    if (!this.controllerView.isVisibility())
      return;
    cancelHideTimer();
    this.controllerHideTimer = new Timer();
    this.controllerHideTimer.schedule(new TimerTask()
    {
      public void run()
      {
        new Handler(BaseVideoPlayer.this.mContext.getMainLooper()).post(new Runnable()
        {
          public void run()
          {
            BaseVideoPlayer.this.hideController();
          }
        });
      }
    }
    , 5000L);
  }

  public void resetShowTimer()
  {
    if (this.controllerView.isVisibility())
      return;
    cancelShowTimer();
    this.controllerShowTimer = new Timer();
    this.controllerShowTimer.schedule(new TimerTask()
    {
      public void run()
      {
        new Handler(BaseVideoPlayer.this.mContext.getMainLooper()).post(new Runnable()
        {
          public void run()
          {
            BaseVideoPlayer.this.showController();
          }
        });
      }
    }
    , 100L);
  }

  public void restore()
  {
    destroy();
    this.preview_img.setVisibility(0);
    GlideUtils.loadCacheImg(this.mContext, this.reformer.imageUrl, this.preview_img);
    this.playState = PlayState.PAUSE;
    this.controllerView.updatePlayBtnUI();
    this.controllerView.setPlayBtnState(true);
    this.controllerView.showController();
    this.controllerView.hideTitle();
    this.controllerView.hideBottomView();
    cancelHideTimer();
    this.reformer.currentPosition = 0L;
    this.reformer.currentPlayTime = 0;
    this.reformer.isCompleted = false;
    this.reformer.isPrepared = false;
    this.playState = PlayState.PLAY;
    releaseMediaPlayer();
    setTotalTime(this.reformer.duration);
    setProgress(0);
    this.progressTimer = new Timer();
    this.progressTimerTask = new ProgressTimerTask();
  }

  public void seekTo(long paramLong)
  {
    if (this.mediaPlayer != null)
    {
      LogUtils.d("BaseSptVideoPlayerOL->seekTo->position:", String.valueOf(paramLong));
      this.mediaPlayer.seekTo(verifyPosition(paramLong));
    }
  }

  public void setActivityState(String paramString)
  {
    this.activityState = paramString;
  }

  public void setContext(Context paramContext)
  {
    this.mContext = paramContext;
  }

  public void setCurrentTime(int paramInt)
  {
    this.reformer.currentPlayTime = paramInt;
    this.controllerView.setCurrentTime(paramInt);
  }

  public void setPageType(EnumConstant.PageType paramPageType)
  {
    this.pageType = paramPageType;
    int j;
    label170: LinearLayout localLinearLayout;
    int i;
    if (paramPageType == EnumConstant.PageType.SHRINK)
    {
      this.parent_layout.getLayoutParams().height = (int)(0.5625D * Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight));
      this.parent_layout.getLayoutParams().width = Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight);
      this.controllerView.shrink();
      if (this.select_layout.getVisibility() == 0)
        this.select_layout.setVisibility(8);
      if ((this.shareDialog != null) && (this.shareDialog.isShowing()))
        this.shareDialog.dismiss();
      if ((this.guideView != null) && (this.guideView.getVisibility() == 0))
      {
        this.guideView.setVisibility(8);
        SharePreferenceUtils5.putMasterVideoGuide(getContext());
        play();
      }
      ImageView localImageView = this.player_btn_back;
      if (this.controllerView.isVisibility())
      {
        j = 8;
        localImageView.setVisibility(j);
        if (this.playState == PlayState.RELOAD)
        {
          localLinearLayout = this.load_fail_layout;
          EnumConstant.PageType localPageType = EnumConstant.PageType.SHRINK;
          i = 0;
          if (paramPageType != localPageType)
            break label293;
        }
      }
    }
    while (true)
    {
      localLinearLayout.setVisibility(i);
      return;
      j = 0;
      break;
      this.player_btn_back.setVisibility(8);
      this.parent_layout.getLayoutParams().width = Math.max(BaseApplication.screenWidth, BaseApplication.screenHeight);
      this.parent_layout.getLayoutParams().height = (Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight) - CompDeviceInfoUtils.getStatusBarHeight(this.mContext));
      this.controllerView.expand();
      if (SharePreferenceUtils5.getMasterVideoGuide(getContext()))
        break label170;
      pause();
      showGuideView();
      break label170;
      label293: i = 8;
    }
  }

  public void setProgress(int paramInt)
  {
    setTextAndSeekBarProgress(paramInt);
  }

  public void setProgress(long paramLong)
  {
    setProgress(getProgress(paramLong));
  }

  public void setTextAndSeekBarProgress(int paramInt)
  {
    setCurrentTime(paramInt);
    this.controllerView.setSeekBarProgress(paramInt);
  }

  protected void setTotalTime(int paramInt)
  {
    this.reformer.duration = paramInt;
    this.controllerView.setMax(paramInt);
    this.controllerView.setTotalTime(paramInt);
  }

  public void showController()
  {
    if (!this.controllerView.isVisibility())
      this.controllerView.showController();
    resetHideTimer();
    if (this.pageType == EnumConstant.PageType.SHRINK)
      return;
    this.controllerView.updatePlayBtnUI();
    this.player_btn_back.setVisibility(8);
  }

  public void showGuideView()
  {
    this.guideView.setVisibility(0);
    this.guideView.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        paramView.setVisibility(8);
        SharePreferenceUtils5.putMasterVideoGuide(BaseVideoPlayer.this.getContext());
        BaseVideoPlayer.this.play();
      }
    });
  }

  public void showIntroView(String paramString1, String paramString2)
  {
    int i = 8;
    this.master_intro_layout.setVisibility(0);
    this.master_detail_title.setText(paramString1);
    this.master_detail_intro.setText(paramString2);
    TextView localTextView1 = this.master_detail_title;
    int j;
    TextView localTextView2;
    if (StringUtils.isNull(paramString1))
    {
      j = i;
      localTextView1.setVisibility(j);
      localTextView2 = this.master_detail_intro;
      if (!StringUtils.isNull(paramString2))
        break label76;
    }
    while (true)
    {
      localTextView2.setVisibility(i);
      return;
      j = 0;
      break;
      label76: i = 0;
    }
  }

  public void showProgressDialog(int paramInt, long paramLong)
  {
    if (this.mProgressDialog != null)
    {
      this.mProgressDialog.setVisibility(0);
      if (paramInt != 0)
        break label85;
      this.mProgressDialogImg.setImageResource(R.mipmap.icn_forward2);
    }
    while (true)
    {
      int i = getProgress(paramLong);
      CustomTextView localCustomTextView = this.mProgressDialogTxt;
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = StringUtils.timeInt2Str(i);
      arrayOfObject[1] = StringUtils.timeInt2Str(this.reformer.duration);
      localCustomTextView.setText(String.format("%s/%s", arrayOfObject));
      return;
      label85: this.mProgressDialogImg.setImageResource(R.mipmap.icn_forward);
    }
  }

  public void showShareDialog(MasterPlayerPresenter paramMasterPlayerPresenter, UseShareModel paramUseShareModel, com.sportq.fit.common.interfaces.dialog.DialogInterface paramDialogInterface)
  {
    if (this.shareDialog == null)
    {
      this.shareDialog = new MasterVideoShareDialog(this.mContext, R.style.MasterShareDialog);
      this.shareDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
      {
        public void onDismiss(android.content.DialogInterface paramDialogInterface)
        {
          BaseVideoPlayer.this.reformer.isShareDialogShowing = false;
          if ((BaseVideoPlayer.this.shareDialog != null) && (BaseVideoPlayer.this.shareDialog.isCompletion()))
          {
            BaseVideoPlayer.this.restore();
            if (BaseVideoPlayer.this.listener != null)
              BaseVideoPlayer.this.listener.shrink();
          }
          do
            return;
          while ("pause".equals(BaseVideoPlayer.this.activityState));
          BaseVideoPlayer.this.onResume();
        }
      });
    }
    if (!isInit())
      hideController();
    this.shareDialog.setVideoLists(paramMasterPlayerPresenter.getShareVideoList());
    this.shareDialog.setModel(paramUseShareModel);
    this.shareDialog.setDialog(paramDialogInterface);
    this.shareDialog.setCompletion(this.reformer.isCompleted);
    this.shareDialog.show();
    this.reformer.isShareDialogShowing = true;
  }

  public static enum PlayState
  {
    static
    {
      PAUSE = new PlayState("PAUSE", 1);
      RELOAD = new PlayState("RELOAD", 2);
      PlayState[] arrayOfPlayState = new PlayState[3];
      arrayOfPlayState[0] = PLAY;
      arrayOfPlayState[1] = PAUSE;
      arrayOfPlayState[2] = RELOAD;
      $VALUES = arrayOfPlayState;
    }
  }

  protected class ProgressTimerTask extends TimerTask
  {
    protected ProgressTimerTask()
    {
    }

    public void run()
    {
      if ((BaseVideoPlayer.this.playState == BaseVideoPlayer.PlayState.PLAY) && (BaseVideoPlayer.this.mainThreadHandler != null))
        BaseVideoPlayer.this.mainThreadHandler.post(new Runnable()
        {
          public void run()
          {
            if (BaseVideoPlayer.this.mediaPlayer != null)
            {
              int i = BaseVideoPlayer.this.getProgress(BaseVideoPlayer.this.mediaPlayer.getCurrentPosition());
              if (i > 0)
                BaseVideoPlayer.this.setTextAndSeekBarProgress(i);
            }
          }
        });
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.player.BaseVideoPlayer
 * JD-Core Version:    0.6.0
 */