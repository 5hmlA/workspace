package com.sportq.fit.fitmoudle5.presenter;

import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle5.reformer.MasterVideoReformer;
import com.sportq.fit.fitmoudle5.reformer.model.EntLesSectionDetModel;
import com.sportq.fit.fitmoudle5.reformer.model.EntLessonDetModel;
import com.sportq.fit.fitmoudle5.reformer.model.LesSectionDetModel;
import java.util.ArrayList;

public class MasterPlayerPresenter
{
  public InitPlayListener listener;
  public MasterVideoReformer reformer;

  public MasterPlayerPresenter(InitPlayListener paramInitPlayListener)
  {
    this.listener = paramInitPlayListener;
  }

  private void initReformer(Object paramObject, boolean paramBoolean)
  {
    boolean bool1 = true;
    if (this.reformer == null)
      this.reformer = new MasterVideoReformer();
    if ((paramObject instanceof EntLesSectionDetModel))
    {
      EntLesSectionDetModel localEntLesSectionDetModel = (EntLesSectionDetModel)paramObject;
      if ((localEntLesSectionDetModel.lstLesSection != null) && (localEntLesSectionDetModel.lstLesSection.size() > 0))
      {
        this.reformer.currentIndex = localEntLesSectionDetModel.curPlayIndex;
        LesSectionDetModel localLesSectionDetModel = (LesSectionDetModel)localEntLesSectionDetModel.lstLesSection.get(localEntLesSectionDetModel.curPlayIndex);
        this.reformer.title = localLesSectionDetModel.title;
        this.reformer.videoURL = localLesSectionDetModel.videoURL;
        this.reformer.imageUrl = localLesSectionDetModel.videoImage;
        this.reformer.duration = StringUtils.string2Int(localLesSectionDetModel.videoTime);
        if (this.reformer.currentIndex >= -1 + localEntLesSectionDetModel.lstLesSection.size())
          this.reformer.isLastOne = bool1;
        this.reformer.isShowPlayBtn = bool1;
        this.reformer.isGuideVideo = false;
        MasterVideoReformer localMasterVideoReformer4 = this.reformer;
        if (paramBoolean)
          break label219;
        localMasterVideoReformer4.isCanPlay = bool1;
        this.reformer.selectList = localEntLesSectionDetModel.lstLesSection;
        this.listener.initPlay(this.reformer);
      }
    }
    label219: 
    do
    {
      return;
      bool1 = false;
      break;
    }
    while (!(paramObject instanceof EntLessonDetModel));
    EntLessonDetModel localEntLessonDetModel = (EntLessonDetModel)paramObject;
    this.reformer.currentIndex = 0;
    this.reformer.title = localEntLessonDetModel.title;
    this.reformer.videoURL = localEntLessonDetModel.videoURL;
    this.reformer.imageUrl = localEntLessonDetModel.imageUrl;
    this.reformer.duration = StringUtils.string2Int(localEntLessonDetModel.videoTime);
    if (this.reformer.currentIndex >= -1 + localEntLessonDetModel.lstLesSection.size())
      this.reformer.isLastOne = bool1;
    MasterVideoReformer localMasterVideoReformer1 = this.reformer;
    boolean bool2;
    boolean bool3;
    label364: MasterVideoReformer localMasterVideoReformer3;
    if (!paramBoolean)
    {
      bool2 = bool1;
      localMasterVideoReformer1.isCanPlay = bool2;
      MasterVideoReformer localMasterVideoReformer2 = this.reformer;
      if (StringUtils.isNull(localEntLessonDetModel.videoURL))
        break label453;
      bool3 = bool1;
      localMasterVideoReformer2.isShowPlayBtn = bool3;
      this.reformer.isLastOne = bool1;
      localMasterVideoReformer3 = this.reformer;
      if (StringUtils.isNull(localEntLessonDetModel.videoURL))
        break label459;
    }
    while (true)
    {
      localMasterVideoReformer3.isGuideVideo = bool1;
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(new LesSectionDetModel());
      this.reformer.selectList = localArrayList;
      this.listener.initPlay(this.reformer);
      return;
      bool2 = false;
      break;
      label453: bool3 = false;
      break label364;
      label459: bool1 = false;
    }
  }

  public MasterVideoReformer getReformer()
  {
    if (this.reformer == null)
      this.reformer = new MasterVideoReformer();
    return this.reformer;
  }

  public ArrayList<LesSectionDetModel> getShareVideoList()
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < this.reformer.selectList.size(); i++)
    {
      if (i <= this.reformer.currentIndex)
        continue;
      localArrayList.add(this.reformer.selectList.get(i));
    }
    return localArrayList;
  }

  public void initReformer(Object paramObject)
  {
    initReformer(paramObject, true);
  }

  public void playNext(EntLesSectionDetModel paramEntLesSectionDetModel)
  {
    initReformer(paramEntLesSectionDetModel, false);
  }

  public void setReformer(MasterVideoReformer paramMasterVideoReformer)
  {
    this.reformer = paramMasterVideoReformer;
  }

  public static abstract interface InitPlayListener
  {
    public abstract void initPlay(MasterVideoReformer paramMasterVideoReformer);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.presenter.MasterPlayerPresenter
 * JD-Core Version:    0.6.0
 */