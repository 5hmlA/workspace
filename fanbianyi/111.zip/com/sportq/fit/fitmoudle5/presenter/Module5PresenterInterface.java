package com.sportq.fit.fitmoudle5.presenter;

import android.content.Context;
import com.sportq.fit.common.model.request.RequestModel;

public abstract interface Module5PresenterInterface
{
  public abstract void getAllLesson(RequestModel paramRequestModel, Context paramContext);

  public abstract void getLesSectionDet(RequestModel paramRequestModel, Context paramContext);

  public abstract void getLessonDet(RequestModel paramRequestModel, Context paramContext);

  public abstract void getUserLesson(RequestModel paramRequestModel, Context paramContext);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.presenter.Module5PresenterInterface
 * JD-Core Version:    0.6.0
 */