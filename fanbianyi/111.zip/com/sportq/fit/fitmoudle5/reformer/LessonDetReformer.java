package com.sportq.fit.fitmoudle5.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle5.reformer.model.EntLessonDetModel;
import java.io.Serializable;

public class LessonDetReformer extends BaseReformer
  implements Serializable
{
  public EntLessonDetModel entLessonDet;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.LessonDetReformer
 * JD-Core Version:    0.6.0
 */