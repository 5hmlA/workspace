package com.sportq.fit.fitmoudle5.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle5.reformer.data.LesSectionDetData;

public class LesSectionDetReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    LesSectionDetData localLesSectionDetData = (LesSectionDetData)paramBaseData;
    LesSectionDetReformer localLesSectionDetReformer = new LesSectionDetReformer();
    localLesSectionDetReformer.entLesSectionDet = localLesSectionDetData.entLesSectionDet;
    return localLesSectionDetReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (LesSectionDetData)FitGsonFactory.create().fromJson(paramString2, LesSectionDetData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.LesSectionDetReformerImpl
 * JD-Core Version:    0.6.0
 */