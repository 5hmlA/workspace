package com.sportq.fit.fitmoudle5.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle5.reformer.model.EntLesSectionDetModel;

public class LesSectionDetReformer extends BaseReformer
{
  public EntLesSectionDetModel entLesSectionDet;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.LesSectionDetReformer
 * JD-Core Version:    0.6.0
 */