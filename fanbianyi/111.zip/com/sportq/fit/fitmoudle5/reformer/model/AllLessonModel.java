package com.sportq.fit.fitmoudle5.reformer.model;

import com.sportq.fit.common.model.BaseModel;

public class AllLessonModel extends BaseModel
{
  public String advLink;
  public String bannerCode;
  public String bannerType;
  public String courseNumber;
  public String freeFlg;
  public String imageUrl;
  public String intr;
  public String isBuy;
  public String isNewTag;
  public String lessonId;
  public String olapInfo;
  public String price;
  public String title;
  public String wechatKeyword;
  public String wechatNum;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.model.AllLessonModel
 * JD-Core Version:    0.6.0
 */