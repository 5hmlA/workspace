package com.sportq.fit.fitmoudle5.reformer.model;

import com.sportq.fit.common.model.BaseModel;
import java.util.ArrayList;

public class AllLessonBaseModel extends BaseModel
{
  public ArrayList<AllLessonModel> lstBanner;
  public ArrayList<AllLessonModel> lstLesson;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.model.AllLessonBaseModel
 * JD-Core Version:    0.6.0
 */