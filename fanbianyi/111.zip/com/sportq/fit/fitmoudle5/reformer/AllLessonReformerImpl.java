package com.sportq.fit.fitmoudle5.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle5.reformer.data.AllLessonData;
import com.sportq.fit.fitmoudle5.reformer.model.AllLessonBaseModel;
import com.sportq.fit.fitmoudle5.reformer.model.AllLessonModel;
import java.util.ArrayList;
import java.util.Iterator;

public class AllLessonReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    AllLessonData localAllLessonData = (AllLessonData)paramBaseData;
    AllLessonReformer localAllLessonReformer = new AllLessonReformer();
    ArrayList localArrayList1 = new ArrayList();
    if ((localAllLessonData.entAllLesson != null) && (localAllLessonData.entAllLesson.lstBanner != null) && (localAllLessonData.entAllLesson.lstBanner.size() != 0))
    {
      Iterator localIterator2 = localAllLessonData.entAllLesson.lstBanner.iterator();
      while (localIterator2.hasNext())
      {
        AllLessonModel localAllLessonModel3 = (AllLessonModel)localIterator2.next();
        AllLessonModel localAllLessonModel4 = new AllLessonModel();
        localAllLessonModel4.bannerCode = localAllLessonModel3.bannerCode;
        localAllLessonModel4.bannerType = localAllLessonModel3.bannerType;
        localAllLessonModel4.imageUrl = localAllLessonModel3.imageUrl;
        localAllLessonModel4.advLink = localAllLessonModel3.advLink;
        localAllLessonModel4.olapInfo = localAllLessonModel3.olapInfo;
        localArrayList1.add(localAllLessonModel4);
      }
    }
    localAllLessonReformer.lstBanner = localArrayList1;
    ArrayList localArrayList2 = new ArrayList();
    if ((localAllLessonData.entAllLesson != null) && (localAllLessonData.entAllLesson.lstLesson != null) && (localAllLessonData.entAllLesson.lstLesson.size() != 0));
    for (ArrayList localArrayList3 = localAllLessonData.entAllLesson.lstLesson; (localArrayList3 != null) && (localArrayList3.size() != 0); localArrayList3 = localAllLessonData.lstLesson)
    {
      Iterator localIterator1 = localArrayList3.iterator();
      while (localIterator1.hasNext())
      {
        AllLessonModel localAllLessonModel1 = (AllLessonModel)localIterator1.next();
        AllLessonModel localAllLessonModel2 = new AllLessonModel();
        localAllLessonModel2.lessonId = localAllLessonModel1.lessonId;
        localAllLessonModel2.title = localAllLessonModel1.title;
        localAllLessonModel2.intr = localAllLessonModel1.intr;
        localAllLessonModel2.courseNumber = localAllLessonModel1.courseNumber;
        localAllLessonModel2.imageUrl = localAllLessonModel1.imageUrl;
        localAllLessonModel2.price = localAllLessonModel1.price;
        localAllLessonModel2.isNewTag = localAllLessonModel1.isNewTag;
        localAllLessonModel2.isBuy = localAllLessonModel1.isBuy;
        localAllLessonModel2.freeFlg = localAllLessonModel1.freeFlg;
        localAllLessonModel2.wechatKeyword = localAllLessonModel1.wechatKeyword;
        localAllLessonModel2.wechatNum = localAllLessonModel1.wechatNum;
        localAllLessonModel2.olapInfo = localAllLessonModel1.olapInfo;
        localArrayList2.add(localAllLessonModel2);
      }
    }
    localAllLessonReformer.lstLesson = localArrayList2;
    return localAllLessonReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (AllLessonData)FitGsonFactory.create().fromJson(paramString2, AllLessonData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.AllLessonReformerImpl
 * JD-Core Version:    0.6.0
 */