package com.sportq.fit.fitmoudle5.reformer.data;

import com.sportq.fit.common.BaseData;
import com.sportq.fit.fitmoudle5.reformer.model.EntLessonDetModel;

public class LessonDetData extends BaseData
{
  public EntLessonDetModel entLessonDet;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.data.LessonDetData
 * JD-Core Version:    0.6.0
 */