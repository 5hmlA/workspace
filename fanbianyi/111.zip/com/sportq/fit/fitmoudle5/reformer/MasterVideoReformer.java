package com.sportq.fit.fitmoudle5.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.fitmoudle5.reformer.model.LesSectionDetModel;
import java.io.Serializable;
import java.util.ArrayList;

public class MasterVideoReformer extends BaseReformer
  implements Serializable
{
  public int bufferPoint;
  public int bufferUpdatePercent;
  public int currentIndex;
  public int currentPlayTime;
  public long currentPosition;
  public int duration;
  public String imageUrl;
  public boolean isCanPlay = false;
  public boolean isCompleted = false;
  public boolean isGuideVideo = false;
  public boolean isLastOne = false;
  public boolean isPrepared = false;
  public boolean isShareDialogShowing = false;
  public boolean isShowPlayBtn = false;
  public ArrayList<LesSectionDetModel> selectList;
  public String title;
  public String videoURL;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.MasterVideoReformer
 * JD-Core Version:    0.6.0
 */