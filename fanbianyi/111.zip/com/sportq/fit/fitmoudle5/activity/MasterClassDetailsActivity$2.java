package com.sportq.fit.fitmoudle5.activity;

import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle5.reformer.model.EntLessonDetModel;

class MasterClassDetailsActivity$2
  implements Runnable
{
  public void run()
  {
    if ((MasterClassDetailsActivity.access$000(this.this$0) != null) && (!StringUtils.isNull(MasterClassDetailsActivity.access$000(this.this$0).videoURL)) && (this.this$0.getRequestedOrientation() != 10))
      this.this$0.setRequestedOrientation(10);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterClassDetailsActivity.2
 * JD-Core Version:    0.6.0
 */