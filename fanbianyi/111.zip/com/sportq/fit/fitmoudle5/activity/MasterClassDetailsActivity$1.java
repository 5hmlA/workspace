package com.sportq.fit.fitmoudle5.activity;

import android.support.design.widget.AppBarLayout;
import android.support.design.widget.AppBarLayout.OnOffsetChangedListener;
import android.support.v7.widget.Toolbar;
import com.sportq.fit.fitmoudle5.reformer.model.EntLessonDetModel;

class MasterClassDetailsActivity$1
  implements AppBarLayout.OnOffsetChangedListener
{
  public void onOffsetChanged(AppBarLayout paramAppBarLayout, int paramInt)
  {
    if ((paramInt != 0) && (Math.abs(paramInt) >= paramAppBarLayout.getTotalScrollRange()))
    {
      if (MasterClassDetailsActivity.access$000(this.this$0) != null)
      {
        MasterClassDetailsActivity.access$100(this.this$0).setVisibility(0);
        MasterClassDetailsActivity.access$100(this.this$0).setTitle(MasterClassDetailsActivity.access$000(this.this$0).title);
      }
      return;
    }
    MasterClassDetailsActivity.access$100(this.this$0).setVisibility(4);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterClassDetailsActivity.1
 * JD-Core Version:    0.6.0
 */