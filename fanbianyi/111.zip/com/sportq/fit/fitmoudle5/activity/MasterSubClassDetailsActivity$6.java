package com.sportq.fit.fitmoudle5.activity;

class MasterSubClassDetailsActivity$6
  implements Runnable
{
  public void run()
  {
    if (this.this$0.getRequestedOrientation() != 10)
      this.this$0.setRequestedOrientation(10);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterSubClassDetailsActivity.6
 * JD-Core Version:    0.6.0
 */