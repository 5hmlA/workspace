package com.sportq.fit.fitmoudle5.activity;

import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.widget.viewpager.FixedSpeedScroller;
import java.util.ArrayList;

class MasterClassListActivity$MyOnPageChangeListener
  implements ViewPager.OnPageChangeListener
{
  private ArrayList<View> listViews;
  private FixedSpeedScroller mScroller;
  private LinearLayout page_index_layout;

  MasterClassListActivity$MyOnPageChangeListener(ArrayList<View> paramArrayList, FixedSpeedScroller paramFixedSpeedScroller, LinearLayout paramLinearLayout)
  {
    this.listViews = paramFixedSpeedScroller;
    this.mScroller = paramLinearLayout;
    Object localObject;
    this.page_index_layout = localObject;
  }

  public void onPageScrollStateChanged(int paramInt)
  {
  }

  public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
  {
  }

  public void onPageSelected(int paramInt)
  {
    if (paramInt == -1 + this.listViews.size())
    {
      if (this.mScroller == null)
        return;
      this.mScroller.setmDuration(0);
    }
    while (true)
    {
      MasterClassListActivity.access$100(this.this$0).setBackgroundResource(R.mipmap.icn_slider2);
      LinearLayout.LayoutParams localLayoutParams1 = (LinearLayout.LayoutParams)MasterClassListActivity.access$100(this.this$0).getLayoutParams();
      localLayoutParams1.gravity = 16;
      localLayoutParams1.width = CompDeviceInfoUtils.convertOfDip(this.this$0, 7.0F);
      localLayoutParams1.height = CompDeviceInfoUtils.convertOfDip(this.this$0, 7.0F);
      MasterClassListActivity.access$100(this.this$0).setLayoutParams(localLayoutParams1);
      TextView localTextView = (TextView)this.page_index_layout.getChildAt(paramInt);
      localTextView.setBackgroundResource(R.mipmap.icn_slider1);
      LinearLayout.LayoutParams localLayoutParams2 = (LinearLayout.LayoutParams)localTextView.getLayoutParams();
      localLayoutParams2.gravity = 16;
      localLayoutParams2.width = CompDeviceInfoUtils.convertOfDip(this.this$0, 9.0F);
      localLayoutParams2.height = CompDeviceInfoUtils.convertOfDip(this.this$0, 9.0F);
      localTextView.setLayoutParams(localLayoutParams2);
      MasterClassListActivity.access$102(this.this$0, localTextView);
      return;
      if (paramInt != 0)
        continue;
      if (this.mScroller == null)
        break;
      this.mScroller.setmDuration(100);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterClassListActivity.MyOnPageChangeListener
 * JD-Core Version:    0.6.0
 */