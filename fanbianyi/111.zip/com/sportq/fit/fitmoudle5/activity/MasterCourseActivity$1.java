package com.sportq.fit.fitmoudle5.activity;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle.AnimationUtil;

class MasterCourseActivity$1
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    Intent localIntent = new Intent(this.this$0, MasterClassListActivity.class);
    this.this$0.startActivity(localIntent);
    AnimationUtil.pageJumpAnim(this.this$0, 0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterCourseActivity.1
 * JD-Core Version:    0.6.0
 */