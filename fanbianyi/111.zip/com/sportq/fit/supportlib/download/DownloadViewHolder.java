package com.sportq.fit.supportlib.download;

import android.view.View;
import java.io.File;
import org.xutils.ViewInjector;
import org.xutils.common.Callback.CancelledException;
import org.xutils.x;

public abstract class DownloadViewHolder
{
  protected DownloadInfo downloadInfo;

  public DownloadViewHolder(View paramView, DownloadInfo paramDownloadInfo)
  {
    this.downloadInfo = paramDownloadInfo;
    x.view().inject(this, paramView);
  }

  public DownloadViewHolder(DownloadInfo paramDownloadInfo)
  {
    this.downloadInfo = paramDownloadInfo;
  }

  public final DownloadInfo getDownloadInfo()
  {
    return this.downloadInfo;
  }

  public abstract void onCancelled(Callback.CancelledException paramCancelledException);

  public abstract void onError(Throwable paramThrowable, boolean paramBoolean);

  public abstract void onLoading(long paramLong1, long paramLong2);

  public abstract void onStarted();

  public abstract void onSuccess(File paramFile);

  public abstract void onWaiting();

  public void update(DownloadInfo paramDownloadInfo)
  {
    this.downloadInfo = paramDownloadInfo;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.supportlib.download.DownloadViewHolder
 * JD-Core Version:    0.6.0
 */