package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;

class StickyListHeadersListView$1
  implements View.OnClickListener
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    StickyListHeadersListView.access$500(this.this$0).onHeaderClick(this.this$0, StickyListHeadersListView.access$200(this.this$0), StickyListHeadersListView.access$300(this.this$0).intValue(), StickyListHeadersListView.access$400(this.this$0).longValue(), true);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersListView.1
 * JD-Core Version:    0.6.0
 */