package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.database.DataSetObserver;

class StickyListHeadersListView$AdapterWrapperDataSetObserver extends DataSetObserver
{
  private StickyListHeadersListView$AdapterWrapperDataSetObserver(StickyListHeadersListView paramStickyListHeadersListView)
  {
  }

  public void onChanged()
  {
    StickyListHeadersListView.access$600(this.this$0);
  }

  public void onInvalidated()
  {
    StickyListHeadersListView.access$600(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersListView.AdapterWrapperDataSetObserver
 * JD-Core Version:    0.6.0
 */