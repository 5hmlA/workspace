package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.content.Context;
import android.widget.Checkable;

class CheckableWrapperView extends WrapperView
  implements Checkable
{
  public CheckableWrapperView(Context paramContext)
  {
    super(paramContext);
  }

  public boolean isChecked()
  {
    return ((Checkable)this.mItem).isChecked();
  }

  public void setChecked(boolean paramBoolean)
  {
    ((Checkable)this.mItem).setChecked(paramBoolean);
  }

  public void toggle()
  {
    if (!isChecked());
    for (boolean bool = true; ; bool = false)
    {
      setChecked(bool);
      return;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.CheckableWrapperView
 * JD-Core Version:    0.6.0
 */