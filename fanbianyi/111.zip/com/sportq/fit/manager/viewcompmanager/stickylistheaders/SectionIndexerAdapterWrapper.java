package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.content.Context;
import android.widget.SectionIndexer;

class SectionIndexerAdapterWrapper extends AdapterWrapper
  implements SectionIndexer
{
  final SectionIndexer mSectionIndexerDelegate;

  SectionIndexerAdapterWrapper(Context paramContext, StickyListHeadersAdapter paramStickyListHeadersAdapter)
  {
    super(paramContext, paramStickyListHeadersAdapter);
    this.mSectionIndexerDelegate = ((SectionIndexer)paramStickyListHeadersAdapter);
  }

  public int getPositionForSection(int paramInt)
  {
    return this.mSectionIndexerDelegate.getPositionForSection(paramInt);
  }

  public int getSectionForPosition(int paramInt)
  {
    return this.mSectionIndexerDelegate.getSectionForPosition(paramInt);
  }

  public Object[] getSections()
  {
    return this.mSectionIndexerDelegate.getSections();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.SectionIndexerAdapterWrapper
 * JD-Core Version:    0.6.0
 */