package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;

public abstract interface StickyListHeadersAdapter extends ListAdapter
{
  public abstract long getHeaderId(int paramInt);

  public abstract View getHeaderView(int paramInt, View paramView, ViewGroup paramViewGroup);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersAdapter
 * JD-Core Version:    0.6.0
 */