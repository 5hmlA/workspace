package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;

public class WrapperView extends ViewGroup
{
  Drawable mDivider;
  int mDividerHeight;
  View mHeader;
  View mItem;
  int mItemTop;

  WrapperView(Context paramContext)
  {
    super(paramContext);
  }

  protected void dispatchDraw(Canvas paramCanvas)
  {
    super.dispatchDraw(paramCanvas);
    if ((this.mHeader == null) && (this.mDivider != null) && (this.mItem.getVisibility() != 8))
    {
      if (Build.VERSION.SDK_INT < 11)
        paramCanvas.clipRect(0, 0, getWidth(), this.mDividerHeight);
      this.mDivider.draw(paramCanvas);
    }
  }

  public View getHeader()
  {
    return this.mHeader;
  }

  public View getItem()
  {
    return this.mItem;
  }

  public boolean hasHeader()
  {
    return this.mHeader != null;
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = getWidth();
    int j = getHeight();
    if (this.mHeader != null)
    {
      int k = this.mHeader.getMeasuredHeight();
      this.mHeader.layout(0, 0, i, k);
      this.mItemTop = k;
      this.mItem.layout(0, k, i, j);
      return;
    }
    if (this.mDivider != null)
    {
      this.mDivider.setBounds(0, 0, i, this.mDividerHeight);
      this.mItemTop = this.mDividerHeight;
      this.mItem.layout(0, this.mDividerHeight, i, j);
      return;
    }
    this.mItemTop = 0;
    this.mItem.layout(0, 0, i, j);
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
    int k;
    label72: ViewGroup.LayoutParams localLayoutParams1;
    if (this.mHeader != null)
    {
      ViewGroup.LayoutParams localLayoutParams2 = this.mHeader.getLayoutParams();
      if ((localLayoutParams2 != null) && (localLayoutParams2.height > 0))
      {
        this.mHeader.measure(j, View.MeasureSpec.makeMeasureSpec(localLayoutParams2.height, 1073741824));
        k = 0 + this.mHeader.getMeasuredHeight();
        localLayoutParams1 = this.mItem.getLayoutParams();
        if (this.mItem.getVisibility() != 8)
          break label177;
        this.mItem.measure(j, View.MeasureSpec.makeMeasureSpec(0, 1073741824));
      }
    }
    while (true)
    {
      setMeasuredDimension(i, k);
      return;
      this.mHeader.measure(j, View.MeasureSpec.makeMeasureSpec(0, 0));
      break;
      Drawable localDrawable = this.mDivider;
      k = 0;
      if (localDrawable == null)
        break label72;
      int m = this.mItem.getVisibility();
      k = 0;
      if (m == 8)
        break label72;
      k = 0 + this.mDividerHeight;
      break label72;
      label177: if ((localLayoutParams1 != null) && (localLayoutParams1.height >= 0))
      {
        this.mItem.measure(j, View.MeasureSpec.makeMeasureSpec(localLayoutParams1.height, 1073741824));
        k += this.mItem.getMeasuredHeight();
        continue;
      }
      this.mItem.measure(j, View.MeasureSpec.makeMeasureSpec(0, 0));
      k += this.mItem.getMeasuredHeight();
    }
  }

  void update(View paramView1, View paramView2, Drawable paramDrawable, int paramInt)
  {
    if (paramView1 == null)
      throw new NullPointerException("List view item must not be null.");
    if (this.mItem != paramView1)
    {
      removeView(this.mItem);
      this.mItem = paramView1;
      ViewParent localViewParent = paramView1.getParent();
      if ((localViewParent != null) && (localViewParent != this) && ((localViewParent instanceof ViewGroup)))
        ((ViewGroup)localViewParent).removeView(paramView1);
      addView(paramView1);
    }
    if (this.mHeader != paramView2)
    {
      if (this.mHeader != null)
        removeView(this.mHeader);
      this.mHeader = paramView2;
      if (paramView2 != null)
        addView(paramView2);
    }
    if (this.mDivider != paramDrawable)
    {
      this.mDivider = paramDrawable;
      this.mDividerHeight = paramInt;
      invalidate();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.WrapperView
 * JD-Core Version:    0.6.0
 */