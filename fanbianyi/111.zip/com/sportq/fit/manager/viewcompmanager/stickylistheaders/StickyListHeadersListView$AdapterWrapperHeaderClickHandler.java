package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.view.View;

class StickyListHeadersListView$AdapterWrapperHeaderClickHandler
  implements AdapterWrapper.OnHeaderClickListener
{
  private StickyListHeadersListView$AdapterWrapperHeaderClickHandler(StickyListHeadersListView paramStickyListHeadersListView)
  {
  }

  public void onHeaderClick(View paramView, int paramInt, long paramLong)
  {
    StickyListHeadersListView.access$500(this.this$0).onHeaderClick(this.this$0, paramView, paramInt, paramLong, false);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersListView.AdapterWrapperHeaderClickHandler
 * JD-Core Version:    0.6.0
 */