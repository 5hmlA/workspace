package com.sportq.fit.manager.accountmanager;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnDismissListener;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.nineoldandroids.animation.ValueAnimator;
import com.nineoldandroids.animation.ValueAnimator.AnimatorUpdateListener;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.EnergyModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.superView.RLinearLayout;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;

public class MedalEnergyDialog
{
  public static boolean isShowing = false;
  private Context context;
  private Dialog mDialog;
  TextView mEnergyDialogEnergyValue;
  RLinearLayout mEnergyDialogLinearLayout;

  public MedalEnergyDialog createDialog(Context paramContext)
  {
    this.context = paramContext;
    try
    {
      this.mDialog = new Dialog(paramContext);
      this.mDialog.requestWindowFeature(1);
      this.mDialog.getWindow().setBackgroundDrawableResource(2131624292);
      this.mDialog.setContentView(2130968954);
      WindowManager.LayoutParams localLayoutParams = this.mDialog.getWindow().getAttributes();
      localLayoutParams.width = (int)(0.7639D * BaseApplication.screenWidth);
      localLayoutParams.height = -2;
      this.mDialog.getWindow().setAttributes(localLayoutParams);
      this.mDialog.setCancelable(true);
      this.mDialog.setCanceledOnTouchOutside(true);
      Dialog localDialog = this.mDialog;
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      isShowing = true;
      this.mEnergyDialogEnergyValue = ((TextView)this.mDialog.findViewById(2131755937));
      this.mEnergyDialogEnergyValue.setTypeface(TextUtils.getFontFaceImpact());
      this.mEnergyDialogLinearLayout = ((RLinearLayout)this.mDialog.findViewById(2131755942));
      new Handler().postDelayed(new Runnable(paramContext)
      {
        public void run()
        {
          if (((this.val$context instanceof Activity)) && (!((Activity)this.val$context).isFinishing()))
            try
            {
              MedalEnergyDialog.this.mDialog.dismiss();
              MedalEnergyDialog.isShowing = false;
              return;
            }
            catch (Exception localException)
            {
              MedalEnergyDialog.access$002(MedalEnergyDialog.this, null);
              MedalEnergyDialog.access$102(MedalEnergyDialog.this, null);
              MedalEnergyDialog.isShowing = false;
              LogUtils.e(localException);
              return;
            }
          MedalEnergyDialog.isShowing = false;
        }
      }
      , 3000L);
      return this;
    }
    catch (Exception localException)
    {
      this.mDialog = null;
      this.context = null;
      isShowing = false;
      LogUtils.e(localException);
    }
    return this;
  }

  public MedalEnergyDialog setEnergyList(ArrayList<EnergyModel> paramArrayList)
  {
    if ((this.mEnergyDialogLinearLayout != null) && (paramArrayList != null))
    {
      this.mEnergyDialogLinearLayout.removeAllViews();
      Iterator localIterator = paramArrayList.iterator();
      while (localIterator.hasNext())
      {
        EnergyModel localEnergyModel = (EnergyModel)localIterator.next();
        View localView = View.inflate(this.context, 2130968905, null);
        ((CustomTextView)localView.findViewById(2131756364)).setText(localEnergyModel.comment);
        ((CustomTextView)localView.findViewById(2131755350)).setText(localEnergyModel.energyValue);
        if (paramArrayList.indexOf(localEnergyModel) == -1 + paramArrayList.size())
          ((LinearLayout)localView).getChildAt(1).setVisibility(8);
        this.mEnergyDialogLinearLayout.addView(localView);
      }
    }
    return this;
  }

  public MedalEnergyDialog setEnergyValue(String paramString1, String paramString2)
  {
    if (this.mEnergyDialogEnergyValue != null)
    {
      this.mEnergyDialogEnergyValue.setText(paramString1);
      BaseApplication.userModel.energyValue = paramString2;
      EventBus.getDefault().post("REDEEM.DIALOG.SUCCESS");
      int[] arrayOfInt = new int[2];
      arrayOfInt[0] = StringUtils.string2Int(paramString1);
      arrayOfInt[1] = StringUtils.string2Int(paramString2);
      ValueAnimator localValueAnimator = ValueAnimator.ofInt(arrayOfInt);
      localValueAnimator.setDuration(500L);
      localValueAnimator.setStartDelay(200L);
      localValueAnimator.setInterpolator(new DecelerateInterpolator());
      localValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(localValueAnimator)
      {
        public void onAnimationUpdate(ValueAnimator paramValueAnimator)
        {
          MedalEnergyDialog.this.mEnergyDialogEnergyValue.setText(String.valueOf(this.val$animator1.getAnimatedValue()));
        }
      });
      localValueAnimator.start();
    }
    return this;
  }

  public MedalEnergyDialog setOnDismissListener(DialogInterface.OnDismissListener paramOnDismissListener)
  {
    if (this.mDialog != null)
      this.mDialog.setOnDismissListener(paramOnDismissListener);
    return this;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.accountmanager.MedalEnergyDialog
 * JD-Core Version:    0.6.0
 */