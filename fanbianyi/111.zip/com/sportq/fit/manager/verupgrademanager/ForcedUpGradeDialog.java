package com.sportq.fit.manager.verupgrademanager;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;

public class ForcedUpGradeDialog
{
  private static boolean isExist = false;

  public static void createDialog(Context paramContext, String paramString)
  {
    if (isExist);
    do
      return;
    while (!"1".equals(paramString));
    isExist = true;
    createForceUpGradeDialog(paramContext);
  }

  public static void createForceUpGradeDialog(Context paramContext)
  {
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setContentView(2130968872);
    localDialog.setCancelable(false);
    localDialog.setCanceledOnTouchOutside(false);
    ((TextView)localDialog.findViewById(2131756257)).setOnClickListener(new FitAction(null, paramContext)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        MiddleManager.getInstance().getMinePresenterImpl(null).getMessageNumberC();
        Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + this.val$mContext.getPackageName()));
        try
        {
          this.val$mContext.startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)this.val$mContext, 0);
          super.onClick(paramView);
          return;
        }
        catch (Exception localException)
        {
          while (true)
            LogUtils.e(localException);
        }
      }
    });
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
    localLayoutParams.height = -2;
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.verupgrademanager.ForcedUpGradeDialog
 * JD-Core Version:    0.6.0
 */