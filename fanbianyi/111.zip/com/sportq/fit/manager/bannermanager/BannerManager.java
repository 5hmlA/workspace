package com.sportq.fit.manager.bannermanager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.sportq.fit.common.event.CustomBannerJumpEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.IBannerManager;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;

public class BannerManager
  implements FitInterfaceUtils.UIInitListener, FitInterfaceUtils.IBannerManager
{
  public DialogInterface dialog;
  private Context mContext;
  private String strPlanId;

  public void fitOnClick(View paramView)
  {
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof PlanReformer))
    {
      if (this.dialog != null)
        this.dialog.closeDialog();
      PlanReformer localPlanReformer = (PlanReformer)paramT;
      if ((localPlanReformer._individualArray != null) && (localPlanReformer._individualArray.size() != 0))
        break label79;
    }
    label79: for (Intent localIntent = new Intent(this.mContext, Find04GenTrainInfoActivity.class); ; localIntent = new Intent(this.mContext, Find03GenTrainListActivity.class))
    {
      localIntent.putExtra("plan.id", this.strPlanId);
      this.mContext.startActivity(localIntent);
      return;
    }
  }

  public void init(Context paramContext)
  {
    this.dialog = new DialogManager();
    this.mContext = paramContext;
  }

  public void initLayout(Bundle paramBundle)
  {
  }

  public void jumpTo(String paramString1, String paramString2)
  {
    jumpTo(paramString1, paramString2, "");
  }

  public void jumpTo(String paramString1, String paramString2, String paramString3)
  {
    int i = StringUtils.string2Int(paramString1);
    if (i >= 10)
      i++;
    EventBus.getDefault().post(new CustomBannerJumpEvent(this.mContext, String.valueOf(i), paramString2));
  }

  public <T> void onRefresh(T paramT)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.bannermanager.BannerManager
 * JD-Core Version:    0.6.0
 */