package com.sportq.fit;

public class NdkUtils
{
  static
  {
    System.loadLibrary("fit");
  }

  public static native String getAlipayAppId();

  public static native String getBackAdd();

  public static native String getBdFormalAdd();

  public static native String getSignBaseUrl();

  public static native String getWeixinAppid();
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.NdkUtils
 * JD-Core Version:    0.6.0
 */