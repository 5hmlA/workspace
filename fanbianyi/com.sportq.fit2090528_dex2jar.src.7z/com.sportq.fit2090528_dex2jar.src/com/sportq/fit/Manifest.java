package com.sportq.fit;

public final class Manifest
{
  public static final class permission
  {
    public static final String MIPUSH_RECEIVE = "com.sportq.fit.permission.MIPUSH_RECEIVE";
    public static final String WRITE_APN_SETTINGS = "android.permission.WRITE_APN_SETTINGS";
    public static final String fit = "getui.permission.GetuiService.com.sportq.fit";
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.Manifest
 * JD-Core Version:    0.6.0
 */