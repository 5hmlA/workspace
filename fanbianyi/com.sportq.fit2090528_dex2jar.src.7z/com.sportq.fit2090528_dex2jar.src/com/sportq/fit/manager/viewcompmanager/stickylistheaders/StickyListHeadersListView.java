package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.View.OnCreateContextMenuListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.AbsListView.MultiChoiceModeListener;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ListView;
import android.widget.SectionIndexer;
import com.sportq.fit.R.styleable;

public class StickyListHeadersListView extends FrameLayout
{
  private AdapterWrapper mAdapter;
  private boolean mAreHeadersSticky = true;
  private boolean mClippingToPadding = true;
  private StickyListHeadersListView.AdapterWrapperDataSetObserver mDataSetObserver;
  private Drawable mDivider;
  private int mDividerHeight;
  private View mHeader;
  private Long mHeaderId;
  private Integer mHeaderOffset;
  private Integer mHeaderPosition;
  private boolean mIsDrawingListUnderStickyHeader = true;
  private WrapperViewList mList;
  private StickyListHeadersListView.OnHeaderClickListener mOnHeaderClickListener;
  private AbsListView.OnScrollListener mOnScrollListenerDelegate;
  private StickyListHeadersListView.OnStickyHeaderChangedListener mOnStickyHeaderChangedListener;
  private StickyListHeadersListView.OnStickyHeaderOffsetChangedListener mOnStickyHeaderOffsetChangedListener;
  private int mPaddingBottom = 0;
  private int mPaddingLeft = 0;
  private int mPaddingRight = 0;
  private int mPaddingTop = 0;
  private int mStickyHeaderTopOffset = 0;

  public StickyListHeadersListView(Context paramContext)
  {
    this(paramContext, null);
  }

  public StickyListHeadersListView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  @TargetApi(11)
  public StickyListHeadersListView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mList = new WrapperViewList(paramContext);
    this.mDivider = this.mList.getDivider();
    this.mDividerHeight = this.mList.getDividerHeight();
    this.mList.setDivider(null);
    this.mList.setDividerHeight(0);
    TypedArray localTypedArray;
    if (paramAttributeSet != null)
      localTypedArray = paramContext.getTheme().obtainStyledAttributes(paramAttributeSet, R.styleable.StickyListHeadersListView, 0, 0);
    while (true)
    {
      try
      {
        int i = localTypedArray.getDimensionPixelSize(1, 0);
        this.mPaddingLeft = localTypedArray.getDimensionPixelSize(2, i);
        this.mPaddingTop = localTypedArray.getDimensionPixelSize(3, i);
        this.mPaddingRight = localTypedArray.getDimensionPixelSize(4, i);
        this.mPaddingBottom = localTypedArray.getDimensionPixelSize(5, i);
        setPadding(this.mPaddingLeft, this.mPaddingTop, this.mPaddingRight, this.mPaddingBottom);
        this.mClippingToPadding = localTypedArray.getBoolean(8, true);
        super.setClipToPadding(true);
        this.mList.setClipToPadding(this.mClippingToPadding);
        int j = localTypedArray.getInt(6, 512);
        WrapperViewList localWrapperViewList1 = this.mList;
        if ((j & 0x200) == 0)
          continue;
        boolean bool1 = true;
        localWrapperViewList1.setVerticalScrollBarEnabled(bool1);
        WrapperViewList localWrapperViewList2 = this.mList;
        if ((j & 0x100) == 0)
          continue;
        boolean bool2 = true;
        localWrapperViewList2.setHorizontalScrollBarEnabled(bool2);
        if (Build.VERSION.SDK_INT < 9)
          continue;
        this.mList.setOverScrollMode(localTypedArray.getInt(18, 0));
        this.mList.setFadingEdgeLength(localTypedArray.getDimensionPixelSize(7, this.mList.getVerticalFadingEdgeLength()));
        int k = localTypedArray.getInt(20, 0);
        if (k != 4096)
          continue;
        this.mList.setVerticalFadingEdgeEnabled(false);
        this.mList.setHorizontalFadingEdgeEnabled(true);
        this.mList.setCacheColorHint(localTypedArray.getColor(13, this.mList.getCacheColorHint()));
        if (Build.VERSION.SDK_INT < 11)
          continue;
        this.mList.setChoiceMode(localTypedArray.getInt(16, this.mList.getChoiceMode()));
        this.mList.setDrawSelectorOnTop(localTypedArray.getBoolean(10, false));
        this.mList.setFastScrollEnabled(localTypedArray.getBoolean(17, this.mList.isFastScrollEnabled()));
        if (Build.VERSION.SDK_INT < 11)
          continue;
        this.mList.setFastScrollAlwaysVisible(localTypedArray.getBoolean(19, this.mList.isFastScrollAlwaysVisible()));
        this.mList.setScrollBarStyle(localTypedArray.getInt(0, 0));
        if (!localTypedArray.hasValue(9))
          continue;
        this.mList.setSelector(localTypedArray.getDrawable(9));
        this.mList.setScrollingCacheEnabled(localTypedArray.getBoolean(11, this.mList.isScrollingCacheEnabled()));
        if (!localTypedArray.hasValue(14))
          continue;
        this.mDivider = localTypedArray.getDrawable(14);
        this.mDividerHeight = localTypedArray.getDimensionPixelSize(15, this.mDividerHeight);
        this.mList.setTranscriptMode(localTypedArray.getInt(12, 0));
        this.mAreHeadersSticky = localTypedArray.getBoolean(21, true);
        this.mIsDrawingListUnderStickyHeader = localTypedArray.getBoolean(22, true);
        localTypedArray.recycle();
        this.mList.setLifeCycleListener(new StickyListHeadersListView.WrapperViewListLifeCycleListener(this, null));
        this.mList.setOnScrollListener(new StickyListHeadersListView.WrapperListScrollListener(this, null));
        addView(this.mList);
        return;
        bool1 = false;
        continue;
        bool2 = false;
        continue;
        if (k == 8192)
        {
          this.mList.setVerticalFadingEdgeEnabled(true);
          this.mList.setHorizontalFadingEdgeEnabled(false);
          continue;
        }
      }
      finally
      {
        localTypedArray.recycle();
      }
      this.mList.setVerticalFadingEdgeEnabled(false);
      this.mList.setHorizontalFadingEdgeEnabled(false);
    }
  }

  private void clearHeader()
  {
    if (this.mHeader != null)
    {
      removeView(this.mHeader);
      this.mHeader = null;
      this.mHeaderId = null;
      this.mHeaderPosition = null;
      this.mHeaderOffset = null;
      this.mList.setTopClippingLength(0);
      updateHeaderVisibilities();
    }
  }

  private void ensureHeaderHasCorrectLayoutParams(View paramView)
  {
    ViewGroup.LayoutParams localLayoutParams = paramView.getLayoutParams();
    if (localLayoutParams == null)
      paramView.setLayoutParams(new FrameLayout.LayoutParams(-1, -2));
    do
      return;
    while ((localLayoutParams.height != -1) && (localLayoutParams.width != -2));
    localLayoutParams.height = -2;
    localLayoutParams.width = -1;
    paramView.setLayoutParams(localLayoutParams);
  }

  private boolean isStartOfSection(int paramInt)
  {
    return (paramInt == 0) || (this.mAdapter.getHeaderId(paramInt) != this.mAdapter.getHeaderId(paramInt - 1));
  }

  private void measureHeader(View paramView)
  {
    if (paramView != null)
      measureChild(paramView, View.MeasureSpec.makeMeasureSpec(getMeasuredWidth() - this.mPaddingLeft - this.mPaddingRight, 1073741824), View.MeasureSpec.makeMeasureSpec(0, 0));
  }

  private boolean requireSdkVersion(int paramInt)
  {
    if (Build.VERSION.SDK_INT < paramInt)
    {
      Log.e("StickyListHeaders", "Api lvl must be at least " + paramInt + " to call this method");
      return false;
    }
    return true;
  }

  @SuppressLint({"NewApi"})
  private void setHeaderOffet(int paramInt)
  {
    if ((this.mHeaderOffset == null) || (this.mHeaderOffset.intValue() != paramInt))
    {
      this.mHeaderOffset = Integer.valueOf(paramInt);
      if (Build.VERSION.SDK_INT < 11)
        break label79;
      this.mHeader.setTranslationY(this.mHeaderOffset.intValue());
    }
    while (true)
    {
      if (this.mOnStickyHeaderOffsetChangedListener != null)
        this.mOnStickyHeaderOffsetChangedListener.onStickyHeaderOffsetChanged(this, this.mHeader, -this.mHeaderOffset.intValue());
      return;
      label79: ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)this.mHeader.getLayoutParams();
      localMarginLayoutParams.topMargin = this.mHeaderOffset.intValue();
      this.mHeader.setLayoutParams(localMarginLayoutParams);
    }
  }

  private int stickyHeaderTop()
  {
    int i = this.mStickyHeaderTopOffset;
    if (this.mClippingToPadding);
    for (int j = this.mPaddingTop; ; j = 0)
      return j + i;
  }

  private void swapHeader(View paramView)
  {
    if (this.mHeader != null)
      removeView(this.mHeader);
    this.mHeader = paramView;
    addView(this.mHeader);
    if (this.mOnHeaderClickListener != null)
      this.mHeader.setOnClickListener(new StickyListHeadersListView.1(this));
    this.mHeader.setClickable(true);
  }

  private void updateHeader(int paramInt)
  {
    if ((this.mHeaderPosition == null) || (this.mHeaderPosition.intValue() != paramInt))
    {
      this.mHeaderPosition = Integer.valueOf(paramInt);
      long l = this.mAdapter.getHeaderId(paramInt);
      if ((this.mHeaderId == null) || (this.mHeaderId.longValue() != l))
      {
        this.mHeaderId = Long.valueOf(l);
        View localView1 = this.mAdapter.getHeaderView(this.mHeaderPosition.intValue(), this.mHeader, this);
        if (this.mHeader != localView1)
        {
          if (localView1 == null)
            throw new NullPointerException("header may not be null");
          swapHeader(localView1);
        }
        ensureHeaderHasCorrectLayoutParams(this.mHeader);
        measureHeader(this.mHeader);
        if (this.mOnStickyHeaderChangedListener != null)
          this.mOnStickyHeaderChangedListener.onStickyHeaderChanged(this, this.mHeader, paramInt, this.mHeaderId.longValue());
        this.mHeaderOffset = null;
      }
    }
    int i = this.mHeader.getMeasuredHeight() + stickyHeaderTop();
    for (int j = 0; ; j++)
    {
      int k = this.mList.getChildCount();
      int m = 0;
      View localView2;
      if (j < k)
      {
        localView2 = this.mList.getChildAt(j);
        if ((!(localView2 instanceof WrapperView)) || (!((WrapperView)localView2).hasHeader()))
          break label320;
      }
      label320: for (int n = 1; ; n = 0)
      {
        boolean bool = this.mList.containsFooterView(localView2);
        if ((localView2.getTop() < stickyHeaderTop()) || ((n == 0) && (!bool)))
          break;
        m = Math.min(localView2.getTop() - i, 0);
        setHeaderOffet(m);
        if (!this.mIsDrawingListUnderStickyHeader)
          this.mList.setTopClippingLength(this.mHeader.getMeasuredHeight() + this.mHeaderOffset.intValue());
        updateHeaderVisibilities();
        return;
      }
    }
  }

  private void updateHeaderVisibilities()
  {
    int n;
    int i;
    label43: int k;
    label53: View localView1;
    if (this.mHeader != null)
    {
      int m = this.mHeader.getMeasuredHeight();
      if (this.mHeaderOffset != null)
      {
        n = this.mHeaderOffset.intValue();
        i = n + m + this.mStickyHeaderTopOffset;
        int j = this.mList.getChildCount();
        k = 0;
        if (k >= j)
          return;
        localView1 = this.mList.getChildAt(k);
        if ((localView1 instanceof WrapperView))
          break label96;
      }
    }
    while (true)
    {
      k++;
      break label53;
      n = 0;
      break;
      i = stickyHeaderTop();
      break label43;
      label96: WrapperView localWrapperView = (WrapperView)localView1;
      if (!localWrapperView.hasHeader())
        continue;
      View localView2 = localWrapperView.mHeader;
      if (localWrapperView.getTop() < i)
      {
        if (localView2.getVisibility() == 4)
          continue;
        localView2.setVisibility(4);
        continue;
      }
      if (localView2.getVisibility() == 0)
        continue;
      localView2.setVisibility(0);
    }
  }

  private void updateOrClearHeader(int paramInt)
  {
    if (this.mAdapter == null);
    for (int i = 0; (i == 0) || (!this.mAreHeadersSticky); i = this.mAdapter.getCount())
      return;
    int j = paramInt - this.mList.getHeaderViewsCount();
    if ((this.mList.getChildCount() > 0) && (this.mList.getChildAt(0).getBottom() < stickyHeaderTop()))
      j++;
    int k;
    if (this.mList.getChildCount() != 0)
    {
      k = 1;
      if ((k == 0) || (this.mList.getFirstVisiblePosition() != 0) || (this.mList.getChildAt(0).getTop() < stickyHeaderTop()))
        break label165;
    }
    label165: for (int m = 1; ; m = 0)
    {
      int n;
      if (j <= i - 1)
      {
        n = 0;
        if (j >= 0);
      }
      else
      {
        n = 1;
      }
      if ((k != 0) && (n == 0) && (m == 0))
        break label171;
      clearHeader();
      return;
      k = 0;
      break;
    }
    label171: updateHeader(j);
  }

  public void addFooterView(View paramView)
  {
    this.mList.addFooterView(paramView);
  }

  public void addFooterView(View paramView, Object paramObject, boolean paramBoolean)
  {
    this.mList.addFooterView(paramView, paramObject, paramBoolean);
  }

  public void addHeaderView(View paramView)
  {
    this.mList.addHeaderView(paramView);
  }

  public void addHeaderView(View paramView, Object paramObject, boolean paramBoolean)
  {
    this.mList.addHeaderView(paramView, paramObject, paramBoolean);
  }

  public boolean areHeadersSticky()
  {
    return this.mAreHeadersSticky;
  }

  @TargetApi(14)
  public boolean canScrollVertically(int paramInt)
  {
    return this.mList.canScrollVertically(paramInt);
  }

  protected void dispatchDraw(Canvas paramCanvas)
  {
    if ((this.mList.getVisibility() == 0) || (this.mList.getAnimation() != null))
      drawChild(paramCanvas, this.mList, 0L);
  }

  public StickyListHeadersAdapter getAdapter()
  {
    if (this.mAdapter == null)
      return null;
    return this.mAdapter.mDelegate;
  }

  @Deprecated
  public boolean getAreHeadersSticky()
  {
    return areHeadersSticky();
  }

  @TargetApi(11)
  public int getCheckedItemCount()
  {
    if (requireSdkVersion(11))
      return this.mList.getCheckedItemCount();
    return 0;
  }

  @TargetApi(8)
  public long[] getCheckedItemIds()
  {
    if (requireSdkVersion(8))
      return this.mList.getCheckedItemIds();
    return null;
  }

  @TargetApi(11)
  public int getCheckedItemPosition()
  {
    return this.mList.getCheckedItemPosition();
  }

  @TargetApi(11)
  public SparseBooleanArray getCheckedItemPositions()
  {
    return this.mList.getCheckedItemPositions();
  }

  public int getCount()
  {
    return this.mList.getCount();
  }

  public Drawable getDivider()
  {
    return this.mDivider;
  }

  public int getDividerHeight()
  {
    return this.mDividerHeight;
  }

  public View getEmptyView()
  {
    return this.mList.getEmptyView();
  }

  public int getFirstVisiblePosition()
  {
    return this.mList.getFirstVisiblePosition();
  }

  public int getFooterViewsCount()
  {
    return this.mList.getFooterViewsCount();
  }

  public int getHeaderOverlap(int paramInt)
  {
    boolean bool = isStartOfSection(Math.max(0, paramInt - getHeaderViewsCount()));
    int i = 0;
    if (!bool)
    {
      View localView = this.mAdapter.getHeaderView(paramInt, null, this.mList);
      if (localView == null)
        throw new NullPointerException("header may not be null");
      ensureHeaderHasCorrectLayoutParams(localView);
      measureHeader(localView);
      i = localView.getMeasuredHeight();
    }
    return i;
  }

  public int getHeaderViewsCount()
  {
    return this.mList.getHeaderViewsCount();
  }

  public Object getItemAtPosition(int paramInt)
  {
    return this.mList.getItemAtPosition(paramInt);
  }

  public long getItemIdAtPosition(int paramInt)
  {
    return this.mList.getItemIdAtPosition(paramInt);
  }

  public int getLastVisiblePosition()
  {
    return this.mList.getLastVisiblePosition();
  }

  public View getListChildAt(int paramInt)
  {
    return this.mList.getChildAt(paramInt);
  }

  public int getListChildCount()
  {
    return this.mList.getChildCount();
  }

  @TargetApi(9)
  public int getOverScrollMode()
  {
    if (requireSdkVersion(9))
      return this.mList.getOverScrollMode();
    return 0;
  }

  public int getPaddingBottom()
  {
    return this.mPaddingBottom;
  }

  public int getPaddingLeft()
  {
    return this.mPaddingLeft;
  }

  public int getPaddingRight()
  {
    return this.mPaddingRight;
  }

  public int getPaddingTop()
  {
    return this.mPaddingTop;
  }

  public int getPositionForView(View paramView)
  {
    return this.mList.getPositionForView(paramView);
  }

  public int getScrollBarStyle()
  {
    return this.mList.getScrollBarStyle();
  }

  public int getStickyHeaderTopOffset()
  {
    return this.mStickyHeaderTopOffset;
  }

  public ListView getWrappedList()
  {
    return this.mList;
  }

  public void invalidateViews()
  {
    this.mList.invalidateViews();
  }

  public boolean isDrawingListUnderStickyHeader()
  {
    return this.mIsDrawingListUnderStickyHeader;
  }

  @TargetApi(11)
  public boolean isFastScrollAlwaysVisible()
  {
    if (Build.VERSION.SDK_INT < 11)
      return false;
    return this.mList.isFastScrollAlwaysVisible();
  }

  public boolean isHorizontalScrollBarEnabled()
  {
    return this.mList.isHorizontalScrollBarEnabled();
  }

  public boolean isVerticalScrollBarEnabled()
  {
    return this.mList.isVerticalScrollBarEnabled();
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.mList.layout(0, 0, this.mList.getMeasuredWidth(), getHeight());
    if (this.mHeader != null)
    {
      int i = ((ViewGroup.MarginLayoutParams)this.mHeader.getLayoutParams()).topMargin + stickyHeaderTop();
      this.mHeader.layout(this.mPaddingLeft, i, this.mHeader.getMeasuredWidth() + this.mPaddingLeft, i + this.mHeader.getMeasuredHeight());
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    measureHeader(this.mHeader);
  }

  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    super.onRestoreInstanceState(View.BaseSavedState.EMPTY_STATE);
    this.mList.onRestoreInstanceState(paramParcelable);
  }

  public Parcelable onSaveInstanceState()
  {
    if (super.onSaveInstanceState() != View.BaseSavedState.EMPTY_STATE)
      throw new IllegalStateException("Handling non empty state of parent class is not implemented");
    return this.mList.onSaveInstanceState();
  }

  protected void recomputePadding()
  {
    setPadding(this.mPaddingLeft, this.mPaddingTop, this.mPaddingRight, this.mPaddingBottom);
  }

  public void removeFooterView(View paramView)
  {
    this.mList.removeFooterView(paramView);
  }

  public void removeHeaderView(View paramView)
  {
    this.mList.removeHeaderView(paramView);
  }

  public void setAdapter(StickyListHeadersAdapter paramStickyListHeadersAdapter)
  {
    if (paramStickyListHeadersAdapter == null)
    {
      this.mList.setAdapter(null);
      clearHeader();
      return;
    }
    if (this.mAdapter != null)
      this.mAdapter.unregisterDataSetObserver(this.mDataSetObserver);
    if ((paramStickyListHeadersAdapter instanceof SectionIndexer))
    {
      this.mAdapter = new SectionIndexerAdapterWrapper(getContext(), paramStickyListHeadersAdapter);
      this.mDataSetObserver = new StickyListHeadersListView.AdapterWrapperDataSetObserver(this, null);
      this.mAdapter.registerDataSetObserver(this.mDataSetObserver);
      if (this.mOnHeaderClickListener == null)
        break label155;
      this.mAdapter.setOnHeaderClickListener(new StickyListHeadersListView.AdapterWrapperHeaderClickHandler(this, null));
    }
    while (true)
    {
      this.mAdapter.setDivider(this.mDivider, this.mDividerHeight);
      this.mList.setAdapter(this.mAdapter);
      clearHeader();
      return;
      this.mAdapter = new AdapterWrapper(getContext(), paramStickyListHeadersAdapter);
      break;
      label155: this.mAdapter.setOnHeaderClickListener(null);
    }
  }

  public void setAreHeadersSticky(boolean paramBoolean)
  {
    this.mAreHeadersSticky = paramBoolean;
    if (!paramBoolean)
      clearHeader();
    while (true)
    {
      this.mList.invalidate();
      return;
      updateOrClearHeader(this.mList.getFixedFirstVisibleItem());
    }
  }

  public void setBlockLayoutChildren(boolean paramBoolean)
  {
    this.mList.setBlockLayoutChildren(paramBoolean);
  }

  @TargetApi(11)
  public void setChoiceMode(int paramInt)
  {
    this.mList.setChoiceMode(paramInt);
  }

  public void setClipToPadding(boolean paramBoolean)
  {
    if (this.mList != null)
      this.mList.setClipToPadding(paramBoolean);
    this.mClippingToPadding = paramBoolean;
  }

  public void setDivider(Drawable paramDrawable)
  {
    this.mDivider = paramDrawable;
    if (this.mAdapter != null)
      this.mAdapter.setDivider(this.mDivider, this.mDividerHeight);
  }

  public void setDividerHeight(int paramInt)
  {
    this.mDividerHeight = paramInt;
    if (this.mAdapter != null)
      this.mAdapter.setDivider(this.mDivider, this.mDividerHeight);
  }

  public void setDrawingListUnderStickyHeader(boolean paramBoolean)
  {
    this.mIsDrawingListUnderStickyHeader = paramBoolean;
    this.mList.setTopClippingLength(0);
  }

  public void setEmptyView(View paramView)
  {
    this.mList.setEmptyView(paramView);
  }

  @TargetApi(11)
  public void setFastScrollAlwaysVisible(boolean paramBoolean)
  {
    if (requireSdkVersion(11))
      this.mList.setFastScrollAlwaysVisible(paramBoolean);
  }

  public void setFastScrollEnabled(boolean paramBoolean)
  {
    this.mList.setFastScrollEnabled(paramBoolean);
  }

  public void setHorizontalScrollBarEnabled(boolean paramBoolean)
  {
    this.mList.setHorizontalScrollBarEnabled(paramBoolean);
  }

  @TargetApi(11)
  public void setItemChecked(int paramInt, boolean paramBoolean)
  {
    this.mList.setItemChecked(paramInt, paramBoolean);
  }

  @TargetApi(11)
  public void setMultiChoiceModeListener(AbsListView.MultiChoiceModeListener paramMultiChoiceModeListener)
  {
    if (requireSdkVersion(11))
      this.mList.setMultiChoiceModeListener(paramMultiChoiceModeListener);
  }

  public void setOnCreateContextMenuListener(View.OnCreateContextMenuListener paramOnCreateContextMenuListener)
  {
    this.mList.setOnCreateContextMenuListener(paramOnCreateContextMenuListener);
  }

  public void setOnHeaderClickListener(StickyListHeadersListView.OnHeaderClickListener paramOnHeaderClickListener)
  {
    this.mOnHeaderClickListener = paramOnHeaderClickListener;
    if (this.mAdapter != null)
    {
      if (this.mOnHeaderClickListener == null)
        break label58;
      this.mAdapter.setOnHeaderClickListener(new StickyListHeadersListView.AdapterWrapperHeaderClickHandler(this, null));
      if (this.mHeader != null)
        this.mHeader.setOnClickListener(new StickyListHeadersListView.2(this));
    }
    return;
    label58: this.mAdapter.setOnHeaderClickListener(null);
  }

  public void setOnItemClickListener(AdapterView.OnItemClickListener paramOnItemClickListener)
  {
    this.mList.setOnItemClickListener(paramOnItemClickListener);
  }

  public void setOnItemLongClickListener(AdapterView.OnItemLongClickListener paramOnItemLongClickListener)
  {
    this.mList.setOnItemLongClickListener(paramOnItemLongClickListener);
  }

  public void setOnScrollListener(AbsListView.OnScrollListener paramOnScrollListener)
  {
    this.mOnScrollListenerDelegate = paramOnScrollListener;
  }

  public void setOnStickyHeaderChangedListener(StickyListHeadersListView.OnStickyHeaderChangedListener paramOnStickyHeaderChangedListener)
  {
    this.mOnStickyHeaderChangedListener = paramOnStickyHeaderChangedListener;
  }

  public void setOnStickyHeaderOffsetChangedListener(StickyListHeadersListView.OnStickyHeaderOffsetChangedListener paramOnStickyHeaderOffsetChangedListener)
  {
    this.mOnStickyHeaderOffsetChangedListener = paramOnStickyHeaderOffsetChangedListener;
  }

  public void setOnTouchListener(View.OnTouchListener paramOnTouchListener)
  {
    if (paramOnTouchListener != null)
    {
      this.mList.setOnTouchListener(new StickyListHeadersListView.3(this, paramOnTouchListener));
      return;
    }
    this.mList.setOnTouchListener(null);
  }

  @TargetApi(9)
  public void setOverScrollMode(int paramInt)
  {
    if ((requireSdkVersion(9)) && (this.mList != null))
      this.mList.setOverScrollMode(paramInt);
  }

  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.mPaddingLeft = paramInt1;
    this.mPaddingTop = paramInt2;
    this.mPaddingRight = paramInt3;
    this.mPaddingBottom = paramInt4;
    if (this.mList != null)
      this.mList.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
    super.setPadding(0, 0, 0, 0);
    requestLayout();
  }

  public void setScrollBarStyle(int paramInt)
  {
    this.mList.setScrollBarStyle(paramInt);
  }

  public void setSelection(int paramInt)
  {
    setSelectionFromTop(paramInt, 0);
  }

  public void setSelectionAfterHeaderView()
  {
    this.mList.setSelectionAfterHeaderView();
  }

  @TargetApi(21)
  public void setSelectionFromTop(int paramInt1, int paramInt2)
  {
    int i;
    int j;
    int k;
    if (this.mAdapter == null)
    {
      i = 0;
      j = paramInt2 + i;
      boolean bool = this.mClippingToPadding;
      k = 0;
      if (!bool)
        break label55;
    }
    while (true)
    {
      int m = j - k;
      this.mList.setSelectionFromTop(paramInt1, m);
      return;
      i = getHeaderOverlap(paramInt1);
      break;
      label55: k = this.mPaddingTop;
    }
  }

  public void setSelector(int paramInt)
  {
    this.mList.setSelector(paramInt);
  }

  public void setSelector(Drawable paramDrawable)
  {
    this.mList.setSelector(paramDrawable);
  }

  public void setStickyHeaderTopOffset(int paramInt)
  {
    this.mStickyHeaderTopOffset = paramInt;
    updateOrClearHeader(this.mList.getFixedFirstVisibleItem());
  }

  public void setTranscriptMode(int paramInt)
  {
    this.mList.setTranscriptMode(paramInt);
  }

  public void setVerticalScrollBarEnabled(boolean paramBoolean)
  {
    this.mList.setVerticalScrollBarEnabled(paramBoolean);
  }

  public boolean showContextMenu()
  {
    return this.mList.showContextMenu();
  }

  @TargetApi(8)
  public void smoothScrollBy(int paramInt1, int paramInt2)
  {
    if (requireSdkVersion(8))
      this.mList.smoothScrollBy(paramInt1, paramInt2);
  }

  @TargetApi(11)
  public void smoothScrollByOffset(int paramInt)
  {
    if (requireSdkVersion(11))
      this.mList.smoothScrollByOffset(paramInt);
  }

  @SuppressLint({"NewApi"})
  @TargetApi(8)
  public void smoothScrollToPosition(int paramInt)
  {
    if (requireSdkVersion(8))
    {
      if (Build.VERSION.SDK_INT < 11)
        this.mList.smoothScrollToPosition(paramInt);
    }
    else
      return;
    int i;
    int j;
    if (this.mAdapter == null)
    {
      i = 0;
      boolean bool = this.mClippingToPadding;
      j = 0;
      if (!bool)
        break label73;
    }
    while (true)
    {
      int k = i - j;
      this.mList.smoothScrollToPositionFromTop(paramInt, k);
      return;
      i = getHeaderOverlap(paramInt);
      break;
      label73: j = this.mPaddingTop;
    }
  }

  @TargetApi(8)
  public void smoothScrollToPosition(int paramInt1, int paramInt2)
  {
    if (requireSdkVersion(8))
      this.mList.smoothScrollToPosition(paramInt1, paramInt2);
  }

  @TargetApi(11)
  public void smoothScrollToPositionFromTop(int paramInt1, int paramInt2)
  {
    int i;
    int j;
    int k;
    if (requireSdkVersion(11))
    {
      if (this.mAdapter != null)
        break label55;
      i = 0;
      j = paramInt2 + i;
      boolean bool = this.mClippingToPadding;
      k = 0;
      if (!bool)
        break label64;
    }
    while (true)
    {
      int m = j - k;
      this.mList.smoothScrollToPositionFromTop(paramInt1, m);
      return;
      label55: i = getHeaderOverlap(paramInt1);
      break;
      label64: k = this.mPaddingTop;
    }
  }

  @TargetApi(11)
  public void smoothScrollToPositionFromTop(int paramInt1, int paramInt2, int paramInt3)
  {
    int i;
    int j;
    int k;
    if (requireSdkVersion(11))
    {
      if (this.mAdapter != null)
        break label58;
      i = 0;
      j = paramInt2 + i;
      boolean bool = this.mClippingToPadding;
      k = 0;
      if (!bool)
        break label68;
    }
    while (true)
    {
      int m = j - k;
      this.mList.smoothScrollToPositionFromTop(paramInt1, m, paramInt3);
      return;
      label58: i = getHeaderOverlap(paramInt1);
      break;
      label68: k = this.mPaddingTop;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersListView
 * JD-Core Version:    0.6.0
 */