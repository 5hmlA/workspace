package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.view.View;

public abstract interface StickyListHeadersListView$OnHeaderClickListener
{
  public abstract void onHeaderClick(StickyListHeadersListView paramStickyListHeadersListView, View paramView, int paramInt, long paramLong, boolean paramBoolean);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersListView.OnHeaderClickListener
 * JD-Core Version:    0.6.0
 */