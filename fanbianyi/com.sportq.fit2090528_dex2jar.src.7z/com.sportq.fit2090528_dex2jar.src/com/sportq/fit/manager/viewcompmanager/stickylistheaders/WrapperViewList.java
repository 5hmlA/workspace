package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ListView;
import com.sportq.fit.common.utils.LogUtils;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

class WrapperViewList extends ListView
{
  private boolean mBlockLayoutChildren = false;
  private boolean mClippingToPadding = true;
  private List<View> mFooterViews;
  private LifeCycleListener mLifeCycleListener;
  private Field mSelectorPositionField;
  private Rect mSelectorRect = new Rect();
  private int mTopClippingLength;

  public WrapperViewList(Context paramContext)
  {
    super(paramContext);
    try
    {
      Field localField = AbsListView.class.getDeclaredField("mSelectorRect");
      localField.setAccessible(true);
      this.mSelectorRect = ((Rect)localField.get(this));
      if (Build.VERSION.SDK_INT >= 14)
      {
        this.mSelectorPositionField = AbsListView.class.getDeclaredField("mSelectorPosition");
        this.mSelectorPositionField.setAccessible(true);
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void addInternalFooterView(View paramView)
  {
    if (this.mFooterViews == null)
      this.mFooterViews = new ArrayList();
    this.mFooterViews.add(paramView);
  }

  private int getSelectorPosition()
  {
    if (this.mSelectorPositionField == null)
      for (int j = 0; j < getChildCount(); j++)
        if (getChildAt(j).getBottom() == this.mSelectorRect.bottom)
          return j + getFixedFirstVisibleItem();
    try
    {
      int i = this.mSelectorPositionField.getInt(this);
      return i;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return -1;
  }

  private void positionSelectorRect()
  {
    if (!this.mSelectorRect.isEmpty())
    {
      int i = getSelectorPosition();
      if (i >= 0)
      {
        View localView = getChildAt(i - getFixedFirstVisibleItem());
        if ((localView instanceof WrapperView))
        {
          WrapperView localWrapperView = (WrapperView)localView;
          this.mSelectorRect.top = (localWrapperView.getTop() + localWrapperView.mItemTop);
        }
      }
    }
  }

  public void addFooterView(View paramView)
  {
    super.addFooterView(paramView);
    addInternalFooterView(paramView);
  }

  public void addFooterView(View paramView, Object paramObject, boolean paramBoolean)
  {
    super.addFooterView(paramView, paramObject, paramBoolean);
    addInternalFooterView(paramView);
  }

  boolean containsFooterView(View paramView)
  {
    if (this.mFooterViews == null)
      return false;
    return this.mFooterViews.contains(paramView);
  }

  protected void dispatchDraw(Canvas paramCanvas)
  {
    positionSelectorRect();
    if (this.mTopClippingLength != 0)
    {
      paramCanvas.save();
      Rect localRect = paramCanvas.getClipBounds();
      localRect.top = this.mTopClippingLength;
      paramCanvas.clipRect(localRect);
      super.dispatchDraw(paramCanvas);
      paramCanvas.restore();
    }
    while (true)
    {
      this.mLifeCycleListener.onDispatchDrawOccurred(paramCanvas);
      return;
      super.dispatchDraw(paramCanvas);
    }
  }

  int getFixedFirstVisibleItem()
  {
    int i = getFirstVisiblePosition();
    if (Build.VERSION.SDK_INT >= 11)
      return i;
    for (int j = 0; ; j++)
    {
      if (j < getChildCount())
      {
        if (getChildAt(j).getBottom() < 0)
          continue;
        i += j;
      }
      if ((!this.mClippingToPadding) && (getPaddingTop() > 0) && (i > 0) && (getChildAt(0).getTop() > 0))
        i--;
      return i;
    }
  }

  protected void layoutChildren()
  {
    if (!this.mBlockLayoutChildren)
      super.layoutChildren();
  }

  public boolean performItemClick(View paramView, int paramInt, long paramLong)
  {
    if ((paramView instanceof WrapperView))
      paramView = ((WrapperView)paramView).mItem;
    return super.performItemClick(paramView, paramInt, paramLong);
  }

  public boolean removeFooterView(View paramView)
  {
    if (super.removeFooterView(paramView))
    {
      this.mFooterViews.remove(paramView);
      return true;
    }
    return false;
  }

  public void setBlockLayoutChildren(boolean paramBoolean)
  {
    this.mBlockLayoutChildren = paramBoolean;
  }

  public void setClipToPadding(boolean paramBoolean)
  {
    this.mClippingToPadding = paramBoolean;
    super.setClipToPadding(paramBoolean);
  }

  void setLifeCycleListener(LifeCycleListener paramLifeCycleListener)
  {
    this.mLifeCycleListener = paramLifeCycleListener;
  }

  void setTopClippingLength(int paramInt)
  {
    this.mTopClippingLength = paramInt;
  }

  static abstract interface LifeCycleListener
  {
    public abstract void onDispatchDrawOccurred(Canvas paramCanvas);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.WrapperViewList
 * JD-Core Version:    0.6.0
 */