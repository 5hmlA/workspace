package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Checkable;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import java.util.LinkedList;
import java.util.List;

class AdapterWrapper extends BaseAdapter
  implements StickyListHeadersAdapter
{
  private final Context mContext;
  private DataSetObserver mDataSetObserver = new DataSetObserver()
  {
    public void onChanged()
    {
      AdapterWrapper.this.notifyDataSetChanged();
    }

    public void onInvalidated()
    {
      AdapterWrapper.this.mHeaderCache.clear();
      AdapterWrapper.this.notifyDataSetInvalidated();
    }
  };
  final StickyListHeadersAdapter mDelegate;
  private Drawable mDivider;
  private int mDividerHeight;
  private final List<View> mHeaderCache = new LinkedList();
  private OnHeaderClickListener mOnHeaderClickListener;

  AdapterWrapper(Context paramContext, StickyListHeadersAdapter paramStickyListHeadersAdapter)
  {
    this.mContext = paramContext;
    this.mDelegate = paramStickyListHeadersAdapter;
    paramStickyListHeadersAdapter.registerDataSetObserver(this.mDataSetObserver);
  }

  private View configureHeader(WrapperView paramWrapperView, int paramInt)
  {
    if (paramWrapperView.mHeader == null);
    View localView2;
    for (View localView1 = popHeader(); ; localView1 = paramWrapperView.mHeader)
    {
      localView2 = this.mDelegate.getHeaderView(paramInt, localView1, paramWrapperView);
      if (localView2 != null)
        break;
      throw new NullPointerException("Header view must not be null.");
    }
    localView2.setClickable(true);
    localView2.setOnClickListener(new View.OnClickListener(paramInt)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (AdapterWrapper.this.mOnHeaderClickListener != null)
        {
          long l = AdapterWrapper.this.mDelegate.getHeaderId(this.val$position);
          AdapterWrapper.this.mOnHeaderClickListener.onHeaderClick(paramView, this.val$position, l);
        }
      }
    });
    return localView2;
  }

  private View popHeader()
  {
    if (this.mHeaderCache.size() > 0)
      return (View)this.mHeaderCache.remove(0);
    return null;
  }

  private boolean previousPositionHasSameHeader(int paramInt)
  {
    return (paramInt != 0) && (this.mDelegate.getHeaderId(paramInt) == this.mDelegate.getHeaderId(paramInt - 1));
  }

  private void recycleHeaderIfExists(WrapperView paramWrapperView)
  {
    View localView = paramWrapperView.mHeader;
    if (localView != null)
    {
      localView.setVisibility(0);
      this.mHeaderCache.add(localView);
    }
  }

  public boolean areAllItemsEnabled()
  {
    return this.mDelegate.areAllItemsEnabled();
  }

  public boolean equals(Object paramObject)
  {
    return this.mDelegate.equals(paramObject);
  }

  public int getCount()
  {
    return this.mDelegate.getCount();
  }

  public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    return ((BaseAdapter)this.mDelegate).getDropDownView(paramInt, paramView, paramViewGroup);
  }

  public long getHeaderId(int paramInt)
  {
    return this.mDelegate.getHeaderId(paramInt);
  }

  public View getHeaderView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    return this.mDelegate.getHeaderView(paramInt, paramView, paramViewGroup);
  }

  public Object getItem(int paramInt)
  {
    return this.mDelegate.getItem(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return this.mDelegate.getItemId(paramInt);
  }

  public int getItemViewType(int paramInt)
  {
    return this.mDelegate.getItemViewType(paramInt);
  }

  public WrapperView getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView1;
    View localView2;
    if (paramView == null)
    {
      localObject = new WrapperView(this.mContext);
      localView1 = this.mDelegate.getView(paramInt, ((WrapperView)localObject).mItem, paramViewGroup);
      localView2 = null;
      if (!previousPositionHasSameHeader(paramInt))
        break label110;
      recycleHeaderIfExists((WrapperView)localObject);
      label52: if ((!(localView1 instanceof Checkable)) || ((localObject instanceof CheckableWrapperView)))
        break label122;
    }
    for (Object localObject = new CheckableWrapperView(this.mContext); ; localObject = new WrapperView(this.mContext))
      label110: label122: 
      do
      {
        ((WrapperView)localObject).update(localView1, localView2, this.mDivider, this.mDividerHeight);
        return localObject;
        localObject = (WrapperView)paramView;
        break;
        localView2 = configureHeader((WrapperView)localObject, paramInt);
        break label52;
      }
      while (((localView1 instanceof Checkable)) || (!(localObject instanceof CheckableWrapperView)));
  }

  public int getViewTypeCount()
  {
    return this.mDelegate.getViewTypeCount();
  }

  public boolean hasStableIds()
  {
    return this.mDelegate.hasStableIds();
  }

  public int hashCode()
  {
    return this.mDelegate.hashCode();
  }

  public boolean isEmpty()
  {
    return this.mDelegate.isEmpty();
  }

  public boolean isEnabled(int paramInt)
  {
    return this.mDelegate.isEnabled(paramInt);
  }

  public void notifyDataSetChanged()
  {
    ((BaseAdapter)this.mDelegate).notifyDataSetChanged();
  }

  public void notifyDataSetInvalidated()
  {
    ((BaseAdapter)this.mDelegate).notifyDataSetInvalidated();
  }

  void setDivider(Drawable paramDrawable, int paramInt)
  {
    this.mDivider = paramDrawable;
    this.mDividerHeight = paramInt;
    notifyDataSetChanged();
  }

  public void setOnHeaderClickListener(OnHeaderClickListener paramOnHeaderClickListener)
  {
    this.mOnHeaderClickListener = paramOnHeaderClickListener;
  }

  public String toString()
  {
    return this.mDelegate.toString();
  }

  static abstract interface OnHeaderClickListener
  {
    public abstract void onHeaderClick(View paramView, int paramInt, long paramLong);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.AdapterWrapper
 * JD-Core Version:    0.6.0
 */