package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.graphics.Canvas;
import android.os.Build.VERSION;

class StickyListHeadersListView$WrapperViewListLifeCycleListener
  implements WrapperViewList.LifeCycleListener
{
  private StickyListHeadersListView$WrapperViewListLifeCycleListener(StickyListHeadersListView paramStickyListHeadersListView)
  {
  }

  public void onDispatchDrawOccurred(Canvas paramCanvas)
  {
    if (Build.VERSION.SDK_INT < 8)
      StickyListHeadersListView.access$900(this.this$0, StickyListHeadersListView.access$800(this.this$0).getFixedFirstVisibleItem());
    if (StickyListHeadersListView.access$200(this.this$0) != null)
    {
      if (StickyListHeadersListView.access$1000(this.this$0))
      {
        paramCanvas.save();
        paramCanvas.clipRect(0, StickyListHeadersListView.access$1100(this.this$0), this.this$0.getRight(), this.this$0.getBottom());
        StickyListHeadersListView.access$1200(this.this$0, paramCanvas, StickyListHeadersListView.access$200(this.this$0), 0L);
        paramCanvas.restore();
      }
    }
    else
      return;
    StickyListHeadersListView.access$1300(this.this$0, paramCanvas, StickyListHeadersListView.access$200(this.this$0), 0L);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersListView.WrapperViewListLifeCycleListener
 * JD-Core Version:    0.6.0
 */