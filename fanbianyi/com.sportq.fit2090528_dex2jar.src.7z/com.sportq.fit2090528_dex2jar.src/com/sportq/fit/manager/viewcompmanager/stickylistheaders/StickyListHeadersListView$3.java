package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

class StickyListHeadersListView$3
  implements View.OnTouchListener
{
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    return this.val$l.onTouch(this.this$0, paramMotionEvent);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersListView.3
 * JD-Core Version:    0.6.0
 */