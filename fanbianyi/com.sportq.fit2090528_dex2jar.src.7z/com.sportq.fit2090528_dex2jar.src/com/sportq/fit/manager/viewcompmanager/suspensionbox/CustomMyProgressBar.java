package com.sportq.fit.manager.viewcompmanager.suspensionbox;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import com.sportq.fit.fitmoudle.widget.CustomTextView;

public class CustomMyProgressBar extends RelativeLayout
{
  private CustomTextView leftTextView;
  private CustomTextView rightTextView;
  private ProgressBar textProgressBar;

  public CustomMyProgressBar(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    initView(paramContext);
  }

  public int getProgress()
  {
    return this.textProgressBar.getProgress();
  }

  public void initView(Context paramContext)
  {
    View.inflate(paramContext, 2130968750, this);
    this.textProgressBar = ((ProgressBar)findViewById(2131755815));
    this.leftTextView = ((CustomTextView)findViewById(2131755816));
    this.rightTextView = ((CustomTextView)findViewById(2131755817));
    this.textProgressBar.setIndeterminate(false);
  }

  public void setLeftText(String paramString)
  {
    this.leftTextView.setText(paramString);
  }

  public void setProgress(int paramInt)
  {
    if (paramInt == 0)
      paramInt = 1;
    this.textProgressBar.setProgress(paramInt);
  }

  public void setProgressMax(int paramInt)
  {
    this.textProgressBar.setMax(paramInt);
  }

  public void setRightText(String paramString)
  {
    this.rightTextView.setText(paramString);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.suspensionbox.CustomMyProgressBar
 * JD-Core Version:    0.6.0
 */