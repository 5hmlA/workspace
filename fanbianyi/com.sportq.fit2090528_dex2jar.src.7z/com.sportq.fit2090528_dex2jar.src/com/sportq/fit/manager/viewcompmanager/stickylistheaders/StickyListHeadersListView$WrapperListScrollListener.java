package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;

class StickyListHeadersListView$WrapperListScrollListener
  implements AbsListView.OnScrollListener
{
  private StickyListHeadersListView$WrapperListScrollListener(StickyListHeadersListView paramStickyListHeadersListView)
  {
  }

  public void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
  {
    if (StickyListHeadersListView.access$700(this.this$0) != null)
      StickyListHeadersListView.access$700(this.this$0).onScroll(paramAbsListView, paramInt1, paramInt2, paramInt3);
    StickyListHeadersListView.access$900(this.this$0, StickyListHeadersListView.access$800(this.this$0).getFixedFirstVisibleItem());
  }

  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
  {
    if (StickyListHeadersListView.access$700(this.this$0) != null)
      StickyListHeadersListView.access$700(this.this$0).onScrollStateChanged(paramAbsListView, paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersListView.WrapperListScrollListener
 * JD-Core Version:    0.6.0
 */