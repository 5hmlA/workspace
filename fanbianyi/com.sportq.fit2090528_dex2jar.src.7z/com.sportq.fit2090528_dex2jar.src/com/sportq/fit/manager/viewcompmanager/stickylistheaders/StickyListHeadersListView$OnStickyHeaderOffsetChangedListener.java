package com.sportq.fit.manager.viewcompmanager.stickylistheaders;

import android.view.View;

public abstract interface StickyListHeadersListView$OnStickyHeaderOffsetChangedListener
{
  public abstract void onStickyHeaderOffsetChanged(StickyListHeadersListView paramStickyListHeadersListView, View paramView, int paramInt);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.stickylistheaders.StickyListHeadersListView.OnStickyHeaderOffsetChangedListener
 * JD-Core Version:    0.6.0
 */