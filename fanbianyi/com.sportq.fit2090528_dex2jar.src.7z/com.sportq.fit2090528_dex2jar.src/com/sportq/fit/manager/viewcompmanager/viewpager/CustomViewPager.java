package com.sportq.fit.manager.viewcompmanager.viewpager;

import android.content.Context;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewParent;
import com.sportq.fit.common.utils.LogUtils;

public class CustomViewPager extends ViewPager
{
  private DelayFindScrollThread fThread;
  private Handler handler;
  boolean scrollFlg = true;

  public CustomViewPager(Context paramContext)
  {
    super(paramContext, null);
  }

  public CustomViewPager(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.handler = new Handler();
  }

  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    try
    {
      getParent().requestDisallowInterceptTouchEvent(true);
      boolean bool = super.onInterceptTouchEvent(paramMotionEvent);
      return bool;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return false;
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    try
    {
      switch (paramMotionEvent.getAction())
      {
      case 0:
      case 1:
      default:
      case 2:
      }
      while (true)
      {
        return super.onTouchEvent(paramMotionEvent);
        stopScroll();
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return false;
  }

  public void startScroll(int paramInt)
  {
    if (this.fThread != null)
      this.handler.removeCallbacks(this.fThread);
    this.fThread = new DelayFindScrollThread(paramInt);
    this.handler.postDelayed(this.fThread, 4000L);
  }

  public void stopScroll()
  {
    if (this.fThread != null)
      this.handler.removeCallbacks(this.fThread);
  }

  private class DelayFindScrollThread
    implements Runnable
  {
    private int pageCount;

    public DelayFindScrollThread(int arg2)
    {
      int i;
      this.pageCount = i;
    }

    public void run()
    {
      try
      {
        int i = CustomViewPager.this.getCurrentItem();
        int k;
        if (CustomViewPager.this.scrollFlg)
        {
          int j = i + 1;
          k = j;
          if (-1 + this.pageCount == j)
            CustomViewPager.this.scrollFlg = false;
        }
        while (true)
        {
          CustomViewPager.this.setCurrentItem(k, true);
          CustomViewPager.this.handler.postDelayed(CustomViewPager.this.fThread, 3000L);
          return;
          int m = i - 1;
          k = m;
          if (m != 0)
            continue;
          CustomViewPager.this.scrollFlg = true;
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.viewcompmanager.viewpager.CustomViewPager
 * JD-Core Version:    0.6.0
 */