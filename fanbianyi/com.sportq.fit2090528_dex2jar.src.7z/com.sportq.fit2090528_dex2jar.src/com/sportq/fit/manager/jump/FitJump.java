package com.sportq.fit.manager.jump;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.google.gson.Gson;
import com.sportq.fit.business.NavMainActivity;
import com.sportq.fit.business.account.activity.Account02VideoGuideActivity;
import com.sportq.fit.business.account.activity.Account03QuickLoginActivity;
import com.sportq.fit.business.account.fit_login.LoginActivity;
import com.sportq.fit.business.find.activity.CourseActOperationalActivity;
import com.sportq.fit.business.mine.activity.Mine03FeedbackActivity;
import com.sportq.fit.business.mine.activity.Mine03PhotoInfoActivity;
import com.sportq.fit.business.mine.activity.Mine03WebUrlActivity;
import com.sportq.fit.business.mine.activity.MineFCurrencyActivity;
import com.sportq.fit.business.train.activity.Train22RecommendActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.TrainFinishEvent;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.EntdayPlanData;
import com.sportq.fit.common.model.GetuiDataModel;
import com.sportq.fit.common.model.MedalModel;
import com.sportq.fit.common.model.OrderTrackUsingModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import com.sportq.fit.common.reformer.BrowseVideoListReformer;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.activity.ClipPictureActivity;
import com.sportq.fit.fitmoudle.event.GotoShopTabEvent;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.network.data.CoursePhotoData;
import com.sportq.fit.fitmoudle.task.activity.Task01NewChallengesListActivity;
import com.sportq.fit.fitmoudle.task.activity.Task02ChallengeDetailsActivity;
import com.sportq.fit.fitmoudle.task.activity.Task03ChallengeWinnerListActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02FeedBackActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02FragmentMedalActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02HealthData2Activity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02HealthDataActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02NoticeActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02RemindActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02WeightActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine03MedalDetailsActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine03NotPunchAcitvity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine03SetNoticeActivity;
import com.sportq.fit.fitmoudle10.organize.activity.PerfectInfoFirstActivity;
import com.sportq.fit.fitmoudle10.organize.activity.TrainDetailInfoActivity;
import com.sportq.fit.fitmoudle10.organize.activity.TrainRecordsActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Video03ShowActivity;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.FitnessStartPageActivity;
import com.sportq.fit.fitmoudle11.video.activity.VideoOL01Activity;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseArticleDetailsActivity;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseVideoDetailsActivity;
import com.sportq.fit.fitmoudle12.browse.activity.ContentCommentActivity;
import com.sportq.fit.fitmoudle12.browse.activity.MineLikesAndCommentActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MallGoodsInfoActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MineCouponActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MineOrderDetailActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MineOrderTrackActivity;
import com.sportq.fit.fitmoudle13.shop.activity.ShopRecommendListActivity;
import com.sportq.fit.fitmoudle2.camera.activity.AlbumImageActivity;
import com.sportq.fit.fitmoudle2.camera.activity.FitnessPicPubRelease;
import com.sportq.fit.fitmoudle2.camera.activity.NewCameraActivity;
import com.sportq.fit.fitmoudle3.video.activity.Find07TrainPreviewActivity;
import com.sportq.fit.fitmoudle3.video.activity.Video01Activity;
import com.sportq.fit.fitmoudle3.video.activity.Video02FinishActivity;
import com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity;
import com.sportq.fit.fitmoudle5.activity.MasterClassDetailsActivity;
import com.sportq.fit.fitmoudle5.activity.MasterClassListActivity;
import com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity;
import com.sportq.fit.fitmoudle7.customize.activity.CustomStartActivity;
import com.sportq.fit.fitmoudle8.activity.Find02TrainCategoryActivity;
import com.sportq.fit.fitmoudle8.activity.Find02TrainCollectionActivity;
import com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.fitmoudle8.activity.action_library.ActionDetailsActivity;
import com.sportq.fit.fitmoudle8.activity.action_library.ActionUnLockActivity;
import com.sportq.fit.fitmoudle9.energy.activity.EnergyActionActivity;
import com.sportq.fit.fitmoudle9.energy.activity.EnergyDetailActivity;
import com.sportq.fit.fitmoudle9.energy.activity.EnergyInvitCodeActivity;
import com.sportq.fit.minepresenter.reformerImpl.PushJumpMedalImpl;
import com.sportq.fit.push.CheckPushManager;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.EventBus;

public class FitJump
  implements FitJumpInterface
{
  public void JumpPhotoActivity(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, AlbumImageActivity.class);
    localIntent.putExtra("sendImg", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void JumpSendImgPreviewActivity(Context paramContext, List paramList, int paramInt)
  {
  }

  public void JumpTrainCategoryActivity(Context paramContext, String paramString1, String paramString2)
  {
    Intent localIntent = new Intent(paramContext, Find02TrainCategoryActivity.class);
    localIntent.putExtra("type.id", paramString1);
    localIntent.putExtra("train.name", paramString2);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void courseJumpCommodityInfo(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, MallGoodsInfoActivity.class);
    localIntent.putExtra(MallGoodsInfoActivity.GOODSJSON, paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void courseJumpCommodityList(Context paramContext, String paramString1, String paramString2)
  {
    Intent localIntent = new Intent(paramContext, ShopRecommendListActivity.class);
    localIntent.putExtra("DATA_JSON", paramString1);
    localIntent.putExtra("TITLE", paramString2);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void customWeekDetailsJumpCourse(Context paramContext)
  {
  }

  public void customerToCommodityInfo(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, MallGoodsInfoActivity.class);
    localIntent.putExtra(MallGoodsInfoActivity.GOODSID, paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void customizeJumpCourse(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    Intent localIntent = new Intent(paramContext, Find04GenTrainInfoActivity.class);
    localIntent.putExtra("single.type", "0");
    localIntent.putExtra("plan.id", paramString1);
    if (!StringUtils.isNull(paramString2))
      localIntent.putExtra("show.join.btn.flg", "hide");
    localIntent.putExtra("customized.id", paramString3);
    localIntent.putExtra("week.num", paramString4);
    localIntent.putExtra("base.customized.id", paramString5);
    localIntent.putExtra("CUSTOM_PAUSE_DAY", paramString6);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void exitRemoveTag(Context paramContext)
  {
    CheckPushManager.updatePushToken(CheckPushManager.getPushChannel(), "");
  }

  public void fatCampJumpCourseDetail(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    Intent localIntent = new Intent(paramContext, Find04GenTrainInfoActivity.class);
    localIntent.putExtra("single.type", "0");
    localIntent.putExtra("customized.id", paramString2);
    localIntent.putExtra("FAT_CAMP_ID", paramString1);
    localIntent.putExtra("plan.id", paramString3);
    if (!StringUtils.isNull(paramString5))
      localIntent.putExtra("show.join.btn.flg", "hide");
    localIntent.putExtra("week.num", paramString4);
    localIntent.putExtra("CUSTOM_PAUSE_DAY", paramString6);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void findJumpAccount02VideoGuideActivity(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Account02VideoGuideActivity.class));
  }

  public void findJumpFind07TrainPreviewActivity(Context paramContext, int paramInt, PlanReformer paramPlanReformer, ActionModel paramActionModel)
  {
    Intent localIntent = new Intent(paramContext, Find07TrainPreviewActivity.class);
    localIntent.putExtra("intent.orientation", paramInt);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("intent.planModel", paramPlanReformer);
    localBundle.putSerializable("intent.current.actionModel", paramActionModel);
    localIntent.putExtras(localBundle);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void findJumpSecActivity(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
  }

  public void findJumpVideo01Activity(Context paramContext, PlanReformer paramPlanReformer, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    Intent localIntent = new Intent(paramContext, Video01Activity.class);
    localIntent.putExtra("train.model", paramPlanReformer);
    localIntent.putExtra("lose.id", paramString1);
    localIntent.putExtra("week.num", paramString2);
    localIntent.putExtra("day.num", paramString3);
    localIntent.putExtra("base.customized.id", paramString4);
    localIntent.putExtra("intent.from", paramString5);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void finishJumpCamera(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
  }

  public void finishJumpSec(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
  }

  public void finishJumpSetNotice(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Mine03SetNoticeActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void finishJumpTrainFeedBack(Context paramContext, String paramString1, String paramString2)
  {
  }

  public void finishJumpTrainPhotoInfo(Context paramContext)
  {
  }

  public void finishJumpTrainPhotoInfo(Context paramContext, String paramString)
  {
  }

  public void jumpBrowseVideoPlayActivity(Context paramContext, BrowseVideoListReformer paramBrowseVideoListReformer)
  {
    Intent localIntent = new Intent(paramContext, VideoOL01Activity.class);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("reformer", paramBrowseVideoListReformer);
    localIntent.putExtras(localBundle);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpCameraTakeActivity(Context paramContext, CoursePhotoData paramCoursePhotoData)
  {
    Intent localIntent = new Intent(paramContext, NewCameraActivity.class);
    localIntent.putExtra("course.info", paramCoursePhotoData);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpCommentList(Context paramContext, String paramString1, String paramString2, String paramString3, int paramInt)
  {
    Intent localIntent = new Intent(paramContext, ContentCommentActivity.class);
    localIntent.putExtra("tpc.id", paramString1);
    localIntent.putExtra("tpc.type", paramString2);
    localIntent.putExtra("from.type", paramString3);
    localIntent.putExtra("comment.num", String.valueOf(paramInt));
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpCommentList(Context paramContext, String paramString1, String paramString2, String paramString3, int paramInt, boolean paramBoolean)
  {
    Intent localIntent = new Intent(paramContext, ContentCommentActivity.class);
    localIntent.putExtra("tpc.id", paramString1);
    localIntent.putExtra("tpc.type", paramString2);
    localIntent.putExtra("from.type", paramString3);
    localIntent.putExtra("comment.num", String.valueOf(paramInt));
    localIntent.putExtra("show.edit", paramBoolean);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpCouponAct(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, MineCouponActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpCourseAct(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, CourseActOperationalActivity.class);
    localIntent.putExtra("jump.type", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpEnergyActivity(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, EnergyActionActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpFcoinAct(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, MineFCurrencyActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpFitnessPicPub(Context paramContext, CoursePhotoData paramCoursePhotoData)
  {
    Intent localIntent = new Intent(paramContext, FitnessPicPubRelease.class);
    localIntent.putExtra("jump.flg", "nav.main.jump");
    localIntent.putExtra("course.info", paramCoursePhotoData);
    localIntent.putExtra("wmfilter.olapinfo", paramCoursePhotoData.wmfOlapinfo);
    localIntent.putExtra("poster.olapinfo", paramCoursePhotoData.posterOlapinfo);
    FitnessPicPubRelease.strImageType = paramCoursePhotoData.strImageType;
    FitnessPicPubRelease.strImgPath = paramCoursePhotoData.strImgPath;
    localIntent.putExtra("cur.weight", paramCoursePhotoData.currentWeight);
    localIntent.putExtra("comment", paramCoursePhotoData.feeling);
    FitnessPicPubRelease.bodyDirection = paramCoursePhotoData.bodyDirection;
    FitnessPicPubRelease.strPubType = paramCoursePhotoData.strPubType;
    if ((paramContext instanceof Video02FinishActivity))
      localIntent.putExtra("from.where", "0");
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpFitnessTest(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, FitnessStartPageActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpMasterDetailAct(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, MasterClassDetailsActivity.class);
    localIntent.putExtra("lesson.id", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpMasterListAct(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, MasterClassListActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpNoPunshActivity(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Mine03NotPunchAcitvity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpPersonalEdit(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Mine03PersonalActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpRecomm(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Train22RecommendActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public <T> void jumpRecordDetail(Context paramContext, T paramT, String paramString1, String paramString2)
  {
    Intent localIntent = new Intent(paramContext, TrainDetailInfoActivity.class);
    if ((paramT instanceof PlanModel))
      localIntent.putExtra("data", (PlanModel)paramT);
    while (true)
    {
      localIntent.putExtra("week.id", paramString1);
      localIntent.putExtra("use.id", paramString2);
      localIntent.putExtra("show.bottom.btn", true);
      paramContext.startActivity(localIntent);
      AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
      return;
      if (!(paramT instanceof EntdayPlanData))
        continue;
      localIntent.putExtra("data", (EntdayPlanData)paramT);
    }
  }

  public void jumpRecordDetailInfoActivity(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    Intent localIntent = new Intent(paramContext, TrainDetailInfoActivity.class);
    localIntent.putExtra("intent.planId", paramString1);
    localIntent.putExtra("intent.olapInfo", paramString2);
    localIntent.putExtra("intent.time", paramString3);
    localIntent.putExtra("intent.calorie", paramString4);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpTask01NewChallengesListActivity(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Task01NewChallengesListActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpTrainStartCustomizeActivity(Context paramContext, String paramString1, String paramString2)
  {
    Intent localIntent = new Intent(paramContext, CustomStartActivity.class);
    localIntent.putExtra("custom_hascusflag", paramString1);
    localIntent.putExtra("custom_hasHistoryFlag", paramString2);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpUnLockAction(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, ActionUnLockActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void jumpVideo03ShowInfoActivity(Context paramContext, PlanReformer paramPlanReformer)
  {
    Intent localIntent = new Intent(paramContext, Video03ShowActivity.class);
    localIntent.putExtra("intent.TrainFinishEvent", paramPlanReformer);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void mine02FragmentMedal(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Mine02FragmentMedalActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void mine02HealthDataJump(Context paramContext, String paramString)
  {
    paramContext.startActivity(new Intent(paramContext, Mine02HealthDataActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void mine02NoticeJump(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Mine02NoticeActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void mine02WeightJump(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Mine02WeightActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void mine03MedalDetailsJump(Context paramContext, String paramString1, String paramString2, MedalModel paramMedalModel)
  {
    Intent localIntent = new Intent(paramContext, Mine03MedalDetailsActivity.class);
    localIntent.putExtra("type", paramString2);
    localIntent.putExtra("isSoudpool", paramString1);
    localIntent.putExtra("model", paramMedalModel);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void myLikeActionJumpDetails(Context paramContext, int paramInt, ArrayList<ResponseModel.ActionData> paramArrayList, String paramString)
  {
    Intent localIntent = new Intent(paramContext, ActionDetailsActivity.class);
    localIntent.putExtra("intent.current.actionModel", paramInt);
    localIntent.putExtra("original.data", paramArrayList);
    localIntent.putExtra("system.time", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void noticeJumpTaskWinnerList(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, Task03ChallengeWinnerListActivity.class);
    localIntent.putExtra("missionId", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushBrowseVideoDetailsActivity(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, BrowseVideoDetailsActivity.class);
    localIntent.putExtra("tpc.id", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushFeedbackActivity(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, Mine02FeedBackActivity.class);
    localIntent.putExtra(Mine02FeedBackActivity.FEEDBACKID, paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpArticleActivtiy(Context paramContext, String paramString, GetuiDataModel paramGetuiDataModel)
  {
    Intent localIntent = new Intent(paramContext, BrowseArticleDetailsActivity.class);
    localIntent.putExtra("article.url", paramString);
    localIntent.putExtra("article.id", StringUtils.urlGetArticleId(paramString));
    localIntent.putExtra("webPage.tag", "0");
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpChallengeActivity(Context paramContext, String paramString1, String paramString2, String paramString3, GetuiDataModel paramGetuiDataModel)
  {
    Intent localIntent = new Intent();
    localIntent.setClass(paramContext, Task02ChallengeDetailsActivity.class);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("message.model", paramGetuiDataModel);
    localIntent.putExtras(localBundle);
    localIntent.putExtra("missionId", paramString1);
    localIntent.putExtra("missionName", paramString2);
    localIntent.putExtra("click.flg", paramString3);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpCommentListActivity(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, MineLikesAndCommentActivity.class);
    localIntent.putExtra("message.type", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpEnergyDetailActivity(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, EnergyDetailActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpLikeListActivity(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, MineLikesAndCommentActivity.class);
    localIntent.putExtra("message.type", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpMissonActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel)
  {
    Intent localIntent = new Intent();
    localIntent.setClass(paramContext, Task03ChallengeWinnerListActivity.class);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("message.model", paramGetuiDataModel);
    localIntent.putExtras(localBundle);
    localIntent.putExtra("missionId", paramString1);
    localIntent.putExtra("click.flg", paramString2);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpNavMainActivity(Context paramContext)
  {
    Intent localIntent = new Intent(paramContext, NavMainActivity.class);
    localIntent.addFlags(268435456);
    paramContext.startActivity(localIntent);
  }

  public void pushJumpNoticeActivity(Context paramContext, String paramString, GetuiDataModel paramGetuiDataModel)
  {
    Intent localIntent = new Intent();
    localIntent.setClass(paramContext, Mine02NoticeActivity.class);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("message.model", paramGetuiDataModel);
    localIntent.putExtras(localBundle);
    localIntent.putExtra("click.flg", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpRemindListActivity(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Mine02RemindActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpSecActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel)
  {
  }

  public void pushJumpTrainCollectionActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel)
  {
    Intent localIntent = new Intent();
    localIntent.setClass(paramContext, Find02TrainCollectionActivity.class);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("message.model", paramGetuiDataModel);
    localIntent.putExtras(localBundle);
    localIntent.putExtra("group.id", paramString1);
    localIntent.putExtra("click.flg", paramString2);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpTrainCustomizedActivity(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, CustomDetailActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpTrainInfoActivity(Context paramContext, String paramString1, String paramString2, String paramString3, GetuiDataModel paramGetuiDataModel)
  {
    Intent localIntent = new Intent();
    localIntent.setClass(paramContext, Find04GenTrainInfoActivity.class);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("message.model", paramGetuiDataModel);
    localIntent.putExtras(localBundle);
    localIntent.putExtra("plan.id", paramString1);
    localIntent.putExtra("single.type", paramString2);
    localIntent.putExtra("click.flg", paramString3);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpTrainListActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel)
  {
    Intent localIntent = new Intent();
    localIntent.setClass(paramContext, Find03GenTrainListActivity.class);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("message.model", paramGetuiDataModel);
    localIntent.putExtras(localBundle);
    localIntent.putExtra("plan.id", paramString1);
    localIntent.putExtra("click.flg", paramString2);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushJumpTrainRecordsActivity(Context paramContext, String paramString1, String paramString2)
  {
    Intent localIntent = new Intent(paramContext, TrainRecordsActivity.class);
    if ("0".equals(paramString2));
    for (String str = "WEEK_DATE"; ; str = "MONTH_DATE")
    {
      localIntent.putExtra(str, paramString1);
      paramContext.startActivity(localIntent);
      AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
      return;
    }
  }

  public void pushJumpWebViewActivtiy(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, GetuiDataModel paramGetuiDataModel)
  {
    Intent localIntent = new Intent();
    localIntent.setClass(paramContext, Mine03WebUrlActivity.class);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("message.model", paramGetuiDataModel);
    localIntent.putExtras(localBundle);
    localIntent.putExtra("fromFlg", paramString1);
    localIntent.putExtra("webUrl", paramString2);
    localIntent.putExtra("describe", paramString3);
    localIntent.putExtra("share.flg", paramString4);
    localIntent.putExtra("click.flg", paramString5);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushMallGoodsInfoActivity(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, MallGoodsInfoActivity.class);
    localIntent.putExtra(MallGoodsInfoActivity.GOODSID, paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushMedalActivity(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, Mine03MedalDetailsActivity.class);
    localIntent.putExtra("intent.from", "intent.from.MedalManager");
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("model", new PushJumpMedalImpl().getMedalModel(paramString));
    localIntent.putExtras(localBundle);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushMineOrderDetailActivity(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, MineOrderDetailActivity.class);
    localIntent.putExtra("order.id", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushMineOrderTrackActivity(Context paramContext, String paramString)
  {
    OrderTrackUsingModel localOrderTrackUsingModel = (OrderTrackUsingModel)FitGsonFactory.create().fromJson(paramString, OrderTrackUsingModel.class);
    Intent localIntent = new Intent(paramContext, MineOrderTrackActivity.class);
    localIntent.putExtra("ORDER_TIME", localOrderTrackUsingModel.genOrderDate);
    localIntent.putExtra("ORDER_ID", localOrderTrackUsingModel.orderNum);
    localIntent.putExtra("PAGE_CODE", localOrderTrackUsingModel.packageId);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void pushShopMainActivity(Context paramContext)
  {
    EventBus.getDefault().post(new GotoShopTabEvent());
  }

  public void pushShopRecommendListActivity(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, ShopRecommendListActivity.class);
    localIntent.putExtra("key.jumpFlg", paramString);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void recordJumpTrainPhotoInfo(Context paramContext, String paramString1, String paramString2)
  {
    Intent localIntent = new Intent(paramContext, Mine03PhotoInfoActivity.class);
    localIntent.putExtra("train_history_id", paramString1);
    localIntent.putExtra("intent.from", paramString2);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void settingJumpClipPicture(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent(paramContext, ClipPictureActivity.class);
    localIntent.putExtra("clip.img.path", paramString);
    ((Activity)paramContext).startActivityForResult(localIntent, 4);
  }

  public void settingJumpEnergyInvitCode(Context paramContext)
  {
    Intent localIntent = new Intent(paramContext, EnergyInvitCodeActivity.class);
    localIntent.putExtra("from.type", "0");
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void settingJumpFeedBack(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Mine03FeedbackActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void settingJumpHealthData(Context paramContext, String paramString)
  {
    UserModel localUserModel = BaseApplication.userModel;
    Intent localIntent = new Intent(paramContext, Mine02HealthData2Activity.class);
    if (StringUtils.isNull(localUserModel.initialWeight))
      localIntent.setClass(paramContext, PerfectInfoFirstActivity.class);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void settingJumpVideoGuide(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, Account03QuickLoginActivity.class));
  }

  public void settingJumpWebView(Context paramContext, String paramString1, String paramString2)
  {
    Intent localIntent = new Intent(paramContext, Mine03WebUrlActivity.class);
    localIntent.putExtra("fromFlg", paramString1);
    localIntent.putExtra("webUrl", paramString2);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void taskJumpEnergyActivity(Context paramContext)
  {
    paramContext.startActivity(new Intent(paramContext, EnergyActionActivity.class));
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void taskLimitCourseJump(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    Intent localIntent = new Intent(paramContext, Find04GenTrainInfoActivity.class);
    localIntent.putExtra("single.type", "0");
    localIntent.putExtra("plan.id", paramString1);
    if (!StringUtils.isNull(paramString2))
      localIntent.putExtra("show.join.btn.flg", "hide");
    localIntent.putExtra("intent.from", paramString3);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void taskNotLoginJumpLogin(Context paramContext)
  {
    Intent localIntent = new Intent(paramContext, LoginActivity.class);
    localIntent.putExtra("task_noLogin_join", "task_noLogin_join");
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void trainerJumpWebView(Context paramContext, String paramString1, String paramString2)
  {
    Intent localIntent = new Intent(paramContext, Mine03WebUrlActivity.class);
    localIntent.putExtra("flg", paramString1);
    localIntent.putExtra("webUrl", paramString2);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void videoJumpFinishAcitivty(Context paramContext, TrainFinishEvent paramTrainFinishEvent, String paramString1, String paramString2, String paramString3)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.jump.FitJump
 * JD-Core Version:    0.6.0
 */