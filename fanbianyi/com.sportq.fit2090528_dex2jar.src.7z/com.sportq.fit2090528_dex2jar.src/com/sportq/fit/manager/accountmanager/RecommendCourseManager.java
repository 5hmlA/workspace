package com.sportq.fit.manager.accountmanager;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.view.View;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.train.widget.RecommendCourseDialog;
import com.sportq.fit.business.train.widget.RecommendCourseDialog.RecommendClickListener;
import com.sportq.fit.common.event.MainToastEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.fitmoudle.widget.ReminderDialog;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;

public class RecommendCourseManager
{
  public PlanModel _recomPlan;
  private RecommendCourseDialog.RecommendClickListener listener;
  private Context mContext;
  public PlanRecommendReformer planRecommendReformer;

  public RecommendCourseManager(RecommendCourseDialog.RecommendClickListener paramRecommendClickListener, Context paramContext, PlanRecommendReformer paramPlanRecommendReformer)
  {
    this.planRecommendReformer = paramPlanRecommendReformer;
    if (this.planRecommendReformer != null)
      this._recomPlan = this.planRecommendReformer._recomPlan;
    this.mContext = paramContext;
    this.listener = paramRecommendClickListener;
  }

  public void showRecommend()
  {
    if (this.planRecommendReformer._recomTypeFlg == 1)
    {
      if (this._recomPlan == null)
        return;
      new RecommendCourseDialog(this.listener, this.mContext).createDialog(this.planRecommendReformer);
      return;
    }
    if (this.planRecommendReformer._recomTypeFlg == 2)
    {
      new ReminderDialog(this.mContext).createDialog().setImageUrl(this.planRecommendReformer._popImgURL).setButtonText(this.mContext.getText(2131298922)).setPopupTitleText(this.planRecommendReformer._popTitle).setPopupMainTitleText(this.planRecommendReformer.mainTitle).setButtonLayoutOnClick(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          super.onClick(paramView);
        }
      }).setCloseLayoutOnClick(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          super.onClick(paramView);
        }
      }).setOnDismissListener(new DialogInterface.OnDismissListener()
      {
        public void onDismiss(DialogInterface paramDialogInterface)
        {
          EventBus.getDefault().post(new MainToastEvent(3));
        }
      });
      return;
    }
    EventBus.getDefault().post(new MainToastEvent(3));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.accountmanager.RecommendCourseManager
 * JD-Core Version:    0.6.0
 */