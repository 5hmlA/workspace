package com.sportq.fit.manager.accountmanager;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.activity.Mine03WebUrlActivity;
import com.sportq.fit.business.mine.widget.NewCouponDialog;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.event.MainToastEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.model.EnergyModel;
import com.sportq.fit.common.model.EntLinkData;
import com.sportq.fit.common.model.EntcouponDetData;
import com.sportq.fit.common.model.MedalModel;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.task.activity.Task01NewChallengesListActivity;
import com.sportq.fit.fitmoudle.task.activity.Task02ChallengeDetailsActivity;
import com.sportq.fit.fitmoudle.widget.ReminderDialog;
import com.sportq.fit.fitmoudle10.organize.activity.Mine03MedalDetailsActivity;
import com.sportq.fit.fitmoudle5.activity.MasterClassDetailsActivity;
import com.sportq.fit.fitmoudle7.customize.activity.TrainStartNextCustomizeActivity;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeFinishReformer;
import com.sportq.fit.supportlib.CommonUtils;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;

public class MedalManager
{
  public static final String EVENT_SHOWNOTICE = "MedalManager.event.showTrainNotice";
  private MedalManagerEnergy energy;
  private CustomizeModel.CustomDataEntity entCusData;
  private EntLinkData entLesData;
  private EntLinkData entLinkData;
  private MedalManagerEntMission entMission;
  private EntcouponDetData entNewCoupon;
  private Context mContext;
  private ArrayList<MedalModel> medalArray;
  private String popupCon;

  public MedalManager(Context paramContext, PlanRecommendReformer paramPlanRecommendReformer)
  {
    this.mContext = paramContext;
    this.medalArray = new ArrayList();
    Iterator localIterator = paramPlanRecommendReformer.medalArray.iterator();
    while (localIterator.hasNext())
    {
      MedalModel localMedalModel = (MedalModel)localIterator.next();
      if (localMedalModel == null)
        continue;
      this.medalArray.add(localMedalModel);
    }
    if (!StringUtils.isNull(paramPlanRecommendReformer.entMission_Type))
    {
      this.entMission = new MedalManagerEntMission();
      this.entMission.entMission_PopupId = paramPlanRecommendReformer.entMission_PopupId;
      this.entMission.entMission_ImageURL = paramPlanRecommendReformer.entMission_ImageURL;
      this.entMission.entMission_MainTitle = paramPlanRecommendReformer.entMission_MainTitle;
      this.entMission.entMission_PopupTitle = paramPlanRecommendReformer.entMission_PopupTitle;
      this.entMission.type = paramPlanRecommendReformer.entMission_Type;
    }
    MedalManagerEnergy localMedalManagerEnergy;
    if ((!StringUtils.isNull(paramPlanRecommendReformer.energyValue)) && (paramPlanRecommendReformer.energyArray != null) && (!paramPlanRecommendReformer.energyArray.isEmpty()))
    {
      this.energy = new MedalManagerEnergy();
      localMedalManagerEnergy = this.energy;
      if (!StringUtils.isNull(paramPlanRecommendReformer.originalEnergyValue))
        break label334;
    }
    label334: for (String str = "0"; ; str = paramPlanRecommendReformer.originalEnergyValue)
    {
      localMedalManagerEnergy.originalEnergyValue = str;
      this.energy.energyValue = paramPlanRecommendReformer.energyValue;
      this.energy.energyArray = paramPlanRecommendReformer.energyArray;
      if ((paramPlanRecommendReformer.entCouponDet != null) && (!StringUtils.isNull(paramPlanRecommendReformer.entCouponDet.couponId)))
        this.entNewCoupon = paramPlanRecommendReformer.entCouponDet;
      if (!StringUtils.isNull(paramPlanRecommendReformer.popupCon))
        this.popupCon = paramPlanRecommendReformer.popupCon;
      if ((paramPlanRecommendReformer.entCusData != null) && (!StringUtils.isNull(paramPlanRecommendReformer.entCusData.customId)))
        this.entCusData = paramPlanRecommendReformer.entCusData;
      if (paramPlanRecommendReformer.entLink != null)
        this.entLinkData = paramPlanRecommendReformer.entLink;
      if (paramPlanRecommendReformer.entLes != null)
        this.entLesData = paramPlanRecommendReformer.entLes;
      return;
    }
  }

  private void showCusOver()
  {
    new DialogManager().createChoiceDialog(new FitInterfaceUtils.DialogListener()
    {
      public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
      {
        if (paramInt == -1)
        {
          CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GetCusData);
          CustomizeFinishReformer localCustomizeFinishReformer = new CustomizeFinishReformer();
          localCustomizeFinishReformer.entCusData = MedalManager.this.entCusData;
          Intent localIntent = new Intent(MedalManager.this.mContext, TrainStartNextCustomizeActivity.class);
          localIntent.putExtra("see_finished_train_situation", localCustomizeFinishReformer);
          MedalManager.this.mContext.startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)MedalManager.this.mContext, 0);
        }
      }
    }
    , this.mContext, "", this.popupCon, "立即查看", "取消").setOnDismissListener(new DialogInterface.OnDismissListener()
    {
      public void onDismiss(DialogInterface paramDialogInterface)
      {
        MedalManager.access$502(MedalManager.this, "");
        MedalManager.access$602(MedalManager.this, null);
        EventBus.getDefault().post(new MainToastEvent(0));
      }
    });
  }

  private void showEnergy()
  {
    if (!MedalEnergyDialog.isShowing)
      new MedalEnergyDialog().createDialog(this.mContext).setEnergyValue(this.energy.originalEnergyValue, this.energy.energyValue).setEnergyList(this.energy.energyArray).setOnDismissListener(new DialogInterface.OnDismissListener()
      {
        public void onDismiss(DialogInterface paramDialogInterface)
        {
          MedalManager.access$202(MedalManager.this, null);
          EventBus.getDefault().post(new MainToastEvent(0));
        }
      });
  }

  private void showEntMission()
  {
    new ReminderDialog(this.mContext).createDialog().setPopupTitleText(this.entMission.entMission_PopupTitle).setPopupMainTitleText(this.entMission.entMission_MainTitle).setImageUrl(this.entMission.entMission_ImageURL).setButtonText(this.mContext.getText(2131298134)).setButtonLayoutOnClick(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if ((MedalManager.this.entMission == null) || (MedalManager.this.entMission.isList()))
        {
          Intent localIntent1 = new Intent(MedalManager.this.mContext, Task01NewChallengesListActivity.class);
          localIntent1.putExtra("page.show", "viewpager.mine");
          MedalManager.this.mContext.startActivity(localIntent1);
          return;
        }
        Intent localIntent2 = new Intent(MedalManager.this.mContext, Task02ChallengeDetailsActivity.class);
        localIntent2.putExtra("missionId", MedalManager.this.entMission.entMission_PopupId);
        localIntent2.putExtra("missionName", MedalManager.this.entMission.entMission_PopupTitle);
        MedalManager.this.mContext.startActivity(localIntent2);
      }
    }).setOnDismissListener(new DialogInterface.OnDismissListener()
    {
      public void onDismiss(DialogInterface paramDialogInterface)
      {
        MedalManager.access$302(MedalManager.this, null);
        EventBus.getDefault().post(new MainToastEvent(0));
      }
    });
  }

  private void showEntNewCoupon()
  {
    new NewCouponDialog().create(this.mContext, this.entNewCoupon).setOnDismissListener(new DialogInterface.OnDismissListener()
    {
      public void onDismiss(DialogInterface paramDialogInterface)
      {
        MedalManager.access$402(MedalManager.this, null);
        EventBus.getDefault().post(new MainToastEvent(0));
      }
    });
  }

  private void showLesDialog()
  {
    String str = this.entLesData.jumpId;
    new ReminderDialog(this.mContext).createDialog().setPopupTitleText(this.entLesData.popupComment).setPopupMainTitleText(this.entLesData.popupTitle).setImageUrl(this.entLesData.imageURL).setButtonText("去看看").setButtonLayoutOnClick(new View.OnClickListener(str)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(MedalManager.this.mContext, MasterClassDetailsActivity.class);
        localIntent.putExtra("lesson.id", this.val$jumpId);
        MedalManager.this.mContext.startActivity(localIntent);
      }
    }).setOnDismissListener(new DialogInterface.OnDismissListener()
    {
      public void onDismiss(DialogInterface paramDialogInterface)
      {
        MedalManager.access$702(MedalManager.this, null);
        EventBus.getDefault().post(new MainToastEvent(0));
      }
    });
  }

  private void showLink()
  {
    String str = this.entLinkData.linkUrl;
    new DialogManager().createAdPopDialog(new FitInterfaceUtils.DialogListener(str)
    {
      public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
      {
        switch (paramInt)
        {
        case -2:
        default:
          return;
        case -1:
          Intent localIntent = new Intent(MedalManager.this.mContext, Mine03WebUrlActivity.class);
          localIntent.putExtra("webUrl", this.val$linkUrl);
          MedalManager.this.mContext.startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)MedalManager.this.mContext, 0);
          return;
        case -3:
        }
        MedalManager.access$102(MedalManager.this, null);
        EventBus.getDefault().post(new MainToastEvent(0));
      }
    }
    , this.entLinkData.imageURL, this.mContext);
  }

  private void showMedal()
  {
    LogUtils.d("勋章数组大小：", String.valueOf(this.medalArray.size()));
    LogUtils.d("勋章内容：", String.valueOf(((MedalModel)this.medalArray.get(0)).medalCom));
    Intent localIntent = new Intent(this.mContext, Mine03MedalDetailsActivity.class);
    MedalModel localMedalModel = (MedalModel)this.medalArray.get(0);
    if ("MED01".equals(localMedalModel.medalType))
      localMedalModel.medalTypel = "1";
    while (true)
    {
      localIntent.putExtra("intent.from", "intent.from.MedalManager");
      Bundle localBundle = new Bundle();
      localBundle.putSerializable("model", localMedalModel);
      localBundle.putString("isSoudpool", "isSoudpool");
      localIntent.putExtras(localBundle);
      this.medalArray.remove(0);
      this.mContext.startActivity(localIntent);
      EventBus.getDefault().post("refresh.media.ui");
      return;
      if (("MED02".equals(localMedalModel.medalType)) || ("MED03".equals(localMedalModel.medalType)))
      {
        localMedalModel.medalTypel = "2";
        continue;
      }
      if (!"MED12".equals(localMedalModel.medalType))
        break;
      localMedalModel.medalTypel = "4";
    }
    while (true)
    {
      try
      {
        String[] arrayOfString = localMedalModel.olapInfo.split("\\|!\\|");
        if (!"0".equals(arrayOfString[(-1 + arrayOfString.length)]))
          break label271;
        str = "3";
        localMedalModel.medalTypel = str;
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
      }
      break;
      label271: String str = "16";
    }
  }

  public boolean hasMedal()
  {
    if (this.medalArray == null);
    do
      return false;
    while (this.medalArray.size() <= 0);
    return true;
  }

  public void show()
  {
    if (this.entLinkData != null)
    {
      showLink();
      return;
    }
    if (this.energy != null)
    {
      showEnergy();
      return;
    }
    if (hasMedal())
    {
      showMedal();
      return;
    }
    if (this.entMission != null)
    {
      showEntMission();
      return;
    }
    if (this.entNewCoupon != null)
    {
      showEntNewCoupon();
      return;
    }
    if ((!StringUtils.isNull(this.popupCon)) && (this.entCusData != null))
    {
      showCusOver();
      return;
    }
    if (this.entLesData != null)
    {
      showLesDialog();
      return;
    }
    EventBus.getDefault().post(new MainToastEvent(2));
  }

  static class MedalManagerEnergy
  {
    public ArrayList<EnergyModel> energyArray;
    public String energyValue;
    public String originalEnergyValue;
  }

  static class MedalManagerEntMission
  {
    public String entMission_ImageURL;
    public String entMission_MainTitle;
    public String entMission_PopupId;
    public String entMission_PopupTitle;
    public String type;

    public boolean isList()
    {
      return "2".equals(this.type);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.manager.accountmanager.MedalManager
 * JD-Core Version:    0.6.0
 */