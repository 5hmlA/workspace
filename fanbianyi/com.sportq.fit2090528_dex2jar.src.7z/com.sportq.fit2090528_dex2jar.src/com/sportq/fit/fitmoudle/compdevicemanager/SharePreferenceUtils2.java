package com.sportq.fit.fitmoudle.compdevicemanager;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.google.gson.Gson;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.ExitAtVideo02Event;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.greenrobot.eventbus.EventBus;

public class SharePreferenceUtils2 extends SharePreferenceUtils
{
  private static final String KEY_BE_KILLED_AT_TRAIN = "key.be.killed.at.train";
  private static final String KEY_EXIT_AT_VIDEO02FINISHACITIVITY = "key.exit.at.video02FinishActivity";
  private static final String OLD_LOCAL_TIME = "old.local.time";
  private static final String SEPARATOR = ",";
  private static final String SYSTEM_TIME_DIFF = "system.time.diff";
  private static final String TABLE_VIDEO = "table.video";
  private static final String TABLE_VIDEO_FINISH = "table.video.finish";
  private static final String USERS_TYPE = "users.type";

  public static boolean delLocalTrainDataPlanReformer(String paramString)
  {
    if (BaseApplication.appliContext == null);
    SharedPreferences localSharedPreferences;
    do
    {
      return false;
      localSharedPreferences = BaseApplication.appliContext.getSharedPreferences("local.train.date.planreformer", 0);
    }
    while (!localSharedPreferences.contains(getKeyWithUserId(paramString)));
    SharedPreferences.Editor localEditor = localSharedPreferences.edit();
    localEditor.remove(getKeyWithUserId(paramString));
    localEditor.apply();
    return true;
  }

  public static List<PlanReformer> getAllLocalTrainDataPlanReformer()
  {
    ArrayList localArrayList = new ArrayList();
    if (BaseApplication.appliContext == null)
      return localArrayList;
    Map localMap = BaseApplication.appliContext.getSharedPreferences("local.train.date.planreformer", 0).getAll();
    Iterator localIterator = localMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str1 = (String)localIterator.next();
      if (!isCurrentUser(str1))
        continue;
      String str2 = String.valueOf(localMap.get(str1));
      Gson localGson = FitGsonFactory.create();
      try
      {
        localArrayList.add(localGson.fromJson(str2, PlanReformer.class));
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
      }
    }
    Collections.sort(localArrayList, new Comparator()
    {
      public int compare(PlanReformer paramPlanReformer1, PlanReformer paramPlanReformer2)
      {
        if ((paramPlanReformer1 == null) || (paramPlanReformer2 == null))
          return 1;
        Date localDate = DateUtils.stringToDate2(paramPlanReformer1.startDate);
        return Long.valueOf(DateUtils.stringToDate2(paramPlanReformer2.startDate).getTime()).compareTo(Long.valueOf(localDate.getTime()));
      }
    });
    return localArrayList;
  }

  public static boolean getBeKilledAtTrain(Context paramContext)
  {
    if (paramContext == null)
      return false;
    boolean bool = paramContext.getSharedPreferences("table.video", 0).getBoolean("key.be.killed.at.train", false);
    putBeKilledAtTrain(paramContext, false);
    return bool;
  }

  public static boolean getExitAtVideo02FinishActivity()
  {
    if (BaseApplication.appliContext == null)
      return false;
    return BaseApplication.appliContext.getSharedPreferences("table.video.finish", 0).getBoolean(getKeyWithUserId("key.exit.at.video02FinishActivity"), false);
  }

  private static String getKeyWithUserId(String paramString)
  {
    if (BaseApplication.userModel != null)
      paramString = BaseApplication.userModel.userId + "," + paramString;
    return paramString;
  }

  public static PlanReformer getLocalTrainDataPlanReformer(String paramString)
  {
    if (BaseApplication.appliContext == null)
      return null;
    String str = BaseApplication.appliContext.getSharedPreferences("local.train.date.planreformer", 0).getString(getKeyWithUserId(paramString), "");
    if (StringUtils.isNull(str))
      return null;
    Gson localGson = FitGsonFactory.create();
    try
    {
      PlanReformer localPlanReformer = (PlanReformer)localGson.fromJson(str, PlanReformer.class);
      return localPlanReformer;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return null;
  }

  public static PlanReformer getNewLocalTrainDataPlanReformer()
  {
    Context localContext = BaseApplication.appliContext;
    PlanReformer localPlanReformer = null;
    if (localContext != null)
    {
      String str = BaseApplication.appliContext.getSharedPreferences("local.train.date.newest.planreformer", 0).getString(getKeyWithUserId("key.news.local.train.data.key"), "");
      boolean bool = StringUtils.isNull(str);
      localPlanReformer = null;
      if (!bool)
        localPlanReformer = getLocalTrainDataPlanReformer(str);
    }
    return localPlanReformer;
  }

  public static String getNewRegisteredUsersTime(String paramString)
  {
    if (BaseApplication.appliContext == null)
      return "";
    return BaseApplication.appliContext.getSharedPreferences("users.type", 0).getString(paramString, "");
  }

  public static String getOldLocalTime()
  {
    if (BaseApplication.appliContext == null)
      return "";
    return BaseApplication.appliContext.getSharedPreferences("local.time", 0).getString("old.local.time", "");
  }

  public static String getTimeDiff()
  {
    if (BaseApplication.appliContext == null)
      return "";
    return BaseApplication.appliContext.getSharedPreferences("time.diff", 0).getString("system.time.diff", "");
  }

  private static boolean isCurrentUser(String paramString)
  {
    UserModel localUserModel = BaseApplication.userModel;
    boolean bool1 = false;
    if (localUserModel != null)
    {
      boolean bool2 = paramString.contains(",");
      bool1 = false;
      if (bool2)
      {
        String[] arrayOfString = paramString.split(",");
        bool1 = false;
        if (arrayOfString != null)
        {
          int i = arrayOfString.length;
          bool1 = false;
          if (i > 0)
            bool1 = arrayOfString[0].equals(BaseApplication.userModel.userId);
        }
      }
    }
    return bool1;
  }

  public static void putBeKilledAtTrain(Context paramContext, boolean paramBoolean)
  {
    if (paramContext != null)
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("table.video", 0).edit();
      localEditor.putBoolean("key.be.killed.at.train", paramBoolean);
      localEditor.apply();
    }
  }

  public static void putExitAtVideo02FinishActivity(boolean paramBoolean)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("table.video.finish", 0).edit();
      localEditor.putBoolean(getKeyWithUserId("key.exit.at.video02FinishActivity"), paramBoolean);
      localEditor.apply();
    }
  }

  public static void putLocalTrainDataPlanReformer(String paramString, PlanReformer paramPlanReformer)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("local.train.date.planreformer", 0).edit();
      localEditor.putString(getKeyWithUserId(paramString), FitGsonFactory.create().toJson(paramPlanReformer));
      localEditor.apply();
      EventBus.getDefault().post(new ExitAtVideo02Event());
    }
  }

  public static void putNewLocalTrainDataPlanReformerKey(String paramString)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("local.train.date.newest.planreformer", 0).edit();
      localEditor.putString(getKeyWithUserId("key.news.local.train.data.key"), paramString);
      localEditor.apply();
    }
  }

  public static void putNewRegisteredUsersTime(String paramString1, String paramString2)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("users.type", 0).edit();
      localEditor.putString(paramString1, paramString2);
      localEditor.apply();
    }
  }

  public static void putOldLocalTime(String paramString)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("local.time", 0).edit();
      localEditor.putString("old.local.time", paramString);
      localEditor.apply();
    }
  }

  public static void putTimeDiff(String paramString)
  {
    if (BaseApplication.appliContext != null)
    {
      SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("time.diff", 0).edit();
      localEditor.putString("system.time.diff", paramString);
      localEditor.apply();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.compdevicemanager.SharePreferenceUtils2
 * JD-Core Version:    0.6.0
 */