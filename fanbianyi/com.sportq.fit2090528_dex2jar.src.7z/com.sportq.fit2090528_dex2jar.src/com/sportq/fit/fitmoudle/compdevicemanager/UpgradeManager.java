package com.sportq.fit.fitmoudle.compdevicemanager;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DownLoadListener;
import com.sportq.fit.common.interfaces.presenter.video.Callback;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.supportlib.download.DefaultDownloadViewHolder;
import com.sportq.fit.supportlib.download.DownloadInfo;
import com.sportq.fit.supportlib.download.DownloadManager;
import com.sportq.fit.supportlib.download.UpdateDownloadViewHolder;
import java.io.File;

public class UpgradeManager
{
  private static final String TAG = UpgradeManager.class.getName();
  private DownloadInfo downloadInfo;
  private DownloadManager downloadManager;
  private final String fileName = VersionUpdateCheck.UPGRADE_APK_URL;

  public void delApk(Context paramContext)
  {
    if (CompDeviceInfoUtils.checkPermission(paramContext, "android.permission.WRITE_EXTERNAL_STORAGE"))
    {
      File localFile = new File(this.fileName);
      while (localFile.exists())
        localFile.delete();
    }
  }

  public void downloadApk(String paramString, Callback<Boolean> paramCallback)
  {
    try
    {
      if (new File(this.fileName).exists())
      {
        paramCallback.callback(Boolean.valueOf(true));
        return;
      }
      this.downloadInfo = new DownloadInfo();
      this.downloadInfo.setUrl(paramString);
      this.downloadInfo.setAutoRename(true);
      this.downloadInfo.setAutoResume(true);
      this.downloadInfo.setLabel("apkURL");
      this.downloadInfo.setFileSavePath(this.fileName);
      com.sportq.fit.common.BaseApplication.downLoadsize = 1.0F;
      this.downloadManager = new DownloadManager();
      this.downloadManager.startDownload(paramString, "apkURL", this.fileName, true, true, new DefaultDownloadViewHolder(this.downloadInfo, new FitInterfaceUtils.DownLoadListener(paramCallback)
      {
        public void onFailure()
        {
        }

        public void onLoading(float paramFloat)
        {
          String str = UpgradeManager.TAG;
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = Float.valueOf(paramFloat);
          LogUtils.d(str, String.format("进度:%s", arrayOfObject));
          Log.e("onLoading", String.valueOf(paramFloat));
        }

        public void onSuccess()
        {
          Log.e("onSuccess", "下载新包完成");
          LogUtils.d(UpgradeManager.TAG, String.format("下载新包完成", new Object[0]));
          if (this.val$callback != null)
            this.val$callback.callback(Boolean.valueOf(true));
        }
      }));
      return;
    }
    catch (ActivityNotFoundException localActivityNotFoundException)
    {
      LogUtils.e(localActivityNotFoundException);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void installApk(Context paramContext)
  {
    File localFile = new File(this.fileName);
    if (localFile.exists())
    {
      Intent localIntent = new Intent("android.intent.action.VIEW");
      localIntent.setDataAndType(Uri.fromFile(localFile), "application/vnd.android.package-archive");
      paramContext.startActivity(localIntent);
    }
  }

  public void startDownLoad(String paramString, Callback<Boolean> paramCallback)
  {
    try
    {
      this.downloadInfo = new DownloadInfo();
      this.downloadInfo.setUrl(paramString);
      this.downloadInfo.setAutoRename(true);
      this.downloadInfo.setAutoResume(true);
      this.downloadInfo.setLabel("apkURL");
      this.downloadInfo.setFileSavePath(this.fileName);
      com.sportq.fit.common.BaseApplication.downLoadsize = 1.0F;
      this.downloadManager = new DownloadManager();
      this.downloadManager.startDownload(paramString, "apkURL", this.fileName, true, true, new UpdateDownloadViewHolder(this.downloadInfo, new FitInterfaceUtils.DownLoadListener(paramCallback)
      {
        public void onFailure()
        {
        }

        public void onLoading(float paramFloat)
        {
          Log.e("onLoading", String.valueOf(paramFloat));
        }

        public void onSuccess()
        {
          Log.e("onSuccess", "下载新包完成");
          if (this.val$callback != null)
            this.val$callback.callback(Boolean.valueOf(true));
        }
      }));
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.compdevicemanager.UpgradeManager
 * JD-Core Version:    0.6.0
 */