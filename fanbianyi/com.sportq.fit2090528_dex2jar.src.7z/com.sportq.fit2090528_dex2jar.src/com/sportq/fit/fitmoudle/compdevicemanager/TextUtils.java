package com.sportq.fit.fitmoudle.compdevicemanager;

import android.content.ClipData;
import android.content.ClipData.Item;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.EditText;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.uicommon.R.mipmap;

public class TextUtils
{
  private static final String STR_TAG = "TextUtils";

  public static boolean copyToClipboard(String paramString)
  {
    try
    {
      ClipboardManager localClipboardManager = (ClipboardManager)BaseApplication.appliContext.getSystemService("clipboard");
      int i = 0;
      if (localClipboardManager != null)
      {
        localClipboardManager.setPrimaryClip(ClipData.newPlainText("Label", paramString));
        i = 1;
      }
      return i;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return false;
  }

  public static String getClipboardValue()
  {
    try
    {
      ClipboardManager localClipboardManager = (ClipboardManager)BaseApplication.appliContext.getSystemService("clipboard");
      if ((localClipboardManager != null) && (localClipboardManager.hasPrimaryClip()))
      {
        CharSequence localCharSequence = localClipboardManager.getPrimaryClip().getItemAt(0).getText();
        if (localCharSequence == null)
          return "";
        return String.valueOf(localCharSequence);
      }
      return "";
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return "";
  }

  public static Typeface getFontFace()
  {
    return Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/FIT_FONT.ttf");
  }

  public static Typeface getFontFaceByWM()
  {
    return Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/WATER_MARK_FONT.ttf");
  }

  public static Typeface getFontFaceImpact()
  {
    return Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf");
  }

  private static String getNumFit(String paramString)
  {
    String str = "";
    int i = paramString.length();
    for (int j = 0; j < i; j++)
    {
      int k = Integer.valueOf(paramString.substring(j, j + 1)).intValue();
      str = str + String.valueOf(BaseApplication.typeFaceList[k]);
    }
    return str;
  }

  public static void onTextChange(FitInterfaceUtils.onTextChangeListener paramonTextChangeListener, EditText paramEditText)
  {
    if ((paramEditText == null) || (paramonTextChangeListener == null))
    {
      LogUtils.e("TextUtils", "onTextChange() 方法参数为空");
      return;
    }
    paramEditText.addTextChangedListener(new TextWatcher(paramEditText, paramonTextChangeListener)
    {
      public void afterTextChanged(Editable paramEditable)
      {
        String str = this.val$editText.getText().toString();
        this.val$listener.onChangeResult(str);
      }

      public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
      {
      }

      public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
      {
      }
    });
  }

  public static String replacePointSize(String paramString)
  {
    return paramString.replaceAll("·", "•");
  }

  public static void setEditAlpha(EditText paramEditText, TextInputLayout paramTextInputLayout)
  {
    paramEditText.setOnFocusChangeListener(new View.OnFocusChangeListener(paramTextInputLayout, paramEditText)
    {
      @Instrumented
      public void onFocusChange(View paramView, boolean paramBoolean)
      {
        VdsAgent.onFocusChange(this, paramView, paramBoolean);
        if (paramBoolean)
        {
          this.val$textInputLayout.setAlpha(1.0F);
          return;
        }
        if (StringUtils.isNull(this.val$editText.getText().toString()))
        {
          this.val$textInputLayout.setAlpha(0.26F);
          return;
        }
        this.val$textInputLayout.setAlpha(1.0F);
      }
    });
  }

  public static void setFontFaceText(TextView paramTextView, String paramString)
  {
    paramTextView.setText(getNumFit(paramString));
    paramTextView.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/FIT_FONT.ttf"));
  }

  public static void setMedalTrainNumber(TextView paramTextView, String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int i = 0; i < paramString.length(); i++)
      localStringBuilder.append(BaseApplication.typeFaceList[Integer.valueOf(paramString.substring(i, i + 1)).intValue()]);
    paramTextView.setTypeface(getFontFace());
    paramTextView.setText(localStringBuilder.toString());
  }

  public static void setRightDraw(Context paramContext, TextView paramTextView)
  {
    Drawable localDrawable = ContextCompat.getDrawable(paramContext, R.mipmap.more_icon);
    localDrawable.setBounds(0, 0, localDrawable.getMinimumWidth(), localDrawable.getMinimumHeight());
    paramTextView.setCompoundDrawables(null, null, localDrawable, null);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.compdevicemanager.TextUtils
 * JD-Core Version:    0.6.0
 */