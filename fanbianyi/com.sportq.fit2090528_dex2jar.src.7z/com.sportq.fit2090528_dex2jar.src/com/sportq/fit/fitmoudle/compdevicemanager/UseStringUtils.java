package com.sportq.fit.fitmoudle.compdevicemanager;

import android.content.Context;
import android.content.res.Resources;
import com.sportq.fit.common.BaseApplication;

public class UseStringUtils
{
  public static String getStr(int paramInt)
  {
    return getStr(BaseApplication.appliContext, paramInt, new String[] { "" });
  }

  public static String getStr(int paramInt, String[] paramArrayOfString)
  {
    return getStr(BaseApplication.appliContext, paramInt, paramArrayOfString);
  }

  @Deprecated
  public static String getStr(Context paramContext, int paramInt)
  {
    return getStr(paramContext, paramInt, new String[] { "" });
  }

  public static String getStr(Context paramContext, int paramInt, String[] paramArrayOfString)
  {
    String str1 = paramContext.getResources().getString(paramInt);
    if ((paramArrayOfString != null) && (paramArrayOfString.length > 0) && (str1.contains("%1$s")))
    {
      int i = 0;
      if (i < paramArrayOfString.length)
      {
        String str2 = "%" + (i + 1) + "$s";
        String str3 = paramArrayOfString[i];
        if (str3 == null);
        while (true)
        {
          i++;
          break;
          str1 = str1.replace(str2, str3);
        }
      }
    }
    return str1;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils
 * JD-Core Version:    0.6.0
 */