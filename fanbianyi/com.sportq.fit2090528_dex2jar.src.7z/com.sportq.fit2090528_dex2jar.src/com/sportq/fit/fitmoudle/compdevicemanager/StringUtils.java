package com.sportq.fit.fitmoudle.compdevicemanager;

import android.content.Context;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.fitmoudle.network.data.CoursePhotoData;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class StringUtils extends com.sportq.fit.common.utils.StringUtils
{
  public static void appendCourseData(String paramString, Context paramContext)
  {
    if (com.sportq.fit.common.utils.StringUtils.isNull(paramString))
      return;
    String[] arrayOfString = paramString.split("±");
    if (arrayOfString.length > 0);
    for (String str1 = arrayOfString[0]; com.sportq.fit.common.utils.StringUtils.isNull(str1); str1 = "")
    {
      String str3 = SharePreferenceUtils.getPublishExistTag(paramContext);
      SharePreferenceUtils.putPublishExistTag(paramContext, paramString + "Δ" + str3);
      return;
    }
    CoursePhotoData localCoursePhotoData = getAlbumCoursePhotosData(str1, paramContext);
    if ((localCoursePhotoData != null) && (!com.sportq.fit.common.utils.StringUtils.isNull(localCoursePhotoData.strMoveTime)))
      delAlbumCoursePhotoData(str1, paramContext);
    String str2 = SharePreferenceUtils.getPublishExistTag(paramContext);
    SharePreferenceUtils.putPublishExistTag(paramContext, paramString + "Δ" + str2);
  }

  private static CoursePhotoData convertData(String paramString)
  {
    CoursePhotoData localCoursePhotoData = new CoursePhotoData();
    try
    {
      String[] arrayOfString = paramString.split("±");
      if (arrayOfString.length < 13)
        return null;
      localCoursePhotoData.strMoveTime = arrayOfString[0];
      localCoursePhotoData.strTrainName = arrayOfString[1];
      localCoursePhotoData.strTrainInfo = arrayOfString[2];
      localCoursePhotoData.strPlanId = arrayOfString[3];
      localCoursePhotoData.individualId = arrayOfString[4];
      localCoursePhotoData.wmfOlapinfo = arrayOfString[5];
      localCoursePhotoData.posterOlapinfo = arrayOfString[6];
      localCoursePhotoData.strImageType = arrayOfString[7];
      localCoursePhotoData.strImgPath = arrayOfString[8];
      localCoursePhotoData.feeling = arrayOfString[9];
      localCoursePhotoData.bodyDirection = arrayOfString[10];
      localCoursePhotoData.currentWeight = arrayOfString[11];
      localCoursePhotoData.strPubType = arrayOfString[12];
      if (arrayOfString.length > 13)
        localCoursePhotoData.punchDays = arrayOfString[13];
      if (arrayOfString.length > 14)
      {
        localCoursePhotoData.continuousDays = arrayOfString[14];
        return localCoursePhotoData;
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return localCoursePhotoData;
  }

  public static void delAlbumCoursePhotoData(String paramString, Context paramContext)
  {
    String str1 = SharePreferenceUtils.getPublishExistTag(paramContext);
    if (com.sportq.fit.common.utils.StringUtils.isNull(str1));
    String[] arrayOfString;
    while (true)
    {
      return;
      if ("-1".equals(paramString))
      {
        SharePreferenceUtils.putPublishExistTag(paramContext, "");
        return;
      }
      arrayOfString = str1.split("Δ");
      if (arrayOfString.length > 0)
        break;
      CoursePhotoData localCoursePhotoData2 = convertData(str1);
      if ((localCoursePhotoData2 != null) && (!localCoursePhotoData2.strMoveTime.equals(paramString)))
        continue;
      SharePreferenceUtils.putPublishExistTag(paramContext, "");
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    int i = arrayOfString.length;
    int j = 0;
    if (j < i)
    {
      String str2 = arrayOfString[j];
      CoursePhotoData localCoursePhotoData1 = convertData(str2);
      if ((localCoursePhotoData1 == null) || (localCoursePhotoData1.strMoveTime.equals(paramString)));
      while (true)
      {
        j++;
        break;
        localStringBuilder.append(str2);
        localStringBuilder.append("Δ");
      }
    }
    SharePreferenceUtils.putPublishExistTag(paramContext, localStringBuilder.toString());
  }

  public static CoursePhotoData getAlbumCoursePhotosData(String paramString, Context paramContext)
  {
    String str = SharePreferenceUtils.getPublishExistTag(paramContext);
    CoursePhotoData localCoursePhotoData1;
    if ((com.sportq.fit.common.utils.StringUtils.isNull(str)) || (com.sportq.fit.common.utils.StringUtils.isNull(paramString)))
    {
      localCoursePhotoData1 = null;
      return localCoursePhotoData1;
    }
    while (true)
    {
      int j;
      try
      {
        String[] arrayOfString = str.split("Δ");
        if (arrayOfString.length <= 0)
          continue;
        localCoursePhotoData1 = new CoursePhotoData();
        int i = arrayOfString.length;
        j = 0;
        if (j >= i)
          break;
        CoursePhotoData localCoursePhotoData2 = convertData(arrayOfString[j]);
        if (localCoursePhotoData2 != null)
        {
          if ("-1".equals(paramString))
            return localCoursePhotoData2;
          if (paramString.equals(localCoursePhotoData2.strMoveTime))
          {
            return localCoursePhotoData2;
            CoursePhotoData localCoursePhotoData3 = convertData(str);
            return localCoursePhotoData3;
          }
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return null;
      }
      j++;
    }
  }

  public static ArrayList<CoursePhotoData> getAlbumCoursePhotosData(Context paramContext)
  {
    String str = SharePreferenceUtils.getPublishExistTag(paramContext);
    ArrayList localArrayList;
    if (com.sportq.fit.common.utils.StringUtils.isNull(str))
    {
      localArrayList = null;
      return localArrayList;
    }
    while (true)
    {
      int j;
      try
      {
        String[] arrayOfString = str.split("Δ");
        localArrayList = new ArrayList();
        if (arrayOfString.length > 0)
        {
          int i = arrayOfString.length;
          j = 0;
          if (j >= i)
            break;
          CoursePhotoData localCoursePhotoData2 = convertData(arrayOfString[j]);
          if (localCoursePhotoData2 == null)
            break label110;
          localArrayList.add(localCoursePhotoData2);
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return null;
      }
      CoursePhotoData localCoursePhotoData1 = convertData(str);
      if (localCoursePhotoData1 == null)
        break;
      localArrayList.add(localCoursePhotoData1);
      return localArrayList;
      label110: j++;
    }
  }

  public static String getM(double paramDouble)
  {
    double d = paramDouble / 1024.0D;
    return new DecimalFormat("######0.00").format(d);
  }

  public static String getTrainDuration(int paramInt)
  {
    return String.valueOf((int)Math.ceil(paramInt / 60.0D));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.compdevicemanager.StringUtils
 * JD-Core Version:    0.6.0
 */