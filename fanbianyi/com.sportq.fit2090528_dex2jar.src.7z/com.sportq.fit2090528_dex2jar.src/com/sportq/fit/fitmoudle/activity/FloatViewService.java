package com.sportq.fit.fitmoudle.activity;

import android.annotation.SuppressLint;
import android.app.Application;
import android.app.Service;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.LinearLayout;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;

public class FloatViewService extends Service
{
  private static final String TAG = "FloatViewService";
  private LinearLayout mFloatLayout;
  private LinearLayout mFloatView;
  private WindowManager mWindowManager;
  private int rawX;
  private int rawY;
  private WindowManager.LayoutParams wmParams;

  @SuppressLint({"InflateParams"})
  private void createFloatView()
  {
    this.wmParams = new WindowManager.LayoutParams();
    Application localApplication = getApplication();
    getApplication();
    this.mWindowManager = ((WindowManager)localApplication.getSystemService("window"));
    WindowManager.LayoutParams localLayoutParams = this.wmParams;
    if (Build.VERSION.SDK_INT >= 26);
    for (int i = 2038; ; i = 2002)
    {
      localLayoutParams.type = i;
      this.wmParams.format = 1;
      this.wmParams.flags = 8;
      this.wmParams.gravity = 85;
      this.wmParams.x = 50;
      this.wmParams.y = 152;
      this.wmParams.width = -2;
      this.wmParams.height = -2;
      this.mFloatLayout = ((LinearLayout)LayoutInflater.from(getApplication()).inflate(R.layout.alert_window_menu, null));
      this.mWindowManager.addView(this.mFloatLayout, this.wmParams);
      this.mFloatView = ((LinearLayout)this.mFloatLayout.findViewById(R.id.alert_window_imagebtn));
      this.mFloatLayout.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
      this.mFloatView.setOnTouchListener(new View.OnTouchListener()
      {
        boolean isClick;

        @SuppressLint({"ClickableViewAccessibility"})
        public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
        {
          switch (paramMotionEvent.getAction())
          {
          default:
          case 0:
          case 2:
            int i;
            int j;
            do
            {
              return false;
              FloatViewService.access$002(FloatViewService.this, (int)paramMotionEvent.getRawX());
              FloatViewService.access$102(FloatViewService.this, (int)paramMotionEvent.getRawY());
              this.isClick = false;
              return false;
              i = Math.abs(FloatViewService.this.rawX - (int)paramMotionEvent.getRawX());
              j = Math.abs(FloatViewService.this.rawY - (int)paramMotionEvent.getRawY());
            }
            while ((i < 20) && (j < 20));
            this.isClick = true;
            FloatViewService.this.wmParams.x = (BaseApplication.screenWidth - (int)paramMotionEvent.getRawX() - FloatViewService.this.mFloatView.getMeasuredWidth() / 2);
            FloatViewService.this.wmParams.y = (BaseApplication.screenHeight - (int)paramMotionEvent.getRawY() - FloatViewService.this.mFloatView.getMeasuredHeight() / 2);
            FloatViewService.this.mWindowManager.updateViewLayout(FloatViewService.this.mFloatLayout, FloatViewService.this.wmParams);
            return true;
          case 1:
          }
          return this.isClick;
        }
      });
      this.mFloatView.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          Intent localIntent = new Intent(FloatViewService.this, FitConsoleActivity.class);
          localIntent.setFlags(268435456);
          FloatViewService.this.startActivity(localIntent);
        }
      });
      return;
    }
  }

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public void onCreate()
  {
    super.onCreate();
    Log.i("FloatViewService", "onCreate");
    createFloatView();
  }

  public void onDestroy()
  {
    super.onDestroy();
    if (this.mFloatLayout != null)
      this.mWindowManager.removeView(this.mFloatLayout);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.activity.FloatViewService
 * JD-Core Version:    0.6.0
 */