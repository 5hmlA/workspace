package com.sportq.fit.fitmoudle.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.TestUtils;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout;
import com.sportq.fit.fitmoudle.widget.fitconsoleview.FitInfoView;
import com.sportq.fit.fitmoudle.widget.fitconsoleview.FitIntentView;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;
import java.util.ArrayList;

public class FitConsoleActivity extends BaseActivity
{
  CustomTabLayout customTabLayout;
  private FitInfoView fitInfoView;
  private FitIntentView fitIntentView;
  private ArrayList<View> viewList = new ArrayList();
  ViewPager viewPager;

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.clear_view)
    {
      this.fitInfoView.clearData();
      this.fitIntentView.clearData();
      TestUtils.getInstance().clear();
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() != R.id.hint_view)
        continue;
      finish();
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.fit_console_layout);
    WindowManager.LayoutParams localLayoutParams = getWindow().getAttributes();
    localLayoutParams.width = BaseApplication.screenWidth;
    localLayoutParams.height = (int)(0.8D * BaseApplication.screenHeight);
    localLayoutParams.gravity = 80;
    getWindow().setAttributes(localLayoutParams);
    String[] arrayOfString = { "info", "intent" };
    this.customTabLayout = ((CustomTabLayout)findViewById(R.id.custom_tab_layout));
    this.viewPager = ((ViewPager)findViewById(R.id.view_pager));
    findViewById(R.id.clear_view).setOnClickListener(new FitAction(this));
    findViewById(R.id.hint_view).setOnClickListener(new FitAction(this));
    this.fitInfoView = new FitInfoView(this);
    this.fitIntentView = new FitIntentView(this);
    this.viewList.add(this.fitInfoView);
    this.viewList.add(this.fitIntentView);
    this.viewPager.setAdapter(new CustomViewPagerAdapter(this.viewList));
    this.viewPager.addOnPageChangeListener(new FitConsoleChangeListener(null));
    this.customTabLayout.setViewPager(this.viewPager, arrayOfString);
    this.fitInfoView.setData();
    this.viewPager.setCurrentItem(0);
  }

  private class FitConsoleChangeListener
    implements ViewPager.OnPageChangeListener
  {
    private FitConsoleChangeListener()
    {
    }

    public void onPageScrollStateChanged(int paramInt)
    {
    }

    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
    {
    }

    public void onPageSelected(int paramInt)
    {
      switch (paramInt)
      {
      default:
        return;
      case 0:
        FitConsoleActivity.this.fitInfoView.setData();
        return;
      case 1:
      }
      FitConsoleActivity.this.fitIntentView.setData();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.activity.FitConsoleActivity
 * JD-Core Version:    0.6.0
 */