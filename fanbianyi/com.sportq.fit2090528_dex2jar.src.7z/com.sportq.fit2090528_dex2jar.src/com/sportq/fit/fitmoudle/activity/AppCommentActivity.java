package com.sportq.fit.fitmoudle.activity;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.superView.RLinearLayout;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.uicommon.R.color;
import com.sportq.fit.uicommon.R.drawable;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;
import com.sportq.fit.uicommon.R.string;
import org.greenrobot.eventbus.EventBus;

public class AppCommentActivity extends BaseActivity
{
  View decorView;
  private boolean isClickComment = false;
  private boolean isToComment = false;

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.app_comment_dialog_layout);
    this.decorView = getWindow().getDecorView();
    getWindow().setBackgroundDrawable(new ColorDrawable(0));
    this.decorView.setBackgroundResource(R.drawable.checkeditionhint);
    WindowManager.LayoutParams localLayoutParams = getWindow().getAttributes();
    localLayoutParams.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
    getWindow().setAttributes(localLayoutParams);
    RLinearLayout localRLinearLayout = (RLinearLayout)findViewById(R.id.comment_layout);
    RTextView localRTextView1 = (RTextView)findViewById(R.id.app_to_comment);
    RTextView localRTextView2 = (RTextView)findViewById(R.id.to_feedback);
    RTextView localRTextView3 = (RTextView)findViewById(R.id.remind_me_later);
    TextView localTextView = (TextView)findViewById(R.id.app_comment_hint);
    SpannableString localSpannableString = new SpannableString(getString(R.string.z_3_1) + getString(R.string.z_3_2));
    localSpannableString.setSpan(new StyleSpan(1), 0, localSpannableString.length(), 33);
    localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(this, R.color.color_ff6a49)), -9 + localSpannableString.length(), localSpannableString.length(), 33);
    localTextView.setText(localSpannableString);
    localRTextView1.setOnClickListener(new View.OnClickListener(localRLinearLayout)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        AppCommentActivity.access$002(AppCommentActivity.this, true);
        if (this.val$comment_layout != null)
        {
          AppCommentActivity.this.decorView.setBackgroundResource(R.color.transparent);
          AppCommentActivity.this.decorView.setVisibility(4);
          this.val$comment_layout.setVisibility(8);
        }
        MiddleManager.getInstance().getFindPresenterImpl(null, null).gradeToastClick(AppCommentActivity.this, Constant.STR_1);
        Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + AppCommentActivity.this.getPackageName()));
        try
        {
          AppCommentActivity.this.startActivity(localIntent);
          return;
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
        }
      }
    });
    localRTextView2.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.commentFlag = "1";
        MiddleManager.getInstance().getMinePresenterImpl(AppCommentActivity.this).storeComment(AppCommentActivity.this, localRequestModel);
        MiddleManager.getInstance().getFindPresenterImpl(null, null).gradeToastClick(AppCommentActivity.this, Constant.STR_1);
        FitJumpImpl.getInstance().settingJumpFeedBack(AppCommentActivity.this);
        AppCommentActivity.this.finish();
      }
    });
    localRTextView3.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        MiddleManager.getInstance().getFindPresenterImpl(null, null).gradeToastClick(AppCommentActivity.this, Constant.STR_0);
        AppCommentActivity.this.finish();
      }
    });
    EventBus.getDefault().post("app.comment");
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      MiddleManager.getInstance().getFindPresenterImpl(null, null).gradeToastClick(this, Constant.STR_0);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  protected void onResume()
  {
    super.onResume();
    if (this.isToComment)
      EventBus.getDefault().post("to.store.comment");
    if (this.isClickComment)
      finish();
  }

  protected void onStop()
  {
    super.onStop();
    if (this.isClickComment)
    {
      this.isToComment = true;
      return;
    }
    finish();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.activity.AppCommentActivity
 * JD-Core Version:    0.6.0
 */