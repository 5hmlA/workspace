package com.sportq.fit.fitmoudle.activity;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.VipHistReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.adapter.VipHistAdapter;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.uicommon.R.color;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;
import com.sportq.fit.uicommon.R.mipmap;
import com.sportq.fit.uicommon.R.string;
import java.util.ArrayList;

public class VipHistActivity extends BaseActivity
{
  TextView empty_hint;
  ImageView empty_icon;
  LinearLayout empty_layout;
  RecyclerView recyclerView;
  CustomToolBar toolBar;

  private void initData()
  {
    this.dialog = new DialogManager();
    this.toolBar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.toolBar.setNavIcon(R.mipmap.btn_back_black);
    this.toolBar.setAppTitle(getString(R.string.c_86_1_1));
    this.toolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolBar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolBar);
    this.empty_layout = ((LinearLayout)findViewById(R.id.empty_layout));
    this.empty_hint = ((TextView)findViewById(R.id.empty_hint));
    this.empty_icon = ((ImageView)findViewById(R.id.empty_icon));
    this.recyclerView = ((RecyclerView)findViewById(R.id.vip_record_recyclerView));
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    VipHistReformer localVipHistReformer;
    if ((paramT instanceof VipHistReformer))
    {
      localVipHistReformer = (VipHistReformer)paramT;
      if ((localVipHistReformer.lstVipHist == null) || (localVipHistReformer.lstVipHist.size() == 0))
      {
        this.empty_layout.setVisibility(0);
        this.recyclerView.setVisibility(8);
        this.empty_hint.setText("从2018年7月10日开始记录\n你还没有新交易哦～");
        this.empty_icon.setImageResource(R.mipmap.icn_trading_record_default);
      }
    }
    else
    {
      return;
    }
    this.recyclerView.setVisibility(0);
    this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
    this.empty_layout.setVisibility(8);
    VipHistAdapter localVipHistAdapter = new VipHistAdapter(this, localVipHistReformer.lstVipHist, R.layout.vip_hist_item_layout);
    this.recyclerView.setAdapter(localVipHistAdapter);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.vip_hist_layout);
    initData();
    if (CompDeviceInfoUtils.checkNetwork())
    {
      this.dialog.createProgressDialog(this, "请稍后...");
      MiddleManager.getInstance().getMinePresenterImpl(this).getVipHist(this, new RequestModel());
      return;
    }
    ToastUtils.makeToast(this, getResources().getString(R.string.link_failure_hint));
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.activity.VipHistActivity
 * JD-Core Version:    0.6.0
 */