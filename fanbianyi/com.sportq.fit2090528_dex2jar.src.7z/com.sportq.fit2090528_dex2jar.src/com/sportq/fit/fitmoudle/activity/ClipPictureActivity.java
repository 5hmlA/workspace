package com.sportq.fit.fitmoudle.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.ImageUtils.OnSaveImgListener;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;
import com.sportq.fit.uicommon.R.menu;
import com.sportq.fit.uicommon.R.mipmap;
import java.util.Arrays;

public class ClipPictureActivity extends BaseActivity
  implements View.OnTouchListener
{
  private static final int DRAG = 1;
  private static final int NONE = 0;
  private static final int ZOOM = 2;
  private int clipImgHeight;
  private ImageView clip_image;
  private float[] mMatrixValues = new float[9];
  private Matrix matrix = new Matrix();
  private PointF mid = new PointF();
  private int mode = 0;
  private float oldDist = 1.0F;
  private Matrix savedMatrix = new Matrix();
  private Bitmap showBitmap;
  private PointF start = new PointF();
  private String strPicturePath;
  private CustomToolBar toolbar;
  private float x1;
  private float x2;
  private float y2;

  private float calculateTransDistance()
  {
    float f = this.clipImgHeight / 2.0F;
    return (BaseApplication.screenHeight - CompDeviceInfoUtils.getStatusBarHeight(this)) / 2.0F - f;
  }

  private void clipImgAction()
  {
    float[] arrayOfFloat = new float[9];
    this.matrix.getValues(arrayOfFloat);
    Log.d("matrix :", Arrays.toString(arrayOfFloat));
    float f1 = arrayOfFloat[2];
    float f2 = arrayOfFloat[5];
    float f3 = Float.valueOf(String.valueOf(this.clip_image.getTag())).floatValue();
    int i = (int)(this.clipImgHeight * arrayOfFloat[0]);
    int j = (int)(BaseApplication.screenWidth * arrayOfFloat[0]);
    float f4;
    if (f2 > f3)
      f4 = f2;
    while (true)
    {
      int k = BaseApplication.screenWidth / 6;
      Bitmap localBitmap1;
      if ((f1 + j < k) || (f1 > BaseApplication.screenWidth - k) || (f2 + i < f3 + k) || (f2 > f3 + BaseApplication.screenWidth - k))
        localBitmap1 = getClipCenterSquareBitmap(this.showBitmap);
      try
      {
        1 local1 = new ImageUtils.OnSaveImgListener()
        {
          public void saveSuccess(String paramString)
          {
            ClipPictureActivity.access$002(ClipPictureActivity.this, paramString);
            Intent localIntent = new Intent();
            localIntent.putExtra("clip.image", ClipPictureActivity.this.strPicturePath);
            ClipPictureActivity.this.setResult(-1, localIntent);
            ClipPictureActivity.this.finish();
          }
        };
        ImageUtils.saveImgToAlbum(local1, localBitmap1, this);
        return;
        f4 = f3;
        continue;
        getBarHeight(this);
        float f5;
        label221: float f6;
        label265: Bitmap localBitmap2;
        int m;
        int n;
        if (f1 <= 0.0F)
        {
          f5 = f1 + j;
          if (f5 > BaseApplication.screenWidth)
            f5 = BaseApplication.screenWidth;
          if (f4 > f3)
            break label396;
          f6 = i - f3;
          if (f4 + f6 > f3 + BaseApplication.screenWidth)
            f6 = f3 + BaseApplication.screenWidth - f4;
          boolean bool3 = CompDeviceInfoUtils.isFullScreen(this);
          localBitmap2 = takeScreenShot();
          if (f1 < 0.0F)
            f1 = 0.0F;
          m = (int)f1;
          n = (int)f4 + this.statusBarHeight;
          if (!bool3)
            break label460;
        }
        label396: label460: for (int i1 = this.statusBarHeight / 2; ; i1 = 0)
        {
          localBitmap1 = getClipCenterSquareBitmap(Bitmap.createBitmap(localBitmap2, m, i1 + n, (int)f5, (int)f6 - this.statusBarHeight));
          break;
          if (f1 + j <= BaseApplication.screenWidth)
          {
            f5 = j;
            break label221;
          }
          boolean bool1 = f1 + j < BaseApplication.screenWidth;
          f5 = 0.0F;
          if (!bool1)
            break label221;
          f5 = BaseApplication.screenWidth - f1;
          break label221;
          if (f4 + i <= f3 + BaseApplication.screenWidth)
          {
            f6 = i;
            break label265;
          }
          boolean bool2 = f4 + i < f3 + BaseApplication.screenWidth;
          f6 = 0.0F;
          if (!bool2)
            break label265;
          f6 = f3 + BaseApplication.screenWidth - f4;
          break label265;
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
      }
    }
  }

  private Bitmap getClipCenterSquareBitmap(Bitmap paramBitmap)
  {
    int i = paramBitmap.getWidth();
    int j = paramBitmap.getHeight();
    Bitmap localBitmap = paramBitmap;
    int k;
    float f1;
    if (i != j)
    {
      if (i >= j)
        break label82;
      k = i;
      if (i >= j)
        break label88;
      f1 = 0.0F;
    }
    while (true)
    {
      float f2 = 0.0F;
      if (i < j)
        f2 = (float)(j / 2.0D - k / 2.0D);
      localBitmap = Bitmap.createBitmap(paramBitmap, (int)f1, (int)f2, k - 1, k - 1);
      return localBitmap;
      label82: k = j;
      break;
      label88: f1 = (float)(i / 2.0D - k / 2.0D);
    }
  }

  private void midPoint(PointF paramPointF, MotionEvent paramMotionEvent)
  {
    float f1 = paramMotionEvent.getX(0) + paramMotionEvent.getX(1);
    float f2 = paramMotionEvent.getY(0) + paramMotionEvent.getY(1);
    paramPointF.set(f1 / 2.0F, f2 / 2.0F);
  }

  private void showClipPicture()
  {
    this.strPicturePath = getIntent().getStringExtra("clip.img.path");
    if (StringUtils.isNull(this.strPicturePath))
      finish();
    this.showBitmap = ImageUtils.getImageBitmap(this.strPicturePath, 1);
    this.showBitmap = ImageUtils.handleCameraPhoto(this.showBitmap, this.strPicturePath);
    if (this.showBitmap == null)
    {
      finish();
      return;
    }
    this.toolbar.setNavIcon(-1);
    this.toolbar.setAppTitle("裁剪图片");
    setSupportActionBar(this.toolbar);
    float f = this.showBitmap.getWidth() / this.showBitmap.getHeight();
    int i = BaseApplication.screenWidth;
    this.clipImgHeight = (int)(BaseApplication.screenWidth / f);
    LogUtils.e("裁剪图片的宽度是：", String.valueOf(i));
    LogUtils.e("裁剪图片的高度是：", String.valueOf(this.clipImgHeight));
    this.showBitmap = ImageUtils.createBitmapBySize(this.showBitmap, i, this.clipImgHeight);
    this.clip_image.setImageBitmap(this.showBitmap);
    this.clip_image.setScaleType(ImageView.ScaleType.MATRIX);
    this.clip_image.setOnTouchListener(this);
    this.matrix.postTranslate(0.0F, calculateTransDistance());
    this.clip_image.setImageMatrix(this.matrix);
    this.clip_image.setTag(Integer.valueOf(BaseApplication.screenHeight / 2 - BaseApplication.screenWidth / 2));
  }

  private float spacing(MotionEvent paramMotionEvent)
  {
    float f1 = paramMotionEvent.getX(0) - paramMotionEvent.getX(1);
    float f2 = paramMotionEvent.getY(0) - paramMotionEvent.getY(1);
    return (float)Math.sqrt(f1 * f1 + f2 * f2);
  }

  public void fitOnClick(View paramView)
  {
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.clip_picture);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.clip_image = ((ImageView)findViewById(R.id.clip_image));
    showClipPicture();
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(R.menu.menu_mine02_notice_clear, paramMenu);
    paramMenu.findItem(R.id.action_clear).setTitle("确定");
    paramMenu.findItem(R.id.action_clear).setIcon(R.mipmap.icon_done);
    return super.onCreateOptionsMenu(paramMenu);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (16908332 == paramMenuItem.getItemId())
      finish();
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      if (R.id.action_clear != paramMenuItem.getItemId())
        continue;
      clipImgAction();
    }
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    ImageView localImageView = (ImageView)paramView;
    switch (0xFF & paramMotionEvent.getAction())
    {
    case 3:
    case 4:
    default:
    case 0:
    case 5:
    case 1:
    case 6:
    case 2:
    }
    while (true)
    {
      localImageView.setImageMatrix(this.matrix);
      return true;
      this.x1 = paramMotionEvent.getX();
      this.savedMatrix.set(this.matrix);
      this.start.set(paramMotionEvent.getX(), paramMotionEvent.getY());
      this.mode = 1;
      continue;
      this.oldDist = spacing(paramMotionEvent);
      if (this.oldDist <= 10.0F)
        continue;
      this.savedMatrix.set(this.matrix);
      midPoint(this.mid, paramMotionEvent);
      this.mode = 2;
      continue;
      this.mode = 0;
      if (((Math.abs(this.x1 - this.x2) < 3.0F) || (this.x2 == 0.0F) || (this.y2 == 0.0F)) && ((Math.abs(this.x1 - this.x2) != 0.0F) || (this.x2 != 0.0F) || (this.y2 != 0.0F)))
      {
        this.x1 = 0.0F;
        this.x2 = 0.0F;
        this.y2 = 0.0F;
        return false;
      }
      this.x1 = 0.0F;
      this.x2 = 0.0F;
      this.y2 = 0.0F;
      return true;
      this.x2 = paramMotionEvent.getX();
      this.y2 = paramMotionEvent.getY();
      if (this.mode == 1)
      {
        this.matrix.set(this.savedMatrix);
        this.matrix.postTranslate(paramMotionEvent.getX() - this.start.x, paramMotionEvent.getY() - this.start.y);
        continue;
      }
      if (this.mode != 2)
        continue;
      this.matrix.getValues(this.mMatrixValues);
      float f1 = this.mMatrixValues[0];
      float f2 = spacing(paramMotionEvent);
      float f3 = f2 / this.oldDist;
      if (((f1 < 0.7D) && (f3 < 1.0F)) || (f2 <= 10.0F))
        continue;
      this.matrix.set(this.savedMatrix);
      this.matrix.postScale(f3, f3, this.mid.x, this.mid.y);
    }
  }

  protected Bitmap takeScreenShot()
  {
    View localView = getWindow().getDecorView();
    localView.setDrawingCacheEnabled(true);
    localView.buildDrawingCache();
    return localView.getDrawingCache();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.activity.ClipPictureActivity
 * JD-Core Version:    0.6.0
 */