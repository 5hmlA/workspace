package com.sportq.fit.fitmoudle.activity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.collection.GrowingIO;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.logic.JDPayHandler;
import com.sportq.fit.common.logic.payutil.AlipayHandler;
import com.sportq.fit.common.logic.payutil.HuaweiPayHandler;
import com.sportq.fit.common.logic.payutil.OnPayListener;
import com.sportq.fit.common.logic.payutil.WechatPayHandler;
import com.sportq.fit.common.logic.payutil.WechatPayHandler.OnGetOrderIdListener;
import com.sportq.fit.common.model.JDPayResultModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.VipCommodityEntity;
import com.sportq.fit.common.model.VipCommodityItemEntity;
import com.sportq.fit.common.model.WelcomeModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.VipCommodityReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CustomerServiceUtils;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RLinearLayout;
import com.sportq.fit.common.utils.superView.RRelativeLayout;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RBaseHelper;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.adapter.VipPrivilegeAdapter;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.ReceiveMedalEvent;
import com.sportq.fit.fitmoudle.event.VipServiceEvent;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.CustomScrollView;
import com.sportq.fit.fitmoudle.widget.CustomScrollView.ScrollViewListener;
import com.sportq.fit.fitmoudle.widget.FitVipUserView;
import com.sportq.fit.fitmoudle.widget.VipNoScrollGridView;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior;
import com.sportq.fit.middlelib.statistics.GrowingIOVariables;
import com.sportq.fit.uicommon.R.anim;
import com.sportq.fit.uicommon.R.color;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;
import com.sportq.fit.uicommon.R.mipmap;
import com.sportq.fit.uicommon.R.string;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class VipCenterActivity extends BaseActivity
  implements OnPayListener, WechatPayHandler.OnGetOrderIdListener
{
  private VipPrivilegeAdapter adapter;
  private AlipayHandler alipayHandler;
  private ImageView back_layout;
  private FrameLayout bottom_bar_layout;
  private TextView buy_vip_btn;
  private RRelativeLayout defaultSelVipLayout;
  private VipNoScrollGridView grid_view;
  private HuaweiPayHandler huaweiPayHandler;
  private JDPayHandler jdPayHandler;
  private ImageView jd_select_icon;
  private ProgressBar loader_icon;
  private TextView mine_fragment_name;
  private int payType;
  private TextView pay_comment;
  private TextView pay_money_hint;
  private CustomScrollView scrollview;
  private VipCommodityItemEntity selVipCommoItemEntity;
  private ImageView service_layout;
  private String strVipJDOrderId;
  private String strVipOrderId;
  private FrameLayout title_layout;
  private FitVipUserView user_icon;
  private TextView user_info_hint;
  private ImageView vipHist_layout;
  private WelcomeModel vipWelcomeModel;
  private ImageView vip_ad_img;
  private FrameLayout vip_ad_layout;
  private LinearLayout vip_body_layout;
  private LinearLayout vip_linear_layout;
  private LinearLayout vip_privilege_parent_layout;
  private TextView vip_title;
  private View vip_title_line;
  private RLinearLayout vip_wechat_layout;
  private WechatPayHandler wechatPayHandler;
  private ImageView wechat_select_icon;
  private ImageView zhifubao_select_icon;

  private String getVipDesc()
  {
    String str = "";
    if ((this.user_icon.getIsVip() == 1) || (this.user_icon.getIsVip() == 2))
      if (!StringUtils.isNull(BaseApplication.userModel.vipEndComment))
        str = "VIP会员 " + BaseApplication.userModel.vipEndComment;
    do
      while (true)
      {
        return str;
        if (!"1".equals(BaseApplication.userModel.isBuyVip))
          break;
        if (!StringUtils.isNull(BaseApplication.userModel.vipEndComment))
          return getResources().getString(R.string.c_1_2_1) + BaseApplication.userModel.vipEndComment;
      }
    while (StringUtils.isNull(BaseApplication.userModel.privilegeComment));
    return BaseApplication.userModel.privilegeComment;
  }

  private void initView()
  {
    this.dialog = new DialogManager();
    this.title_layout = ((FrameLayout)findViewById(R.id.title_layout));
    this.back_layout = ((ImageView)findViewById(R.id.back_layout));
    this.back_layout.setOnClickListener(new FitAction(this));
    this.service_layout = ((ImageView)findViewById(R.id.service_layout));
    this.service_layout.setOnClickListener(new FitAction(this));
    this.vipHist_layout = ((ImageView)findViewById(R.id.vipHist_layout));
    this.vipHist_layout.setOnClickListener(new FitAction(this));
    this.vip_title = ((TextView)findViewById(R.id.vip_title));
    this.vip_title_line = findViewById(R.id.vip_title_line);
    this.vip_wechat_layout = ((RLinearLayout)findViewById(R.id.vip_wechat_layout));
    this.vip_wechat_layout.setOnClickListener(new FitAction(this));
    this.bottom_bar_layout = ((FrameLayout)findViewById(R.id.bottom_bar_layout));
    this.user_info_hint = ((TextView)findViewById(R.id.user_info_hint));
    this.pay_comment = ((TextView)findViewById(R.id.pay_comment));
    this.mine_fragment_name = ((TextView)findViewById(R.id.mine_fragment_name));
    this.user_icon = ((FitVipUserView)findViewById(R.id.user_icon));
    this.vip_linear_layout = ((LinearLayout)findViewById(R.id.vip_linear_layout));
    this.vip_privilege_parent_layout = ((LinearLayout)findViewById(R.id.vip_privilege_parent_layout));
    this.vip_ad_layout = ((FrameLayout)findViewById(R.id.vip_ad_layout));
    this.vip_ad_img = ((ImageView)findViewById(R.id.vip_ad_img));
    this.pay_money_hint = ((TextView)findViewById(R.id.pay_money_hint));
    this.buy_vip_btn = ((TextView)findViewById(R.id.buy_vip_btn));
    this.buy_vip_btn.setOnClickListener(new FitAction(this));
    LinearLayout localLinearLayout = (LinearLayout)findViewById(R.id.pay_layout);
    this.scrollview = ((CustomScrollView)findViewById(R.id.scrollview));
    ((RelativeLayout)findViewById(R.id.zhifubao_layout)).setOnClickListener(new FitAction(this));
    ((RelativeLayout)findViewById(R.id.wechat_layout)).setOnClickListener(new FitAction(this));
    ((RelativeLayout)findViewById(R.id.jd_layout)).setOnClickListener(new FitAction(this));
    this.zhifubao_select_icon = ((ImageView)findViewById(R.id.zhifubao_select_icon));
    this.wechat_select_icon = ((ImageView)findViewById(R.id.wechat_select_icon));
    this.jd_select_icon = ((ImageView)findViewById(R.id.jd_select_icon));
    this.vip_body_layout = ((LinearLayout)findViewById(R.id.vip_body_layout));
    this.grid_view = ((VipNoScrollGridView)findViewById(R.id.grid_view));
    ((RelativeLayout)findViewById(R.id.vip_privilege_title_layout)).setOnClickListener(new FitAction(this));
    ((RelativeLayout)findViewById(R.id.vip_agreement_layout)).setOnClickListener(new FitAction(this));
    this.loader_icon = ((ProgressBar)findViewById(R.id.loader_icon));
    this.jdPayHandler = new JDPayHandler(this, this);
    this.jdPayHandler.setPayType("3");
    this.alipayHandler = new AlipayHandler(this);
    this.alipayHandler.setPayType("3");
    this.wechatPayHandler = new WechatPayHandler(this, this);
    this.wechatPayHandler.setPayType("3");
    this.huaweiPayHandler = new HuaweiPayHandler(this, this);
    this.huaweiPayHandler.setPayType("3");
    setUserVipInfo();
    if (CompDeviceInfoUtils.isHuaweiChannel());
    for (int i = 8; ; i = 0)
    {
      localLinearLayout.setVisibility(i);
      return;
    }
  }

  private void payAction()
  {
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.commodityId = this.selVipCommoItemEntity.commodityId;
    localRequestModel.quantity = "1";
    String str = StringUtils.convertPrice02(this.selVipCommoItemEntity.price);
    localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.selVipCommoItemEntity.commodityId + NdkUtils.getSignBaseUrl()).toUpperCase();
    localRequestModel.callType = "3";
    if (CompDeviceInfoUtils.isHuaweiChannel())
    {
      localRequestModel.totalPrice = str;
      this.huaweiPayHandler.executeCallHuaweipay(localRequestModel);
      return;
    }
    switch (this.payType)
    {
    default:
      return;
    case 0:
      localRequestModel.aliJson = this.alipayHandler.getAlipayReqParams(str, null, "Fit VIP会员");
      this.alipayHandler.executeCallAlipay(this, localRequestModel);
      return;
    case 1:
      localRequestModel.totalPrice = str;
      this.wechatPayHandler.executeCallWechatPay(this, localRequestModel);
      return;
    case 2:
    }
    localRequestModel.totalPrice = str;
    this.jdPayHandler.executeCallJDPay(this, localRequestModel);
  }

  private void resetPaySelectorStatus()
  {
    this.zhifubao_select_icon.setImageResource(R.mipmap.btn_normal);
    this.wechat_select_icon.setImageResource(R.mipmap.btn_normal);
    this.jd_select_icon.setImageResource(R.mipmap.btn_normal);
  }

  private void setDataForPage(VipCommodityReformer paramVipCommodityReformer)
  {
    if (paramVipCommodityReformer == null)
      return;
    while (true)
    {
      VipCommodityItemEntity localVipCommodityItemEntity;
      RRelativeLayout localRRelativeLayout;
      ImageView localImageView1;
      try
      {
        if (this.vipWelcomeModel == null)
        {
          this.vip_ad_layout.setVisibility(8);
          if ((paramVipCommodityReformer.lstVipPrivilege == null) || (paramVipCommodityReformer.lstVipPrivilege.size() == 0))
            break label777;
          this.vip_privilege_parent_layout.setVisibility(0);
          this.adapter = new VipPrivilegeAdapter(this, paramVipCommodityReformer);
          this.grid_view.setAdapter(this.adapter);
          this.scrollview.smoothScrollTo(0, 0);
          this.scrollview.setScrollViewListener(new CustomScrollView.ScrollViewListener()
          {
            public void onScrollChanged(CustomScrollView paramCustomScrollView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
            {
              FrameLayout localFrameLayout1 = VipCenterActivity.this.title_layout;
              int i;
              float f;
              label58: String str;
              label102: int k;
              label127: int m;
              label152: ImageView localImageView3;
              if (paramInt2 > 0)
              {
                i = R.color.white;
                localFrameLayout1.setBackgroundResource(i);
                if (Build.VERSION.SDK_INT < 21)
                  break label225;
                FrameLayout localFrameLayout2 = VipCenterActivity.this.title_layout;
                if (paramInt2 <= 0)
                  break label219;
                f = CompDeviceInfoUtils.convertOfDip(VipCenterActivity.this, 3.0F);
                localFrameLayout2.setElevation(f);
                VipCenterActivity.this.vip_title_line.setVisibility(8);
                TextView localTextView = VipCenterActivity.this.vip_title;
                if (paramInt2 <= 0)
                  break label258;
                str = VipCenterActivity.this.getString(R.string.c_76_1_1);
                localTextView.setText(str);
                ImageView localImageView1 = VipCenterActivity.this.back_layout;
                if (paramInt2 <= 0)
                  break label265;
                k = R.mipmap.btn_back_black;
                localImageView1.setImageResource(k);
                ImageView localImageView2 = VipCenterActivity.this.vipHist_layout;
                if (paramInt2 <= 0)
                  break label273;
                m = R.mipmap.c_btn_detail_black;
                localImageView2.setImageResource(m);
                localImageView3 = VipCenterActivity.this.service_layout;
                if (paramInt2 <= 0)
                  break label281;
              }
              label258: label265: label273: label281: for (int n = R.mipmap.btn_custom_service; ; n = R.mipmap.btn_custom_service_white)
              {
                localImageView3.setImageResource(n);
                if ((paramInt2 != 0) && (Math.abs(paramInt2) / 300.0F < 1.0F))
                  break label289;
                VipCenterActivity.this.title_layout.setAlpha(1.0F);
                return;
                i = 0;
                break;
                label219: f = 0.0F;
                break label58;
                label225: View localView = VipCenterActivity.this.vip_title_line;
                int j = 0;
                if (paramInt2 > 0);
                while (true)
                {
                  localView.setVisibility(j);
                  break;
                  j = 8;
                }
                str = "";
                break label102;
                k = R.mipmap.btn_back_white;
                break label127;
                m = R.mipmap.c_btn_detail_white;
                break label152;
              }
              label289: VipCenterActivity.this.title_layout.setAlpha(Math.abs(paramInt2) / 300.0F);
            }
          });
          this.grid_view.setOnItemClickListener(new AdapterView.OnItemClickListener()
          {
            @Instrumented
            public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
            {
              VdsAgent.onItemClick(this, paramAdapterView, paramView, paramInt, paramLong);
              ArrayList localArrayList = VipCenterActivity.this.adapter.getLstVipPrivilege();
              if ((localArrayList != null) && (localArrayList.size() != 0) && (!StringUtils.isNull(((VipCommodityItemEntity)localArrayList.get(paramInt)).privilegeId)))
              {
                String str = VersionUpdateCheck.WEB_ADDRESS + "vip/vipTab?page=" + ((VipCommodityItemEntity)VipCenterActivity.this.adapter.getLstVipPrivilege().get(paramInt)).privilegeId;
                FitJumpImpl.getInstance().settingJumpWebView(VipCenterActivity.this, null, str);
              }
            }
          });
          if ((paramVipCommodityReformer.lstVipPackage == null) || (paramVipCommodityReformer.lstVipPackage.lstVipCommodity == null))
            break label1155;
          this.vip_linear_layout.removeAllViews();
          this.vip_linear_layout.setWeightSum(paramVipCommodityReformer.lstVipPackage.lstVipCommodity.size());
          Iterator localIterator = paramVipCommodityReformer.lstVipPackage.lstVipCommodity.iterator();
          if (!localIterator.hasNext())
            break label1155;
          localVipCommodityItemEntity = (VipCommodityItemEntity)localIterator.next();
          View localView = LayoutInflater.from(this).inflate(R.layout.vip_price_item, null);
          this.vip_linear_layout.addView(localView);
          ((TextView)localView.findViewById(R.id.vip_time_hint)).setText(localVipCommodityItemEntity.commodityTitle);
          TextView localTextView1 = (TextView)localView.findViewById(R.id.vip_price);
          localTextView1.setText(String.valueOf(localVipCommodityItemEntity.price));
          setVipPriceTextStyle(localTextView1);
          TextView localTextView2 = (TextView)localView.findViewById(R.id.vip_cheap_hint);
          localTextView2.setText(localVipCommodityItemEntity.commodityComment);
          if (!StringUtils.isNull(localVipCommodityItemEntity.commodityComment))
            break label1172;
          i = 4;
          localTextView2.setVisibility(i);
          localRRelativeLayout = (RRelativeLayout)localView.findViewById(R.id.vip_month_layout);
          localRRelativeLayout.getLayoutParams().width = (int)((BaseApplication.screenWidth - CompDeviceInfoUtils.convertOfDip(this, 66.0F)) / 3.0F);
          localImageView1 = (ImageView)localView.findViewById(R.id.vip_package_tag);
          ImageView localImageView2 = (ImageView)localView.findViewById(R.id.promotion_anim);
          ImageView localImageView3 = (ImageView)localView.findViewById(R.id.vip_active_img);
          RTextView localRTextView = (RTextView)localView.findViewById(R.id.vip_active_details);
          if (StringUtils.isNull(localVipCommodityItemEntity.downImageUrl))
            continue;
          localImageView3.setVisibility(0);
          localRTextView.setVisibility(4);
          localImageView3.setOnClickListener(new FitAction(this, localVipCommodityItemEntity)
          {
            @Instrumented
            public void onClick(View paramView)
            {
              VdsAgent.onClick(this, paramView);
              FitJumpImpl.getInstance().settingJumpWebView(VipCenterActivity.this, "", this.val$loopEntity.downUrl);
              super.onClick(paramView);
            }
          });
          GlideUtils.loadImgByAdjust(localVipCommodityItemEntity.downImageUrl, localImageView3);
          if ((!"1".equals(localVipCommodityItemEntity.commodityType)) && (!"2".equals(localVipCommodityItemEntity.commodityType)) && (!"3".equals(localVipCommodityItemEntity.commodityType)))
            break label789;
          GlideUtils.loadImgByAdjust(localVipCommodityItemEntity.activeImageUrl, localImageView1);
          localImageView1.setVisibility(0);
          localRTextView.setVisibility(4);
          if (!"3".equals(localVipCommodityItemEntity.commodityType))
            continue;
          localImageView2.startAnimation(AnimationUtils.loadAnimation(this, R.anim.vip_promotion_anim));
          if ((StringUtils.isNull(localVipCommodityItemEntity.disComment)) || (localImageView3.getVisibility() == 0))
            continue;
          localRTextView.setVisibility(0);
          localImageView3.setVisibility(4);
          localRTextView.setText(localVipCommodityItemEntity.disComment);
          if (paramVipCommodityReformer.lstVipPackage.lstVipCommodity.indexOf(localVipCommodityItemEntity) == 0)
            continue;
          ((LinearLayout.LayoutParams)localView.getLayoutParams()).leftMargin = CompDeviceInfoUtils.convertOfDip(this, 10.0F);
          if (!"1".equals(paramVipCommodityReformer.hasActive))
            break label976;
          if (!"3".equals(localVipCommodityItemEntity.commodityType))
            break label939;
          if (paramVipCommodityReformer.lstVipPackage.lstVipCommodity.indexOf(localVipCommodityItemEntity) == 2)
            break label798;
          localRRelativeLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this, R.color.transparent)).setBorderColorNormal(ContextCompat.getColor(this, R.color.color_e6e6e6)).setBorderWidthNormal(CompDeviceInfoUtils.convertOfDip(this, 1.0F));
          localRRelativeLayout.setOnClickListener(new View.OnClickListener(localVipCommodityItemEntity)
          {
            @Instrumented
            public void onClick(View paramView)
            {
              VdsAgent.onClick(this, paramView);
              if (VipCenterActivity.this.defaultSelVipLayout != null)
                VipCenterActivity.this.defaultSelVipLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(VipCenterActivity.this, R.color.transparent)).setBorderColorNormal(ContextCompat.getColor(VipCenterActivity.this, R.color.color_e6e6e6)).setBorderWidthNormal(CompDeviceInfoUtils.convertOfDip(VipCenterActivity.this, 1.0F));
              ((RRelativeLayout)paramView).getHelper().setBackgroundColorNormal(ContextCompat.getColor(VipCenterActivity.this, R.color.color_28ffd208)).setBorderColorNormal(ContextCompat.getColor(VipCenterActivity.this, R.color.color_ffd208)).setBorderWidthNormal(CompDeviceInfoUtils.convertOfDip(VipCenterActivity.this, 1.0F));
              VipCenterActivity.access$702(VipCenterActivity.this, (RRelativeLayout)paramView);
              VipCenterActivity.this.pay_money_hint.setText(String.valueOf("实付：¥" + this.val$loopEntity.price));
              if (!StringUtils.isNull(this.val$loopEntity.buyComment))
              {
                VipCenterActivity.this.pay_comment.setVisibility(0);
                VipCenterActivity.this.pay_comment.setText(this.val$loopEntity.buyComment);
              }
              while (true)
              {
                VipCenterActivity.access$1002(VipCenterActivity.this, this.val$loopEntity);
                return;
                VipCenterActivity.this.pay_comment.setVisibility(8);
              }
            }
          });
          continue;
        }
      }
      catch (Exception localException)
      {
        ToastUtils.makeToast(this, "数据解析异常");
        return;
      }
      this.vip_ad_img.getLayoutParams().width = BaseApplication.screenWidth;
      this.vip_ad_img.getLayoutParams().height = (int)(0.1861D * BaseApplication.screenWidth);
      this.vip_ad_layout.setVisibility(0);
      this.vip_ad_layout.setOnClickListener(new FitAction(this));
      GlideUtils.loadCacheImg(this, this.vipWelcomeModel.useUrl, this.vip_ad_img);
      continue;
      label777: this.vip_privilege_parent_layout.setVisibility(8);
      continue;
      label789: localImageView1.setVisibility(4);
      continue;
      label798: if (this.defaultSelVipLayout != null)
        this.defaultSelVipLayout.setBackgroundResource(0);
      localRRelativeLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this, R.color.color_28ffd208)).setBorderColorNormal(ContextCompat.getColor(this, R.color.color_ffd208)).setBorderWidthNormal(CompDeviceInfoUtils.convertOfDip(this, 1.0F));
      this.defaultSelVipLayout = localRRelativeLayout;
      this.pay_money_hint.setText(String.valueOf("实付：¥" + localVipCommodityItemEntity.price));
      if (!StringUtils.isNull(localVipCommodityItemEntity.buyComment))
      {
        this.pay_comment.setVisibility(0);
        this.pay_comment.setText(localVipCommodityItemEntity.buyComment);
      }
      while (true)
      {
        this.selVipCommoItemEntity = localVipCommodityItemEntity;
        break;
        this.pay_comment.setVisibility(8);
      }
      label939: localRRelativeLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this, R.color.transparent)).setBorderColorNormal(ContextCompat.getColor(this, R.color.color_e6e6e6)).setBorderWidthNormal(CompDeviceInfoUtils.convertOfDip(this, 1.0F));
      continue;
      label976: if (paramVipCommodityReformer.lstVipPackage.lstVipCommodity.indexOf(localVipCommodityItemEntity) == 1)
      {
        localRRelativeLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this, R.color.color_28ffd208)).setBorderColorNormal(ContextCompat.getColor(this, R.color.color_ffd208)).setBorderWidthNormal(CompDeviceInfoUtils.convertOfDip(this, 1.0F));
        this.defaultSelVipLayout = localRRelativeLayout;
        this.pay_money_hint.setText(String.valueOf("实付：¥" + localVipCommodityItemEntity.price));
        if (!StringUtils.isNull(localVipCommodityItemEntity.buyComment))
        {
          this.pay_comment.setVisibility(0);
          this.pay_comment.setText(localVipCommodityItemEntity.buyComment);
        }
        while (true)
        {
          this.selVipCommoItemEntity = localVipCommodityItemEntity;
          break;
          this.pay_comment.setVisibility(8);
        }
      }
      localRRelativeLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this, R.color.transparent)).setBorderColorNormal(ContextCompat.getColor(this, R.color.color_e6e6e6)).setBorderWidthNormal(CompDeviceInfoUtils.convertOfDip(this, 1.0F));
      continue;
      label1155: this.vip_body_layout.setVisibility(0);
      this.bottom_bar_layout.setVisibility(0);
      return;
      label1172: int i = 0;
    }
  }

  private void setUserVipInfo()
  {
    this.mine_fragment_name.setText(BaseApplication.userModel.userName);
    FitVipUserView localFitVipUserView = this.user_icon;
    int i;
    int j;
    label101: LinearLayout.LayoutParams localLayoutParams;
    float f;
    if (StringUtils.isNull(BaseApplication.userModel.isVip))
    {
      i = 0;
      localFitVipUserView.setIsVip(i);
      this.user_icon.loadUserIcon(BaseApplication.userModel.userImg).setVipTagSize(CompDeviceInfoUtils.convertOfDip(this, 70.0F), 0.2857D);
      TextView localTextView = this.buy_vip_btn;
      Resources localResources = getResources();
      if ((this.user_icon.getIsVip() != 1) && (this.user_icon.getIsVip() != 2))
        break label214;
      j = R.string.c_76_2_5;
      localTextView.setText(localResources.getString(j));
      this.user_info_hint.setText(getVipDesc());
      RLinearLayout localRLinearLayout = this.vip_wechat_layout;
      boolean bool = StringUtils.isNull(BaseApplication.userModel.wechatNum);
      int k = 0;
      if (bool)
        k = 8;
      localRLinearLayout.setVisibility(k);
      localLayoutParams = (LinearLayout.LayoutParams)this.mine_fragment_name.getLayoutParams();
      if (this.vip_wechat_layout.getVisibility() != 0)
        break label222;
      f = 71.0F;
    }
    while (true)
    {
      localLayoutParams.rightMargin = CompDeviceInfoUtils.convertOfDip(this, f);
      return;
      i = Integer.valueOf(BaseApplication.userModel.isVip).intValue();
      break;
      label214: j = R.string.c_76_1_6;
      break label101;
      label222: f = 16.0F;
    }
  }

  private void setVipPriceTextStyle(TextView paramTextView)
  {
    paramTextView.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.vip_agreement_layout)
      FitJumpImpl.getInstance().settingJumpWebView(this, null, VersionUpdateCheck.WEB_ADDRESS + "vip/agreement");
    while (true)
    {
      super.fitOnClick(paramView);
      do
      {
        return;
        if (paramView.getId() == R.id.zhifubao_layout)
        {
          this.payType = 0;
          resetPaySelectorStatus();
          this.zhifubao_select_icon.setImageResource(R.mipmap.c_btn_select_vip);
          break;
        }
        if (paramView.getId() == R.id.wechat_layout)
        {
          this.payType = 1;
          resetPaySelectorStatus();
          this.wechat_select_icon.setImageResource(R.mipmap.c_btn_select_vip);
          break;
        }
        if (paramView.getId() == R.id.jd_layout)
        {
          this.payType = 2;
          resetPaySelectorStatus();
          this.jd_select_icon.setImageResource(R.mipmap.c_btn_select_vip);
          break;
        }
        if (paramView.getId() == R.id.buy_vip_btn)
        {
          payAction();
          break;
        }
        if (paramView.getId() == R.id.back_layout)
        {
          finish();
          AnimationUtil.pageJumpAnim(this, 1);
          break;
        }
        if (paramView.getId() == R.id.service_layout)
        {
          CustomerServiceUtils.openServiceActivity(this);
          break;
        }
        if (paramView.getId() == R.id.vipHist_layout)
        {
          startActivity(new Intent(this, VipHistActivity.class));
          AnimationUtil.pageJumpAnim(this, 0);
          break;
        }
        if (paramView.getId() != R.id.vip_privilege_title_layout)
          break label345;
      }
      while (this.adapter == null);
      ArrayList localArrayList = this.adapter.getLstVipPrivilege();
      if ((localArrayList == null) || (localArrayList.size() == 0) || (StringUtils.isNull(((VipCommodityItemEntity)localArrayList.get(0)).privilegeId)))
        continue;
      String str = VersionUpdateCheck.WEB_ADDRESS + "vip/vipTab?page=" + ((VipCommodityItemEntity)this.adapter.getLstVipPrivilege().get(0)).privilegeId;
      FitJumpImpl.getInstance().settingJumpWebView(this, null, str);
      continue;
      label345: if (paramView.getId() == R.id.vip_ad_layout)
      {
        FitJumpImpl.getInstance().settingJumpWebView(this, "", this.vipWelcomeModel.adUrl);
        GrowingIOVariables localGrowingIOVariables = new GrowingIOVariables();
        localGrowingIOVariables.eventid = "ad_banner_click";
        localGrowingIOVariables.ad_id = this.vipWelcomeModel.adId;
        GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
        continue;
      }
      if (paramView.getId() != R.id.vip_wechat_layout)
        continue;
      this.dialog.zeroVipShareDialog(this, BaseApplication.userModel.wechatNum, new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          if (paramInt == -1)
          {
            TextUtils.copyToClipboard(BaseApplication.userModel.wechatNum);
            ToastUtils.makeToast(VipCenterActivity.this, "复制成功");
          }
        }
      });
    }
  }

  public <T> void getDataFail(T paramT)
  {
    if (this.loader_icon != null)
      this.loader_icon.setVisibility(4);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (this.loader_icon != null)
      this.loader_icon.setVisibility(4);
    if (this.dialog != null)
      this.dialog.closeDialog();
    if ((paramT instanceof VipCommodityReformer))
      setDataForPage((VipCommodityReformer)paramT);
    do
      return;
    while (!"Y".equals(paramT));
    if (!StringUtils.isNull(BaseApplication.userModel.wechatNum))
    {
      this.dialog.zeroVipShareDialog(this, BaseApplication.userModel.wechatNum, new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          ClipboardManager localClipboardManager;
          if (paramInt == -1)
          {
            localClipboardManager = (ClipboardManager)VipCenterActivity.this.getSystemService("clipboard");
            if (localClipboardManager == null)
              ToastUtils.makeToast(VipCenterActivity.this, "复制失败");
          }
          do
          {
            return;
            localClipboardManager.setPrimaryClip(ClipData.newPlainText("Label", BaseApplication.userModel.wechatNum));
            ToastUtils.makeToast(VipCenterActivity.this, "复制成功");
            return;
          }
          while (paramInt != -2);
          EventBus.getDefault().post(new ReceiveMedalEvent("11", VipCenterActivity.this));
        }
      });
      return;
    }
    EventBus.getDefault().post(new ReceiveMedalEvent("11", this));
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.vip_center);
    EventBus.getDefault().register(this);
    GrowingIO.getInstance().setPageVariable(this, "page_name", "我的会员");
    initView();
    this.vipWelcomeModel = MiddleManager.getInstance().getLoginPresenterImpl(null).getAdVipData(this);
    if (CompDeviceInfoUtils.checkNetwork())
    {
      this.loader_icon.setVisibility(0);
      MiddleManager.getInstance().getMinePresenterImpl(this).getVipCommodity(this, new RequestModel());
      return;
    }
    this.loader_icon.setVisibility(4);
    ToastUtils.makeToast(this, getResources().getString(R.string.link_failure_hint));
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    String str;
    if ((paramIntent != null) && (1024 == paramInt2))
    {
      str = paramIntent.getStringExtra("jdpay_Result");
      if (!StringUtils.isNull(str))
        break label29;
    }
    label29: JDPayResultModel localJDPayResultModel;
    do
    {
      return;
      localJDPayResultModel = (JDPayResultModel)FitGsonFactory.create().fromJson(str, JDPayResultModel.class);
    }
    while (localJDPayResultModel == null);
    if (!"JDP_PAY_SUCCESS".equals(localJDPayResultModel.payStatus))
    {
      this.jdPayHandler.setPayStatus(-1);
      return;
    }
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.jdOrderId = this.strVipOrderId;
    localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.strVipOrderId + NdkUtils.getSignBaseUrl()).toUpperCase();
    localRequestModel.extraMsg = localJDPayResultModel.extraMsg;
    this.jdPayHandler.checkJDPayResult(this, localRequestModel);
  }

  protected void onDestroy()
  {
    SharePreferenceUtils.putBuyVipFromPage("");
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("onResp".equals(paramString))
      if (this.wechatPayHandler != null)
      {
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.orderId = this.strVipOrderId;
        localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.strVipOrderId + NdkUtils.getSignBaseUrl()).toUpperCase();
        this.wechatPayHandler.checkWechatPayResult(this, localRequestModel);
      }
    do
      while (true)
      {
        return;
        if (!"onPayError".equals(paramString))
          break;
        if (this.wechatPayHandler == null)
          continue;
        this.wechatPayHandler.resetPayStatus();
        return;
      }
    while (!"refresh.mine.page.data".equals(paramString));
    setUserVipInfo();
    VipServiceEvent localVipServiceEvent = new VipServiceEvent();
    localVipServiceEvent.isPayVip = "1";
    EventBus.getDefault().post(localVipServiceEvent);
    this.buy_vip_btn.setText(getResources().getString(R.string.c_76_2_5));
  }

  public void onGetOrderId(String paramString)
  {
    if (paramString.contains("±"))
    {
      this.strVipJDOrderId = paramString.split("±")[0];
      this.strVipOrderId = paramString.split("±")[1];
      return;
    }
    this.strVipOrderId = paramString;
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  public void onPayFail(int paramInt, String paramString)
  {
  }

  public void onPaySuccess(int paramInt)
  {
    this.dialog.createProgressDialog(this, "请稍后...");
    BaseApplication.isRefresh = true;
    MiddleManager.getInstance().getMinePresenterImpl(this).getUserInfo(this);
  }

  protected void onResume()
  {
    if (this.wechatPayHandler != null)
      this.wechatPayHandler.checkWeichatVersion();
    super.onResume();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.activity.VipCenterActivity
 * JD-Core Version:    0.6.0
 */