package com.sportq.fit.fitmoudle.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.stub.StubApp;

public class ErrorActivity extends AppCompatActivity
{
  static
  {
    StubApp.interface11(9832);
  }

  protected native void onCreate(Bundle paramBundle);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.activity.ErrorActivity
 * JD-Core Version:    0.6.0
 */