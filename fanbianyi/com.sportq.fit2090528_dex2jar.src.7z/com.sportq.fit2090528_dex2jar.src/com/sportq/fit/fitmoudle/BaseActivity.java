package com.sportq.fit.fitmoudle;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.monitorlib.MonitorInterface;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.activity.FloatViewService;
import com.umeng.analytics.MobclickAgent;

public abstract class BaseActivity extends AppCompatActivity
  implements FitInterfaceUtils.UIInitListener
{
  private static final String STR_TAG = "BaseActivity";
  public DialogInterface dialog;
  private Context mBaseContext;
  protected int statusBarHeight = 0;
  protected int titleBarHeight = 0;

  private void getIntentInfo()
  {
    Intent localIntent;
    try
    {
      if (!VersionUpdateCheck.BUGTAGS_ON)
        return;
      Constant.NEXT_CLASS_NAME = StringUtils.getClassName(getClass());
      localIntent = getIntent();
      if ((StringUtils.isNull(Constant.LAST_CLASS_NAME)) || (StringUtils.isNull(Constant.NEXT_CLASS_NAME)) || ("FitConsoleActivity".equals(Constant.NEXT_CLASS_NAME)) || ("FitConsoleActivity".equals(Constant.LAST_CLASS_NAME)))
        return;
      if (localIntent == null)
      {
        CompDeviceInfoUtils.saveIntentArray(Constant.LAST_CLASS_NAME + " => " + Constant.NEXT_CLASS_NAME + "传值信息：" + "\n" + "无传值");
        return;
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      return;
    }
    if (localIntent.getExtras() == null)
    {
      CompDeviceInfoUtils.saveIntentArray(Constant.LAST_CLASS_NAME + " => " + Constant.NEXT_CLASS_NAME + "传值信息：" + "\n" + "无传值");
      return;
    }
    String str = StringUtils.getBundleData(localIntent.getExtras());
    CompDeviceInfoUtils.saveIntentArray(Constant.LAST_CLASS_NAME + " => " + Constant.NEXT_CLASS_NAME + "传值信息：" + "\n" + str);
  }

  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent)
  {
    if (BaseApplication.monitorInterface != null)
      BaseApplication.monitorInterface.onDispatchTouchEvent(this, paramMotionEvent);
    try
    {
      boolean bool = super.dispatchTouchEvent(paramMotionEvent);
      return bool;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return false;
  }

  public void fitOnClick(View paramView)
  {
  }

  public String fitOnOptionsItemSelected(MenuItem paramMenuItem)
  {
    return "";
  }

  protected void getBarHeight(Context paramContext)
  {
    Rect localRect = new Rect();
    ((Activity)paramContext).getWindow().getDecorView().getWindowVisibleDisplayFrame(localRect);
    this.statusBarHeight = localRect.top;
    this.titleBarHeight = (((Activity)paramContext).getWindow().findViewById(16908290).getTop() - this.statusBarHeight);
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
  }

  public Resources getResources()
  {
    Resources localResources = super.getResources();
    Configuration localConfiguration = new Configuration();
    localConfiguration.setToDefaults();
    localResources.updateConfiguration(localConfiguration, localResources.getDisplayMetrics());
    return localResources;
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    LogUtils.i("BaseActivity", "执行 onCreate() 方法");
    this.mBaseContext = this;
    CompDeviceInfoUtils.getDeviceWidthHeight(this.mBaseContext);
    getIntentInfo();
    try
    {
      initLayout(paramBundle);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }

  protected void onPause()
  {
    super.onPause();
    Constant.LAST_CLASS_NAME = StringUtils.getClassName(getClass());
    if (BaseApplication.monitorInterface != null)
      BaseApplication.monitorInterface.onPause(this);
    if (VersionUpdateCheck.YOUMENG_ON)
      MobclickAgent.onPause(this);
  }

  public <T> void onRefresh(T paramT)
  {
  }

  protected void onResume()
  {
    super.onResume();
    LogUtils.i("BaseActivity", "执行 onResume() 方法");
    if (BaseApplication.monitorInterface != null)
      BaseApplication.monitorInterface.onResume(this);
    if (VersionUpdateCheck.YOUMENG_ON)
      MobclickAgent.onResume(this);
    try
    {
      if (VersionUpdateCheck.BUGTAGS_ON)
        if (Build.VERSION.SDK_INT >= 23)
        {
          if (Settings.canDrawOverlays(this))
          {
            startService(new Intent(this, FloatViewService.class));
            return;
          }
        }
        else
        {
          startService(new Intent(this, FloatViewService.class));
          return;
        }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  protected void onStart()
  {
    super.onStart();
  }

  protected void onStop()
  {
    super.onStop();
    LogUtils.i("BaseActivity", "执行 onStop() 方法");
    try
    {
      if ((!CompDeviceInfoUtils.isRunningForeground(this.mBaseContext)) && (VersionUpdateCheck.BUGTAGS_ON) && (CompDeviceInfoUtils.checkPermission(this, "android.permission.SYSTEM_ALERT_WINDOW")))
        stopService(new Intent(this, FloatViewService.class));
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.BaseActivity
 * JD-Core Version:    0.6.0
 */