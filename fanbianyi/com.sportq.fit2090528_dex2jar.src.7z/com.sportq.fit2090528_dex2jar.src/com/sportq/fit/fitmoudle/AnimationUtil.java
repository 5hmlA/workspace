package com.sportq.fit.fitmoudle;

import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.app.Activity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.TextView;
import com.sportq.fit.uicommon.R.anim;

public class AnimationUtil
{
  public static void clearControlAnim(View paramView, boolean paramBoolean)
  {
    if (paramView != null)
    {
      paramView.clearAnimation();
      if (paramBoolean)
        paramView.setVisibility(0);
    }
    else
    {
      return;
    }
    paramView.setVisibility(8);
  }

  public static ValueAnimator fontColorGradientAnimation(TextView paramTextView, int paramInt1, int paramInt2, int paramInt3)
  {
    2 local2 = new TypeEvaluator()
    {
      public Object evaluate(float paramFloat, Object paramObject1, Object paramObject2)
      {
        int i = ((Integer)paramObject1).intValue();
        int j = 0xFF & i >> 24;
        int k = 0xFF & i >> 16;
        int m = 0xFF & i >> 8;
        int n = i & 0xFF;
        int i1 = ((Integer)paramObject2).intValue();
        int i2 = 0xFF & i1 >> 24;
        int i3 = 0xFF & i1 >> 16;
        int i4 = 0xFF & i1 >> 8;
        int i5 = i1 & 0xFF;
        return Integer.valueOf(j + (int)(paramFloat * (i2 - j)) << 24 | k + (int)(paramFloat * (i3 - k)) << 16 | m + (int)(paramFloat * (i4 - m)) << 8 | n + (int)(paramFloat * (i5 - n)));
      }
    };
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = Integer.valueOf(paramInt1);
    arrayOfObject[1] = Integer.valueOf(paramInt2);
    ValueAnimator localValueAnimator = ValueAnimator.ofObject(local2, arrayOfObject);
    localValueAnimator.setDuration(paramInt3);
    localValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(paramTextView)
    {
      public void onAnimationUpdate(ValueAnimator paramValueAnimator)
      {
        int i = ((Integer)paramValueAnimator.getAnimatedValue()).intValue();
        this.val$textView.setTextColor(i);
      }
    });
    localValueAnimator.start();
    return localValueAnimator;
  }

  public static void pageJumpAnim(Activity paramActivity, int paramInt)
  {
    switch (paramInt)
    {
    default:
      return;
    case 0:
      paramActivity.overridePendingTransition(R.anim.pagejump_in, R.anim.pagejump_out);
      return;
    case 1:
    }
    paramActivity.overridePendingTransition(R.anim.pageback_in, R.anim.pageback_out);
  }

  public static void pagePopAnim(Activity paramActivity, int paramInt)
  {
    switch (paramInt)
    {
    default:
      return;
    case 0:
      paramActivity.overridePendingTransition(R.anim.pop_inside_in, R.anim.pop_inside_out);
      return;
    case 1:
    }
    paramActivity.overridePendingTransition(R.anim.pop_inside_out, R.anim.pop_outside_in);
  }

  public static void pagePopNotAnim(Activity paramActivity)
  {
    paramActivity.overridePendingTransition(R.anim.not_anim, R.anim.not_anim);
  }

  public static void rotateAnim(OnAnimFinishListener paramOnAnimFinishListener, View paramView, int paramInt, float paramFloat)
  {
    if (paramView != null)
    {
      paramView.setVisibility(0);
      RotateAnimation localRotateAnimation = new RotateAnimation(0.0F, paramFloat, 1, 0.5F, 1, 0.5F);
      localRotateAnimation.setDuration(paramInt);
      paramView.startAnimation(localRotateAnimation);
      localRotateAnimation.setAnimationListener(new Animation.AnimationListener(paramOnAnimFinishListener)
      {
        public void onAnimationEnd(Animation paramAnimation)
        {
          if (this.val$listener != null)
            this.val$listener.onFinish();
        }

        public void onAnimationRepeat(Animation paramAnimation)
        {
        }

        public void onAnimationStart(Animation paramAnimation)
        {
        }
      });
    }
  }

  public static void scaleAnim(View paramView)
  {
    ScaleAnimation localScaleAnimation = new ScaleAnimation(2.0F, 1.0F, 2.0F, 1.0F, 1, 0.5F, 1, 0.5F);
    localScaleAnimation.setDuration(1000L);
    paramView.startAnimation(localScaleAnimation);
  }

  public static abstract interface OnAnimFinishListener
  {
    public abstract void onFinish();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.AnimationUtil
 * JD-Core Version:    0.6.0
 */