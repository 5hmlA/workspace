package com.sportq.fit.fitmoudle.dialogmanager;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnDismissListener;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.uicommon.R.color;
import com.sportq.fit.uicommon.R.drawable;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;

public class MaterialDialog
{
  private static final int BUTTON_BOTTOM = 9;
  private static final int BUTTON_TOP = 9;
  private AlertDialog mAlertDialog;
  private Drawable mBackgroundDrawable;
  private int mBackgroundResId = -1;
  private Builder mBuilder;
  private boolean mCancel;
  private Context mContext;
  private boolean mHasShow = false;
  private LinearLayout.LayoutParams mLayoutParams;
  private CharSequence mMessage;
  private View mMessageContentView;
  private int mMessageContentViewResId;
  private int mMessageResId;
  private Button mNegativeButton;
  private DialogInterface.OnDismissListener mOnDismissListener;
  private Button mPositiveButton;
  private CharSequence mTitle;
  private int mTitleResId;
  private TextView mTitleView;
  private View mView;
  private int nId = -1;
  View.OnClickListener nListener;
  private String nText;
  private int nTextColor = R.color.black;
  private int pId = -1;
  View.OnClickListener pListener;
  private String pText;
  private int pTextColor = R.color.color_ffd208;

  public MaterialDialog(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private int dip2px(float paramFloat)
  {
    return (int)(0.5F + paramFloat * this.mContext.getResources().getDisplayMetrics().density);
  }

  private static boolean isLollipop()
  {
    return Build.VERSION.SDK_INT >= 21;
  }

  private boolean isNullOrEmpty(String paramString)
  {
    return (paramString == null) || (paramString.isEmpty());
  }

  private void setListViewHeightBasedOnChildren(ListView paramListView)
  {
    ListAdapter localListAdapter = paramListView.getAdapter();
    if (localListAdapter == null)
      return;
    int i = 0;
    for (int j = 0; j < localListAdapter.getCount(); j++)
    {
      View localView = localListAdapter.getView(j, null, paramListView);
      localView.measure(0, 0);
      i += localView.getMeasuredHeight();
    }
    ViewGroup.LayoutParams localLayoutParams = paramListView.getLayoutParams();
    localLayoutParams.height = (i + paramListView.getDividerHeight() * (-1 + localListAdapter.getCount()));
    paramListView.setLayoutParams(localLayoutParams);
  }

  public void dismiss()
  {
    this.mAlertDialog.dismiss();
    this.mHasShow = false;
  }

  public View findViewById(int paramInt)
  {
    return this.mBuilder.findViewById(paramInt);
  }

  public Button getNegativeButton()
  {
    return this.mNegativeButton;
  }

  public Button getPositiveButton()
  {
    return this.mPositiveButton;
  }

  public TextView getTitle()
  {
    return this.mTitleView;
  }

  public void hideButtonLayout()
  {
    this.mBuilder.hideButtonLayout();
  }

  public boolean ismHasShow()
  {
    return this.mHasShow;
  }

  public MaterialDialog setBackground(Drawable paramDrawable)
  {
    this.mBackgroundDrawable = paramDrawable;
    if (this.mBuilder != null)
      this.mBuilder.setBackground(this.mBackgroundDrawable);
    return this;
  }

  public MaterialDialog setBackgroundResource(int paramInt)
  {
    this.mBackgroundResId = paramInt;
    if (this.mBuilder != null)
      this.mBuilder.setBackgroundResource(this.mBackgroundResId);
    return this;
  }

  public MaterialDialog setCanceledOnTouchOutside(boolean paramBoolean)
  {
    this.mCancel = paramBoolean;
    if (this.mBuilder != null)
      this.mBuilder.setCanceledOnTouchOutside(this.mCancel);
    return this;
  }

  public MaterialDialog setContentView(int paramInt)
  {
    this.mMessageContentViewResId = paramInt;
    this.mMessageContentView = null;
    if (this.mBuilder != null)
      this.mBuilder.setContentView(paramInt);
    return this;
  }

  public MaterialDialog setContentView(View paramView)
  {
    this.mMessageContentView = paramView;
    this.mMessageContentViewResId = 0;
    if (this.mBuilder != null)
      this.mBuilder.setContentView(this.mMessageContentView);
    return this;
  }

  public MaterialDialog setMessage(int paramInt)
  {
    this.mMessageResId = paramInt;
    if (this.mBuilder != null)
      this.mBuilder.setMessage(paramInt);
    return this;
  }

  public MaterialDialog setMessage(CharSequence paramCharSequence)
  {
    this.mMessage = paramCharSequence;
    if (this.mBuilder != null)
      this.mBuilder.setMessage(paramCharSequence);
    return this;
  }

  public MaterialDialog setNegativeButton(int paramInt, View.OnClickListener paramOnClickListener)
  {
    this.nId = paramInt;
    this.nListener = paramOnClickListener;
    return this;
  }

  public MaterialDialog setNegativeButton(String paramString, View.OnClickListener paramOnClickListener)
  {
    this.nText = paramString;
    this.nListener = paramOnClickListener;
    return this;
  }

  public MaterialDialog setNegativeButtonColor(int paramInt)
  {
    this.nTextColor = paramInt;
    return this;
  }

  public MaterialDialog setOnDismissListener(DialogInterface.OnDismissListener paramOnDismissListener)
  {
    this.mOnDismissListener = paramOnDismissListener;
    return this;
  }

  public MaterialDialog setPositiveButton(int paramInt, View.OnClickListener paramOnClickListener)
  {
    this.pId = paramInt;
    this.pListener = paramOnClickListener;
    return this;
  }

  public MaterialDialog setPositiveButton(String paramString, View.OnClickListener paramOnClickListener)
  {
    this.pText = paramString;
    this.pListener = paramOnClickListener;
    return this;
  }

  public MaterialDialog setPositiveButtonColor(int paramInt)
  {
    this.pTextColor = paramInt;
    return this;
  }

  public MaterialDialog setTitle(int paramInt)
  {
    this.mTitleResId = paramInt;
    if (this.mBuilder != null)
      this.mBuilder.setTitle(paramInt);
    return this;
  }

  public MaterialDialog setTitle(CharSequence paramCharSequence)
  {
    this.mTitle = paramCharSequence;
    if (this.mBuilder != null)
      this.mBuilder.setTitle(paramCharSequence);
    return this;
  }

  public MaterialDialog setView(View paramView)
  {
    this.mView = paramView;
    if (this.mBuilder != null)
      this.mBuilder.setView(paramView);
    return this;
  }

  public void show()
  {
    if (!this.mHasShow)
      this.mBuilder = new Builder(null);
    while (true)
    {
      this.mHasShow = true;
      return;
      AlertDialog localAlertDialog = this.mAlertDialog;
      localAlertDialog.show();
      VdsAgent.showDialog((Dialog)localAlertDialog);
    }
  }

  private class Builder
  {
    private Window mAlertDialogWindow;
    private LinearLayout mButtonLayout;
    private ViewGroup mMessageContentRoot;
    private TextView mMessageView;

    private Builder()
    {
      MaterialDialog.access$102(MaterialDialog.this, new AlertDialog.Builder(MaterialDialog.this.mContext).create());
      AlertDialog localAlertDialog = MaterialDialog.this.mAlertDialog;
      localAlertDialog.show();
      VdsAgent.showDialog((Dialog)localAlertDialog);
      MaterialDialog.this.mAlertDialog.getWindow().clearFlags(131080);
      MaterialDialog.this.mAlertDialog.getWindow().setSoftInputMode(15);
      this.mAlertDialogWindow = MaterialDialog.this.mAlertDialog.getWindow();
      View localView = LayoutInflater.from(MaterialDialog.this.mContext).inflate(R.layout.layout_material_dialog, null);
      localView.setFocusable(true);
      localView.setFocusableInTouchMode(true);
      this.mAlertDialogWindow.setBackgroundDrawableResource(R.drawable.material_dialog_window);
      this.mAlertDialogWindow.setContentView(localView);
      MaterialDialog.access$302(MaterialDialog.this, (TextView)this.mAlertDialogWindow.findViewById(R.id.title));
      this.mMessageView = ((TextView)this.mAlertDialogWindow.findViewById(R.id.message));
      this.mButtonLayout = ((LinearLayout)this.mAlertDialogWindow.findViewById(R.id.buttonLayout));
      MaterialDialog.access$402(MaterialDialog.this, (Button)this.mButtonLayout.findViewById(R.id.btn_p));
      MaterialDialog.access$502(MaterialDialog.this, (Button)this.mButtonLayout.findViewById(R.id.btn_n));
      this.mMessageContentRoot = ((ViewGroup)this.mAlertDialogWindow.findViewById(R.id.message_content_root));
      if (MaterialDialog.this.mView != null)
      {
        LinearLayout localLinearLayout2 = (LinearLayout)this.mAlertDialogWindow.findViewById(R.id.contentView);
        localLinearLayout2.removeAllViews();
        localLinearLayout2.addView(MaterialDialog.this.mView);
      }
      if (MaterialDialog.this.mTitleResId != 0)
        setTitle(MaterialDialog.this.mTitleResId);
      if (MaterialDialog.this.mTitle != null)
        setTitle(MaterialDialog.this.mTitle);
      if ((MaterialDialog.this.mTitle == null) && (MaterialDialog.this.mTitleResId == 0))
        MaterialDialog.this.mTitleView.setVisibility(8);
      if (MaterialDialog.this.mMessageResId != 0)
        setMessage(MaterialDialog.this.mMessageResId);
      if (MaterialDialog.this.mMessage != null)
        setMessage(MaterialDialog.this.mMessage);
      if (MaterialDialog.this.pId != -1)
      {
        MaterialDialog.this.mPositiveButton.setVisibility(0);
        MaterialDialog.this.mPositiveButton.setText(MaterialDialog.this.pId);
        MaterialDialog.this.mPositiveButton.setOnClickListener(MaterialDialog.this.pListener);
        MaterialDialog.this.mPositiveButton.setTextColor(MaterialDialog.this.mContext.getResources().getColor(MaterialDialog.this.pTextColor));
        if (MaterialDialog.access$1300())
          MaterialDialog.this.mPositiveButton.setElevation(0.0F);
      }
      if (MaterialDialog.this.nId != -1)
      {
        MaterialDialog.this.mNegativeButton.setVisibility(0);
        MaterialDialog.this.mNegativeButton.setText(MaterialDialog.this.nId);
        MaterialDialog.this.mNegativeButton.setOnClickListener(MaterialDialog.this.nListener);
        MaterialDialog.this.mNegativeButton.setTextColor(MaterialDialog.this.mContext.getResources().getColor(MaterialDialog.this.nTextColor));
        if (MaterialDialog.access$1300())
          MaterialDialog.this.mNegativeButton.setElevation(0.0F);
      }
      if (!MaterialDialog.this.isNullOrEmpty(MaterialDialog.this.pText))
      {
        MaterialDialog.this.mPositiveButton.setVisibility(0);
        MaterialDialog.this.mPositiveButton.setText(MaterialDialog.this.pText);
        MaterialDialog.this.mPositiveButton.setOnClickListener(MaterialDialog.this.pListener);
        MaterialDialog.this.mPositiveButton.setTextColor(MaterialDialog.this.mContext.getResources().getColor(MaterialDialog.this.pTextColor));
        if (MaterialDialog.access$1300())
          MaterialDialog.this.mPositiveButton.setElevation(0.0F);
      }
      if (!MaterialDialog.this.isNullOrEmpty(MaterialDialog.this.nText))
      {
        MaterialDialog.this.mNegativeButton.setVisibility(0);
        MaterialDialog.this.mNegativeButton.setText(MaterialDialog.this.nText);
        MaterialDialog.this.mNegativeButton.setOnClickListener(MaterialDialog.this.nListener);
        MaterialDialog.this.mNegativeButton.setTextColor(MaterialDialog.this.mContext.getResources().getColor(MaterialDialog.this.nTextColor));
        if (MaterialDialog.access$1300())
          MaterialDialog.this.mNegativeButton.setElevation(0.0F);
      }
      if ((MaterialDialog.this.isNullOrEmpty(MaterialDialog.this.pText)) && (MaterialDialog.this.pId == -1))
        MaterialDialog.this.mPositiveButton.setVisibility(8);
      if ((MaterialDialog.this.isNullOrEmpty(MaterialDialog.this.nText)) && (MaterialDialog.this.nId == -1))
        MaterialDialog.this.mNegativeButton.setVisibility(8);
      if (MaterialDialog.this.mBackgroundResId != -1)
        ((LinearLayout)this.mAlertDialogWindow.findViewById(R.id.material_background)).setBackgroundResource(MaterialDialog.this.mBackgroundResId);
      if (MaterialDialog.this.mBackgroundDrawable != null)
      {
        LinearLayout localLinearLayout1 = (LinearLayout)this.mAlertDialogWindow.findViewById(R.id.material_background);
        if (Build.VERSION.SDK_INT >= 16)
          localLinearLayout1.setBackground(MaterialDialog.this.mBackgroundDrawable);
      }
      if (MaterialDialog.this.mMessageContentView != null)
        setContentView(MaterialDialog.this.mMessageContentView);
      while (true)
      {
        MaterialDialog.this.mAlertDialog.setCanceledOnTouchOutside(MaterialDialog.this.mCancel);
        MaterialDialog.this.mAlertDialog.setCancelable(MaterialDialog.this.mCancel);
        if (MaterialDialog.this.mOnDismissListener != null)
          MaterialDialog.this.mAlertDialog.setOnDismissListener(MaterialDialog.this.mOnDismissListener);
        return;
        if (MaterialDialog.this.mMessageContentViewResId == 0)
          continue;
        setContentView(MaterialDialog.this.mMessageContentViewResId);
      }
    }

    public View findViewById(int paramInt)
    {
      return this.mMessageContentRoot.findViewById(paramInt);
    }

    public void hideButtonLayout()
    {
      if (this.mButtonLayout != null)
      {
        ViewGroup.LayoutParams localLayoutParams = this.mButtonLayout.getLayoutParams();
        localLayoutParams.height = CompDeviceInfoUtils.convertOfDip(MaterialDialog.this.mContext, 8.0F);
        this.mButtonLayout.setLayoutParams(localLayoutParams);
      }
    }

    @TargetApi(16)
    public void setBackground(Drawable paramDrawable)
    {
      ((LinearLayout)this.mAlertDialogWindow.findViewById(R.id.material_background)).setBackground(paramDrawable);
    }

    public void setBackgroundResource(int paramInt)
    {
      ((LinearLayout)this.mAlertDialogWindow.findViewById(R.id.material_background)).setBackgroundResource(paramInt);
    }

    public void setCanceledOnTouchOutside(boolean paramBoolean)
    {
      MaterialDialog.this.mAlertDialog.setCanceledOnTouchOutside(paramBoolean);
      MaterialDialog.this.mAlertDialog.setCancelable(paramBoolean);
    }

    public void setContentView(int paramInt)
    {
      this.mMessageContentRoot.removeAllViews();
      LayoutInflater.from(this.mMessageContentRoot.getContext()).inflate(paramInt, this.mMessageContentRoot);
    }

    public void setContentView(View paramView)
    {
      paramView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
      if ((paramView instanceof ListView))
        MaterialDialog.this.setListViewHeightBasedOnChildren((ListView)paramView);
      LinearLayout localLinearLayout = (LinearLayout)this.mAlertDialogWindow.findViewById(R.id.message_content_view);
      if (localLinearLayout != null)
      {
        localLinearLayout.removeAllViews();
        localLinearLayout.addView(paramView);
      }
      int i = 0;
      if (localLinearLayout != null);
      for (int j = localLinearLayout.getChildCount(); ; j = 0)
      {
        if (i >= j)
          return;
        if ((localLinearLayout.getChildAt(i) instanceof AutoCompleteTextView))
        {
          AutoCompleteTextView localAutoCompleteTextView = (AutoCompleteTextView)localLinearLayout.getChildAt(i);
          localAutoCompleteTextView.setFocusable(true);
          localAutoCompleteTextView.requestFocus();
          localAutoCompleteTextView.setFocusableInTouchMode(true);
        }
        i++;
        break;
      }
    }

    public void setMessage(int paramInt)
    {
      if (this.mMessageView != null)
        this.mMessageView.setText(paramInt);
    }

    public void setMessage(CharSequence paramCharSequence)
    {
      if (this.mMessageView != null)
        this.mMessageView.setText(paramCharSequence);
    }

    public void setNegativeButton(String paramString, View.OnClickListener paramOnClickListener)
    {
      Button localButton = new Button(MaterialDialog.this.mContext);
      LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, -2);
      localButton.setLayoutParams(localLayoutParams);
      localButton.setBackgroundResource(R.drawable.material_card);
      localButton.setText(paramString);
      localButton.setTextColor(Color.argb(222, 0, 0, 0));
      localButton.setTextSize(14.0F);
      localButton.setGravity(17);
      localButton.setPadding(0, 0, 0, MaterialDialog.this.dip2px(8.0F));
      localButton.setOnClickListener(paramOnClickListener);
      if (this.mButtonLayout.getChildCount() > 0)
      {
        localLayoutParams.setMargins(20, 0, 10, MaterialDialog.this.dip2px(9.0F));
        localButton.setLayoutParams(localLayoutParams);
        this.mButtonLayout.addView(localButton, 1);
        return;
      }
      localButton.setLayoutParams(localLayoutParams);
      this.mButtonLayout.addView(localButton);
    }

    public void setPositiveButton(String paramString, View.OnClickListener paramOnClickListener)
    {
      Button localButton = new Button(MaterialDialog.this.mContext);
      localButton.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
      localButton.setBackgroundResource(R.drawable.material_card);
      localButton.setTextColor(Color.argb(255, 35, 159, 242));
      localButton.setText(paramString);
      localButton.setGravity(17);
      localButton.setTextSize(14.0F);
      localButton.setPadding(MaterialDialog.this.dip2px(12.0F), 0, MaterialDialog.this.dip2px(32.0F), MaterialDialog.this.dip2px(9.0F));
      localButton.setOnClickListener(paramOnClickListener);
      this.mButtonLayout.addView(localButton);
    }

    public void setTitle(int paramInt)
    {
      MaterialDialog.this.mTitleView.setText(paramInt);
    }

    public void setTitle(CharSequence paramCharSequence)
    {
      MaterialDialog.this.mTitleView.setText(paramCharSequence);
    }

    public void setView(View paramView)
    {
      LinearLayout localLinearLayout = (LinearLayout)this.mAlertDialogWindow.findViewById(R.id.contentView);
      localLinearLayout.removeAllViews();
      paramView.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
      paramView.setOnFocusChangeListener(new View.OnFocusChangeListener()
      {
        @Instrumented
        public void onFocusChange(View paramView, boolean paramBoolean)
        {
          VdsAgent.onFocusChange(this, paramView, paramBoolean);
          MaterialDialog.Builder.this.mAlertDialogWindow.setSoftInputMode(5);
          ((InputMethodManager)MaterialDialog.this.mContext.getSystemService("input_method")).toggleSoftInput(2, 1);
        }
      });
      localLinearLayout.addView(paramView);
      if ((paramView instanceof ViewGroup))
      {
        ViewGroup localViewGroup = (ViewGroup)paramView;
        for (int i = 0; i < localViewGroup.getChildCount(); i++)
        {
          if (!(localViewGroup.getChildAt(i) instanceof EditText))
            continue;
          EditText localEditText = (EditText)localViewGroup.getChildAt(i);
          localEditText.setFocusable(true);
          localEditText.requestFocus();
          localEditText.setFocusableInTouchMode(true);
        }
        for (int j = 0; j < localViewGroup.getChildCount(); j++)
        {
          if (!(localViewGroup.getChildAt(j) instanceof AutoCompleteTextView))
            continue;
          AutoCompleteTextView localAutoCompleteTextView = (AutoCompleteTextView)localViewGroup.getChildAt(j);
          localAutoCompleteTextView.setFocusable(true);
          localAutoCompleteTextView.requestFocus();
          localAutoCompleteTextView.setFocusableInTouchMode(true);
        }
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.dialogmanager.MaterialDialog
 * JD-Core Version:    0.6.0
 */