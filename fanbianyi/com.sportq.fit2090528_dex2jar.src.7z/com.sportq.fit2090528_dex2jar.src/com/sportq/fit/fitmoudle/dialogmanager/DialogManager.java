package com.sportq.fit.fitmoudle.dialogmanager;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Html.ImageGetter;
import android.text.SpannableString;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.TimePicker;
import com.bartoszlipinski.recyclerviewheader.RecyclerViewHeader;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.OnNoticTimeListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.ShareUIFunctionListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.TrainFeedBcakListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.WeekMoreClickListener;
import com.sportq.fit.common.interfaces.presenter.video.Callback;
import com.sportq.fit.common.model.ModelListener;
import com.sportq.fit.common.model.NoticeModel;
import com.sportq.fit.common.model.NoticeWeekModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.imageloader.QueueCallback;
import com.sportq.fit.common.utils.superView.RRelativeLayout;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RBaseHelper;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.sharemanager.ShareAdapter;
import com.sportq.fit.fitmoudle.sharemanager.ShareListenerFunction;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.ShareItemModel;
import com.sportq.fit.fitmoudle.widget.CustomDialogView;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.uicommon.R.color;
import com.sportq.fit.uicommon.R.drawable;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;
import com.sportq.fit.uicommon.R.mipmap;
import com.sportq.fit.uicommon.R.string;
import com.sportq.fit.uicommon.R.style;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DialogManager
  implements com.sportq.fit.common.interfaces.dialog.DialogInterface
{
  private Boolean checkflg = Boolean.valueOf(true);
  Dialog dialog1_1_1;
  NoticeModel noticeModel_s;
  private Dialog opeExecuteDialog;
  private TextView opeExecuteText;

  private void addNormalShareModel(List<ModelListener> paramList, int paramInt)
  {
    ShareItemModel localShareItemModel = new ShareItemModel();
    localShareItemModel.fromFlg = "1";
    switch (paramInt)
    {
    default:
    case 100:
    case 101:
    case 102:
    case 103:
    case 104:
    }
    while (true)
    {
      paramList.add(localShareItemModel);
      return;
      localShareItemModel.icon = R.drawable.ssdk_oks_classic_wechatmoments;
      localShareItemModel.name = "朋友圈";
      localShareItemModel.code = 100;
      continue;
      localShareItemModel.icon = R.drawable.ssdk_oks_classic_wechat;
      localShareItemModel.name = "微信";
      localShareItemModel.code = 101;
      continue;
      localShareItemModel.icon = R.drawable.ssdk_oks_classic_sinaweibo;
      localShareItemModel.name = "微博";
      localShareItemModel.code = 102;
      continue;
      localShareItemModel.icon = R.drawable.ssdk_oks_classic_qq;
      localShareItemModel.name = "QQ好友";
      localShareItemModel.code = 103;
      continue;
      localShareItemModel.icon = R.drawable.ssdk_oks_classic_qzone;
      localShareItemModel.name = "QQ空间";
      localShareItemModel.code = 104;
    }
  }

  private boolean checkWeekItemIsShow(List<NoticeWeekModel> paramList)
  {
    int i = 0;
    for (int j = 0; ; j++)
    {
      if (j < paramList.size())
      {
        NoticeWeekModel localNoticeWeekModel = (NoticeWeekModel)paramList.get(j);
        if (!Constant.STR_1.equals(localNoticeWeekModel.showOnOff))
          continue;
        i++;
        if (i <= 2)
          continue;
      }
      if (i > 1)
        break;
      return true;
    }
    return false;
  }

  public static List<ResolveInfo> getShareApps(Context paramContext)
  {
    Intent localIntent = new Intent("android.intent.action.SEND", null);
    localIntent.addCategory("android.intent.category.DEFAULT");
    localIntent.setType("text/plain");
    return paramContext.getPackageManager().queryIntentActivities(localIntent, 0);
  }

  public static Dialog guide_Dialog(Context paramContext, int paramInt1, int paramInt2)
  {
    Dialog localDialog = new Dialog(paramContext);
    DisplayMetrics localDisplayMetrics = new DisplayMetrics();
    ((Activity)paramContext).getWindowManager().getDefaultDisplay().getMetrics(localDisplayMetrics);
    if ((localDisplayMetrics.widthPixels > 0) && (localDisplayMetrics.heightPixels > 0))
      BaseApplication.screenWidth = localDisplayMetrics.widthPixels;
    int i = BaseApplication.screenWidth;
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setContentView(paramInt1);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    if (paramInt2 == 0)
      localLayoutParams.width = i;
    while (true)
    {
      localDialog.getWindow().setAttributes(localLayoutParams);
      return localDialog;
      if (paramInt2 != 1)
        continue;
      localLayoutParams.width = -2;
    }
  }

  private View weekItemView(Context paramContext, NoticeWeekModel paramNoticeWeekModel, int paramInt)
  {
    View localView = LayoutInflater.from(paramContext).inflate(R.layout.mine03_set_notice_week, null);
    int i = (int)(0.8611D * BaseApplication.screenWidth) - CompDeviceInfoUtils.convertOfDip(paramContext, 48.0F) - 6 * CompDeviceInfoUtils.convertOfDip(paramContext, 3.0F);
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(i / 7, i / 7);
    if (paramInt != 0)
      localLayoutParams.leftMargin = CompDeviceInfoUtils.convertOfDip(paramContext, 3.0F);
    localView.setLayoutParams(localLayoutParams);
    RTextView localRTextView = (RTextView)localView.findViewById(R.id.mine03_week_item_view);
    localRTextView.getLayoutParams().width = (i / 7);
    localRTextView.getLayoutParams().height = (i / 7);
    RTextViewHelper localRTextViewHelper = localRTextView.getHelper();
    localRTextViewHelper.setCornerRadius(i / 7 / 2);
    localRTextView.setText(paramNoticeWeekModel.day);
    if (Constant.STR_1.equals(paramNoticeWeekModel.showOnOff))
    {
      localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(paramContext, R.color.color_ffd208));
      localRTextView.setTextColor(ContextCompat.getColor(paramContext, R.color.color_313131));
    }
    while (true)
    {
      localView.setOnClickListener(new FitAction(null, paramInt, localRTextView, localRTextViewHelper, paramContext)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          NoticeWeekModel localNoticeWeekModel = (NoticeWeekModel)DialogManager.this.noticeModel_s.weekList.get(this.val$position);
          this.val$itemView.setText(localNoticeWeekModel.day);
          if (Constant.STR_0.equals(localNoticeWeekModel.showOnOff))
          {
            this.val$rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this.val$context, R.color.color_ffd208));
            this.val$itemView.setTextColor(ContextCompat.getColor(this.val$context, R.color.color_313131));
          }
          for (((NoticeWeekModel)DialogManager.this.noticeModel_s.weekList.get(this.val$position)).showOnOff = Constant.STR_1; ; ((NoticeWeekModel)DialogManager.this.noticeModel_s.weekList.get(this.val$position)).showOnOff = Constant.STR_0)
          {
            super.onClick(paramView);
            do
              return;
            while (DialogManager.this.checkWeekItemIsShow(DialogManager.this.noticeModel_s.weekList));
            this.val$rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this.val$context, R.color.color_e6e6e6));
            this.val$itemView.setTextColor(ContextCompat.getColor(this.val$context, R.color.color_c8c8c8));
          }
        }
      });
      return localView;
      localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(paramContext, R.color.color_e6e6e6));
      localRTextView.setTextColor(ContextCompat.getColor(paramContext, R.color.color_c8c8c8));
    }
  }

  public void appHintDialog(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, int paramInt, String paramString1, String paramString2)
  {
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setCancelable(true);
    localDialog.setContentView(R.layout.app_hint_layout);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    ((ImageView)localDialog.findViewById(R.id.hint_img)).setImageResource(paramInt);
    ((TextView)localDialog.findViewById(R.id.hint_content)).setText(paramString1);
    RTextView localRTextView = (RTextView)localDialog.findViewById(R.id.hint_bottom_btn);
    localRTextView.setText(paramString2);
    localRTextView.setOnClickListener(new View.OnClickListener(paramDialogListener, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (this.val$listener != null)
          this.val$listener.onDialogClick(null, -1);
        this.val$dialog.dismiss();
      }
    });
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public void closeDialog()
  {
    try
    {
      if ((this.opeExecuteDialog != null) && (this.opeExecuteDialog.isShowing()))
      {
        this.opeExecuteDialog.dismiss();
        this.opeExecuteDialog = null;
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void creatChooseWeekDialog(Context paramContext, NoticeModel paramNoticeModel, FitInterfaceUtils.WeekMoreClickListener paramWeekMoreClickListener)
  {
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setContentView(R.layout.choose_week_dialog);
    this.noticeModel_s = paramNoticeModel;
    LinearLayout localLinearLayout = (LinearLayout)localDialog.findViewById(R.id.dialog_week_list);
    RTextView localRTextView1 = (RTextView)localDialog.findViewById(R.id.dialog_week_confirm_btn);
    RTextView localRTextView2 = (RTextView)localDialog.findViewById(R.id.dialog_week_up_btn);
    for (int i = 0; i < this.noticeModel_s.weekList.size(); i++)
      localLinearLayout.addView(weekItemView(paramContext, (NoticeWeekModel)this.noticeModel_s.weekList.get(i), i));
    localRTextView1.setOnClickListener(new FitAction(null, paramWeekMoreClickListener, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        this.val$listener.onRightClick(DialogManager.this.noticeModel_s);
        this.val$dialog.dismiss();
        super.onClick(paramView);
      }
    });
    localRTextView2.setOnClickListener(new FitAction(null, paramWeekMoreClickListener, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        this.val$listener.onBackClick(DialogManager.this.noticeModel_s.noticeTime);
        this.val$dialog.dismiss();
        super.onClick(paramView);
      }
    });
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.8611D * BaseApplication.screenWidth);
    localDialog.getWindow().setAttributes(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public void creatTimeDialog(Context paramContext, TextView paramTextView, FitInterfaceUtils.OnNoticTimeListener paramOnNoticTimeListener, int paramInt)
  {
    String[] arrayOfString = paramTextView.getText().toString().split(":");
    int i = Integer.valueOf(arrayOfString[0]).intValue();
    int j = Integer.valueOf(arrayOfString[1]).intValue();
    MyTimePickerDialog localMyTimePickerDialog = new MyTimePickerDialog(paramContext, new TimePickerDialog.OnTimeSetListener(paramOnNoticTimeListener, paramTextView, paramInt)
    {
      public void onTimeSet(TimePicker paramTimePicker, int paramInt1, int paramInt2)
      {
        if (DialogManager.this.checkflg.booleanValue())
          DialogManager.access$302(DialogManager.this, Boolean.valueOf(false));
        if (String.valueOf(paramInt2).length() == 1);
        String str2;
        for (String str1 = "0" + paramInt2; ; str1 = String.valueOf(paramInt2))
        {
          str2 = paramInt1 + ":" + str1;
          if (!this.val$listener.checkTimeCopy(str2))
            break;
          return;
        }
        this.val$mineNoticeTime.setText(str2);
        this.val$listener.updateTime(paramInt1 + ":" + str1, this.val$position);
        BaseApplication.userModel.remindTime = (paramInt1 + ":" + str1);
      }
    }
    , i, j, true);
    localMyTimePickerDialog.show();
    VdsAgent.showDialog((TimePickerDialog)localMyTimePickerDialog);
  }

  public void creatTimeDialog(Context paramContext, String paramString, TimePickerDialog.OnTimeSetListener paramOnTimeSetListener)
  {
    String[] arrayOfString = paramString.split(":");
    TimePickerDialog localTimePickerDialog = new TimePickerDialog(paramContext, paramOnTimeSetListener, Integer.valueOf(arrayOfString[0]).intValue(), Integer.valueOf(arrayOfString[1]).intValue(), true);
    localTimePickerDialog.show();
    VdsAgent.showDialog((TimePickerDialog)localTimePickerDialog);
  }

  public void createAdPopDialog(FitInterfaceUtils.DialogListener paramDialogListener, String paramString, Context paramContext)
  {
    try
    {
      Dialog localDialog = new Dialog(paramContext);
      localDialog.requestWindowFeature(1);
      localDialog.getWindow().setBackgroundDrawableResource(17170445);
      localDialog.setCanceledOnTouchOutside(true);
      localDialog.setCancelable(true);
      localDialog.setContentView(R.layout.ad_pop_layout);
      WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
      localLayoutParams.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
      localLayoutParams.height = (int)(1.3077D * (0.9028000000000001D * BaseApplication.screenWidth));
      localLayoutParams.gravity = 17;
      localDialog.getWindow().setAttributes(localLayoutParams);
      ImageView localImageView1 = (ImageView)localDialog.findViewById(R.id.ad_pop_img);
      GlideUtils.loadImgByRadius(paramString, R.mipmap.img_default, 8.0F, localImageView1);
      ImageView localImageView2 = (ImageView)localDialog.findViewById(R.id.close_btn);
      localImageView1.setOnClickListener(new View.OnClickListener(paramDialogListener, localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (this.val$listener != null)
            this.val$listener.onDialogClick(this.val$dialog, -1);
          this.val$dialog.dismiss();
        }
      });
      localImageView2.setOnClickListener(new View.OnClickListener(paramDialogListener, localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (this.val$listener != null)
            this.val$listener.onDialogClick(this.val$dialog, -2);
          this.val$dialog.dismiss();
        }
      });
      localDialog.setOnDismissListener(new DialogInterface.OnDismissListener(paramDialogListener)
      {
        public void onDismiss(android.content.DialogInterface paramDialogInterface)
        {
          if (this.val$listener != null)
            this.val$listener.onDialogClick(paramDialogInterface, -3);
        }
      });
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public Dialog createChoiceDialog(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String paramString1, String paramString2)
  {
    return createChoiceDialog(paramDialogListener, paramContext, paramString1, paramString2, paramContext.getResources().getString(R.string.make_sure), paramContext.getResources().getString(R.string.cancel_hint));
  }

  public Dialog createChoiceDialog(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return createChoiceDialogWithColor(paramDialogListener, paramContext, paramString1, paramString2, paramString3, paramString4, R.color.color_ffd208, R.color.color_e6e6e6, R.color.color_313131, R.color.color_626262);
  }

  public Dialog createChoiceDialog(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
  {
    return createChoiceDialogWithColor(paramDialogListener, paramContext, paramString1, paramString2, paramString3, paramString4, R.color.color_ffd208, R.color.color_e6e6e6, R.color.color_313131, R.color.color_626262, paramBoolean);
  }

  public Dialog createChoiceDialogWithColor(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return createChoiceDialogWithColor(paramDialogListener, paramContext, paramString1, paramString2, paramString3, paramString4, paramInt1, paramInt2, paramInt3, paramInt4, false);
  }

  public Dialog createChoiceDialogWithColor(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    if ((paramDialogListener == null) || (((Activity)paramContext).isFinishing()))
      return new Dialog(paramContext);
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setCancelable(true);
    localDialog.setContentView(R.layout.choice_dialog_view);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.gravity = 17;
    localLayoutParams.width = (int)(0.861D * BaseApplication.screenWidth);
    localDialog.getWindow().setAttributes(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
    TextView localTextView1 = (TextView)localDialog.findViewById(R.id.msg_hint);
    LinearLayout localLinearLayout = (LinearLayout)localDialog.findViewById(R.id.bottom_layout);
    int i;
    RTextView localRTextView1;
    LinearLayout.LayoutParams localLayoutParams1;
    RTextView localRTextView2;
    LinearLayout.LayoutParams localLayoutParams2;
    label430: TextView localTextView2;
    if (paramBoolean)
    {
      i = 1;
      localLinearLayout.setOrientation(i);
      localRTextView1 = new RTextView(paramContext);
      RTextViewHelper localRTextViewHelper1 = localRTextView1.getHelper();
      localRTextViewHelper1.setBackgroundColorNormal(ContextCompat.getColor(paramContext, paramInt1));
      localRTextViewHelper1.setCornerRadius(CompDeviceInfoUtils.convertOfDip(paramContext, 25.0F));
      localRTextView1.setTextColor(ContextCompat.getColor(paramContext, paramInt3));
      localRTextView1.setTextSize(16.0F);
      localRTextView1.setText(paramString3);
      localRTextView1.setGravity(17);
      localLayoutParams1 = new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(paramContext, 50.0F));
      localLayoutParams1.weight = 1.0F;
      localRTextView2 = new RTextView(paramContext);
      RTextViewHelper localRTextViewHelper2 = localRTextView2.getHelper();
      localRTextViewHelper2.setBackgroundColorNormal(ContextCompat.getColor(paramContext, paramInt2));
      localRTextViewHelper2.setCornerRadius(CompDeviceInfoUtils.convertOfDip(paramContext, 25.0F));
      localRTextView2.setTextColor(ContextCompat.getColor(paramContext, paramInt4));
      localRTextView2.setText(paramString4);
      localRTextView2.setTextSize(16.0F);
      localRTextView2.setGravity(17);
      localLayoutParams2 = new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(paramContext, 50.0F));
      localLayoutParams2.weight = 1.0F;
      if (!paramBoolean)
        break label518;
      localLayoutParams1.bottomMargin = CompDeviceInfoUtils.convertOfDip(paramContext, 19.5F);
      localLayoutParams1.leftMargin = 0;
      localLayoutParams2.bottomMargin = 0;
      localLayoutParams2.rightMargin = 0;
      if (!StringUtils.isNull(paramString3))
        localLinearLayout.addView(localRTextView1, localLayoutParams1);
      if (!StringUtils.isNull(paramString4))
        localLinearLayout.addView(localRTextView2, localLayoutParams2);
      localTextView2 = (TextView)localDialog.findViewById(R.id.title);
      if (StringUtils.isNull(paramString1))
        break label591;
      localTextView2.setVisibility(0);
      localTextView2.setText(paramString1);
    }
    while (true)
    {
      if (!StringUtils.isNull(paramString2))
        localTextView1.setText(paramString2);
      localRTextView1.setOnClickListener(new View.OnClickListener(localDialog, paramDialogListener)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$dialog.dismiss();
          this.val$listener.onDialogClick(this.val$dialog, -1);
        }
      });
      localRTextView2.setOnClickListener(new View.OnClickListener(localDialog, paramDialogListener)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$dialog.dismiss();
          this.val$listener.onDialogClick(this.val$dialog, -2);
        }
      });
      return localDialog;
      i = 0;
      break;
      label518: localLayoutParams1.leftMargin = CompDeviceInfoUtils.convertOfDip(paramContext, 7.5F);
      localLayoutParams1.bottomMargin = 0;
      localLayoutParams2.rightMargin = CompDeviceInfoUtils.convertOfDip(paramContext, 7.5F);
      localLayoutParams2.bottomMargin = 0;
      if (!StringUtils.isNull(paramString4))
        localLinearLayout.addView(localRTextView2, localLayoutParams2);
      if (StringUtils.isNull(paramString3))
        break label430;
      localLinearLayout.addView(localRTextView1, localLayoutParams1);
      break label430;
      label591: localTextView2.setVisibility(8);
    }
  }

  public Dialog createDialog(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String[] paramArrayOfString)
  {
    if ((paramDialogListener == null) || (paramArrayOfString == null) || (paramArrayOfString.length == 0))
      return null;
    return createDialog(paramDialogListener, paramContext, paramArrayOfString, (int)(0.5D * BaseApplication.screenWidth), (int)(0.2778D * (0.5D * BaseApplication.screenWidth)));
  }

  public Dialog createDialog(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String[] paramArrayOfString, int paramInt1, int paramInt2)
  {
    if ((paramDialogListener == null) || (paramArrayOfString == null) || (paramArrayOfString.length == 0))
      return null;
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setCancelable(true);
    CustomDialogView localCustomDialogView = new CustomDialogView(paramContext);
    localCustomDialogView.setData(new FitInterfaceUtils.DialogListener(paramDialogListener, localDialog)
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        this.val$listener.onDialogClick(null, paramInt);
        this.val$dialog.dismiss();
      }
    }
    , paramArrayOfString);
    localDialog.setContentView(localCustomDialogView);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = paramInt1;
    localLayoutParams.height = (paramInt2 * paramArrayOfString.length);
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
    return localDialog;
  }

  public Dialog createEnergyHintDialog(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String paramString1, String paramString2)
  {
    if (paramDialogListener == null)
      return null;
    return createEnergyHintDialog(paramDialogListener, paramContext, paramString1, paramString2, "");
  }

  public Dialog createEnergyHintDialog(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    if (paramDialogListener == null)
      return null;
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    View localView1 = LayoutInflater.from(paramContext).inflate(R.layout.energy_hint_layout, null);
    RRelativeLayout localRRelativeLayout = (RRelativeLayout)localView1.findViewById(R.id.base_layout);
    int[] arrayOfInt = new int[2];
    String[] arrayOfString = new String[2];
    int i = -1;
    View localView2;
    label153: RTextView localRTextView1;
    RTextView localRTextView2;
    switch (paramString1.hashCode())
    {
    default:
      switch (i)
      {
      default:
        localView2 = LayoutInflater.from(paramContext).inflate(R.layout.energy_header_layout01, null);
        RelativeLayout localRelativeLayout = (RelativeLayout)localView1.findViewById(R.id.custom_view);
        RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(-1, -2);
        localLayoutParams.addRule(2, R.id.energy_select_layout);
        localRelativeLayout.addView(localView2, localLayoutParams);
        localDialog.setContentView(localView1);
        localRTextView1 = (RTextView)localDialog.findViewById(R.id.view_cancel);
        localRTextView2 = (RTextView)localDialog.findViewById(R.id.view_confirm);
        localRTextView1.getHelper().setBackgroundColorNormal(ContextCompat.getColor(paramContext, arrayOfInt[0]));
        localRTextView2.getHelper().setBackgroundColorNormal(ContextCompat.getColor(paramContext, arrayOfInt[1]));
        localRTextView1.setText(arrayOfString[0]);
        localRTextView2.setText(arrayOfString[1]);
        if (!"2".equals(paramString1));
      case 0:
      case 1:
      case 2:
      case 3:
      }
    case 48:
    case 49:
    case 50:
    case 51:
    }
    for (int k = R.color.white; ; k = R.color.color_626262)
    {
      localRTextView1.setTextColor(ContextCompat.getColor(paramContext, k));
      14 local14 = new FitAction(null, localDialog, paramDialogListener)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$dialog.dismiss();
          this.val$listener.onDialogClick(this.val$dialog, -1);
          super.onClick(paramView);
        }
      };
      localRTextView1.setOnClickListener(local14);
      15 local15 = new FitAction(null, localDialog, paramDialogListener)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$dialog.dismiss();
          this.val$listener.onDialogClick(this.val$dialog, -2);
          super.onClick(paramView);
        }
      };
      localRTextView2.setOnClickListener(local15);
      WindowManager.LayoutParams localLayoutParams1 = localDialog.getWindow().getAttributes();
      localLayoutParams1.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
      localLayoutParams1.height = -2;
      localLayoutParams1.gravity = 17;
      localDialog.getWindow().setAttributes(localLayoutParams1);
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      return localDialog;
      if (!paramString1.equals("0"))
        break;
      i = 0;
      break;
      if (!paramString1.equals("1"))
        break;
      i = 1;
      break;
      if (!paramString1.equals("2"))
        break;
      i = 2;
      break;
      if (!paramString1.equals("3"))
        break;
      i = 3;
      break;
      localView2 = LayoutInflater.from(paramContext).inflate(R.layout.energy_header_layout01, null);
      arrayOfInt[0] = R.color.color_e6e6e6;
      arrayOfInt[1] = R.color.color_ffd208;
      arrayOfString[0] = paramContext.getString(R.string.b_65_3);
      arrayOfString[1] = paramContext.getString(R.string.b_65_4);
      localRRelativeLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(paramContext, R.color.white));
      RTextView localRTextView3 = (RTextView)localView2.findViewById(R.id.use_time);
      localRTextView3.setTypeface(TextUtils.getFontFaceImpact());
      localRTextView3.setText(paramString2);
      ((TextView)localView2.findViewById(R.id.use_time_unit)).setTypeface(TextUtils.getFontFaceImpact());
      ((TextView)localView2.findViewById(R.id.energy_course_use_time)).setText(String.format(StringUtils.getStringResources(R.string.b_65_2), new Object[] { paramString2 }));
      break label153;
      localView2 = LayoutInflater.from(paramContext).inflate(R.layout.energy_header_layout02, null);
      arrayOfInt[0] = R.color.color_e6e6e6;
      arrayOfInt[1] = R.color.color_ffd208;
      arrayOfString[0] = paramContext.getString(R.string.b_66_3);
      arrayOfString[1] = paramContext.getString(R.string.b_66_4);
      localRRelativeLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(paramContext, R.color.white));
      TextView localTextView3 = (TextView)localView2.findViewById(R.id.need_consume_value);
      localTextView3.setTypeface(TextUtils.getFontFaceImpact());
      localTextView3.setText(paramString2);
      ((TextView)localView2.findViewById(R.id.mine_energy_value)).setText(StringUtils.getStringResources(R.string.b_66_2) + " " + BaseApplication.userModel.energyValue);
      break label153;
      localView2 = LayoutInflater.from(paramContext).inflate(R.layout.energy_header_layout03, null);
      arrayOfInt[0] = R.color.color_e74824;
      arrayOfInt[1] = R.color.color_ffd208;
      arrayOfString[0] = paramContext.getString(R.string.b_67_2);
      arrayOfString[1] = paramContext.getString(R.string.b_67_3);
      localRRelativeLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(paramContext, R.color.color_ff6a49));
      break label153;
      localView2 = LayoutInflater.from(paramContext).inflate(R.layout.energy_header_layout04, null);
      arrayOfInt[0] = R.color.color_e6e6e6;
      arrayOfInt[1] = R.color.color_ffd208;
      arrayOfString[0] = StringUtils.getStringResources(R.string.b_70_3);
      arrayOfString[1] = StringUtils.getStringResources(R.string.b_70_4);
      localRRelativeLayout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(paramContext, R.color.white));
      TextView localTextView1 = (TextView)localView2.findViewById(R.id.course_expire_hint);
      TextView localTextView2 = (TextView)localView2.findViewById(R.id.course_expire);
      String str;
      if ("action".equals(paramString3))
      {
        str = paramContext.getString(R.string.b_105_1);
        label942: localTextView2.setText(str);
        if (!"action".equals(paramString3))
          break label999;
      }
      label999: for (int j = R.string.b_105_2; ; j = R.string.b_70_2)
      {
        localTextView1.setText(UseStringUtils.getStr(j, new String[] { paramString2 }));
        break;
        str = paramContext.getString(R.string.b_70_1);
        break label942;
      }
    }
  }

  public void createListDialog(FitInterfaceUtils.DialogListener paramDialogListener, Context paramContext, String paramString, String[] paramArrayOfString)
  {
    if (paramDialogListener == null)
      return;
    try
    {
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(paramContext);
      localBuilder.setTitle(paramString);
      localBuilder.setItems(paramArrayOfString, new DialogInterface.OnClickListener(paramDialogListener)
      {
        @Instrumented
        public void onClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          VdsAgent.onClick(this, paramDialogInterface, paramInt);
          this.val$listener.onDialogClick(paramDialogInterface, paramInt);
        }
      });
      AlertDialog localAlertDialog = localBuilder.create();
      localAlertDialog.show();
      VdsAgent.showDialog((Dialog)localAlertDialog);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void createProgressDialog(Context paramContext, String paramString)
  {
    try
    {
      this.opeExecuteDialog = new Dialog(paramContext);
      this.opeExecuteDialog.requestWindowFeature(1);
      this.opeExecuteDialog.getWindow().setBackgroundDrawableResource(17170445);
      this.opeExecuteDialog.setCanceledOnTouchOutside(false);
      this.opeExecuteDialog.setContentView(R.layout.operate_execute_dialog);
      CompDeviceInfoUtils.getDeviceWidthHeight(paramContext);
      WindowManager.LayoutParams localLayoutParams = this.opeExecuteDialog.getWindow().getAttributes();
      localLayoutParams.width = BaseApplication.screenWidth;
      localLayoutParams.gravity = 16;
      this.opeExecuteDialog.getWindow().setAttributes(localLayoutParams);
      ((ProgressBar)this.opeExecuteDialog.findViewById(R.id.operate_execute_loader_icon01)).setVisibility(0);
      this.opeExecuteText = ((TextView)this.opeExecuteDialog.findViewById(R.id.operate_execute_text));
      if (!StringUtils.isNull(paramString))
      {
        this.opeExecuteText.setText(paramString);
        this.opeExecuteText.setVisibility(0);
      }
      while (true)
      {
        Dialog localDialog = this.opeExecuteDialog;
        localDialog.show();
        VdsAgent.showDialog((Dialog)localDialog);
        return;
        this.opeExecuteText.setVisibility(8);
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void createToastDialog(Context paramContext, String paramString)
  {
    try
    {
      Dialog localDialog = new Dialog(paramContext);
      localDialog.requestWindowFeature(1);
      localDialog.getWindow().setBackgroundDrawableResource(17170445);
      localDialog.setCanceledOnTouchOutside(true);
      localDialog.setCancelable(true);
      localDialog.setContentView(R.layout.choice_dialog_view);
      WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
      localLayoutParams.gravity = 17;
      localDialog.getWindow().setAttributes(localLayoutParams);
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      TextView localTextView1 = (TextView)localDialog.findViewById(R.id.msg_hint);
      TextView localTextView2 = (TextView)localDialog.findViewById(R.id.confirm_btn);
      TextView localTextView3 = (TextView)localDialog.findViewById(R.id.cancel_btn);
      ((TextView)localDialog.findViewById(R.id.title)).setVisibility(8);
      localTextView3.setVisibility(8);
      localTextView1.setText(paramString);
      localTextView2.setText(paramContext.getResources().getString(R.string.make_sure));
      localTextView2.setOnClickListener(new View.OnClickListener(localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$dialog.dismiss();
        }
      });
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void setProDialogTextHint(String paramString)
  {
    try
    {
      if (this.opeExecuteText != null)
        this.opeExecuteText.setText(paramString);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  @TargetApi(20)
  public void shareDialog1_1_1(Context paramContext, int paramInt, Object paramObject, FitInterfaceUtils.ShareUIFunctionListener paramShareUIFunctionListener, com.sportq.fit.common.interfaces.dialog.DialogInterface paramDialogInterface, int[] paramArrayOfInt)
  {
    shareDialog1_2(paramContext, paramInt, paramObject, null, paramDialogInterface, null, new int[0]);
  }

  public void shareDialog1_2(Context paramContext, int paramInt, Object paramObject, FitInterfaceUtils.ShareUIFunctionListener paramShareUIFunctionListener, com.sportq.fit.common.interfaces.dialog.DialogInterface paramDialogInterface, Callback paramCallback, int[] paramArrayOfInt)
  {
    if ((this.dialog1_1_1 != null) && (this.dialog1_1_1.isShowing()))
      return;
    this.dialog1_1_1 = new Dialog(paramContext);
    this.dialog1_1_1.requestWindowFeature(1);
    this.dialog1_1_1.getWindow().setBackgroundDrawableResource(17170445);
    this.dialog1_1_1.setCanceledOnTouchOutside(true);
    this.dialog1_1_1.setContentView(R.layout.share_dialog_1_1_1);
    this.dialog1_1_1.getWindow().setWindowAnimations(R.style.dialogWindowAnim);
    WindowManager.LayoutParams localLayoutParams = this.dialog1_1_1.getWindow().getAttributes();
    localLayoutParams.width = BaseApplication.screenWidth;
    localLayoutParams.height = -2;
    localLayoutParams.gravity = 80;
    this.dialog1_1_1.getWindow().setAttributes(localLayoutParams);
    ArrayList localArrayList = new ArrayList();
    if (paramObject != null)
    {
      addNormalShareModel(localArrayList, 100);
      addNormalShareModel(localArrayList, 101);
      addNormalShareModel(localArrayList, 102);
      addNormalShareModel(localArrayList, 103);
      addNormalShareModel(localArrayList, 104);
      List localList = getShareApps(paramContext);
      PackageManager localPackageManager = paramContext.getPackageManager();
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        ResolveInfo localResolveInfo = (ResolveInfo)localIterator.next();
        String str1 = localResolveInfo.activityInfo.applicationInfo.loadLabel(localPackageManager).toString();
        String str2 = localResolveInfo.loadLabel(localPackageManager).toString();
        if (("QQ".equals(str1)) || ("微信".equals(str1)) || ("微博".equals(str1)))
          continue;
        ShareItemModel localShareItemModel2 = new ShareItemModel();
        localShareItemModel2.fromFlg = "2";
        localShareItemModel2.resolveInfo = localResolveInfo;
        localShareItemModel2.packageName = localResolveInfo.activityInfo.applicationInfo.packageName;
        localShareItemModel2.icon_drawable = localResolveInfo.loadIcon(localPackageManager);
        localShareItemModel2.name = str2;
        localShareItemModel2.code = 6;
        localArrayList.add(localShareItemModel2);
      }
    }
    int i = localArrayList.size() % 4;
    if (i != 0)
      while (i != 4)
      {
        ShareItemModel localShareItemModel1 = new ShareItemModel();
        localShareItemModel1.fromFlg = "3";
        localShareItemModel1.name = "";
        localShareItemModel1.icon = -1;
        localArrayList.add(localShareItemModel1);
        i++;
      }
    RecyclerViewHeader localRecyclerViewHeader = RecyclerViewHeader.fromXml(paramContext, R.layout.dialog_header_1_1_1);
    RelativeLayout localRelativeLayout = (RelativeLayout)localRecyclerViewHeader.findViewById(R.id.tmp_rl);
    int j = 270 * (localArrayList.size() / 4);
    int k;
    if (j < (int)(0.4D * BaseApplication.screenHeight))
      k = BaseApplication.screenHeight - j - CompDeviceInfoUtils.getStatusBarHeight(paramContext);
    while (true)
    {
      LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(BaseApplication.screenWidth, k);
      localRelativeLayout.setLayoutParams(localLayoutParams1);
      localRecyclerViewHeader.setOnClickListener(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          DialogManager.this.dialog1_1_1.dismiss();
        }
      });
      RecyclerView localRecyclerView = (RecyclerView)this.dialog1_1_1.findViewById(R.id.share_recyclerView);
      ShareAdapter localShareAdapter = new ShareAdapter(paramContext, localArrayList, R.layout.share_item_03, paramShareUIFunctionListener);
      localRecyclerView.setLayoutManager(new GridLayoutManager(paramContext, 4));
      localShareAdapter.setShareListenerFunction(new ShareListenerFunction(paramContext, paramInt, paramObject, this.dialog1_1_1, paramDialogInterface, paramCallback));
      localShareAdapter.setDialog(this.dialog1_1_1);
      localRecyclerView.setAdapter(localShareAdapter);
      localRecyclerViewHeader.attachTo(localRecyclerView);
      Dialog localDialog = this.dialog1_1_1;
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      return;
      if (localArrayList.size() / 4 == 2)
      {
        k = (int)(0.8D * BaseApplication.screenHeight);
        continue;
      }
      k = (int)(0.6D * BaseApplication.screenHeight);
    }
  }

  @TargetApi(21)
  public void showShareChoiseDialog(Context paramContext, int paramInt, Object paramObject, com.sportq.fit.common.interfaces.dialog.DialogInterface paramDialogInterface)
  {
    shareDialog1_1_1(paramContext, paramInt, paramObject, null, paramDialogInterface, new int[0]);
  }

  public void showTrainDetailsIntro(Context paramContext, PlanModel paramPlanModel)
  {
    try
    {
      Dialog localDialog = new Dialog(paramContext);
      localDialog.requestWindowFeature(1);
      localDialog.getWindow().setBackgroundDrawableResource(17170445);
      localDialog.setCanceledOnTouchOutside(false);
      localDialog.setContentView(R.layout.train_details_intro_dialog);
      WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
      localLayoutParams.height = BaseApplication.screenHeight;
      localLayoutParams.width = BaseApplication.screenWidth;
      localLayoutParams.gravity = 17;
      localDialog.getWindow().setAttributes(localLayoutParams);
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      ((RelativeLayout)localDialog.findViewById(R.id.close_layout)).setOnClickListener(new View.OnClickListener(paramContext, localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          FitAction.temporaryPCC(this.val$context.getResources().getString(R.string.stats_b1_19_exitBtn));
          this.val$dialog.dismiss();
        }
      });
      TextView localTextView = (TextView)localDialog.findViewById(R.id.train_intro);
      if (paramPlanModel.detailSummary != null)
      {
        localTextView.setVisibility(0);
        localTextView.setText(Html.fromHtml(paramPlanModel.detailSummary, new URLImageParser(localTextView, null), null));
        localTextView.setLineSpacing(0.0F, 1.2F);
        localTextView.setMovementMethod(ScrollingMovementMethod.getInstance());
        return;
      }
      localTextView.setVisibility(8);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void showWebImg(Context paramContext, int paramInt1, int paramInt2, ArrayList<String> paramArrayList, int paramInt3)
  {
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setContentView(R.layout.show_web_img_dialog);
    ViewPager localViewPager = (ViewPager)localDialog.findViewById(R.id.view_pager);
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      View localView = View.inflate(paramContext, R.layout.web_img_item_layout, null);
      ImageView localImageView = (ImageView)localView.findViewById(R.id.web_img);
      GlideUtils.loadImgByOptions(new RequestOptions().diskCacheStrategy(DiskCacheStrategy.RESOURCE).centerInside(), str, localImageView);
      localView.setOnClickListener(new View.OnClickListener(localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$dialog.dismiss();
        }
      });
      localArrayList.add(localView);
    }
    localViewPager.setAdapter(new CustomViewPagerAdapter(localArrayList));
    localViewPager.setCurrentItem(paramInt3);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.height = paramInt2;
    localLayoutParams.width = paramInt1;
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public void trainFeedBackFillInContactDialog(Context paramContext, FitInterfaceUtils.TrainFeedBcakListener paramTrainFeedBcakListener)
  {
    try
    {
      Dialog localDialog = new Dialog(paramContext);
      localDialog.requestWindowFeature(1);
      localDialog.getWindow().setBackgroundDrawableResource(17170445);
      localDialog.setCanceledOnTouchOutside(false);
      localDialog.setCancelable(false);
      localDialog.setContentView(R.layout.train_feedback_layout);
      WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
      localLayoutParams.gravity = 17;
      localDialog.getWindow().setAttributes(localLayoutParams);
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      EditText localEditText = (EditText)localDialog.findViewById(R.id.train_feedback_editText);
      TextView localTextView1 = (TextView)localDialog.findViewById(R.id.train_feedback_confirm_btn);
      TextView localTextView2 = (TextView)localDialog.findViewById(R.id.train_feedback_anonymous_submi_btn);
      localTextView1.setOnClickListener(new View.OnClickListener(localEditText, paramContext, localDialog, paramTrainFeedBcakListener)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          String str = this.val$editText.getText().toString();
          if (StringUtils.isNull(str))
          {
            ToastUtils.makeToast(this.val$context, "请填写联系方式");
            return;
          }
          this.val$dialog.dismiss();
          this.val$listener.onBtnClick(str);
        }
      });
      localTextView2.setOnClickListener(new View.OnClickListener(localDialog, paramTrainFeedBcakListener)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$dialog.dismiss();
          this.val$listener.onBtnClick("");
        }
      });
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void zeroVipShareDialog(Context paramContext, String paramString, FitInterfaceUtils.DialogListener paramDialogListener)
  {
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(false);
    localDialog.setCancelable(false);
    View localView = View.inflate(paramContext, R.layout.vip_active_share_layout, null);
    TextView localTextView = (TextView)localView.findViewById(R.id.hint_content);
    SpannableString localSpannableString = new SpannableString(UseStringUtils.getStr(R.string.c_76_17_2, new String[] { paramString }));
    localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(paramContext, R.color.color_dbb76a)), 18, 18 + paramString.length(), 17);
    localSpannableString.setSpan(new StyleSpan(1), 18, 18 + paramString.length(), 17);
    localTextView.setText(localSpannableString);
    ((TextView)localView.findViewById(R.id.copy_wechat_num)).setOnClickListener(new View.OnClickListener(paramDialogListener, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        this.val$listener.onDialogClick(this.val$dialog, -1);
      }
    });
    ((ImageView)localView.findViewById(R.id.btn_close)).setOnClickListener(new View.OnClickListener(paramDialogListener, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        this.val$listener.onDialogClick(this.val$dialog, -2);
        this.val$dialog.dismiss();
      }
    });
    localDialog.setContentView(localView);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  private class URLDrawable extends BitmapDrawable
  {
    private Bitmap bitmap;

    private URLDrawable()
    {
    }

    public void draw(Canvas paramCanvas)
    {
      if (this.bitmap != null)
      {
        int i = (int)(CompDeviceInfoUtils.convertOfDip(BaseApplication.appliContext, 4.0F) / 1920.0F * BaseApplication.screenHeight);
        paramCanvas.drawBitmap(this.bitmap, 0.0F, -i, getPaint());
      }
    }
  }

  private class URLImageParser
    implements Html.ImageGetter
  {
    TextView mTextView;

    private URLImageParser(TextView arg2)
    {
      Object localObject;
      this.mTextView = localObject;
    }

    public Drawable getDrawable(String paramString)
    {
      String str = paramString.replace("\"", "").replace("\\", "");
      DialogManager.URLDrawable localURLDrawable = new DialogManager.URLDrawable(DialogManager.this, null);
      ImageUtils.getImageViewBitmap(str, new QueueCallback(localURLDrawable)
      {
        public void onErrorResponse()
        {
        }

        public void onResponse(Object paramObject)
        {
          if (paramObject == null);
          do
          {
            return;
            Bitmap localBitmap1 = (Bitmap)paramObject;
            Matrix localMatrix = new Matrix();
            localMatrix.postScale(1.5F, 1.5F);
            Bitmap localBitmap2 = Bitmap.createBitmap(localBitmap1, 0, 0, localBitmap1.getWidth(), localBitmap1.getHeight(), localMatrix, true);
            DialogManager.URLDrawable.access$202(this.val$urlDrawable, localBitmap2);
            this.val$urlDrawable.setBounds(0, 0, localBitmap2.getWidth(), localBitmap2.getHeight());
          }
          while (DialogManager.URLImageParser.this.mTextView == null);
          DialogManager.URLImageParser.this.mTextView.invalidate();
          DialogManager.URLImageParser.this.mTextView.setText(DialogManager.URLImageParser.this.mTextView.getText());
        }
      });
      return localURLDrawable;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.dialogmanager.DialogManager
 * JD-Core Version:    0.6.0
 */