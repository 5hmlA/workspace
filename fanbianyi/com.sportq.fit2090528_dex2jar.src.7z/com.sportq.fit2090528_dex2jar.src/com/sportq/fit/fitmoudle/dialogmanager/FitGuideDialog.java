package com.sportq.fit.fitmoudle.dialogmanager;

import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.VersionModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;
import com.sportq.fit.uicommon.R.string;

public class FitGuideDialog
{
  public static void editionCheckVer(Context paramContext, VersionModel paramVersionModel, int paramInt)
  {
    String str1 = VersionUpdateCheck.STR_DOWNLOAD_URL;
    String str2 = paramVersionModel.imageUrl;
    Dialog localDialog = DialogManager.guide_Dialog(paramContext, R.layout.guide_editioncheckver, 1);
    ImageView localImageView = (ImageView)localDialog.findViewById(R.id.neweditionimage);
    TextView localTextView1 = (TextView)localDialog.findViewById(R.id.btnnow_experience);
    TextView localTextView2 = (TextView)localDialog.findViewById(R.id.btn_cancel);
    if (paramInt == 0)
    {
      localTextView2.setText(paramContext.getResources().getString(R.string.cancel_hint));
      localTextView1.setText(paramContext.getResources().getString(R.string.check_version_update_now));
    }
    while (true)
    {
      ((TextView)localDialog.findViewById(R.id.tvNewEditionTitle)).setText(paramVersionModel.title);
      ((TextView)localDialog.findViewById(R.id.tvNewEditionNotes)).setText(paramVersionModel.comment);
      ((TextView)localDialog.findViewById(R.id.tvNewEditionNotes)).setMaxLines(8);
      ((TextView)localDialog.findViewById(R.id.tvNewEditionNotes)).setMovementMethod(ScrollingMovementMethod.getInstance());
      FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams((int)(0.792D * BaseApplication.screenWidth), -2);
      localDialog.findViewById(R.id.reldialog).setLayoutParams(localLayoutParams);
      int i = (int)(0.658D * BaseApplication.screenWidth);
      LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(i, (int)(0.754D * i));
      localLayoutParams1.gravity = 1;
      localImageView.setLayoutParams(localLayoutParams1);
      GlideUtils.loadImgByDefault(str2, localImageView);
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      localTextView2.setOnClickListener(new View.OnClickListener(paramInt, localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (this.val$pageIndex == 0)
            this.val$guideDialog.dismiss();
        }
      });
      localTextView1.setOnClickListener(new View.OnClickListener(paramInt, str1, localDialog, paramContext, paramVersionModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (this.val$pageIndex == 0)
          {
            if (!StringUtils.isNull(this.val$strLinkUrl))
            {
              this.val$guideDialog.dismiss();
              CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
              {
                public void result(boolean paramBoolean)
                {
                  if (paramBoolean)
                    new UpgradeProgressDialog().downloadApk(FitGuideDialog.2.this.val$mContext, FitGuideDialog.2.this.val$_versionModel.linkUrl);
                }
              }
              , this.val$mContext, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
            }
          }
          else
            return;
          CompDeviceInfoUtils.AppJumpToMarket(this.val$mContext);
        }
      });
      return;
      localTextView2.setText(paramContext.getResources().getString(R.string.check_version_update_collection));
      localTextView1.setText(paramContext.getResources().getString(R.string.check_version_update_start));
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.dialogmanager.FitGuideDialog
 * JD-Core Version:    0.6.0
 */