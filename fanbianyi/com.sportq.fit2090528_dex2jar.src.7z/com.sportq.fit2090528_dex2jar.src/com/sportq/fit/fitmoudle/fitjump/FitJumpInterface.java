package com.sportq.fit.fitmoudle.fitjump;

import android.content.Context;
import com.sportq.fit.common.event.TrainFinishEvent;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.GetuiDataModel;
import com.sportq.fit.common.model.MedalModel;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import com.sportq.fit.common.reformer.BrowseVideoListReformer;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.fitmoudle.network.data.CoursePhotoData;
import java.util.ArrayList;
import java.util.List;

public abstract interface FitJumpInterface
{
  public abstract void JumpPhotoActivity(Context paramContext, String paramString);

  public abstract void JumpSendImgPreviewActivity(Context paramContext, List paramList, int paramInt);

  public abstract void JumpTrainCategoryActivity(Context paramContext, String paramString1, String paramString2);

  public abstract void courseJumpCommodityInfo(Context paramContext, String paramString);

  public abstract void courseJumpCommodityList(Context paramContext, String paramString1, String paramString2);

  public abstract void customWeekDetailsJumpCourse(Context paramContext);

  public abstract void customerToCommodityInfo(Context paramContext, String paramString);

  public abstract void customizeJumpCourse(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6);

  public abstract void exitRemoveTag(Context paramContext);

  public abstract void fatCampJumpCourseDetail(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6);

  public abstract void findJumpAccount02VideoGuideActivity(Context paramContext);

  public abstract void findJumpFind07TrainPreviewActivity(Context paramContext, int paramInt, PlanReformer paramPlanReformer, ActionModel paramActionModel);

  public abstract void findJumpSecActivity(Context paramContext, String paramString1, String paramString2, String paramString3);

  public abstract void findJumpVideo01Activity(Context paramContext, PlanReformer paramPlanReformer, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract void finishJumpCamera(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract void finishJumpSec(Context paramContext, String paramString1, String paramString2, String paramString3);

  public abstract void finishJumpSetNotice(Context paramContext);

  public abstract void finishJumpTrainFeedBack(Context paramContext, String paramString1, String paramString2);

  public abstract void finishJumpTrainPhotoInfo(Context paramContext);

  public abstract void finishJumpTrainPhotoInfo(Context paramContext, String paramString);

  public abstract void jumpBrowseVideoPlayActivity(Context paramContext, BrowseVideoListReformer paramBrowseVideoListReformer);

  public abstract void jumpCameraTakeActivity(Context paramContext, CoursePhotoData paramCoursePhotoData);

  public abstract void jumpCommentList(Context paramContext, String paramString1, String paramString2, String paramString3, int paramInt);

  public abstract void jumpCommentList(Context paramContext, String paramString1, String paramString2, String paramString3, int paramInt, boolean paramBoolean);

  public abstract void jumpCouponAct(Context paramContext);

  public abstract void jumpCourseAct(Context paramContext, String paramString);

  public abstract void jumpEnergyActivity(Context paramContext);

  public abstract void jumpFcoinAct(Context paramContext);

  public abstract void jumpFitnessPicPub(Context paramContext, CoursePhotoData paramCoursePhotoData);

  public abstract void jumpFitnessTest(Context paramContext);

  public abstract void jumpMasterDetailAct(Context paramContext, String paramString);

  public abstract void jumpMasterListAct(Context paramContext);

  public abstract void jumpNoPunshActivity(Context paramContext);

  public abstract void jumpPersonalEdit(Context paramContext);

  public abstract void jumpRecomm(Context paramContext);

  public abstract <T> void jumpRecordDetail(Context paramContext, T paramT, String paramString1, String paramString2);

  public abstract void jumpRecordDetailInfoActivity(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract void jumpTask01NewChallengesListActivity(Context paramContext);

  public abstract void jumpTrainStartCustomizeActivity(Context paramContext, String paramString1, String paramString2);

  public abstract void jumpUnLockAction(Context paramContext);

  public abstract void jumpVideo03ShowInfoActivity(Context paramContext, PlanReformer paramPlanReformer);

  public abstract void mine02FragmentMedal(Context paramContext);

  public abstract void mine02HealthDataJump(Context paramContext, String paramString);

  public abstract void mine02NoticeJump(Context paramContext);

  public abstract void mine02WeightJump(Context paramContext);

  public abstract void mine03MedalDetailsJump(Context paramContext, String paramString1, String paramString2, MedalModel paramMedalModel);

  public abstract void myLikeActionJumpDetails(Context paramContext, int paramInt, ArrayList<ResponseModel.ActionData> paramArrayList, String paramString);

  public abstract void noticeJumpTaskWinnerList(Context paramContext, String paramString);

  public abstract void pushBrowseVideoDetailsActivity(Context paramContext, String paramString);

  public abstract void pushFeedbackActivity(Context paramContext, String paramString);

  public abstract void pushJumpArticleActivtiy(Context paramContext, String paramString, GetuiDataModel paramGetuiDataModel);

  public abstract void pushJumpChallengeActivity(Context paramContext, String paramString1, String paramString2, String paramString3, GetuiDataModel paramGetuiDataModel);

  public abstract void pushJumpCommentListActivity(Context paramContext, String paramString);

  public abstract void pushJumpEnergyDetailActivity(Context paramContext);

  public abstract void pushJumpLikeListActivity(Context paramContext, String paramString);

  public abstract void pushJumpMissonActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel);

  public abstract void pushJumpNavMainActivity(Context paramContext);

  public abstract void pushJumpNoticeActivity(Context paramContext, String paramString, GetuiDataModel paramGetuiDataModel);

  public abstract void pushJumpRemindListActivity(Context paramContext);

  public abstract void pushJumpSecActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel);

  public abstract void pushJumpTrainCollectionActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel);

  public abstract void pushJumpTrainCustomizedActivity(Context paramContext);

  public abstract void pushJumpTrainInfoActivity(Context paramContext, String paramString1, String paramString2, String paramString3, GetuiDataModel paramGetuiDataModel);

  public abstract void pushJumpTrainListActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel);

  public abstract void pushJumpTrainRecordsActivity(Context paramContext, String paramString1, String paramString2);

  public abstract void pushJumpWebViewActivtiy(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, GetuiDataModel paramGetuiDataModel);

  public abstract void pushMallGoodsInfoActivity(Context paramContext, String paramString);

  public abstract void pushMedalActivity(Context paramContext, String paramString);

  public abstract void pushMineOrderDetailActivity(Context paramContext, String paramString);

  public abstract void pushMineOrderTrackActivity(Context paramContext, String paramString);

  public abstract void pushShopMainActivity(Context paramContext);

  public abstract void pushShopRecommendListActivity(Context paramContext, String paramString);

  public abstract void recordJumpTrainPhotoInfo(Context paramContext, String paramString1, String paramString2);

  public abstract void settingJumpClipPicture(Context paramContext, String paramString);

  public abstract void settingJumpEnergyInvitCode(Context paramContext);

  public abstract void settingJumpFeedBack(Context paramContext);

  public abstract void settingJumpHealthData(Context paramContext, String paramString);

  public abstract void settingJumpVideoGuide(Context paramContext);

  public abstract void settingJumpWebView(Context paramContext, String paramString1, String paramString2);

  public abstract void taskJumpEnergyActivity(Context paramContext);

  public abstract void taskLimitCourseJump(Context paramContext, String paramString1, String paramString2, String paramString3);

  public abstract void taskNotLoginJumpLogin(Context paramContext);

  public abstract void trainerJumpWebView(Context paramContext, String paramString1, String paramString2);

  public abstract void videoJumpFinishAcitivty(Context paramContext, TrainFinishEvent paramTrainFinishEvent, String paramString1, String paramString2, String paramString3);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.fitjump.FitJumpInterface
 * JD-Core Version:    0.6.0
 */