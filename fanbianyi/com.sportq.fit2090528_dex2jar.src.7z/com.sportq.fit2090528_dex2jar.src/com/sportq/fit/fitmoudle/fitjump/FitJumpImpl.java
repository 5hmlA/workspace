package com.sportq.fit.fitmoudle.fitjump;

import android.content.Context;
import com.sportq.fit.common.event.TrainFinishEvent;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.GetuiDataModel;
import com.sportq.fit.common.model.MedalModel;
import com.sportq.fit.common.model.response.ResponseModel.ActionData;
import com.sportq.fit.common.reformer.BrowseVideoListReformer;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle.network.data.CoursePhotoData;
import java.util.ArrayList;
import java.util.List;

public class FitJumpImpl
  implements FitJumpInterface
{
  private static FitJumpInterface singleton;

  public static FitJumpInterface getInstance()
  {
    if (singleton == null)
      LogUtils.d("FitJumpImpl", "创建FitJumpInterface对象");
    try
    {
      singleton = (FitJumpInterface)Class.forName("com.sportq.fit.manager.jump.FitJump").newInstance();
      return singleton;
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
  }

  public static void init(FitJumpInterface paramFitJumpInterface)
  {
    if (singleton != null)
      singleton = paramFitJumpInterface;
  }

  public void JumpPhotoActivity(Context paramContext, String paramString)
  {
    singleton.JumpPhotoActivity(paramContext, paramString);
  }

  public void JumpSendImgPreviewActivity(Context paramContext, List paramList, int paramInt)
  {
    singleton.JumpSendImgPreviewActivity(paramContext, paramList, paramInt);
  }

  public void JumpTrainCategoryActivity(Context paramContext, String paramString1, String paramString2)
  {
    singleton.JumpTrainCategoryActivity(paramContext, paramString1, paramString2);
  }

  public void courseJumpCommodityInfo(Context paramContext, String paramString)
  {
    singleton.courseJumpCommodityInfo(paramContext, paramString);
  }

  public void courseJumpCommodityList(Context paramContext, String paramString1, String paramString2)
  {
    singleton.courseJumpCommodityList(paramContext, paramString1, paramString2);
  }

  public void customWeekDetailsJumpCourse(Context paramContext)
  {
    singleton.customWeekDetailsJumpCourse(paramContext);
  }

  public void customerToCommodityInfo(Context paramContext, String paramString)
  {
    singleton.customerToCommodityInfo(paramContext, paramString);
  }

  public void customizeJumpCourse(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    singleton.customizeJumpCourse(paramContext, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6);
  }

  public void exitRemoveTag(Context paramContext)
  {
    singleton.exitRemoveTag(paramContext);
  }

  public void fatCampJumpCourseDetail(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    singleton.fatCampJumpCourseDetail(paramContext, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6);
  }

  public void findJumpAccount02VideoGuideActivity(Context paramContext)
  {
    singleton.findJumpAccount02VideoGuideActivity(paramContext);
  }

  public void findJumpFind07TrainPreviewActivity(Context paramContext, int paramInt, PlanReformer paramPlanReformer, ActionModel paramActionModel)
  {
    singleton.findJumpFind07TrainPreviewActivity(paramContext, paramInt, paramPlanReformer, paramActionModel);
  }

  public void findJumpSecActivity(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    singleton.findJumpSecActivity(paramContext, paramString1, paramString2, paramString3);
  }

  public void findJumpVideo01Activity(Context paramContext, PlanReformer paramPlanReformer, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    singleton.findJumpVideo01Activity(paramContext, paramPlanReformer, paramString1, paramString2, paramString3, paramString4, paramString5);
  }

  public void finishJumpCamera(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    singleton.finishJumpCamera(paramContext, paramString1, paramString2, paramString3, paramString4, paramString5);
  }

  public void finishJumpSec(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    singleton.finishJumpSec(paramContext, paramString1, paramString2, paramString3);
  }

  public void finishJumpSetNotice(Context paramContext)
  {
    singleton.finishJumpSetNotice(paramContext);
  }

  public void finishJumpTrainFeedBack(Context paramContext, String paramString1, String paramString2)
  {
    singleton.finishJumpTrainFeedBack(paramContext, paramString1, paramString2);
  }

  public void finishJumpTrainPhotoInfo(Context paramContext)
  {
    singleton.finishJumpTrainPhotoInfo(paramContext);
  }

  public void finishJumpTrainPhotoInfo(Context paramContext, String paramString)
  {
    singleton.finishJumpTrainPhotoInfo(paramContext, paramString);
  }

  public void jumpBrowseVideoPlayActivity(Context paramContext, BrowseVideoListReformer paramBrowseVideoListReformer)
  {
    singleton.jumpBrowseVideoPlayActivity(paramContext, paramBrowseVideoListReformer);
  }

  public void jumpCameraTakeActivity(Context paramContext, CoursePhotoData paramCoursePhotoData)
  {
    singleton.jumpCameraTakeActivity(paramContext, paramCoursePhotoData);
  }

  public void jumpCommentList(Context paramContext, String paramString1, String paramString2, String paramString3, int paramInt)
  {
    singleton.jumpCommentList(paramContext, paramString1, paramString2, paramString3, paramInt);
  }

  public void jumpCommentList(Context paramContext, String paramString1, String paramString2, String paramString3, int paramInt, boolean paramBoolean)
  {
    singleton.jumpCommentList(paramContext, paramString1, paramString2, paramString3, paramInt, paramBoolean);
  }

  public void jumpCouponAct(Context paramContext)
  {
    singleton.jumpCouponAct(paramContext);
  }

  public void jumpCourseAct(Context paramContext, String paramString)
  {
    singleton.jumpCourseAct(paramContext, paramString);
  }

  public void jumpEnergyActivity(Context paramContext)
  {
    singleton.jumpEnergyActivity(paramContext);
  }

  public void jumpFcoinAct(Context paramContext)
  {
    singleton.jumpFcoinAct(paramContext);
  }

  public void jumpFitnessPicPub(Context paramContext, CoursePhotoData paramCoursePhotoData)
  {
    singleton.jumpFitnessPicPub(paramContext, paramCoursePhotoData);
  }

  public void jumpFitnessTest(Context paramContext)
  {
    singleton.jumpFitnessTest(paramContext);
  }

  public void jumpMasterDetailAct(Context paramContext, String paramString)
  {
    singleton.jumpMasterDetailAct(paramContext, paramString);
  }

  public void jumpMasterListAct(Context paramContext)
  {
    singleton.jumpMasterListAct(paramContext);
  }

  public void jumpNoPunshActivity(Context paramContext)
  {
    singleton.jumpNoPunshActivity(paramContext);
  }

  public void jumpPersonalEdit(Context paramContext)
  {
    singleton.jumpPersonalEdit(paramContext);
  }

  public void jumpRecomm(Context paramContext)
  {
    singleton.jumpRecomm(paramContext);
  }

  public <T> void jumpRecordDetail(Context paramContext, T paramT, String paramString1, String paramString2)
  {
    singleton.jumpRecordDetail(paramContext, paramT, paramString1, paramString2);
  }

  public void jumpRecordDetailInfoActivity(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    singleton.jumpRecordDetailInfoActivity(paramContext, paramString1, paramString2, paramString3, paramString4);
  }

  public void jumpTask01NewChallengesListActivity(Context paramContext)
  {
    singleton.jumpTask01NewChallengesListActivity(paramContext);
  }

  public void jumpTrainStartCustomizeActivity(Context paramContext, String paramString1, String paramString2)
  {
    singleton.jumpTrainStartCustomizeActivity(paramContext, paramString1, paramString2);
  }

  public void jumpUnLockAction(Context paramContext)
  {
    singleton.jumpUnLockAction(paramContext);
  }

  public void jumpVideo03ShowInfoActivity(Context paramContext, PlanReformer paramPlanReformer)
  {
    singleton.jumpVideo03ShowInfoActivity(paramContext, paramPlanReformer);
  }

  public void mine02FragmentMedal(Context paramContext)
  {
    singleton.mine02FragmentMedal(paramContext);
  }

  public void mine02HealthDataJump(Context paramContext, String paramString)
  {
    singleton.mine02HealthDataJump(paramContext, paramString);
  }

  public void mine02NoticeJump(Context paramContext)
  {
    singleton.mine02NoticeJump(paramContext);
  }

  public void mine02WeightJump(Context paramContext)
  {
    singleton.mine02WeightJump(paramContext);
  }

  public void mine03MedalDetailsJump(Context paramContext, String paramString1, String paramString2, MedalModel paramMedalModel)
  {
    singleton.mine03MedalDetailsJump(paramContext, paramString1, paramString2, paramMedalModel);
  }

  public void myLikeActionJumpDetails(Context paramContext, int paramInt, ArrayList<ResponseModel.ActionData> paramArrayList, String paramString)
  {
    singleton.myLikeActionJumpDetails(paramContext, paramInt, paramArrayList, paramString);
  }

  public void noticeJumpTaskWinnerList(Context paramContext, String paramString)
  {
    singleton.noticeJumpTaskWinnerList(paramContext, paramString);
  }

  public void pushBrowseVideoDetailsActivity(Context paramContext, String paramString)
  {
    singleton.pushBrowseVideoDetailsActivity(paramContext, paramString);
  }

  public void pushFeedbackActivity(Context paramContext, String paramString)
  {
    singleton.pushMedalActivity(paramContext, paramString);
  }

  public void pushJumpArticleActivtiy(Context paramContext, String paramString, GetuiDataModel paramGetuiDataModel)
  {
    singleton.pushJumpArticleActivtiy(paramContext, paramString, paramGetuiDataModel);
  }

  public void pushJumpChallengeActivity(Context paramContext, String paramString1, String paramString2, String paramString3, GetuiDataModel paramGetuiDataModel)
  {
    singleton.pushJumpChallengeActivity(paramContext, paramString1, paramString2, paramString3, paramGetuiDataModel);
  }

  public void pushJumpCommentListActivity(Context paramContext, String paramString)
  {
    singleton.pushJumpCommentListActivity(paramContext, paramString);
  }

  public void pushJumpEnergyDetailActivity(Context paramContext)
  {
    singleton.pushJumpEnergyDetailActivity(paramContext);
  }

  public void pushJumpLikeListActivity(Context paramContext, String paramString)
  {
    singleton.pushJumpLikeListActivity(paramContext, paramString);
  }

  public void pushJumpMissonActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel)
  {
    singleton.pushJumpMissonActivity(paramContext, paramString1, paramString2, paramGetuiDataModel);
  }

  public void pushJumpNavMainActivity(Context paramContext)
  {
    singleton.pushJumpNavMainActivity(paramContext);
  }

  public void pushJumpNoticeActivity(Context paramContext, String paramString, GetuiDataModel paramGetuiDataModel)
  {
    singleton.pushJumpNoticeActivity(paramContext, paramString, paramGetuiDataModel);
  }

  public void pushJumpRemindListActivity(Context paramContext)
  {
    singleton.pushJumpRemindListActivity(paramContext);
  }

  public void pushJumpSecActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel)
  {
    singleton.pushJumpSecActivity(paramContext, paramString1, paramString2, paramGetuiDataModel);
  }

  public void pushJumpTrainCollectionActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel)
  {
    singleton.pushJumpTrainCollectionActivity(paramContext, paramString1, paramString2, paramGetuiDataModel);
  }

  public void pushJumpTrainCustomizedActivity(Context paramContext)
  {
    singleton.pushJumpTrainCustomizedActivity(paramContext);
  }

  public void pushJumpTrainInfoActivity(Context paramContext, String paramString1, String paramString2, String paramString3, GetuiDataModel paramGetuiDataModel)
  {
    singleton.pushJumpTrainInfoActivity(paramContext, paramString1, paramString2, paramString3, paramGetuiDataModel);
  }

  public void pushJumpTrainListActivity(Context paramContext, String paramString1, String paramString2, GetuiDataModel paramGetuiDataModel)
  {
    singleton.pushJumpTrainListActivity(paramContext, paramString1, paramString2, paramGetuiDataModel);
  }

  public void pushJumpTrainRecordsActivity(Context paramContext, String paramString1, String paramString2)
  {
    singleton.pushJumpTrainRecordsActivity(paramContext, paramString1, paramString2);
  }

  public void pushJumpWebViewActivtiy(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, GetuiDataModel paramGetuiDataModel)
  {
    singleton.pushJumpWebViewActivtiy(paramContext, paramString1, paramString2, paramString3, paramString4, paramString5, paramGetuiDataModel);
  }

  public void pushMallGoodsInfoActivity(Context paramContext, String paramString)
  {
    singleton.pushMallGoodsInfoActivity(paramContext, paramString);
  }

  public void pushMedalActivity(Context paramContext, String paramString)
  {
    singleton.pushMedalActivity(paramContext, paramString);
  }

  public void pushMineOrderDetailActivity(Context paramContext, String paramString)
  {
    singleton.pushMineOrderDetailActivity(paramContext, paramString);
  }

  public void pushMineOrderTrackActivity(Context paramContext, String paramString)
  {
    singleton.pushMineOrderTrackActivity(paramContext, paramString);
  }

  public void pushShopMainActivity(Context paramContext)
  {
    singleton.pushShopMainActivity(paramContext);
  }

  public void pushShopRecommendListActivity(Context paramContext, String paramString)
  {
    singleton.pushShopRecommendListActivity(paramContext, paramString);
  }

  public void recordJumpTrainPhotoInfo(Context paramContext, String paramString1, String paramString2)
  {
    singleton.recordJumpTrainPhotoInfo(paramContext, paramString1, paramString2);
  }

  public void settingJumpClipPicture(Context paramContext, String paramString)
  {
    singleton.settingJumpClipPicture(paramContext, paramString);
  }

  public void settingJumpEnergyInvitCode(Context paramContext)
  {
    singleton.settingJumpEnergyInvitCode(paramContext);
  }

  public void settingJumpFeedBack(Context paramContext)
  {
    singleton.settingJumpFeedBack(paramContext);
  }

  public void settingJumpHealthData(Context paramContext, String paramString)
  {
    singleton.settingJumpHealthData(paramContext, paramString);
  }

  public void settingJumpVideoGuide(Context paramContext)
  {
    singleton.settingJumpVideoGuide(paramContext);
  }

  public void settingJumpWebView(Context paramContext, String paramString1, String paramString2)
  {
    singleton.settingJumpWebView(paramContext, paramString1, paramString2);
  }

  public void taskJumpEnergyActivity(Context paramContext)
  {
    singleton.taskJumpEnergyActivity(paramContext);
  }

  public void taskLimitCourseJump(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    singleton.taskLimitCourseJump(paramContext, paramString1, paramString2, paramString3);
  }

  public void taskNotLoginJumpLogin(Context paramContext)
  {
    singleton.taskNotLoginJumpLogin(paramContext);
  }

  public void trainerJumpWebView(Context paramContext, String paramString1, String paramString2)
  {
    singleton.trainerJumpWebView(paramContext, paramString1, paramString2);
  }

  public void videoJumpFinishAcitivty(Context paramContext, TrainFinishEvent paramTrainFinishEvent, String paramString1, String paramString2, String paramString3)
  {
    singleton.videoJumpFinishAcitivty(paramContext, paramTrainFinishEvent, paramString1, paramString2, paramString3);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.fitjump.FitJumpImpl
 * JD-Core Version:    0.6.0
 */