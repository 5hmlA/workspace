package com.sportq.fit.fitmoudle.task.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import cn.iwgang.countdownview.CountdownView;
import cn.iwgang.countdownview.CountdownView.OnCountdownEndListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.event.CountDownFinishEvent;
import com.sportq.fit.common.event.EnergyUnlockSuccessEvent;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.SystemTimeReformer;
import com.sportq.fit.common.reformer.TaskReformer;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.R.color;
import com.sportq.fit.fitmoudle.R.id;
import com.sportq.fit.fitmoudle.R.layout;
import com.sportq.fit.fitmoudle.R.mipmap;
import com.sportq.fit.fitmoudle.task.adapter.TaskMissionLimitPlanAdapter;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.supportlib.CommonUtils;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Task03ChallengeLimitCourseActivity extends BaseActivity
  implements CountdownView.OnCountdownEndListener
{
  TaskMissionLimitPlanAdapter adapter;
  private SystemTimeReformer systemTimeReformer;
  RecyclerView taskLimitCourseRecyclerView;
  private TaskReformer taskReformer;
  CustomToolBar toolbar;

  private void initUI()
  {
    if (!StringUtils.isNull(getIntent().getStringExtra("missionId")))
    {
      CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GetMissionPlan);
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.missionId = getIntent().getStringExtra("missionId");
      MiddleManager.getInstance().getFindPresenterImpl(this, null).getMissionPlan(localRequestModel, this);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof SystemTimeReformer))
      this.systemTimeReformer = ((SystemTimeReformer)paramT);
    if ((paramT instanceof TaskReformer))
      this.taskReformer = ((TaskReformer)paramT);
    if ((this.systemTimeReformer != null) && (this.taskReformer != null))
    {
      long l1 = SystemClock.elapsedRealtime();
      Iterator localIterator = this.taskReformer.lstTraint.iterator();
      while (localIterator.hasNext())
      {
        PlanModel localPlanModel = (PlanModel)localIterator.next();
        if (StringUtils.isNull(localPlanModel.effectTime))
          continue;
        long l2 = Long.valueOf(DateUtils.date2TimeStamp(this.systemTimeReformer.timeKey, "yyyy-MM-dd HH:mm:ss")).longValue();
        long l3 = Long.valueOf(DateUtils.date2TimeStamp(localPlanModel.effectTime, "yyyy-MM-dd HH:mm:ss")).longValue() - l2;
        if (l3 > 0L);
        for (String str = String.valueOf(l1 + l3); ; str = "")
        {
          localPlanModel.restTime = str;
          break;
        }
      }
      this.adapter = new TaskMissionLimitPlanAdapter(this, this.taskReformer.lstTraint, this);
      this.taskLimitCourseRecyclerView.setAdapter(this.adapter);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    EventBus.getDefault().register(this);
    setContentView(R.layout.task_challengeslimitcourse);
    String str = getIntent().getStringExtra("missionPlan");
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.taskLimitCourseRecyclerView = ((RecyclerView)findViewById(R.id.task_limitCourse_recyclerView));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(str);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    this.taskLimitCourseRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    initUI();
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  public void onEnd(CountdownView paramCountdownView)
  {
    if ((paramCountdownView != null) && (paramCountdownView.getTag() != null))
      EventBus.getDefault().post(new CountDownFinishEvent(paramCountdownView.getTag().toString()));
  }

  @Subscribe
  public void onEventMainThread(CountDownFinishEvent paramCountDownFinishEvent)
  {
    if ((paramCountDownFinishEvent != null) && (this.taskReformer.lstTraint != null))
    {
      Iterator localIterator = this.taskReformer.lstTraint.iterator();
      while (localIterator.hasNext())
      {
        PlanModel localPlanModel = (PlanModel)localIterator.next();
        if (!localPlanModel.planId.equals(paramCountDownFinishEvent.planId))
          continue;
        localPlanModel.restTime = "";
      }
      if (this.adapter != null)
      {
        this.adapter.setPlanModels(this.taskReformer.lstTraint);
        this.adapter.notifyDataSetChanged();
      }
    }
  }

  @Subscribe
  public void onEventMainThread(EnergyUnlockSuccessEvent paramEnergyUnlockSuccessEvent)
  {
    if ((paramEnergyUnlockSuccessEvent != null) && (this.taskReformer.lstTraint != null))
    {
      Iterator localIterator = this.taskReformer.lstTraint.iterator();
      while (localIterator.hasNext())
      {
        PlanModel localPlanModel = (PlanModel)localIterator.next();
        if (!localPlanModel.planId.equals(paramEnergyUnlockSuccessEvent.planId))
          continue;
        localPlanModel.restTime = String.valueOf(SystemClock.elapsedRealtime() + 1000 * StringUtils.string2Int(paramEnergyUnlockSuccessEvent.restTime));
      }
      if (this.adapter != null)
      {
        this.adapter.setPlanModels(this.taskReformer.lstTraint);
        this.adapter.notifyDataSetChanged();
      }
    }
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("Video01Activity.videoPlayFinish".equals(paramString))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  protected void onResume()
  {
    if (this.adapter != null)
      this.adapter.notifyDataSetChanged();
    super.onResume();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.task.activity.Task03ChallengeLimitCourseActivity
 * JD-Core Version:    0.6.0
 */