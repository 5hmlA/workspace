package com.sportq.fit.fitmoudle.task.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.collection.GrowingIO;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.AppCommentEvent;
import com.sportq.fit.common.event.TrainFinishPageFinishBtnClickEvent;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.TaskModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.R.anim;
import com.sportq.fit.fitmoudle.R.color;
import com.sportq.fit.fitmoudle.R.id;
import com.sportq.fit.fitmoudle.R.layout;
import com.sportq.fit.fitmoudle.R.menu;
import com.sportq.fit.fitmoudle.R.mipmap;
import com.sportq.fit.fitmoudle.R.string;
import com.sportq.fit.fitmoudle.activity.VipCenterActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.VipServiceEvent;
import com.sportq.fit.fitmoudle.task.eventbus.TaskSharePreferenceUtils;
import com.sportq.fit.fitmoudle.task.presenter.PresenterImpl;
import com.sportq.fit.fitmoudle.task.reformer.model.ChallengesModel;
import com.sportq.fit.fitmoudle.task.reformer.model.UserInfoModel;
import com.sportq.fit.fitmoudle.task.reformer.reformer.ChallengesJoinReformer;
import com.sportq.fit.fitmoudle.task.reformer.reformer.ChallengesReformer;
import com.sportq.fit.fitmoudle.task.widget.TaskDetailGoalsView;
import com.sportq.fit.fitmoudle.task.widget.TaskDetailJoinPeopleView;
import com.sportq.fit.fitmoudle.task.widget.TaskDetailsBottomBtnView;
import com.sportq.fit.fitmoudle.task.widget.TaskListItemView;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.ReminderDialog;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.http.cache.FitCacheStoreUtils;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Task02ChallengeDetailsActivity extends BaseActivity
{
  private RTextView buy_vip_btn;
  private ChallengesReformer challengesReformer;
  private boolean isRefresh = false;
  LinearLayout joinPeople_layout;
  private String missionId;
  private String missionName;
  private String missionPlan;
  private String missionPlanType;
  private boolean prizeRefresh = false;
  private ReminderDialog reminderDialog;
  TaskDetailsBottomBtnView taskDetailBtnContent;
  TaskDetailGoalsView taskDetailGoalsView;
  TaskListItemView taskDetailHeader;
  TaskDetailJoinPeopleView taskDetailJoinPeopleView;
  FrameLayout taskDetailLimitClass;
  TextView taskDetailLimitText;
  WebView taskDetailRules;
  TextView task_date;
  LinearLayout task_detail_reward_layout;
  LinearLayout task_list_info_layout;
  CustomToolBar toolbar;

  private void showRegisteredAnimation()
  {
    FrameLayout localFrameLayout = (FrameLayout)findViewById(R.id.registered_success_layout);
    if (localFrameLayout != null)
    {
      Animation localAnimation = AnimationUtils.loadAnimation(this, R.anim.roll_up);
      localAnimation.setFillAfter(true);
      localFrameLayout.setAnimation(localAnimation);
      localFrameLayout.setVisibility(0);
      new Handler().postDelayed(new Task02ChallengeDetailsActivity.4(this, localFrameLayout), 2000L);
    }
  }

  public void fitOnClick(View paramView)
  {
    super.fitOnClick(paramView);
    String str;
    int i;
    if (R.id.task_detail_btnContent == paramView.getId())
    {
      str = paramView.findViewById(R.id.task_detail_bottom_btn).getTag().toString();
      i = -1;
      switch (str.hashCode())
      {
      default:
        switch (i)
        {
        default:
          this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
          RequestModel localRequestModel = new RequestModel();
          localRequestModel.missionId = this.missionId;
          new PresenterImpl(this).joinMission(this, localRequestModel);
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        }
      case 51:
      case 55:
      case 56:
      case 1567:
      case 1568:
      case 1569:
      }
    }
    do
    {
      return;
      if (!str.equals("3"))
        break;
      i = 0;
      break;
      if (!str.equals("7"))
        break;
      i = 1;
      break;
      if (!str.equals("8"))
        break;
      i = 2;
      break;
      if (!str.equals("10"))
        break;
      i = 3;
      break;
      if (!str.equals("11"))
        break;
      i = 4;
      break;
      if (!str.equals("12"))
        break;
      i = 5;
      break;
      if ("0".equals(this.missionPlanType))
      {
        Intent localIntent4 = new Intent(this, Task03ChallengeLimitCourseActivity.class);
        localIntent4.putExtra("missionPlan", this.missionPlan);
        localIntent4.putExtra("missionId", this.missionId);
        localIntent4.putExtra("intent.from", "from.challenge");
        startActivity(localIntent4);
        AnimationUtil.pageJumpAnim(this, 0);
        return;
      }
      new ReminderDialog(this).createDialog().setImageRes(R.mipmap.to_challenge).setButtonText(getString(R.string.jump_to_plan)).setPopupTitleText(getString(R.string.no_limited_hint)).setPopupMainTitleText(getString(R.string.all_course_challenges)).setCloseLayoutOnClick(new Task02ChallengeDetailsActivity.3(this, null)).setButtonLayoutOnClick(new Task02ChallengeDetailsActivity.2(this, null));
      return;
      Intent localIntent3 = new Intent(this, Task03ChallengeWinnerListActivity.class);
      localIntent3.putExtra("missionId", this.missionId);
      startActivity(localIntent3);
      AnimationUtil.pageJumpAnim(this, 0);
      return;
      if (("10".equals(str)) || ("11".equals(str)))
        this.prizeRefresh = true;
      Intent localIntent2 = new Intent(this, TaskWebViewActivity.class);
      localIntent2.putExtra("task.id", this.challengesReformer.entDekaron.missionId);
      startActivity(localIntent2);
      AnimationUtil.pageJumpAnim(this, 0);
      return;
      if (R.id.buy_vip_btn != paramView.getId())
        continue;
      SharePreferenceUtils.putBuyVipFromPage("5");
      startActivity(new Intent(this, VipCenterActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
      return;
    }
    while (R.id.joinPeople_layout != paramView.getId());
    Intent localIntent1 = new Intent(this, TaskJoinActivity.class);
    localIntent1.putExtra("mission.id", this.missionId);
    startActivity(localIntent1);
    AnimationUtil.pageJumpAnim(this, 0);
  }

  public <T> void getDataFail(T paramT)
  {
    try
    {
      if (this.dialog != null)
        this.dialog.closeDialog();
      if ((!isFinishing()) && ((paramT instanceof String)))
        ToastUtils.makeToast(this, String.valueOf(paramT));
      super.getDataFail(paramT);
      return;
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
    if ((paramT instanceof ChallengesReformer))
    {
      this.challengesReformer = ((ChallengesReformer)paramT);
      if ((StringUtils.isNull(this.missionName)) || (!this.missionName.equals(this.challengesReformer.entDekaron.missionName)))
      {
        this.missionName = this.challengesReformer.entDekaron.missionName;
        this.toolbar.setNavIcon(R.mipmap.btn_back_black);
        this.toolbar.setTitle(this.missionName);
        this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
        this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
        setSupportActionBar(this.toolbar);
      }
      this.taskDetailHeader.setViewValue(this.challengesReformer.entDekaron, 1, 0);
      this.task_date.setText(this.challengesReformer.entDekaron.missionTime);
      this.taskDetailGoalsView.setViewValue(this.challengesReformer.entDekaron, this.taskDetailHeader);
      this.missionPlan = this.challengesReformer.entDekaron.missionPlan;
      this.missionPlanType = this.challengesReformer.entDekaron.missionPlanType;
      if (!StringUtils.isNull(this.missionPlan))
      {
        this.taskDetailLimitText.setText(this.missionPlan);
        this.taskDetailLimitClass.setVisibility(0);
        this.joinPeople_layout.setOnClickListener(new FitAction(this));
        if ((this.challengesReformer.entDekaron.lstJoinUser != null) && (this.challengesReformer.entDekaron.lstJoinUser.size() != 0))
          break label530;
        this.joinPeople_layout.setVisibility(8);
        label293: if (StringUtils.isNull(this.challengesReformer.entDekaron.introduce))
          break label555;
        this.task_detail_reward_layout.setVisibility(0);
        this.challengesReformer.entDekaron.introduce = this.challengesReformer.entDekaron.introduce.replace("<img", "<img height=\"auto\"; width=\"100%\"");
        WebView localWebView = this.taskDetailRules;
        String str = this.challengesReformer.entDekaron.introduce;
        localWebView.loadDataWithBaseURL("about:blank", str, "text/html", "utf-8", null);
        VdsAgent.loadDataWithBaseURL((View)localWebView, "about:blank", str, "text/html", "utf-8", null);
        label401: if (!StringUtils.isNull(this.challengesReformer.entDekaron.buttonType))
          break label567;
        this.taskDetailBtnContent.setVisibility(8);
        label426: new Handler().postDelayed(new Task02ChallengeDetailsActivity.1(this), 1300L);
        this.task_list_info_layout.setVisibility(0);
        if (!"1".equals(this.challengesReformer.entDekaron.isVip))
          break label602;
        if (("1".equals(BaseApplication.userModel.isVip)) || (!"-1".equals(this.challengesReformer.entDekaron.stateCode)))
          break label592;
        this.buy_vip_btn.setVisibility(0);
      }
    }
    label530: label555: label567: label592: label602: 
    do
    {
      return;
      this.taskDetailLimitClass.setVisibility(8);
      break;
      this.joinPeople_layout.setVisibility(0);
      this.taskDetailJoinPeopleView.setUserImageAndTitle(this.challengesReformer.entDekaron);
      break label293;
      this.task_detail_reward_layout.setVisibility(8);
      break label401;
      this.taskDetailBtnContent.setDataInfo(this.challengesReformer.entDekaron);
      this.taskDetailBtnContent.setVisibility(0);
      break label426;
      this.buy_vip_btn.setVisibility(8);
      return;
      this.buy_vip_btn.setVisibility(8);
      return;
    }
    while (!(paramT instanceof ChallengesJoinReformer));
    ChallengesJoinReformer localChallengesJoinReformer = (ChallengesJoinReformer)paramT;
    if (!StringUtils.isNull(localChallengesJoinReformer.message))
    {
      ToastUtils.makeToast(this, localChallengesJoinReformer.message);
      return;
    }
    if (localChallengesJoinReformer.challengesJoinData == null)
    {
      ToastUtils.makeToast(this, "参加失败");
      return;
    }
    this.challengesReformer.entDekaron.buttonType = localChallengesJoinReformer.challengesJoinData.buttonType;
    this.challengesReformer.entDekaron.stateIntr = localChallengesJoinReformer.challengesJoinData.stateIntr;
    this.challengesReformer.entDekaron.missionTime = localChallengesJoinReformer.challengesJoinData.missionTime;
    this.challengesReformer.entDekaron.buttonName = localChallengesJoinReformer.challengesJoinData.buttonName;
    this.challengesReformer.entDekaron.missionColorMain = localChallengesJoinReformer.challengesJoinData.missionColorMain;
    this.challengesReformer.entDekaron.stateCode = "0";
    EventBus.getDefault().post("join.mission");
    this.taskDetailHeader.reSetIntroduce(this.challengesReformer.entDekaron.stateIntr);
    TaskSharePreferenceUtils.putTaskMainScheduleNum(this, this.challengesReformer.entDekaron.missionId, "");
    this.challengesReformer.entDekaron.missionMainFinishNum = "0";
    this.taskDetailGoalsView.setViewValue(this.challengesReformer.entDekaron, this.taskDetailHeader);
    this.taskDetailBtnContent.setDataInfo(this.challengesReformer.entDekaron);
    showRegisteredAnimation();
    this.taskDetailHeader.hintFailIcon();
    this.task_date.setText(this.challengesReformer.entDekaron.missionTime);
    this.joinPeople_layout.setVisibility(0);
    UserInfoModel localUserInfoModel1 = new UserInfoModel();
    localUserInfoModel1.userImg = BaseApplication.userModel.userImg;
    localUserInfoModel1.stateCode = "0";
    localUserInfoModel1.isVip = BaseApplication.userModel.isVip;
    if ((this.challengesReformer.entDekaron.lstJoinUser == null) || (this.challengesReformer.entDekaron.lstJoinUser.size() == 0))
      this.challengesReformer.entDekaron.lstJoinUser = new ArrayList();
    while (true)
    {
      this.challengesReformer.entDekaron.joinNumber = String.valueOf(1 + StringUtils.string2Int(this.challengesReformer.entDekaron.joinNumber));
      this.challengesReformer.entDekaron.lstJoinUser.add(localUserInfoModel1);
      this.taskDetailJoinPeopleView.setUserImageAndTitle(this.challengesReformer.entDekaron);
      return;
      Iterator localIterator = this.challengesReformer.entDekaron.lstJoinUser.iterator();
      if (!localIterator.hasNext())
        continue;
      UserInfoModel localUserInfoModel2 = (UserInfoModel)localIterator.next();
      if (!localUserInfoModel2.userId.equals(BaseApplication.userModel.userId))
        break;
      this.challengesReformer.entDekaron.lstJoinUser.remove(localUserInfoModel2);
    }
  }

  public void init()
  {
    if (!StringUtils.isNull(this.missionId))
    {
      FitCacheStoreUtils.setApiCacheInvalid("/SFitWeb/sfit/getChallengeDet");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.missionId = this.missionId;
      new PresenterImpl(this).getChallengesInfo(this, localRequestModel);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.task_challengesdetail);
    EventBus.getDefault().register(this);
    this.missionId = getIntent().getStringExtra("missionId");
    this.missionName = getIntent().getStringExtra("missionName");
    GrowingIO.getInstance().setPageVariable(this, "page_name", "挑战");
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.taskDetailHeader = ((TaskListItemView)findViewById(R.id.task_detail_header));
    this.taskDetailGoalsView = ((TaskDetailGoalsView)findViewById(R.id.task_detail_goalsView));
    this.taskDetailLimitClass = ((FrameLayout)findViewById(R.id.task_detail_limitClass));
    this.taskDetailLimitText = ((TextView)findViewById(R.id.task_detail_limitText));
    this.taskDetailRules = ((WebView)findViewById(R.id.task_detail_reward));
    this.task_detail_reward_layout = ((LinearLayout)findViewById(R.id.task_detail_reward_layout));
    this.taskDetailJoinPeopleView = ((TaskDetailJoinPeopleView)findViewById(R.id.task_detail_joinPeopleView));
    this.joinPeople_layout = ((LinearLayout)findViewById(R.id.joinPeople_layout));
    this.taskDetailBtnContent = ((TaskDetailsBottomBtnView)findViewById(R.id.task_detail_btnContent));
    this.task_date = ((TextView)findViewById(R.id.task_date));
    this.task_list_info_layout = ((LinearLayout)findViewById(R.id.task_list_info_layout));
    this.buy_vip_btn = ((RTextView)findViewById(R.id.buy_vip_btn));
    this.buy_vip_btn.setOnClickListener(new FitAction(this));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(this.missionName);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    this.taskDetailBtnContent.setOnClickListener(new FitAction(this));
    this.dialog = new DialogManager();
    init();
    EventBus.getDefault().post("Task02ChallengeDetailsActivity.onCreate");
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(R.menu.task_detail_menu, paramMenu);
    return true;
  }

  protected void onDestroy()
  {
    EventBus.getDefault().post("Task02ChallengeDetailsActivity.onDestroy");
    EventBus.getDefault().unregister(this);
    if (this.taskDetailRules != null)
      this.taskDetailRules.destroy();
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(TrainFinishPageFinishBtnClickEvent paramTrainFinishPageFinishBtnClickEvent)
  {
    init();
    this.isRefresh = true;
  }

  @Subscribe
  public void onEventMainThread(VipServiceEvent paramVipServiceEvent)
  {
    if (paramVipServiceEvent == null);
    do
      return;
    while (!"1".equals(paramVipServiceEvent.isPayVip));
    init();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("task_RegisterSuccess".equals(paramString))
      finish();
    if ("close.details.page".equals(paramString))
      finish();
    if ("app.comment".equals(paramString))
      EventBus.getDefault().post(new AppCommentEvent(this));
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  protected void onNewIntent(Intent paramIntent)
  {
    VdsAgent.onNewIntent(this, paramIntent);
    this.missionId = paramIntent.getStringExtra("missionId");
    this.missionName = "";
    init();
    super.onNewIntent(paramIntent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      if (R.id.share != paramMenuItem.getItemId())
        continue;
      if ((this.challengesReformer == null) || (this.challengesReformer.entDekaron == null))
      {
        VdsAgent.handleClickResult(new Boolean(false));
        return false;
      }
      TaskModel localTaskModel = new TaskModel();
      localTaskModel.missionId = this.challengesReformer.entDekaron.missionId;
      localTaskModel.joinNumber = this.challengesReformer.entDekaron.joinNumber;
      localTaskModel.missionName = this.challengesReformer.entDekaron.missionName;
      localTaskModel.missionUrl = this.challengesReformer.entDekaron.missionUrl;
      localTaskModel.imageURL = this.challengesReformer.entDekaron.imageURL;
      this.dialog.showShareChoiseDialog(this, 17, localTaskModel, this.dialog);
    }
  }

  protected void onResume()
  {
    super.onResume();
    if (this.dialog != null)
      this.dialog.closeDialog();
    if (this.prizeRefresh)
    {
      init();
      this.prizeRefresh = false;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.task.activity.Task02ChallengeDetailsActivity
 * JD-Core Version:    0.6.0
 */