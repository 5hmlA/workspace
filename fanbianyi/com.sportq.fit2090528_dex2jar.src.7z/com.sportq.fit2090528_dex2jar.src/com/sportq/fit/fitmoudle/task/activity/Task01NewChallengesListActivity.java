package com.sportq.fit.fitmoudle.task.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.MenuItem;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.event.TrainFinishPageFinishBtnClickEvent;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.R.color;
import com.sportq.fit.fitmoudle.R.id;
import com.sportq.fit.fitmoudle.R.layout;
import com.sportq.fit.fitmoudle.R.mipmap;
import com.sportq.fit.fitmoudle.R.string;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.task.widget.AllChallengesItemView;
import com.sportq.fit.fitmoudle.task.widget.MineChallengesItemView;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.stub.StubApp;
import com.tencent.smtt.sdk.QbSdk;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Task01NewChallengesListActivity extends BaseActivity
{
  AllChallengesItemView allChallengesItemView;
  CustomTabLayout customTabLayout;
  MineChallengesItemView mineChallengesItemView;
  private String pageType;
  int viewPagerState;
  private ViewPager view_pager;

  private void initElement()
  {
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setAppTitle(R.string.fit_challenges_hint);
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setToolbarBg(R.color.white);
    localCustomToolBar.setToolbarTitleColor(R.color.color_313131);
    setSupportActionBar(localCustomToolBar);
    this.view_pager = ((ViewPager)findViewById(R.id.view_pager));
    if (getIntent() != null)
      this.pageType = getIntent().getStringExtra("page.show");
    ArrayList localArrayList = new ArrayList();
    this.allChallengesItemView = new AllChallengesItemView(this);
    this.mineChallengesItemView = new MineChallengesItemView(this);
    localArrayList.add(this.allChallengesItemView);
    localArrayList.add(this.mineChallengesItemView);
    this.view_pager.setAdapter(new CustomViewPagerAdapter(localArrayList));
    this.view_pager.addOnPageChangeListener(new Task01NewChallengesListActivity.MyOnPageChangeListener(this, null));
    this.customTabLayout = ((CustomTabLayout)findViewById(R.id.custom_tab_layout));
    CustomTabLayout localCustomTabLayout = this.customTabLayout;
    ViewPager localViewPager1 = this.view_pager;
    String[] arrayOfString = new String[2];
    arrayOfString[0] = getString(R.string.b_30_2);
    arrayOfString[1] = getString(R.string.b_30_3);
    localCustomTabLayout.setViewPager(localViewPager1, arrayOfString, true);
    ViewPager localViewPager2 = this.view_pager;
    if ("viewpager.mine".equals(this.pageType));
    for (int i = 1; ; i = 0)
    {
      localViewPager2.setCurrentItem(i);
      this.allChallengesItemView.getAllChallengesData();
      return;
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.task01_new_challengeslist);
    EventBus.getDefault().register(this);
    initElement();
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(TrainFinishPageFinishBtnClickEvent paramTrainFinishPageFinishBtnClickEvent)
  {
    this.mineChallengesItemView.refreshMineData();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if (("task_RegisterSuccess".equals(paramString)) || ("close.page".equals(paramString)))
      finish();
    do
      return;
    while (!"join.mission".equals(paramString));
    this.mineChallengesItemView.refreshMineData();
    this.allChallengesItemView.refreshAllData();
  }

  @Instrumented
  protected void onNewIntent(Intent paramIntent)
  {
    VdsAgent.onNewIntent(this, paramIntent);
    if (paramIntent != null)
      this.pageType = paramIntent.getStringExtra("page.show");
    ViewPager localViewPager = this.view_pager;
    int i;
    if ("viewpager.mine".equals(this.pageType))
    {
      i = 1;
      localViewPager.setCurrentItem(i);
      if (!"viewpager.mine".equals(this.pageType))
        break label81;
      this.mineChallengesItemView.getMineChallengesData();
    }
    while (true)
    {
      EventBus.getDefault().post("close.details.page");
      super.onNewIntent(paramIntent);
      return;
      i = 0;
      break;
      label81: this.allChallengesItemView.getAllChallengesData();
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  protected void onResume()
  {
    super.onResume();
    Task01NewChallengesListActivity.1 local1 = new Task01NewChallengesListActivity.1(this);
    QbSdk.setTbsListener(new Task01NewChallengesListActivity.2(this));
    QbSdk.initX5Environment(StubApp.getOrigApplicationContext(getApplicationContext()), local1);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.task.activity.Task01NewChallengesListActivity
 * JD-Core Version:    0.6.0
 */