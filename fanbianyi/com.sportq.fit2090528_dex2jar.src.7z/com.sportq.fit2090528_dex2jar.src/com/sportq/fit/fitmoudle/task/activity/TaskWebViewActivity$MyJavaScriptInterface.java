package com.sportq.fit.fitmoudle.task.activity;

import android.webkit.JavascriptInterface;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.R.string;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import org.json.JSONObject;

public class TaskWebViewActivity$MyJavaScriptInterface
{
  public TaskWebViewActivity$MyJavaScriptInterface(TaskWebViewActivity paramTaskWebViewActivity)
  {
  }

  @JavascriptInterface
  public void androidCopy(String paramString)
  {
    TextUtils.copyToClipboard(paramString);
    ToastUtils.makeToast(this.this$0, this.this$0.getString(R.string.copy_success));
  }

  @JavascriptInterface
  public void clickDw(String paramString)
  {
    if ("跳转下载".equals(paramString))
      CompDeviceInfoUtils.applyPermission(new TaskWebViewActivity.MyJavaScriptInterface.1(this), this.this$0, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
  }

  @JavascriptInterface
  public void clickEnergy(String paramString)
  {
    try
    {
      if ("查看我的能量".equals(paramString))
        FitJumpImpl.getInstance().taskJumpEnergyActivity(this.this$0);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  @JavascriptInterface
  public void clickFill(String paramString)
  {
    if (this.this$0.getString(R.string.click_give_up).equals(paramString))
    {
      this.this$0.finish();
      AnimationUtil.pageJumpAnim(this.this$0, 1);
    }
  }

  @JavascriptInterface
  public void clickOnAndroid(String paramString)
  {
  }

  @JavascriptInterface
  public void openQQ(String paramString)
  {
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      CompDeviceInfoUtils.openQQ(this.this$0, StringUtils.string2Int(localJSONObject.optString("page")), localJSONObject.getString("text"));
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.task.activity.TaskWebViewActivity.MyJavaScriptInterface
 * JD-Core Version:    0.6.0
 */