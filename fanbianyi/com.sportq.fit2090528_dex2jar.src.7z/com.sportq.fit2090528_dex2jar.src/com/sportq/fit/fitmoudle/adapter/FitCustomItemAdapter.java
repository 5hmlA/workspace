package com.sportq.fit.fitmoudle.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView.LayoutParams;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.view.View;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.CourseActItemModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.uicommon.R.color;
import com.sportq.fit.uicommon.R.drawable;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.mipmap;
import java.util.ArrayList;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class FitCustomItemAdapter extends SuperAdapter<CourseActItemModel>
{
  private int imgHeight = 0;
  private String imgUrl;
  private int imgWidth = 0;
  private int leftSize;
  private int rightSize;
  private String strType;
  private String title;

  public FitCustomItemAdapter(Context paramContext, ArrayList<CourseActItemModel> paramArrayList, int paramInt, String paramString)
  {
    super(paramContext, paramArrayList, paramInt);
    this.strType = paramString;
    this.leftSize = CompDeviceInfoUtils.convertOfDip(paramContext, 16.0F);
    this.rightSize = CompDeviceInfoUtils.convertOfDip(paramContext, 10.0F);
  }

  private void initMasterView(SuperViewHolder paramSuperViewHolder, int paramInt, CourseActItemModel paramCourseActItemModel)
  {
    ImageView localImageView = (ImageView)paramSuperViewHolder.findViewById(R.id.find_item_img);
    this.imgUrl = paramCourseActItemModel.imageUrl;
    this.title = paramCourseActItemModel.title;
    paramSuperViewHolder.findViewById(R.id.item_layout).getLayoutParams().width = (int)(0.9139000000000001D * BaseApplication.screenWidth);
    FrameLayout.LayoutParams localLayoutParams = (FrameLayout.LayoutParams)paramSuperViewHolder.findViewById(R.id.master_item_split_view).getLayoutParams();
    int i;
    TextView localTextView1;
    if (paramInt == 1)
    {
      i = CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F);
      localLayoutParams.leftMargin = i;
      ((TextView)paramSuperViewHolder.findViewById(R.id.item_title)).setText(this.title);
      localTextView1 = (TextView)paramSuperViewHolder.findViewById(R.id.item_desc);
      if (!StringUtils.isNull(paramCourseActItemModel.intr))
        break label330;
      localTextView1.setVisibility(8);
    }
    TextView localTextView2;
    TextView localTextView3;
    RTextView localRTextView;
    while (true)
    {
      localTextView2 = (TextView)paramSuperViewHolder.findViewById(R.id.item_info);
      if (!StringUtils.isNull(paramCourseActItemModel.intr))
        break label348;
      localTextView2.setVisibility(8);
      localTextView3 = (TextView)paramSuperViewHolder.findViewById(R.id.price);
      SpannableString localSpannableString = new SpannableString("¥ " + paramCourseActItemModel.price);
      localSpannableString.setSpan(new RelativeSizeSpan(0.72F), 0, 1, 18);
      localTextView3.setText(localSpannableString);
      localRTextView = (RTextView)paramSuperViewHolder.findViewById(R.id.go_train_tv);
      if (!"1".equals(paramCourseActItemModel.isBuy))
        break label409;
      localRTextView.setVisibility(0);
      localRTextView.getHelper().setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_313131));
      localRTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
      localRTextView.setText("去学习");
      localTextView3.setVisibility(8);
      GlideUtils.loadImgByRadius(this.imgUrl, R.mipmap.img_default, 3.0F, localImageView);
      return;
      i = 0;
      break;
      label330: localTextView1.setVisibility(0);
      localTextView1.setText(paramCourseActItemModel.intr);
    }
    label348: localTextView2.setVisibility(0);
    if (paramCourseActItemModel.courseNumber.contains("节"));
    for (String str = paramCourseActItemModel.courseNumber; ; str = paramCourseActItemModel.courseNumber + "节课")
    {
      localTextView2.setText(str);
      break;
    }
    label409: if ("1".equals(paramCourseActItemModel.freeFlg))
    {
      localRTextView.setVisibility(0);
      localRTextView.getHelper().setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_ffd208));
      localRTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_313131));
      localRTextView.setText("免费领取");
    }
    while (true)
    {
      localTextView3.setVisibility(0);
      break;
      localRTextView.setVisibility(8);
    }
  }

  private void initOtherView(SuperViewHolder paramSuperViewHolder, int paramInt, CourseActItemModel paramCourseActItemModel)
  {
    ImageView localImageView = (ImageView)paramSuperViewHolder.findViewById(R.id.find_item_img);
    String str1 = this.strType;
    int i = -1;
    label88: int j;
    label113: TextView localTextView;
    label218: View localView;
    switch (str1.hashCode())
    {
    default:
      switch (i)
      {
      default:
        RecyclerView.LayoutParams localLayoutParams = (RecyclerView.LayoutParams)paramSuperViewHolder.findViewById(R.id.find_item_layout).getLayoutParams();
        if (paramInt == 0)
        {
          j = this.leftSize;
          localLayoutParams.leftMargin = j;
          localLayoutParams.rightMargin = this.rightSize;
          localLayoutParams.width = this.imgWidth;
          localImageView.getLayoutParams().height = this.imgHeight;
          localTextView = (TextView)paramSuperViewHolder.findViewById(R.id.item_label_view);
          if (!StringUtils.isNull(paramCourseActItemModel.missionType))
            break label614;
          localTextView.setVisibility(8);
          ((TextView)paramSuperViewHolder.findViewById(R.id.item_title_view)).setText(this.title);
          if (!StringUtils.isNull(paramCourseActItemModel.comment))
            break label733;
          paramSuperViewHolder.findViewById(R.id.item_introduce_view).setVisibility(8);
          if ("3".equals(this.strType))
          {
            ((RelativeLayout.LayoutParams)paramSuperViewHolder.findViewById(R.id.item_layout02).getLayoutParams()).addRule(14);
            ((RelativeLayout.LayoutParams)paramSuperViewHolder.findViewById(R.id.item_introduce_view).getLayoutParams()).addRule(14);
            localView = paramSuperViewHolder.findViewById(R.id.energy_small_icon);
            if (!"4".equals(paramCourseActItemModel.curriculumtype))
              break label764;
          }
        }
      case 0:
      case 1:
      case 2:
      case 3:
      }
    case 48:
    case 49:
    case 50:
    case 51:
    }
    label430: label473: label614: label764: for (int n = 0; ; n = 8)
    {
      localView.setVisibility(n);
      GlideUtils.loadImgByRadius(this.imgUrl, R.mipmap.img_default, 3.0F, localImageView);
      return;
      if (!str1.equals("0"))
        break;
      i = 0;
      break;
      if (!str1.equals("1"))
        break;
      i = 1;
      break;
      if (!str1.equals("2"))
        break;
      i = 2;
      break;
      if (!str1.equals("3"))
        break;
      i = 3;
      break;
      this.imgWidth = (int)(0.76388D * BaseApplication.screenWidth);
      this.imgHeight = (int)(0.6D * (0.76388D * BaseApplication.screenWidth));
      String str3;
      if ("0".equals(this.strType))
      {
        str3 = paramCourseActItemModel.imageURL;
        this.imgUrl = str3;
        if (!"0".equals(this.strType))
          break label473;
      }
      for (String str4 = paramCourseActItemModel.missionName; ; str4 = paramCourseActItemModel.selectedTitle)
      {
        this.title = str4;
        break;
        str3 = paramCourseActItemModel.imgUrl;
        break label430;
      }
      this.imgWidth = (int)(0.43055D * BaseApplication.screenWidth);
      this.imgHeight = (int)(0.43055D * BaseApplication.screenWidth);
      this.imgUrl = paramCourseActItemModel.imageURL;
      this.title = paramCourseActItemModel.planName;
      break label88;
      this.imgWidth = (int)(0.2777D * BaseApplication.screenWidth);
      this.imgHeight = (int)(0.2777D * BaseApplication.screenWidth);
      this.imgUrl = paramCourseActItemModel.curriculumImageUrl;
      this.title = paramCourseActItemModel.curriculumName;
      paramCourseActItemModel.comment = paramCourseActItemModel.courseNumber;
      break label88;
      if ("4".equals(this.strType))
      {
        j = CompDeviceInfoUtils.convertOfDip(getContext(), 40.0F);
        break label113;
      }
      j = 0;
      break label113;
      localTextView.setVisibility(0);
      String str2;
      label638: int k;
      if ("0".equals(paramCourseActItemModel.missionType))
      {
        str2 = "限时";
        localTextView.setText(str2);
        Context localContext = getContext();
        if (!"0".equals(paramCourseActItemModel.missionType))
          break label717;
        k = R.color.white;
        localTextView.setTextColor(ContextCompat.getColor(localContext, k));
        if (!"0".equals(paramCourseActItemModel.missionType))
          break label725;
      }
      for (int m = R.drawable.app_comment_red_bg; ; m = R.drawable.free_flow_confirm_btn)
      {
        localTextView.setBackgroundResource(m);
        break;
        str2 = "自我";
        break label638;
        k = R.color.color_313131;
        break label669;
      }
      paramSuperViewHolder.findViewById(R.id.item_introduce_view).setVisibility(0);
      ((TextView)paramSuperViewHolder.findViewById(R.id.item_introduce_view)).setText(paramCourseActItemModel.comment);
      break label218;
    }
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, CourseActItemModel paramCourseActItemModel)
  {
    if ("4".equals(this.strType))
    {
      initMasterView(paramSuperViewHolder, paramInt2, paramCourseActItemModel);
      return;
    }
    initOtherView(paramSuperViewHolder, paramInt2, paramCourseActItemModel);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.adapter.FitCustomItemAdapter
 * JD-Core Version:    0.6.0
 */