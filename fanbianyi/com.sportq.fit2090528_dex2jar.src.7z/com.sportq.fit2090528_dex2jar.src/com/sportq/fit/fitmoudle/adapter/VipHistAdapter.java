package com.sportq.fit.fitmoudle.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.TextView;
import com.sportq.fit.common.model.LstVipHistModel;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.uicommon.R.color;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.string;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class VipHistAdapter extends SuperAdapter<LstVipHistModel>
{
  public VipHistAdapter(Context paramContext, List<LstVipHistModel> paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  private String pay_type_select(String paramString)
  {
    int i = -1;
    switch (paramString.hashCode())
    {
    case 52:
    default:
    case 48:
    case 49:
    case 50:
    case 51:
    case 53:
    }
    while (true)
      switch (i)
      {
      default:
        return "";
        if (!paramString.equals("0"))
          continue;
        i = 0;
        continue;
        if (!paramString.equals("1"))
          continue;
        i = 1;
        continue;
        if (!paramString.equals("2"))
          continue;
        i = 2;
        continue;
        if (!paramString.equals("3"))
          continue;
        i = 3;
        continue;
        if (!paramString.equals("5"))
          continue;
        i = 4;
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      }
    return "支付宝支付";
    return "微信支付";
    return "苹果支付";
    return "自动续费 苹果支付";
    return "华为支付";
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, LstVipHistModel paramLstVipHistModel)
  {
    ((TextView)paramSuperViewHolder.findViewById(R.id.vip_name)).setText(paramLstVipHistModel.vipName);
    ((TextView)paramSuperViewHolder.findViewById(R.id.total_price)).setText(paramLstVipHistModel.totalPrice);
    TextView localTextView1 = (TextView)paramSuperViewHolder.findViewById(R.id.start_time);
    int i = R.string.c_86_1_2;
    String[] arrayOfString1 = new String[1];
    arrayOfString1[0] = paramLstVipHistModel.startTime;
    localTextView1.setText(UseStringUtils.getStr(i, arrayOfString1));
    TextView localTextView2 = (TextView)paramSuperViewHolder.findViewById(R.id.end_time);
    int j = R.string.c_86_1_3;
    String[] arrayOfString2 = new String[1];
    arrayOfString2[0] = paramLstVipHistModel.endTime;
    localTextView2.setText(UseStringUtils.getStr(j, arrayOfString2));
    TextView localTextView3 = (TextView)paramSuperViewHolder.findViewById(R.id.buy_time);
    int k = R.string.c_86_1_4;
    String[] arrayOfString3 = new String[1];
    arrayOfString3[0] = paramLstVipHistModel.buyTime;
    localTextView3.setText(UseStringUtils.getStr(k, arrayOfString3));
    TextView localTextView4 = (TextView)paramSuperViewHolder.findViewById(R.id.pay_type);
    int m = R.string.c_86_1_5;
    String[] arrayOfString4 = new String[1];
    arrayOfString4[0] = pay_type_select(paramLstVipHistModel.payType);
    localTextView4.setText(UseStringUtils.getStr(m, arrayOfString4));
    TextView localTextView5 = (TextView)paramSuperViewHolder.findViewById(R.id.orderId);
    int n = R.string.c_86_1_6;
    String[] arrayOfString5 = new String[1];
    arrayOfString5[0] = paramLstVipHistModel.orderId;
    localTextView5.setText(UseStringUtils.getStr(n, arrayOfString5));
    View localView;
    if ("免费赠送".equals(paramLstVipHistModel.totalPrice))
    {
      ((TextView)paramSuperViewHolder.findViewById(R.id.total_price)).setTextColor(ContextCompat.getColor(getContext(), R.color.color_dbb76a));
      paramSuperViewHolder.findViewById(R.id.pay_type).setVisibility(8);
      paramSuperViewHolder.findViewById(R.id.orderId).setVisibility(8);
      localView = paramSuperViewHolder.findViewById(R.id.orderId);
      if (!StringUtils.isNull(paramLstVipHistModel.orderId))
        break label452;
    }
    label452: for (int i1 = 8; ; i1 = 0)
    {
      localView.setVisibility(i1);
      return;
      if ("兑换".equals(paramLstVipHistModel.totalPrice))
      {
        ((TextView)paramSuperViewHolder.findViewById(R.id.total_price)).setTextColor(ContextCompat.getColor(getContext(), R.color.color_dbb76a));
        paramSuperViewHolder.findViewById(R.id.pay_type).setVisibility(8);
        paramSuperViewHolder.findViewById(R.id.orderId).setVisibility(8);
        break;
      }
      ((TextView)paramSuperViewHolder.findViewById(R.id.total_price)).setTextColor(ContextCompat.getColor(getContext(), R.color.color_313131));
      paramSuperViewHolder.findViewById(R.id.pay_type).setVisibility(0);
      break;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.adapter.VipHistAdapter
 * JD-Core Version:    0.6.0
 */