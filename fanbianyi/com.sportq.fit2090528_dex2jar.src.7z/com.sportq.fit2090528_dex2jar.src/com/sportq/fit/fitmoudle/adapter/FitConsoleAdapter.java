package com.sportq.fit.fitmoudle.adapter;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils.TruncateAt;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.utils.JsonUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.uicommon.R.color;
import com.sportq.fit.uicommon.R.id;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class FitConsoleAdapter extends SuperAdapter<String>
{
  public FitConsoleAdapter(Context paramContext, List<String> paramList, @LayoutRes int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  private void setItemColor(SuperViewHolder paramSuperViewHolder, String paramString)
  {
    if (paramString.contains("请求接口"))
      ((TextView)paramSuperViewHolder.findViewById(R.id.info_view)).setTextColor(ContextCompat.getColor(getContext(), R.color.color_ffd208));
    do
    {
      return;
      if (!paramString.contains("接口参数"))
        continue;
      ((TextView)paramSuperViewHolder.findViewById(R.id.info_view)).setTextColor(ContextCompat.getColor(getContext(), R.color.color_62d486));
      return;
    }
    while ((!paramString.contains("接口返回值")) && (!paramString.contains("异常信息")) && (!paramString.contains("传值信息")));
    ((TextView)paramSuperViewHolder.findViewById(R.id.info_view)).setTextColor(ContextCompat.getColor(getContext(), R.color.color_313131));
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, String paramString)
  {
    if (paramString.contains("返回值"))
    {
      ((TextView)paramSuperViewHolder.findViewById(R.id.info_view)).setMaxLines(3);
      ((TextView)paramSuperViewHolder.findViewById(R.id.info_view)).setText(paramString.replace("&", "\n"));
      ((TextView)paramSuperViewHolder.findViewById(R.id.info_view)).setEllipsize(TextUtils.TruncateAt.END);
      paramSuperViewHolder.findViewById(R.id.info_view).setTag("close");
      paramSuperViewHolder.findViewById(R.id.info_view).setOnClickListener(new View.OnClickListener(paramSuperViewHolder, paramString)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if ("close".equals(paramView.getTag().toString()))
          {
            ((TextView)this.val$holder.findViewById(R.id.info_view)).setMaxLines(2147483647);
            ((TextView)this.val$holder.findViewById(R.id.info_view)).setText(JsonUtils.stringToJSON(((TextView)paramView).getText().toString()));
            this.val$holder.findViewById(R.id.info_view).setTag("open");
            return;
          }
          ((TextView)this.val$holder.findViewById(R.id.info_view)).setMaxLines(3);
          ((TextView)this.val$holder.findViewById(R.id.info_view)).setText(this.val$item.replace("&", "\n"));
          ((TextView)this.val$holder.findViewById(R.id.info_view)).setEllipsize(TextUtils.TruncateAt.END);
          this.val$holder.findViewById(R.id.info_view).setTag("close");
        }
      });
    }
    while (true)
    {
      setItemColor(paramSuperViewHolder, paramString);
      paramSuperViewHolder.findViewById(R.id.info_view).setOnLongClickListener(new View.OnLongClickListener()
      {
        public boolean onLongClick(View paramView)
        {
          ((ClipboardManager)FitConsoleAdapter.this.getContext().getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText(null, ((TextView)paramView).getText().toString()));
          ToastUtils.makeToast(FitConsoleAdapter.this.getContext(), "复制成功");
          return true;
        }
      });
      return;
      ((TextView)paramSuperViewHolder.findViewById(R.id.info_view)).setMaxLines(2147483647);
      ((TextView)paramSuperViewHolder.findViewById(R.id.info_view)).setText(paramString);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.adapter.FitConsoleAdapter
 * JD-Core Version:    0.6.0
 */