package com.sportq.fit.fitmoudle.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.sportq.fit.common.model.VipCommodityItemEntity;
import com.sportq.fit.common.reformer.VipCommodityReformer;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.uicommon.R.id;
import com.sportq.fit.uicommon.R.layout;
import com.sportq.fit.uicommon.R.mipmap;
import java.util.ArrayList;

public class VipPrivilegeAdapter extends BaseAdapter
{
  private Context context;
  private ArrayList<VipCommodityItemEntity> lstVipPrivilege;

  public VipPrivilegeAdapter(Context paramContext, VipCommodityReformer paramVipCommodityReformer)
  {
    this.context = paramContext;
    this.lstVipPrivilege = paramVipCommodityReformer.lstVipPrivilege;
  }

  public int getCount()
  {
    return this.lstVipPrivilege.size();
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public ArrayList<VipCommodityItemEntity> getLstVipPrivilege()
  {
    return this.lstVipPrivilege;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    if (paramView == null)
    {
      localViewHolder = new ViewHolder(null);
      paramView = LayoutInflater.from(this.context).inflate(R.layout.vip_privilege_item, null);
      ViewHolder.access$102(localViewHolder, (ImageView)paramView.findViewById(R.id.vip_privilege_icon));
      ViewHolder.access$202(localViewHolder, (TextView)paramView.findViewById(R.id.vip_privilege_tv));
      ViewHolder.access$302(localViewHolder, (ImageView)paramView.findViewById(R.id.vip_privilege_icon01));
      paramView.setTag(localViewHolder);
    }
    while (true)
    {
      localViewHolder.vip_privilege_icon.setVisibility(8);
      localViewHolder.vip_privilege_icon01.setVisibility(0);
      GlideUtils.loadImgByDefault(((VipCommodityItemEntity)this.lstVipPrivilege.get(paramInt)).privilegeImg, R.mipmap.img_default, localViewHolder.vip_privilege_icon01);
      localViewHolder.vip_privilege_tv.setText(((VipCommodityItemEntity)this.lstVipPrivilege.get(paramInt)).privilegeName);
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
    }
  }

  private static final class ViewHolder
  {
    private ImageView vip_privilege_icon;
    private ImageView vip_privilege_icon01;
    private TextView vip_privilege_tv;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.adapter.VipPrivilegeAdapter
 * JD-Core Version:    0.6.0
 */