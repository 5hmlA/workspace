package com.sportq.fit.fitmoudle.adapter;

import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;

public class CustomViewPagerAdapter extends PagerAdapter
{
  private List<View> mListViews;

  public CustomViewPagerAdapter(List<View> paramList)
  {
    this.mListViews = paramList;
  }

  public void destroyItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    paramViewGroup.removeView((View)this.mListViews.get(paramInt));
  }

  public int getCount()
  {
    return this.mListViews.size();
  }

  public Object instantiateItem(ViewGroup paramViewGroup, int paramInt)
  {
    paramViewGroup.addView((View)this.mListViews.get(paramInt), 0);
    return this.mListViews.get(paramInt);
  }

  public boolean isViewFromObject(View paramView, Object paramObject)
  {
    return paramView == paramObject;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter
 * JD-Core Version:    0.6.0
 */