package com.sportq.fit.business.browse.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.BaseFitAdapter;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.BrowseEntity;
import com.sportq.fit.common.utils.BrowseLikeStatusAlbumSaveTools;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.user_behavior.UserBehaviorImpl;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.byteam.superadapter.IMulItemViewType;
import org.byteam.superadapter.SuperViewHolder;

public class BrowseArticleAdapter extends BaseFitAdapter
{
  private OnBrowseArticleClickListener clickListener;
  private Context context;
  private LayoutInflater inflater;
  private BrowseLikeStatusAlbumSaveTools likeStatusAlbumSaveTools;
  private ArrayList<BrowseEntity> lstCategory;

  public BrowseArticleAdapter(Context paramContext, List paramList, IMulItemViewType paramIMulItemViewType, OnBrowseArticleClickListener paramOnBrowseArticleClickListener)
  {
    super(paramContext, paramList, paramIMulItemViewType);
    this.context = paramContext;
    this.clickListener = paramOnBrowseArticleClickListener;
    this.inflater = LayoutInflater.from(paramContext);
    this.likeStatusAlbumSaveTools = new BrowseLikeStatusAlbumSaveTools(paramContext);
  }

  private void initArticle(SuperViewHolder paramSuperViewHolder, int paramInt, Object paramObject)
  {
    BrowseEntity localBrowseEntity = (BrowseEntity)paramObject;
    LogUtils.e("BrowseArticleAdapter---", "initArticle：" + paramInt);
    TextView localTextView1 = (TextView)paramSuperViewHolder.findViewById(2131755510);
    TextView localTextView2;
    label86: TextView localTextView3;
    TextView localTextView4;
    if (StringUtils.isNull(localBrowseEntity.tpcTitle))
    {
      localTextView1.setVisibility(4);
      localTextView2 = (TextView)paramSuperViewHolder.findViewById(2131755511);
      if (!StringUtils.isNull(localBrowseEntity.lastDate))
        break label276;
      localTextView2.setVisibility(4);
      localTextView3 = (TextView)paramSuperViewHolder.findViewById(2131755512);
      if (!StringUtils.isNull(localBrowseEntity.likeNum))
        break label295;
      localTextView3.setText("");
      if (paramInt != 1)
        break label352;
      ImageView localImageView2 = (ImageView)paramSuperViewHolder.findViewById(2131755508);
      localImageView2.getLayoutParams().width = BaseApplication.screenWidth;
      localImageView2.getLayoutParams().height = (BaseApplication.screenWidth / 2);
      GlideUtils.loadImgByDefault(localBrowseEntity.imageUrl, 2130903536, localImageView2);
      localTextView4 = (TextView)paramSuperViewHolder.findViewById(2131755572);
      if (!StringUtils.isNull(localBrowseEntity.tpcDescribe))
        break label333;
      localTextView4.setVisibility(4);
    }
    while (true)
    {
      paramSuperViewHolder.findViewById(2131755507).setOnClickListener(new FitAction(null, localBrowseEntity)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (BrowseArticleAdapter.this.clickListener != null)
            BrowseArticleAdapter.this.clickListener.onArticleItemClick(this.val$browseEntity);
          new UserBehaviorImpl().kanTabArticleClick(this.val$browseEntity.olapInfo);
          super.onClick(paramView);
        }
      });
      this.likeStatusAlbumSaveTools.putArticleLikeFlg(localBrowseEntity.tpcId, localBrowseEntity.isLike);
      LogUtils.e("BrowseArticleAdapter---", "initArticle end：" + paramInt);
      return;
      localTextView1.setVisibility(0);
      localTextView1.setText(localBrowseEntity.tpcTitle);
      break;
      label276: localTextView2.setVisibility(0);
      localTextView2.setText(localBrowseEntity.lastDate);
      break label86;
      label295: if (Integer.valueOf(localBrowseEntity.likeNum).intValue() < 0);
      for (String str = "0"; ; str = localBrowseEntity.likeNum)
      {
        localTextView3.setText(str);
        break;
      }
      label333: localTextView4.setVisibility(0);
      localTextView4.setText(localBrowseEntity.tpcDescribe);
      continue;
      label352: ImageView localImageView1 = (ImageView)paramSuperViewHolder.findViewById(2131755508);
      int i = (int)(0.422D * BaseApplication.screenWidth);
      localImageView1.getLayoutParams().width = (int)(0.422D * BaseApplication.screenWidth);
      localImageView1.getLayoutParams().height = (int)(0.765D * i);
      GlideUtils.loadImgByDefault(QiniuManager.getImgUrl(localBrowseEntity.imageUrl, 480), 2130903536, localImageView1);
    }
  }

  private void initArticleCategory(SuperViewHolder paramSuperViewHolder)
  {
    ArrayList localArrayList;
    LinearLayout localLinearLayout;
    int j;
    int k;
    label88: BrowseEntity localBrowseEntity;
    View localView;
    ImageView localImageView;
    RelativeLayout.LayoutParams localLayoutParams2;
    if (this.lstCategory == null)
    {
      localArrayList = new ArrayList();
      this.lstCategory = localArrayList;
      localLinearLayout = (LinearLayout)paramSuperViewHolder.findViewById(2131755615);
      localLinearLayout.removeAllViews();
      int i = CompDeviceInfoUtils.convertOfDip(this.context, 10.0F);
      localLinearLayout.setPadding(i, i, i, i);
      j = CompDeviceInfoUtils.convertOfDip(this.context, 5.0F);
      k = (int)(0.278D * BaseApplication.screenWidth);
      Iterator localIterator = this.lstCategory.iterator();
      if (!localIterator.hasNext())
        break label266;
      localBrowseEntity = (BrowseEntity)localIterator.next();
      localView = this.inflater.inflate(2130968706, null);
      localImageView = (ImageView)localView.findViewById(2131755661);
      localLayoutParams2 = new RelativeLayout.LayoutParams(k, k);
      if (this.lstCategory.indexOf(localBrowseEntity) != 0)
        break label260;
    }
    label260: for (int m = j; ; m = 0)
    {
      localLayoutParams2.leftMargin = m;
      localLayoutParams2.topMargin = j;
      localLayoutParams2.bottomMargin = j;
      localLayoutParams2.rightMargin = j;
      localImageView.setLayoutParams(localLayoutParams2);
      GlideUtils.loadImgByDefault(localBrowseEntity.imageURL, localImageView);
      ((TextView)localView.findViewById(2131755662)).setText(localBrowseEntity.categoryName);
      localView.setOnClickListener(new FitAction(null, localBrowseEntity)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (BrowseArticleAdapter.this.clickListener != null)
            BrowseArticleAdapter.this.clickListener.onArticleCategoryClick(0, this.val$loopEntity);
          super.onClick(paramView);
        }
      });
      localLinearLayout.addView(localView);
      break label88;
      localArrayList = this.lstCategory;
      break;
    }
    label266: RelativeLayout localRelativeLayout = new RelativeLayout(this.context);
    TextView localTextView1 = new TextView(this.context);
    RelativeLayout.LayoutParams localLayoutParams1 = new RelativeLayout.LayoutParams(k, k);
    localLayoutParams1.leftMargin = 0;
    localLayoutParams1.topMargin = j;
    localLayoutParams1.bottomMargin = j;
    localLayoutParams1.rightMargin = j;
    localTextView1.setLayoutParams(localLayoutParams1);
    localTextView1.setBackgroundColor(ContextCompat.getColor(this.context, 2131624105));
    localRelativeLayout.addView(localTextView1);
    TextView localTextView2 = new TextView(this.context);
    localTextView2.setTextSize(15.0F);
    localTextView2.setTextColor(ContextCompat.getColor(this.context, 2131624044));
    localTextView2.setTypeface(Typeface.defaultFromStyle(1));
    localTextView2.setText(2131298953);
    localRelativeLayout.addView(localTextView2);
    ((RelativeLayout.LayoutParams)localTextView2.getLayoutParams()).addRule(13, -1);
    localRelativeLayout.setOnClickListener(new FitAction(null)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (BrowseArticleAdapter.this.clickListener != null)
          BrowseArticleAdapter.this.clickListener.onArticleCategoryClick(1, null);
        new UserBehaviorImpl().kanTabArticleClassifyClick("1", "");
        super.onClick(paramView);
      }
    });
    localLinearLayout.addView(localRelativeLayout);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, Object paramObject)
  {
    switch (paramInt2)
    {
    default:
      initArticle(paramSuperViewHolder, paramInt2, paramObject);
      return;
    case 0:
      initArticleCategory(paramSuperViewHolder);
      return;
    case 1:
    }
    initArticle(paramSuperViewHolder, paramInt2, paramObject);
  }

  public void setLstCategory(ArrayList<BrowseEntity> paramArrayList)
  {
    this.lstCategory = paramArrayList;
    if (this.lstCategory == null);
    for (ArrayList localArrayList = new ArrayList(); ; localArrayList = this.lstCategory)
    {
      this.lstCategory = localArrayList;
      return;
    }
  }

  public static abstract interface OnBrowseArticleClickListener
  {
    public abstract void onArticleCategoryClick(int paramInt, BrowseEntity paramBrowseEntity);

    public abstract void onArticleItemClick(BrowseEntity paramBrowseEntity);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.browse.adapter.BrowseArticleAdapter
 * JD-Core Version:    0.6.0
 */