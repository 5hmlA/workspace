package com.sportq.fit.business.browse.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.BaseFitAdapter;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.BrowseEntity;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.user_behavior.UserBehaviorImpl;
import com.sportq.fit.videopresenter.manager.cachemanager.VideoCacheDBManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.byteam.superadapter.IMulItemViewType;
import org.byteam.superadapter.SuperViewHolder;

public class BrowseVideoAdapter extends BaseFitAdapter
{
  private OnBrowseVideoClickListener clickListener;
  private Context context;
  private LayoutInflater inflater;
  private ArrayList<BrowseEntity> lstCategory;

  public BrowseVideoAdapter(Context paramContext, List paramList, IMulItemViewType paramIMulItemViewType, OnBrowseVideoClickListener paramOnBrowseVideoClickListener)
  {
    super(paramContext, paramList, paramIMulItemViewType);
    this.context = paramContext;
    this.clickListener = paramOnBrowseVideoClickListener;
    this.inflater = LayoutInflater.from(paramContext);
  }

  private void initVideoByEveryDay(SuperViewHolder paramSuperViewHolder, Object paramObject, int paramInt)
  {
    BrowseEntity localBrowseEntity = (BrowseEntity)paramObject;
    TextView localTextView1 = (TextView)paramSuperViewHolder.findViewById(2131755617);
    View localView = paramSuperViewHolder.findViewById(2131755573);
    ImageView localImageView;
    TextView localTextView2;
    label160: TextView localTextView3;
    int i;
    label200: label207: TextView localTextView4;
    if (StringUtils.isNull(localBrowseEntity.weekName))
    {
      localTextView1.setVisibility(8);
      localView.setVisibility(8);
      localImageView = (ImageView)paramSuperViewHolder.findViewById(2131755618);
      localImageView.getLayoutParams().width = BaseApplication.screenWidth;
      localImageView.getLayoutParams().height = (BaseApplication.screenWidth / 2);
      GlideUtils.loadImgByDefault(localBrowseEntity.imageUrl, 2130903536, localImageView);
      RelativeLayout localRelativeLayout = (RelativeLayout)paramSuperViewHolder.findViewById(2131755620);
      localRelativeLayout.getLayoutParams().width = BaseApplication.screenWidth;
      localRelativeLayout.getLayoutParams().height = (BaseApplication.screenWidth / 2);
      localTextView2 = (TextView)paramSuperViewHolder.findViewById(2131755607);
      if (!StringUtils.isNull(localBrowseEntity.tpcTitle))
        break label300;
      localTextView2.setVisibility(4);
      localTextView3 = (TextView)paramSuperViewHolder.findViewById(2131755619);
      if (!CompDeviceInfoUtils.checkPermission(getContext(), "android.permission.WRITE_EXTERNAL_STORAGE"))
        break label326;
      if (VideoCacheDBManager.getIntance().selectCache(localBrowseEntity.tpcId) == null)
        break label319;
      i = 0;
      localTextView3.setVisibility(i);
      localTextView4 = (TextView)paramSuperViewHolder.findViewById(2131755613);
      if (!StringUtils.isNull(localBrowseEntity.strDesc))
        break label336;
      localTextView4.setVisibility(4);
    }
    while (true)
    {
      paramSuperViewHolder.findViewById(2131755616).setOnClickListener(new FitAction(null, localImageView, localBrowseEntity, paramInt)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
          {
            public void result(boolean paramBoolean)
            {
              if (paramBoolean)
              {
                if (BrowseVideoAdapter.this.clickListener != null)
                  BrowseVideoAdapter.this.clickListener.onVideoItemClick(BrowseVideoAdapter.2.this.val$video_iv, BrowseVideoAdapter.2.this.val$browseEntity.tpcId, BrowseVideoAdapter.2.this.val$browseEntity.imageUrl, BrowseVideoAdapter.2.this.val$position);
                new UserBehaviorImpl().kanTabVideoClick(BrowseVideoAdapter.2.this.val$browseEntity.olapInfo);
              }
            }
          }
          , BrowseVideoAdapter.this.context, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
          super.onClick(paramView);
        }
      });
      return;
      localTextView1.setVisibility(0);
      localView.setVisibility(0);
      localTextView1.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
      localTextView1.setText(localBrowseEntity.weekName);
      break;
      label300: localTextView2.setVisibility(0);
      localTextView2.setText(localBrowseEntity.tpcTitle);
      break label160;
      label319: i = 8;
      break label200;
      label326: localTextView3.setVisibility(8);
      break label207;
      label336: localTextView4.setVisibility(0);
      localTextView4.setText(localBrowseEntity.strDesc);
    }
  }

  private void initVideoCategory(SuperViewHolder paramSuperViewHolder)
  {
    LinearLayout localLinearLayout = (LinearLayout)paramSuperViewHolder.findViewById(2131755615);
    localLinearLayout.removeAllViews();
    int i = CompDeviceInfoUtils.convertOfDip(this.context, 10.0F);
    localLinearLayout.setPadding(i, i, i, i);
    int j = CompDeviceInfoUtils.convertOfDip(this.context, 5.0F);
    int k = (int)(0.278D * BaseApplication.screenWidth);
    Iterator localIterator = this.lstCategory.iterator();
    if (localIterator.hasNext())
    {
      BrowseEntity localBrowseEntity = (BrowseEntity)localIterator.next();
      View localView = this.inflater.inflate(2130968706, null);
      ImageView localImageView = (ImageView)localView.findViewById(2131755661);
      RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(k, k);
      if (this.lstCategory.indexOf(localBrowseEntity) == 0);
      for (int m = j; ; m = 0)
      {
        localLayoutParams.leftMargin = m;
        localLayoutParams.topMargin = j;
        localLayoutParams.bottomMargin = j;
        localLayoutParams.rightMargin = j;
        localImageView.setLayoutParams(localLayoutParams);
        GlideUtils.loadImgByDefault(localBrowseEntity.imageURL, localImageView);
        ((TextView)localView.findViewById(2131755662)).setText(localBrowseEntity.categoryName);
        localView.setOnClickListener(new FitAction(null, localBrowseEntity)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            if (BrowseVideoAdapter.this.clickListener != null)
              BrowseVideoAdapter.this.clickListener.onVideoCategoryClick(0, this.val$loopEntity);
            super.onClick(paramView);
          }
        });
        localLinearLayout.addView(localView);
        break;
      }
    }
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, Object paramObject)
  {
    switch (paramInt2)
    {
    default:
      initVideoByEveryDay(paramSuperViewHolder, paramObject, paramInt2);
      return;
    case 0:
    }
    initVideoCategory(paramSuperViewHolder);
  }

  public void setLstCategory(ArrayList<BrowseEntity> paramArrayList)
  {
    this.lstCategory = paramArrayList;
    if (this.lstCategory == null);
    for (ArrayList localArrayList = new ArrayList(); ; localArrayList = this.lstCategory)
    {
      this.lstCategory = localArrayList;
      return;
    }
  }

  public static abstract interface OnBrowseVideoClickListener
  {
    public abstract void onVideoCategoryClick(int paramInt, BrowseEntity paramBrowseEntity);

    public abstract void onVideoItemClick(View paramView, String paramString1, String paramString2, int paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.browse.adapter.BrowseVideoAdapter
 * JD-Core Version:    0.6.0
 */