package com.sportq.fit.business.browse.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;
import com.sportq.fit.business.browse.adapter.BrowseArticleAdapter;
import com.sportq.fit.business.browse.adapter.BrowseArticleAdapter.OnBrowseArticleClickListener;
import com.sportq.fit.common.model.BrowseEntity;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.BrowseArticleListReformer;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreAdapter;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper.OnLoadMoreWarpperListener;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseNavView;
import com.sportq.fit.fitmoudle.widget.custom.refresh.OnRefreshListener;
import com.sportq.fit.fitmoudle.widget.custom.refresh.SwipeToLoadLayout;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseAllLabelsActivity;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseArticleDetailsActivity;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseArticleListActivity;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseEventEntity;
import com.sportq.fit.persenter.AppPresenterImpl;
import java.util.ArrayList;
import java.util.Iterator;
import org.byteam.superadapter.IMulItemViewType;

public class BrowseArticleView extends BaseNavView
  implements OnRefreshListener, BrowseArticleAdapter.OnBrowseArticleClickListener, LoadMoreWrapper.OnLoadMoreWarpperListener
{
  private BrowseArticleAdapter adapter;
  private AppPresenterImpl appPresenter;
  private ArrayList<BrowseEntity> browseArticleList;
  private LoadMoreWrapper loadMoreWrapper;
  private ProgressBar loader_icon;
  private Context mContext;
  private IMulItemViewType<BrowseEntity> multiItemViewType = new IMulItemViewType()
  {
    public int getItemViewType(int paramInt, BrowseEntity paramBrowseEntity)
    {
      return paramInt;
    }

    public int getLayoutId(int paramInt)
    {
      switch (paramInt)
      {
      default:
        return 2130968681;
      case 0:
        return 2130968695;
      case 1:
      }
      return 2130968680;
    }

    public int getViewTypeCount()
    {
      return 3;
    }
  };
  private SwipeToLoadLayout swipeToLoadLayout;
  private RecyclerView swipe_target;

  public BrowseArticleView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    this.appPresenter = new AppPresenterImpl(this);
    if (this.browseArticleList == null);
    for (ArrayList localArrayList = new ArrayList(); ; localArrayList = this.browseArticleList)
    {
      this.browseArticleList = localArrayList;
      View localView = LayoutInflater.from(this.mContext).inflate(2130968678, null);
      this.loader_icon = ((ProgressBar)localView.findViewById(2131755304));
      this.swipe_target = ((RecyclerView)localView.findViewById(2131755034));
      this.swipeToLoadLayout = ((SwipeToLoadLayout)localView.findViewById(2131755385));
      this.swipeToLoadLayout.setOnRefreshListener(this);
      return localView;
    }
  }

  public void getBrowseArticleData()
  {
    if ((this.browseArticleList != null) && (this.browseArticleList.size() > 1))
      return;
    this.loader_icon.setVisibility(8);
    if (this.swipeToLoadLayout.isRefreshing())
      this.swipeToLoadLayout.setRefreshing(false);
    this.appPresenter.getBrowseArticleList(this.mContext, new RequestModel());
  }

  public <T> void getDataFail(T paramT)
  {
    this.loader_icon.setTag(null);
    this.loader_icon.setVisibility(8);
    if (this.swipeToLoadLayout.isRefreshing())
      this.swipeToLoadLayout.setRefreshing(false);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.loader_icon.setVisibility(8);
    BrowseArticleListReformer localBrowseArticleListReformer;
    if ((paramT instanceof BrowseArticleListReformer))
    {
      localBrowseArticleListReformer = (BrowseArticleListReformer)paramT;
      if ((localBrowseArticleListReformer.lstTopic == null) || (localBrowseArticleListReformer.lstTopic.size() <= 0))
        break label351;
      if ((this.swipeToLoadLayout.isRefreshing()) || (("refresh".equals(localBrowseArticleListReformer.strNetworkRefreshTag)) && (this.loader_icon.getTag() == null)))
      {
        this.swipeToLoadLayout.setRefreshing(false);
        this.browseArticleList.clear();
        if (this.loadMoreWrapper != null)
          this.loadMoreWrapper.setLoadMoreEnabled(true);
      }
      if (this.browseArticleList.size() == 0)
        this.browseArticleList.add(0, new BrowseEntity());
      this.browseArticleList.addAll(localBrowseArticleListReformer.lstTopic);
      if (this.adapter != null)
        break label302;
      this.adapter = new BrowseArticleAdapter(this.mContext, this.browseArticleList, this.multiItemViewType, this);
      this.adapter.setLstCategory(localBrowseArticleListReformer.lstCategory);
      this.swipe_target.setLayoutManager(new LinearLayoutManager(this.mContext));
      this.swipe_target.setAdapter(this.adapter);
      if (this.loadMoreWrapper == null)
      {
        this.loadMoreWrapper = new LoadMoreWrapper(new LoadMoreAdapter(this.adapter), this);
        this.loadMoreWrapper.into(this.swipe_target);
      }
    }
    while (true)
    {
      if ("0".equals(localBrowseArticleListReformer.hasNextPage))
      {
        if (this.loadMoreWrapper != null)
          this.loadMoreWrapper.setLoadMoreEnabled(false);
        if (this.adapter != null)
          this.adapter.notifyDataSetChanged();
      }
      this.loader_icon.setTag(null);
      return;
      label302: if ((localBrowseArticleListReformer.lstCategory != null) && (localBrowseArticleListReformer.lstCategory.size() != 0))
        this.adapter.setLstCategory(localBrowseArticleListReformer.lstCategory);
      this.adapter.replaceAll(this.browseArticleList);
      this.adapter.notifyDataSetChanged();
      continue;
      label351: if (!this.swipeToLoadLayout.isRefreshing())
        continue;
      this.swipeToLoadLayout.setRefreshing(false);
    }
  }

  public void onArticleCategoryClick(int paramInt, BrowseEntity paramBrowseEntity)
  {
    if ((paramInt == 0) && (paramBrowseEntity != null))
    {
      Intent localIntent2 = new Intent(this.mContext, BrowseArticleListActivity.class);
      localIntent2.putExtra("article.title", paramBrowseEntity.categoryName);
      localIntent2.putExtra("article.id", paramBrowseEntity.categoryId);
      this.mContext.startActivity(localIntent2);
      AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
      return;
    }
    Intent localIntent1 = new Intent(this.mContext, BrowseAllLabelsActivity.class);
    this.mContext.startActivity(localIntent1);
    AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
  }

  public void onArticleItemClick(BrowseEntity paramBrowseEntity)
  {
    Intent localIntent = new Intent(this.mContext, BrowseArticleDetailsActivity.class);
    localIntent.putExtra("article.url", paramBrowseEntity.tpcUrl);
    localIntent.putExtra("webPage.tag", "0");
    localIntent.putExtra("article.id", paramBrowseEntity.tpcId);
    localIntent.putExtra("have.like", paramBrowseEntity.isLike);
    localIntent.putExtra("like.num", paramBrowseEntity.likeNum);
    localIntent.putExtra("comment.num", paramBrowseEntity.commentNumber);
    localIntent.putExtra("share.num", paramBrowseEntity.shareNumber);
    this.mContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
  }

  public void onLoadMore()
  {
    if ((this.browseArticleList != null) && (this.browseArticleList.size() > 1))
    {
      this.loader_icon.setTag("loader.more");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.inputDate = ((BrowseEntity)this.browseArticleList.get(-1 + this.browseArticleList.size())).loadMoreData;
      this.appPresenter.getBrowseArticleList(this.mContext, localRequestModel);
    }
  }

  public void onRefresh()
  {
    this.loader_icon.setVisibility(8);
    this.appPresenter.getBrowseArticleList(this.mContext, new RequestModel());
  }

  public void refreshLayout(BrowseEventEntity paramBrowseEventEntity)
  {
    if ((this.browseArticleList == null) || (this.browseArticleList.size() == 0) || (paramBrowseEventEntity == null))
      return;
    Iterator localIterator = this.browseArticleList.iterator();
    while (localIterator.hasNext())
    {
      BrowseEntity localBrowseEntity = (BrowseEntity)localIterator.next();
      if ((StringUtils.isNull(localBrowseEntity.tpcId)) || (!localBrowseEntity.tpcId.equals(paramBrowseEventEntity.tpcId)))
        continue;
      localBrowseEntity.isLike = paramBrowseEventEntity.isLike;
      localBrowseEntity.likeNum = paramBrowseEventEntity.strLikeNum;
    }
    this.adapter.replaceAll(this.browseArticleList);
    this.adapter.notifyDataSetChanged();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.browse.view.BrowseArticleView
 * JD-Core Version:    0.6.0
 */