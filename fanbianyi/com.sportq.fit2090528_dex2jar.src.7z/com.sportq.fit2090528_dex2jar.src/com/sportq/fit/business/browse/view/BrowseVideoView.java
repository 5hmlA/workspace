package com.sportq.fit.business.browse.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;
import com.sportq.fit.business.browse.adapter.BrowseVideoAdapter;
import com.sportq.fit.business.browse.adapter.BrowseVideoAdapter.OnBrowseVideoClickListener;
import com.sportq.fit.common.model.BrowseEntity;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.BrowseVideoListReformer;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreAdapter;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper.OnLoadMoreWarpperListener;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseNavView;
import com.sportq.fit.fitmoudle.widget.custom.refresh.OnRefreshListener;
import com.sportq.fit.fitmoudle.widget.custom.refresh.SwipeToLoadLayout;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseVideoDetailsActivity;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseVideoLabelsListActivity;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseEventEntity;
import com.sportq.fit.persenter.AppPresenterImpl;
import java.util.ArrayList;
import java.util.Iterator;
import org.byteam.superadapter.IMulItemViewType;

public class BrowseVideoView extends BaseNavView
  implements OnRefreshListener, BrowseVideoAdapter.OnBrowseVideoClickListener, LoadMoreWrapper.OnLoadMoreWarpperListener
{
  private BrowseVideoAdapter adapter;
  private AppPresenterImpl appPresenter;
  private ArrayList<BrowseEntity> browseVideoList;
  private LoadMoreWrapper loadMoreWrapper;
  private ProgressBar loader_icon;
  private Context mContext;
  private IMulItemViewType<BrowseEntity> multiItemViewType = new IMulItemViewType()
  {
    public int getItemViewType(int paramInt, BrowseEntity paramBrowseEntity)
    {
      return paramInt;
    }

    public int getLayoutId(int paramInt)
    {
      switch (paramInt)
      {
      default:
        return 2130968696;
      case 0:
      }
      return 2130968695;
    }

    public int getViewTypeCount()
    {
      return 2;
    }
  };
  private SwipeToLoadLayout swipeToLoadLayout;
  private RecyclerView swipe_target;

  public BrowseVideoView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private int[] getShowImgWandH(View paramView)
  {
    int[] arrayOfInt = new int[2];
    arrayOfInt[0] = paramView.getWidth();
    arrayOfInt[1] = paramView.getHeight();
    return arrayOfInt;
  }

  private View onCreateView()
  {
    this.appPresenter = new AppPresenterImpl(this);
    if (this.browseVideoList == null);
    for (ArrayList localArrayList = new ArrayList(); ; localArrayList = this.browseVideoList)
    {
      this.browseVideoList = localArrayList;
      View localView = LayoutInflater.from(this.mContext).inflate(2130968692, null);
      this.loader_icon = ((ProgressBar)localView.findViewById(2131755304));
      this.swipe_target = ((RecyclerView)localView.findViewById(2131755034));
      this.swipeToLoadLayout = ((SwipeToLoadLayout)localView.findViewById(2131755385));
      this.swipeToLoadLayout.setOnRefreshListener(this);
      return localView;
    }
  }

  public void getBrowseVideoData()
  {
    if ((this.browseVideoList != null) && (this.browseVideoList.size() > 1))
    {
      if (this.adapter != null)
        this.adapter.notifyDataSetChanged();
      return;
    }
    this.loader_icon.setVisibility(8);
    if (this.swipeToLoadLayout.isRefreshing())
      this.swipeToLoadLayout.setRefreshing(false);
    this.appPresenter.getBrowseVideoList(this.mContext, new RequestModel());
  }

  public <T> void getDataFail(T paramT)
  {
    this.loader_icon.setTag(null);
    this.loader_icon.setVisibility(8);
    if (this.swipeToLoadLayout.isRefreshing())
      this.swipeToLoadLayout.setRefreshing(false);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.loader_icon.setVisibility(8);
    BrowseVideoListReformer localBrowseVideoListReformer;
    if ((paramT instanceof BrowseVideoListReformer))
    {
      localBrowseVideoListReformer = (BrowseVideoListReformer)paramT;
      if ((localBrowseVideoListReformer.lstWeekVideo == null) || (localBrowseVideoListReformer.lstWeekVideo.size() <= 0))
        break label351;
      if ((this.swipeToLoadLayout.isRefreshing()) || (("refresh".equals(localBrowseVideoListReformer.strNetworkRefreshTag)) && (this.loader_icon.getTag() == null)))
      {
        this.browseVideoList.clear();
        this.swipeToLoadLayout.setRefreshing(false);
        if (this.loadMoreWrapper != null)
          this.loadMoreWrapper.setLoadMoreEnabled(true);
      }
      if (this.browseVideoList.size() == 0)
        this.browseVideoList.add(0, new BrowseEntity());
      this.browseVideoList.addAll(localBrowseVideoListReformer.lstWeekVideo);
      if (this.adapter != null)
        break label302;
      this.adapter = new BrowseVideoAdapter(this.mContext, this.browseVideoList, this.multiItemViewType, this);
      this.adapter.setLstCategory(localBrowseVideoListReformer.lstCategory);
      this.swipe_target.setLayoutManager(new LinearLayoutManager(this.mContext));
      this.swipe_target.setAdapter(this.adapter);
      if (this.loadMoreWrapper == null)
      {
        this.loadMoreWrapper = new LoadMoreWrapper(new LoadMoreAdapter(this.adapter), this);
        this.loadMoreWrapper.into(this.swipe_target);
      }
    }
    while (true)
    {
      if ("0".equals(localBrowseVideoListReformer.hasNextPage))
      {
        if (this.loadMoreWrapper != null)
          this.loadMoreWrapper.setLoadMoreEnabled(false);
        if (this.adapter != null)
          this.adapter.notifyDataSetChanged();
      }
      this.loader_icon.setTag(null);
      return;
      label302: if ((localBrowseVideoListReformer.lstCategory != null) && (localBrowseVideoListReformer.lstCategory.size() != 0))
        this.adapter.setLstCategory(localBrowseVideoListReformer.lstCategory);
      this.adapter.replaceAll(this.browseVideoList);
      this.adapter.notifyDataSetChanged();
      continue;
      label351: if (!this.swipeToLoadLayout.isRefreshing())
        continue;
      this.swipeToLoadLayout.setRefreshing(false);
    }
  }

  public void onLoadMore()
  {
    if ((this.browseVideoList != null) && (this.browseVideoList.size() > 1))
    {
      this.loader_icon.setTag("loader.more");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.inputDate = ((BrowseEntity)this.browseVideoList.get(-1 + this.browseVideoList.size())).lastDate;
      this.appPresenter.getBrowseVideoList(this.mContext, localRequestModel);
    }
  }

  public void onRefresh()
  {
    this.loader_icon.setVisibility(8);
    this.appPresenter.getBrowseVideoList(this.mContext, new RequestModel());
  }

  public void onVideoCategoryClick(int paramInt, BrowseEntity paramBrowseEntity)
  {
    if (paramInt == 0)
    {
      Intent localIntent = new Intent(this.mContext, BrowseVideoLabelsListActivity.class);
      localIntent.putExtra("category.name", paramBrowseEntity.categoryName);
      localIntent.putExtra("category.id", paramBrowseEntity.categoryId);
      this.mContext.startActivity(localIntent);
      AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
    }
  }

  public void onVideoItemClick(View paramView, String paramString1, String paramString2, int paramInt)
  {
    BrowseVideoListReformer localBrowseVideoListReformer = new BrowseVideoListReformer();
    localBrowseVideoListReformer.curPlayIndex = paramInt;
    localBrowseVideoListReformer.lstWeekVideo = this.browseVideoList;
    Intent localIntent = new Intent(this.mContext, BrowseVideoDetailsActivity.class);
    localIntent.putExtra("tpc.id", paramString1);
    localIntent.putExtra("video.img", paramString2);
    localIntent.putExtra("video.list.reformer", localBrowseVideoListReformer);
    int[] arrayOfInt1 = getShowImgWandH(paramView);
    localIntent.putExtra("width", arrayOfInt1[0]);
    localIntent.putExtra("height", arrayOfInt1[1]);
    int[] arrayOfInt2 = new int[2];
    paramView.getLocationOnScreen(arrayOfInt2);
    localIntent.putExtra("locationX", arrayOfInt2[0]);
    localIntent.putExtra("locationY", arrayOfInt2[1]);
    this.mContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
  }

  public void refreshLayout(BrowseEventEntity paramBrowseEventEntity)
  {
    if ((this.browseVideoList == null) || (this.browseVideoList.size() == 0) || (paramBrowseEventEntity == null))
      return;
    Iterator localIterator = this.browseVideoList.iterator();
    while (localIterator.hasNext())
    {
      BrowseEntity localBrowseEntity = (BrowseEntity)localIterator.next();
      if ((StringUtils.isNull(localBrowseEntity.tpcId)) || (!localBrowseEntity.tpcId.equals(paramBrowseEventEntity.tpcId)))
        continue;
      localBrowseEntity.isLike = paramBrowseEventEntity.isLike;
      localBrowseEntity.likeNum = paramBrowseEventEntity.strLikeNum;
    }
    this.adapter.replaceAll(this.browseVideoList);
    this.adapter.notifyDataSetChanged();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.browse.view.BrowseVideoView
 * JD-Core Version:    0.6.0
 */