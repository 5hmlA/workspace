package com.sportq.fit.business.browse.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseEventEntity;
import com.sportq.fit.fitmoudle13.shop.activity.ShopTabView;
import java.util.ArrayList;

public class BrowseViewPager extends ViewPager
{
  private BrowseArticleView browseArticleView;
  private BrowseVideoView browseVideoView;
  private OnTabColorChangeListener cListener;
  private OnLineScrollListener listener;
  private ShopTabView shopTabView;
  private int viewPagerState;

  public BrowseViewPager(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public void checkCurIndexData(int paramInt)
  {
    if ((paramInt < 0) || (paramInt > 2));
    do
      while (true)
      {
        return;
        if (paramInt == 0)
        {
          if (this.browseArticleView == null)
            continue;
          this.browseArticleView.getBrowseArticleData();
          return;
        }
        if (paramInt != 1)
          break;
        if (this.browseVideoView == null)
          continue;
        this.browseVideoView.getBrowseVideoData();
        return;
      }
    while ((paramInt != 2) || (this.browseArticleView == null));
    this.shopTabView.load();
  }

  public void initElements(Context paramContext, OnLineScrollListener paramOnLineScrollListener, OnTabColorChangeListener paramOnTabColorChangeListener)
  {
    this.listener = paramOnLineScrollListener;
    this.cListener = paramOnTabColorChangeListener;
    ArrayList localArrayList = new ArrayList();
    this.browseArticleView = new BrowseArticleView(paramContext);
    this.browseVideoView = new BrowseVideoView(paramContext);
    this.shopTabView = new ShopTabView(paramContext);
    localArrayList.add(this.browseArticleView);
    localArrayList.add(this.browseVideoView);
    localArrayList.add(this.shopTabView);
    setAdapter(new CustomViewPagerAdapter(localArrayList));
    addOnPageChangeListener(new MyOnPageChangeListener(null));
  }

  public void refreshLikeNumOrCancelLike(BrowseEventEntity paramBrowseEventEntity)
  {
    if (getCurrentItem() == 0)
      this.browseArticleView.refreshLayout(paramBrowseEventEntity);
    do
      return;
    while (getCurrentItem() != 1);
    this.browseVideoView.refreshLayout(paramBrowseEventEntity);
  }

  private class MyOnPageChangeListener
    implements ViewPager.OnPageChangeListener
  {
    private MyOnPageChangeListener()
    {
    }

    public void onPageScrollStateChanged(int paramInt)
    {
      BrowseViewPager.access$102(BrowseViewPager.this, paramInt);
    }

    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
    {
      if (BrowseViewPager.this.viewPagerState == 1);
      do
      {
        return;
        if (BrowseViewPager.this.listener == null)
          continue;
        BrowseViewPager.this.listener.onLineScroll(paramInt1, paramFloat);
      }
      while ((paramFloat != 0.0F) || (paramInt2 != 0));
      BrowseViewPager.this.checkCurIndexData(paramInt1);
    }

    public void onPageSelected(int paramInt)
    {
      if (BrowseViewPager.this.cListener != null)
        BrowseViewPager.this.cListener.onTabColorChange(paramInt);
    }
  }

  public static abstract interface OnLineScrollListener
  {
    public abstract void onLineScroll(int paramInt, float paramFloat);
  }

  public static abstract interface OnTabColorChangeListener
  {
    public abstract void onTabColorChange(int paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.browse.view.BrowseViewPager
 * JD-Core Version:    0.6.0
 */