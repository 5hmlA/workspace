package com.sportq.fit.business.browse.view;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;

public class BrowseTitleView extends RelativeLayout
{
  private FrameLayout article_list_btn_layout;
  private TextView article_tv;
  private FrameLayout scroll_view;
  private FrameLayout shop_btn_layout;
  private TextView shop_tv;
  private FrameLayout video_list_btn_layout;
  private TextView video_list_tv;

  public BrowseTitleView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public FrameLayout getArticle_list_btn_layout()
  {
    return this.article_list_btn_layout;
  }

  public FrameLayout getShop_btn_layout()
  {
    return this.shop_btn_layout;
  }

  public FrameLayout getVideo_list_btn_layout()
  {
    return this.video_list_btn_layout;
  }

  public void initElements()
  {
    this.shop_tv = ((TextView)findViewById(2131755596));
    this.article_tv = ((TextView)findViewById(2131755577));
    this.video_list_tv = ((TextView)findViewById(2131755594));
    this.shop_btn_layout = ((FrameLayout)findViewById(2131755595));
    this.video_list_btn_layout = ((FrameLayout)findViewById(2131755593));
    this.article_list_btn_layout = ((FrameLayout)findViewById(2131755592));
    this.scroll_view = ((FrameLayout)findViewById(2131755598));
    ((FrameLayout.LayoutParams)this.article_tv.getLayoutParams()).leftMargin = (int)(0.1013D * BaseApplication.screenWidth);
    ((FrameLayout.LayoutParams)this.shop_tv.getLayoutParams()).rightMargin = (int)(0.1023D * BaseApplication.screenWidth);
    RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(BaseApplication.screenWidth / 3, -1);
    localLayoutParams.addRule(12);
    this.scroll_view.setLayoutParams(localLayoutParams);
    ((FrameLayout.LayoutParams)((RelativeLayout)findViewById(2131755599)).getLayoutParams()).leftMargin = (int)(0.1023D * BaseApplication.screenWidth);
  }

  public void setLineScroll(int paramInt, float paramFloat)
  {
    int i = (int)(0.698D * (int)((paramFloat + paramInt % 3) * this.scroll_view.getWidth()));
    Log.e("滚动的X轴坐标是：", String.valueOf(i));
    ((View)this.scroll_view.getParent()).scrollTo(-i, this.scroll_view.getScrollY());
  }

  public void setTabSelColor(int paramInt, Context paramContext)
  {
    int i = 2131624003;
    TextView localTextView1 = this.video_list_tv;
    int j;
    int k;
    label41: TextView localTextView3;
    if (paramInt == 1)
    {
      j = i;
      localTextView1.setTextColor(ContextCompat.getColor(paramContext, j));
      TextView localTextView2 = this.article_tv;
      if (paramInt != 0)
        break label81;
      k = i;
      localTextView2.setTextColor(ContextCompat.getColor(paramContext, k));
      localTextView3 = this.shop_tv;
      if (paramInt != 2)
        break label88;
    }
    while (true)
    {
      localTextView3.setTextColor(ContextCompat.getColor(paramContext, i));
      return;
      j = 2131624044;
      break;
      label81: k = 2131624044;
      break label41;
      label88: i = 2131624044;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.browse.view.BrowseTitleView
 * JD-Core Version:    0.6.0
 */