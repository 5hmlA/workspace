package com.sportq.fit.business.browse;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import com.sportq.fit.business.BaseNavView;
import com.sportq.fit.business.browse.view.BrowseTitleView;
import com.sportq.fit.business.browse.view.BrowseViewPager;
import com.sportq.fit.business.browse.view.BrowseViewPager.OnLineScrollListener;
import com.sportq.fit.business.browse.view.BrowseViewPager.OnTabColorChangeListener;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseEventEntity;
import com.sportq.fit.middlelib.statistics.FitAction;

public class BrowseTabView extends BaseNavView
  implements BrowseViewPager.OnLineScrollListener, BrowseViewPager.OnTabColorChangeListener
{
  private BrowseTitleView browseTitleView;
  private BrowseViewPager browse_vp;
  private Context mContext;

  public BrowseTabView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
  }

  public BrowseTabView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  private View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(2130968699, null);
    this.browse_vp = ((BrowseViewPager)localView.findViewById(2131755622));
    this.browse_vp.initElements(this.mContext, this, this);
    this.browseTitleView = ((BrowseTitleView)localView.findViewById(2131755621));
    this.browseTitleView.initElements();
    this.browseTitleView.getArticle_list_btn_layout().setOnClickListener(new FitAction(this));
    this.browseTitleView.getVideo_list_btn_layout().setOnClickListener(new FitAction(this));
    this.browseTitleView.getShop_btn_layout().setOnClickListener(new FitAction(this));
    return localView;
  }

  public void checkDataForPage(int paramInt)
  {
    if (this.browse_vp == null)
      addView(onCreateView());
    if (paramInt != -1)
    {
      this.browse_vp.setCurrentItem(paramInt);
      return;
    }
    this.browse_vp.checkCurIndexData(this.browse_vp.getCurrentItem());
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    case 2131755594:
    default:
      return;
    case 2131755593:
      checkDataForPage(1);
      return;
    case 2131755592:
      checkDataForPage(0);
      return;
    case 2131755595:
    }
    checkDataForPage(2);
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
  }

  public void jumpShopTab()
  {
    checkDataForPage(2);
  }

  public void onLineScroll(int paramInt, float paramFloat)
  {
    if (this.browseTitleView == null)
      return;
    this.browseTitleView.setLineScroll(paramInt, paramFloat);
  }

  public void onTabColorChange(int paramInt)
  {
    if (this.browseTitleView == null)
      return;
    this.browseTitleView.setTabSelColor(paramInt, this.mContext);
  }

  public void refreshIsLikeStatus(BrowseEventEntity paramBrowseEventEntity)
  {
    if (this.browse_vp != null)
      this.browse_vp.refreshLikeNumOrCancelLike(paramBrowseEventEntity);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.browse.BrowseTabView
 * JD-Core Version:    0.6.0
 */