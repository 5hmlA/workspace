package com.sportq.fit.business.find.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.middlelib.MiddleManager;
import java.util.ArrayList;

public class FitCourseJumpMidActivity extends BaseActivity
{
  public static final String PLAN_ID = "plan.id";
  private String id;
  private boolean jumpFlg = false;
  private ProgressBar progressBar;
  private String strPlanId;
  CustomToolBar toolbar;
  RelativeLayout toolbar_layout;

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((!(paramT instanceof PlanReformer)) || (this.jumpFlg))
      return;
    this.jumpFlg = true;
    new Handler().postDelayed(new Runnable(paramT)
    {
      public void run()
      {
        PlanReformer localPlanReformer = (PlanReformer)this.val$reformer;
        Intent localIntent = FitCourseJumpMidActivity.this.getIntent();
        if ((localPlanReformer._individualInfo != null) && (localPlanReformer._individualInfo.stageArray.size() > 0))
        {
          localIntent.setClassName(FitCourseJumpMidActivity.this, Find04GenTrainInfoActivity.class.getName());
          localIntent.putExtra("single.type", "");
        }
        while (true)
        {
          FitCourseJumpMidActivity.this.startActivity(localIntent);
          FitCourseJumpMidActivity.this.overridePendingTransition(0, 0);
          FitCourseJumpMidActivity.this.finish();
          return;
          localIntent.setClassName(FitCourseJumpMidActivity.this, Find03GenTrainListActivity.class.getName());
        }
      }
    }
    , 300L);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968732);
    this.progressBar = ((ProgressBar)findViewById(2131755304));
    this.toolbar = ((CustomToolBar)findViewById(2131755432));
    this.toolbar_layout = ((RelativeLayout)findViewById(2131755277));
    this.toolbar.setTitle("");
    this.toolbar.setNavIcon(2130903081);
    this.toolbar.setTitleTextColor(-1);
    this.toolbar.setBackgroundResource(2131624292);
    this.toolbar_layout.setBackgroundResource(2131624292);
    this.toolbar_layout.getChildAt(1).setVisibility(8);
    setSupportActionBar(this.toolbar);
    this.strPlanId = getIntent().getStringExtra("plan.id");
    this.id = getIntent().getStringExtra("id");
    if (StringUtils.isNull(this.id));
    for (String str = this.strPlanId; ; str = this.id)
    {
      this.strPlanId = str;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.planId = this.strPlanId;
      localRequestModel.flg = "1";
      MiddleManager.getInstance().getFindPresenterImpl(this, null).getPlanInfoWithPlanId(localRequestModel, this);
      return;
    }
  }

  protected void onDestroy()
  {
    if (this.progressBar != null)
      this.progressBar.setVisibility(8);
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.activity.FitCourseJumpMidActivity
 * JD-Core Version:    0.6.0
 */