package com.sportq.fit.business.find.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import com.sportq.fit.business.find.widget.CourseActOperationalView;
import com.sportq.fit.common.model.CourseActModel;
import com.sportq.fit.common.model.GoldServiceModel;
import com.sportq.fit.common.reformer.GoldServiceReformer;
import java.util.ArrayList;

public class CourseActOperationalAdapter extends BaseAdapter
{
  private CourseActModel courseActModel;
  private GoldServiceReformer goldServiceReformer;
  private LayoutInflater inflater;
  private String jumpType;

  public CourseActOperationalAdapter(Context paramContext, String paramString, GoldServiceReformer paramGoldServiceReformer, CourseActModel paramCourseActModel)
  {
    this.jumpType = paramString;
    this.goldServiceReformer = paramGoldServiceReformer;
    this.courseActModel = paramCourseActModel;
    this.inflater = LayoutInflater.from(paramContext);
  }

  public int getCount()
  {
    if ("0".equals(this.jumpType))
      return this.goldServiceReformer.lstGoldService.size();
    return this.goldServiceReformer.lstSelectedPlan.size();
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    boolean bool1 = true;
    ViewHolder localViewHolder;
    GoldServiceModel localGoldServiceModel;
    label76: int i;
    label100: CourseActOperationalView localCourseActOperationalView;
    String str;
    boolean bool2;
    if (paramView == null)
    {
      localViewHolder = new ViewHolder(null);
      paramView = this.inflater.inflate(2130968727, null);
      localViewHolder.course_act_item_layout = ((CourseActOperationalView)paramView.findViewById(2131755729));
      paramView.setTag(localViewHolder);
      if (!"0".equals(this.jumpType))
        break label161;
      localGoldServiceModel = (GoldServiceModel)this.goldServiceReformer.lstGoldService.get(paramInt);
      if (!"0".equals(this.jumpType))
        break label180;
      i = this.goldServiceReformer.lstGoldService.size();
      localCourseActOperationalView = localViewHolder.course_act_item_layout;
      str = this.jumpType;
      if (paramInt != i - 1)
        break label195;
      bool2 = bool1;
      label125: if (paramInt != 0)
        break label201;
    }
    while (true)
    {
      localCourseActOperationalView.setCourseActData(str, localGoldServiceModel, bool2, bool1, paramInt, this.courseActModel);
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
      break;
      label161: localGoldServiceModel = (GoldServiceModel)this.goldServiceReformer.lstSelectedPlan.get(paramInt);
      break label76;
      label180: i = this.goldServiceReformer.lstSelectedPlan.size();
      break label100;
      label195: bool2 = false;
      break label125;
      label201: bool1 = false;
    }
  }

  public void setGoldServiceReformer(GoldServiceReformer paramGoldServiceReformer)
  {
    this.goldServiceReformer = paramGoldServiceReformer;
  }

  private static class ViewHolder
  {
    CourseActOperationalView course_act_item_layout;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.adapter.CourseActOperationalAdapter
 * JD-Core Version:    0.6.0
 */