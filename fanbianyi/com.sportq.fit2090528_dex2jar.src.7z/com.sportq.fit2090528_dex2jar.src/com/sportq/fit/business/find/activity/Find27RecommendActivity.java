package com.sportq.fit.business.find.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout.LayoutParams;
import android.widget.RelativeLayout;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.find.widget.SlidTrainImageView;
import com.sportq.fit.common.event.Find27ItemChangeEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle8.widget.guide.ScaleInTransformer;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Find27RecommendActivity extends BaseActivity
  implements FitInterfaceUtils.UIInitListener
{
  public static final String INTENT_PLANRECOMMENDREFORMER = "intent.PlanRecommendReformer";
  private MyPagerAdapter adapter;

  @Bind({2131755296})
  RelativeLayout close_layout;
  public PlanRecommendReformer planRecommendReformer;

  @Bind({2131755364})
  ViewPager slideAnimationViewPager;

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
      return;
    case 2131755296:
    }
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968626);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.close_layout.setOnClickListener(new FitAction(this));
    if (getIntent() == null)
    {
      finish();
      return;
    }
    this.planRecommendReformer = ((PlanRecommendReformer)getIntent().getSerializableExtra("intent.PlanRecommendReformer"));
    if ((this.planRecommendReformer == null) || (this.planRecommendReformer.planArray == null) || (this.planRecommendReformer.planArray.size() == 0))
    {
      finish();
      return;
    }
    FrameLayout.LayoutParams localLayoutParams = (FrameLayout.LayoutParams)this.slideAnimationViewPager.getLayoutParams();
    localLayoutParams.leftMargin = (int)(0.2D * FitApplication.screenWidth);
    localLayoutParams.rightMargin = (int)(0.2D * FitApplication.screenWidth);
    this.slideAnimationViewPager.setLayoutParams(localLayoutParams);
    this.slideAnimationViewPager.setOffscreenPageLimit(3);
    this.slideAnimationViewPager.setPageMargin(CompDeviceInfoUtils.convertOfDip(this, 26.0F));
    this.adapter = new MyPagerAdapter();
    this.slideAnimationViewPager.setAdapter(this.adapter);
    this.slideAnimationViewPager.setPageTransformer(true, new ScaleInTransformer());
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    EventBus.getDefault().post("Mine03MedalDetailsActivity.finish");
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(Find27ItemChangeEvent paramFind27ItemChangeEvent)
  {
    Iterator localIterator = this.planRecommendReformer.planArray.iterator();
    while (localIterator.hasNext())
    {
      PlanModel localPlanModel = (PlanModel)localIterator.next();
      if (!paramFind27ItemChangeEvent.planId.equals(localPlanModel.planId))
        continue;
      int i = this.planRecommendReformer.planArray.indexOf(localPlanModel);
      ((PlanModel)this.planRecommendReformer.planArray.get(i)).planStateCode = paramFind27ItemChangeEvent.stateCode;
      this.adapter.notifyDataSetChanged();
    }
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("Video01Activity.videoPlayFinish".equals(paramString))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  class MyPagerAdapter extends PagerAdapter
  {
    MyPagerAdapter()
    {
    }

    public void destroyItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
    {
      paramViewGroup.removeView((SlidTrainImageView)paramObject);
    }

    public int getCount()
    {
      return Find27RecommendActivity.this.planRecommendReformer.planArray.size();
    }

    public Object instantiateItem(ViewGroup paramViewGroup, int paramInt)
    {
      SlidTrainImageView localSlidTrainImageView = new SlidTrainImageView(Find27RecommendActivity.this, (PlanModel)Find27RecommendActivity.this.planRecommendReformer.planArray.get(paramInt));
      localSlidTrainImageView.setTrainImageUri(((PlanModel)Find27RecommendActivity.this.planRecommendReformer.planArray.get(paramInt)).planImageURL);
      localSlidTrainImageView.setTrainName(((PlanModel)Find27RecommendActivity.this.planRecommendReformer.planArray.get(paramInt)).planName);
      localSlidTrainImageView.setTrainSummary(((PlanModel)Find27RecommendActivity.this.planRecommendReformer.planArray.get(paramInt)).planSummary);
      paramViewGroup.addView(localSlidTrainImageView, paramInt);
      return localSlidTrainImageView;
    }

    public boolean isViewFromObject(View paramView, Object paramObject)
    {
      return paramView == paramObject;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.activity.Find27RecommendActivity
 * JD-Core Version:    0.6.0
 */