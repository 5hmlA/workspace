package com.sportq.fit.business.find.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.find.adapter.CourseActOperationalAdapter;
import com.sportq.fit.common.model.CourseActItemModel;
import com.sportq.fit.common.model.CourseActModel;
import com.sportq.fit.common.model.GoldServiceModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.GoldServiceReformer;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.persenter.AppPresenterImpl;
import java.util.ArrayList;

public class CourseActOperationalActivity extends BaseActivity
{
  public static final String STR_JUMP_TYPE = "jump.type";
  private CourseActOperationalAdapter adapter;
  private CourseActModel courseActModel;

  @Bind({2131755449})
  ListView list_view;
  private String strJumpType;

  @Bind({2131755432})
  CustomToolBar toolbar;

  public <T> void getDataSuccess(T paramT)
  {
    GoldServiceReformer localGoldServiceReformer;
    if ((paramT instanceof GoldServiceReformer))
    {
      localGoldServiceReformer = (GoldServiceReformer)paramT;
      if ((localGoldServiceReformer.lstGoldService != null) || (localGoldServiceReformer.lstSelectedPlan != null));
    }
    else
    {
      return;
    }
    if (("1".equals(this.strJumpType)) && (!StringUtils.isNull(localGoldServiceReformer.curriculumName)))
    {
      this.courseActModel.plateType = "1";
      this.courseActModel.plateName = localGoldServiceReformer.curriculumName;
      this.toolbar.setTitle(localGoldServiceReformer.curriculumName);
      this.toolbar.setNavIcon(2130903080);
      this.toolbar.setToolbarBg(2131624328);
      this.toolbar.setToolbarTitleColor(2131624003);
      setSupportActionBar(this.toolbar);
      if ((localGoldServiceReformer.lstSelectedPlan != null) && (localGoldServiceReformer.lstSelectedPlan.size() > 0))
      {
        ArrayList localArrayList = new ArrayList();
        for (int i = 0; i < localGoldServiceReformer.lstSelectedPlan.size(); i++)
        {
          GoldServiceModel localGoldServiceModel = (GoldServiceModel)localGoldServiceReformer.lstSelectedPlan.get(i);
          CourseActItemModel localCourseActItemModel = new CourseActItemModel();
          localCourseActItemModel.selectedId = localGoldServiceModel.selectedId;
          localCourseActItemModel.imgUrl = localGoldServiceModel.imgUrl;
          localCourseActItemModel.selectedTitle = localGoldServiceModel.selectedTitle;
          localCourseActItemModel.comment = localGoldServiceModel.comment;
          localArrayList.add(localCourseActItemModel);
        }
        this.courseActModel.lstplateDet = localArrayList;
      }
    }
    if (this.adapter == null)
    {
      this.adapter = new CourseActOperationalAdapter(this, this.strJumpType, localGoldServiceReformer, this.courseActModel);
      this.list_view.setAdapter(this.adapter);
      return;
    }
    if ("0".equals(this.strJumpType))
      this.adapter.setGoldServiceReformer(localGoldServiceReformer);
    this.adapter.notifyDataSetChanged();
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968726);
    ButterKnife.bind(this);
    this.strJumpType = getIntent().getStringExtra("jump.type");
    CustomToolBar localCustomToolBar = this.toolbar;
    if ("0".equals(this.strJumpType));
    for (String str = getResources().getString(2131296917); ; str = "")
    {
      localCustomToolBar.setTitle(str);
      this.toolbar.setNavIcon(2130903080);
      this.toolbar.setToolbarBg(2131624328);
      this.toolbar.setToolbarTitleColor(2131624003);
      setSupportActionBar(this.toolbar);
      return;
    }
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    ButterKnife.unbind(this);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  protected void onResume()
  {
    super.onResume();
    AppPresenterImpl localAppPresenterImpl = new AppPresenterImpl(this);
    if ("0".equals(this.strJumpType))
      localAppPresenterImpl.getGoldService(this);
    do
      return;
    while (!"1".equals(this.strJumpType));
    this.courseActModel = new CourseActModel();
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.plateId = getIntent().getStringExtra("plate_id");
    localAppPresenterImpl.getSelectedPlan(this, localRequestModel);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.activity.CourseActOperationalActivity
 * JD-Core Version:    0.6.0
 */