package com.sportq.fit.business.find.activity;

import android.view.View;
import android.widget.ListView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class CourseActOperationalActivity$$ViewBinder<T extends CourseActOperationalActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.list_view = ((ListView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755449, "field 'list_view'"), 2131755449, "field 'list_view'"));
  }

  public void unbind(T paramT)
  {
    paramT.toolbar = null;
    paramT.list_view = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.activity.CourseActOperationalActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */