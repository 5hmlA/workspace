package com.sportq.fit.business.find.widget;

import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;

public class SlidTrainImageView extends RelativeLayout
{
  private Context mContext;
  PlanModel planModel;
  private View rootView;
  ImageView trainImage;
  CustomTextView trainName;
  CustomTextView trainSummary;

  public SlidTrainImageView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    addView(onCreateView());
  }

  public SlidTrainImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    addView(onCreateView());
  }

  public SlidTrainImageView(Context paramContext, PlanModel paramPlanModel)
  {
    super(paramContext);
    this.planModel = paramPlanModel;
    addView(onCreateView());
  }

  public View onCreateView()
  {
    this.mContext = getContext();
    this.rootView = View.inflate(this.mContext, 2130968838, null);
    this.trainImage = ((ImageView)this.rootView.findViewById(2131756117));
    int i = (int)(0.6D * BaseApplication.screenWidth);
    RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(i, i);
    this.trainImage.setLayoutParams(localLayoutParams);
    this.trainName = ((CustomTextView)this.rootView.findViewById(2131756118));
    this.trainSummary = ((CustomTextView)this.rootView.findViewById(2131756119));
    setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Object localObject = Find03GenTrainListActivity.class;
        if ("1".equals(SlidTrainImageView.this.planModel.planStateCode))
          localObject = Find04GenTrainInfoActivity.class;
        Intent localIntent = new Intent(SlidTrainImageView.this.mContext, (Class)localObject);
        localIntent.putExtra("plan.id", SlidTrainImageView.this.planModel.planId);
        SlidTrainImageView.this.mContext.startActivity(localIntent);
      }
    });
    return this.rootView;
  }

  public void setTrainImageUri(String paramString)
  {
    GlideUtils.loadImgByDefault(paramString, 2130903536, this.trainImage);
  }

  public void setTrainName(String paramString)
  {
    this.trainName.setText(paramString);
  }

  public void setTrainSummary(String paramString)
  {
    this.trainSummary.setText(paramString);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.widget.SlidTrainImageView
 * JD-Core Version:    0.6.0
 */