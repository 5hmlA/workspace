package com.sportq.fit.business.find.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.activity.Mine03WebUrlActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.CourseActModel;
import com.sportq.fit.common.model.GoldServiceModel;
import com.sportq.fit.common.model.TrainJoinUserModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity;
import com.sportq.fit.fitmoudle7.customize.activity.CustomStartActivity;
import com.sportq.fit.fitmoudle8.activity.Find02TrainCategoryActivity;
import com.sportq.fit.user_behavior.UserBehaviorImpl;
import java.util.ArrayList;
import java.util.Iterator;

public class CourseActOperationalView extends RelativeLayout
{
  private TextView course_act_desc;
  private ImageView course_act_img;
  private ImageView course_act_status_img;
  private TextView course_act_title;
  private ImageView course_act_type_img;
  private LinearLayout course_join_layout;
  private TextView join_all_user;
  private ImageView join_user01;
  private ImageView join_user02;
  private ImageView join_user03;

  public CourseActOperationalView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    addView(childView(paramContext));
  }

  private View childView(Context paramContext)
  {
    View localView = LayoutInflater.from(paramContext).inflate(2130968728, null);
    this.course_act_img = ((ImageView)localView.findViewById(2131755730));
    this.course_act_type_img = ((ImageView)localView.findViewById(2131755731));
    this.course_act_status_img = ((ImageView)localView.findViewById(2131755732));
    this.course_join_layout = ((LinearLayout)localView.findViewById(2131755733));
    this.join_user01 = ((ImageView)localView.findViewById(2131755734));
    this.join_user02 = ((ImageView)localView.findViewById(2131755735));
    this.join_user03 = ((ImageView)localView.findViewById(2131755736));
    this.join_all_user = ((TextView)localView.findViewById(2131755737));
    this.course_act_title = ((TextView)localView.findViewById(2131755738));
    this.course_act_desc = ((TextView)localView.findViewById(2131755739));
    return localView;
  }

  public void setCourseActData(String paramString, GoldServiceModel paramGoldServiceModel, boolean paramBoolean1, boolean paramBoolean2, int paramInt, CourseActModel paramCourseActModel)
  {
    label175: Iterator localIterator;
    if (paramBoolean2)
    {
      ((RelativeLayout.LayoutParams)this.course_act_img.getLayoutParams()).topMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F);
      ((RelativeLayout.LayoutParams)this.course_act_img.getLayoutParams()).bottomMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 0.0F);
      if (!"0".equals(paramString))
        break label686;
      this.course_join_layout.setVisibility(0);
      this.course_act_status_img.setVisibility(0);
      this.join_user01.setVisibility(8);
      this.join_user02.setVisibility(8);
      this.join_user03.setVisibility(8);
      this.course_act_title.setVisibility(8);
      this.course_act_desc.setVisibility(8);
      if (!"0".equals(paramGoldServiceModel.serviceType))
        break label475;
      this.course_act_type_img.setVisibility(0);
      if ((!"1".equals(BaseApplication.userModel.isVip)) && (!"2".equals(BaseApplication.userModel.isVip)))
        break label426;
      this.course_act_type_img.setImageResource(2130903723);
      localIterator = paramGoldServiceModel.lstJoinUser.iterator();
    }
    while (true)
    {
      if (!localIterator.hasNext())
        break label545;
      TrainJoinUserModel localTrainJoinUserModel = (TrainJoinUserModel)localIterator.next();
      int i = paramGoldServiceModel.lstJoinUser.indexOf(localTrainJoinUserModel);
      if (i == 0)
      {
        this.join_user01.setVisibility(0);
        GlideUtils.loadImgByCircle(localTrainJoinUserModel.userImg, this.join_user01);
        continue;
        if (paramBoolean1)
        {
          label280: RelativeLayout.LayoutParams localLayoutParams2;
          Context localContext2;
          float f2;
          if ("0".equals(paramString))
          {
            ((RelativeLayout.LayoutParams)this.course_act_img.getLayoutParams()).bottomMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F);
            localLayoutParams2 = (RelativeLayout.LayoutParams)this.course_act_img.getLayoutParams();
            localContext2 = getContext();
            if (!"1".equals(paramString))
              break label345;
            f2 = 20.0F;
          }
          while (true)
          {
            localLayoutParams2.topMargin = CompDeviceInfoUtils.convertOfDip(localContext2, f2);
            break;
            setPadding(0, 0, 0, CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F));
            break label280;
            label345: f2 = 10.0F;
          }
        }
        RelativeLayout.LayoutParams localLayoutParams1 = (RelativeLayout.LayoutParams)this.course_act_img.getLayoutParams();
        Context localContext1 = getContext();
        float f1;
        if ("1".equals(paramString))
          f1 = 20.0F;
        while (true)
        {
          localLayoutParams1.topMargin = CompDeviceInfoUtils.convertOfDip(localContext1, f1);
          ((RelativeLayout.LayoutParams)this.course_act_img.getLayoutParams()).bottomMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 0.0F);
          break;
          f1 = 10.0F;
        }
        label426: if (("1".equals(BaseApplication.giftShowFlag)) && ("0".equals(BaseApplication.userModel.hasTryVip)))
        {
          this.course_act_type_img.setImageResource(2130903359);
          break label175;
        }
        this.course_act_type_img.setImageResource(2130903723);
        break label175;
        label475: this.course_act_type_img.setVisibility(8);
        break label175;
      }
      if (i == 1)
      {
        this.join_user02.setVisibility(0);
        GlideUtils.loadImgByCircle(localTrainJoinUserModel.userImg, this.join_user02);
        continue;
      }
      if (i != 2)
        continue;
      this.join_user03.setVisibility(0);
      GlideUtils.loadImgByCircle(localTrainJoinUserModel.userImg, this.join_user03);
    }
    label545: if ((paramGoldServiceModel.lstJoinUser == null) || (paramGoldServiceModel.lstJoinUser.size() == 0))
      this.course_join_layout.setVisibility(8);
    this.join_all_user.setText(paramGoldServiceModel.numberOfParticipants);
    this.course_act_img.getLayoutParams().width = (int)(0.9D * BaseApplication.screenWidth);
    this.course_act_img.getLayoutParams().height = (int)(0.57777D * BaseApplication.screenWidth);
    GlideUtils.loadImgByRadius(paramGoldServiceModel.imgUrl, 2130903536, 8.0F, this.course_act_img);
    if ("1".equals(paramGoldServiceModel.stateCode))
    {
      this.course_act_status_img.setVisibility(0);
      this.course_act_status_img.setImageResource(2130903573);
    }
    while (true)
    {
      this.course_act_img.setOnClickListener(new View.OnClickListener(paramString, paramGoldServiceModel, paramCourseActModel, paramInt)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if ("0".equals(this.val$dataType))
          {
            if ("0".equals(this.val$goldServiceModel.serviceType))
            {
              boolean bool = "1".equals(this.val$goldServiceModel.stateCode);
              String str1 = this.val$goldServiceModel.hasCusFlag;
              String str2 = this.val$goldServiceModel.hasHistoryFlag;
              UserBehaviorImpl localUserBehaviorImpl = new UserBehaviorImpl();
              String str3;
              Intent localIntent4;
              if (bool)
              {
                str3 = "1";
                localUserBehaviorImpl.goldServiceCustomClick(str3);
                if (!bool)
                  break label215;
                if ((!"1".equals(BaseApplication.userModel.isVip)) && (!"3".equals(BaseApplication.userModel.isVip)))
                  break label174;
                localIntent4 = new Intent(CourseActOperationalView.this.getContext(), CustomDetailActivity.class);
              }
              while (true)
              {
                CourseActOperationalView.this.getContext().startActivity(localIntent4);
                AnimationUtil.pageJumpAnim((Activity)CourseActOperationalView.this.getContext(), 0);
                return;
                str3 = "0";
                break;
                label174: localIntent4 = new Intent(CourseActOperationalView.this.getContext(), CustomStartActivity.class);
                localIntent4.putExtra("custom_hascusflag", str1);
                localIntent4.putExtra("custom_hasHistoryFlag", str2);
              }
              label215: Intent localIntent3 = new Intent(CourseActOperationalView.this.getContext(), CustomStartActivity.class);
              localIntent3.putExtra("custom_hascusflag", str1);
              localIntent3.putExtra("custom_hasHistoryFlag", str2);
              CourseActOperationalView.this.getContext().startActivity(localIntent3);
              AnimationUtil.pageJumpAnim((Activity)CourseActOperationalView.this.getContext(), 0);
              return;
            }
            Intent localIntent2 = new Intent(CourseActOperationalView.this.getContext(), Mine03WebUrlActivity.class);
            localIntent2.putExtra("webUrl", this.val$goldServiceModel.linkUrl);
            CourseActOperationalView.this.getContext().startActivity(localIntent2);
            AnimationUtil.pageJumpAnim((Activity)CourseActOperationalView.this.getContext(), 0);
            return;
          }
          new UserBehaviorImpl().selectedThemeItemClick(this.val$goldServiceModel.selectedId);
          Intent localIntent1 = new Intent(CourseActOperationalView.this.getContext(), Find02TrainCategoryActivity.class);
          localIntent1.putExtra("type.id", this.val$goldServiceModel.selectedId);
          localIntent1.putExtra("jump.flg", "0");
          localIntent1.putExtra("act_model", this.val$courseActModel);
          localIntent1.putExtra("act_index", this.val$curIndex);
          CourseActOperationalView.this.getContext().startActivity(localIntent1);
          AnimationUtil.pageJumpAnim((Activity)CourseActOperationalView.this.getContext(), 0);
        }
      });
      return;
      label686: if (!"1".equals(paramString))
        break;
      this.course_act_title.setVisibility(0);
      this.course_act_desc.setVisibility(0);
      this.course_join_layout.setVisibility(8);
      this.course_act_type_img.setVisibility(8);
      this.course_act_status_img.setVisibility(8);
      this.course_act_title.setText(paramGoldServiceModel.selectedTitle);
      this.course_act_desc.setText(paramGoldServiceModel.comment);
      break;
      this.course_act_status_img.setVisibility(8);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.widget.CourseActOperationalView
 * JD-Core Version:    0.6.0
 */