package com.sportq.fit.business.find.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.PlanClassifyModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import java.util.ArrayList;

public class PlanAllClassifyAdapter extends BaseAdapter
{
  private Context context;
  private int imgSize;
  private ArrayList<Integer> lastIndexList;
  private ArrayList<PlanClassifyModel> lstCategory;

  public PlanAllClassifyAdapter(Context paramContext, ArrayList<PlanClassifyModel> paramArrayList)
  {
    this.context = paramContext;
    this.lstCategory = paramArrayList;
    ArrayList localArrayList;
    if (this.lstCategory == null)
    {
      localArrayList = new ArrayList();
      this.lstCategory = localArrayList;
      this.lastIndexList = new ArrayList();
      if (this.lstCategory.size() % 2 != 0)
        break label116;
      this.lastIndexList.add(Integer.valueOf(-1 + this.lstCategory.size()));
      this.lastIndexList.add(Integer.valueOf(-2 + this.lstCategory.size()));
    }
    while (true)
    {
      this.imgSize = (BaseApplication.screenWidth / 2);
      return;
      localArrayList = this.lstCategory;
      break;
      label116: this.lastIndexList.add(Integer.valueOf(-1 + this.lstCategory.size()));
    }
  }

  public int getCount()
  {
    return this.lstCategory.size();
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    label196: int i;
    label228: int j;
    if (paramView == null)
    {
      localViewHolder = new ViewHolder(null);
      paramView = LayoutInflater.from(this.context).inflate(2130969081, null);
      localViewHolder.labels_iv = ((ImageView)paramView.findViewById(2131755560));
      localViewHolder.labels_name = ((TextView)paramView.findViewById(2131755561));
      localViewHolder.energy_icon = ((ImageView)paramView.findViewById(2131757159));
      localViewHolder.labels_num = ((TextView)paramView.findViewById(2131755562));
      paramView.setTag(localViewHolder);
      localViewHolder.labels_iv.getLayoutParams().width = this.imgSize;
      localViewHolder.labels_iv.getLayoutParams().height = this.imgSize;
      GlideUtils.loadImgByDefault(((PlanClassifyModel)this.lstCategory.get(paramInt)).curriculumImageUrl, 2130903536, localViewHolder.labels_iv);
      localViewHolder.labels_name.setText(((PlanClassifyModel)this.lstCategory.get(paramInt)).curriculumName);
      if (!StringUtils.isNull(((PlanClassifyModel)this.lstCategory.get(paramInt)).courseNumber))
        break label304;
      localViewHolder.labels_num.setVisibility(8);
      ImageView localImageView = localViewHolder.energy_icon;
      if (!"4".equals(((PlanClassifyModel)this.lstCategory.get(paramInt)).curriculumtype))
        break label338;
      i = 0;
      localImageView.setVisibility(i);
      if ((paramInt != 0) && (paramInt != 1))
        break label344;
      j = CompDeviceInfoUtils.convertOfDip(this.context, 6.0F);
      label255: if (this.lastIndexList.indexOf(Integer.valueOf(paramInt)) < 0)
        break label350;
    }
    label304: label338: label344: label350: for (int k = CompDeviceInfoUtils.convertOfDip(this.context, 6.0F); ; k = 0)
    {
      paramView.setPadding(0, j, 0, k);
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
      break;
      localViewHolder.labels_num.setVisibility(0);
      localViewHolder.labels_num.setText(((PlanClassifyModel)this.lstCategory.get(paramInt)).courseNumber);
      break label196;
      i = 4;
      break label228;
      j = 0;
      break label255;
    }
  }

  private static final class ViewHolder
  {
    ImageView energy_icon;
    ImageView labels_iv;
    TextView labels_name;
    TextView labels_num;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.adapter.PlanAllClassifyAdapter
 * JD-Core Version:    0.6.0
 */