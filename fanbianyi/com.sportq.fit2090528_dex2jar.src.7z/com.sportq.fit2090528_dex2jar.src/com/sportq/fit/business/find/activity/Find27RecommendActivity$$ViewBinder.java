package com.sportq.fit.business.find.activity;

import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.RelativeLayout;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;

public class Find27RecommendActivity$$ViewBinder<T extends Find27RecommendActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.slideAnimationViewPager = ((ViewPager)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755364, "field 'slideAnimationViewPager'"), 2131755364, "field 'slideAnimationViewPager'"));
    paramT.close_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755296, "field 'close_layout'"), 2131755296, "field 'close_layout'"));
  }

  public void unbind(T paramT)
  {
    paramT.slideAnimationViewPager = null;
    paramT.close_layout = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.activity.Find27RecommendActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */