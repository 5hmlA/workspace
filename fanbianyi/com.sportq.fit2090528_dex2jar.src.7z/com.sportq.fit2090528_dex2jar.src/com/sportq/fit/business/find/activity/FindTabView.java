package com.sportq.fit.business.find.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.BaseNavView;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.common.CheckRedPointUtils;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.event.CustomBannerJumpEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.CarouselModel;
import com.sportq.fit.common.model.CourseActItemModel;
import com.sportq.fit.common.model.CourseActModel;
import com.sportq.fit.common.model.MessageModel;
import com.sportq.fit.common.reformer.BannerReformer;
import com.sportq.fit.common.reformer.MineReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.task.activity.Task01NewChallengesListActivity;
import com.sportq.fit.fitmoudle.task.activity.Task02ChallengeDetailsActivity;
import com.sportq.fit.fitmoudle.widget.CustomScrollView;
import com.sportq.fit.fitmoudle.widget.CustomScrollView.ScrollViewListener;
import com.sportq.fit.fitmoudle.widget.FitCustomItemView;
import com.sportq.fit.fitmoudle.widget.FitCustomItemView.FitItemClickListener;
import com.sportq.fit.fitmoudle.widget.FitCustomItemView.ItemAllClickListener;
import com.sportq.fit.fitmoudle5.activity.MasterClassDetailsActivity;
import com.sportq.fit.fitmoudle5.activity.MasterClassListActivity;
import com.sportq.fit.fitmoudle8.activity.AllCoursesActivity;
import com.sportq.fit.fitmoudle8.activity.Find02TrainCategoryActivity;
import com.sportq.fit.fitmoudle8.activity.Find02TrainCollectionActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.fitmoudle8.activity.FitMusicLibraryActivity;
import com.sportq.fit.fitmoudle8.activity.NewestCourseActivity;
import com.sportq.fit.fitmoudle8.activity.action_library.ActionClassifyActivity;
import com.sportq.fit.manager.viewcompmanager.viewpager.CustomViewPager;
import com.sportq.fit.manager.viewcompmanager.viewpager.FixedSpeedScroller;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior;
import com.sportq.fit.middlelib.statistics.GrowingIOVariables;
import com.sportq.fit.persenter.AppPresenterImpl;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.ApiImpl.OnResJsonListener;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;

public class FindTabView extends BaseNavView
  implements ApiImpl.OnResJsonListener
{
  private Drawable actionDrawable;
  private RTextViewHelper actionHelper;
  private Drawable actionUnreadDrawable;
  private BannerReformer bannerReformer;
  private ImageView course_tv_tag;
  private View findView;
  private LinearLayout find_layout;
  private CustomScrollView find_scrollView;
  private FrameLayout find_tab_title;
  private View find_title_split_line;
  private ImageView gold_medal_service_hot;
  private boolean isNeedRefresh = true;
  private Context mContext;
  private MineReformer mineReformer;
  private Drawable musicDrawable;
  private RTextViewHelper musicHelper;
  private Drawable musicUnreadDrawable;
  private LinearLayout page_index_layout;
  private ImageView place_imgView;
  private ImageView search_course_icon;
  private TextView vPagerText;
  private CustomViewPager viewPager;

  public FindTabView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
  }

  public FindTabView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  private void clearRedPoint(String paramString)
  {
    if (this.mineReformer == null)
      return;
    if (Constant.STR_0.equals(paramString))
    {
      this.mineReformer.messageModel.shouldChallengeShow = false;
      SharePreferenceUtils.putMissionUpdateTime(this.mineReformer.messageModel.missionUpdateTime, Constant.STR_1);
    }
    while (true)
    {
      onCourseTabRedPoint();
      return;
      if (Constant.STR_1.equals(paramString))
      {
        this.mineReformer.messageModel.shouldActionShow = false;
        SharePreferenceUtils.putPlanUpdateTime(this.mineReformer.messageModel.actUpdateTime, Constant.STR_1);
        continue;
      }
      this.mineReformer.messageModel.shouldMusiceLibraryShow = false;
      SharePreferenceUtils.putMusicLibraryTime(this.mineReformer.messageModel.musicUpdateTime, Constant.STR_1);
    }
  }

  private void initViewPager()
  {
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2;
    int i;
    label35: TextView localTextView;
    int j;
    LinearLayout.LayoutParams localLayoutParams;
    if (this.bannerReformer._carouselArray == null)
    {
      localArrayList2 = new ArrayList();
      this.page_index_layout.removeAllViews();
      i = 0;
      if (i >= localArrayList2.size())
        break label261;
      ImageView localImageView = new ImageView(this.mContext);
      CarouselModel localCarouselModel = (CarouselModel)localArrayList2.get(i);
      String str = localCarouselModel.carouselType;
      GlideUtils.loadImgByDefault(localCarouselModel.carouselImageUrl, localImageView);
      5 local5 = new FitAction(this, str, localCarouselModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          GrowingIOVariables localGrowingIOVariables = new GrowingIOVariables();
          localGrowingIOVariables.eventid = "courseCarousel";
          localGrowingIOVariables.carouselType = this.val$strType;
          if (!StringUtils.isNull(this.val$carouseModel.dataId))
            localGrowingIOVariables.carouselId = this.val$carouseModel.dataId;
          GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
          if (("6".equals(this.val$carouseModel.carouselType)) || ("3".equals(this.val$carouseModel.carouselType)))
            EventBus.getDefault().post(new CustomBannerJumpEvent(FindTabView.this.mContext, this.val$carouseModel.carouselType, this.val$carouseModel.carouselAdvertisementUrl));
          while (true)
          {
            super.onClick(paramView);
            return;
            EventBus.getDefault().post(new CustomBannerJumpEvent(FindTabView.this.mContext, this.val$carouseModel.carouselType, this.val$carouseModel.carouselId));
          }
        }
      };
      localImageView.setOnClickListener(local5);
      localArrayList1.add(localImageView);
      if (localArrayList1.size() > 0)
      {
        localTextView = new TextView(this.mContext);
        j = CompDeviceInfoUtils.convertOfDip(this.mContext, 9.0F);
        int k = CompDeviceInfoUtils.convertOfDip(this.mContext, 7.0F);
        if (i == 0)
          break label232;
        localLayoutParams = new LinearLayout.LayoutParams(k, k);
        localLayoutParams.leftMargin = CompDeviceInfoUtils.convertOfDip(this.mContext, 8.0F);
        localTextView.setBackgroundResource(2130903463);
      }
    }
    while (true)
    {
      localLayoutParams.gravity = 16;
      localTextView.setLayoutParams(localLayoutParams);
      this.page_index_layout.addView(localTextView);
      i++;
      break label35;
      localArrayList2 = this.bannerReformer._carouselArray;
      break;
      label232: localLayoutParams = new LinearLayout.LayoutParams(j, j);
      localTextView.setBackgroundResource(2130903462);
      this.vPagerText = localTextView;
    }
    label261: if (localArrayList1.size() > 0)
    {
      if (localArrayList1.size() <= 1)
        break label416;
      CustomViewPager localCustomViewPager2 = this.viewPager;
      CustomViewPagerAdapter localCustomViewPagerAdapter2 = new CustomViewPagerAdapter(localArrayList1);
      localCustomViewPager2.setAdapter(localCustomViewPagerAdapter2);
      this.viewPager.startScroll(localArrayList1.size());
    }
    while (true)
    {
      try
      {
        Field localField = ViewPager.class.getDeclaredField("mScroller");
        localField.setAccessible(true);
        FixedSpeedScroller localFixedSpeedScroller = new FixedSpeedScroller(this.viewPager.getContext(), new LinearInterpolator());
        localFixedSpeedScroller.setmDuration(100);
        localField.set(this.viewPager, localFixedSpeedScroller);
        CustomViewPager localCustomViewPager3 = this.viewPager;
        MyOnPageChangeListener localMyOnPageChangeListener = new MyOnPageChangeListener(localArrayList1, localFixedSpeedScroller, this.page_index_layout);
        localCustomViewPager3.addOnPageChangeListener(localMyOnPageChangeListener);
        this.place_imgView.setVisibility(8);
        return;
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        continue;
      }
      label416: this.page_index_layout.setVisibility(4);
      CustomViewPager localCustomViewPager1 = this.viewPager;
      CustomViewPagerAdapter localCustomViewPagerAdapter1 = new CustomViewPagerAdapter(localArrayList1);
      localCustomViewPager1.setAdapter(localCustomViewPagerAdapter1);
      this.viewPager.setCurrentItem(0);
    }
  }

  private void onCourseTabClickAction(View paramView)
  {
    paramView.findViewById(2131756054).setOnClickListener(new FitAction(this)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(FindTabView.this.mContext, CourseActOperationalActivity.class);
        localIntent.putExtra("jump.type", "0");
        FindTabView.this.mContext.startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)FindTabView.this.mContext, 0);
        super.onClick(paramView);
      }
    });
    paramView.findViewById(2131756055).setOnClickListener(new FitAction(this)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(FindTabView.this.mContext, AllCoursesActivity.class);
        FindTabView.this.mContext.startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)FindTabView.this.mContext, 0);
        super.onClick(paramView);
      }
    });
    paramView.findViewById(2131755844).setOnClickListener(new FitAction(this)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        FindTabView.this.clearRedPoint(Constant.STR_1);
        Intent localIntent = new Intent(FindTabView.this.mContext, ActionClassifyActivity.class);
        FindTabView.this.mContext.startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)FindTabView.this.mContext, 0);
        super.onClick(paramView);
      }
    });
    paramView.findViewById(2131755853).setOnClickListener(new FitAction(this)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        FindTabView.this.clearRedPoint(Constant.STR_2);
        FindTabView.this.mContext.startActivity(new Intent(FindTabView.this.mContext, FitMusicLibraryActivity.class));
        AnimationUtil.pageJumpAnim((Activity)FindTabView.this.mContext, 0);
        super.onClick(paramView);
      }
    });
  }

  private void onCourseTabRedPoint()
  {
    if (this.mineReformer == null)
      return;
    RTextViewHelper localRTextViewHelper1 = this.actionHelper;
    Drawable localDrawable1;
    RTextViewHelper localRTextViewHelper2;
    if (CheckRedPointUtils.isFitAction(this.mineReformer))
    {
      localDrawable1 = this.actionUnreadDrawable;
      localRTextViewHelper1.setIconNormal(localDrawable1);
      localRTextViewHelper2 = this.musicHelper;
      if (!CheckRedPointUtils.isMusicAction(this.mineReformer))
        break label73;
    }
    label73: for (Drawable localDrawable2 = this.musicUnreadDrawable; ; localDrawable2 = this.musicDrawable)
    {
      localRTextViewHelper2.setIconNormal(localDrawable2);
      return;
      localDrawable1 = this.actionDrawable;
      break;
    }
  }

  private View onCreateView()
  {
    this.findView = LayoutInflater.from(this.mContext).inflate(2130968839, null);
    this.find_scrollView = ((CustomScrollView)this.findView.findViewById(2131756120));
    this.find_tab_title = ((FrameLayout)this.findView.findViewById(2131756123));
    this.search_course_icon = ((ImageView)this.findView.findViewById(2131756125));
    this.find_title_split_line = this.findView.findViewById(2131756126);
    TextView localTextView = (TextView)this.findView.findViewById(2131756124);
    this.search_course_icon.setOnClickListener(new FitAction(null)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(FindTabView.this.mContext, AllCoursesActivity.class);
        localIntent.putExtra("search.tag", "search");
        FindTabView.this.mContext.startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)FindTabView.this.mContext, 0);
        super.onClick(paramView);
      }
    });
    this.find_scrollView.setScrollViewListener(new CustomScrollView.ScrollViewListener(localTextView)
    {
      public void onScrollChanged(CustomScrollView paramCustomScrollView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
      {
        if (paramInt2 > 0)
          if (FindTabView.this.find_tab_title.getTag() == null)
          {
            FindTabView.this.find_tab_title.setTag("mine");
            FindTabView.this.find_tab_title.setBackgroundResource(2131624328);
            if (Build.VERSION.SDK_INT >= 21)
            {
              FindTabView.this.find_tab_title.setElevation(CompDeviceInfoUtils.convertOfDip(FindTabView.this.getContext(), 3.0F));
              FindTabView.this.find_title_split_line.setVisibility(8);
              this.val$course_title_hint.setText(FindTabView.this.mContext.getString(2131296948));
              FindTabView.this.search_course_icon.setImageResource(2130903085);
            }
          }
          else
          {
            if (Math.abs(paramInt2) / 600.0F < 1.0F)
              break label154;
            FindTabView.this.find_tab_title.setAlpha(1.0F);
          }
        label154: 
        do
        {
          return;
          FindTabView.this.find_title_split_line.setVisibility(0);
          break;
          FindTabView.this.find_tab_title.setAlpha(Math.abs(paramInt2) / 600.0F);
          return;
        }
        while (FindTabView.this.find_tab_title.getTag() == null);
        FindTabView.this.find_tab_title.setTag(null);
        FindTabView.this.find_tab_title.setBackgroundResource(0);
        if (Build.VERSION.SDK_INT >= 21)
        {
          FindTabView.this.find_tab_title.setElevation(0.0F);
          FindTabView.this.find_title_split_line.setVisibility(8);
        }
        while (true)
        {
          this.val$course_title_hint.setText("");
          FindTabView.this.search_course_icon.setImageResource(2130903737);
          FindTabView.this.find_tab_title.setAlpha(1.0F);
          return;
          FindTabView.this.find_title_split_line.setVisibility(8);
        }
      }
    });
    this.find_layout = ((LinearLayout)this.findView.findViewById(2131756121));
    this.viewPager = ((CustomViewPager)this.findView.findViewById(2131755321));
    int i = (int)(0.5525D * FitApplication.screenWidth);
    this.viewPager.setLayoutParams(new FrameLayout.LayoutParams(FitApplication.screenWidth, i));
    this.place_imgView = ((ImageView)this.findView.findViewById(2131756122));
    this.place_imgView.getLayoutParams().height = i;
    this.page_index_layout = ((LinearLayout)this.findView.findViewById(2131756052));
    this.gold_medal_service_hot = ((ImageView)this.findView.findViewById(2131756057));
    this.course_tv_tag = ((ImageView)this.findView.findViewById(2131756059));
    this.actionHelper = ((RTextView)this.findView.findViewById(2131756060)).getHelper();
    this.actionDrawable = ContextCompat.getDrawable(this.mContext, 2130903370);
    this.actionUnreadDrawable = ContextCompat.getDrawable(this.mContext, 2130903371);
    this.musicHelper = ((RTextView)this.findView.findViewById(2131756061)).getHelper();
    this.musicDrawable = ContextCompat.getDrawable(this.mContext, 2130903436);
    this.musicUnreadDrawable = ContextCompat.getDrawable(this.mContext, 2130903440);
    onCourseTabClickAction(this.findView);
    return this.findView;
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (!this.isNeedRefresh)
      return;
    this.bannerReformer = ((BannerReformer)paramT);
    initViewPager();
    if ((this.bannerReformer != null) && (!StringUtils.isNull(this.bannerReformer.imgUrl)))
    {
      this.gold_medal_service_hot.setVisibility(0);
      GlideUtils.loadImgByAdjust(this.bannerReformer.imgUrl, this.gold_medal_service_hot);
      label62: if ((this.bannerReformer == null) || (StringUtils.isNull(this.bannerReformer.imgKckUrl)))
        break label238;
      this.course_tv_tag.setVisibility(0);
      GlideUtils.loadImgByAdjust(this.bannerReformer.imgKckUrl, this.course_tv_tag);
    }
    while (true)
    {
      onCourseTabRedPoint();
      if (this.find_layout.getChildCount() > 2)
        this.find_layout.removeViewsInLayout(2, -2 + this.find_layout.getChildCount());
      Iterator localIterator = this.bannerReformer.lstPlate.iterator();
      while (localIterator.hasNext())
      {
        CourseActModel localCourseActModel = (CourseActModel)localIterator.next();
        FitCustomItemView localFitCustomItemView = new FitCustomItemView(this.mContext);
        localFitCustomItemView.initFindView(localCourseActModel);
        localFitCustomItemView.setFitItemClickListener(new FitCustomItemView.FitItemClickListener(localCourseActModel)
        {
          public void fitItemClick(int paramInt)
          {
            CourseActItemModel localCourseActItemModel = (CourseActItemModel)this.val$courseActModel.lstplateDet.get(paramInt);
            Intent localIntent;
            if ("0".equals(this.val$courseActModel.plateType))
            {
              localIntent = new Intent(FindTabView.this.mContext, Task02ChallengeDetailsActivity.class);
              localIntent.putExtra("missionId", localCourseActItemModel.missionId);
              localIntent.putExtra("missionName", localCourseActItemModel.missionName);
            }
            while (true)
            {
              if (localIntent != null)
              {
                FindTabView.this.mContext.startActivity(localIntent);
                AnimationUtil.pageJumpAnim((Activity)FindTabView.this.mContext, 0);
              }
              return;
              if ("1".equals(this.val$courseActModel.plateType))
              {
                localIntent = new Intent(FindTabView.this.getContext(), Find02TrainCategoryActivity.class);
                localIntent.putExtra("type.id", localCourseActItemModel.selectedId);
                localIntent.putExtra("jump.flg", "0");
                localIntent.putExtra("act_model", this.val$courseActModel);
                localIntent.putExtra("act_index", paramInt);
                continue;
              }
              if ("2".equals(this.val$courseActModel.plateType))
              {
                localIntent = new Intent(FindTabView.this.mContext, Find04GenTrainInfoActivity.class);
                localIntent.putExtra("single.type", "0");
                localIntent.putExtra("plan.id", localCourseActItemModel.planId);
                continue;
              }
              if ("3".equals(this.val$courseActModel.plateType))
              {
                if ("1".equals(localCourseActItemModel.curriculumtype))
                {
                  localIntent = new Intent(FindTabView.this.mContext, Find02TrainCollectionActivity.class);
                  localIntent.putExtra("group.id", localCourseActItemModel.groupId);
                  continue;
                }
                localIntent = new Intent(FindTabView.this.mContext, Find02TrainCategoryActivity.class);
                localIntent.putExtra("type.id", localCourseActItemModel.classifyId);
                localIntent.putExtra("train.name", localCourseActItemModel.curriculumName);
                localIntent.putExtra("classify.type", localCourseActItemModel.curriculumtype);
                continue;
              }
              boolean bool = "4".equals(this.val$courseActModel.plateType);
              localIntent = null;
              if (!bool)
                continue;
              localIntent = new Intent(FindTabView.this.getContext(), MasterClassDetailsActivity.class);
              localIntent.putExtra("lesson.id", localCourseActItemModel.lessonId);
            }
          }
        });
        localFitCustomItemView.setItemAllClickListener(new FitCustomItemView.ItemAllClickListener(localCourseActModel)
        {
          public void itemAllClick()
          {
            Intent localIntent;
            if ("0".equals(this.val$courseActModel.plateType))
              localIntent = new Intent(FindTabView.this.mContext, Task01NewChallengesListActivity.class);
            while (true)
            {
              if (localIntent != null)
              {
                FindTabView.this.mContext.startActivity(localIntent);
                AnimationUtil.pageJumpAnim((Activity)FindTabView.this.mContext, 0);
              }
              return;
              if ("1".equals(this.val$courseActModel.plateType))
              {
                localIntent = new Intent(FindTabView.this.mContext, CourseActOperationalActivity.class);
                localIntent.putExtra("plate_id", this.val$courseActModel.plateId);
                localIntent.putExtra("jump.type", "1");
                continue;
              }
              if ("2".equals(this.val$courseActModel.plateType))
              {
                localIntent = new Intent(FindTabView.this.mContext, NewestCourseActivity.class);
                continue;
              }
              if ("3".equals(this.val$courseActModel.plateType))
              {
                localIntent = new Intent(FindTabView.this.mContext, PlanAllClassifyActivity.class);
                continue;
              }
              boolean bool = "4".equals(this.val$courseActModel.plateType);
              localIntent = null;
              if (!bool)
                continue;
              localIntent = new Intent(FindTabView.this.mContext, MasterClassListActivity.class);
            }
          }
        });
        this.find_layout.addView(localFitCustomItemView);
      }
      break;
      this.gold_medal_service_hot.setVisibility(8);
      break label62;
      label238: this.course_tv_tag.setVisibility(8);
    }
  }

  public void onResJson(String paramString)
  {
    if (StringUtils.isNull(String.valueOf(this.find_scrollView.getTag())))
    {
      this.find_scrollView.setTag(paramString);
      return;
    }
    if (String.valueOf(this.find_scrollView.getTag()).equals(paramString))
    {
      this.isNeedRefresh = false;
      return;
    }
    this.isNeedRefresh = true;
    this.find_scrollView.setTag(paramString);
  }

  public void setDataForPage()
  {
    if (this.find_scrollView == null)
      addView(onCreateView());
    AppPresenterImpl localAppPresenterImpl = new AppPresenterImpl(this);
    ((ApiImpl)localAppPresenterImpl.getApi()).setOnResJsonListener(this);
    localAppPresenterImpl.getPlanTab(this.mContext);
  }

  public void setMineReformer(MineReformer paramMineReformer)
  {
    this.mineReformer = paramMineReformer;
    if (this.find_scrollView == null)
      return;
    onCourseTabRedPoint();
  }

  private class MyOnPageChangeListener
    implements ViewPager.OnPageChangeListener
  {
    private ArrayList<View> listViews;
    private FixedSpeedScroller mScroller;
    private LinearLayout page_index_layout;

    MyOnPageChangeListener(FixedSpeedScroller paramLinearLayout, LinearLayout arg3)
    {
      this.listViews = paramLinearLayout;
      Object localObject1;
      this.mScroller = localObject1;
      Object localObject2;
      this.page_index_layout = localObject2;
    }

    public void onPageScrollStateChanged(int paramInt)
    {
    }

    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
    {
    }

    public void onPageSelected(int paramInt)
    {
      if (paramInt == -1 + this.listViews.size())
      {
        if (this.mScroller == null)
          return;
        this.mScroller.setmDuration(0);
      }
      while (true)
      {
        FindTabView.this.vPagerText.setBackgroundResource(2130903463);
        LinearLayout.LayoutParams localLayoutParams1 = (LinearLayout.LayoutParams)FindTabView.this.vPagerText.getLayoutParams();
        localLayoutParams1.gravity = 16;
        localLayoutParams1.width = CompDeviceInfoUtils.convertOfDip(FindTabView.this.mContext, 7.0F);
        localLayoutParams1.height = CompDeviceInfoUtils.convertOfDip(FindTabView.this.mContext, 7.0F);
        FindTabView.this.vPagerText.setLayoutParams(localLayoutParams1);
        TextView localTextView = (TextView)this.page_index_layout.getChildAt(paramInt);
        localTextView.setBackgroundResource(2130903462);
        LinearLayout.LayoutParams localLayoutParams2 = (LinearLayout.LayoutParams)localTextView.getLayoutParams();
        localLayoutParams2.gravity = 16;
        localLayoutParams2.width = CompDeviceInfoUtils.convertOfDip(FindTabView.this.mContext, 9.0F);
        localLayoutParams2.height = CompDeviceInfoUtils.convertOfDip(FindTabView.this.mContext, 9.0F);
        localTextView.setLayoutParams(localLayoutParams2);
        FindTabView.access$502(FindTabView.this, localTextView);
        return;
        if (paramInt != 0)
          continue;
        if (this.mScroller == null)
          break;
        this.mScroller.setmDuration(100);
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.activity.FindTabView
 * JD-Core Version:    0.6.0
 */