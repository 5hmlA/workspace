package com.sportq.fit.business.find.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ProgressBar;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.find.adapter.PlanAllClassifyAdapter;
import com.sportq.fit.common.model.PlanClassifyModel;
import com.sportq.fit.common.reformer.PlanClassifyReformer;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle8.activity.AllCoursesActivity;
import com.sportq.fit.fitmoudle8.activity.Find02TrainCategoryActivity;
import com.sportq.fit.fitmoudle8.activity.Find02TrainCollectionActivity;
import com.sportq.fit.persenter.AppPresenterImpl;
import com.sportq.fit.user_behavior.UserBehaviorImpl;
import java.util.ArrayList;

public class PlanAllClassifyActivity extends BaseActivity
{
  private GridView grid_view;
  private ProgressBar loader_icon;
  private ArrayList<PlanClassifyModel> lstCategory;
  private CustomToolBar toolbar;

  private void initElements()
  {
    this.toolbar = ((CustomToolBar)findViewById(2131755432));
    this.toolbar.setAppTitle("课程分类");
    this.toolbar.setNavIcon(2130903080);
    this.toolbar.setToolbarBg(2131624328);
    this.toolbar.setToolbarTitleColor(2131624003);
    setSupportActionBar(this.toolbar);
    this.lstCategory = new ArrayList();
    this.grid_view = ((GridView)findViewById(2131755452));
    this.loader_icon = ((ProgressBar)findViewById(2131755304));
  }

  public <T> void getDataFail(T paramT)
  {
    this.loader_icon.setVisibility(4);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.loader_icon.setVisibility(4);
    PlanClassifyReformer localPlanClassifyReformer;
    if ((paramT instanceof PlanClassifyReformer))
    {
      localPlanClassifyReformer = (PlanClassifyReformer)paramT;
      if ((localPlanClassifyReformer.lstCurriculum != null) && (localPlanClassifyReformer.lstCurriculum.size() != 0));
    }
    else
    {
      return;
    }
    if (!StringUtils.isNull(localPlanClassifyReformer.curriculumName))
    {
      this.toolbar.setAppTitle(localPlanClassifyReformer.curriculumName);
      this.toolbar.setNavIcon(2130903080);
      this.toolbar.setToolbarBg(2131624328);
      this.toolbar.setToolbarTitleColor(2131624003);
      setSupportActionBar(this.toolbar);
    }
    this.lstCategory.clear();
    this.lstCategory.addAll(localPlanClassifyReformer.lstCurriculum);
    PlanAllClassifyAdapter localPlanAllClassifyAdapter = new PlanAllClassifyAdapter(this, this.lstCategory);
    this.grid_view.setAdapter(localPlanAllClassifyAdapter);
    this.grid_view.setOnItemClickListener(new AdapterView.OnItemClickListener()
    {
      @Instrumented
      public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
      {
        VdsAgent.onItemClick(this, paramAdapterView, paramView, paramInt, paramLong);
        while (true)
        {
          try
          {
            if (!((PlanClassifyModel)PlanAllClassifyActivity.this.lstCategory.get(paramInt)).curriculumName.contains("全部课程"))
              continue;
            Intent localIntent1 = new Intent(PlanAllClassifyActivity.this, AllCoursesActivity.class);
            PlanAllClassifyActivity.this.startActivity(localIntent1);
            AnimationUtil.pageJumpAnim(PlanAllClassifyActivity.this, 0);
            new UserBehaviorImpl().courseClassItemClick(((PlanClassifyModel)PlanAllClassifyActivity.this.lstCategory.get(paramInt)).olapInfo);
            return;
            if ("1".equals(((PlanClassifyModel)PlanAllClassifyActivity.this.lstCategory.get(paramInt)).curriculumtype))
            {
              localIntent2 = new Intent(PlanAllClassifyActivity.this, Find02TrainCollectionActivity.class);
              localIntent2.putExtra("group.id", ((PlanClassifyModel)PlanAllClassifyActivity.this.lstCategory.get(paramInt)).groupId);
              PlanAllClassifyActivity.this.startActivity(localIntent2);
              AnimationUtil.pageJumpAnim(PlanAllClassifyActivity.this, 0);
              continue;
            }
          }
          catch (Exception localException)
          {
            LogUtils.e(localException);
            return;
          }
          Intent localIntent2 = new Intent(PlanAllClassifyActivity.this, Find02TrainCategoryActivity.class);
          localIntent2.putExtra("type.id", ((PlanClassifyModel)PlanAllClassifyActivity.this.lstCategory.get(paramInt)).classifyId);
          localIntent2.putExtra("train.name", ((PlanClassifyModel)PlanAllClassifyActivity.this.lstCategory.get(paramInt)).curriculumName);
          localIntent2.putExtra("classify.type", ((PlanClassifyModel)PlanAllClassifyActivity.this.lstCategory.get(paramInt)).curriculumtype);
        }
      }
    });
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969080);
    initElements();
    this.loader_icon.setVisibility(0);
    new AppPresenterImpl(this).getPlanClassify(this);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.find.activity.PlanAllClassifyActivity
 * JD-Core Version:    0.6.0
 */