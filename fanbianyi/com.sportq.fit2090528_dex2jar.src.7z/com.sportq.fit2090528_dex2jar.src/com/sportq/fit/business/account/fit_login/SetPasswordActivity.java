package com.sportq.fit.business.account.fit_login;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.business.account.widget.EditItemView.EditListener;
import com.sportq.fit.business.account.widget.EditItemView.ItemType;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.MD5Util;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.middlelib.MiddleManager;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class SetPasswordActivity extends BaseActivity
{
  public static final String PAGE_FROM = "page.from";
  public static final String PHONE_NUM = "phone.num";

  @Bind({2131755524})
  RTextView confirm_btn;

  @Bind({2131757045})
  TextView header_right_btn;

  @Bind({2131756401})
  EditItemView password_edit_layout;
  private String strPageFrom = "";
  private String strPassword;
  private String strPhoneNum;

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131757043:
    case 2131757045:
    case 2131755524:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      AppSharePreferenceUtils.putSkipSetPassword(true);
      Intent localIntent = new Intent(this, PerfectInfoActivity.class);
      localIntent.putExtra("jump.type", BaseApplication.userModel.terrace);
      startActivity(localIntent);
      finish();
      AnimationUtil.pageJumpAnim(this, 0);
      continue;
      if (!CompDeviceInfoUtils.checkNetwork())
      {
        ToastUtils.makeToast(this, getResources().getString(2131299052));
        return;
      }
      if (!StringUtils.checkPassword(this.strPassword))
      {
        ToastUtils.makeToast(this, "密码仅支持数字，英文字母，下划线或横线");
        return;
      }
      this.dialog.createProgressDialog(this, "请稍后...");
      if ("1".equals(this.strPageFrom))
      {
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.terrace = "8";
        localRequestModel.mbType = "0";
        localRequestModel.phoneNumber = this.strPhoneNum;
        localRequestModel.password = MD5Util.MD5(this.strPassword);
        MiddleManager.getInstance().getLoginPresenterImpl(this).userRegister(localRequestModel, this);
        continue;
      }
      MiddleManager.getInstance().getLoginPresenterImpl(this).postPassword(this.strPassword, this.strPassword, this.strPhoneNum, this);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    Intent localIntent;
    if ("Y".equals(paramT))
    {
      localIntent = new Intent(this, PerfectInfoActivity.class);
      localIntent.putExtra("jump.type", "8");
    }
    while (true)
    {
      if (localIntent != null)
      {
        startActivity(localIntent);
        finish();
        AnimationUtil.pageJumpAnim(this, 0);
      }
      super.getDataSuccess(paramT);
      return;
      boolean bool = paramT instanceof LoginReformer;
      localIntent = null;
      if (!bool)
        continue;
      BaseApplication.userModel.password = MD5Util.MD5(this.strPassword);
      if ("0".equals(this.strPageFrom))
      {
        localIntent = new Intent(this, PerfectInfoActivity.class);
        localIntent.putExtra("jump.type", "8");
        continue;
      }
      localIntent = new Intent(this, LoginActivity.class);
      localIntent.putExtra("page.index", 0);
      localIntent.putExtra("phone.num", this.strPhoneNum);
      ToastUtils.makeToast(this, "修改成功");
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969108);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    EventBus.getDefault().register(this);
    this.strPhoneNum = getIntent().getStringExtra("phone.num");
    this.strPageFrom = getIntent().getStringExtra("page.from");
    this.confirm_btn.setText(getString(2131298353));
    this.password_edit_layout.setEditHint(getString(2131298320)).setItemType(EditItemView.ItemType.PASSWORD).showHideBtn().setListener(new EditItemView.EditListener()
    {
      public void onChangeResult(String paramString)
      {
        SetPasswordActivity.access$002(SetPasswordActivity.this, paramString);
        boolean bool;
        int i;
        label52: RTextView localRTextView;
        SetPasswordActivity localSetPasswordActivity2;
        if (SetPasswordActivity.this.strPassword.length() >= 6)
        {
          bool = true;
          RTextViewHelper localRTextViewHelper = SetPasswordActivity.this.confirm_btn.getHelper();
          SetPasswordActivity localSetPasswordActivity1 = SetPasswordActivity.this;
          if (!bool)
            break label117;
          i = 2131624121;
          localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(localSetPasswordActivity1, i));
          localRTextView = SetPasswordActivity.this.confirm_btn;
          localSetPasswordActivity2 = SetPasswordActivity.this;
          if (!bool)
            break label124;
        }
        label117: label124: for (int j = 2131624003; ; j = 2131624071)
        {
          localRTextView.setTextColor(ContextCompat.getColor(localSetPasswordActivity2, j));
          SetPasswordActivity.this.confirm_btn.setEnabled(bool);
          return;
          bool = false;
          break;
          i = 2131624105;
          break label52;
        }
      }
    });
    this.confirm_btn.setEnabled(false);
    if ("0".equals(this.strPageFrom))
    {
      SharePreferenceUtils.putLoginStatus(this, "perfect.info");
      this.header_right_btn.setText(getString(2131298399));
    }
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("perfect.info".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.SetPasswordActivity
 * JD-Core Version:    0.6.0
 */