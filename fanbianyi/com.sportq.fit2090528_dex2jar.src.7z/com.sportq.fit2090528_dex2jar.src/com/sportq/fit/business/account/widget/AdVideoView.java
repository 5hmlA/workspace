package com.sportq.fit.business.account.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import android.widget.VideoView;

public class AdVideoView extends VideoView
{
  private int height;
  private int width;

  public AdVideoView(Context paramContext)
  {
    super(paramContext);
  }

  public AdVideoView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public AdVideoView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    int i = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt2);
    if ((this.width > 0) && (this.height > 0))
    {
      i = this.width;
      j = this.height;
    }
    setMeasuredDimension(i, j);
  }

  public void setMeasure(int paramInt1, int paramInt2)
  {
    this.width = paramInt1;
    this.height = paramInt2;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.widget.AdVideoView
 * JD-Core Version:    0.6.0
 */