package com.sportq.fit.business.account.activity;

import android.content.Intent;
import android.os.Bundle;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.liulishuo.filedownloader.FileDownloader;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.account.fit_login.PerfectInfoActivity;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.WelcomeModel;
import com.sportq.fit.common.utils.CustomerServiceUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.HwIdUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.middlelib.MiddleManager;
import com.stub.StubApp;

public class SptStartAppActivity extends BaseActivity
{
  WelcomeModel model;

  private void checkUserImgCache()
  {
    try
    {
      if (!StringUtils.isNull(BaseApplication.userModel.userImg))
        GlideUtils.downloadImgCache(BaseApplication.userModel.userImg);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void jumpNextActivity()
  {
    SharePreferenceUtils.putOperateExcuteFlg(this, "");
    String str1 = SharePreferenceUtils.getLoginStatus(this);
    Intent localIntent1;
    if ("login".equals(str1))
    {
      String str2 = AppSharePreferenceUtils.getWechatLogOffTag(this);
      String str3 = SharePreferenceUtils.getWechatUnionId(BaseApplication.appliContext);
      if ((BaseApplication.userModel != null) && (!StringUtils.isNull(BaseApplication.userModel.userId)))
        if ((StringUtils.isNull(str2)) && (StringUtils.isNull(str3)) && (("7".equals(BaseApplication.userModel.loginTerrace)) || ("7".equals(BaseApplication.userModel.terrace)) || (!StringUtils.isNull(BaseApplication.userModel.weixinUid))))
        {
          SharePreferenceUtils.putWechatUnionId(this, "");
          MiddleManager.getInstance().getRegisterPresenterImpl(this).ssoRemoveAccount(this, "Wechat");
          AppSharePreferenceUtils.putWechatLogOffTag(this, "have.been.logoff");
          localIntent1 = new Intent(this, Account02VideoGuideActivity.class);
          startActivity(localIntent1);
          overridePendingTransition(2131034124, 2131034125);
          finish();
        }
    }
    while (true)
    {
      startActivity(localIntent1);
      overridePendingTransition(2131034124, 2131034125);
      finish();
      return;
      this.model = MiddleManager.getInstance().getLoginPresenterImpl(this).getAdLocalCacheData(this);
      Intent localIntent3 = new Intent(this, FitStartAppActivity.class);
      Bundle localBundle2 = new Bundle();
      localBundle2.putSerializable("ad.model", this.model);
      localIntent3.putExtras(localBundle2);
      startActivity(localIntent3);
      overridePendingTransition(2131034124, 2131034125);
      finish();
      return;
      this.model = MiddleManager.getInstance().getLoginPresenterImpl(this).getAdLocalCacheData(this);
      Intent localIntent2 = new Intent(this, FitStartAppActivity.class);
      Bundle localBundle1 = new Bundle();
      localBundle1.putSerializable("ad.model", this.model);
      localIntent2.putExtras(localBundle1);
      startActivity(localIntent2);
      overridePendingTransition(2131034124, 2131034125);
      finish();
      return;
      if ("perfect.info".equals(str1))
      {
        localIntent1 = new Intent(this, PerfectInfoActivity.class);
        localIntent1.putExtra("jump.type", FitApplication.userModel.terrace);
        continue;
      }
      if ((BaseApplication.userModel != null) && (!StringUtils.isNull(BaseApplication.userModel.userId)) && (!StringUtils.isNull(BaseApplication.userModel.userSex)))
      {
        localIntent1 = new Intent(this, Account03QuickLoginActivity.class);
        continue;
      }
      localIntent1 = new Intent(this, Account02VideoGuideActivity.class);
    }
  }

  private void parseIntent()
  {
    if (getIntent().hasExtra("com.netease.nim.EXTRA.NOTIFY_CONTENT.UNICORN"))
    {
      CustomerServiceUtils.openServiceActivity(this);
      setIntent(new Intent());
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969209);
    FileDownloader.setup(this);
    parseIntent();
    if (!isTaskRoot())
    {
      Intent localIntent = getIntent();
      String str5 = localIntent.getAction();
      if ((localIntent.hasCategory("android.intent.category.LAUNCHER")) && (str5 != null) && (str5.equals("android.intent.action.MAIN")))
      {
        finish();
        return;
      }
    }
    HwIdUtils.connect(this);
    String str2;
    String str3;
    if (VersionUpdateCheck.changeTestPathFlg)
    {
      String str1 = SharePreferenceUtils.getBdTestPath(this);
      str2 = SharePreferenceUtils.getTestPath(this);
      if (StringUtils.isNull(str1))
        str1 = VersionUpdateCheck.BD_TEST_ADDRESS;
      VersionUpdateCheck.STATISTICS_HOST_ADDRESS = str1;
      if (!StringUtils.isNull(str2))
        break label157;
      str3 = VersionUpdateCheck.HOST_ADDRESS;
      VersionUpdateCheck.HOST_ADDRESS = str3;
      if (!StringUtils.isNull(str2))
        break label163;
    }
    label157: label163: for (String str4 = VersionUpdateCheck.HOST_ADDRESS; ; str4 = str2)
    {
      VersionUpdateCheck.BACK_ADDRESS = str4;
      if (StringUtils.isNull(str2))
        str2 = VersionUpdateCheck.HOST_ADDRESS;
      VersionUpdateCheck.HOST_ADDRESS01 = str2;
      checkUserImgCache();
      jumpNextActivity();
      return;
      str3 = str2;
      break;
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    StubApp.mark();
    super.onCreate(paramBundle);
  }

  @Instrumented
  protected void onNewIntent(Intent paramIntent)
  {
    VdsAgent.onNewIntent(this, paramIntent);
    setIntent(paramIntent);
    parseIntent();
  }

  protected void onStart()
  {
    super.onStart();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.SptStartAppActivity
 * JD-Core Version:    0.6.0
 */