package com.sportq.fit.business.account.fit_login;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.common.utils.superView.RTextView;

public class PerfectInfoActivity$$ViewBinder<T extends PerfectInfoActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.camera_img = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757124, "field 'camera_img'"), 2131757124, "field 'camera_img'"));
    paramT.username_edit_layout = ((EditItemView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757125, "field 'username_edit_layout'"), 2131757125, "field 'username_edit_layout'"));
    paramT.next_step = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755448, "field 'next_step'"), 2131755448, "field 'next_step'"));
    paramT.select_username_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757126, "field 'select_username_layout'"), 2131757126, "field 'select_username_layout'"));
    paramT.select_username1 = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757129, "field 'select_username1'"), 2131757129, "field 'select_username1'"));
    paramT.select_username2 = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757130, "field 'select_username2'"), 2131757130, "field 'select_username2'"));
    paramT.select_username3 = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757131, "field 'select_username3'"), 2131757131, "field 'select_username3'"));
  }

  public void unbind(T paramT)
  {
    paramT.camera_img = null;
    paramT.username_edit_layout = null;
    paramT.next_step = null;
    paramT.select_username_layout = null;
    paramT.select_username1 = null;
    paramT.select_username2 = null;
    paramT.select_username3 = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.PerfectInfoActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */