package com.sportq.fit.business.account.fit_login;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;
import com.sportq.fit.fitmoudle.network.reformer.NeceDataUIReformer;
import com.sportq.fit.middlelib.MiddleManager;

public class VoiceVerCodeActivity extends BaseActivity
{
  public static final String PAGE_FROM = "page.from";
  public static final String PHONE_NUM = "phone.num";

  @Bind({2131757866})
  TextView phone_info;

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131757043:
    case 2131755522:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      this.dialog.createProgressDialog(this, "请稍后...");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = getIntent().getStringExtra("phone.num");
      new PresenterImpl(this).getNeceData(localRequestModel, this, false);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof NeceDataUIReformer))
    {
      String str = ((NeceDataUIReformer)paramT).timeKey;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = getIntent().getStringExtra("phone.num");
      localRequestModel.acquisitionMode = getIntent().getStringExtra("page.from");
      localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(str + NdkUtils.getSignBaseUrl()).toUpperCase();
      MiddleManager.getInstance().getLoginPresenterImpl(this).getVerification(localRequestModel, this);
    }
    do
    {
      do
        return;
      while (!(paramT instanceof LoginReformer));
      this.dialog.closeDialog();
    }
    while (!"0".equals(((LoginReformer)paramT).tag));
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969241);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    String str = "请确认手机信息\n归属地：中国大陆 (+86)\n手机号：" + getIntent().getStringExtra("phone.num");
    this.phone_info.setText(str);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.VoiceVerCodeActivity
 * JD-Core Version:    0.6.0
 */