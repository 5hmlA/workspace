package com.sportq.fit.business.account.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.NavMainActivity;
import com.sportq.fit.business.account.adapter.Account07RecPlanAdapter;
import com.sportq.fit.business.account.adapter.Account07RecPlanAdapter.ItemClickListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.common.reformer.RecommendReformer;
import com.sportq.fit.common.utils.BigDecimalUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RRelativeLayout;
import com.sportq.fit.common.utils.superView.helper.RBaseHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle8.presenter.PresenterImpl;
import com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior;
import com.sportq.fit.middlelib.statistics.GrowingIOVariables;
import com.sportq.fit.persenter.AppPresenterImpl;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;

public class Account07RecPlanActivity extends BaseActivity
  implements Account07RecPlanAdapter.ItemClickListener
{
  Account07RecPlanAdapter account07RecPlanAdapter;
  RelativeLayout bottom_layout;
  private ArrayList<PlanModel> dataList = new ArrayList();
  private View footView;
  private View headView;
  ImageView header_back_img;
  View header_spilt_line;
  TextView header_title;
  FrameLayout new_head_view;
  RecyclerView recyclerView;
  ArrayList<String> selectList = new ArrayList();
  RRelativeLayout select_all;
  ImageView select_all_icn;

  private void clickAllTrainJoinAction()
  {
    int i = 0;
    if (i < this.dataList.size())
    {
      PlanModel localPlanModel2 = (PlanModel)this.dataList.get(i);
      if (!"select.all".equals(this.select_all.getTag().toString()));
      for (boolean bool2 = true; ; bool2 = false)
      {
        localPlanModel2.iswaiting = bool2;
        i++;
        break;
      }
    }
    RRelativeLayout localRRelativeLayout = this.select_all;
    String str;
    int j;
    label128: RBaseHelper localRBaseHelper;
    if ("select.all".equals(this.select_all.getTag().toString()))
    {
      str = "unSelect";
      localRRelativeLayout.setTag(str);
      ImageView localImageView = this.select_all_icn;
      boolean bool1 = "select.all".equals(this.select_all.getTag().toString());
      j = 0;
      if (!bool1)
        break label260;
      localImageView.setVisibility(j);
      localRBaseHelper = this.select_all.getHelper();
      if (!"select.all".equals(this.select_all.getTag().toString()))
        break label267;
    }
    label260: label267: for (int k = 2131624121; ; k = 2131624105)
    {
      localRBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(this, k));
      this.selectList = new ArrayList();
      if (!"select.all".equals(this.select_all.getTag().toString()))
        break label274;
      Iterator localIterator = this.dataList.iterator();
      while (localIterator.hasNext())
      {
        PlanModel localPlanModel1 = (PlanModel)localIterator.next();
        this.selectList.add(localPlanModel1.planId);
      }
      str = "select.all";
      break;
      j = 8;
      break label128;
    }
    label274: this.account07RecPlanAdapter.notifyDataSetChanged();
  }

  private void initData()
  {
    this.dialog = new DialogManager();
    this.recyclerView = ((RecyclerView)findViewById(2131755254));
    this.bottom_layout = ((RelativeLayout)findViewById(2131755230));
    this.headView = View.inflate(this, 2130968610, null);
    ViewGroup.LayoutParams localLayoutParams1 = new ViewGroup.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this, 80.0F));
    this.headView.setLayoutParams(localLayoutParams1);
    this.footView = View.inflate(this, 2130968609, null);
    ViewGroup.LayoutParams localLayoutParams2 = new ViewGroup.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this, 62.0F));
    this.footView.setLayoutParams(localLayoutParams2);
    this.select_all_icn = ((ImageView)this.footView.findViewById(2131755242));
    this.select_all = ((RRelativeLayout)this.footView.findViewById(2131755241));
    this.select_all.setTag("unSelect");
    this.select_all.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Account07RecPlanActivity.this.clickAllTrainJoinAction();
      }
    });
    this.new_head_view = ((FrameLayout)findViewById(2131755251));
    this.header_back_img = ((ImageView)findViewById(2131757043));
    this.header_title = ((TextView)findViewById(2131757044));
    this.header_title.setText(getString(2131298386));
    this.header_title.setVisibility(0);
    this.header_spilt_line = findViewById(2131755252);
    this.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener()
    {
      public void onScrolled(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
      {
        super.onScrolled(paramRecyclerView, paramInt1, paramInt2);
        int[] arrayOfInt1 = new int[2];
        int[] arrayOfInt2 = new int[2];
        Account07RecPlanActivity.this.new_head_view.getLocationInWindow(arrayOfInt1);
        Account07RecPlanActivity.this.headView.getLocationInWindow(arrayOfInt2);
        int i = CompDeviceInfoUtils.convertOfDip(Account07RecPlanActivity.this, 56.0F) + CompDeviceInfoUtils.getStatusBarHeight(Account07RecPlanActivity.this);
        if (arrayOfInt2[1] == i)
        {
          f = 1.0F;
          Account07RecPlanActivity.this.header_title.setVisibility(8);
          Account07RecPlanActivity.this.header_spilt_line.setVisibility(8);
          Account07RecPlanActivity.this.new_head_view.setAlpha(f);
          return;
        }
        float f = 1.0F - (float)BigDecimalUtils.div(arrayOfInt2[1] - arrayOfInt1[1], 168.0D, 1);
        if (f > 1.0F)
          f = 1.0F;
        while (true)
        {
          Account07RecPlanActivity.this.header_title.setVisibility(0);
          Account07RecPlanActivity.this.header_spilt_line.setVisibility(0);
          break;
          if (f >= 0.2F)
            continue;
          f = 0.2F;
        }
      }
    });
  }

  private String listToString(ArrayList<String> paramArrayList)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int i = 0; i < paramArrayList.size(); i++)
    {
      localStringBuilder.append((String)paramArrayList.get(i));
      if (i >= -1 + paramArrayList.size())
        continue;
      localStringBuilder.append(",");
    }
    return localStringBuilder.toString();
  }

  public void add(PlanModel paramPlanModel)
  {
    this.selectList.add(paramPlanModel.planId);
    Iterator localIterator = this.dataList.iterator();
    while (localIterator.hasNext())
    {
      PlanModel localPlanModel = (PlanModel)localIterator.next();
      if (!paramPlanModel.planId.equals(localPlanModel.planId))
        continue;
      localPlanModel.iswaiting = true;
    }
    this.account07RecPlanAdapter.replaceAll(this.dataList);
    if (this.selectList.size() == this.dataList.size())
    {
      this.select_all.setTag("select.all");
      this.select_all.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this, 2131624121));
      this.select_all_icn.setVisibility(0);
    }
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == 2131757043)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    do
    {
      super.fitOnClick(paramView);
      return;
    }
    while (paramView.getId() != 2131755253);
    this.dialog.createProgressDialog(this, "请稍后...");
    RequestModel localRequestModel = new RequestModel();
    String str1;
    label74: GrowingIOVariables localGrowingIOVariables;
    String str2;
    if (this.selectList.size() > 0)
    {
      str1 = listToString(this.selectList);
      localRequestModel.planId = str1;
      localRequestModel.flg = "2";
      localRequestModel.planType = "0";
      new PresenterImpl(this).joinPlan(localRequestModel, this);
      localGrowingIOVariables = new GrowingIOVariables();
      localGrowingIOVariables.eventid = "complete_info";
      if (this.selectList.size() <= 0)
        break label187;
      str2 = "是";
      label138: localGrowingIOVariables.is_select = str2;
      if (!"select.all".equals(this.select_all.getTag()))
        break label195;
    }
    label187: label195: for (String str3 = "是"; ; str3 = "否")
    {
      localGrowingIOVariables.is_select_all = str3;
      GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
      break;
      str1 = "";
      break label74;
      str2 = "否";
      break label138;
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    RecommendReformer localRecommendReformer;
    if ((paramT instanceof RecommendReformer))
    {
      localRecommendReformer = (RecommendReformer)paramT;
      if (localRecommendReformer._individualArray != null);
    }
    do
    {
      return;
      this.header_title.setVisibility(8);
      this.bottom_layout.setVisibility(0);
      this.dataList = localRecommendReformer._individualArray;
      this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
      this.account07RecPlanAdapter = new Account07RecPlanAdapter(this, this.dataList, 2130968611);
      this.account07RecPlanAdapter.setItemClickListener(this);
      this.account07RecPlanAdapter.addHeaderView(this.headView);
      this.account07RecPlanAdapter.addFooterView(this.footView);
      this.recyclerView.setAdapter(this.account07RecPlanAdapter);
      clickAllTrainJoinAction();
      return;
    }
    while (!(paramT instanceof PlanRecommendReformer));
    EventBus.getDefault().post("register.finish");
    startActivity(new Intent(this, NavMainActivity.class));
    overridePendingTransition(2131034135, 2131034136);
    finish();
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968612);
    SharePreferenceUtils.putLoginStatus(this, "login");
    initData();
    this.dialog.createProgressDialog(this, "请稍后...");
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.flg = "1";
    new AppPresenterImpl(this).getRecommendInfo(this, localRequestModel);
  }

  protected void onDestroy()
  {
    this.dialog.closeDialog();
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  public void remove(PlanModel paramPlanModel)
  {
    this.selectList.remove(paramPlanModel.planId);
    Iterator localIterator = this.dataList.iterator();
    while (localIterator.hasNext())
    {
      PlanModel localPlanModel = (PlanModel)localIterator.next();
      if (!paramPlanModel.planId.equals(localPlanModel.planId))
        continue;
      localPlanModel.iswaiting = false;
    }
    this.account07RecPlanAdapter.replaceAll(this.dataList);
    if ("select.all".equals(this.select_all.getTag().toString()))
    {
      this.select_all.setTag("unSelect");
      this.select_all.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this, 2131624105));
      this.select_all_icn.setVisibility(8);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.Account07RecPlanActivity
 * JD-Core Version:    0.6.0
 */