package com.sportq.fit.business.account.fit_login;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.business.NavMainActivity;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.business.account.widget.EditItemView.EditListener;
import com.sportq.fit.business.account.widget.EditItemView.ItemType;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.CountDownEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.imageloader.QueueCallback;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;
import com.sportq.fit.fitmoudle.network.reformer.NeceDataUIReformer;
import com.sportq.fit.middlelib.MiddleManager;
import java.util.concurrent.TimeUnit;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class RegisterActivity extends BaseActivity
{
  public static final String PHONE_NUM = "phone.num";
  private long cTime = 0L;

  @Bind({2131755522})
  RTextView get_verification_code;

  @Bind({2131757045})
  TextView header_right_btn;

  @Bind({2131757465})
  ImageView huawei_btn;

  @Bind({2131756127})
  EditItemView phone_edit_layout;
  private RTextViewHelper rTextViewHelper;
  private String sendPhoneNum = "";
  private String strChoiceRegisterType;
  private String strPhone;
  private Subscription subscription;

  @Bind({2131757464})
  TextView third_login_title;

  private void getNeceData()
  {
    if (StringUtils.isNull(this.strPhone))
    {
      ToastUtils.makeToast(this, getString(2131298568));
      return;
    }
    if (!StringUtils.checkNumber(this.strPhone))
    {
      ToastUtils.makeToast(this, getString(2131298567));
      return;
    }
    this.dialog.createProgressDialog(this, "请稍后...");
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.phoneNumber = this.strPhone;
    new PresenterImpl(this).getNeceData(localRequestModel, this);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131757043:
    case 2131755522:
    case 2131757466:
    case 2131757467:
    case 2131757468:
    case 2131757465:
    case 2131757045:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      this.strChoiceRegisterType = "8";
      if ((!this.sendPhoneNum.equals(this.strPhone)) || (this.subscription == null))
      {
        this.sendPhoneNum = this.strPhone;
        getNeceData();
        return;
      }
      Intent localIntent = new Intent(this, EditCodeActivity.class);
      localIntent.putExtra("phone.num", this.strPhone);
      localIntent.putExtra("count.down.time", this.cTime);
      localIntent.putExtra("page.from", "1");
      startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this, 0);
      continue;
      this.strChoiceRegisterType = "7";
      this.dialog.createProgressDialog(this, "请稍后...");
      MiddleManager.getInstance().getRegisterPresenterImpl(this).registerAccountBind("7", "1", this);
      continue;
      this.strChoiceRegisterType = "0";
      this.dialog.createProgressDialog(this, "请稍后...");
      MiddleManager.getInstance().getRegisterPresenterImpl(this).registerAccountBind("0", "1", this);
      continue;
      this.strChoiceRegisterType = "1";
      this.dialog.createProgressDialog(this, "请稍后...");
      MiddleManager.getInstance().getRegisterPresenterImpl(this).registerAccountBind("1", "1", this);
      continue;
      this.strChoiceRegisterType = "11";
      this.dialog.createProgressDialog(this, "请稍后...");
      MiddleManager.getInstance().getRegisterPresenterImpl(this).registerAccountBind("11", "1", this);
      continue;
      EventBus.getDefault().post("finish.login");
      startActivity(new Intent(this, LoginActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    String str;
    if ((paramT instanceof String))
    {
      str = (String)paramT;
      if (!str.contains("手机号已注册"))
        break label58;
      this.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          if (paramInt == -1)
          {
            EventBus.getDefault().post("finish.login");
            Intent localIntent = new Intent(RegisterActivity.this, LoginActivity.class);
            localIntent.putExtra("phone.num", RegisterActivity.this.strPhone);
            RegisterActivity.this.startActivity(localIntent);
          }
        }
      }
      , this, "", "该手机号已注册过Fit，是否立即登录？", "去登录", "取消");
    }
    label58: 
    do
      return;
    while (StringUtils.isNull(str));
    ToastUtils.makeToast(this, str);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ("Y".equals(paramT))
    {
      this.dialog.closeDialog();
      if (StringUtils.isNull(BaseApplication.userModel.userSex))
      {
        Intent localIntent2 = new Intent(this, PerfectInfoActivity.class);
        localIntent2.putExtra("jump.type", this.strChoiceRegisterType);
        startActivity(localIntent2);
        AnimationUtil.pageJumpAnim(this, 0);
      }
    }
    UserModel localUserModel;
    do
    {
      while (true)
      {
        return;
        SharePreferenceUtils.putLoginStatus(this, "");
        startActivity(new Intent(this, NavMainActivity.class));
        overridePendingTransition(2131034135, 2131034136);
        finish();
        return;
        if ((paramT instanceof NeceDataUIReformer))
        {
          String str = ((NeceDataUIReformer)paramT).timeKey;
          RequestModel localRequestModel = new RequestModel();
          localRequestModel.phoneNumber = this.strPhone;
          localRequestModel.acquisitionMode = "1";
          localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(str + NdkUtils.getSignBaseUrl()).toUpperCase();
          MiddleManager.getInstance().getLoginPresenterImpl(this).getVerification(localRequestModel, this);
          return;
        }
        if (!(paramT instanceof LoginReformer))
          break;
        this.dialog.closeDialog();
        if (!"0".equals(((LoginReformer)paramT).tag))
          continue;
        this.cTime = 0L;
        startTimeCountdown();
        Intent localIntent1 = new Intent(this, EditCodeActivity.class);
        localIntent1.putExtra("phone.num", this.strPhone);
        localIntent1.putExtra("count.down.time", this.cTime);
        localIntent1.putExtra("page.from", "1");
        startActivity(localIntent1);
        AnimationUtil.pageJumpAnim(this, 0);
        return;
      }
      this.dialog.closeDialog();
      localUserModel = (UserModel)paramT;
      if (!"三方未绑定".equals(localUserModel.tag))
        continue;
      this.dialog.createProgressDialog(this, "正在注册...");
      GlideUtils.loadUrlToBitmap(this, BaseApplication.thirdUserModel.userImg, new QueueCallback()
      {
        public void onErrorResponse()
        {
        }

        public void onResponse(Object paramObject)
        {
          RequestModel localRequestModel = new RequestModel();
          localRequestModel.uid = BaseApplication.thirdUserModel.uid;
          if (paramObject != null)
            localRequestModel.userImg = QiniuManager.uploadData((Bitmap)paramObject);
          localRequestModel.terrace = RegisterActivity.this.strChoiceRegisterType;
          localRequestModel.mbType = "0";
          MiddleManager.getInstance().getLoginPresenterImpl(RegisterActivity.this).userRegister(localRequestModel, RegisterActivity.this);
        }
      });
      return;
    }
    while (!"三方已绑定".equals(localUserModel.tag));
    this.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        if (paramInt == -1)
        {
          EventBus.getDefault().post("register.finish");
          SharePreferenceUtils.putLoginStatus(RegisterActivity.this, "");
          RegisterActivity.this.dialog.createProgressDialog(RegisterActivity.this, "正在登录...");
          RequestModel localRequestModel = new RequestModel();
          localRequestModel.uid = BaseApplication.thirdUserModel.uid;
          localRequestModel.terrace = RegisterActivity.this.strChoiceRegisterType;
          localRequestModel.flag = "0";
          MiddleManager.getInstance().getLoginPresenterImpl(RegisterActivity.this).login(localRequestModel, RegisterActivity.this);
        }
      }
    }
    , this, "", "该账号已注册过Fit，是否立即登录？", "去登录", "取消");
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969089);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.rTextViewHelper = this.get_verification_code.getHelper();
    this.phone_edit_layout.setEditHint(getString(2131298319)).setItemType(EditItemView.ItemType.PHONE).setListener(new EditItemView.EditListener()
    {
      public void onChangeResult(String paramString)
      {
        RegisterActivity.access$002(RegisterActivity.this, paramString);
        RTextView localRTextView1 = RegisterActivity.this.get_verification_code;
        boolean bool;
        int i;
        label75: RTextView localRTextView2;
        RegisterActivity localRegisterActivity2;
        if (RegisterActivity.this.strPhone.length() == 11)
        {
          bool = true;
          localRTextView1.setEnabled(bool);
          RTextViewHelper localRTextViewHelper = RegisterActivity.this.rTextViewHelper;
          RegisterActivity localRegisterActivity1 = RegisterActivity.this;
          if (RegisterActivity.this.strPhone.length() != 11)
            break label141;
          i = 2131624121;
          localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(localRegisterActivity1, i));
          localRTextView2 = RegisterActivity.this.get_verification_code;
          localRegisterActivity2 = RegisterActivity.this;
          if (RegisterActivity.this.strPhone.length() != 11)
            break label148;
        }
        label141: label148: for (int j = 2131624003; ; j = 2131624071)
        {
          localRTextView2.setTextColor(ContextCompat.getColor(localRegisterActivity2, j));
          return;
          bool = false;
          break;
          i = 2131624105;
          break label75;
        }
      }
    });
    String str = getIntent().getStringExtra("phone.num");
    EditItemView localEditItemView = this.phone_edit_layout;
    if (StringUtils.isNull(str))
      str = "";
    localEditItemView.setEditContent(str);
    this.header_right_btn.setText(getString(2131298321));
    this.third_login_title.setText(getString(2131298342));
    ImageView localImageView = this.huawei_btn;
    if (CompDeviceInfoUtils.isHuaweiChannel());
    for (int i = 0; ; i = 8)
    {
      localImageView.setVisibility(i);
      return;
    }
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    if (this.subscription != null)
    {
      this.subscription.unsubscribe();
      this.subscription = null;
    }
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("send.vercode.again".equals(paramString))
      startTimeCountdown();
    if ("perfect.info".equals(paramString))
      finish();
    if ("login.finish".equals(paramString))
      finish();
    if ("finish.register".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  public void startTimeCountdown()
  {
    if (this.subscription != null)
    {
      this.subscription.unsubscribe();
      this.subscription = null;
    }
    this.subscription = Observable.interval(1L, TimeUnit.SECONDS).take(61).onBackpressureBuffer().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1()
    {
      public void call(Long paramLong)
      {
        RegisterActivity.access$302(RegisterActivity.this, paramLong.longValue());
        EventBus.getDefault().post(new CountDownEvent(paramLong.longValue()));
        if (paramLong.longValue() == 60L)
        {
          RegisterActivity.this.subscription.unsubscribe();
          RegisterActivity.access$402(RegisterActivity.this, null);
        }
      }
    });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.RegisterActivity
 * JD-Core Version:    0.6.0
 */