package com.sportq.fit.business.account.adapter;

import android.content.Context;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class Account07RecPlanAdapter extends SuperAdapter<PlanModel>
{
  private ItemClickListener itemClickListener;

  public Account07RecPlanAdapter(Context paramContext, List<PlanModel> paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, PlanModel paramPlanModel)
  {
    GlideUtils.loadImgByDefault(paramPlanModel.planImageURL, 2130903536, (ImageView)paramSuperViewHolder.findViewById(2131755246));
    ((TextView)paramSuperViewHolder.findViewById(2131755247)).setText(paramPlanModel.planName);
    int i;
    label124: int j;
    label147: View localView;
    if (!StringUtils.isNull(paramPlanModel.courseInfo))
    {
      SpannableString localSpannableString = new SpannableString(paramPlanModel.courseInfo);
      StyleSpan localStyleSpan = new StyleSpan(1);
      if (paramPlanModel.courseInfo.contains("钟"))
      {
        i = 1 + paramPlanModel.courseInfo.indexOf("钟");
        localSpannableString.setSpan(localStyleSpan, 0, i, 33);
        ((TextView)paramSuperViewHolder.findViewById(2131755248)).setText(localSpannableString);
        ImageView localImageView = (ImageView)paramSuperViewHolder.findViewById(2131755250);
        if (!paramPlanModel.iswaiting)
          break label224;
        j = 2130903308;
        localImageView.setImageResource(j);
        localView = paramSuperViewHolder.findViewById(2131755249);
        if (!paramPlanModel.iswaiting)
          break label231;
      }
    }
    label224: label231: for (int k = 2131624121; ; k = 2131624090)
    {
      localView.setBackgroundResource(k);
      paramSuperViewHolder.findViewById(2131755245).setOnClickListener(new View.OnClickListener(paramPlanModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (this.val$item.iswaiting)
          {
            Account07RecPlanAdapter.this.itemClickListener.remove(this.val$item);
            return;
          }
          Account07RecPlanAdapter.this.itemClickListener.add(this.val$item);
        }
      });
      return;
      i = 0;
      break;
      ((TextView)paramSuperViewHolder.findViewById(2131755248)).setText("");
      break label124;
      j = 2130903309;
      break label147;
    }
  }

  public void setItemClickListener(ItemClickListener paramItemClickListener)
  {
    this.itemClickListener = paramItemClickListener;
  }

  public static abstract interface ItemClickListener
  {
    public abstract void add(PlanModel paramPlanModel);

    public abstract void remove(PlanModel paramPlanModel);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.adapter.Account07RecPlanAdapter
 * JD-Core Version:    0.6.0
 */