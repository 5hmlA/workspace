package com.sportq.fit.business.account.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.business.NavMainActivity;
import com.sportq.fit.business.account.fit_login.LoginActivity;
import com.sportq.fit.business.account.fit_login.PerfectInfoActivity;
import com.sportq.fit.business.account.widget.AdVideoView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.imageloader.QueueCallback;
import com.sportq.fit.common.utils.superView.RRelativeLayout;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Account02VideoGuideActivity extends BaseActivity
  implements View.OnTouchListener
{

  @Bind({2131755226})
  AdVideoView account02VideoBg;

  @Bind({2131755231})
  RRelativeLayout account02_huawei_login;

  @Bind({2131755232})
  RTextView account02_register;
  private List<String> contentList = new ArrayList();

  @Bind({2131755225})
  RelativeLayout layout;
  private Animation leftInAnima;
  private Animation leftOutAnima;
  private AudioManager.OnAudioFocusChangeListener mAudioFocusChangeListener;
  private AudioManager mAudioManager;
  private GestureDetector mDetector;
  private ViewFlipper mViewFlipper;
  private Animation rightInAnima;
  private Animation rightOutAnima;

  @Bind({2131755233})
  View view_space;

  private void closeDialog()
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
  }

  private void jumpToMainTab()
  {
    if (StringUtils.isNull(BaseApplication.userModel.userSex))
    {
      Intent localIntent1 = new Intent(this, PerfectInfoActivity.class);
      localIntent1.putExtra("jump.type", BaseApplication.userModel.terrace);
      startActivity(localIntent1);
      finish();
      AnimationUtil.pageJumpAnim(this, 0);
      return;
    }
    SharePreferenceUtils.putLoginStatus(this, "");
    Intent localIntent2 = getIntent();
    localIntent2.setClass(this, NavMainActivity.class);
    startActivity(localIntent2);
    overridePendingTransition(2131034135, 2131034136);
    finish();
  }

  private void onStartVideo()
  {
    if (this.mAudioManager != null)
      this.mAudioManager.requestAudioFocus(this.mAudioFocusChangeListener, 3, 2);
    this.account02VideoBg.setVideoURI(Uri.parse("android.resource://com.sportq.fit/2131230720"));
    this.account02VideoBg.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
    {
      public void onPrepared(MediaPlayer paramMediaPlayer)
      {
        try
        {
          int i = paramMediaPlayer.getVideoWidth();
          int j = paramMediaPlayer.getVideoHeight();
          if ((j > 0) && (i > 0))
          {
            float f = i / j;
            int k = BaseApplication.screenWidth;
            int m = (int)(BaseApplication.screenWidth / f);
            if (m < BaseApplication.screenRealHeight)
            {
              m = BaseApplication.screenRealHeight;
              k = (int)(f * BaseApplication.screenRealHeight);
            }
            Account02VideoGuideActivity.this.account02VideoBg.getHolder().setFixedSize(k, m);
            Account02VideoGuideActivity.this.account02VideoBg.setMeasure(k, m);
            Account02VideoGuideActivity.this.account02VideoBg.requestLayout();
          }
          paramMediaPlayer.setLooping(true);
          paramMediaPlayer.start();
          return;
        }
        catch (Exception localException)
        {
          while (true)
            LogUtils.e(localException);
        }
      }
    });
    this.account02VideoBg.setOnErrorListener(new MediaPlayer.OnErrorListener()
    {
      public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2)
      {
        return true;
      }
    });
    this.account02VideoBg.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
    {
      public void onCompletion(MediaPlayer paramMediaPlayer)
      {
        Account02VideoGuideActivity.this.account02VideoBg.setVideoURI(Uri.parse("android.resource://com.sportq.fit/2131230720"));
        Account02VideoGuideActivity.this.account02VideoBg.start();
      }
    });
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
      return;
    case 2131755232:
      startActivity(new Intent(this, LoginActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
      return;
    case 2131755231:
    }
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      ToastUtils.makeToast(this, StringUtils.getStringResources(2131299052));
      return;
    }
    this.dialog.createProgressDialog(this, "请稍后...");
    if ((this.mViewFlipper != null) && (this.mViewFlipper.isFlipping()))
      this.mViewFlipper.stopFlipping();
    BaseApplication.userModel.terrace = "11";
    MiddleManager.getInstance().getRegisterPresenterImpl(this).registerAccountBind("11", "1", this);
  }

  public <T> void getDataFail(T paramT)
  {
    if (!this.account02VideoBg.isPlaying())
      this.account02VideoBg.start();
    closeDialog();
    if ((this.mViewFlipper != null) && (!this.mViewFlipper.isFlipping()))
      this.mViewFlipper.startFlipping();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    closeDialog();
    if ("Y".equals(paramT))
      jumpToMainTab();
    while (true)
    {
      super.getDataSuccess(paramT);
      return;
      UserModel localUserModel = (UserModel)paramT;
      if ("三方未绑定".equals(localUserModel.tag))
      {
        if (this.dialog != null)
          this.dialog.createProgressDialog(this, "正在注册...");
        GlideUtils.loadUrlToBitmap(this, BaseApplication.thirdUserModel.userImg, new QueueCallback(localUserModel)
        {
          public void onErrorResponse()
          {
          }

          public void onResponse(Object paramObject)
          {
            RequestModel localRequestModel = new RequestModel();
            localRequestModel.uid = BaseApplication.thirdUserModel.uid;
            if (paramObject != null)
              localRequestModel.userImg = QiniuManager.uploadData((Bitmap)paramObject);
            localRequestModel.terrace = this.val$userModel.terrace;
            localRequestModel.mbType = "0";
            MiddleManager.getInstance().getLoginPresenterImpl(Account02VideoGuideActivity.this).userRegister(localRequestModel, Account02VideoGuideActivity.this);
          }
        });
        continue;
      }
      if ("三方已绑定".equals(localUserModel.tag))
      {
        if (this.dialog != null)
          this.dialog.createProgressDialog(this, StringUtils.getStringResources(2131298942));
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.uid = BaseApplication.thirdUserModel.uid;
        localRequestModel.terrace = localUserModel.terrace;
        localRequestModel.flag = "0";
        MiddleManager.getInstance().getLoginPresenterImpl(this).login(localRequestModel, this);
        continue;
      }
      jumpToMainTab();
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968607);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.account02_huawei_login.setOnClickListener(new FitAction(this));
    this.account02_register.setOnClickListener(new FitAction(this));
    this.mViewFlipper = ((ViewFlipper)findViewById(2131755229));
    this.leftInAnima = AnimationUtils.loadAnimation(this, 2131034151);
    this.leftOutAnima = AnimationUtils.loadAnimation(this, 2131034152);
    this.rightInAnima = AnimationUtils.loadAnimation(this, 2131034153);
    this.rightOutAnima = AnimationUtils.loadAnimation(this, 2131034154);
    this.contentList.add(getString(2131298369));
    this.contentList.add(getString(2131298370));
    this.contentList.add(getString(2131298372));
    this.contentList.add(getString(2131298373));
    for (int i = 0; i < this.contentList.size(); i++)
    {
      View localView = View.inflate(this, 2130968868, null);
      ((TextView)localView.findViewById(2131756252)).setText((CharSequence)this.contentList.get(i));
      this.mViewFlipper.addView(localView);
    }
    this.mViewFlipper.setInAnimation(this.leftInAnima);
    this.mViewFlipper.setOutAnimation(this.leftOutAnima);
    this.view_space.setOnTouchListener(this);
    this.mDetector = new GestureDetector(this, new SimpleGestureListener(null));
    this.mViewFlipper.setAutoStart(true);
    this.mViewFlipper.setFlipInterval(3750);
    if ((this.mViewFlipper.isAutoStart()) && (!this.mViewFlipper.isFlipping()))
      this.mViewFlipper.startFlipping();
    this.mAudioManager = ((AudioManager)getSystemService("audio"));
    this.mAudioFocusChangeListener = new AudioManager.OnAudioFocusChangeListener()
    {
      public void onAudioFocusChange(int paramInt)
      {
      }
    };
    RRelativeLayout localRRelativeLayout = this.account02_huawei_login;
    if (CompDeviceInfoUtils.isHuaweiChannel());
    for (int j = 0; ; j = 8)
    {
      localRRelativeLayout.setVisibility(j);
      return;
    }
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    closeDialog();
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("quick.login".equals(paramString))
      finish();
    if ("register.finish".equals(paramString))
      finish();
    if ("fitness.finish".equals(paramString))
      finish();
    if ("login.finish".equals(paramString))
      finish();
    if ("perfect.info".equals(paramString))
      finish();
  }

  protected void onPause()
  {
    this.account02VideoBg.pause();
    if (this.mViewFlipper.isFlipping())
      this.mViewFlipper.stopFlipping();
    if ((this.mAudioManager != null) && (this.mAudioFocusChangeListener != null))
      this.mAudioManager.abandonAudioFocus(this.mAudioFocusChangeListener);
    super.onPause();
  }

  protected void onResume()
  {
    try
    {
      onStartVideo();
      if ((this.mViewFlipper != null) && (!this.mViewFlipper.isFlipping()))
        this.mViewFlipper.startFlipping();
      super.onResume();
      return;
    }
    catch (IllegalStateException localIllegalStateException)
    {
      while (true)
        LogUtils.e(localIllegalStateException);
    }
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    this.mViewFlipper.stopFlipping();
    this.mViewFlipper.setAutoStart(false);
    return this.mDetector.onTouchEvent(paramMotionEvent);
  }

  private class SimpleGestureListener extends GestureDetector.SimpleOnGestureListener
  {
    final int FLING_MIN_DISTANCE = 100;
    final int FLING_MIN_VELOCITY = 200;

    private SimpleGestureListener()
    {
    }

    public boolean onDown(MotionEvent paramMotionEvent)
    {
      return true;
    }

    public boolean onFling(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2, float paramFloat1, float paramFloat2)
    {
      if ((paramMotionEvent1.getX() - paramMotionEvent2.getX() > 100.0F) && (Math.abs(paramFloat1) > 200.0F))
      {
        Account02VideoGuideActivity.this.mViewFlipper.setInAnimation(Account02VideoGuideActivity.this.leftInAnima);
        Account02VideoGuideActivity.this.mViewFlipper.setOutAnimation(Account02VideoGuideActivity.this.leftOutAnima);
        Account02VideoGuideActivity.this.mViewFlipper.showNext();
        Account02VideoGuideActivity.this.mViewFlipper.startFlipping();
      }
      while (true)
      {
        new Handler().postDelayed(new Runnable()
        {
          public void run()
          {
            if (Account02VideoGuideActivity.this.mViewFlipper != null)
            {
              Account02VideoGuideActivity.this.mViewFlipper.setInAnimation(Account02VideoGuideActivity.this.leftInAnima);
              Account02VideoGuideActivity.this.mViewFlipper.setOutAnimation(Account02VideoGuideActivity.this.leftOutAnima);
            }
          }
        }
        , 400L);
        return true;
        if ((paramMotionEvent2.getX() - paramMotionEvent1.getX() <= 100.0F) || (Math.abs(paramFloat1) <= 200.0F))
          continue;
        Account02VideoGuideActivity.this.mViewFlipper.setInAnimation(Account02VideoGuideActivity.this.rightInAnima);
        Account02VideoGuideActivity.this.mViewFlipper.setOutAnimation(Account02VideoGuideActivity.this.rightOutAnima);
        Account02VideoGuideActivity.this.mViewFlipper.showPrevious();
        Account02VideoGuideActivity.this.mViewFlipper.startFlipping();
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.Account02VideoGuideActivity
 * JD-Core Version:    0.6.0
 */