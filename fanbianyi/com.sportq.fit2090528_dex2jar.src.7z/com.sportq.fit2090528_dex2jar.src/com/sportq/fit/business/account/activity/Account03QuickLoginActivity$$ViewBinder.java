package com.sportq.fit.business.account.activity;

import android.view.View;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.fitmoudle.widget.FitVipUserView;

public class Account03QuickLoginActivity$$ViewBinder<T extends Account03QuickLoginActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.account03QuickLoginPhoto = ((FitVipUserView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755237, "field 'account03QuickLoginPhoto'"), 2131755237, "field 'account03QuickLoginPhoto'"));
    paramT.account03QuickLoginName = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755238, "field 'account03QuickLoginName'"), 2131755238, "field 'account03QuickLoginName'"));
    paramT.account03QuickLoginOnway = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755239, "field 'account03QuickLoginOnway'"), 2131755239, "field 'account03QuickLoginOnway'"));
    paramT.account03QuickLoginOtherWay = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755234, "field 'account03QuickLoginOtherWay'"), 2131755234, "field 'account03QuickLoginOtherWay'"));
  }

  public void unbind(T paramT)
  {
    paramT.account03QuickLoginPhoto = null;
    paramT.account03QuickLoginName = null;
    paramT.account03QuickLoginOnway = null;
    paramT.account03QuickLoginOtherWay = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.Account03QuickLoginActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */