package com.sportq.fit.business.account.activity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.NavMainActivity;
import com.sportq.fit.business.account.widget.AdVideoView;
import com.sportq.fit.business.find.activity.CourseActOperationalActivity;
import com.sportq.fit.business.find.activity.FitCourseJumpMidActivity;
import com.sportq.fit.business.mine.activity.Mine03WebUrlActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.WelcomeModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RFrameLayout;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.activity.VipCenterActivity;
import com.sportq.fit.fitmoudle.event.GotoShopTabEvent;
import com.sportq.fit.fitmoudle.task.activity.Task02ChallengeDetailsActivity;
import com.sportq.fit.fitmoudle.widget.FitVipUserView;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseArticleDetailsActivity;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseVideoDetailsActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MallGoodsInfoActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MineCouponActivity;
import com.sportq.fit.fitmoudle13.shop.activity.ShopRecommendListActivity;
import com.sportq.fit.fitmoudle5.activity.MasterClassDetailsActivity;
import com.sportq.fit.fitmoudle5.activity.MasterClassListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.fitmoudle9.energy.activity.EnergyActionActivity;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.concurrent.TimeUnit;
import org.greenrobot.eventbus.EventBus;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class FitStartAppActivity extends BaseActivity
{
  private int duration;

  @Bind({2131756184})
  RFrameLayout fit_start_countdown_l;

  @Bind({2131756186})
  TextView fit_start_countdown_time;
  private int mSeekPosition;
  private WelcomeModel model;
  private Subscription subscription;

  @Bind({2131756179})
  FitVipUserView user_icon;

  @Bind({2131756182})
  ImageView welcome_ad_img;

  @Bind({2131756183})
  AdVideoView welcome_ad_video;

  @Bind({2131756180})
  TextView welcome_info;

  @Bind({2131756181})
  TextView welcome_info02;

  @Bind({2131756178})
  LinearLayout welcome_layout;

  private void adClickAction()
  {
    Intent localIntent1 = new Intent(this, NavMainActivity.class);
    String str = this.model.flg;
    int i = -1;
    Intent localIntent2;
    switch (str.hashCode())
    {
    default:
      localIntent2 = null;
      switch (i)
      {
      default:
        label236: if (localIntent2 != null);
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      }
    case 48:
    case 49:
    case 50:
    case 53:
    case 54:
    case 55:
    case 56:
    case 57:
    case 1567:
    case 1568:
    case 1569:
    case 1570:
    case 1571:
    case 1572:
    case 1573:
    }
    for (Intent[] arrayOfIntent = { localIntent1 }; ; arrayOfIntent = new Intent[] { localIntent1, localIntent2 })
    {
      startActivities(arrayOfIntent);
      AnimationUtil.pageJumpAnim(this, 0);
      finish();
      if (this.subscription != null)
      {
        this.subscription.unsubscribe();
        this.subscription = null;
      }
      if (this.welcome_ad_video.getVisibility() == 0)
        this.welcome_ad_video.stopPlayback();
      return;
      if (!str.equals("0"))
        break;
      i = 0;
      break;
      if (!str.equals("1"))
        break;
      i = 1;
      break;
      if (!str.equals("2"))
        break;
      i = 2;
      break;
      if (!str.equals("5"))
        break;
      i = 3;
      break;
      if (!str.equals("6"))
        break;
      i = 4;
      break;
      if (!str.equals("7"))
        break;
      i = 5;
      break;
      if (!str.equals("8"))
        break;
      i = 6;
      break;
      if (!str.equals("9"))
        break;
      i = 7;
      break;
      if (!str.equals("10"))
        break;
      i = 8;
      break;
      if (!str.equals("11"))
        break;
      i = 9;
      break;
      if (!str.equals("12"))
        break;
      i = 10;
      break;
      if (!str.equals("13"))
        break;
      i = 11;
      break;
      if (!str.equals("14"))
        break;
      i = 12;
      break;
      if (!str.equals("15"))
        break;
      i = 13;
      break;
      if (!str.equals("16"))
        break;
      i = 14;
      break;
      boolean bool8 = StringUtils.isNull(this.model.planId);
      localIntent2 = null;
      if (bool8)
        break label236;
      localIntent2 = new Intent(this, Find04GenTrainInfoActivity.class);
      localIntent2.putExtra("plan.id", this.model.planId);
      localIntent2.putExtra("single.type", "0");
      break label236;
      boolean bool7 = StringUtils.isNull(this.model.planId);
      localIntent2 = null;
      if (bool7)
        break label236;
      localIntent2 = new Intent(this, FitCourseJumpMidActivity.class);
      localIntent2.putExtra("plan.id", this.model.planId);
      break label236;
      boolean bool6 = StringUtils.isNull(this.model.adUrl);
      localIntent2 = null;
      if (bool6)
        break label236;
      localIntent2 = new Intent(this, BrowseArticleDetailsActivity.class);
      localIntent2.putExtra("article.url", this.model.adUrl);
      localIntent2.putExtra("article.id", this.model.planId);
      localIntent2.putExtra("webPage.tag", "0");
      break label236;
      boolean bool5 = StringUtils.isNull(this.model.adUrl);
      localIntent2 = null;
      if (bool5)
        break label236;
      localIntent2 = new Intent(this, Mine03WebUrlActivity.class);
      localIntent2.putExtra("webUrl", this.model.adUrl);
      localIntent2.putExtra("share.flg", "13");
      break label236;
      boolean bool4 = StringUtils.isNull(this.model.planId);
      localIntent2 = null;
      if (bool4)
        break label236;
      localIntent2 = new Intent(this, Task02ChallengeDetailsActivity.class);
      localIntent2.putExtra("missionId", this.model.planId);
      break label236;
      boolean bool3 = StringUtils.isNull(this.model.planId);
      localIntent2 = null;
      if (bool3)
        break label236;
      localIntent2 = new Intent(this, BrowseVideoDetailsActivity.class);
      localIntent2.putExtra("tpc.id", this.model.planId);
      break label236;
      boolean bool2 = StringUtils.isNull(this.model.planId);
      localIntent2 = null;
      if (bool2)
        break label236;
      localIntent2 = new Intent(this, ShopRecommendListActivity.class);
      localIntent2.putExtra("key.jumpFlg", this.model.planId);
      break label236;
      boolean bool1 = StringUtils.isNull(this.model.planId);
      localIntent2 = null;
      if (bool1)
        break label236;
      localIntent2 = new Intent(this, MallGoodsInfoActivity.class);
      localIntent2.putExtra(MallGoodsInfoActivity.GOODSID, this.model.planId);
      break label236;
      EventBus.getDefault().post(new GotoShopTabEvent());
      localIntent2 = null;
      break label236;
      SharePreferenceUtils.putBuyVipFromPage("9");
      localIntent2 = new Intent(this, VipCenterActivity.class);
      break label236;
      localIntent2 = new Intent(this, EnergyActionActivity.class);
      break label236;
      localIntent2 = new Intent(this, CourseActOperationalActivity.class);
      localIntent2.putExtra("jump.type", "0");
      break label236;
      localIntent2 = new Intent(this, MasterClassDetailsActivity.class);
      localIntent2.putExtra("lesson.id", this.model.planId);
      break label236;
      localIntent2 = new Intent(this, MasterClassListActivity.class);
      break label236;
      localIntent2 = new Intent(this, MineCouponActivity.class);
      break label236;
    }
  }

  private void displayClodKnowledgeInfo()
  {
    this.welcome_ad_video.setVisibility(8);
    this.welcome_ad_img.setVisibility(8);
    this.welcome_info02.setVisibility(8);
    this.user_icon.loadUserIcon(this.model.cloud_img);
    this.welcome_info.setText(this.model.cloud_str);
  }

  private void init()
  {
    this.model = ((WelcomeModel)getIntent().getSerializableExtra("ad.model"));
    if ((this.model == null) || ("1".equals(this.model.flag)) || ("2".equals(this.model.flag)) || ("0".equals(this.model.adType)))
    {
      AlphaAnimation localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
      localAlphaAnimation.setDuration(1500L);
      this.welcome_layout.startAnimation(localAlphaAnimation);
    }
    try
    {
      if (this.model != null)
      {
        if ("1".equals(this.model.adType))
          playAdVideo();
        while (true)
        {
          this.fit_start_countdown_l.setOnClickListener(new FitAction(this));
          this.welcome_ad_img.setOnClickListener(new FitAction(this));
          this.welcome_ad_video.setOnClickListener(new FitAction(this));
          if ("1".equals(this.model.adType))
            this.fit_start_countdown_time.setVisibility(8);
          return;
          showAdImage();
        }
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        LogUtils.e(localException);
        intentFitTrain();
        continue;
        this.duration = 5;
        this.model = MiddleManager.getInstance().getLoginPresenterImpl(this).getTrivia(this);
        displayClodKnowledgeInfo();
      }
    }
  }

  private void intentFitTrain()
  {
    startActivity(new Intent(this, NavMainActivity.class));
    overridePendingTransition(2131034135, 2131034136);
    finish();
  }

  private void loadNormalUI()
  {
    if ("1".equals(this.model.flag))
    {
      this.welcome_ad_img.setVisibility(8);
      this.welcome_ad_video.setVisibility(8);
      this.welcome_info.setVisibility(0);
      this.welcome_info02.setVisibility(0);
      if (!StringUtils.isNull(FitApplication.userModel.userImg))
      {
        this.user_icon.loadUserIcon(FitApplication.userModel.userImg).setVipTagSize(CompDeviceInfoUtils.convertOfDip(this, 82.0F), 0.243902D);
        this.welcome_info.setText(FitApplication.userModel.userName);
        this.welcome_info02.setText(this.model.comment);
      }
    }
    while (true)
    {
      startTimeCountdown();
      return;
      this.user_icon.loadUserIcon(ImageUtils.readBitMapBase(this, 2130903056)).setVipTagSize(CompDeviceInfoUtils.convertOfDip(this, 82.0F), 0.243902D);
      break;
      this.duration = 5;
      displayClodKnowledgeInfo();
    }
  }

  private void playAdVideo()
  {
    this.welcome_ad_img.setVisibility(8);
    this.welcome_layout.setVisibility(8);
    this.welcome_ad_video.setVisibility(0);
    this.welcome_ad_video.setVideoURI(Uri.parse(ImageUtils.getAdVideoName(this.model.imageUrl)));
    this.welcome_ad_video.start();
    this.welcome_ad_video.requestFocus();
    this.welcome_ad_video.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
    {
      public void onPrepared(MediaPlayer paramMediaPlayer)
      {
        try
        {
          int i = paramMediaPlayer.getVideoWidth();
          int j = paramMediaPlayer.getVideoHeight();
          if ((j > 0) && (i > 0))
          {
            float f = i / j;
            int k = BaseApplication.screenWidth;
            int m = (int)(BaseApplication.screenWidth / f);
            if (m < BaseApplication.screenRealHeight)
            {
              m = BaseApplication.screenRealHeight;
              k = (int)(f * BaseApplication.screenRealHeight);
            }
            FitStartAppActivity.this.welcome_ad_video.getHolder().setFixedSize(k, m);
            FitStartAppActivity.this.welcome_ad_video.setMeasure(k, m);
            FitStartAppActivity.this.welcome_ad_video.requestLayout();
          }
          paramMediaPlayer.setVolume(0.0F, 0.0F);
          paramMediaPlayer.start();
          if (!paramMediaPlayer.isPlaying())
          {
            if (FitStartAppActivity.this.mSeekPosition != 0)
            {
              paramMediaPlayer.seekTo(FitStartAppActivity.this.mSeekPosition);
              paramMediaPlayer.start();
              paramMediaPlayer.pause();
              return;
            }
            paramMediaPlayer.start();
            return;
          }
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
          FitStartAppActivity.this.intentFitTrain();
          return;
        }
        paramMediaPlayer.setOnInfoListener(new MediaPlayer.OnInfoListener()
        {
          public boolean onInfo(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2)
          {
            if ((paramInt1 == 3) && (FitStartAppActivity.this.mSeekPosition != 0))
            {
              FitStartAppActivity.this.welcome_ad_video.seekTo(FitStartAppActivity.this.mSeekPosition);
              FitStartAppActivity.this.welcome_ad_video.start();
              FitStartAppActivity.this.welcome_ad_video.pause();
              return true;
            }
            return false;
          }
        });
      }
    });
    this.welcome_ad_video.setOnErrorListener(new MediaPlayer.OnErrorListener()
    {
      public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2)
      {
        FitStartAppActivity.this.intentFitTrain();
        return true;
      }
    });
    this.welcome_ad_video.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
    {
      public void onCompletion(MediaPlayer paramMediaPlayer)
      {
        FitStartAppActivity.this.intentFitTrain();
      }
    });
  }

  private void showAdImage()
  {
    if (StringUtils.isNull(this.model.duration));
    for (int i = 3; ; i = StringUtils.string2Int(this.model.duration))
    {
      this.duration = i;
      if (!"0".equals(this.model.flag))
        break;
      this.welcome_layout.setVisibility(8);
      this.welcome_ad_video.setVisibility(8);
      this.welcome_ad_img.setVisibility(0);
      GlideUtils.loadCacheImg(this, this.model.useUrl, this.welcome_ad_img);
      startTimeCountdown();
      return;
    }
    loadNormalUI();
  }

  public void fitOnClick(View paramView)
  {
    if ((paramView.getId() == 2131756183) || (paramView.getId() == 2131756182))
    {
      if (!"0".equals(this.model.flag));
      do
        return;
      while ("3".equals(this.model.flg));
      adClickAction();
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() != 2131756184)
        continue;
      if (this.subscription != null)
      {
        this.subscription.unsubscribe();
        this.subscription = null;
      }
      if (this.welcome_ad_video.getVisibility() == 0)
        this.welcome_ad_video.pause();
      intentFitTrain();
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968852);
    ButterKnife.bind(this);
    init();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      if (this.subscription != null)
      {
        this.subscription.unsubscribe();
        this.subscription = null;
      }
      if ((this.welcome_ad_video != null) && (this.welcome_ad_video.getVisibility() == 0))
        this.welcome_ad_video.stopPlayback();
      finish();
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  protected void onPause()
  {
    if ((this.welcome_ad_video.getVisibility() == 0) && (this.welcome_ad_video.isPlaying()))
      this.mSeekPosition = this.welcome_ad_video.getCurrentPosition();
    super.onPause();
  }

  public void startTimeCountdown()
  {
    this.fit_start_countdown_time.setVisibility(0);
    this.fit_start_countdown_time.setText(String.valueOf(this.duration));
    this.subscription = Observable.interval(1L, TimeUnit.SECONDS).take(60).onBackpressureBuffer().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1()
    {
      public void call(Long paramLong)
      {
        if (FitStartAppActivity.this.duration - paramLong.longValue() > 1L)
          FitStartAppActivity.this.fit_start_countdown_time.setText(String.valueOf(FitStartAppActivity.this.duration - paramLong.longValue() - 1L));
        if (paramLong.longValue() == -1 + FitStartAppActivity.this.duration)
        {
          FitStartAppActivity.this.intentFitTrain();
          FitStartAppActivity.this.subscription.unsubscribe();
          FitStartAppActivity.access$202(FitStartAppActivity.this, null);
        }
      }
    });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.FitStartAppActivity
 * JD-Core Version:    0.6.0
 */