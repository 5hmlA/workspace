package com.sportq.fit.business.account.activity;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.business.account.widget.AdVideoView;
import com.sportq.fit.common.utils.superView.RFrameLayout;
import com.sportq.fit.fitmoudle.widget.FitVipUserView;

public class FitStartAppActivity$$ViewBinder<T extends FitStartAppActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.fit_start_countdown_time = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756186, "field 'fit_start_countdown_time'"), 2131756186, "field 'fit_start_countdown_time'"));
    paramT.fit_start_countdown_l = ((RFrameLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756184, "field 'fit_start_countdown_l'"), 2131756184, "field 'fit_start_countdown_l'"));
    paramT.welcome_ad_img = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756182, "field 'welcome_ad_img'"), 2131756182, "field 'welcome_ad_img'"));
    paramT.welcome_ad_video = ((AdVideoView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756183, "field 'welcome_ad_video'"), 2131756183, "field 'welcome_ad_video'"));
    paramT.user_icon = ((FitVipUserView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756179, "field 'user_icon'"), 2131756179, "field 'user_icon'"));
    paramT.welcome_layout = ((LinearLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756178, "field 'welcome_layout'"), 2131756178, "field 'welcome_layout'"));
    paramT.welcome_info = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756180, "field 'welcome_info'"), 2131756180, "field 'welcome_info'"));
    paramT.welcome_info02 = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756181, "field 'welcome_info02'"), 2131756181, "field 'welcome_info02'"));
  }

  public void unbind(T paramT)
  {
    paramT.fit_start_countdown_time = null;
    paramT.fit_start_countdown_l = null;
    paramT.welcome_ad_img = null;
    paramT.welcome_ad_video = null;
    paramT.user_icon = null;
    paramT.welcome_layout = null;
    paramT.welcome_info = null;
    paramT.welcome_info02 = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.FitStartAppActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */