package com.sportq.fit.business.account.fit_login;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.TextPaint;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.NavMainActivity;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.business.account.widget.EditItemView.CountDownClickListener;
import com.sportq.fit.business.account.widget.EditItemView.EditListener;
import com.sportq.fit.business.account.widget.EditItemView.ItemType;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.imageloader.QueueCallback;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;
import com.sportq.fit.fitmoudle.network.reformer.NeceDataUIReformer;
import com.sportq.fit.middlelib.MiddleManager;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class LoginActivity extends BaseActivity
{
  public static final String PAGE_FROM = "page.from";
  public static final String PAGE_INDEX = "page.index";
  public static final String PHONE_NUM = "phone.num";

  @Bind({2131756128})
  EditItemView code_edit_layout;
  private int defaultStyle = -1;

  @Bind({2131757045})
  TextView header_right_btn;

  @Bind({2131756129})
  TextView help_btn;

  @Bind({2131757465})
  ImageView huawei_btn;

  @Bind({2131756402})
  RTextView login_in_view;

  @Bind({2131756401})
  EditItemView password_edit_layout;

  @Bind({2131756400})
  View password_login_line;

  @Bind({2131756399})
  TextView password_login_title;

  @Bind({2131756127})
  EditItemView phone_edit_layout;
  private RTextViewHelper rTextViewHelper;
  private String strCode = "";
  private String strLoginStyle = "";
  private String strPassword = "";
  private String strPhone = "";

  @Bind({2131756397})
  View verification_code_login_line;

  @Bind({2131756396})
  TextView verification_code_login_title;

  @Bind({2131756404})
  TextView verification_login_hint;

  private void checkLoginBtnState()
  {
    boolean bool = true;
    int i;
    label65: RTextView localRTextView;
    if (this.defaultStyle == 0)
      if ((this.strPhone.length() == 11) && (this.strPassword.length() >= 6) && (this.strPassword.length() <= 20))
      {
        this.login_in_view.setEnabled(bool);
        RTextViewHelper localRTextViewHelper = this.rTextViewHelper;
        if (!bool)
          break label137;
        i = 2131624121;
        localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this, i));
        localRTextView = this.login_in_view;
        if (!bool)
          break label143;
      }
    label137: label143: for (int j = 2131624003; ; j = 2131624071)
    {
      localRTextView.setTextColor(ContextCompat.getColor(this, j));
      return;
      bool = false;
      break;
      if ((this.strPhone.length() == 11) && (this.strCode.length() == 4))
        break;
      while (true)
        bool = false;
      i = 2131624105;
      break label65;
    }
  }

  private void closeDialog()
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
  }

  private void getNeceData()
  {
    if (StringUtils.isNull(this.strPhone))
    {
      ToastUtils.makeToast(this, getString(2131298568));
      return;
    }
    if (!StringUtils.checkNumber(this.strPhone))
    {
      ToastUtils.makeToast(this, getString(2131298567));
      return;
    }
    this.dialog.createProgressDialog(this, "请稍后...");
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.phoneNumber = this.strPhone;
    new PresenterImpl(this).getNeceData(localRequestModel, this);
  }

  private void jumpToMainTab()
  {
    if (StringUtils.isNull(BaseApplication.userModel.userSex))
    {
      Intent localIntent2;
      if (("8".equals(BaseApplication.userModel.terrace)) && (StringUtils.isNull(BaseApplication.userModel.password)) && (!AppSharePreferenceUtils.getSkipSetPassword()))
      {
        localIntent2 = new Intent(this, SetPasswordActivity.class);
        localIntent2.putExtra("page.from", "0");
        localIntent2.putExtra("phone.num", this.strPhone);
      }
      while (true)
      {
        startActivity(localIntent2);
        finish();
        AnimationUtil.pageJumpAnim(this, 0);
        return;
        localIntent2 = new Intent(this, PerfectInfoActivity.class);
        localIntent2.putExtra("jump.type", BaseApplication.userModel.terrace);
      }
    }
    SharePreferenceUtils.putLoginStatus(this, "");
    EventBus.getDefault().post("login.finish");
    Intent localIntent1 = getIntent();
    localIntent1.setClass(this, NavMainActivity.class);
    startActivity(localIntent1);
    overridePendingTransition(2131034135, 2131034136);
    finish();
  }

  private void loginIn(String paramString)
  {
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      ToastUtils.makeToast(this, StringUtils.getStringResources(2131299052));
      return;
    }
    this.strLoginStyle = paramString;
    closeDialog();
    this.dialog.createProgressDialog(this, "请稍后...");
    if ("8".equals(paramString))
    {
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.terrace = "8";
      localRequestModel.phoneNumber = this.strPhone;
      if (this.defaultStyle == 0)
      {
        this.strLoginStyle = "8";
        localRequestModel.password = this.strPassword;
        localRequestModel.flag = "0";
        MiddleManager.getInstance().getLoginPresenterImpl(this).mobileLogin(localRequestModel, this);
        return;
      }
      this.strLoginStyle = "9";
      localRequestModel.verification = this.strCode;
      localRequestModel.flag = "1";
      MiddleManager.getInstance().getLoginPresenterImpl(this).mobileLogin(localRequestModel, this);
      return;
    }
    MiddleManager.getInstance().getRegisterPresenterImpl(this).registerAccountBind(paramString, "1", this);
  }

  private void setTitleStyle(int paramInt)
  {
    int i = 2131624003;
    int j = 4;
    if (this.defaultStyle == paramInt)
      return;
    this.defaultStyle = paramInt;
    TextView localTextView1 = this.password_login_title;
    int k;
    int m;
    label56: label74: int n;
    label116: int i1;
    label137: int i2;
    label158: TextView localTextView4;
    if (paramInt == 0)
    {
      k = i;
      localTextView1.setTextColor(ContextCompat.getColor(this, k));
      View localView1 = this.password_login_line;
      if (paramInt != 0)
        break label216;
      m = 0;
      localView1.setVisibility(m);
      TextView localTextView2 = this.verification_code_login_title;
      if (paramInt != 1)
        break label222;
      localTextView2.setTextColor(ContextCompat.getColor(this, i));
      View localView2 = this.verification_code_login_line;
      if (paramInt == 1)
        j = 0;
      localView2.setVisibility(j);
      EditItemView localEditItemView1 = this.password_edit_layout;
      if (paramInt != 0)
        break label228;
      n = 0;
      localEditItemView1.setVisibility(n);
      EditItemView localEditItemView2 = this.code_edit_layout;
      if (paramInt != 1)
        break label235;
      i1 = 0;
      localEditItemView2.setVisibility(i1);
      TextView localTextView3 = this.verification_login_hint;
      i2 = 0;
      if (paramInt != 1)
        break label242;
      localTextView3.setVisibility(i2);
      localTextView4 = this.help_btn;
      if (paramInt != 0)
        break label249;
    }
    label216: label222: label228: label235: label242: label249: for (String str = getString(2131298322); ; str = getString(2131298396))
    {
      localTextView4.setText(str);
      if (paramInt != 0)
        break label261;
      this.code_edit_layout.clear();
      this.strCode = "";
      return;
      k = 2131624071;
      break;
      m = j;
      break label56;
      i = 2131624071;
      break label74;
      n = 8;
      break label116;
      i1 = 8;
      break label137;
      i2 = 8;
      break label158;
    }
    label261: this.strPassword = "";
    this.password_edit_layout.restore();
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131757043:
    case 2131756398:
    case 2131756395:
    case 2131756402:
    case 2131756129:
    case 2131757466:
    case 2131757467:
    case 2131757468:
    case 2131757465:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      setTitleStyle(0);
      continue;
      setTitleStyle(1);
      continue;
      loginIn("8");
      continue;
      Intent localIntent;
      if (this.defaultStyle == 0)
      {
        localIntent = new Intent(this, FindPasswordActivity.class);
        localIntent.putExtra("phone.num", this.strPhone);
      }
      while (true)
      {
        startActivity(localIntent);
        AnimationUtil.pageJumpAnim(this, 0);
        break;
        if (StringUtils.isNull(this.strPhone))
        {
          ToastUtils.makeToast(this, "请输入手机号");
          return;
        }
        if (!StringUtils.checkNumber(this.strPhone))
        {
          ToastUtils.makeToast(this, "请输入正确的手机号");
          return;
        }
        localIntent = new Intent(this, VoiceVerCodeActivity.class);
        localIntent.putExtra("phone.num", this.strPhone);
        localIntent.putExtra("page.from", "6");
      }
      loginIn("7");
      continue;
      loginIn("0");
      continue;
      loginIn("1");
      continue;
      loginIn("11");
    }
  }

  public <T> void getDataFail(T paramT)
  {
    closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof NeceDataUIReformer))
    {
      String str = ((NeceDataUIReformer)paramT).timeKey;
      RequestModel localRequestModel2 = new RequestModel();
      localRequestModel2.phoneNumber = this.strPhone;
      localRequestModel2.acquisitionMode = "5";
      localRequestModel2.keySign = CompDeviceInfoUtils.generateMD5Encrypt(str + NdkUtils.getSignBaseUrl()).toUpperCase();
      MiddleManager.getInstance().getLoginPresenterImpl(this).getVerification(localRequestModel2, this);
    }
    while (true)
    {
      return;
      if (!(paramT instanceof LoginReformer))
        break;
      closeDialog();
      if (!"0".equals(((LoginReformer)paramT).tag))
        continue;
      this.code_edit_layout.startTimeCountdown();
      return;
    }
    if ("Y".equals(paramT))
    {
      closeDialog();
      jumpToMainTab();
      return;
    }
    closeDialog();
    UserModel localUserModel = (UserModel)paramT;
    if ("三方未绑定".equals(localUserModel.tag))
    {
      this.dialog.createProgressDialog(this, "正在注册...");
      GlideUtils.loadUrlToBitmap(this, BaseApplication.thirdUserModel.userImg, new QueueCallback()
      {
        public void onErrorResponse()
        {
        }

        public void onResponse(Object paramObject)
        {
          RequestModel localRequestModel = new RequestModel();
          localRequestModel.uid = BaseApplication.thirdUserModel.uid;
          if (paramObject != null)
            localRequestModel.userImg = QiniuManager.uploadData((Bitmap)paramObject);
          localRequestModel.terrace = LoginActivity.this.strLoginStyle;
          localRequestModel.mbType = "0";
          MiddleManager.getInstance().getLoginPresenterImpl(LoginActivity.this).userRegister(localRequestModel, LoginActivity.this);
        }
      });
      return;
    }
    if ("三方已绑定".equals(localUserModel.tag))
    {
      if (this.dialog != null)
        this.dialog.setProDialogTextHint(StringUtils.getStringResources(2131298942));
      RequestModel localRequestModel1 = new RequestModel();
      localRequestModel1.uid = FitApplication.thirdUserModel.uid;
      localRequestModel1.terrace = this.strLoginStyle;
      localRequestModel1.flag = "0";
      MiddleManager.getInstance().getLoginPresenterImpl(this).login(localRequestModel1, this);
      return;
    }
    jumpToMainTab();
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968921);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    EventBus.getDefault().register(this);
    this.rTextViewHelper = this.login_in_view.getHelper();
    this.phone_edit_layout.setEditHint(getString(2131298319)).setItemType(EditItemView.ItemType.PHONE).setListener(new EditItemView.EditListener()
    {
      public void onChangeResult(String paramString)
      {
        LoginActivity.access$002(LoginActivity.this, paramString);
        EditItemView localEditItemView = LoginActivity.this.code_edit_layout;
        if (LoginActivity.this.strPhone.length() == 11);
        for (boolean bool = true; ; bool = false)
        {
          localEditItemView.setCodeEnable(bool);
          LoginActivity.this.checkLoginBtnState();
          return;
        }
      }
    });
    String str = getIntent().getStringExtra("phone.num");
    EditItemView localEditItemView = this.phone_edit_layout;
    if (StringUtils.isNull(str))
      str = "";
    localEditItemView.setEditContent(str);
    this.password_edit_layout.setEditHint(getString(2131298320)).setItemType(EditItemView.ItemType.PASSWORD).showHideBtn().setListener(new EditItemView.EditListener()
    {
      public void onChangeResult(String paramString)
      {
        LoginActivity.access$202(LoginActivity.this, paramString);
        LoginActivity.this.checkLoginBtnState();
      }
    });
    this.code_edit_layout.setEditHint("请输入4位验证码").setItemType(EditItemView.ItemType.VERIFICATION).showCountDown().setListener(new EditItemView.EditListener()
    {
      public void onChangeResult(String paramString)
      {
        LoginActivity.access$402(LoginActivity.this, paramString);
        LoginActivity.this.checkLoginBtnState();
      }
    }).setClickListener(new EditItemView.CountDownClickListener()
    {
      public void onClick()
      {
        LoginActivity.this.getNeceData();
      }
    });
    this.header_right_btn.setVisibility(8);
    this.help_btn.setText(getString(2131298300));
    this.help_btn.getPaint().setFlags(9);
    this.login_in_view.setEnabled(false);
    setTitleStyle(getIntent().getIntExtra("page.index", 1));
    ImageView localImageView = this.huawei_btn;
    boolean bool = CompDeviceInfoUtils.isHuaweiChannel();
    int i = 0;
    if (bool);
    while (true)
    {
      localImageView.setVisibility(i);
      return;
      i = 8;
    }
  }

  protected void onDestroy()
  {
    this.code_edit_layout.onDestroy();
    closeDialog();
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("perfect.info".equals(paramString))
      finish();
    if ("register.finish".equals(paramString))
      finish();
    if ("finish.login".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.LoginActivity
 * JD-Core Version:    0.6.0
 */