package com.sportq.fit.business.account.fit_login;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.account.activity.Account02VideoGuideActivity;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.business.account.widget.EditItemView.EditListener;
import com.sportq.fit.business.account.widget.EditItemView.ItemType;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.SystemPhotoModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.SystemPhotoUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.activity.ClipPictureActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior;
import com.sportq.fit.middlelib.statistics.GrowingIOVariables;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class PerfectInfoActivity extends BaseActivity
{
  public static final String JUMP_TYPE = "jump.type";

  @Bind({2131757124})
  ImageView camera_img;
  private String[] itemList = { "拍照", "相册" };

  @Bind({2131755448})
  RTextView next_step;
  private RTextViewHelper rTextViewHelper;

  @Bind({2131757129})
  public TextView select_username1;

  @Bind({2131757130})
  public TextView select_username2;

  @Bind({2131757131})
  public TextView select_username3;

  @Bind({2131757126})
  RelativeLayout select_username_layout;
  private String strPicturePath;
  private String strUserName;
  private SystemPhotoUtils systemPhotoUtils;

  @Bind({2131757125})
  EditItemView username_edit_layout;

  private void takePhoto()
  {
    this.dialog.createDialog(new FitInterfaceUtils.DialogListener()
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        switch (paramInt)
        {
        default:
          return;
        case 0:
          Intent localIntent = new Intent("android.media.action.IMAGE_CAPTURE");
          localIntent.putExtra("android.intent.extra.videoQuality", 1);
          PerfectInfoActivity.access$302(PerfectInfoActivity.this, FileUtils.getPhotopath());
          localIntent.putExtra("output", FileUtils.getTakePhotoUri(PerfectInfoActivity.this.strPicturePath));
          localIntent.putExtra("orientation", 180);
          PerfectInfoActivity.this.startActivityForResult(localIntent, 1);
          return;
        case 1:
        }
        PerfectInfoActivity.this.systemPhotoUtils.openSystemPhoto();
      }
    }
    , this, this.itemList);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131755357:
    case 2131757124:
    case 2131755448:
    case 2131757129:
    case 2131757130:
    case 2131757131:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      SharePreferenceUtils.putLoginStatus(this, "");
      startActivity(new Intent(this, Account02VideoGuideActivity.class));
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
      {
        public void result(boolean paramBoolean)
        {
          if (paramBoolean)
            PerfectInfoActivity.this.takePhoto();
        }
      }
      , this, new String[] { "android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE" });
      continue;
      if (!StringUtils.checkName(this.strUserName))
      {
        ToastUtils.makeToast(this, "昵称支持中英文、数字、下划线和横线");
        return;
      }
      this.dialog.createProgressDialog(this, "请稍后...");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.userName = this.strUserName;
      MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(localRequestModel, this);
      continue;
      this.username_edit_layout.setEditContent(this.select_username1.getText().toString());
      continue;
      this.username_edit_layout.setEditContent(this.select_username2.getText().toString());
      continue;
      this.username_edit_layout.setEditContent(this.select_username3.getText().toString());
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    this.dialog.closeDialog();
    if ((paramT instanceof String))
    {
      if (((String)paramT).contains("[br]"))
      {
        String[] arrayOfString = ((String)paramT).replace("[br]", "&").split("&");
        this.select_username_layout.setVisibility(0);
        this.select_username1.setText(arrayOfString[0]);
        this.select_username2.setText(arrayOfString[1]);
        this.select_username3.setText(arrayOfString[2]);
      }
    }
    else
      return;
    ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    this.dialog.closeDialog();
    if ("Y".equals(paramT))
    {
      this.select_username_layout.setVisibility(4);
      Intent localIntent = new Intent(this, SelectBirthdayAndSexActivity.class);
      FitApplication.userModel.userName = this.strUserName;
      FitApplication.userModel.userImg = this.strPicturePath;
      startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969070);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.systemPhotoUtils = new SystemPhotoUtils(this);
    this.dialog = new DialogManager();
    this.rTextViewHelper = this.next_step.getHelper();
    SharePreferenceUtils.putLoginStatus(this, "perfect.info");
    this.username_edit_layout.setItemIcon(2130903307).setEditHint(getString(2131298352)).setItemType(EditItemView.ItemType.USERNAME).setListener(new EditItemView.EditListener()
    {
      public void onChangeResult(String paramString)
      {
        PerfectInfoActivity.access$002(PerfectInfoActivity.this, paramString);
        boolean bool;
        int i;
        label48: RTextView localRTextView;
        PerfectInfoActivity localPerfectInfoActivity2;
        if (StringUtils.unicodeLenOfStr(PerfectInfoActivity.this.strUserName) >= 3)
        {
          bool = true;
          RTextViewHelper localRTextViewHelper = PerfectInfoActivity.this.rTextViewHelper;
          PerfectInfoActivity localPerfectInfoActivity1 = PerfectInfoActivity.this;
          if (!bool)
            break label113;
          i = 2131624121;
          localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(localPerfectInfoActivity1, i));
          localRTextView = PerfectInfoActivity.this.next_step;
          localPerfectInfoActivity2 = PerfectInfoActivity.this;
          if (!bool)
            break label120;
        }
        label113: label120: for (int j = 2131624003; ; j = 2131624071)
        {
          localRTextView.setTextColor(ContextCompat.getColor(localPerfectInfoActivity2, j));
          PerfectInfoActivity.this.next_step.setEnabled(bool);
          return;
          bool = false;
          break;
          i = 2131624105;
          break label48;
        }
      }
    });
    this.next_step.setEnabled(false);
    String str = getIntent().getStringExtra("jump.type");
    if (!"8".equals(str))
    {
      GlideUtils.loadImgByCircle(FitApplication.thirdUserModel.userImg, 2130903056, this.camera_img);
      this.username_edit_layout.setEditContent(FitApplication.thirdUserModel.userName);
    }
    EventBus.getDefault().post("perfect.info");
    GrowingIOVariables localGrowingIOVariables = new GrowingIOVariables();
    localGrowingIOVariables.eventid = "register";
    localGrowingIOVariables.registerType = str;
    GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    switch (paramInt1)
    {
    default:
    case 1:
    case 999:
    case 4:
    }
    while (true)
    {
      super.onActivityResult(paramInt1, paramInt2, paramIntent);
      return;
      if (StringUtils.isNull(this.strPicturePath))
        continue;
      Intent localIntent2 = new Intent(this, ClipPictureActivity.class);
      localIntent2.putExtra("clip.img.path", this.strPicturePath);
      startActivityForResult(localIntent2, 4);
      continue;
      if (paramIntent == null)
        continue;
      SystemPhotoModel localSystemPhotoModel = this.systemPhotoUtils.resultData(this, paramIntent);
      if (localSystemPhotoModel != null)
        this.strPicturePath = localSystemPhotoModel.url_pri;
      if (StringUtils.isNull(this.strPicturePath))
        continue;
      Intent localIntent1 = new Intent(this, ClipPictureActivity.class);
      localIntent1.putExtra("clip.img.path", this.strPicturePath);
      startActivityForResult(localIntent1, 4);
      continue;
      if (paramIntent == null)
        continue;
      this.strPicturePath = paramIntent.getStringExtra("clip.image");
      Bitmap localBitmap = ImageUtils.getImageBitmap(this.strPicturePath, 1);
      if ((StringUtils.isNull(this.strPicturePath)) || (localBitmap == null))
        continue;
      int i = CompDeviceInfoUtils.convertOfDip(this, localBitmap.getWidth() / 2);
      this.camera_img.setImageBitmap(ImageUtils.getRoundedCornerBitmap(localBitmap, i));
    }
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("register.finish".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      SharePreferenceUtils.putLoginStatus(this, "");
      startActivity(new Intent(this, Account02VideoGuideActivity.class));
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.PerfectInfoActivity
 * JD-Core Version:    0.6.0
 */