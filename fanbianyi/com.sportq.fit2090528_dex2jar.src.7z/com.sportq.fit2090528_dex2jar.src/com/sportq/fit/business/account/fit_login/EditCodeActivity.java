package com.sportq.fit.business.account.fit_login;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.StyleSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.event.CountDownEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;
import com.sportq.fit.fitmoudle.network.reformer.NeceDataUIReformer;
import com.sportq.fit.middlelib.MiddleManager;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class EditCodeActivity extends BaseActivity
{
  public static final String COUNT_DOWN_TIME = "count.down.time";
  public static final String PAGE_FROM = "page.from";
  public static final String PHONE_NUM = "phone.num";
  private ArrayList<EditText> editList = new ArrayList();

  @Bind({2131755895})
  EditText first_edit;

  @Bind({2131755898})
  EditText forth_edit;

  @Bind({2131755899})
  TextView not_received_view;
  private String pageFrom = "";

  @Bind({2131755896})
  EditText second_edit;

  @Bind({2131755900})
  TextView send_verification_code;
  private String strFirstCode = "";
  private String strForthCode = "";
  private String strPhoneNum;
  private String strSecondCode = "";
  private String strThirdCode = "";

  @Bind({2131755897})
  EditText third_edit;

  @Bind({2131755041})
  TextView title;

  private void backFocus()
  {
    for (int i = -1 + this.editList.size(); ; i--)
    {
      if (i >= 0)
      {
        EditText localEditText = (EditText)this.editList.get(i);
        if (localEditText.getText().length() != 1)
          continue;
        localEditText.requestFocus();
        localEditText.setSelection(1);
      }
      return;
    }
  }

  private void frontFocus()
  {
    for (int i = 0; ; i++)
    {
      if (i < this.editList.size())
      {
        EditText localEditText = (EditText)this.editList.get(i);
        if (localEditText.getText().length() >= 1)
          continue;
        localEditText.requestFocus();
      }
      return;
    }
  }

  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    if ((paramKeyEvent.getKeyCode() == 67) && (paramKeyEvent.getAction() != 1))
      backFocus();
    return super.dispatchKeyEvent(paramKeyEvent);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131757043:
    case 2131755899:
    case 2131755900:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      Intent localIntent = new Intent(this, VoiceVerCodeActivity.class);
      localIntent.putExtra("phone.num", this.strPhoneNum);
      if ("1".equals(this.pageFrom));
      for (String str = "2"; ; str = "7")
      {
        localIntent.putExtra("page.from", str);
        startActivity(localIntent);
        AnimationUtil.pageJumpAnim(this, 0);
        break;
      }
      if (StringUtils.isNull(this.strPhoneNum))
      {
        ToastUtils.makeToast(this, getString(2131298568));
        return;
      }
      if (!StringUtils.checkNumber(this.strPhoneNum))
      {
        ToastUtils.makeToast(this, getString(2131298567));
        return;
      }
      this.dialog.createProgressDialog(this, "请稍后...");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = this.strPhoneNum;
      new PresenterImpl(this).getNeceData(localRequestModel, this);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    String str2;
    if ((paramT instanceof NeceDataUIReformer))
    {
      String str1 = ((NeceDataUIReformer)paramT).timeKey;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = this.strPhoneNum;
      if ("1".equals(this.pageFrom))
      {
        str2 = "0";
        localRequestModel.acquisitionMode = str2;
        localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(str1 + NdkUtils.getSignBaseUrl()).toUpperCase();
        MiddleManager.getInstance().getLoginPresenterImpl(this).getVerification(localRequestModel, this);
      }
    }
    LoginReformer localLoginReformer;
    do
    {
      do
      {
        return;
        str2 = "3";
        break;
      }
      while (!(paramT instanceof LoginReformer));
      this.dialog.closeDialog();
      localLoginReformer = (LoginReformer)paramT;
      if (!"0".equals(localLoginReformer.tag))
        continue;
      this.send_verification_code.setEnabled(false);
      this.send_verification_code.setText(UseStringUtils.getStr(2131298345, new String[] { "60" }));
      this.send_verification_code.setTextColor(ContextCompat.getColor(this, 2131624044));
      EventBus.getDefault().post("send.vercode.again");
      return;
    }
    while (!"1".equals(localLoginReformer.tag));
    CompDeviceInfoUtils.hideSoftInput(this, this.forth_edit);
    Intent localIntent = new Intent(this, SetPasswordActivity.class);
    localIntent.putExtra("phone.num", this.strPhoneNum);
    localIntent.putExtra("page.from", this.pageFrom);
    startActivity(localIntent);
    AnimationUtil.pageJumpAnim(this, 0);
  }

  public void initLayout(Bundle paramBundle)
  {
    getWindow().setSoftInputMode(5);
    setContentView(2130968777);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.strPhoneNum = getIntent().getStringExtra("phone.num");
    this.pageFrom = getIntent().getStringExtra("page.from");
    this.editList.add(this.first_edit);
    this.editList.add(this.second_edit);
    this.editList.add(this.third_edit);
    this.editList.add(this.forth_edit);
    String[] arrayOfString1 = new String[1];
    arrayOfString1[0] = ("\n当前号码：" + this.strPhoneNum);
    SpannableString localSpannableString = new SpannableString(UseStringUtils.getStr(2131298343, arrayOfString1));
    localSpannableString.setSpan(new AbsoluteSizeSpan(CompDeviceInfoUtils.convertOfDip(this, 24.0F)), 0, 7, 33);
    localSpannableString.setSpan(new StyleSpan(1), 0, 7, 33);
    this.title.setText(localSpannableString);
    frontFocus();
    this.not_received_view.getPaint().setFlags(9);
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        EditCodeActivity.access$002(EditCodeActivity.this, paramString);
        EditCodeActivity.this.frontFocus();
      }
    }
    , this.first_edit);
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        EditCodeActivity.access$202(EditCodeActivity.this, paramString);
        EditCodeActivity.this.frontFocus();
      }
    }
    , this.second_edit);
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        EditCodeActivity.access$302(EditCodeActivity.this, paramString);
        EditCodeActivity.this.frontFocus();
      }
    }
    , this.third_edit);
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        EditCodeActivity.access$402(EditCodeActivity.this, paramString);
        if ((EditCodeActivity.this.strFirstCode.length() == 1) && (EditCodeActivity.this.strSecondCode.length() == 1) && (EditCodeActivity.this.strThirdCode.length() == 1) && (EditCodeActivity.this.strForthCode.length() == 1))
        {
          String str = EditCodeActivity.this.strFirstCode + EditCodeActivity.this.strSecondCode + EditCodeActivity.this.strThirdCode + EditCodeActivity.this.strForthCode;
          EditCodeActivity.this.dialog.createProgressDialog(EditCodeActivity.this, "请稍后...");
          MiddleManager.getInstance().getLoginPresenterImpl(EditCodeActivity.this).postCheckVerification(EditCodeActivity.this.strPhoneNum, str, EditCodeActivity.this);
          return;
        }
        EditCodeActivity.this.frontFocus();
      }
    }
    , this.forth_edit);
    long l1 = getIntent().getLongExtra("count.down.time", 0L);
    this.send_verification_code.setEnabled(false);
    long l2;
    if (l1 == 0L)
      l2 = 60L;
    while (true)
    {
      TextView localTextView = this.send_verification_code;
      String[] arrayOfString2 = new String[1];
      arrayOfString2[0] = String.valueOf(l2);
      localTextView.setText(UseStringUtils.getStr(2131298345, arrayOfString2));
      return;
      l2 = 59L - l1;
    }
  }

  @Subscribe
  public void onEventMainThread(CountDownEvent paramCountDownEvent)
  {
    TextView localTextView = this.send_verification_code;
    boolean bool;
    if (paramCountDownEvent.time == 60L)
    {
      bool = true;
      localTextView.setEnabled(bool);
      if (paramCountDownEvent.time != 60L)
        break label72;
    }
    label72: String[] arrayOfString;
    for (String str = getString(2131298346); ; str = UseStringUtils.getStr(2131298345, arrayOfString))
    {
      this.send_verification_code.setText(str);
      this.send_verification_code.setTextColor(ContextCompat.getColor(this, 2131624003));
      return;
      bool = false;
      break;
      arrayOfString = new String[1];
      arrayOfString[0] = String.valueOf(59L - paramCountDownEvent.time);
    }
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("perfect.info".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.EditCodeActivity
 * JD-Core Version:    0.6.0
 */