package com.sportq.fit.business.account.fit_login;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;

public class EditCodeActivity$$ViewBinder<T extends EditCodeActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.title = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755041, "field 'title'"), 2131755041, "field 'title'"));
    paramT.first_edit = ((EditText)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755895, "field 'first_edit'"), 2131755895, "field 'first_edit'"));
    paramT.second_edit = ((EditText)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755896, "field 'second_edit'"), 2131755896, "field 'second_edit'"));
    paramT.third_edit = ((EditText)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755897, "field 'third_edit'"), 2131755897, "field 'third_edit'"));
    paramT.forth_edit = ((EditText)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755898, "field 'forth_edit'"), 2131755898, "field 'forth_edit'"));
    paramT.not_received_view = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755899, "field 'not_received_view'"), 2131755899, "field 'not_received_view'"));
    paramT.send_verification_code = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755900, "field 'send_verification_code'"), 2131755900, "field 'send_verification_code'"));
  }

  public void unbind(T paramT)
  {
    paramT.title = null;
    paramT.first_edit = null;
    paramT.second_edit = null;
    paramT.third_edit = null;
    paramT.forth_edit = null;
    paramT.not_received_view = null;
    paramT.send_verification_code = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.EditCodeActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */