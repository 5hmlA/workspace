package com.sportq.fit.business.account.fit_login;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.account.activity.Account05FitnessGoalsActivity;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.LocationHandler;
import com.sportq.fit.common.utils.LocationHandler.OnLocationListener;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle4.setting.widget.SelectProvinceDialog;
import com.sportq.fit.fitmoudle4.setting.widget.SelectProvinceDialog.OnCitySelectorListener;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class AddressActivity extends BaseActivity
{

  @Bind({2131757045})
  TextView header_right_btn;
  private boolean isFirstClick = true;

  @Bind({2131755448})
  RTextView next_step;
  private RTextViewHelper rTextViewHelper;
  private SelectProvinceDialog selectProvinceDialog;
  private String strLocation;

  @Bind({2131755447})
  TextView user_address;

  private void getLocation()
  {
    if (this.isFirstClick)
    {
      this.isFirstClick = false;
      CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
      {
        public void result(boolean paramBoolean)
        {
          if (paramBoolean)
            new LocationHandler(AddressActivity.this, new LocationHandler.OnLocationListener()
            {
              public void locationFail()
              {
                ToastUtils.makeToast(AddressActivity.this, "定位失败");
                AddressActivity.access$002(AddressActivity.this, "安徽 安庆");
              }

              public void locationSuccess(String paramString)
              {
                if (paramString.contains("null"))
                {
                  ToastUtils.makeToast(AddressActivity.this, "定位失败");
                  AddressActivity.access$002(AddressActivity.this, "安徽 安庆");
                  return;
                }
                AddressActivity.access$002(AddressActivity.this, paramString);
                AddressActivity.this.user_address.setText(paramString);
                AddressActivity.this.setNextStep();
              }
            }
            , AddressActivity.this.dialog).gpsLocationStart();
        }
      }
      , this, new String[] { "android.permission.ACCESS_COARSE_LOCATION" });
      return;
    }
    if (this.selectProvinceDialog == null);
    for (SelectProvinceDialog localSelectProvinceDialog = new SelectProvinceDialog(this); ; localSelectProvinceDialog = this.selectProvinceDialog)
    {
      this.selectProvinceDialog = localSelectProvinceDialog;
      this.selectProvinceDialog.createDialog(this.strLocation, new SelectProvinceDialog.OnCitySelectorListener()
      {
        public void onSelect(String paramString)
        {
          AddressActivity.access$002(AddressActivity.this, paramString);
          AddressActivity.this.user_address.setText(paramString);
          AddressActivity.this.setNextStep();
        }
      });
      return;
    }
  }

  private void setNextStep()
  {
    boolean bool;
    int i;
    label24: RTextView localRTextView;
    if (!StringUtils.isNull(this.strLocation))
    {
      bool = true;
      RTextViewHelper localRTextViewHelper = this.rTextViewHelper;
      if (!bool)
        break label73;
      i = 2131624121;
      localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this, i));
      localRTextView = this.next_step;
      if (!bool)
        break label79;
    }
    label73: label79: for (int j = 2131624003; ; j = 2131624071)
    {
      localRTextView.setTextColor(ContextCompat.getColor(this, j));
      this.next_step.setEnabled(bool);
      return;
      bool = false;
      break;
      i = 2131624105;
      break label24;
    }
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131757043:
    case 2131757045:
    case 2131755447:
    case 2131755448:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      startActivity(new Intent(this, Account05FitnessGoalsActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
      continue;
      getLocation();
      continue;
      FitApplication.userModel.region = this.strLocation;
      startActivity(new Intent(this, Account05FitnessGoalsActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968637);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.rTextViewHelper = this.next_step.getHelper();
    this.header_right_btn.setText(getString(2131298399));
    this.header_right_btn.setVisibility(0);
    this.next_step.setEnabled(false);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("register.finish".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.AddressActivity
 * JD-Core Version:    0.6.0
 */