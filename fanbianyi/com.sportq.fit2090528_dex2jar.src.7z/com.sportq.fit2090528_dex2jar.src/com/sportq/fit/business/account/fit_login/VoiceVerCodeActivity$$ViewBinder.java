package com.sportq.fit.business.account.fit_login;

import android.view.View;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;

public class VoiceVerCodeActivity$$ViewBinder<T extends VoiceVerCodeActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.phone_info = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757866, "field 'phone_info'"), 2131757866, "field 'phone_info'"));
  }

  public void unbind(T paramT)
  {
    paramT.phone_info = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.VoiceVerCodeActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */