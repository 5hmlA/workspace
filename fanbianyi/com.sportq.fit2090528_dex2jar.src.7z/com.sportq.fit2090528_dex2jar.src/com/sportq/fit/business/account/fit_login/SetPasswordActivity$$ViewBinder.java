package com.sportq.fit.business.account.fit_login;

import android.view.View;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.common.utils.superView.RTextView;

public class SetPasswordActivity$$ViewBinder<T extends SetPasswordActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.password_edit_layout = ((EditItemView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756401, "field 'password_edit_layout'"), 2131756401, "field 'password_edit_layout'"));
    paramT.confirm_btn = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755524, "field 'confirm_btn'"), 2131755524, "field 'confirm_btn'"));
    paramT.header_right_btn = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757045, "field 'header_right_btn'"), 2131757045, "field 'header_right_btn'"));
  }

  public void unbind(T paramT)
  {
    paramT.password_edit_layout = null;
    paramT.confirm_btn = null;
    paramT.header_right_btn = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.SetPasswordActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */