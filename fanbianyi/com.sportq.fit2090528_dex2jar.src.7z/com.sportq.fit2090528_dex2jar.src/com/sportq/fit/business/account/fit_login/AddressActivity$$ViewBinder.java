package com.sportq.fit.business.account.fit_login;

import android.view.View;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.common.utils.superView.RTextView;

public class AddressActivity$$ViewBinder<T extends AddressActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.header_right_btn = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757045, "field 'header_right_btn'"), 2131757045, "field 'header_right_btn'"));
    paramT.user_address = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755447, "field 'user_address'"), 2131755447, "field 'user_address'"));
    paramT.next_step = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755448, "field 'next_step'"), 2131755448, "field 'next_step'"));
  }

  public void unbind(T paramT)
  {
    paramT.header_right_btn = null;
    paramT.user_address = null;
    paramT.next_step = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.AddressActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */