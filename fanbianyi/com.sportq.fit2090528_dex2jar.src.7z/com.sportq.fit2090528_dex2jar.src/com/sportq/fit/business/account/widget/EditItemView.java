package com.sportq.fit.business.account.widget;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class EditItemView extends FrameLayout
{
  private CountDownClickListener clickListener;
  private boolean isDisplay = true;
  private ItemType itemType;
  private ImageView item_clear;
  private RTextView item_countdown_view;
  private EditText item_edit;
  private ImageView item_hide;
  private ImageView item_icon;
  private EditListener listener;
  private boolean mHasFocus = false;
  private RTextViewHelper rTextViewHelper;
  private String result;
  private Subscription subscription;

  public EditItemView(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public EditItemView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public EditItemView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), 2130968778, null);
    this.item_edit = ((EditText)localView.findViewById(2131755902));
    this.item_edit.setOnFocusChangeListener(new View.OnFocusChangeListener()
    {
      @Instrumented
      public void onFocusChange(View paramView, boolean paramBoolean)
      {
        VdsAgent.onFocusChange(this, paramView, paramBoolean);
        EditItemView.access$002(EditItemView.this, paramBoolean);
        if ((EditItemView.this.listener != null) && (!paramBoolean))
          EditItemView.this.listener.onChangeResult(EditItemView.this.item_edit.getText().toString());
        EditItemView.this.setClearState();
      }
    });
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        if ((EditItemView.this.itemType == EditItemView.ItemType.PHONE) && (paramString.length() > 11))
        {
          EditItemView.this.item_edit.setText(paramString.substring(0, 11));
          EditItemView.this.item_edit.setSelection(11);
          ToastUtils.makeToast(EditItemView.this.getContext(), "手机号不能超过11位");
          return;
        }
        if ((EditItemView.this.itemType == EditItemView.ItemType.PASSWORD) && (paramString.length() > 20))
        {
          EditItemView.this.item_edit.setText(paramString.substring(0, 20));
          EditItemView.this.item_edit.setSelection(20);
          ToastUtils.makeToast(EditItemView.this.getContext(), "密码不能超过20位");
          return;
        }
        if ((EditItemView.this.itemType == EditItemView.ItemType.VERIFICATION) && (paramString.length() > 4))
        {
          EditItemView.this.item_edit.setText(paramString.substring(0, 4));
          EditItemView.this.item_edit.setSelection(4);
          ToastUtils.makeToast(EditItemView.this.getContext(), "验证码不能超过4位");
          return;
        }
        if ((EditItemView.this.itemType == EditItemView.ItemType.USERNAME) && (StringUtils.unicodeLenOfStr(paramString) > 32))
        {
          EditItemView.this.item_edit.setText(paramString.substring(0, -1 + paramString.length()));
          EditItemView.this.item_edit.setSelection(EditItemView.this.item_edit.getText().length());
          ToastUtils.makeToast(EditItemView.this.getContext(), "昵称请控制在3-32位字符");
        }
        EditItemView.access$502(EditItemView.this, paramString);
        if (EditItemView.this.listener != null)
          EditItemView.this.listener.onChangeResult(paramString);
        EditItemView.this.setClearState();
      }
    }
    , this.item_edit);
    this.item_clear = ((ImageView)localView.findViewById(2131755903));
    this.item_clear.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        EditItemView.this.item_edit.setText("");
        EditItemView.this.item_edit.setSelection(0);
      }
    });
    this.item_hide = ((ImageView)localView.findViewById(2131755904));
    this.item_hide.setVisibility(8);
    this.item_hide.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        ImageView localImageView = EditItemView.this.item_hide;
        int i;
        Object localObject;
        label55: EditItemView localEditItemView;
        if (EditItemView.this.isDisplay)
        {
          i = 2130903303;
          localImageView.setImageResource(i);
          EditText localEditText = EditItemView.this.item_edit;
          if (!EditItemView.this.isDisplay)
            break label122;
          localObject = HideReturnsTransformationMethod.getInstance();
          localEditText.setTransformationMethod((TransformationMethod)localObject);
          localEditItemView = EditItemView.this;
          if (EditItemView.this.isDisplay)
            break label130;
        }
        label130: for (boolean bool = true; ; bool = false)
        {
          EditItemView.access$602(localEditItemView, bool);
          EditItemView.this.item_edit.setSelection(EditItemView.this.item_edit.getText().toString().length());
          return;
          i = 2130903304;
          break;
          label122: localObject = PasswordTransformationMethod.getInstance();
          break label55;
        }
      }
    });
    this.item_countdown_view = ((RTextView)localView.findViewById(2131755905));
    this.item_countdown_view.setEnabled(false);
    this.rTextViewHelper = this.item_countdown_view.getHelper();
    this.item_countdown_view.setVisibility(8);
    this.item_countdown_view.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (EditItemView.this.clickListener != null)
          EditItemView.this.clickListener.onClick();
      }
    });
    this.item_icon = ((ImageView)localView.findViewById(2131755901));
    this.item_icon.setVisibility(8);
    return localView;
  }

  private void setClearState()
  {
    ImageView localImageView = this.item_clear;
    if ((this.mHasFocus) && (!StringUtils.isNull(this.result)) && (this.item_edit.isEnabled()));
    for (int i = 0; ; i = 4)
    {
      localImageView.setVisibility(i);
      return;
    }
  }

  public void clear()
  {
    this.item_edit.setText("");
  }

  public void onDestroy()
  {
    if (this.subscription != null)
    {
      this.subscription.unsubscribe();
      this.subscription = null;
    }
  }

  public void restore()
  {
    this.item_edit.setText("");
    this.item_clear.setVisibility(4);
    if (this.item_hide.getVisibility() == 0)
    {
      this.item_hide.setImageResource(2130903304);
      this.item_edit.setTransformationMethod(PasswordTransformationMethod.getInstance());
      this.isDisplay = true;
    }
  }

  public EditItemView setClickEnable(boolean paramBoolean)
  {
    this.item_edit.setEnabled(paramBoolean);
    return this;
  }

  public EditItemView setClickListener(CountDownClickListener paramCountDownClickListener)
  {
    this.clickListener = paramCountDownClickListener;
    return this;
  }

  public void setCodeEnable(boolean paramBoolean)
  {
    if (this.subscription != null)
      return;
    RTextViewHelper localRTextViewHelper = this.rTextViewHelper;
    Context localContext1 = getContext();
    int i;
    RTextView localRTextView;
    Context localContext2;
    if (paramBoolean)
    {
      i = 2131624121;
      localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(localContext1, i));
      this.item_countdown_view.setEnabled(paramBoolean);
      this.item_countdown_view.setText(getContext().getString(2131298346));
      localRTextView = this.item_countdown_view;
      localContext2 = getContext();
      if (!paramBoolean)
        break label110;
    }
    label110: for (int j = 2131624003; ; j = 2131624071)
    {
      localRTextView.setTextColor(ContextCompat.getColor(localContext2, j));
      this.item_countdown_view.setTextSize(15.0F);
      return;
      i = 2131624105;
      break;
    }
  }

  public EditItemView setEditColor(int paramInt)
  {
    this.item_edit.setTextColor(ContextCompat.getColor(getContext(), paramInt));
    return this;
  }

  public EditItemView setEditContent(String paramString)
  {
    if (StringUtils.isNull(paramString))
      paramString = "";
    this.item_edit.setText(paramString);
    this.item_edit.setSelection(paramString.length());
    return this;
  }

  public EditItemView setEditHint(String paramString)
  {
    this.item_edit.setHint(paramString);
    return this;
  }

  public EditItemView setItemIcon(int paramInt)
  {
    this.item_icon.setVisibility(0);
    this.item_icon.setImageResource(paramInt);
    return this;
  }

  public EditItemView setItemType(ItemType paramItemType)
  {
    this.itemType = paramItemType;
    if (this.itemType == ItemType.PHONE)
    {
      this.item_edit.setInputType(3);
      return this;
    }
    if (this.itemType == ItemType.PASSWORD)
    {
      this.item_edit.setInputType(129);
      return this;
    }
    if (this.itemType == ItemType.VERIFICATION)
    {
      this.item_edit.setInputType(2);
      return this;
    }
    this.item_edit.setInputType(1);
    return this;
  }

  public EditItemView setListener(EditListener paramEditListener)
  {
    this.listener = paramEditListener;
    return this;
  }

  public EditItemView showCountDown()
  {
    this.item_countdown_view.setVisibility(0);
    return this;
  }

  public EditItemView showHideBtn()
  {
    this.item_hide.setVisibility(0);
    this.item_edit.setTransformationMethod(PasswordTransformationMethod.getInstance());
    return this;
  }

  public void startTimeCountdown()
  {
    this.item_countdown_view.setEnabled(false);
    this.item_countdown_view.setTextSize(12.0F);
    this.rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), 2131624105));
    this.item_countdown_view.setText(UseStringUtils.getStr(2131298345, new String[] { "60" }));
    this.item_countdown_view.setTextColor(ContextCompat.getColor(getContext(), 2131624071));
    this.subscription = Observable.interval(1L, TimeUnit.SECONDS).take(61).onBackpressureBuffer().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1()
    {
      public void call(Long paramLong)
      {
        if (EditItemView.this.subscription == null)
          return;
        if (paramLong.longValue() == 60L)
        {
          EditItemView.this.subscription.unsubscribe();
          EditItemView.access$902(EditItemView.this, null);
          EditItemView.this.setCodeEnable(true);
          return;
        }
        RTextView localRTextView = EditItemView.this.item_countdown_view;
        String[] arrayOfString = new String[1];
        arrayOfString[0] = String.valueOf(59L - paramLong.longValue());
        localRTextView.setText(UseStringUtils.getStr(2131298345, arrayOfString));
      }
    });
  }

  public static abstract interface CountDownClickListener
  {
    public abstract void onClick();
  }

  public static abstract interface EditListener
  {
    public abstract void onChangeResult(String paramString);
  }

  public static enum ItemType
  {
    static
    {
      PASSWORD = new ItemType("PASSWORD", 1);
      VERIFICATION = new ItemType("VERIFICATION", 2);
      USERNAME = new ItemType("USERNAME", 3);
      ItemType[] arrayOfItemType = new ItemType[4];
      arrayOfItemType[0] = PHONE;
      arrayOfItemType[1] = PASSWORD;
      arrayOfItemType[2] = VERIFICATION;
      arrayOfItemType[3] = USERNAME;
      $VALUES = arrayOfItemType;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.widget.EditItemView
 * JD-Core Version:    0.6.0
 */