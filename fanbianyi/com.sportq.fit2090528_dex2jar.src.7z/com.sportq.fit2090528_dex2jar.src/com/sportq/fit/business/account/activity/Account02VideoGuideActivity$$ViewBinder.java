package com.sportq.fit.business.account.activity;

import android.view.View;
import android.widget.RelativeLayout;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.business.account.widget.AdVideoView;
import com.sportq.fit.common.utils.superView.RRelativeLayout;
import com.sportq.fit.common.utils.superView.RTextView;

public class Account02VideoGuideActivity$$ViewBinder<T extends Account02VideoGuideActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.account02VideoBg = ((AdVideoView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755226, "field 'account02VideoBg'"), 2131755226, "field 'account02VideoBg'"));
    paramT.account02_huawei_login = ((RRelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755231, "field 'account02_huawei_login'"), 2131755231, "field 'account02_huawei_login'"));
    paramT.account02_register = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755232, "field 'account02_register'"), 2131755232, "field 'account02_register'"));
    paramT.view_space = ((View)paramFinder.findRequiredView(paramObject, 2131755233, "field 'view_space'"));
    paramT.layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755225, "field 'layout'"), 2131755225, "field 'layout'"));
  }

  public void unbind(T paramT)
  {
    paramT.account02VideoBg = null;
    paramT.account02_huawei_login = null;
    paramT.account02_register = null;
    paramT.view_space = null;
    paramT.layout = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.Account02VideoGuideActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */