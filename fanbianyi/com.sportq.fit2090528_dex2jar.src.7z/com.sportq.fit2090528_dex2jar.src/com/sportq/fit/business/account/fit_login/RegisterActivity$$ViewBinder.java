package com.sportq.fit.business.account.fit_login;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.common.utils.superView.RTextView;

public class RegisterActivity$$ViewBinder<T extends RegisterActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.header_right_btn = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757045, "field 'header_right_btn'"), 2131757045, "field 'header_right_btn'"));
    paramT.phone_edit_layout = ((EditItemView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756127, "field 'phone_edit_layout'"), 2131756127, "field 'phone_edit_layout'"));
    paramT.get_verification_code = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755522, "field 'get_verification_code'"), 2131755522, "field 'get_verification_code'"));
    paramT.third_login_title = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757464, "field 'third_login_title'"), 2131757464, "field 'third_login_title'"));
    paramT.huawei_btn = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757465, "field 'huawei_btn'"), 2131757465, "field 'huawei_btn'"));
  }

  public void unbind(T paramT)
  {
    paramT.header_right_btn = null;
    paramT.phone_edit_layout = null;
    paramT.get_verification_code = null;
    paramT.third_login_title = null;
    paramT.huawei_btn = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.RegisterActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */