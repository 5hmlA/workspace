package com.sportq.fit.business.account.fit_login;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.TextPaint;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.business.account.widget.EditItemView.CountDownClickListener;
import com.sportq.fit.business.account.widget.EditItemView.EditListener;
import com.sportq.fit.business.account.widget.EditItemView.ItemType;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;
import com.sportq.fit.fitmoudle.network.reformer.NeceDataUIReformer;
import com.sportq.fit.middlelib.MiddleManager;

public class FindPasswordActivity extends BaseActivity
{
  public static final String PHONE_NUM = "phone.num";

  @Bind({2131756128})
  EditItemView code_edit_layout;

  @Bind({2131756129})
  TextView help_btn;

  @Bind({2131755448})
  RTextView next_step;

  @Bind({2131756127})
  EditItemView phone_edit_layout;
  private RTextViewHelper rTextViewHelper;
  private String strCode = "";
  private String strPhone = "";

  private void checkNextStepBtnState()
  {
    boolean bool;
    int i;
    label45: RTextView localRTextView;
    if ((this.strPhone.length() == 11) && (this.strCode.length() == 4))
    {
      bool = true;
      this.next_step.setEnabled(bool);
      RTextViewHelper localRTextViewHelper = this.rTextViewHelper;
      if (!bool)
        break label86;
      i = 2131624121;
      localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this, i));
      localRTextView = this.next_step;
      if (!bool)
        break label92;
    }
    label86: label92: for (int j = 2131624003; ; j = 2131624071)
    {
      localRTextView.setTextColor(ContextCompat.getColor(this, j));
      return;
      bool = false;
      break;
      i = 2131624105;
      break label45;
    }
  }

  private void getNeceData()
  {
    if (StringUtils.isNull(this.strPhone))
    {
      ToastUtils.makeToast(this, getString(2131298568));
      return;
    }
    if (!StringUtils.checkNumber(this.strPhone))
    {
      ToastUtils.makeToast(this, getString(2131298567));
      return;
    }
    this.dialog.createProgressDialog(this, "请稍后...");
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.phoneNumber = this.strPhone;
    new PresenterImpl(this).getNeceData(localRequestModel, this);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131757043:
    case 2131756129:
    case 2131755448:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      if (StringUtils.isNull(this.strPhone))
      {
        ToastUtils.makeToast(this, "请输入手机号");
        return;
      }
      if (!StringUtils.checkNumber(this.strPhone))
      {
        ToastUtils.makeToast(this, "请输入正确的手机号");
        return;
      }
      Intent localIntent = new Intent(this, VoiceVerCodeActivity.class);
      localIntent.putExtra("phone.num", this.strPhone);
      localIntent.putExtra("page.from", "7");
      startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this, 0);
      continue;
      this.dialog.createProgressDialog(this, "请稍后...");
      MiddleManager.getInstance().getLoginPresenterImpl(this).postCheckVerification(this.strPhone, this.strCode, this);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof NeceDataUIReformer))
    {
      String str = ((NeceDataUIReformer)paramT).timeKey;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = this.strPhone;
      localRequestModel.acquisitionMode = "3";
      localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(str + NdkUtils.getSignBaseUrl()).toUpperCase();
      MiddleManager.getInstance().getLoginPresenterImpl(this).getVerification(localRequestModel, this);
    }
    LoginReformer localLoginReformer;
    do
    {
      do
        return;
      while (!(paramT instanceof LoginReformer));
      this.dialog.closeDialog();
      localLoginReformer = (LoginReformer)paramT;
      if (!"0".equals(localLoginReformer.tag))
        continue;
      this.code_edit_layout.startTimeCountdown();
      return;
    }
    while (!"1".equals(localLoginReformer.tag));
    Intent localIntent = new Intent(this, SetPasswordActivity.class);
    localIntent.putExtra("phone.num", this.strPhone);
    localIntent.putExtra("page.from", "2");
    startActivity(localIntent);
    AnimationUtil.pageJumpAnim(this, 0);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968840);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    this.rTextViewHelper = this.next_step.getHelper();
    this.strPhone = getIntent().getStringExtra("phone.num");
    this.phone_edit_layout.setEditHint(getString(2131298340)).setItemType(EditItemView.ItemType.PHONE).setListener(new EditItemView.EditListener()
    {
      public void onChangeResult(String paramString)
      {
        FindPasswordActivity.access$002(FindPasswordActivity.this, paramString);
        EditItemView localEditItemView = FindPasswordActivity.this.code_edit_layout;
        if (FindPasswordActivity.this.strPhone.length() == 11);
        for (boolean bool = true; ; bool = false)
        {
          localEditItemView.setCodeEnable(bool);
          FindPasswordActivity.this.checkNextStepBtnState();
          return;
        }
      }
    }).setEditContent(this.strPhone);
    this.code_edit_layout.setEditHint("请输入4位验证码").setItemType(EditItemView.ItemType.VERIFICATION).showCountDown().setListener(new EditItemView.EditListener()
    {
      public void onChangeResult(String paramString)
      {
        FindPasswordActivity.access$302(FindPasswordActivity.this, paramString);
        FindPasswordActivity.this.checkNextStepBtnState();
      }
    }).setClickListener(new EditItemView.CountDownClickListener()
    {
      public void onClick()
      {
        FindPasswordActivity.this.getNeceData();
      }
    });
    this.help_btn.setText(getString(2131298344));
    this.help_btn.getPaint().setFlags(9);
    this.next_step.setEnabled(false);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.FindPasswordActivity
 * JD-Core Version:    0.6.0
 */