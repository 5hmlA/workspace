package com.sportq.fit.business.account.fit_login;

import android.view.View;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.common.utils.superView.RTextView;

public class FindPasswordActivity$$ViewBinder<T extends FindPasswordActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.phone_edit_layout = ((EditItemView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756127, "field 'phone_edit_layout'"), 2131756127, "field 'phone_edit_layout'"));
    paramT.code_edit_layout = ((EditItemView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756128, "field 'code_edit_layout'"), 2131756128, "field 'code_edit_layout'"));
    paramT.next_step = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755448, "field 'next_step'"), 2131755448, "field 'next_step'"));
    paramT.help_btn = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756129, "field 'help_btn'"), 2131756129, "field 'help_btn'"));
  }

  public void unbind(T paramT)
  {
    paramT.phone_edit_layout = null;
    paramT.code_edit_layout = null;
    paramT.next_step = null;
    paramT.help_btn = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.FindPasswordActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */