package com.sportq.fit.business.account.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.nineoldandroids.view.ViewHelper;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle7.customize.widget.CustomizeCommonMethods;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Account05FitnessBasicActivity extends BaseActivity
{

  @Bind({2131755255})
  ImageView account05_fitness_goal_back;

  @Bind({2131755256})
  TextView account05_fitness_goal_title;
  private int animaDuration = 200;
  private CustomizeCommonMethods cMethods = null;
  String comment = "从零开始，通过适应性训练，开启你的减脂之旅|从零开始，通过适应性训练，为塑造肌肉线条打好基础|从零开始，通过适应性训练，为肌肉力量训练打好基础";
  String comment2 = "身体素质良好，需要系统化的减脂训练指引|有运动基础，追求力量、耐力及肌肉线条的全面进阶|有一定运动经验和力量基础，接受塑造肌肉线条的进阶训练";
  String comment3 = "有运动基础，能接受高强度的减脂训练课程|有运动基础和健身经验，能接受高强度的塑形训练课程|肌肉线条清晰，有一定健身经验和力量基础，向完美进发";

  @Bind({2131755259})
  RTextView cust02fitgoalNextBtn;
  private int delayTime = 100;

  @Bind({2131755276})
  View focusIcon;
  private int[] hintLocation = new int[2];

  @Bind({2131755261})
  TextView hint_view;
  private boolean initFlg = true;
  private int[] initLocation = new int[2];
  private int[] location = new int[2];
  private RTextViewHelper rTextViewHelper;

  @Bind({2131755257})
  TextView title_content_hint;

  @Bind({2131755260})
  RelativeLayout train06FirstContent;

  @Bind({2131755264})
  View train06FirstIcon;

  @Bind({2131755265})
  TextView train06FirstIntroduce;

  @Bind({2131755263})
  TextView train06FirstTitle;

  @Bind({2131755266})
  RelativeLayout train06SecondContent;

  @Bind({2131755269})
  View train06SecondIcon;

  @Bind({2131755270})
  TextView train06SecondIntroduce;

  @Bind({2131755268})
  TextView train06SecondTitle;

  @Bind({2131755271})
  RelativeLayout train06ThirdContent;

  @Bind({2131755274})
  View train06ThirdIcon;

  @Bind({2131755275})
  TextView train06ThirdIntroduce;

  @Bind({2131755273})
  TextView train06ThirdTitle;
  private TextView[] viewHintList;
  private View[] viewIconList;
  private TextView[] viewItemList;

  private void initAnimation(int paramInt)
  {
    if (this.initFlg)
    {
      initClickAnimation(paramInt);
      initIconLocation(this.viewIconList[paramInt]);
      this.initFlg = false;
      return;
    }
    startClickAnimation(paramInt);
  }

  private void initClickAnimation(int paramInt)
  {
    TranslateAnimation localTranslateAnimation = new TranslateAnimation(0.0F, this.hintLocation[0] - this.initLocation[0], 0.0F, 0.0F);
    localTranslateAnimation.setDuration(this.animaDuration);
    this.train06FirstTitle.startAnimation(localTranslateAnimation);
    this.train06SecondTitle.startAnimation(localTranslateAnimation);
    this.train06ThirdTitle.startAnimation(localTranslateAnimation);
    localTranslateAnimation.setAnimationListener(new Animation.AnimationListener(paramInt)
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Account05FitnessBasicActivity.this.train06FirstTitle.clearAnimation();
        Account05FitnessBasicActivity.this.train06SecondTitle.clearAnimation();
        Account05FitnessBasicActivity.this.train06ThirdTitle.clearAnimation();
        ViewHelper.setTranslationX(Account05FitnessBasicActivity.this.train06FirstTitle, Account05FitnessBasicActivity.this.hintLocation[0] - Account05FitnessBasicActivity.this.initLocation[0]);
        ViewHelper.setTranslationX(Account05FitnessBasicActivity.this.train06SecondTitle, Account05FitnessBasicActivity.this.hintLocation[0] - Account05FitnessBasicActivity.this.initLocation[0]);
        ViewHelper.setTranslationX(Account05FitnessBasicActivity.this.train06ThirdTitle, Account05FitnessBasicActivity.this.hintLocation[0] - Account05FitnessBasicActivity.this.initLocation[0]);
        Account05FitnessBasicActivity.this.viewHintList[this.val$index].setVisibility(0);
        AlphaAnimation localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
        localAlphaAnimation.setDuration(Account05FitnessBasicActivity.this.delayTime);
        Account05FitnessBasicActivity.this.viewHintList[this.val$index].setAnimation(localAlphaAnimation);
        Account05FitnessBasicActivity.this.train06FirstContent.setOnClickListener(new FitAction(Account05FitnessBasicActivity.this));
        Account05FitnessBasicActivity.this.train06SecondContent.setOnClickListener(new FitAction(Account05FitnessBasicActivity.this));
        Account05FitnessBasicActivity.this.train06ThirdContent.setOnClickListener(new FitAction(Account05FitnessBasicActivity.this));
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
        Account05FitnessBasicActivity.this.train06FirstContent.setOnClickListener(null);
        Account05FitnessBasicActivity.this.train06SecondContent.setOnClickListener(null);
        Account05FitnessBasicActivity.this.train06ThirdContent.setOnClickListener(null);
      }
    });
    new Handler().postDelayed(new Runnable(paramInt)
    {
      public void run()
      {
        AnimationUtil.fontColorGradientAnimation(Account05FitnessBasicActivity.this.viewItemList[this.val$index], -1644826, -13553359, Account05FitnessBasicActivity.this.delayTime);
      }
    }
    , this.delayTime);
  }

  private void initData()
  {
    this.account05_fitness_goal_back.setVisibility(0);
    this.account05_fitness_goal_title.setText(getString(2131298267));
    this.title_content_hint.setText(getString(2131298274));
    TextView[] arrayOfTextView1 = new TextView[3];
    arrayOfTextView1[0] = this.train06FirstTitle;
    arrayOfTextView1[1] = this.train06SecondTitle;
    arrayOfTextView1[2] = this.train06ThirdTitle;
    this.viewItemList = arrayOfTextView1;
    View[] arrayOfView = new View[3];
    arrayOfView[0] = this.train06FirstIcon;
    arrayOfView[1] = this.train06SecondIcon;
    arrayOfView[2] = this.train06ThirdIcon;
    this.viewIconList = arrayOfView;
    TextView[] arrayOfTextView2 = new TextView[3];
    arrayOfTextView2[0] = this.train06FirstIntroduce;
    arrayOfTextView2[1] = this.train06SecondIntroduce;
    arrayOfTextView2[2] = this.train06ThirdIntroduce;
    this.viewHintList = arrayOfTextView2;
    try
    {
      this.train06FirstTitle.setText(StringUtils.getStringResources(2131299096));
      this.train06FirstIntroduce.setText(this.comment.split("[|]")[StringUtils.string2Int(FitApplication.userModel.fitGoal)]);
      this.train06SecondTitle.setText(StringUtils.getStringResources(2131298929));
      this.train06SecondIntroduce.setText(this.comment2.split("[|]")[StringUtils.string2Int(FitApplication.userModel.fitGoal)]);
      this.train06ThirdTitle.setText(StringUtils.getStringResources(2131299131));
      this.train06ThirdIntroduce.setText(this.comment3.split("[|]")[StringUtils.string2Int(FitApplication.userModel.fitGoal)]);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void initIconLocation(View paramView)
  {
    paramView.post(new Runnable(paramView)
    {
      public void run()
      {
        this.val$view.getLocationInWindow(Account05FitnessBasicActivity.this.location);
        RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)Account05FitnessBasicActivity.this.focusIcon.getLayoutParams();
        localLayoutParams.height = Account05FitnessBasicActivity.this.train06FirstIcon.getHeight();
        Account05FitnessBasicActivity.this.focusIcon.setLayoutParams(localLayoutParams);
        Account05FitnessBasicActivity.this.focusIcon.setX(Account05FitnessBasicActivity.this.location[0]);
        Account05FitnessBasicActivity.this.focusIcon.setY(Account05FitnessBasicActivity.this.location[1] - CompDeviceInfoUtils.getStatusBarHeight(Account05FitnessBasicActivity.this));
        new Handler().postDelayed(new Runnable()
        {
          public void run()
          {
            Account05FitnessBasicActivity.this.focusIcon.setVisibility(0);
            AlphaAnimation localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
            localAlphaAnimation.setDuration(Account05FitnessBasicActivity.this.delayTime);
            Account05FitnessBasicActivity.this.focusIcon.setAnimation(localAlphaAnimation);
          }
        }
        , Account05FitnessBasicActivity.this.delayTime);
      }
    });
  }

  private void startClickAnimation(int paramInt)
  {
    this.focusIcon.getLocationInWindow(this.location);
    int[] arrayOfInt = new int[2];
    View localView = this.viewIconList[paramInt];
    localView.getLocationInWindow(arrayOfInt);
    TranslateAnimation localTranslateAnimation = new TranslateAnimation(0.0F, 0.0F, 0.0F, arrayOfInt[1] - this.location[1]);
    localTranslateAnimation.setDuration(this.animaDuration);
    this.focusIcon.startAnimation(localTranslateAnimation);
    localTranslateAnimation.setAnimationListener(new Animation.AnimationListener(arrayOfInt)
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Account05FitnessBasicActivity.this.focusIcon.clearAnimation();
        ViewHelper.setTranslationX(Account05FitnessBasicActivity.this.focusIcon, this.val$clickViewLocation[0]);
        ViewHelper.setTranslationY(Account05FitnessBasicActivity.this.focusIcon, this.val$clickViewLocation[1] - CompDeviceInfoUtils.getStatusBarHeight(Account05FitnessBasicActivity.this));
        Account05FitnessBasicActivity.this.train06FirstContent.setOnClickListener(new FitAction(Account05FitnessBasicActivity.this));
        Account05FitnessBasicActivity.this.train06SecondContent.setOnClickListener(new FitAction(Account05FitnessBasicActivity.this));
        Account05FitnessBasicActivity.this.train06ThirdContent.setOnClickListener(new FitAction(Account05FitnessBasicActivity.this));
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
        Account05FitnessBasicActivity.this.train06FirstContent.setOnClickListener(null);
        Account05FitnessBasicActivity.this.train06SecondContent.setOnClickListener(null);
        Account05FitnessBasicActivity.this.train06ThirdContent.setOnClickListener(null);
      }
    });
    if (localView.getId() == 2131755264)
      this.cMethods.titleColorIsAnima(this.train06FirstTitle, this.train06SecondTitle, this.train06ThirdTitle);
    while (localView.getId() == 2131755264)
    {
      this.cMethods.introShowOrHideAnima(this.train06FirstIntroduce, this.train06SecondIntroduce, this.train06ThirdIntroduce);
      return;
      if (localView.getId() == 2131755269)
      {
        this.cMethods.titleColorIsAnima(this.train06SecondTitle, this.train06FirstTitle, this.train06ThirdTitle);
        continue;
      }
      this.cMethods.titleColorIsAnima(this.train06ThirdTitle, this.train06FirstTitle, this.train06SecondTitle);
    }
    if (localView.getId() == 2131755269)
    {
      this.cMethods.introShowOrHideAnima(this.train06SecondIntroduce, this.train06FirstIntroduce, this.train06ThirdIntroduce);
      return;
    }
    this.cMethods.introShowOrHideAnima(this.train06ThirdIntroduce, this.train06FirstIntroduce, this.train06SecondIntroduce);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131755255:
    case 2131755260:
    case 2131755266:
    case 2131755271:
    case 2131755259:
    }
    while (true)
    {
      this.rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this, 2131624121));
      this.cust02fitgoalNextBtn.setTextColor(ContextCompat.getColor(this, 2131624003));
      this.cust02fitgoalNextBtn.setEnabled(true);
      return;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      initAnimation(0);
      FitApplication.userModel.fitBase = "0";
      continue;
      initAnimation(1);
      FitApplication.userModel.fitBase = "1";
      continue;
      initAnimation(2);
      FitApplication.userModel.fitBase = "2";
      continue;
      this.dialog.createProgressDialog(this, "请稍后...");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.userName = FitApplication.userModel.userName;
      if ((!StringUtils.isNull(FitApplication.userModel.userImg)) && (!FitApplication.userModel.userImg.contains("http")))
      {
        Bitmap localBitmap = BitmapFactory.decodeFile(FitApplication.userModel.userImg);
        if (localBitmap != null)
          localRequestModel.userImg = QiniuManager.uploadBitmap(localBitmap);
      }
      localRequestModel.fitGoal = FitApplication.userModel.fitGoal;
      localRequestModel.fitBase = FitApplication.userModel.fitBase;
      localRequestModel.coachSexf = FitApplication.userModel.coachSexf;
      MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(localRequestModel, this);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    if ("Y".equals(paramT))
    {
      AppSharePreferenceUtils.putRegisterFirstLogin(true);
      startActivity(new Intent(this, Account07RecPlanActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968613);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.rTextViewHelper = this.cust02fitgoalNextBtn.getHelper();
    this.cMethods = new CustomizeCommonMethods("1");
    this.cMethods.setColors(-13553359, -1644826);
    initData();
    this.train06FirstContent.setOnClickListener(new FitAction(this));
    this.train06SecondContent.setOnClickListener(new FitAction(this));
    this.train06ThirdContent.setOnClickListener(new FitAction(this));
    this.account05_fitness_goal_back.setOnClickListener(new FitAction(this));
    this.cust02fitgoalNextBtn.setOnClickListener(new FitAction(this));
    this.cust02fitgoalNextBtn.setEnabled(false);
    this.train06FirstTitle.post(new Runnable()
    {
      public void run()
      {
        Account05FitnessBasicActivity.this.train06FirstTitle.getLocationInWindow(Account05FitnessBasicActivity.this.initLocation);
      }
    });
    this.hint_view.post(new Runnable()
    {
      public void run()
      {
        Account05FitnessBasicActivity.this.hint_view.getLocationInWindow(Account05FitnessBasicActivity.this.hintLocation);
      }
    });
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("register.finish".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.Account05FitnessBasicActivity
 * JD-Core Version:    0.6.0
 */