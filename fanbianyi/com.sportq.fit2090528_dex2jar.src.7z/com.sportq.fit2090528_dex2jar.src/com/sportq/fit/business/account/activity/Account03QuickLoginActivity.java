package com.sportq.fit.business.account.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextPaint;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.NavMainActivity;
import com.sportq.fit.business.account.fit_login.LoginActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.FitVipUserView;
import com.sportq.fit.middlelib.MiddleManager;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Account03QuickLoginActivity extends BaseActivity
{

  @Bind({2131755238})
  TextView account03QuickLoginName;

  @Bind({2131755239})
  TextView account03QuickLoginOnway;

  @Bind({2131755234})
  TextView account03QuickLoginOtherWay;

  @Bind({2131755237})
  FitVipUserView account03QuickLoginPhoto;

  private void closeDialog()
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
  }

  private void init()
  {
    if (!StringUtils.isNull(BaseApplication.userModel.isVip))
      this.account03QuickLoginPhoto.setIsVip(Integer.valueOf(BaseApplication.userModel.isVip).intValue());
    this.account03QuickLoginPhoto.loadUserIcon(FitApplication.userModel.userImg).setVipTagSize(CompDeviceInfoUtils.convertOfDip(this, 75.0F), 0.2667D);
    if (!StringUtils.isNull(FitApplication.userModel.userName))
      this.account03QuickLoginName.setText(FitApplication.userModel.userName);
    this.account03QuickLoginOnway.setText(StringUtils.getLastLoginName());
    this.account03QuickLoginOtherWay.getPaint().setFlags(9);
  }

  private void jumpToMainTab()
  {
    EventBus.getDefault().post("quick.login");
    SharePreferenceUtils.putLoginStatus(this, "");
    startActivity(new Intent(this, NavMainActivity.class));
    overridePendingTransition(2131034135, 2131034136);
    finish();
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
      return;
    case 2131755234:
      startActivity(new Intent(this, LoginActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
      return;
    case 2131755235:
    }
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      ToastUtils.makeToast(this, StringUtils.getStringResources(2131299052));
      return;
    }
    if ("8".equals(FitApplication.userModel.loginTerrace))
    {
      if (StringUtils.isNull(BaseApplication.userModel.password))
      {
        Intent localIntent = new Intent(this, LoginActivity.class);
        localIntent.putExtra("phone.num", BaseApplication.userModel.phoneNumber);
        localIntent.putExtra("page.from", "1");
        startActivity(localIntent);
        AnimationUtil.pageJumpAnim(this, 0);
        return;
      }
      this.dialog.createProgressDialog(this, "请稍后...");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.terrace = "8";
      localRequestModel.phoneNumber = FitApplication.userModel.phoneNumber;
      localRequestModel.password = FitApplication.userModel.password;
      localRequestModel.flag = "0";
      MiddleManager.getInstance().getLoginPresenterImpl(this).quickLogin(localRequestModel, this);
      return;
    }
    this.dialog.createProgressDialog(this, "请稍后...");
    MiddleManager.getInstance().getRegisterPresenterImpl(this).registerAccountBind(FitApplication.userModel.loginTerrace, "1", this);
  }

  public <T> void getDataFail(T paramT)
  {
    closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ("Y".equals(paramT))
    {
      closeDialog();
      jumpToMainTab();
    }
    do
      return;
    while (!"三方已绑定".equals(((UserModel)paramT).tag));
    if (this.dialog != null)
      this.dialog.setProDialogTextHint(StringUtils.getStringResources(2131298942));
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.uid = FitApplication.thirdUserModel.uid;
    localRequestModel.terrace = FitApplication.userModel.loginTerrace;
    localRequestModel.flag = "0";
    MiddleManager.getInstance().getLoginPresenterImpl(this).login(localRequestModel, this);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968608);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    EventBus.getDefault().register(this);
    init();
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    closeDialog();
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("login.finish".equals(paramString))
      finish();
    if ("fitness.finish".equals(paramString))
      finish();
    if ("perfect.info".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      return true;
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.Account03QuickLoginActivity
 * JD-Core Version:    0.6.0
 */