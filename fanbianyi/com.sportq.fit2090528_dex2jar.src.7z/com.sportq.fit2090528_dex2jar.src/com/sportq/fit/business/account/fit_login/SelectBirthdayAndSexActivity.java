package com.sportq.fit.business.account.fit_login;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.account.activity.Account05FitnessGoalsActivity;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class SelectBirthdayAndSexActivity extends BaseActivity
{

  @Bind({2131757208})
  ImageView female_btn;

  @Bind({2131757207})
  ImageView male_btn;

  @Bind({2131755448})
  RTextView next_step;
  private RTextViewHelper rTextViewHelper;
  private String userSex = "";

  private void checkNextStep()
  {
    boolean bool;
    int i;
    label24: RTextView localRTextView;
    if (!StringUtils.isNull(this.userSex))
    {
      bool = true;
      RTextViewHelper localRTextViewHelper = this.rTextViewHelper;
      if (!bool)
        break label73;
      i = 2131624121;
      localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this, i));
      localRTextView = this.next_step;
      if (!bool)
        break label79;
    }
    label73: label79: for (int j = 2131624003; ; j = 2131624071)
    {
      localRTextView.setTextColor(ContextCompat.getColor(this, j));
      this.next_step.setEnabled(bool);
      return;
      bool = false;
      break;
      i = 2131624105;
      break label24;
    }
  }

  private void choiceSex(String paramString)
  {
    this.userSex = paramString;
    ImageView localImageView1 = this.male_btn;
    int i;
    ImageView localImageView2;
    if ("0".equals(paramString))
    {
      i = 2130903297;
      localImageView1.setImageResource(i);
      localImageView2 = this.female_btn;
      if (!"1".equals(paramString))
        break label64;
    }
    label64: for (int j = 2130903294; ; j = 2130903295)
    {
      localImageView2.setImageResource(j);
      checkNextStep();
      return;
      i = 2130903298;
      break;
    }
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131757043:
    case 2131757207:
    case 2131757208:
      while (true)
      {
        super.fitOnClick(paramView);
        return;
        finish();
        AnimationUtil.pageJumpAnim(this, 1);
        continue;
        choiceSex("0");
        continue;
        choiceSex("1");
      }
    case 2131755448:
    }
    com.sportq.fit.common.interfaces.dialog.DialogInterface localDialogInterface = this.dialog;
    1 local1 = new FitInterfaceUtils.DialogListener()
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        if (paramInt == -1)
        {
          FitApplication.userModel.userSex = SelectBirthdayAndSexActivity.this.userSex;
          FitApplication.userModel.coachSexf = SelectBirthdayAndSexActivity.this.userSex;
          SelectBirthdayAndSexActivity.this.startActivity(new Intent(SelectBirthdayAndSexActivity.this, Account05FitnessGoalsActivity.class));
          AnimationUtil.pageJumpAnim(SelectBirthdayAndSexActivity.this, 0);
        }
      }
    };
    String[] arrayOfString = new String[1];
    if ("0".equals(this.userSex));
    for (String str = "男"; ; str = "女")
    {
      arrayOfString[0] = str;
      localDialogInterface.createChoiceDialog(local1, this, "", UseStringUtils.getStr(2131298287, arrayOfString));
      break;
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969096);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.rTextViewHelper = this.next_step.getHelper();
    this.next_step.setEnabled(false);
  }

  protected void onDestroy()
  {
    this.dialog.closeDialog();
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("register.finish".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.SelectBirthdayAndSexActivity
 * JD-Core Version:    0.6.0
 */