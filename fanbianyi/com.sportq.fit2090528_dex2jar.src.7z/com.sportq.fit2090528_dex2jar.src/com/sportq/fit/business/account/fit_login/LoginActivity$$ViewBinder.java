package com.sportq.fit.business.account.fit_login;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.business.account.widget.EditItemView;
import com.sportq.fit.common.utils.superView.RTextView;

public class LoginActivity$$ViewBinder<T extends LoginActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.header_right_btn = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757045, "field 'header_right_btn'"), 2131757045, "field 'header_right_btn'"));
    paramT.password_login_title = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756399, "field 'password_login_title'"), 2131756399, "field 'password_login_title'"));
    paramT.password_login_line = ((View)paramFinder.findRequiredView(paramObject, 2131756400, "field 'password_login_line'"));
    paramT.verification_code_login_title = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756396, "field 'verification_code_login_title'"), 2131756396, "field 'verification_code_login_title'"));
    paramT.verification_code_login_line = ((View)paramFinder.findRequiredView(paramObject, 2131756397, "field 'verification_code_login_line'"));
    paramT.phone_edit_layout = ((EditItemView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756127, "field 'phone_edit_layout'"), 2131756127, "field 'phone_edit_layout'"));
    paramT.password_edit_layout = ((EditItemView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756401, "field 'password_edit_layout'"), 2131756401, "field 'password_edit_layout'"));
    paramT.code_edit_layout = ((EditItemView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756128, "field 'code_edit_layout'"), 2131756128, "field 'code_edit_layout'"));
    paramT.login_in_view = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756402, "field 'login_in_view'"), 2131756402, "field 'login_in_view'"));
    paramT.help_btn = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756129, "field 'help_btn'"), 2131756129, "field 'help_btn'"));
    paramT.verification_login_hint = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756404, "field 'verification_login_hint'"), 2131756404, "field 'verification_login_hint'"));
    paramT.huawei_btn = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757465, "field 'huawei_btn'"), 2131757465, "field 'huawei_btn'"));
  }

  public void unbind(T paramT)
  {
    paramT.header_right_btn = null;
    paramT.password_login_title = null;
    paramT.password_login_line = null;
    paramT.verification_code_login_title = null;
    paramT.verification_code_login_line = null;
    paramT.phone_edit_layout = null;
    paramT.password_edit_layout = null;
    paramT.code_edit_layout = null;
    paramT.login_in_view = null;
    paramT.help_btn = null;
    paramT.verification_login_hint = null;
    paramT.huawei_btn = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.LoginActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */