package com.sportq.fit.business.account.fit_login;

import android.view.View;
import android.widget.ImageView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.common.utils.superView.RTextView;

public class SelectBirthdayAndSexActivity$$ViewBinder<T extends SelectBirthdayAndSexActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.male_btn = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757207, "field 'male_btn'"), 2131757207, "field 'male_btn'"));
    paramT.female_btn = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757208, "field 'female_btn'"), 2131757208, "field 'female_btn'"));
    paramT.next_step = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755448, "field 'next_step'"), 2131755448, "field 'next_step'"));
  }

  public void unbind(T paramT)
  {
    paramT.male_btn = null;
    paramT.female_btn = null;
    paramT.next_step = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.fit_login.SelectBirthdayAndSexActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */