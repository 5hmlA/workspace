package com.sportq.fit.business.account.activity;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.common.utils.superView.RTextView;

public class Account05FitnessGoalsActivity$$ViewBinder<T extends Account05FitnessGoalsActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.focusIcon = ((View)paramFinder.findRequiredView(paramObject, 2131755276, "field 'focusIcon'"));
    paramT.train06FirstIcon = ((View)paramFinder.findRequiredView(paramObject, 2131755264, "field 'train06FirstIcon'"));
    paramT.train06FirstTitle = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755263, "field 'train06FirstTitle'"), 2131755263, "field 'train06FirstTitle'"));
    paramT.train06FirstIntroduce = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755265, "field 'train06FirstIntroduce'"), 2131755265, "field 'train06FirstIntroduce'"));
    paramT.train06FirstContent = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755260, "field 'train06FirstContent'"), 2131755260, "field 'train06FirstContent'"));
    paramT.train06SecondIcon = ((View)paramFinder.findRequiredView(paramObject, 2131755269, "field 'train06SecondIcon'"));
    paramT.train06SecondTitle = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755268, "field 'train06SecondTitle'"), 2131755268, "field 'train06SecondTitle'"));
    paramT.train06SecondIntroduce = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755270, "field 'train06SecondIntroduce'"), 2131755270, "field 'train06SecondIntroduce'"));
    paramT.train06SecondContent = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755266, "field 'train06SecondContent'"), 2131755266, "field 'train06SecondContent'"));
    paramT.train06ThirdIcon = ((View)paramFinder.findRequiredView(paramObject, 2131755274, "field 'train06ThirdIcon'"));
    paramT.train06ThirdTitle = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755273, "field 'train06ThirdTitle'"), 2131755273, "field 'train06ThirdTitle'"));
    paramT.train06ThirdIntroduce = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755275, "field 'train06ThirdIntroduce'"), 2131755275, "field 'train06ThirdIntroduce'"));
    paramT.train06ThirdContent = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755271, "field 'train06ThirdContent'"), 2131755271, "field 'train06ThirdContent'"));
    paramT.cust02fitgoalNextBtn = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755259, "field 'cust02fitgoalNextBtn'"), 2131755259, "field 'cust02fitgoalNextBtn'"));
    paramT.title_content_hint = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755257, "field 'title_content_hint'"), 2131755257, "field 'title_content_hint'"));
    paramT.account05_fitness_goal_title = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755256, "field 'account05_fitness_goal_title'"), 2131755256, "field 'account05_fitness_goal_title'"));
    paramT.account05_fitness_goal_back = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755255, "field 'account05_fitness_goal_back'"), 2131755255, "field 'account05_fitness_goal_back'"));
    paramT.hint_view = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755261, "field 'hint_view'"), 2131755261, "field 'hint_view'"));
  }

  public void unbind(T paramT)
  {
    paramT.focusIcon = null;
    paramT.train06FirstIcon = null;
    paramT.train06FirstTitle = null;
    paramT.train06FirstIntroduce = null;
    paramT.train06FirstContent = null;
    paramT.train06SecondIcon = null;
    paramT.train06SecondTitle = null;
    paramT.train06SecondIntroduce = null;
    paramT.train06SecondContent = null;
    paramT.train06ThirdIcon = null;
    paramT.train06ThirdTitle = null;
    paramT.train06ThirdIntroduce = null;
    paramT.train06ThirdContent = null;
    paramT.cust02fitgoalNextBtn = null;
    paramT.title_content_hint = null;
    paramT.account05_fitness_goal_title = null;
    paramT.account05_fitness_goal_back = null;
    paramT.hint_view = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.account.activity.Account05FitnessGoalsActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */