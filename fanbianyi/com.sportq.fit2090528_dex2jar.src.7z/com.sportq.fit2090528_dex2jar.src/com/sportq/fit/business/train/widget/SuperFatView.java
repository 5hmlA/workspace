package com.sportq.fit.business.train.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.activity.Mine03WebUrlActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.EntloseFatData;
import com.sportq.fit.common.model.EntloseFatItemModel;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampDetailActivity;
import com.sportq.fit.fitmoudle7.customize.activity.fat_camp.FatCampWelcomeActivity;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.http.cache.FitCacheStoreUtils;
import java.util.ArrayList;

public class SuperFatView extends FrameLayout
{
  private RTextView finish_pro;
  private TextView super_fat_class_name;
  private ImageView super_fat_img;
  private RelativeLayout super_fat_join_layout;
  private TextView super_fat_title;
  private LinearLayout train_num_layout;

  public SuperFatView(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public SuperFatView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public SuperFatView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), 2130968809, null);
    this.super_fat_title = ((TextView)localView.findViewById(2131755999));
    this.super_fat_img = ((ImageView)localView.findViewById(2131756002));
    this.super_fat_join_layout = ((RelativeLayout)localView.findViewById(2131756003));
    this.super_fat_class_name = ((TextView)localView.findViewById(2131756004));
    this.train_num_layout = ((LinearLayout)localView.findViewById(2131756006));
    this.finish_pro = ((RTextView)localView.findViewById(2131756007));
    FrameLayout localFrameLayout = (FrameLayout)localView.findViewById(2131756001);
    localFrameLayout.getLayoutParams().width = BaseApplication.screenWidth;
    localFrameLayout.getLayoutParams().height = (int)(0.6403D * BaseApplication.screenWidth);
    this.super_fat_join_layout.getLayoutParams().height = (int)(0.78D * (0.6403D * BaseApplication.screenWidth));
    return localView;
  }

  public ImageView getSuper_fat_img()
  {
    return this.super_fat_img;
  }

  public void initData(EntloseFatData paramEntloseFatData)
  {
    this.super_fat_title.setText(paramEntloseFatData.loseFatTitle);
    GlideUtils.loadImgByDefault(paramEntloseFatData.loseFatImg, 2130903536, this.super_fat_img);
    if ("2".equals(paramEntloseFatData.joinState))
    {
      if ("1".equals(paramEntloseFatData.isFirstTime))
        this.super_fat_join_layout.setVisibility(8);
      while (true)
      {
        this.super_fat_img.setOnClickListener(new FitAction(null, paramEntloseFatData)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            Intent localIntent;
            if (("1".equals(this.val$entloseFatData.isFirstTime)) && ("0".equals(this.val$entloseFatData.campType)))
            {
              localIntent = new Intent(SuperFatView.this.getContext(), FatCampWelcomeActivity.class);
              localIntent.putExtra("WELCOME_INTRODUCE", this.val$entloseFatData.firstInComment);
            }
            while (true)
            {
              if ("1".equals(this.val$entloseFatData.isFirstTime))
                FitCacheStoreUtils.setApiCacheInvalid("/SFitWeb/sfit/getTrainTab");
              localIntent.putExtra("lose.fat.id", this.val$entloseFatData.loseFatId);
              SuperFatView.this.getContext().startActivity(localIntent);
              AnimationUtil.pageJumpAnim((Activity)SuperFatView.this.getContext(), 0);
              super.onClick(paramView);
              return;
              localIntent = new Intent(SuperFatView.this.getContext(), FatCampDetailActivity.class);
            }
          }
        });
        return;
        this.super_fat_join_layout.setVisibility(0);
        this.super_fat_class_name.setText(paramEntloseFatData.loseFatComment);
        if ((paramEntloseFatData.lstPlan != null) && (paramEntloseFatData.lstPlan.size() > 0))
        {
          int i = 0;
          this.finish_pro.setVisibility(0);
          this.train_num_layout.setVisibility(0);
          this.train_num_layout.removeAllViews();
          int j = 0;
          if (j < paramEntloseFatData.lstPlan.size())
          {
            View localView = LayoutInflater.from(getContext()).inflate(2130968705, null);
            ImageView localImageView = (ImageView)localView.findViewById(2131755659);
            if ("1".equals(((EntloseFatItemModel)paramEntloseFatData.lstPlan.get(j)).isFinish))
            {
              i++;
              localImageView.setImageResource(2130903338);
            }
            while (true)
            {
              ((TextView)localView.findViewById(2131755660)).setText(((EntloseFatItemModel)paramEntloseFatData.lstPlan.get(j)).planName);
              this.train_num_layout.addView(localView);
              j++;
              break;
              localImageView.setImageResource(2130903481);
            }
          }
          int k;
          label274: int m;
          label298: String str;
          SpannableStringBuilder localSpannableStringBuilder;
          int n;
          label392: Context localContext3;
          if (i == paramEntloseFatData.lstPlan.size())
          {
            k = 1;
            RTextViewHelper localRTextViewHelper = this.finish_pro.getHelper();
            Context localContext1 = getContext();
            if (k != 0)
              break label515;
            m = 2131624328;
            localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(localContext1, m));
            str = "今日完成\n" + i + "/" + paramEntloseFatData.lstPlan.size();
            this.finish_pro.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
            localSpannableStringBuilder = new SpannableStringBuilder(str);
            Context localContext2 = getContext();
            if (k != 0)
              break label523;
            n = 2131624010;
            localSpannableStringBuilder.setSpan(new ForegroundColorSpan(ContextCompat.getColor(localContext2, n)), 0, 4, 33);
            localContext3 = getContext();
            if (k != 0)
              break label530;
          }
          label515: label523: label530: for (int i1 = 2131624118; ; i1 = 2131624328)
          {
            localSpannableStringBuilder.setSpan(new ForegroundColorSpan(ContextCompat.getColor(localContext3, i1)), 5, str.length(), 33);
            localSpannableStringBuilder.setSpan(new StyleSpan(1), 5, str.length(), 33);
            localSpannableStringBuilder.setSpan(new RelativeSizeSpan(2.0F), 5, 6, 33);
            this.finish_pro.setText(localSpannableStringBuilder);
            break;
            k = 0;
            break label274;
            m = 2131623984;
            break label298;
            n = 2131624328;
            break label392;
          }
        }
        this.finish_pro.setVisibility(4);
        this.train_num_layout.setVisibility(4);
      }
    }
    this.super_fat_join_layout.setVisibility(8);
    this.super_fat_img.setOnClickListener(new View.OnClickListener(paramEntloseFatData)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        String str;
        if (("0".equals(this.val$entloseFatData.isFillInfo)) && ("1".equals(this.val$entloseFatData.joinState)))
        {
          str = this.val$entloseFatData.fillInfoUrl;
          FitCacheStoreUtils.setApiCacheInvalid("/SFitWeb/sfit/getTrainTab");
        }
        while (true)
        {
          Intent localIntent = new Intent(SuperFatView.this.getContext(), Mine03WebUrlActivity.class);
          localIntent.putExtra("webUrl", str);
          SuperFatView.this.getContext().startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)SuperFatView.this.getContext(), 0);
          return;
          str = this.val$entloseFatData.linkUrl;
        }
      }
    });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.SuperFatView
 * JD-Core Version:    0.6.0
 */