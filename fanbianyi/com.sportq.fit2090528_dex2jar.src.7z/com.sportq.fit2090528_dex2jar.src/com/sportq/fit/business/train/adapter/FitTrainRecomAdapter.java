package com.sportq.fit.business.train.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.train.activity.Train22RecommendActivity;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.reformer.RecommendReformer;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.widget.PlanTrainUnJoinView;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView;
import com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.Iterator;

public class FitTrainRecomAdapter extends BaseAdapter
{
  private Context context;
  private ArrayList<PlanModel> dataList;
  private LayoutInflater inflater;
  private int itemCount;
  private String pageFromFlag;
  private ArrayList<PlanModel> planList;

  public FitTrainRecomAdapter(Context paramContext, int paramInt, String paramString1, String paramString2, RecommendReformer paramRecommendReformer)
  {
    this.context = paramContext;
    this.pageFromFlag = paramString1;
    this.dataList = new ArrayList();
    this.itemCount = paramInt;
    this.inflater = LayoutInflater.from(this.context);
    Iterator localIterator1 = paramRecommendReformer._individualArray.iterator();
    while (localIterator1.hasNext())
    {
      PlanModel localPlanModel2 = (PlanModel)localIterator1.next();
      FitAction.temporaryPCB("p.c.rec|!||!||!|", "0|!|" + localPlanModel2.planId);
    }
    Iterator localIterator2 = paramRecommendReformer._planArray.iterator();
    while (localIterator2.hasNext())
    {
      PlanModel localPlanModel1 = (PlanModel)localIterator2.next();
      FitAction.temporaryPCB("p.c.rec|!||!||!|", "1|!|" + localPlanModel1.planId);
    }
  }

  private void initControl(View paramView, ViewHolder paramViewHolder)
  {
    ViewHolder.access$202(paramViewHolder, paramView.findViewById(2131755526));
    ViewHolder.access$102(paramViewHolder, (TextView)paramView.findViewById(2131756068));
    ViewHolder.access$302(paramViewHolder, (PlanTrainUnJoinView)paramView.findViewById(2131755248));
    ViewHolder.access$402(paramViewHolder, (SinglePlanTrainView)paramView.findViewById(2131756069));
    ViewHolder.access$802(paramViewHolder, paramView.findViewById(2131755573));
    ViewHolder.access$702(paramViewHolder, paramView.findViewById(2131756070));
  }

  private void setDateForPage(int paramInt, ViewHolder paramViewHolder)
  {
    int i = this.planList.size();
    View localView;
    if (paramInt < i)
      if (paramInt == 0)
      {
        paramViewHolder.course_title.setVisibility(0);
        paramViewHolder.course_title.setText("多节课程");
        paramViewHolder.split_line.setVisibility(8);
        PlanModel localPlanModel2 = (PlanModel)this.planList.get(paramInt);
        paramViewHolder.course_info.setVisibility(0);
        paramViewHolder.single_course_info.setVisibility(4);
        paramViewHolder.course_info.initView(localPlanModel2);
        paramViewHolder.course_info.setOnClickListener(new FitAction((Train22RecommendActivity)this.context, localPlanModel2, paramInt)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            String str1 = SharePreferenceUtils.getLoginStatus(FitTrainRecomAdapter.this.context);
            if ((StringUtils.isNull(this.val$planModel.planStateCode)) || ((("0".equals(this.val$planModel.planStateCode)) || ("2".equals(this.val$planModel.planStateCode))) && ("login".equals(str1))))
            {
              Intent localIntent1 = new Intent(FitTrainRecomAdapter.this.context, Find03GenTrainListActivity.class);
              localIntent1.putExtra("plan.id", this.val$planModel.planId);
              localIntent1.putExtra("position", String.valueOf(this.val$position));
              localIntent1.putExtra("plan.stateCode", this.val$planModel.planStateCode);
              FitTrainRecomAdapter.this.context.startActivity(localIntent1);
              AnimationUtil.pageJumpAnim((Activity)FitTrainRecomAdapter.this.context, 0);
              if (!FitTrainRecomAdapter.this.pageFromFlag.equals("recommd.foryou"))
                break label288;
            }
            label288: for (String str2 = StringUtils.getStringResources(2131299266); ; str2 = StringUtils.getStringResources(2131299261))
            {
              paramView.setTag(StringUtils.stitchingUserEvent(str2, this.val$planModel.olapInfo));
              super.onClick(paramView);
              return;
              Intent localIntent2 = new Intent(FitTrainRecomAdapter.this.context, Find04GenTrainInfoActivity.class);
              localIntent2.putExtra("plan.id", this.val$planModel.planId);
              localIntent2.putExtra("position", String.valueOf(this.val$position));
              localIntent2.putExtra("plan.stateCode", this.val$planModel.planStateCode);
              FitTrainRecomAdapter.this.context.startActivity(localIntent2);
              AnimationUtil.pageJumpAnim((Activity)FitTrainRecomAdapter.this.context, 0);
              break;
            }
          }
        });
        if ((this.planList.size() <= 0) || (paramInt >= this.planList.size()))
          break label294;
        paramViewHolder.single_space_view.setVisibility(8);
        localView = paramViewHolder.space_view;
        if (paramInt + 1 == this.planList.size())
          break label287;
      }
    label287: for (int j = 0; ; j = 8)
    {
      localView.setVisibility(j);
      return;
      paramViewHolder.course_title.setVisibility(8);
      break;
      if (paramInt == i)
      {
        paramViewHolder.course_title.setVisibility(0);
        paramViewHolder.course_title.setText("单节课程");
      }
      while (true)
      {
        paramViewHolder.split_line.setVisibility(0);
        paramViewHolder.course_info.setVisibility(8);
        paramViewHolder.single_course_info.setVisibility(0);
        PlanModel localPlanModel1 = (PlanModel)this.dataList.get(paramInt - i);
        paramViewHolder.single_course_info.initView(localPlanModel1, 0);
        paramViewHolder.single_course_info.setCourseStyleBold();
        singleTrainClickAction(paramViewHolder.single_course_info, localPlanModel1, localPlanModel1.planId);
        break;
        paramViewHolder.course_title.setVisibility(8);
      }
    }
    label294: paramViewHolder.space_view.setVisibility(8);
    paramViewHolder.single_space_view.setVisibility(0);
  }

  private void singleTrainClickAction(SinglePlanTrainView paramSinglePlanTrainView, PlanModel paramPlanModel, String paramString)
  {
    paramSinglePlanTrainView.setOnClickListener(new FitAction(null, paramPlanModel, paramString)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (FitTrainRecomAdapter.this.pageFromFlag.equals("recommd.foryou"));
        for (String str = StringUtils.getStringResources(2131299266); ; str = StringUtils.getStringResources(2131299261))
        {
          paramView.setTag(StringUtils.stitchingUserEvent(str, this.val$planModel.olapInfo));
          Intent localIntent = new Intent(FitTrainRecomAdapter.this.context, Find04GenTrainInfoActivity.class);
          localIntent.putExtra("single.type", "0");
          localIntent.putExtra("plan.id", this.val$strPlanId);
          FitTrainRecomAdapter.this.context.startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)FitTrainRecomAdapter.this.context, 0);
          super.onClick(paramView);
          return;
        }
      }
    });
  }

  public int getCount()
  {
    return this.itemCount;
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    if (paramView == null)
    {
      localViewHolder = new ViewHolder(null);
      paramView = this.inflater.inflate(2130969035, null);
      initControl(paramView, localViewHolder);
      paramView.setTag(localViewHolder);
    }
    try
    {
      while (true)
      {
        setDateForPage(paramInt, localViewHolder);
        return paramView;
        localViewHolder = (ViewHolder)paramView.getTag();
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return paramView;
  }

  public void setDataList(ArrayList<PlanModel> paramArrayList)
  {
    this.dataList = paramArrayList;
  }

  public void setPlanList(ArrayList<PlanModel> paramArrayList)
  {
    this.planList = paramArrayList;
    ArrayList localArrayList;
    if (this.planList == null)
    {
      localArrayList = new ArrayList();
      this.planList = localArrayList;
    }
    while (true)
    {
      this.planList = localArrayList;
      return;
      localArrayList = this.planList;
    }
  }

  private static class ViewHolder
  {
    private PlanTrainUnJoinView course_info;
    private TextView course_title;
    private SinglePlanTrainView single_course_info;
    private View single_space_view;
    private View space_view;
    private View split_line;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.adapter.FitTrainRecomAdapter
 * JD-Core Version:    0.6.0
 */