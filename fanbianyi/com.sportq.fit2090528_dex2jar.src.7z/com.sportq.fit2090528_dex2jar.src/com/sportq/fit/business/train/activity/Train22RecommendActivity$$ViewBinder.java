package com.sportq.fit.business.train.activity;

import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class Train22RecommendActivity$$ViewBinder<T extends Train22RecommendActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.train22RecyclerView = ((ListView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757591, "field 'train22RecyclerView'"), 2131757591, "field 'train22RecyclerView'"));
    paramT.goal = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757584, "field 'goal'"), 2131757584, "field 'goal'"));
    paramT.basics = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757586, "field 'basics'"), 2131757586, "field 'basics'"));
    paramT.recom_change = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757587, "field 'recom_change'"), 2131757587, "field 'recom_change'"));
    paramT.ad_recommend_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757588, "field 'ad_recommend_layout'"), 2131757588, "field 'ad_recommend_layout'"));
    paramT.ad_recommend_img = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757589, "field 'ad_recommend_img'"), 2131757589, "field 'ad_recommend_img'"));
    paramT.ad_recommend_close_btn = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757590, "field 'ad_recommend_close_btn'"), 2131757590, "field 'ad_recommend_close_btn'"));
  }

  public void unbind(T paramT)
  {
    paramT.toolbar = null;
    paramT.train22RecyclerView = null;
    paramT.goal = null;
    paramT.basics = null;
    paramT.recom_change = null;
    paramT.ad_recommend_layout = null;
    paramT.ad_recommend_img = null;
    paramT.ad_recommend_close_btn = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.activity.Train22RecommendActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */