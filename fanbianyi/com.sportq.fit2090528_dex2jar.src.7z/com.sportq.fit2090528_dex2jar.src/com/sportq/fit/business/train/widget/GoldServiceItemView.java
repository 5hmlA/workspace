package com.sportq.fit.business.train.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.BaseNavView;
import com.sportq.fit.business.mine.activity.Mine03WebUrlActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.GoldServiceModel;
import com.sportq.fit.common.model.TrainJoinUserModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.widget.FitVipUserView;
import com.sportq.fit.fitmoudle7.customize.activity.CustomStartActivity;
import java.util.ArrayList;

public class GoldServiceItemView extends BaseNavView
{
  private GoldServiceModel goldServiceModel;
  ImageView gold_service_item_img;
  private int imgHeight = 0;
  private int imgWidth = 0;
  LinearLayout join_layout;
  ImageView small_icon;

  public GoldServiceItemView(Context paramContext)
  {
    super(paramContext);
  }

  public GoldServiceItemView(Context paramContext, GoldServiceModel paramGoldServiceModel)
  {
    super(paramContext);
    this.imgWidth = (int)(0.9D * BaseApplication.screenWidth);
    this.imgHeight = (int)(0.642D * (0.9D * BaseApplication.screenWidth));
    this.goldServiceModel = paramGoldServiceModel;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), 2130968884, null);
    this.gold_service_item_img = ((ImageView)localView.findViewById(2131756307));
    this.small_icon = ((ImageView)localView.findViewById(2131756308));
    this.join_layout = ((LinearLayout)localView.findViewById(2131756309));
    this.gold_service_item_img.getLayoutParams().width = this.imgWidth;
    this.gold_service_item_img.getLayoutParams().height = this.imgHeight;
    GlideUtils.loadImgByRadius(this.goldServiceModel.imgUrl, 2130903536, 8.0F, this.gold_service_item_img);
    int i;
    if ((this.goldServiceModel.lstJoinUser == null) || (this.goldServiceModel.lstJoinUser.size() == 0))
    {
      this.join_layout.setVisibility(8);
      if (!"0".equals(this.goldServiceModel.serviceType))
        break label476;
      this.small_icon.setVisibility(0);
      if (!"0".equals(BaseApplication.userModel.isVip))
        break label464;
      ImageView localImageView = this.small_icon;
      if ((!"1".equals(BaseApplication.giftShowFlag)) || (!"0".equals(BaseApplication.userModel.hasTryVip)))
        break label458;
      i = 2130903359;
      label198: localImageView.setImageResource(i);
    }
    while (true)
    {
      setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          GoldServiceModel localGoldServiceModel = GoldServiceItemView.this.goldServiceModel;
          Intent localIntent;
          if ("0".equals(localGoldServiceModel.serviceType))
          {
            localIntent = new Intent(GoldServiceItemView.this.getContext(), CustomStartActivity.class);
            localIntent.putExtra("custom_hascusflag", localGoldServiceModel.hasCusFlag);
            localIntent.putExtra("custom_hasHistoryFlag", localGoldServiceModel.hasHistoryFlag);
          }
          while (true)
          {
            GoldServiceItemView.this.getContext().startActivity(localIntent);
            AnimationUtil.pageJumpAnim((Activity)GoldServiceItemView.this.getContext(), 0);
            return;
            localIntent = new Intent(GoldServiceItemView.this.getContext(), Mine03WebUrlActivity.class);
            localIntent.putExtra("webUrl", localGoldServiceModel.linkUrl);
          }
        }
      });
      return localView;
      this.join_layout.setVisibility(0);
      this.join_layout.removeAllViews();
      for (int j = 0; j < this.goldServiceModel.lstJoinUser.size(); j++)
      {
        FitVipUserView localFitVipUserView = new FitVipUserView(getContext());
        localFitVipUserView.loadUserIcon(((TrainJoinUserModel)this.goldServiceModel.lstJoinUser.get(j)).userImg);
        localFitVipUserView.setIsVip(0);
        LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(CompDeviceInfoUtils.convertOfDip(getContext(), 24.0F), CompDeviceInfoUtils.convertOfDip(getContext(), 24.0F));
        if (j != 0)
          localLayoutParams1.leftMargin = (-CompDeviceInfoUtils.convertOfDip(getContext(), 5.0F));
        localLayoutParams1.gravity = 16;
        this.join_layout.addView(localFitVipUserView, localLayoutParams1);
      }
      TextView localTextView = new TextView(getContext());
      localTextView.setTextColor(ContextCompat.getColor(getContext(), 2131624328));
      localTextView.setTextSize(12.0F);
      localTextView.setText(this.goldServiceModel.numberOfParticipants);
      LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-2, -2);
      localLayoutParams2.leftMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 10.0F);
      localLayoutParams2.gravity = 16;
      this.join_layout.addView(localTextView, localLayoutParams2);
      break;
      label458: i = 2130903723;
      break label198;
      label464: this.small_icon.setImageResource(2130903723);
      continue;
      label476: this.small_icon.setVisibility(8);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.GoldServiceItemView
 * JD-Core Version:    0.6.0
 */