package com.sportq.fit.business.train.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.RelativeLayout;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.FitApplication;

public class CoverRecyclerViewAdapter extends RecyclerView.Adapter
{
  private CoverViewOnClickListener listener;
  private Context mContext;
  private RelativeLayout nothingCover;

  public CoverRecyclerViewAdapter(Context paramContext, CoverViewOnClickListener paramCoverViewOnClickListener)
  {
    this.mContext = paramContext;
    this.listener = paramCoverViewOnClickListener;
  }

  public int getItemCount()
  {
    return 1;
  }

  public void onBindViewHolder(RecyclerView.ViewHolder paramViewHolder, int paramInt)
  {
    this.nothingCover = ((NothingViewHolder)paramViewHolder).nothingCover;
    ViewGroup.LayoutParams localLayoutParams = this.nothingCover.getLayoutParams();
    localLayoutParams.width = FitApplication.screenWidth;
    localLayoutParams.height = FitApplication.screenHeight;
    this.nothingCover.setLayoutParams(localLayoutParams);
    this.nothingCover.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (CoverRecyclerViewAdapter.this.listener != null)
          CoverRecyclerViewAdapter.this.listener.coverViewOnClick();
      }
    });
  }

  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt)
  {
    return new NothingViewHolder(LayoutInflater.from(this.mContext).inflate(2130969041, null));
  }

  public void setCoverAlpha(float paramFloat)
  {
    if (this.nothingCover != null)
      this.nothingCover.setAlpha(paramFloat);
  }

  public static abstract interface CoverViewOnClickListener
  {
    public abstract void coverViewOnClick();
  }

  static class NothingViewHolder extends RecyclerView.ViewHolder
  {

    @Bind({2131757050})
    RelativeLayout nothingCover;

    NothingViewHolder(View paramView)
    {
      super();
      ButterKnife.bind(this, paramView);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.adapter.CoverRecyclerViewAdapter
 * JD-Core Version:    0.6.0
 */