package com.sportq.fit.business.train.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.task.activity.Task01NewChallengesListActivity;
import com.sportq.fit.fitmoudle.task.activity.Task02ChallengeDetailsActivity;
import com.sportq.fit.fitmoudle.task.reformer.model.ChallengesModel;
import com.sportq.fit.fitmoudle.task.widget.TaskListItemView;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.user_behavior.UserBehaviorImpl;

public class MineChallengesView extends FrameLayout
{
  private TextView fit_custom_all;
  private TextView fit_custom_title;
  private TaskListItemView taskListItemView;
  private FrameLayout title_layout;

  public MineChallengesView(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public MineChallengesView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public MineChallengesView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), 2130968999, null);
    this.title_layout = ((FrameLayout)localView.findViewById(2131755295));
    this.fit_custom_title = ((TextView)localView.findViewById(2131756154));
    this.fit_custom_all = ((TextView)localView.findViewById(2131756155));
    this.taskListItemView = ((TaskListItemView)localView.findViewById(2131756823));
    return localView;
  }

  public void initData(ChallengesModel paramChallengesModel, String paramString)
  {
    if (StringUtils.isNull(paramString))
      this.title_layout.setVisibility(8);
    while (true)
    {
      this.taskListItemView.setFitView(paramChallengesModel);
      this.taskListItemView.setOnClickListener(new FitAction(null, paramChallengesModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          new UserBehaviorImpl().trainTabMineTaskClick(this.val$challengesModel.olapInfo);
          Intent localIntent = new Intent(MineChallengesView.this.getContext(), Task02ChallengeDetailsActivity.class);
          localIntent.putExtra("missionId", this.val$challengesModel.missionId);
          localIntent.putExtra("missionName", this.val$challengesModel.missionName);
          MineChallengesView.this.getContext().startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)MineChallengesView.this.getContext(), 0);
          super.onClick(paramView);
        }
      });
      return;
      this.title_layout.setVisibility(0);
      this.title_layout.setBackgroundResource(2131624328);
      this.fit_custom_title.setText(getContext().getString(2131296428));
      this.fit_custom_all.setOnClickListener(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          new UserBehaviorImpl().allTaskClick();
          MineChallengesView.this.getContext().startActivity(new Intent(MineChallengesView.this.getContext(), Task01NewChallengesListActivity.class));
          AnimationUtil.pageJumpAnim((Activity)MineChallengesView.this.getContext(), 0);
          super.onClick(paramView);
        }
      });
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.MineChallengesView
 * JD-Core Version:    0.6.0
 */