package com.sportq.fit.business.train.widget;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.MainToastEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import org.greenrobot.eventbus.EventBus;

public class RecommendCourseDialog
  implements FitInterfaceUtils.UIInitListener
{
  private Dialog guideDialog;
  private RecommendClickListener listener;
  private Context mContext;
  private String strPlanId;
  private String strStoreFlg = "";
  private String strType;

  public RecommendCourseDialog(Context paramContext)
  {
    this.mContext = paramContext;
  }

  public RecommendCourseDialog(RecommendClickListener paramRecommendClickListener, Context paramContext)
  {
    this.mContext = paramContext;
    this.listener = paramRecommendClickListener;
  }

  public void createDialog(PlanRecommendReformer paramPlanRecommendReformer)
  {
    if (paramPlanRecommendReformer == null);
    PlanModel localPlanModel;
    do
    {
      return;
      localPlanModel = paramPlanRecommendReformer._recomPlan;
    }
    while (localPlanModel == null);
    String str = localPlanModel.planImageURL;
    this.guideDialog = DialogManager.guide_Dialog(this.mContext, 2130969087, 1);
    ImageView localImageView = (ImageView)this.guideDialog.findViewById(2131757176);
    RelativeLayout localRelativeLayout = (RelativeLayout)this.guideDialog.findViewById(2131757185);
    this.guideDialog.findViewById(2131757182).setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        RecommendCourseDialog.this.guideDialog.dismiss();
      }
    });
    ((TextView)this.guideDialog.findViewById(2131757177)).setText(localPlanModel.planName);
    ((TextView)this.guideDialog.findViewById(2131757179)).setText(localPlanModel.trainDuration);
    ((TextView)this.guideDialog.findViewById(2131757180)).setText(localPlanModel.planKaluri);
    ((TextView)this.guideDialog.findViewById(2131757181)).setText(localPlanModel.planDifficultyLevel);
    ((TextView)this.guideDialog.findViewById(2131757184)).setText(paramPlanRecommendReformer._popTitle);
    this.guideDialog.setCanceledOnTouchOutside(false);
    this.guideDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
    {
      public void onDismiss(DialogInterface paramDialogInterface)
      {
        EventBus.getDefault().post(new MainToastEvent(3));
      }
    });
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams((int)(0.903D * BaseApplication.screenWidth), (int)(0.755D * BaseApplication.screenHeight));
    this.guideDialog.findViewById(2131756313).setLayoutParams(localLayoutParams);
    GlideUtils.loadImgByDefault(str, 2130903536, localImageView);
    Dialog localDialog = this.guideDialog;
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
    localRelativeLayout.setOnClickListener(new View.OnClickListener(localPlanModel)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (RecommendCourseDialog.this.listener != null)
          RecommendCourseDialog.this.listener.clickAction("1", this.val$planModel.olapInfo);
        Intent localIntent = new Intent(RecommendCourseDialog.this.mContext, Find04GenTrainInfoActivity.class);
        localIntent.putExtra("single.type", "0");
        localIntent.putExtra("plan.id", this.val$planModel.planId);
        RecommendCourseDialog.this.mContext.startActivity(localIntent);
        RecommendCourseDialog.this.guideDialog.dismiss();
      }
    });
  }

  public void fitOnClick(View paramView)
  {
  }

  public <T> void getDataFail(T paramT)
  {
    ToastUtils.makeToast(this.mContext, "收藏失败，请稍后尝试");
  }

  public <T> void getDataSuccess(T paramT)
  {
    Context localContext;
    if (((paramT instanceof PlanReformer)) && ("3".equals(((PlanReformer)paramT).tag)))
    {
      localContext = this.mContext;
      if (!"1".equals(this.strStoreFlg))
        break label62;
    }
    label62: for (String str = "收藏成功"; ; str = "取消收藏成功")
    {
      ToastUtils.makeToast(localContext, str);
      if (this.guideDialog != null)
        this.guideDialog.dismiss();
      return;
    }
  }

  public void initLayout(Bundle paramBundle)
  {
  }

  public <T> void onRefresh(T paramT)
  {
  }

  public static abstract interface RecommendClickListener
  {
    public abstract void clickAction(String paramString1, String paramString2);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.RecommendCourseDialog
 * JD-Core Version:    0.6.0
 */