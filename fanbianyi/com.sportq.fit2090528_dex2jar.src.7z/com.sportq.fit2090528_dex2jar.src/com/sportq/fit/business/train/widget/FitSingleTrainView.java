package com.sportq.fit.business.train.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import cn.iwgang.countdownview.CountdownView;
import cn.iwgang.countdownview.CountdownView.OnCountdownEndListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.CountDownFinishEvent;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle8.activity.AllCoursesActivity;
import org.greenrobot.eventbus.EventBus;

public class FitSingleTrainView extends FrameLayout
{
  private TextView download_hint;
  private CountdownView energy_course_countdown_view;
  private ImageView energy_course_lock;
  private ImageView energy_icn;
  private TextView fit_custom_all;
  private TextView fit_custom_title;
  private ImageView new_tag;
  private ImageView single_train_img;
  private TextView single_train_introduce;
  private ConstraintLayout single_train_item_layout;
  private View single_train_line;
  private TextView single_train_name;
  private FrameLayout title_layout;
  private RTextView train_times;

  public FitSingleTrainView(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public FitSingleTrainView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public FitSingleTrainView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), 2130968851, null);
    this.title_layout = ((FrameLayout)localView.findViewById(2131755295));
    this.single_train_item_layout = ((ConstraintLayout)localView.findViewById(2131756177));
    this.single_train_item_layout.setLayoutParams(new LinearLayout.LayoutParams(BaseApplication.screenWidth, -2));
    this.fit_custom_title = ((TextView)localView.findViewById(2131756154));
    this.fit_custom_all = ((TextView)localView.findViewById(2131756155));
    this.single_train_img = ((ImageView)localView.findViewById(2131757290));
    this.new_tag = ((ImageView)localView.findViewById(2131757295));
    this.single_train_name = ((TextView)localView.findViewById(2131757291));
    this.single_train_introduce = ((TextView)localView.findViewById(2131757293));
    this.train_times = ((RTextView)localView.findViewById(2131757294));
    this.download_hint = ((TextView)localView.findViewById(2131755811));
    this.energy_icn = ((ImageView)localView.findViewById(2131757292));
    this.energy_course_lock = ((ImageView)localView.findViewById(2131757296));
    this.energy_course_countdown_view = ((CountdownView)localView.findViewById(2131757297));
    this.single_train_line = localView.findViewById(2131756176);
    return localView;
  }

  public ConstraintLayout getSingle_train_item_layout()
  {
    return this.single_train_item_layout;
  }

  public void initView(PlanModel paramPlanModel, String paramString1, String paramString2)
  {
    int j;
    label168: ImageView localImageView2;
    int k;
    if (StringUtils.isNull(paramString1))
    {
      this.title_layout.setVisibility(8);
      this.single_train_line.setVisibility(8);
      GlideUtils.loadImgByDefault(QiniuManager.getImgUrl(paramPlanModel.planImageURL, CompDeviceInfoUtils.convertOfDip(getContext(), 90.0F)), 2130903536, this.single_train_img);
      this.single_train_name.setText(paramPlanModel.planName);
      this.single_train_introduce.setText(paramPlanModel.scheduleInfo);
      if (!"1".equals(paramString2))
        break label328;
      str1 = "已完成" + paramPlanModel.finishSection + "次";
      this.train_times.getHelper().setIconNormal(ContextCompat.getDrawable(getContext(), 2130903421));
      String str2 = SharePreferenceUtils.getDownLoadedSinglePlanId(getContext());
      TextView localTextView = this.download_hint;
      if ((StringUtils.isNull(str2)) || (!str2.contains(paramPlanModel.planId)))
        break label315;
      j = 0;
      localTextView.setVisibility(j);
      this.download_hint.setText("已下载");
      this.download_hint.setTextColor(ContextCompat.getColor(getContext(), 2131624044));
      this.download_hint.setBackgroundResource(2130837745);
      this.new_tag.setImageResource(2130903470);
      localImageView2 = this.new_tag;
      boolean bool2 = "1".equals(paramPlanModel.topFlag);
      k = 0;
      if (!bool2)
        break label321;
    }
    while (true)
    {
      localImageView2.setVisibility(k);
      this.train_times.setText(str1);
      return;
      this.single_train_line.setVisibility(0);
      this.title_layout.setVisibility(0);
      this.fit_custom_title.setText(paramString1);
      this.fit_custom_all.setText(StringUtils.getStringResources(2131296411));
      this.fit_custom_all.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          FitSingleTrainView.this.getContext().startActivity(new Intent(FitSingleTrainView.this.getContext(), AllCoursesActivity.class));
          AnimationUtil.pageJumpAnim((Activity)FitSingleTrainView.this.getContext(), 0);
        }
      });
      break;
      label315: j = 4;
      break label168;
      label321: k = 8;
    }
    label328: String str1 = paramPlanModel.planNumberOfParticipants.replace("已参加", "") + "已参加";
    this.train_times.getHelper().setIconNormal(null);
    this.download_hint.setVisibility(8);
    this.new_tag.setImageResource(2130903602);
    ImageView localImageView1 = this.new_tag;
    boolean bool1 = "1".equals(paramPlanModel.isNewTag);
    int i = 0;
    if (bool1);
    while (true)
    {
      localImageView1.setVisibility(i);
      break;
      i = 8;
    }
  }

  public void setCountDownTime(PlanModel paramPlanModel, CountdownView.OnCountdownEndListener paramOnCountdownEndListener)
  {
    try
    {
      if (!"1".equals(paramPlanModel.energyFlag))
        break label215;
      this.energy_icn.setVisibility(0);
      if (("1".equals(BaseApplication.userModel.isVip)) || ("1".equals(BaseApplication.userModel.isHasLosFat)))
      {
        this.energy_course_lock.setVisibility(4);
        this.energy_course_countdown_view.setVisibility(4);
        return;
      }
      if (StringUtils.isNull(paramPlanModel.restTime))
      {
        this.energy_course_lock.setVisibility(0);
        this.energy_course_countdown_view.setVisibility(4);
        return;
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      return;
    }
    this.energy_course_lock.setVisibility(4);
    this.energy_course_countdown_view.setVisibility(0);
    long l1 = SystemClock.elapsedRealtime();
    long l2 = Long.valueOf(paramPlanModel.restTime).longValue() - l1;
    this.energy_course_countdown_view.setTag(paramPlanModel.planId);
    if (paramOnCountdownEndListener != null)
      this.energy_course_countdown_view.setOnCountdownEndListener(paramOnCountdownEndListener);
    if (l2 > 0L)
    {
      this.energy_course_countdown_view.start(l2);
      return;
    }
    this.energy_course_countdown_view.stop();
    EventBus.getDefault().post(new CountDownFinishEvent(paramPlanModel.planId));
    this.energy_course_lock.setVisibility(0);
    this.energy_course_countdown_view.setVisibility(4);
    return;
    label215: this.energy_course_lock.setVisibility(4);
    this.energy_icn.setVisibility(4);
    this.energy_course_countdown_view.setVisibility(4);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.FitSingleTrainView
 * JD-Core Version:    0.6.0
 */