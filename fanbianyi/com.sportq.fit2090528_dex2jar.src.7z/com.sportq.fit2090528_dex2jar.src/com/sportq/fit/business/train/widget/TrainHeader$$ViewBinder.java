package com.sportq.fit.business.train.widget;

import android.view.View;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;

public class TrainHeader$$ViewBinder<T extends TrainHeader>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.train_head_progressBar = ((TrainHeadProgressBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757627, "field 'train_head_progressBar'"), 2131757627, "field 'train_head_progressBar'"));
    paramT.next_text = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757628, "field 'next_text'"), 2131757628, "field 'next_text'"));
  }

  public void unbind(T paramT)
  {
    paramT.train_head_progressBar = null;
    paramT.next_text = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.TrainHeader..ViewBinder
 * JD-Core Version:    0.6.0
 */