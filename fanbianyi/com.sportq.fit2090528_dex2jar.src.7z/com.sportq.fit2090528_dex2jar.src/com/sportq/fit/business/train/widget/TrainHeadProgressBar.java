package com.sportq.fit.business.train.widget;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.TrainHeadAnimEvent;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import org.greenrobot.eventbus.EventBus;

public class TrainHeadProgressBar extends View
{
  private Paint allArcPaint;
  private int aniSpeed = 1200;
  private int bgArcWidth = CompDeviceInfoUtils.dipToPx(8.0F);
  private RectF bgRect;
  private String centerValue;
  private int centerX;
  private int centerY;
  private boolean close_flg = false;
  private Paint curSpeedPaint;
  private float curSpeedSize = CompDeviceInfoUtils.spTopx(10.0F);
  private float curValues = 0.0F;
  private float currentAngle = 0.0F;
  private int diameter;
  private Paint hintPaint;
  private float hintSize = CompDeviceInfoUtils.spTopx(10.0F);
  private String hintStr = "分钟";
  private float lastAngle;
  private int levelColor = 2131624121;
  private Paint levelPaint;
  private float levelSize = CompDeviceInfoUtils.spTopx(12.0F);
  private String levelStr = "无等级";
  private PaintFlagsDrawFilter mDrawFilter;
  private int maxNumberStr = 100;
  private int nowNumberStr = 0;
  private float percent;
  private ValueAnimator progressAnimator;
  private Paint progressPaint;
  private float progressWidth = CompDeviceInfoUtils.dipToPx(8.0F);
  private Rect rect = new Rect();
  private int showNumberStr = 0;
  private int startAngle = 113;
  private int sweepAngle = 314;
  private int textSize = CompDeviceInfoUtils.spTopx(45.0F);
  private String titleStr = "总共训练";
  private TrainHeadAnimEvent trainHeadAnimEvent;
  private Paint vTextPaint;
  int valueHeight = 0;

  public TrainHeadProgressBar(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    initView();
  }

  private void initView()
  {
    this.diameter = CompDeviceInfoUtils.dipToPx(160.0F);
    this.bgRect = new RectF();
    this.bgRect.top = CompDeviceInfoUtils.dipToPx(8.0F);
    this.bgRect.left = CompDeviceInfoUtils.dipToPx(8.0F);
    this.bgRect.right = (this.diameter - CompDeviceInfoUtils.dipToPx(8.0F));
    this.bgRect.bottom = (this.diameter - CompDeviceInfoUtils.dipToPx(8.0F));
    this.centerX = (this.diameter / 2);
    this.centerY = (this.diameter / 2);
    this.allArcPaint = new Paint();
    this.allArcPaint.setAntiAlias(true);
    this.allArcPaint.setStyle(Paint.Style.STROKE);
    this.allArcPaint.setStrokeWidth(this.bgArcWidth);
    this.allArcPaint.setColor(getContext().getResources().getColor(2131624105));
    this.allArcPaint.setStrokeCap(Paint.Cap.ROUND);
    this.progressPaint = new Paint();
    this.progressPaint.setAntiAlias(true);
    this.progressPaint.setStyle(Paint.Style.STROKE);
    this.progressPaint.setStrokeCap(Paint.Cap.ROUND);
    this.progressPaint.setStrokeWidth(this.progressWidth);
    this.progressPaint.setColor(getContext().getResources().getColor(2131624121));
    this.vTextPaint = new Paint();
    this.vTextPaint.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.vTextPaint.setTextSize(this.textSize);
    this.vTextPaint.setColor(getContext().getResources().getColor(2131624003));
    this.vTextPaint.setTextAlign(Paint.Align.CENTER);
    this.hintPaint = new Paint();
    this.hintPaint.setTextSize(this.hintSize);
    this.hintPaint.setColor(getContext().getResources().getColor(2131624044));
    this.hintPaint.setTextAlign(Paint.Align.CENTER);
    this.curSpeedPaint = new Paint();
    this.curSpeedPaint.setTextSize(this.curSpeedSize);
    this.curSpeedPaint.setColor(getContext().getResources().getColor(2131624044));
    this.curSpeedPaint.setTextAlign(Paint.Align.CENTER);
    this.levelPaint = new Paint();
    this.levelPaint.setTextSize(this.levelSize);
    this.levelPaint.setFakeBoldText(true);
    this.levelPaint.setTextAlign(Paint.Align.CENTER);
    this.levelPaint.setColor(getContext().getResources().getColor(this.levelColor));
    this.mDrawFilter = new PaintFlagsDrawFilter(0, 3);
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Float.valueOf(this.curValues);
    this.centerValue = String.format("%.0f", arrayOfObject);
    if (this.centerValue.length() < 5)
    {
      this.vTextPaint.setTextSize(CompDeviceInfoUtils.spTopx(45.0F));
      this.textSize = CompDeviceInfoUtils.spTopx(45.0F);
      return;
    }
    if (this.centerValue.length() < 6)
    {
      this.vTextPaint.setTextSize(CompDeviceInfoUtils.spTopx(40.0F));
      this.textSize = CompDeviceInfoUtils.spTopx(40.0F);
      return;
    }
    this.vTextPaint.setTextSize(CompDeviceInfoUtils.spTopx(35.0F));
    this.textSize = CompDeviceInfoUtils.spTopx(35.0F);
  }

  private void setAnimation(float paramFloat1, float paramFloat2, int paramInt)
  {
    this.progressAnimator = ValueAnimator.ofFloat(new float[] { paramFloat1, paramFloat2 });
    this.progressAnimator.setDuration(paramInt);
    this.progressAnimator.setTarget(Float.valueOf(this.currentAngle));
    this.progressAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener()
    {
      public void onAnimationUpdate(ValueAnimator paramValueAnimator)
      {
        TrainHeadProgressBar.access$002(TrainHeadProgressBar.this, ((Float)paramValueAnimator.getAnimatedValue()).floatValue());
        if (TrainHeadProgressBar.this.nowNumberStr > 0);
        for (int i = TrainHeadProgressBar.this.nowNumberStr; ; i = 1)
        {
          TrainHeadProgressBar.access$202(TrainHeadProgressBar.this, TrainHeadProgressBar.this.showNumberStr * (TrainHeadProgressBar.this.currentAngle / TrainHeadProgressBar.this.percent) / i);
          TrainHeadProgressBar localTrainHeadProgressBar = TrainHeadProgressBar.this;
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = Float.valueOf(TrainHeadProgressBar.access$200(TrainHeadProgressBar.this));
          TrainHeadProgressBar.access$502(localTrainHeadProgressBar, String.format("%.0f", arrayOfObject));
          return;
        }
      }
    });
    this.progressAnimator.start();
  }

  protected void onDraw(Canvas paramCanvas)
  {
    paramCanvas.setDrawFilter(this.mDrawFilter);
    paramCanvas.drawArc(this.bgRect, this.startAngle, this.sweepAngle, false, this.allArcPaint);
    paramCanvas.drawArc(this.bgRect, this.startAngle, this.currentAngle, false, this.progressPaint);
    paramCanvas.drawArc(this.bgRect, this.startAngle, 1.0F, false, this.progressPaint);
    if ((Integer.valueOf(this.centerValue).intValue() == this.showNumberStr) && (this.close_flg))
      EventBus.getDefault().post(this.trainHeadAnimEvent);
    this.vTextPaint.getTextBounds(this.centerValue, 0, this.centerValue.length(), this.rect);
    this.valueHeight = this.rect.height();
    paramCanvas.drawText(this.centerValue, this.centerX, this.centerY + this.valueHeight / 2, this.vTextPaint);
    this.curSpeedPaint.getTextBounds(this.titleStr, 0, this.titleStr.length(), this.rect);
    paramCanvas.drawText(this.titleStr, this.centerX, this.centerY - CompDeviceInfoUtils.dipToPx(31.0F), this.curSpeedPaint);
    this.hintPaint.getTextBounds(this.hintStr, 0, this.hintStr.length(), this.rect);
    paramCanvas.drawText(this.hintStr, this.centerX, this.centerY + CompDeviceInfoUtils.dipToPx(39.0F), this.hintPaint);
    paramCanvas.drawText(this.levelStr, this.centerX, 2 * this.centerY - CompDeviceInfoUtils.dipToPx(8.0F), this.levelPaint);
    if ((Integer.valueOf(this.centerValue).intValue() != this.showNumberStr) || (!this.close_flg))
      invalidate();
  }

  public void setCurrentValues()
  {
    if (this.progressAnimator != null)
      this.progressAnimator.cancel();
    if (this.nowNumberStr > this.maxNumberStr)
      this.nowNumberStr = this.maxNumberStr;
    if (this.nowNumberStr < 0)
      this.nowNumberStr = 0;
    this.curValues = this.nowNumberStr;
    this.lastAngle = this.currentAngle;
    setAnimation(this.lastAngle, this.nowNumberStr * this.percent, this.aniSpeed);
  }

  public void setMaxValues(float paramFloat)
  {
    this.percent = (this.sweepAngle / paramFloat);
  }

  public void setShowInfo(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2, String paramString3)
  {
    this.close_flg = true;
    this.titleStr = paramString1;
    this.showNumberStr = paramInt1;
    this.nowNumberStr = paramInt2;
    this.maxNumberStr = paramInt3;
    this.hintStr = paramString2;
    this.levelStr = paramString3;
    this.levelPaint.setColor(getContext().getResources().getColor(this.levelColor));
    this.trainHeadAnimEvent = new TrainHeadAnimEvent();
    setMaxValues(paramInt3);
    invalidate();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.TrainHeadProgressBar
 * JD-Core Version:    0.6.0
 */