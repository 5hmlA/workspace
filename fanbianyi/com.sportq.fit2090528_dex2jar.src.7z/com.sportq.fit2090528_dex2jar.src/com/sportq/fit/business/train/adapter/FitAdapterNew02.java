package com.sportq.fit.business.train.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import cn.iwgang.countdownview.CountdownView.OnCountdownEndListener;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.train.widget.FitItemDecoration;
import com.sportq.fit.business.train.widget.FitMoreTrainView;
import com.sportq.fit.business.train.widget.FitSingleTrainView;
import com.sportq.fit.business.train.widget.GoldServiceView;
import com.sportq.fit.business.train.widget.MineChallengesView;
import com.sportq.fit.business.train.widget.SuperFatView;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.AppUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.CourseActItemModel;
import com.sportq.fit.common.model.CourseActModel;
import com.sportq.fit.common.model.CurriculumModel;
import com.sportq.fit.common.model.EntloseFatData;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.WelcomeModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.task.activity.Task01NewChallengesListActivity;
import com.sportq.fit.fitmoudle.task.activity.Task02ChallengeDetailsActivity;
import com.sportq.fit.fitmoudle.task.reformer.model.ChallengesModel;
import com.sportq.fit.fitmoudle.widget.FitCustomItemView;
import com.sportq.fit.fitmoudle.widget.FitCustomItemView.FitItemClickListener;
import com.sportq.fit.fitmoudle.widget.FitCustomItemView.ItemAllClickListener;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.FitnessStartPageActivity;
import com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity;
import com.sportq.fit.fitmoudle7.customize.activity.CustomStartActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior;
import com.sportq.fit.middlelib.statistics.GrowingIOVariables;
import com.sportq.fit.persenter.AppPresenterImpl;
import com.sportq.fit.persenter.trainreformer.TrainTabReformer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class FitAdapterNew02 extends RecyclerView.Adapter
{
  private AppPresenterImpl appPresenter;
  private CountdownView.OnCountdownEndListener countdownEndListener;
  private PlanModel customizeInfo;
  private int customizeXML = 2;
  private FitItemDecoration fitItemDecoration;
  private int goldServiceXML = 0;
  private String hasCusFlag;
  private String hasHistoryFlag;
  private int itemCount;
  private Context mContext;
  private ArrayList<PlanModel> mineList;
  private int mineTaskFirstPos = 0;
  private ArrayList<ChallengesModel> mineTaskList;
  private int mineTaskXML = 4;
  private int mineTrainFirstPos = 0;
  private int mineTrainXML = 5;
  private int physicalTestXML = 7;
  private ArrayList<PlanModel> recommendList;
  private int recommendTrainFirstPos = 0;
  private int recommendTrainXML = 6;
  private ArrayList<Integer> sequenceIndex = new ArrayList();
  private int superFatFirstPos = 0;
  private int superFatXML = 3;
  private int taskRecommendXML = 1;
  private TrainTabReformer trainTabReformer;
  private WelcomeModel trainWelcome;
  private FitInterfaceUtils.UIInitListener uiInitListener;

  public FitAdapterNew02(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private void cancelTopPlanDataOrder(PlanModel paramPlanModel)
  {
    for (int i = 0; ; i++)
    {
      int j;
      if (i < this.mineList.size())
      {
        if (!"1".equals(((PlanModel)this.mineList.get(-1 + this.mineList.size() - i)).topFlag))
          continue;
        j = -1;
      }
      for (int k = 0; ; k++)
      {
        if (k < this.mineList.size())
        {
          if (!((PlanModel)this.mineList.get(k)).planId.equals(paramPlanModel.planId))
            continue;
          j = k;
        }
        this.mineList.remove(paramPlanModel);
        paramPlanModel.topFlag = "0";
        this.mineList.add(this.mineList.size() - i, paramPlanModel);
        int m = -1 + (this.mineList.size() - i) + this.mineTrainFirstPos;
        if (j != -1)
        {
          notifyItemMoved(j + this.mineTrainFirstPos, m);
          notifyItemRangeChanged(j + this.mineTrainFirstPos, m + 1 - j);
        }
        return;
      }
    }
  }

  private void changeTopPlanDataOrder(PlanModel paramPlanModel)
  {
    int i = -1;
    for (int j = 0; ; j++)
    {
      if (j < this.mineList.size())
      {
        if (!((PlanModel)this.mineList.get(j)).planId.equals(paramPlanModel.planId))
          continue;
        i = j;
      }
      this.mineList.remove(paramPlanModel);
      paramPlanModel.topFlag = "1";
      this.mineList.add(0, paramPlanModel);
      if (i != -1)
      {
        notifyItemMoved(i + this.mineTrainFirstPos, this.mineTrainFirstPos);
        notifyItemRangeChanged(this.mineTrainFirstPos, i + 1 + this.mineTrainFirstPos);
      }
      return;
    }
  }

  private ArrayList<Integer> getXmlType(String[] paramArrayOfString)
  {
    ArrayList localArrayList1 = new ArrayList(Arrays.asList(paramArrayOfString));
    ArrayList localArrayList2 = new ArrayList();
    int i = 0;
    if (i < localArrayList1.size())
    {
      String str = (String)localArrayList1.get(i);
      label88: int j;
      switch (str.hashCode())
      {
      default:
        j = -1;
        label91: switch (j)
        {
        default:
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        }
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      }
      while (true)
      {
        i++;
        break;
        if (!str.equals("1"))
          break label88;
        j = 0;
        break label91;
        if (!str.equals("2"))
          break label88;
        j = 1;
        break label91;
        if (!str.equals("3"))
          break label88;
        j = 2;
        break label91;
        if (!str.equals("4"))
          break label88;
        j = 3;
        break label91;
        if (!str.equals("5"))
          break label88;
        j = 4;
        break label91;
        if (!str.equals("6"))
          break label88;
        j = 5;
        break label91;
        localArrayList2.add(Integer.valueOf(this.customizeXML));
        continue;
        this.mineTrainFirstPos = localArrayList2.size();
        for (int i1 = 0; i1 < this.trainTabReformer.lstMine.size(); i1++)
          localArrayList2.add(Integer.valueOf(this.mineTrainXML));
        continue;
        this.superFatFirstPos = localArrayList2.size();
        for (int n = 0; n < this.trainTabReformer.lstCamp.size(); n++)
          localArrayList2.add(Integer.valueOf(this.superFatXML));
        continue;
        if ("0".equals(this.trainTabReformer.missionJoinFlag))
        {
          localArrayList2.add(Integer.valueOf(this.taskRecommendXML));
          continue;
        }
        this.mineTaskFirstPos = localArrayList2.size();
        for (int m = 0; m < this.trainTabReformer.lstMission.size(); m++)
          localArrayList2.add(Integer.valueOf(this.mineTaskXML));
        continue;
        localArrayList2.add(Integer.valueOf(this.goldServiceXML));
        continue;
        this.recommendTrainFirstPos = localArrayList2.size();
        for (int k = 0; k < this.trainTabReformer.lstRecommend.size(); k++)
          localArrayList2.add(Integer.valueOf(this.recommendTrainXML));
      }
    }
    if ((this.sequenceIndex != null) && (this.sequenceIndex.contains(Integer.valueOf(this.physicalTestXML))))
    {
      localArrayList2.add(0, Integer.valueOf(this.physicalTestXML));
      this.mineTrainFirstPos = (1 + this.mineTrainFirstPos);
      this.recommendTrainFirstPos = (1 + this.recommendTrainFirstPos);
      this.mineTaskFirstPos = (1 + this.mineTaskFirstPos);
      this.superFatFirstPos = (1 + this.superFatFirstPos);
    }
    return localArrayList2;
  }

  private void removePhysicalTestView()
  {
    if (!this.sequenceIndex.contains(Integer.valueOf(this.physicalTestXML)))
      return;
    this.sequenceIndex.remove(0);
    this.fitItemDecoration.setmSequenceIndex(this.sequenceIndex);
    this.mineTrainFirstPos = (-1 + this.mineTrainFirstPos);
    this.recommendTrainFirstPos = (-1 + this.recommendTrainFirstPos);
    this.mineTaskFirstPos = (-1 + this.mineTaskFirstPos);
    this.superFatFirstPos = (-1 + this.superFatFirstPos);
    this.itemCount = (-1 + this.itemCount);
    notifyItemRemoved(0);
    notifyItemRangeChanged(0, this.itemCount);
  }

  public FitItemDecoration getFitItemDecoration()
  {
    return this.fitItemDecoration;
  }

  public String getHasCusFlag()
  {
    return this.hasCusFlag;
  }

  public String getHasHistoryFlag()
  {
    return this.hasHistoryFlag;
  }

  public ArrayList<PlanModel> getIndivList()
  {
    return this.mineList;
  }

  public int getItemCount()
  {
    return this.itemCount;
  }

  public int getItemViewType(int paramInt)
  {
    return ((Integer)this.sequenceIndex.get(paramInt)).intValue();
  }

  public boolean isCustomized()
  {
    return !this.trainTabReformer.customizeInfo.stateCode.equals("0");
  }

  public boolean isShowPhyView()
  {
    return this.sequenceIndex.contains(Integer.valueOf(this.physicalTestXML));
  }

  public void onBindViewHolder(RecyclerView.ViewHolder paramViewHolder, int paramInt)
  {
    if ((paramViewHolder instanceof GoldServiceViewHolder))
      ((GoldServiceViewHolder)paramViewHolder).goldServiceView.initGoldService(this.trainTabReformer.lstGoldService);
    do
    {
      return;
      if ((paramViewHolder instanceof TaskRecommendViewHolder))
      {
        CourseActModel localCourseActModel = new CourseActModel();
        localCourseActModel.plateType = "0";
        localCourseActModel.plateName = this.mContext.getString(2131296402);
        localCourseActModel.lstplateDet = this.trainTabReformer.lstMission;
        ((TaskRecommendViewHolder)paramViewHolder).fitCustomItemView.initFindView(localCourseActModel);
        ((TaskRecommendViewHolder)paramViewHolder).fitCustomItemView.setItemAllClickListener(new FitCustomItemView.ItemAllClickListener()
        {
          public void itemAllClick()
          {
            FitAdapterNew02.this.mContext.startActivity(new Intent(FitAdapterNew02.this.mContext, Task01NewChallengesListActivity.class));
            AnimationUtil.pageJumpAnim((Activity)FitAdapterNew02.this.mContext, 0);
          }
        });
        ((TaskRecommendViewHolder)paramViewHolder).fitCustomItemView.setFitItemClickListener(new FitCustomItemView.FitItemClickListener()
        {
          public void fitItemClick(int paramInt)
          {
            CourseActItemModel localCourseActItemModel = (CourseActItemModel)FitAdapterNew02.this.trainTabReformer.lstMission.get(paramInt);
            Intent localIntent = new Intent(FitAdapterNew02.this.mContext, Task02ChallengeDetailsActivity.class);
            localIntent.putExtra("missionId", localCourseActItemModel.missionId);
            localIntent.putExtra("missionName", localCourseActItemModel.missionName);
            FitAdapterNew02.this.mContext.startActivity(localIntent);
            AnimationUtil.pageJumpAnim((Activity)FitAdapterNew02.this.mContext, 0);
          }
        });
        return;
      }
      if ((paramViewHolder instanceof CustomizeViewHolder))
      {
        ((CustomizeViewHolder)paramViewHolder).fitMoreTrainView.initCustomizeView(this.customizeInfo);
        ((CustomizeViewHolder)paramViewHolder).fitMoreTrainView.setOnClickListener(new FitAction(null)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            Intent localIntent;
            if ("0".equals(FitAdapterNew02.this.customizeInfo.stateCode))
            {
              localIntent = new Intent(FitAdapterNew02.this.mContext, CustomStartActivity.class);
              localIntent.putExtra("custom_hascusflag", FitAdapterNew02.this.hasCusFlag);
              localIntent.putExtra("custom_hasHistoryFlag", FitAdapterNew02.this.hasHistoryFlag);
            }
            while (true)
            {
              FitAdapterNew02.this.mContext.startActivity(localIntent);
              AnimationUtil.pageJumpAnim((Activity)FitAdapterNew02.this.mContext, 0);
              super.onClick(paramView);
              return;
              if (("1".equals(BaseApplication.userModel.isVip)) || ("3".equals(BaseApplication.userModel.isVip)))
              {
                localIntent = new Intent(FitAdapterNew02.this.mContext, CustomDetailActivity.class);
                continue;
              }
              localIntent = new Intent(FitAdapterNew02.this.mContext, CustomStartActivity.class);
              localIntent.putExtra("custom_hascusflag", FitAdapterNew02.this.hasCusFlag);
              localIntent.putExtra("custom_hasHistoryFlag", FitAdapterNew02.this.hasHistoryFlag);
            }
          }
        });
        return;
      }
      if ((paramViewHolder instanceof SuperFatViewHolder))
      {
        ((SuperFatViewHolder)paramViewHolder).superFatView.initData((EntloseFatData)this.trainTabReformer.lstCamp.get(paramInt - this.superFatFirstPos));
        return;
      }
      if ((paramViewHolder instanceof MineTaskViewHolder))
      {
        MineChallengesView localMineChallengesView = ((MineTaskViewHolder)paramViewHolder).mineChallengesView;
        ChallengesModel localChallengesModel = (ChallengesModel)this.mineTaskList.get(paramInt - this.mineTaskFirstPos);
        if (paramInt == this.mineTaskFirstPos);
        for (String str3 = this.mContext.getString(2131296428); ; str3 = "")
        {
          localMineChallengesView.initData(localChallengesModel, str3);
          return;
        }
      }
      if ((paramViewHolder instanceof MineTrainViewHolder))
      {
        PlanModel localPlanModel3 = (PlanModel)this.mineList.get(paramInt - this.mineTrainFirstPos);
        FitSingleTrainView localFitSingleTrainView2 = ((MineTrainViewHolder)paramViewHolder).mineTrainView;
        if (paramInt == this.mineTrainFirstPos);
        for (String str2 = "我的课程"; ; str2 = "")
        {
          localFitSingleTrainView2.initView(localPlanModel3, str2, "1");
          ((MineTrainViewHolder)paramViewHolder).mineTrainView.getSingle_train_item_layout().setOnClickListener(new FitAction(null, localPlanModel3)
          {
            @Instrumented
            public void onClick(View paramView)
            {
              VdsAgent.onClick(this, paramView);
              Intent localIntent = new Intent(FitAdapterNew02.this.mContext, Find04GenTrainInfoActivity.class);
              localIntent.putExtra("single.type", "0");
              localIntent.putExtra("plan.id", this.val$planModel.planId);
              FitAdapterNew02.this.mContext.startActivity(localIntent);
              AnimationUtil.pageJumpAnim((Activity)FitAdapterNew02.this.mContext, 0);
              super.onClick(paramView);
            }
          });
          ((MineTrainViewHolder)paramViewHolder).mineTrainView.getSingle_train_item_layout().setOnLongClickListener(new View.OnLongClickListener(localPlanModel3, paramInt)
          {
            public boolean onLongClick(View paramView)
            {
              String[] arrayOfString = new String[2];
              if ("1".equals(this.val$planModel.topFlag));
              for (String str = "取消置顶"; ; str = "置顶")
              {
                arrayOfString[0] = str;
                arrayOfString[1] = "退出单节课程";
                new DialogManager().createDialog(new FitInterfaceUtils.DialogListener()
                {
                  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
                  {
                    if (paramInt == 0)
                    {
                      RequestModel localRequestModel = new RequestModel();
                      localRequestModel.planId = FitAdapterNew02.5.this.val$planModel.planId;
                      if ("1".equals(FitAdapterNew02.5.this.val$planModel.topFlag));
                      for (String str = "0"; ; str = "1")
                      {
                        localRequestModel.topFlag = str;
                        localRequestModel.planType = "0";
                        FitAdapterNew02.this.appPresenter.setTopCourse(FitAdapterNew02.this.mContext, localRequestModel);
                        if (!"1".equals(FitAdapterNew02.5.this.val$planModel.topFlag))
                          break;
                        FitAdapterNew02.this.cancelTopPlanDataOrder(FitAdapterNew02.5.this.val$planModel);
                        return;
                      }
                      FitAdapterNew02.this.changeTopPlanDataOrder(FitAdapterNew02.5.this.val$planModel);
                      return;
                    }
                    new DialogManager().createChoiceDialog(new FitInterfaceUtils.DialogListener()
                    {
                      public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
                      {
                        if (paramInt == -1)
                        {
                          RequestModel localRequestModel = new RequestModel();
                          localRequestModel.planId = FitAdapterNew02.5.this.val$planModel.planId;
                          localRequestModel.flg = "1";
                          localRequestModel.planType = FitAdapterNew02.5.this.val$planModel.trainType;
                          MiddleManager.getInstance().getFindPresenterImpl(FitAdapterNew02.this.uiInitListener, null).joinPlan(localRequestModel, FitAdapterNew02.this.mContext);
                          FitAdapterNew02.this.mineList.remove(FitAdapterNew02.5.this.val$planModel);
                          if ((FitAdapterNew02.this.mineTaskFirstPos > FitAdapterNew02.this.mineTrainFirstPos) && (FitAdapterNew02.this.mineTaskFirstPos > 0))
                            FitAdapterNew02.access$1010(FitAdapterNew02.this);
                          if ((FitAdapterNew02.this.superFatFirstPos > FitAdapterNew02.this.mineTrainFirstPos) && (FitAdapterNew02.this.superFatFirstPos > 0))
                            FitAdapterNew02.access$1210(FitAdapterNew02.this);
                          if ((FitAdapterNew02.this.recommendTrainFirstPos > FitAdapterNew02.this.mineTrainFirstPos) && (FitAdapterNew02.this.recommendTrainFirstPos > 0))
                            FitAdapterNew02.access$1310(FitAdapterNew02.this);
                          FitAdapterNew02.access$1410(FitAdapterNew02.this);
                          if ((FitAdapterNew02.this.sequenceIndex != null) && (FitAdapterNew02.this.sequenceIndex.size() > 0))
                          {
                            FitAdapterNew02.this.sequenceIndex.remove(FitAdapterNew02.5.this.val$position);
                            FitAdapterNew02.this.fitItemDecoration.setmSequenceIndex(FitAdapterNew02.this.sequenceIndex);
                          }
                          FitAdapterNew02.this.notifyItemRemoved(FitAdapterNew02.5.this.val$position);
                          FitAdapterNew02.this.notifyItemRangeChanged(0, FitAdapterNew02.this.itemCount);
                        }
                      }
                    }
                    , FitAdapterNew02.this.mContext, "", FitAdapterNew02.this.mContext.getString(2131297093), FitAdapterNew02.this.mContext.getString(2131297094), FitAdapterNew02.this.mContext.getString(2131297095));
                  }
                }
                , FitAdapterNew02.this.mContext, arrayOfString);
                return false;
              }
            }
          });
          return;
        }
      }
      if (!(paramViewHolder instanceof RecommendTrainViewHolder))
        continue;
      PlanModel localPlanModel1 = (PlanModel)this.recommendList.get(paramInt - this.recommendTrainFirstPos);
      FitSingleTrainView localFitSingleTrainView1 = ((RecommendTrainViewHolder)paramViewHolder).recommendTrainView;
      PlanModel localPlanModel2 = (PlanModel)this.recommendList.get(paramInt - this.recommendTrainFirstPos);
      if (paramInt == this.recommendTrainFirstPos);
      for (String str1 = "推荐课程"; ; str1 = "")
      {
        localFitSingleTrainView1.initView(localPlanModel2, str1, "0");
        ((RecommendTrainViewHolder)paramViewHolder).recommendTrainView.getSingle_train_item_layout().setOnClickListener(new FitAction(null, localPlanModel1)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            Intent localIntent = new Intent(FitAdapterNew02.this.mContext, Find04GenTrainInfoActivity.class);
            localIntent.putExtra("single.type", "0");
            localIntent.putExtra("plan.id", this.val$planModel.planId);
            FitAdapterNew02.this.mContext.startActivity(localIntent);
            AnimationUtil.pageJumpAnim((Activity)FitAdapterNew02.this.mContext, 0);
            super.onClick(paramView);
          }
        });
        return;
      }
    }
    while (!(paramViewHolder instanceof PhysicalTestViewHolder));
    if (this.trainWelcome != null)
      GlideUtils.loadCacheImg(this.mContext, this.trainWelcome.useUrl, ((PhysicalTestViewHolder)paramViewHolder).train_ad_img);
    while (true)
    {
      ((PhysicalTestViewHolder)paramViewHolder).physical_close.setOnClickListener(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          FitAdapterNew02.this.removePhysicalTestView();
          if (FitAdapterNew02.this.trainWelcome == null)
            AppSharePreferenceUtils.putPhysicalCloseBtnClick();
          while (true)
          {
            super.onClick(paramView);
            return;
            AppSharePreferenceUtils.putTrainTabAdCloseBtnClick();
          }
        }
      });
      ((PhysicalTestViewHolder)paramViewHolder).physical_layout.setOnClickListener(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (FitAdapterNew02.this.trainWelcome == null)
          {
            SharePreferenceUtils.putPhyFromPage("0");
            Intent localIntent = new Intent(FitAdapterNew02.this.mContext, FitnessStartPageActivity.class);
            FitAdapterNew02.this.mContext.startActivity(localIntent);
            AnimationUtil.pageJumpAnim((Activity)FitAdapterNew02.this.mContext, 0);
          }
          while (true)
          {
            super.onClick(paramView);
            return;
            AppUtils.navAdJump(FitAdapterNew02.this.mContext, FitAdapterNew02.this.trainWelcome);
            GrowingIOVariables localGrowingIOVariables = new GrowingIOVariables();
            localGrowingIOVariables.eventid = "ad_banner_click";
            localGrowingIOVariables.ad_id = FitAdapterNew02.this.trainWelcome.adId;
            GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
          }
        }
      });
      return;
      ((PhysicalTestViewHolder)paramViewHolder).train_ad_img.setImageResource(2130903560);
    }
  }

  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt)
  {
    if (this.goldServiceXML == paramInt)
      return new GoldServiceViewHolder(new GoldServiceView(this.mContext));
    if (this.taskRecommendXML == paramInt)
      return new TaskRecommendViewHolder(new FitCustomItemView(this.mContext));
    if (this.customizeXML == paramInt)
      return new CustomizeViewHolder(new FitMoreTrainView(this.mContext));
    if (this.superFatXML == paramInt)
      return new SuperFatViewHolder(new SuperFatView(this.mContext));
    if (this.mineTaskXML == paramInt)
      return new MineTaskViewHolder(new MineChallengesView(this.mContext));
    if (this.mineTrainXML == paramInt)
      return new MineTrainViewHolder(new FitSingleTrainView(this.mContext));
    if (this.recommendTrainXML == paramInt)
      return new RecommendTrainViewHolder(new FitSingleTrainView(this.mContext));
    View localView = View.inflate(this.mContext, 2130969078, null);
    localView.setLayoutParams(new ViewGroup.LayoutParams(-1, (int)(0.1861D * BaseApplication.screenWidth)));
    return new PhysicalTestViewHolder(localView);
  }

  public void onViewAttachedToWindow(RecyclerView.ViewHolder paramViewHolder)
  {
    int i = paramViewHolder.getAdapterPosition();
    try
    {
      if (((paramViewHolder instanceof MineTrainViewHolder)) && (i >= this.mineTrainFirstPos))
      {
        PlanModel localPlanModel = (PlanModel)this.mineList.get(i - this.mineTrainFirstPos);
        ((MineTrainViewHolder)paramViewHolder).mineTrainView.setCountDownTime(localPlanModel, this.countdownEndListener);
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void setData(TrainTabReformer paramTrainTabReformer)
  {
    this.trainTabReformer = paramTrainTabReformer;
    this.hasHistoryFlag = this.trainTabReformer.customizeInfo.hasHistoryFlag;
    this.hasCusFlag = this.trainTabReformer.customizeInfo.hasCusFlag;
    this.sequenceIndex = getXmlType(this.trainTabReformer.orderNumber.split(","));
    this.itemCount = this.sequenceIndex.size();
    this.mineList = this.trainTabReformer.lstMine;
    this.recommendList = this.trainTabReformer.lstRecommend;
    if (("1".equals(this.trainTabReformer.missionJoinFlag)) && (this.trainTabReformer.lstMission != null) && (this.trainTabReformer.lstMission.size() > 0))
    {
      this.mineTaskList = new ArrayList();
      Gson localGson = new Gson();
      Iterator localIterator = this.trainTabReformer.lstMission.iterator();
      while (localIterator.hasNext())
      {
        CourseActItemModel localCourseActItemModel = (CourseActItemModel)localIterator.next();
        this.mineTaskList.add(localGson.fromJson(localGson.toJson(localCourseActItemModel), ChallengesModel.class));
      }
    }
    this.customizeInfo = AppUtils.convertCustomModel(this.trainTabReformer.customizeInfo);
    if (this.fitItemDecoration == null)
    {
      this.fitItemDecoration = new FitItemDecoration(this.mContext);
      this.fitItemDecoration.setDivider(2130837689);
    }
    this.fitItemDecoration.setmSequenceIndex(this.sequenceIndex);
  }

  public void setIndivList(ArrayList<PlanModel> paramArrayList)
  {
    this.mineList = paramArrayList;
  }

  public void setListener(FitInterfaceUtils.UIInitListener paramUIInitListener, CountdownView.OnCountdownEndListener paramOnCountdownEndListener)
  {
    this.uiInitListener = paramUIInitListener;
    this.countdownEndListener = paramOnCountdownEndListener;
    this.appPresenter = new AppPresenterImpl(paramUIInitListener);
  }

  public void setPhysicalTestView(WelcomeModel paramWelcomeModel)
  {
    this.trainWelcome = paramWelcomeModel;
    if (this.sequenceIndex.contains(Integer.valueOf(this.physicalTestXML)))
      return;
    this.sequenceIndex.add(0, Integer.valueOf(this.physicalTestXML));
    this.fitItemDecoration.setmSequenceIndex(this.sequenceIndex);
    this.mineTrainFirstPos = (1 + this.mineTrainFirstPos);
    this.recommendTrainFirstPos = (1 + this.recommendTrainFirstPos);
    this.mineTaskFirstPos = (1 + this.mineTaskFirstPos);
    this.superFatFirstPos = (1 + this.superFatFirstPos);
    this.itemCount = (1 + this.itemCount);
    notifyItemInserted(0);
    notifyItemRangeChanged(0, this.itemCount);
  }

  private class CustomizeViewHolder extends RecyclerView.ViewHolder
  {
    FitMoreTrainView fitMoreTrainView;

    CustomizeViewHolder(View arg2)
    {
      super();
      this.fitMoreTrainView = ((FitMoreTrainView)localView);
    }
  }

  private class GoldServiceViewHolder extends RecyclerView.ViewHolder
  {
    GoldServiceView goldServiceView;

    GoldServiceViewHolder(View arg2)
    {
      super();
      this.goldServiceView = ((GoldServiceView)localView);
    }
  }

  private class MineTaskViewHolder extends RecyclerView.ViewHolder
  {
    MineChallengesView mineChallengesView;

    MineTaskViewHolder(View arg2)
    {
      super();
      this.mineChallengesView = ((MineChallengesView)localView);
    }
  }

  private class MineTrainViewHolder extends RecyclerView.ViewHolder
  {
    FitSingleTrainView mineTrainView;

    MineTrainViewHolder(View arg2)
    {
      super();
      this.mineTrainView = ((FitSingleTrainView)localView);
    }
  }

  private class PhysicalTestViewHolder extends RecyclerView.ViewHolder
  {
    RelativeLayout physical_close;
    FrameLayout physical_layout;
    ImageView train_ad_img;

    PhysicalTestViewHolder(View arg2)
    {
      super();
      this.physical_close = ((RelativeLayout)localView.findViewById(2131757153));
      this.physical_layout = ((FrameLayout)localView.findViewById(2131757151));
      this.train_ad_img = ((ImageView)localView.findViewById(2131757152));
    }
  }

  private class RecommendTrainViewHolder extends RecyclerView.ViewHolder
  {
    FitSingleTrainView recommendTrainView;

    RecommendTrainViewHolder(View arg2)
    {
      super();
      this.recommendTrainView = ((FitSingleTrainView)localView);
    }
  }

  private class SuperFatViewHolder extends RecyclerView.ViewHolder
  {
    SuperFatView superFatView;

    SuperFatViewHolder(View arg2)
    {
      super();
      this.superFatView = ((SuperFatView)localView);
    }
  }

  private class TaskRecommendViewHolder extends RecyclerView.ViewHolder
  {
    FitCustomItemView fitCustomItemView;

    TaskRecommendViewHolder(View arg2)
    {
      super();
      this.fitCustomItemView = ((FitCustomItemView)localView);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.adapter.FitAdapterNew02
 * JD-Core Version:    0.6.0
 */