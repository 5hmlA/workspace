package com.sportq.fit.business.train.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.find.activity.CourseActOperationalActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.GoldServiceModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.manager.viewcompmanager.viewpager.FixedSpeedScroller;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class GoldServiceView extends FrameLayout
{
  private TextView fit_custom_all;
  private TextView fit_custom_title;
  private ViewPager item_view_pager;
  private Subscription subscription;
  private ArrayList<View> viewList;

  public GoldServiceView(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public GoldServiceView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public GoldServiceView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    onCreateView();
  }

  private void initViewPagerData(ArrayList<GoldServiceModel> paramArrayList)
  {
    this.viewList = new ArrayList();
    Iterator localIterator = paramArrayList.iterator();
    while (localIterator.hasNext())
    {
      GoldServiceModel localGoldServiceModel = (GoldServiceModel)localIterator.next();
      GoldServiceItemView localGoldServiceItemView = new GoldServiceItemView(getContext(), localGoldServiceModel);
      this.viewList.add(localGoldServiceItemView);
    }
    this.item_view_pager.setAdapter(new CustomViewPagerAdapter(this.viewList));
    this.item_view_pager.setCurrentItem(0);
    this.item_view_pager.setTag(new Gson().toJson(paramArrayList));
  }

  private void onCreateView()
  {
    View localView = LayoutInflater.from(getContext()).inflate(2130968885, this, true);
    this.fit_custom_title = ((TextView)localView.findViewById(2131756154));
    this.fit_custom_all = ((TextView)localView.findViewById(2131756155));
    this.item_view_pager = ((ViewPager)localView.findViewById(2131756310));
    this.item_view_pager.getLayoutParams().height = (int)(0.642D * (0.9D * BaseApplication.screenWidth));
    startCountDown();
    int i = (int)(0.0444D * BaseApplication.screenWidth);
    int j = (int)(0.0278D * BaseApplication.screenWidth);
    this.item_view_pager.setPadding(i, 0, j, 0);
    this.item_view_pager.setOnTouchListener(new View.OnTouchListener()
    {
      public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
      {
        switch (paramMotionEvent.getAction())
        {
        default:
        case 0:
        case 2:
        case 1:
        case 3:
        }
        while (true)
        {
          return false;
          if (GoldServiceView.this.subscription == null)
            continue;
          GoldServiceView.this.subscription.unsubscribe();
          GoldServiceView.access$002(GoldServiceView.this, null);
          continue;
          GoldServiceView.this.startCountDown();
        }
      }
    });
    try
    {
      Field localField = ViewPager.class.getDeclaredField("mScroller");
      localField.setAccessible(true);
      FixedSpeedScroller localFixedSpeedScroller = new FixedSpeedScroller(this.item_view_pager.getContext(), new LinearInterpolator());
      localFixedSpeedScroller.setmDuration(200);
      localField.set(this.item_view_pager, localFixedSpeedScroller);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void startCountDown()
  {
    if (this.subscription == null)
      this.subscription = Observable.interval(5L, TimeUnit.SECONDS).onBackpressureBuffer().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1()
      {
        public void call(Long paramLong)
        {
          int i = GoldServiceView.this.item_view_pager.getCurrentItem();
          if (i == -1 + GoldServiceView.this.viewList.size());
          for (int j = 0; ; j = i + 1)
          {
            ViewPager localViewPager = GoldServiceView.this.item_view_pager;
            boolean bool = false;
            if (j != 0)
              bool = true;
            localViewPager.setCurrentItem(j, bool);
            return;
          }
        }
      });
  }

  public void initGoldService(ArrayList<GoldServiceModel> paramArrayList)
  {
    this.fit_custom_title.setText(getContext().getString(2131296410));
    this.fit_custom_all.setOnClickListener(new FitAction(null)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(GoldServiceView.this.getContext(), CourseActOperationalActivity.class);
        localIntent.putExtra("jump.type", "0");
        GoldServiceView.this.getContext().startActivity(localIntent);
        AnimationUtil.pageJumpAnim((Activity)GoldServiceView.this.getContext(), 0);
      }
    });
    if (this.item_view_pager.getTag() == null)
      initViewPagerData(paramArrayList);
    do
      return;
    while (this.item_view_pager.getTag().toString().equals(new Gson().toJson(paramArrayList)));
    initViewPagerData(paramArrayList);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.GoldServiceView
 * JD-Core Version:    0.6.0
 */