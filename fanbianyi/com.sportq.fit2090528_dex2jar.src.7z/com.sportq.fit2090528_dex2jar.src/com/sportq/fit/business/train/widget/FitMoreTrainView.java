package com.sportq.fit.business.train.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle8.activity.AllCoursesActivity;

public class FitMoreTrainView extends FrameLayout
{
  private TextView fit_custom_all;
  private TextView fit_custom_title;
  private FrameLayout frameLayout;
  private ImageView more_train_img;
  private TextView more_train_info01;
  private TextView more_train_info02;
  private TextView more_train_info03;
  private LinearLayout more_train_info_layout;
  private TextView more_train_schedule;
  private ImageView more_train_state_icon;
  private FrameLayout.LayoutParams params;
  private LinearLayout.LayoutParams params02;
  private LinearLayout schedule_layout;
  private TextView start_customize_view;
  private FrameLayout title_layout;

  public FitMoreTrainView(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public FitMoreTrainView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public FitMoreTrainView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    addView(onCreateView());
  }

  private boolean isFinished(PlanModel paramPlanModel)
  {
    return paramPlanModel.finishSection.equals(paramPlanModel.sectionCount);
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), 2130968850, null);
    this.title_layout = ((FrameLayout)localView.findViewById(2131755295));
    this.fit_custom_title = ((TextView)localView.findViewById(2131756154));
    this.fit_custom_all = ((TextView)localView.findViewById(2131756155));
    this.more_train_img = ((ImageView)localView.findViewById(2131756167));
    this.more_train_state_icon = ((ImageView)localView.findViewById(2131756174));
    this.more_train_info_layout = ((LinearLayout)localView.findViewById(2131756168));
    this.more_train_info01 = ((TextView)localView.findViewById(2131756169));
    this.more_train_info02 = ((TextView)localView.findViewById(2131756170));
    this.more_train_info03 = ((TextView)localView.findViewById(2131756171));
    this.schedule_layout = ((LinearLayout)localView.findViewById(2131756172));
    this.more_train_schedule = ((TextView)localView.findViewById(2131756173));
    this.start_customize_view = ((TextView)localView.findViewById(2131756175));
    this.frameLayout = ((FrameLayout)localView.findViewById(2131755519));
    this.params = ((FrameLayout.LayoutParams)this.more_train_info_layout.getLayoutParams());
    this.params02 = ((LinearLayout.LayoutParams)this.more_train_info03.getLayoutParams());
    return localView;
  }

  public FrameLayout getFrameLayout()
  {
    return this.frameLayout;
  }

  public ImageView getMore_train_img()
  {
    return this.more_train_img;
  }

  public void initCustomizeView(PlanModel paramPlanModel)
  {
    this.fit_custom_title.setText(getContext().getString(2131298002));
    this.fit_custom_all.setVisibility(8);
    this.frameLayout.getLayoutParams().height = (int)(0.63889D * BaseApplication.screenWidth);
    this.frameLayout.getLayoutParams().width = BaseApplication.screenWidth;
    this.more_train_state_icon.setVisibility(8);
    if ("0".equals(paramPlanModel.stateCode))
    {
      this.more_train_info_layout.setVisibility(8);
      this.schedule_layout.setVisibility(8);
      this.start_customize_view.setVisibility(0);
      this.more_train_img.setImageResource(2130903062);
      Drawable localDrawable = ContextCompat.getDrawable(getContext(), 2130903451);
      localDrawable.setBounds(0, 0, CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F), CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F));
      this.start_customize_view.setCompoundDrawables(null, null, localDrawable, null);
      return;
    }
    this.more_train_info_layout.setGravity(8388611);
    this.params.gravity = 16;
    this.params.leftMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F);
    this.params02.topMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 1.0F);
    GlideUtils.loadImgByDefault(paramPlanModel.planImageURL, this.more_train_img);
    this.more_train_info01.setText(paramPlanModel.planName);
    this.more_train_info02.setVisibility(0);
    this.more_train_info02.setTextSize(23.0F);
    if ("1".equals(paramPlanModel.planState))
    {
      SpannableString localSpannableString = new SpannableString(paramPlanModel.currentSection);
      localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getContext(), 2131624117)), 1 + paramPlanModel.currentSection.indexOf("/"), paramPlanModel.currentSection.length(), 17);
      this.more_train_info02.setText(localSpannableString);
      if (!StringUtils.isNull(paramPlanModel.courseInfo))
        break label376;
      this.more_train_info03.setVisibility(8);
    }
    while (true)
    {
      if (!"未开始".equals(paramPlanModel.currentSection))
        break label408;
      this.schedule_layout.setVisibility(8);
      return;
      this.more_train_info02.setText(paramPlanModel.currentSection);
      break;
      label376: this.more_train_info03.setTextSize(14.0F);
      this.more_train_info03.setVisibility(0);
      this.more_train_info03.setText(paramPlanModel.courseInfo);
    }
    label408: this.schedule_layout.setVisibility(0);
    this.more_train_schedule.setText(paramPlanModel.scheduleInfo);
  }

  public void initView(PlanModel paramPlanModel, String paramString1, String paramString2)
  {
    this.frameLayout.getLayoutParams().height = (int)(0.5069D * BaseApplication.screenWidth);
    this.frameLayout.getLayoutParams().width = BaseApplication.screenWidth;
    this.start_customize_view.setVisibility(8);
    int i;
    label99: LinearLayout localLinearLayout;
    if (StringUtils.isNull(paramString1))
    {
      this.title_layout.setVisibility(8);
      GlideUtils.loadImgByDefault(paramPlanModel.planImageURL, this.more_train_img);
      this.more_train_info01.setText(paramPlanModel.planName);
      ImageView localImageView1 = this.more_train_state_icon;
      if (!"0".equals(paramString2))
        break label327;
      i = 2130903602;
      localImageView1.setImageResource(i);
      localLinearLayout = this.schedule_layout;
      if (!"0".equals(paramString2))
        break label335;
    }
    label327: label335: for (int j = 8; ; j = 0)
    {
      localLinearLayout.setVisibility(j);
      if (!"0".equals(paramString2))
        break label341;
      this.more_train_info_layout.setGravity(1);
      this.params.gravity = 1;
      this.params.topMargin = (int)(0.16111D * BaseApplication.screenWidth);
      this.params.leftMargin = 0;
      this.params02.topMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F);
      this.more_train_info02.setVisibility(0);
      this.more_train_info02.setText(paramPlanModel.courseInfo);
      this.more_train_info02.setTextSize(14.0F);
      String str = paramPlanModel.planNumberOfParticipants.replace("已参加", "") + "已参加";
      this.more_train_info03.setText(str);
      return;
      this.title_layout.setBackgroundResource(2131624328);
      this.title_layout.setVisibility(0);
      this.fit_custom_title.setText(paramString1);
      this.fit_custom_all.setText(StringUtils.getStringResources(2131296411));
      this.fit_custom_all.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          FitMoreTrainView.this.getContext().startActivity(new Intent(FitMoreTrainView.this.getContext(), AllCoursesActivity.class));
          AnimationUtil.pageJumpAnim((Activity)FitMoreTrainView.this.getContext(), 0);
        }
      });
      break;
      i = 2130903470;
      break label99;
    }
    label341: this.more_train_info_layout.setGravity(8388611);
    this.params.gravity = 16;
    this.params.topMargin = 0;
    this.params.leftMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F);
    this.params02.topMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 1.0F);
    ImageView localImageView2;
    int k;
    if (isFinished(paramPlanModel))
    {
      this.more_train_info02.setVisibility(8);
      this.more_train_info03.setText(paramPlanModel.courseInfo);
      this.more_train_info03.setTextSize(14.0F);
      this.more_train_schedule.setText(paramPlanModel.scheduleInfo);
      localImageView2 = this.more_train_state_icon;
      boolean bool = "1".equals(paramPlanModel.topFlag);
      k = 0;
      if (!bool)
        break label539;
    }
    while (true)
    {
      localImageView2.setVisibility(k);
      return;
      this.more_train_info02.setVisibility(0);
      this.more_train_info02.setText(String.valueOf("第" + paramPlanModel.currentSection + "节"));
      this.more_train_info02.setTextSize(23.0F);
      break;
      label539: k = 4;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.FitMoreTrainView
 * JD-Core Version:    0.6.0
 */