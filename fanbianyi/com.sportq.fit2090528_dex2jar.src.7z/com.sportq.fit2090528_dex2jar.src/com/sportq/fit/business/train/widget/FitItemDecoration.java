package com.sportq.fit.business.train.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ItemDecoration;
import android.support.v7.widget.RecyclerView.LayoutParams;
import android.support.v7.widget.RecyclerView.State;
import android.view.View;
import com.sportq.fit.common.utils.LogUtils;
import java.util.ArrayList;

public class FitItemDecoration extends RecyclerView.ItemDecoration
{
  private Context mContext;
  private Drawable mDivider;
  private ArrayList<Integer> mSequenceIndex;

  public FitItemDecoration(Context paramContext)
  {
    this.mContext = paramContext;
  }

  public void getItemOffsets(Rect paramRect, View paramView, RecyclerView paramRecyclerView, RecyclerView.State paramState)
  {
    try
    {
      int j = paramRecyclerView.getChildAdapterPosition(paramView);
      if (j >= 0)
      {
        if (j > -1 + this.mSequenceIndex.size())
          return;
        if (((Integer)this.mSequenceIndex.get(j)).intValue() != 7)
        {
          int k = this.mSequenceIndex.size();
          if (j != k - 1)
            break label78;
        }
        label78: int m;
        for (i = 0; ; i = m)
        {
          paramRect.set(0, 0, 0, i);
          return;
          m = this.mDivider.getIntrinsicHeight();
        }
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        LogUtils.e(localException);
        int i = this.mDivider.getIntrinsicHeight();
      }
    }
  }

  public void onDraw(Canvas paramCanvas, RecyclerView paramRecyclerView, RecyclerView.State paramState)
  {
    int i = paramRecyclerView.getPaddingLeft();
    int j = paramRecyclerView.getWidth() - paramRecyclerView.getPaddingRight();
    int k = paramRecyclerView.getChildCount();
    int m = 0;
    if (m < k)
    {
      View localView = paramRecyclerView.getChildAt(m);
      RecyclerView.LayoutParams localLayoutParams = (RecyclerView.LayoutParams)localView.getLayoutParams();
      int n = localView.getBottom() + localLayoutParams.bottomMargin;
      if (localView.getId() == 2131757151);
      for (int i1 = 0; ; i1 = this.mDivider.getIntrinsicHeight())
      {
        int i2 = n + i1;
        this.mDivider.setBounds(i, n, j, i2);
        this.mDivider.draw(paramCanvas);
        m++;
        break;
      }
    }
  }

  public void setDivider(int paramInt)
  {
    this.mDivider = this.mContext.getResources().getDrawable(paramInt);
  }

  public void setmSequenceIndex(ArrayList<Integer> paramArrayList)
  {
    this.mSequenceIndex = paramArrayList;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.FitItemDecoration
 * JD-Core Version:    0.6.0
 */