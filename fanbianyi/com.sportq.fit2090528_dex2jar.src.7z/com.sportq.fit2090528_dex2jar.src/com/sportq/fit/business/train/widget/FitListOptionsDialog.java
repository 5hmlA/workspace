package com.sportq.fit.business.train.widget;

import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.v4.content.ContextCompat;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;

public class FitListOptionsDialog
{
  private LinearLayout dialogLinear;
  private Context mContext;

  public FitListOptionsDialog(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private View createLineView()
  {
    TextView localTextView = new TextView(this.mContext);
    localTextView.setBackgroundColor(ContextCompat.getColor(this.mContext, 2131624092));
    localTextView.setLayoutParams(new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 0.5F)));
    return localTextView;
  }

  private TextView createTextView(String paramString)
  {
    TextView localTextView = new TextView(this.mContext);
    TypedValue localTypedValue = new TypedValue();
    this.mContext.getTheme().resolveAttribute(16843534, localTypedValue, true);
    int[] arrayOfInt = { 16843534 };
    TypedArray localTypedArray = this.mContext.getTheme().obtainStyledAttributes(localTypedValue.resourceId, arrayOfInt);
    if (Build.VERSION.SDK_INT >= 16)
      localTextView.setBackground(localTypedArray.getDrawable(0));
    localTypedArray.recycle();
    localTextView.setTextSize(2, 16.0F);
    localTextView.setTextColor(ContextCompat.getColor(this.mContext, 2131624031));
    localTextView.setText(paramString);
    localTextView.setLayoutParams(new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 47.0F)));
    localTextView.setPadding(0, 0, 0, 0);
    localTextView.setGravity(17);
    return localTextView;
  }

  public void createDialog(String[] paramArrayOfString, FitListOptionsDialogClick paramFitListOptionsDialogClick)
  {
    Dialog localDialog = new Dialog(this.mContext);
    localDialog.requestWindowFeature(1);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setCancelable(true);
    localDialog.setContentView(2130968854);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.8611D * BaseApplication.screenWidth);
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    this.dialogLinear = ((LinearLayout)localDialog.findViewById(2131756200));
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      if (i != 0)
        this.dialogLinear.addView(createLineView());
      TextView localTextView = createTextView(paramArrayOfString[i]);
      localTextView.setOnClickListener(new View.OnClickListener(paramFitListOptionsDialogClick, i, localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (this.val$fitListOptionsDialogClick != null)
            this.val$fitListOptionsDialogClick.ItemClick(this.val$finalI);
          this.val$mDialog.dismiss();
        }
      });
      this.dialogLinear.addView(localTextView);
    }
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public static abstract interface FitListOptionsDialogClick
  {
    public abstract void ItemClick(int paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.FitListOptionsDialog
 * JD-Core Version:    0.6.0
 */