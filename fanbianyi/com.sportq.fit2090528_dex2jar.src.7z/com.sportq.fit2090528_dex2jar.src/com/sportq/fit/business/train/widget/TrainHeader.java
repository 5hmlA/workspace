package com.sportq.fit.business.train.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.common.model.HeadModel;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.manager.viewcompmanager.suspensionbox.CustomMyProgressBar;

public class TrainHeader extends RelativeLayout
{

  @Bind({2131757628})
  TextView next_text;

  @Bind({2131757627})
  TrainHeadProgressBar train_head_progressBar;

  public TrainHeader(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public void init(Context paramContext)
  {
    ButterKnife.bind(inflate(paramContext, 2130969180, this));
  }

  public void onShowTrainData()
  {
    this.train_head_progressBar.setCurrentValues();
  }

  public void setHeaderData(CustomMyProgressBar paramCustomMyProgressBar)
  {
    int i;
    int j;
    if (StringUtils.isNull(FitApplication.headModel.sectionDuration))
    {
      i = 0;
      if (!StringUtils.isNull(FitApplication.headModel.trainDuration))
        break label126;
      j = 0;
      label28: if (!StringUtils.isNull(FitApplication.headModel.levelName))
        break label142;
    }
    label142: for (String str1 = "无等级"; ; str1 = FitApplication.headModel.levelName)
    {
      if (i != 0)
        break label153;
      this.train_head_progressBar.setShowInfo("总共训练", j, j, j, "分钟", str1);
      this.next_text.setText("膜拜大神，从此能战胜的只有你自己了，继续加油~");
      paramCustomMyProgressBar.setProgressMax(j);
      paramCustomMyProgressBar.setProgress(j);
      paramCustomMyProgressBar.setRightText("");
      if ("无等级".equals(str1))
        str1 = "";
      paramCustomMyProgressBar.setLeftText(str1);
      return;
      i = Integer.valueOf(FitApplication.headModel.sectionDuration).intValue();
      break;
      label126: j = Integer.valueOf(FitApplication.headModel.trainDuration).intValue();
      break label28;
    }
    label153: String str2;
    int k;
    label184: int m;
    label194: int n;
    if (StringUtils.isNull(FitApplication.headModel.differDuration))
    {
      str2 = "0";
      if (!StringUtils.isNull(FitApplication.headModel.lastTrainDuration))
        break label326;
      k = 0;
      if (j - k != 0)
        break label343;
      m = 1;
      this.train_head_progressBar.setShowInfo("总共训练", j, m, i - k, "分钟", str1);
      this.next_text.setText(str2);
      if (k != 0)
        break label352;
      n = 100;
      label232: paramCustomMyProgressBar.setProgressMax(n);
      if (k != 0)
        break label361;
    }
    label326: label343: label352: label361: for (int i1 = 1; ; i1 = j - k)
    {
      paramCustomMyProgressBar.setProgress(i1);
      String[] arrayOfString = new String[1];
      arrayOfString[0] = (i - j + "");
      paramCustomMyProgressBar.setRightText(UseStringUtils.getStr(2131296495, arrayOfString));
      if ("无等级".equals(str1))
        str1 = "";
      paramCustomMyProgressBar.setLeftText(str1);
      return;
      str2 = FitApplication.headModel.differDuration;
      break;
      k = Integer.valueOf(FitApplication.headModel.lastTrainDuration).intValue();
      break label184;
      m = j - k;
      break label194;
      n = i - k;
      break label232;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.TrainHeader
 * JD-Core Version:    0.6.0
 */