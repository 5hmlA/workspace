package com.sportq.fit.business.train.activity;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.common.utils.superView.REditText;
import com.sportq.fit.common.utils.superView.RTextView;

public class BindPhoneActivity$$ViewBinder<T extends BindPhoneActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.editPhoneNum = ((REditText)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755520, "field 'editPhoneNum'"), 2131755520, "field 'editPhoneNum'"));
    paramT.editVerificationCode = ((REditText)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755521, "field 'editVerificationCode'"), 2131755521, "field 'editVerificationCode'"));
    paramT.getVerificationCode = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755522, "field 'getVerificationCode'"), 2131755522, "field 'getVerificationCode'"));
    paramT.editPassword = ((REditText)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755523, "field 'editPassword'"), 2131755523, "field 'editPassword'"));
    paramT.close_btn = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755439, "field 'close_btn'"), 2131755439, "field 'close_btn'"));
    paramT.confirmBtn = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755524, "field 'confirmBtn'"), 2131755524, "field 'confirmBtn'"));
    paramT.frame_layout = ((FrameLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755519, "field 'frame_layout'"), 2131755519, "field 'frame_layout'"));
    paramT.scrollview = ((ScrollView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755315, "field 'scrollview'"), 2131755315, "field 'scrollview'"));
  }

  public void unbind(T paramT)
  {
    paramT.editPhoneNum = null;
    paramT.editVerificationCode = null;
    paramT.getVerificationCode = null;
    paramT.editPassword = null;
    paramT.close_btn = null;
    paramT.confirmBtn = null;
    paramT.frame_layout = null;
    paramT.scrollview = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.activity.BindPhoneActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */