package com.sportq.fit.business.train.adapter;

import android.view.View;
import android.widget.RelativeLayout;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;

public class CoverRecyclerViewAdapter$NothingViewHolder$$ViewBinder<T extends CoverRecyclerViewAdapter.NothingViewHolder>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.nothingCover = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757050, "field 'nothingCover'"), 2131757050, "field 'nothingCover'"));
  }

  public void unbind(T paramT)
  {
    paramT.nothingCover = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.adapter.CoverRecyclerViewAdapter.NothingViewHolder..ViewBinder
 * JD-Core Version:    0.6.0
 */