package com.sportq.fit.business.train.widget;

import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

public class WriteTextHandler extends Handler
{
  private final CharSequence content;
  private int handlerLen;
  private int showTotalWords;
  private TextView textView;

  public WriteTextHandler(TextView paramTextView, CharSequence paramCharSequence)
  {
    this.textView = paramTextView;
    this.content = paramCharSequence;
  }

  public void handleMessage(Message paramMessage)
  {
    this.handlerLen = (-1 + this.handlerLen);
    if (this.handlerLen == 0)
    {
      this.textView.setText(this.content);
      return;
    }
    this.showTotalWords = (1 + this.showTotalWords);
    int i = Math.min(this.content.length(), this.showTotalWords);
    this.textView.setText(this.content.subSequence(0, i));
    sendEmptyMessageDelayed(1, 20L);
  }

  public void setText()
  {
    this.handlerLen = this.content.length();
    this.textView.setText("");
    removeMessages(1);
    sendEmptyMessageDelayed(1, 20L);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.WriteTextHandler
 * JD-Core Version:    0.6.0
 */