package com.sportq.fit.business.train.activity;

import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.MD5Util;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.SoftKeyBoardUtils;
import com.sportq.fit.common.utils.SoftKeyBoardUtils.SoftKeyboardStateListener;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.REditText;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.ReceiveMedalEvent;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;
import com.sportq.fit.fitmoudle.network.reformer.NeceDataUIReformer;
import com.sportq.fit.fitmoudle4.setting.eventbus.MineAccountEventBus;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.user_behavior.UserBehaviorImpl;
import java.util.concurrent.TimeUnit;
import org.greenrobot.eventbus.EventBus;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class BindPhoneActivity extends BaseActivity
{

  @Bind({2131755439})
  ImageView close_btn;

  @Bind({2131755524})
  RTextView confirmBtn;

  @Bind({2131755523})
  REditText editPassword;

  @Bind({2131755520})
  REditText editPhoneNum;

  @Bind({2131755521})
  REditText editVerificationCode;

  @Bind({2131755519})
  FrameLayout frame_layout;

  @Bind({2131755522})
  RTextView getVerificationCode;
  private String password = "";
  private boolean passwordFocus = false;
  private String phoneNum = "";

  @Bind({2131755315})
  ScrollView scrollview;
  private Subscription subscription;
  private String verCode = "";

  private void bindPhoneNum()
  {
    if (!StringUtils.checkNumber(this.phoneNum))
    {
      ToastUtils.makeToast(this, "请输入正确的手机号");
      return;
    }
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.phoneNumber = this.phoneNum;
    localRequestModel.verification = this.verCode;
    localRequestModel.password = MD5Util.MD5(this.password);
    this.dialog.createProgressDialog(this, StringUtils.getStringResources(2131299604));
    MiddleManager.getInstance().getMinePresenterImpl(this).addPhoneNumber(localRequestModel, this);
  }

  private void checkConfirmBtn()
  {
    boolean bool;
    int i;
    label84: RTextView localRTextView;
    if ((this.phoneNum.length() == 11) && (this.verCode.length() == 4) && (this.password.length() >= 6) && (this.password.length() <= 16))
    {
      bool = true;
      this.confirmBtn.setEnabled(bool);
      this.confirmBtn.getHelper().setCornerRadius(180.0F);
      RTextViewHelper localRTextViewHelper = this.confirmBtn.getHelper();
      if (!bool)
        break label125;
      i = 2131624121;
      localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this, i));
      localRTextView = this.confirmBtn;
      if (!bool)
        break label131;
    }
    label131: for (int j = 2131624003; ; j = 2131624044)
    {
      localRTextView.setTextColor(ContextCompat.getColor(this, j));
      return;
      bool = false;
      break;
      label125: i = 2131624021;
      break label84;
    }
  }

  private void initView()
  {
    this.getVerificationCode.setOnClickListener(new FitAction(this));
    this.confirmBtn.setOnClickListener(new FitAction(this));
    this.close_btn.setOnClickListener(new FitAction(this));
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        BindPhoneActivity.access$202(BindPhoneActivity.this, paramString);
        BindPhoneActivity.this.checkConfirmBtn();
      }
    }
    , this.editPhoneNum);
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        BindPhoneActivity.access$402(BindPhoneActivity.this, paramString);
        BindPhoneActivity.this.checkConfirmBtn();
      }
    }
    , this.editVerificationCode);
    this.editPassword.setOnFocusChangeListener(new View.OnFocusChangeListener()
    {
      @Instrumented
      public void onFocusChange(View paramView, boolean paramBoolean)
      {
        VdsAgent.onFocusChange(this, paramView, paramBoolean);
        BindPhoneActivity.access$002(BindPhoneActivity.this, paramBoolean);
      }
    });
    TextUtils.onTextChange(new FitInterfaceUtils.onTextChangeListener()
    {
      public void onChangeResult(String paramString)
      {
        BindPhoneActivity.access$502(BindPhoneActivity.this, paramString);
        BindPhoneActivity.this.checkConfirmBtn();
      }
    }
    , this.editPassword);
    this.confirmBtn.setEnabled(false);
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == 2131755522)
    {
      if (StringUtils.isNull(this.phoneNum))
      {
        ToastUtils.makeToast(this, StringUtils.getStringResources(2131297542));
        return;
      }
      if (!StringUtils.checkNumber(this.phoneNum))
      {
        ToastUtils.makeToast(this, StringUtils.getStringResources(2131298567));
        return;
      }
      this.dialog.createProgressDialog(this, StringUtils.getStringResources(2131299604));
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = this.phoneNum;
      new PresenterImpl(this).getNeceData(localRequestModel, this);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() == 2131755524)
      {
        bindPhoneNum();
        continue;
      }
      if (paramView.getId() != 2131755439)
        continue;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    if ((paramT instanceof String))
    {
      this.dialog.closeDialog();
      ToastUtils.makeToast(this, (String)paramT);
    }
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    if ((paramT instanceof NeceDataUIReformer))
    {
      String str = ((NeceDataUIReformer)paramT).timeKey;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = this.phoneNum;
      localRequestModel.acquisitionMode = "0";
      localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(str + NdkUtils.getSignBaseUrl()).toUpperCase();
      MiddleManager.getInstance().getLoginPresenterImpl(this).getVerification(localRequestModel, this);
    }
    LoginReformer localLoginReformer;
    do
    {
      do
        return;
      while (!(paramT instanceof LoginReformer));
      localLoginReformer = (LoginReformer)paramT;
      if (!"0".equals(localLoginReformer.tag))
        continue;
      startTimeCountdown();
      return;
    }
    while (!"1".equals(localLoginReformer.tag));
    new UserBehaviorImpl().bindPhoneNumSuccess("");
    BaseApplication.userModel.phoneNumber = this.phoneNum;
    EventBus.getDefault().post(new MineAccountEventBus("have.phone"));
    SharePreferenceUtils.putIsClickUnbindCloseBtn(this, BaseApplication.userModel.userId, "0");
    EventBus.getDefault().post(new ReceiveMedalEvent("8", this));
    ToastUtils.makeToast(this, "绑定成功");
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968662);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    initView();
    new SoftKeyBoardUtils(this.frame_layout).addSoftKeyboardStateListener(new SoftKeyBoardUtils.SoftKeyboardStateListener()
    {
      public void onSoftKeyboardClosed()
      {
      }

      public void onSoftKeyboardOpened(int paramInt)
      {
        new Handler().post(new Runnable()
        {
          public void run()
          {
            if (BindPhoneActivity.this.passwordFocus)
              BindPhoneActivity.this.scrollview.fullScroll(130);
          }
        });
      }
    });
  }

  protected void onDestroy()
  {
    EventBus.getDefault().post("close.bind.phone");
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  public void startTimeCountdown()
  {
    this.getVerificationCode.setClickable(false);
    this.getVerificationCode.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this, 2131624006));
    this.getVerificationCode.getHelper().setBorderColorNormal(ContextCompat.getColor(this, 2131624006));
    this.getVerificationCode.getHelper().setCornerRadius(180.0F);
    this.getVerificationCode.setText(String.valueOf("60s"));
    this.getVerificationCode.setTextColor(ContextCompat.getColor(this, 2131624328));
    this.subscription = Observable.interval(1L, TimeUnit.SECONDS).take(61).onBackpressureBuffer().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1()
    {
      public void call(Long paramLong)
      {
        if (paramLong.longValue() == 60L)
        {
          if (BindPhoneActivity.this.subscription != null)
          {
            BindPhoneActivity.this.subscription.unsubscribe();
            BindPhoneActivity.access$102(BindPhoneActivity.this, null);
          }
          BindPhoneActivity.this.getVerificationCode.setClickable(true);
          BindPhoneActivity.this.getVerificationCode.getHelper().setBorderColorNormal(ContextCompat.getColor(BindPhoneActivity.this, 2131624121));
          BindPhoneActivity.this.getVerificationCode.getHelper().setBackgroundColorNormal(ContextCompat.getColor(BindPhoneActivity.this, 17170445));
          BindPhoneActivity.this.getVerificationCode.getHelper().setCornerRadius(180.0F);
          BindPhoneActivity.this.getVerificationCode.setText("重获验证码");
          BindPhoneActivity.this.getVerificationCode.setTextColor(ContextCompat.getColor(BindPhoneActivity.this, 2131624121));
          return;
        }
        BindPhoneActivity.this.getVerificationCode.setText(String.valueOf(59L - paramLong.longValue() + "s"));
      }
    });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.activity.BindPhoneActivity
 * JD-Core Version:    0.6.0
 */