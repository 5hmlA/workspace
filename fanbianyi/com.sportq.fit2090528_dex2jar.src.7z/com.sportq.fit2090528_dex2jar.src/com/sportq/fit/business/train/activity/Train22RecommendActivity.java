package com.sportq.fit.business.train.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.mine.activity.Mine03WebUrlActivity;
import com.sportq.fit.business.train.adapter.FitTrainRecomAdapter;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.Find27ItemChangeEvent;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.train.TrainPresenterInterface;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.WelcomeModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.QuestionnaireReformer;
import com.sportq.fit.common.reformer.RecommendReformer;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.setting.activity.Mine03FitnessGoalsActivity;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.persenter.AppPresenterImpl;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Train22RecommendActivity extends BaseActivity
{
  private ArrayList<WelcomeModel> adList;

  @Bind({2131757590})
  ImageView ad_recommend_close_btn;

  @Bind({2131757589})
  ImageView ad_recommend_img;

  @Bind({2131757588})
  RelativeLayout ad_recommend_layout;
  private FitTrainRecomAdapter adapter = null;

  @Bind({2131757586})
  TextView basics;
  private ArrayList<PlanModel> dataList;

  @Bind({2131757584})
  TextView goal;
  private ArrayList<PlanModel> planList;

  @Bind({2131757587})
  RTextView recom_change;

  @Bind({2131755432})
  CustomToolBar toolbar;

  @Bind({2131757591})
  ListView train22RecyclerView;

  public void fitOnClick(View paramView)
  {
    try
    {
      int i = paramView.getId();
      switch (i)
      {
      default:
      case 2131757590:
        while (true)
        {
          super.fitOnClick(paramView);
          return;
          if (this.adList == null)
            continue;
          MiddleManager.getInstance().getRegisterPresenterImpl(this).statsFitAdClick("0", ((WelcomeModel)this.adList.get(0)).adId, "1", "5", "");
          this.adList.remove(0);
          if (this.adList.size() <= 0)
            break;
          GlideUtils.loadCacheImg(this, ((WelcomeModel)this.adList.get(0)).useUrl, this.ad_recommend_img);
        }
      case 2131757589:
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        LogUtils.e(localException);
        continue;
        this.ad_recommend_layout.setVisibility(8);
        continue;
        if (StringUtils.isNull(((WelcomeModel)this.adList.get(0)).adUrl))
          continue;
        MiddleManager.getInstance().getRegisterPresenterImpl(this).statsFitAdClick("1", ((WelcomeModel)this.adList.get(0)).adId, "1", "5", "");
        Intent localIntent = new Intent(this, Mine03WebUrlActivity.class);
        localIntent.putExtra("webUrl", ((WelcomeModel)this.adList.get(0)).adUrl);
        localIntent.putExtra("share.flg", "13");
        startActivity(localIntent);
        AnimationUtil.pageJumpAnim(this, 0);
      }
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    RecommendReformer localRecommendReformer = (RecommendReformer)paramT;
    this.dataList = new ArrayList();
    if ((localRecommendReformer._individualArray != null) && (!localRecommendReformer._individualArray.isEmpty()))
      this.dataList.addAll(localRecommendReformer._individualArray);
    this.planList = localRecommendReformer._planArray;
    if ((this.planList == null) || (this.planList.size() == 0));
    for (int i = 0; ; i = this.planList.size())
    {
      this.adapter = new FitTrainRecomAdapter(this, i + this.dataList.size(), "recommd.foryou", localRecommendReformer._customType, localRecommendReformer);
      this.adapter.setDataList(this.dataList);
      this.adapter.setPlanList(this.planList);
      this.train22RecyclerView.setAdapter(this.adapter);
      String str1 = FitApplication.quReformer.getCustomizedTargetName(FitApplication.userModel.fitGoal);
      String str2 = FitApplication.quReformer.getCustomizedDifficultName(FitApplication.userModel.fitBase);
      this.goal.setText(str1);
      this.basics.setText(str2);
      return;
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969165);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.toolbar.setTitle(2131299108);
    this.toolbar.setNavIcon(2130903080);
    this.toolbar.setToolbarBg(2131624328);
    this.toolbar.setToolbarTitleColor(2131624003);
    setSupportActionBar(this.toolbar);
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.flg = "0";
    FitApplication.isRefresh = true;
    new AppPresenterImpl(this).getRecommendInfo(this, localRequestModel);
    this.recom_change.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(Train22RecommendActivity.this, Mine03FitnessGoalsActivity.class);
        Train22RecommendActivity.this.startActivity(localIntent);
        AnimationUtil.pageJumpAnim(Train22RecommendActivity.this, 0);
      }
    });
    this.adList = MiddleManager.getInstance().getLoginPresenterImpl(this).getAdRecommendData(this);
    if ((this.adList != null) && (this.adList.size() > 0))
    {
      this.ad_recommend_layout.setVisibility(0);
      this.ad_recommend_close_btn.setOnClickListener(new FitAction(this));
      this.ad_recommend_img.setOnClickListener(new FitAction(this));
      LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)this.ad_recommend_layout.getLayoutParams();
      localLayoutParams.height = (int)(0.2778D * BaseApplication.screenWidth);
      this.ad_recommend_layout.setLayoutParams(localLayoutParams);
      GlideUtils.loadCacheImg(this, ((WelcomeModel)this.adList.get(0)).useUrl, this.ad_recommend_img);
      return;
    }
    this.ad_recommend_layout.setVisibility(8);
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    ButterKnife.unbind(this);
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(Find27ItemChangeEvent paramFind27ItemChangeEvent)
  {
    if (paramFind27ItemChangeEvent != null);
    try
    {
      if (this.dataList != null)
      {
        Iterator localIterator = this.dataList.iterator();
        while (localIterator.hasNext())
        {
          PlanModel localPlanModel = (PlanModel)localIterator.next();
          if (!localPlanModel.planId.equals(paramFind27ItemChangeEvent.planId))
            continue;
          localPlanModel.planStateCode = paramFind27ItemChangeEvent.stateCode;
        }
        if (this.adapter != null)
        {
          this.adapter.setDataList(this.dataList);
          this.adapter.notifyDataSetChanged();
        }
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("Video01Activity.videoPlayFinish".equals(paramString))
      finish();
    do
      return;
    while (!"goal.basics.revise".equals(paramString));
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.flg = "0";
    FitApplication.isRefresh = true;
    MiddleManager.getInstance().getTrainPresenterImpl(this).getRecommendInfo(localRequestModel, this);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  protected void onResume()
  {
    try
    {
      String str1 = PreferencesTools.getValueToKey("jionexitplan", "jionexitkey");
      PlanModel localPlanModel;
      if (!StringUtils.isNull(str1))
      {
        String[] arrayOfString = str1.split("-");
        String str2 = arrayOfString[0];
        if ((!StringUtils.isNull(str2)) && (this.planList != null) && (-1 + this.planList.size() >= Integer.valueOf(str2).intValue()) && (!String.valueOf(arrayOfString[1]).equals(((PlanModel)this.planList.get(Integer.valueOf(str2).intValue())).planStateCode)))
        {
          ((PlanModel)this.planList.get(Integer.valueOf(str2).intValue())).planStateCode = arrayOfString[1];
          localPlanModel = (PlanModel)this.planList.get(Integer.valueOf(str2).intValue());
          if (!"0".equals(arrayOfString[1]))
            break label185;
        }
      }
      label185: for (String str3 = ""; ; str3 = "已参加")
      {
        localPlanModel.planState = str3;
        this.adapter.notifyDataSetChanged();
        PreferencesTools.delValueToTable("jionexitplan", "jionexitkey");
        super.onResume();
        return;
      }
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.activity.Train22RecommendActivity
 * JD-Core Version:    0.6.0
 */