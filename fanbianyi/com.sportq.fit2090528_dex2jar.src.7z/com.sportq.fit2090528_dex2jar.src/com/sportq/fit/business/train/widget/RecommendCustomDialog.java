package com.sportq.fit.business.train.widget;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.view.View;
import android.widget.FrameLayout.LayoutParams;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.MainToastEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle7.customize.activity.CustomStartActivity;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;

public class RecommendCustomDialog
{
  private Context mContext;

  public RecommendCustomDialog(Context paramContext)
  {
    this.mContext = paramContext;
  }

  public void createDialog()
  {
    Dialog localDialog = DialogManager.guide_Dialog(this.mContext, 2130969088, 1);
    localDialog.findViewById(2131755365).setOnClickListener(new FitAction(null, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        super.onClick(paramView);
        this.val$guideDialog.dismiss();
      }
    });
    localDialog.findViewById(2131757186).setOnClickListener(new FitAction(null, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        super.onClick(paramView);
        Intent localIntent = new Intent(RecommendCustomDialog.this.mContext, CustomStartActivity.class);
        localIntent.putExtra("custom_hascusflag", "0");
        localIntent.putExtra("custom_hasHistoryFlag", "0");
        RecommendCustomDialog.this.mContext.startActivity(localIntent);
        this.val$guideDialog.dismiss();
      }
    });
    localDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
    {
      public void onDismiss(DialogInterface paramDialogInterface)
      {
        EventBus.getDefault().post(new MainToastEvent(2));
      }
    });
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams((int)(0.903D * BaseApplication.screenWidth), (int)(1.18D * BaseApplication.screenWidth));
    localDialog.findViewById(2131756313).setLayoutParams(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.widget.RecommendCustomDialog
 * JD-Core Version:    0.6.0
 */