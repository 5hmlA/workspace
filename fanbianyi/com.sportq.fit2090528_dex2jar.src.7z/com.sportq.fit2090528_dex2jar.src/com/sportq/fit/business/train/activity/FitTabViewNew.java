package com.sportq.fit.business.train.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import cn.iwgang.countdownview.CountdownView;
import cn.iwgang.countdownview.CountdownView.OnCountdownEndListener;
import com.airbnb.lottie.LottieAnimationView;
import com.growingio.android.sdk.collection.GrowingIO;
import com.sportq.fit.business.BaseNavView;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.NavMainActivity;
import com.sportq.fit.business.mine.activity.Mine03WebUrlActivity;
import com.sportq.fit.business.train.adapter.CoverRecyclerViewAdapter;
import com.sportq.fit.business.train.adapter.CoverRecyclerViewAdapter.CoverViewOnClickListener;
import com.sportq.fit.business.train.adapter.FitAdapterNew02;
import com.sportq.fit.business.train.widget.TrainHeader;
import com.sportq.fit.business.train.widget.WriteTextHandler;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.CheckRedPointUtils;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.event.CountDownFinishEvent;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.model.CurriculumModel;
import com.sportq.fit.common.model.HeadModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.WelcomeModel;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.common.reformer.SystemTimeReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.widget.FeedRootRecyclerView;
import com.sportq.fit.fitmoudle.widget.NoScrollViewPager;
import com.sportq.fit.fitmoudle10.organize.activity.TrainRecordsActivity;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.NoResultReformer;
import com.sportq.fit.manager.viewcompmanager.suspensionbox.CustomMyProgressBar;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.persenter.AppPresenterImpl;
import com.sportq.fit.persenter.model.NewBiesModel;
import com.sportq.fit.persenter.trainreformer.TrainTabReformer;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.ApiImpl.OnResJsonListener;
import com.sportq.fit.v25.design.AppBarLayout;
import com.sportq.fit.v25.design.AppBarLayout.OnOffsetChangedListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;

public class FitTabViewNew extends BaseNavView
  implements CoverRecyclerViewAdapter.CoverViewOnClickListener, CountdownView.OnCountdownEndListener, ApiImpl.OnResJsonListener
{
  private AppBarLayout appBarLayout;
  boolean closeHeaderFlg = false;
  private CollapsingToolbarLayoutState collapsingToolbarLayoutState;
  private CoverRecyclerViewAdapter coverViewAdapter;
  private DialogInterface dialog;
  public FitAdapterNew02 fitAdapterNew;
  private TrainHeader fitTabViewTrainAccording;
  private CustomMyProgressBar head_cm_progressbar;
  private String isHasPhy = "1";
  private Context mContext;
  private LottieAnimationView newbies_img;
  private RelativeLayout newbies_layout;
  private AppBarLayout.OnOffsetChangedListener onOffsetChangedListener = new AppBarLayout.OnOffsetChangedListener()
  {
    public void onOffsetChanged(AppBarLayout paramAppBarLayout, int paramInt)
    {
      if (paramInt == 0)
      {
        if (FitTabViewNew.this.collapsingToolbarLayoutState != FitTabViewNew.CollapsingToolbarLayoutState.EXPANDED)
          FitTabViewNew.access$302(FitTabViewNew.this, FitTabViewNew.CollapsingToolbarLayoutState.EXPANDED);
        FitTabViewNew.this.recyclerView_CoverView.setVisibility(0);
      }
      while (true)
      {
        float f = Math.abs(Float.valueOf(paramInt).floatValue()) / paramAppBarLayout.getTotalScrollRange();
        if (FitTabViewNew.this.coverViewAdapter != null)
          FitTabViewNew.this.coverViewAdapter.setCoverAlpha((float)(0.6D * (1.0F - f)));
        if ((f == 1.0D) && (FitTabViewNew.this.recyclerView.getChildCount() > 0) && (FitTabViewNew.this.recyclerView.getChildAt(0).getTop() == 0) && (((NavMainActivity)FitTabViewNew.this.mContext).view_pager.getCurrentItem() == 0) && (FitTabViewNew.this.viewPagerState == 0))
          EventBus.getDefault().post("show.medal.dialog");
        int i = (int)(Math.abs(Float.valueOf(paramInt).floatValue()) * CompDeviceInfoUtils.convertOfDip(FitTabViewNew.this.mContext, 22.0F) / paramAppBarLayout.getTotalScrollRange());
        RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)FitTabViewNew.this.head_cm_progressbar.getLayoutParams();
        localLayoutParams.setMargins(0, i - CompDeviceInfoUtils.convertOfDip(FitTabViewNew.this.mContext, 22.0F), 0, 0);
        FitTabViewNew.this.head_cm_progressbar.setLayoutParams(localLayoutParams);
        return;
        if (Math.abs(paramInt) >= paramAppBarLayout.getTotalScrollRange())
        {
          if (FitTabViewNew.this.collapsingToolbarLayoutState != FitTabViewNew.CollapsingToolbarLayoutState.COLLAPSED)
            FitTabViewNew.access$302(FitTabViewNew.this, FitTabViewNew.CollapsingToolbarLayoutState.COLLAPSED);
          FitTabViewNew.this.recyclerView_CoverView.setVisibility(8);
          FitTabViewNew.this.showPhysical();
          continue;
        }
        if (FitTabViewNew.this.collapsingToolbarLayoutState != FitTabViewNew.CollapsingToolbarLayoutState.INTERNEDIATE)
          FitTabViewNew.access$302(FitTabViewNew.this, FitTabViewNew.CollapsingToolbarLayoutState.INTERNEDIATE);
        FitTabViewNew.this.recyclerView_CoverView.setVisibility(0);
      }
    }
  };
  public FeedRootRecyclerView recyclerView;
  private RecyclerView recyclerView_CoverView;
  private String strReloadAlbumDataTag;
  public SystemTimeReformer systemReformer;
  private TrainTabReformer trainTabReformer;
  private WelcomeModel trainWelcome;
  private ImageView unread_point;
  public int viewPagerState;

  public FitTabViewNew(Context paramContext)
  {
    super(paramContext);
  }

  public FitTabViewNew(Context paramContext, DialogInterface paramDialogInterface)
  {
    super(paramContext);
    GrowingIO.getInstance().setPageVariable((AppCompatActivity)paramContext, "page_name", "训练");
    this.mContext = paramContext;
    this.dialog = paramDialogInterface;
    addView(onCreateView());
    this.trainWelcome = MiddleManager.getInstance().getLoginPresenterImpl(null).getAdTrainTabData(this.mContext);
  }

  private void addBubbleGuide(View paramView)
  {
    new Handler().postDelayed(new Runnable(paramView)
    {
      public void run()
      {
        if (!StringUtils.isNull(FitTabViewNew.this.trainTabReformer.entNewGift.popContent))
        {
          RelativeLayout localRelativeLayout = (RelativeLayout)LayoutInflater.from(FitTabViewNew.this.getContext()).inflate(2130969036, null);
          ((RelativeLayout)this.val$rootView).addView(localRelativeLayout);
          ((RelativeLayout.LayoutParams)localRelativeLayout.getLayoutParams()).topMargin = CompDeviceInfoUtils.convertOfDip(FitTabViewNew.this.getContext(), 48.0F);
          ((RelativeLayout.LayoutParams)localRelativeLayout.getLayoutParams()).leftMargin = CompDeviceInfoUtils.convertOfDip(FitTabViewNew.this.getContext(), 35.0F);
          AlphaAnimation localAlphaAnimation = new AlphaAnimation(0.0F, 1.0F);
          localAlphaAnimation.setDuration(800L);
          localRelativeLayout.startAnimation(localAlphaAnimation);
          ScaleAnimation localScaleAnimation = new ScaleAnimation(0.0F, 1.0F, 0.0F, 1.0F, 1, 0.0F, 1, 0.0F);
          localScaleAnimation.setDuration(800L);
          localRelativeLayout.startAnimation(localScaleAnimation);
          RTextView localRTextView = (RTextView)localRelativeLayout.findViewById(2131757047);
          localRTextView.setMaxWidth((int)(0.5555D * BaseApplication.screenWidth));
          localRTextView.setText(FitTabViewNew.this.trainTabReformer.entNewGift.popContent);
          new Handler().postDelayed(new Runnable(localRelativeLayout)
          {
            public void run()
            {
              if (!StringUtils.isNull(FitTabViewNew.this.trainTabReformer.entNewGift.popContent))
              {
                new WriteTextHandler((TextView)this.val$bubble_layout.findViewById(2131757048), FitTabViewNew.this.trainTabReformer.entNewGift.popContent).setText();
                new Handler().postDelayed(new Runnable()
                {
                  public void run()
                  {
                    if (!StringUtils.isNull(FitTabViewNew.this.trainTabReformer.entNewGift.popContent))
                      ((RelativeLayout)FitTabViewNew.1.this.val$rootView).removeView(FitTabViewNew.1.1.this.val$bubble_layout);
                  }
                }
                , 3000L);
              }
            }
          }
          , 1200L);
        }
      }
    }
    , 2000L);
  }

  private void showPhysical()
  {
    if (("0".equals(this.isHasPhy)) && (FitApplication.headModel != null) && (StringUtils.string2Int(FitApplication.headModel.trainDuration) != 0) && (!AppSharePreferenceUtils.getPhysicalCloseBtnClick()))
      if ((this.fitAdapterNew != null) && (!this.fitAdapterNew.isShowPhyView()))
      {
        this.fitAdapterNew.setPhysicalTestView(null);
        this.recyclerView.scrollToPosition(0);
      }
    do
      return;
    while ((AppSharePreferenceUtils.getTrainTabAdCloseBtnClick()) || (this.trainWelcome == null) || (this.fitAdapterNew == null) || (this.fitAdapterNew.isShowPhyView()));
    this.fitAdapterNew.setPhysicalTestView(this.trainWelcome);
    this.recyclerView.scrollToPosition(0);
  }

  public void closeHeader()
  {
    if ((this.appBarLayout != null) && (!this.closeHeaderFlg))
    {
      this.closeHeaderFlg = true;
      new Handler().postDelayed(new Runnable()
      {
        public void run()
        {
          if (FitTabViewNew.this.appBarLayout != null)
            FitTabViewNew.this.appBarLayout.setExpanded(false);
        }
      }
      , 1000L);
    }
  }

  public void countDownEndRefresh(CountDownFinishEvent paramCountDownFinishEvent)
  {
    try
    {
      if (this.fitAdapterNew != null)
      {
        ArrayList localArrayList = this.fitAdapterNew.getIndivList();
        Iterator localIterator = localArrayList.iterator();
        while (localIterator.hasNext())
        {
          PlanModel localPlanModel = (PlanModel)localIterator.next();
          if (!localPlanModel.planId.equals(paramCountDownFinishEvent.planId))
            continue;
          localPlanModel.restTime = "";
        }
        this.fitAdapterNew.setIndivList(localArrayList);
        this.fitAdapterNew.notifyDataSetChanged();
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void coverViewOnClick()
  {
    if (this.collapsingToolbarLayoutState == CollapsingToolbarLayoutState.EXPANDED)
      this.appBarLayout.setExpanded(false);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    case 2131756193:
    case 2131756195:
    case 2131756196:
    default:
    case 2131756192:
    case 2131756197:
    case 2131756194:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      this.appBarLayout.setExpanded(false);
      continue;
      Intent localIntent = new Intent(this.mContext, TrainRecordsActivity.class);
      this.mContext.startActivity(localIntent);
      AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
      continue;
      jumpNewbiesActivity();
    }
  }

  public <T> void getDataFail(T paramT)
  {
    if ((paramT instanceof String))
      ToastUtils.makeToast(this.mContext, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    try
    {
      if ((paramT instanceof NoResultReformer))
        return;
      if ((paramT instanceof PlanRecommendReformer))
      {
        initUI();
        return;
      }
    }
    catch (Exception localException1)
    {
      LogUtils.e(localException1);
      return;
    }
    if ((paramT instanceof SystemTimeReformer))
      this.systemReformer = ((SystemTimeReformer)paramT);
    String str1;
    long l1;
    label229: PlanModel localPlanModel;
    long l3;
    while (true)
    {
      if ("no.refresh".equals(this.strReloadAlbumDataTag))
        break label782;
      if ((this.trainTabReformer == null) || (StringUtils.isNull(this.trainTabReformer.orderNumber)))
        break label791;
      if (FitApplication.headModel != null)
      {
        this.fitTabViewTrainAccording.setHeaderData(this.head_cm_progressbar);
        Handler localHandler = new Handler();
        2 local2 = new Runnable()
        {
          public void run()
          {
            FitTabViewNew.this.fitTabViewTrainAccording.onShowTrainData();
          }
        };
        localHandler.postDelayed(local2, 1000L);
      }
      UserModel localUserModel = BaseApplication.userModel;
      if (!"0".equals(this.trainTabReformer.customizeInfo.stateCode))
        break label792;
      str1 = "0";
      localUserModel.orderf = str1;
      AppSharePreferenceUtils.putZeroNum(this.trainTabReformer.customizeInfo.zeroNum);
      AppSharePreferenceUtils.putZeroLink(this.trainTabReformer.customizeInfo.zeroLink);
      if ((this.fitAdapterNew != null) && (this.systemReformer == null))
        break label791;
      l1 = SystemClock.elapsedRealtime();
      if (this.trainTabReformer.lstMine == null)
        break;
      Iterator localIterator = this.trainTabReformer.lstMine.iterator();
      while (true)
      {
        if (!localIterator.hasNext())
          break label400;
        localPlanModel = (PlanModel)localIterator.next();
        if (StringUtils.isNull(localPlanModel.effectTime))
          continue;
        if (this.systemReformer == null)
        {
          localPlanModel.restTime = "";
          continue;
          if (!(paramT instanceof TrainTabReformer))
            break;
          this.trainTabReformer = ((TrainTabReformer)paramT);
          if (this.trainTabReformer.entNewGift != null)
            BaseApplication.giftShowFlag = this.trainTabReformer.entNewGift.flag;
          LogUtils.e("训练数据---", "返回");
          break;
        }
      }
      long l2 = Long.valueOf(DateUtils.date2TimeStamp(this.systemReformer.timeKey, "yyyy-MM-dd HH:mm:ss")).longValue();
      l3 = Long.valueOf(DateUtils.date2TimeStamp(localPlanModel.effectTime, "yyyy-MM-dd HH:mm:ss")).longValue() - l2;
      if (l3 <= 0L)
        break label799;
    }
    label400: label791: label792: label799: for (String str3 = String.valueOf(l1 + l3); ; str3 = "")
    {
      localPlanModel.restTime = str3;
      break label229;
      if (this.fitAdapterNew == null)
      {
        this.fitAdapterNew = new FitAdapterNew02(this.mContext);
        this.fitAdapterNew.setListener(this, this);
        this.fitAdapterNew.setData(this.trainTabReformer);
        this.recyclerView.addItemDecoration(this.fitAdapterNew.getFitItemDecoration());
        this.recyclerView.setAdapter(this.fitAdapterNew);
        LogUtils.e("训练Tab：", "刷新");
        CoverRecyclerViewAdapter localCoverRecyclerViewAdapter = new CoverRecyclerViewAdapter(this.mContext, this);
        this.coverViewAdapter = localCoverRecyclerViewAdapter;
        this.recyclerView_CoverView.setAdapter(this.coverViewAdapter);
        if ((this.trainTabReformer.entNewGift == null) || (!Constant.STR_1.equals(this.trainTabReformer.entNewGift.flag)))
          break label753;
        if (StringUtils.isNull(AppSharePreferenceUtils.getNewbiesDialogGuideTag(getContext())))
          AppSharePreferenceUtils.putNewbiesDialogGuideTag(getContext(), "show");
        this.newbies_layout.setVisibility(0);
        this.newbies_img.setAnimation("newbies_anim.json");
        this.newbies_img.loop(true);
        this.newbies_img.playAnimation();
        boolean bool = StringUtils.isNull(this.trainTabReformer.entNewGift.popContent);
        if (bool);
      }
      while (true)
      {
        try
        {
          String str2 = AppSharePreferenceUtils.getNewbiesBubbleTag(BaseApplication.appliContext);
          if (StringUtils.isNull(str2))
            continue;
          Date localDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).parse(str2);
          if (Math.abs(new Date().getTime() - localDate.getTime()) / 1000L / 60L < 1440L)
            continue;
          AppSharePreferenceUtils.putNewbiesBubbleTag(BaseApplication.appliContext, DateUtils.getStrCurrentTime());
          addBubbleGuide(this);
          this.systemReformer = null;
          return;
          this.fitAdapterNew.setData(this.trainTabReformer);
          this.fitAdapterNew.notifyDataSetChanged();
          break;
          AppSharePreferenceUtils.putNewbiesBubbleTag(BaseApplication.appliContext, DateUtils.getStrCurrentTime());
          addBubbleGuide(this);
          continue;
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
          continue;
        }
        label753: this.newbies_layout.setVisibility(8);
        if (!this.newbies_img.isAnimating())
          continue;
        this.newbies_img.clearAnimation();
      }
      LogUtils.e("训练Tab：", "不做刷新");
      return;
      str1 = "1";
      break;
    }
  }

  public void initUI()
  {
    if ("login".equals(SharePreferenceUtils.getLoginStatus(this.mContext)))
    {
      AppPresenterImpl localAppPresenterImpl = new AppPresenterImpl(this);
      ((ApiImpl)localAppPresenterImpl.getApi()).setOnResJsonListener(this);
      localAppPresenterImpl.getTrainTab(this.mContext);
    }
  }

  public void jumpNewbiesActivity()
  {
    Intent localIntent = new Intent(getContext(), Mine03WebUrlActivity.class);
    localIntent.putExtra("webUrl", VersionUpdateCheck.WEB_ADDRESS + "h5/newUser2019");
    this.mContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)getContext(), 0);
  }

  public View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(2130968853, null);
    this.recyclerView = ((FeedRootRecyclerView)localView.findViewById(2131756191));
    this.recyclerView_CoverView = ((RecyclerView)localView.findViewById(2131756192));
    this.fitTabViewTrainAccording = ((TrainHeader)localView.findViewById(2131756190));
    this.fitTabViewTrainAccording.init(this.mContext);
    this.appBarLayout = ((AppBarLayout)localView.findViewById(2131756188));
    ((RelativeLayout)localView.findViewById(2131756197)).setOnClickListener(new FitAction(this));
    this.newbies_layout = ((RelativeLayout)localView.findViewById(2131756194));
    this.newbies_layout.setOnClickListener(new FitAction(this));
    this.newbies_img = ((LottieAnimationView)localView.findViewById(2131756195));
    this.head_cm_progressbar = ((CustomMyProgressBar)localView.findViewById(2131756193));
    RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)this.head_cm_progressbar.getLayoutParams();
    localLayoutParams.setMargins(0, -CompDeviceInfoUtils.convertOfDip(this.mContext, 22.0F), 0, 0);
    this.head_cm_progressbar.setLayoutParams(localLayoutParams);
    this.unread_point = ((ImageView)localView.findViewById(2131756199));
    this.appBarLayout.addOnOffsetChangedListener(this.onOffsetChangedListener);
    this.recyclerView.setLayoutManager(new LinearLayoutManager(this.mContext));
    DefaultItemAnimator localDefaultItemAnimator = new DefaultItemAnimator();
    localDefaultItemAnimator.setAddDuration(1500L);
    this.recyclerView.setItemAnimator(localDefaultItemAnimator);
    this.recyclerView_CoverView.setLayoutManager(new LinearLayoutManager(this.mContext));
    setUnreadPointState(CheckRedPointUtils.isTrainingRecords());
    return localView;
  }

  public void onEnd(CountdownView paramCountdownView)
  {
    if ((paramCountdownView != null) && (paramCountdownView.getTag() != null))
      EventBus.getDefault().post(new CountDownFinishEvent(paramCountdownView.getTag().toString()));
  }

  public <T> void onRefresh(T paramT)
  {
    initUI();
  }

  public void onResJson(String paramString)
  {
    if (StringUtils.isNull(String.valueOf(this.recyclerView.getTag())))
    {
      this.recyclerView.setTag(paramString);
      return;
    }
    if (String.valueOf(this.recyclerView.getTag()).equals(paramString))
    {
      this.strReloadAlbumDataTag = "no.refresh";
      return;
    }
    this.strReloadAlbumDataTag = null;
    this.recyclerView.setTag(paramString);
  }

  public void setIsHasPhy(String paramString)
  {
    this.isHasPhy = paramString;
    if (this.collapsingToolbarLayoutState == CollapsingToolbarLayoutState.COLLAPSED)
      showPhysical();
  }

  public void setUnreadPointState(boolean paramBoolean)
  {
    ImageView localImageView = this.unread_point;
    if (paramBoolean);
    for (int i = 0; ; i = 8)
    {
      localImageView.setVisibility(i);
      return;
    }
  }

  private static enum CollapsingToolbarLayoutState
  {
    static
    {
      COLLAPSED = new CollapsingToolbarLayoutState("COLLAPSED", 1);
      INTERNEDIATE = new CollapsingToolbarLayoutState("INTERNEDIATE", 2);
      CollapsingToolbarLayoutState[] arrayOfCollapsingToolbarLayoutState = new CollapsingToolbarLayoutState[3];
      arrayOfCollapsingToolbarLayoutState[0] = EXPANDED;
      arrayOfCollapsingToolbarLayoutState[1] = COLLAPSED;
      arrayOfCollapsingToolbarLayoutState[2] = INTERNEDIATE;
      $VALUES = arrayOfCollapsingToolbarLayoutState;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.train.activity.FitTabViewNew
 * JD-Core Version:    0.6.0
 */