package com.sportq.fit.business;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.fitmoudle.widget.NoScrollViewPager;

public class NavMainActivity$$ViewBinder<T extends NavMainActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.train_tab_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757003, "field 'train_tab_layout'"), 2131757003, "field 'train_tab_layout'"));
    paramT.find_tab_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757004, "field 'find_tab_layout'"), 2131757004, "field 'find_tab_layout'"));
    paramT.browse_tab_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757006, "field 'browse_tab_layout'"), 2131757006, "field 'browse_tab_layout'"));
    paramT.mine_tab_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756909, "field 'mine_tab_layout'"), 2131756909, "field 'mine_tab_layout'"));
    paramT.view_pager = ((NoScrollViewPager)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755321, "field 'view_pager'"), 2131755321, "field 'view_pager'"));
    paramT.train_icon = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756929, "field 'train_icon'"), 2131756929, "field 'train_icon'"));
    paramT.find_icon = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757005, "field 'find_icon'"), 2131757005, "field 'find_icon'"));
    paramT.browse_icon = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757007, "field 'browse_icon'"), 2131757007, "field 'browse_icon'"));
    paramT.mine_icon = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757008, "field 'mine_icon'"), 2131757008, "field 'mine_icon'"));
  }

  public void unbind(T paramT)
  {
    paramT.train_tab_layout = null;
    paramT.find_tab_layout = null;
    paramT.browse_tab_layout = null;
    paramT.mine_tab_layout = null;
    paramT.view_pager = null;
    paramT.train_icon = null;
    paramT.find_icon = null;
    paramT.browse_icon = null;
    paramT.mine_icon = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.NavMainActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */