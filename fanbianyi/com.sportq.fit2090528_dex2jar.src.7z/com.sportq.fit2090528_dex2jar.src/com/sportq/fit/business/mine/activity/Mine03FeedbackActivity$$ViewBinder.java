package com.sportq.fit.business.mine.activity;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.fitmoudle.widget.ChatEditText;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class Mine03FeedbackActivity$$ViewBinder<T extends Mine03FeedbackActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.goingWriDateEt = ((ChatEditText)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756695, "field 'goingWriDateEt'"), 2131756695, "field 'goingWriDateEt'"));
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.feednbackImgL = ((LinearLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756696, "field 'feednbackImgL'"), 2131756696, "field 'feednbackImgL'"));
    paramT.feednback_addimg = ((FrameLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756697, "field 'feednback_addimg'"), 2131756697, "field 'feednback_addimg'"));
    paramT.select_type_btn = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756694, "field 'select_type_btn'"), 2131756694, "field 'select_type_btn'"));
    paramT.select_type_layout = ((FrameLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756693, "field 'select_type_layout'"), 2131756693, "field 'select_type_layout'"));
  }

  public void unbind(T paramT)
  {
    paramT.goingWriDateEt = null;
    paramT.toolbar = null;
    paramT.feednbackImgL = null;
    paramT.feednback_addimg = null;
    paramT.select_type_btn = null;
    paramT.select_type_layout = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.Mine03FeedbackActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */