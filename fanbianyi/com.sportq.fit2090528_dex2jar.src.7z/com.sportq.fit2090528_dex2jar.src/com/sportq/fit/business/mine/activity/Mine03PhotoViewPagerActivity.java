package com.sportq.fit.business.mine.activity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils.TruncateAt;
import android.text.method.ScrollingMovementMethod;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.adapter.Mine03PhotoAdapter;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.FitnessPicItemModel;
import com.sportq.fit.common.model.FitnessPicModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.PopWindowMenu;
import com.sportq.fit.fitmoudle.dialogmanager.PopWindowMenu.OnPopViewClickListener;
import com.sportq.fit.fitmoudle.event.DelFitnessPhotoEvent;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;
import uk.co.senab.photoview.PhotoView;
import uk.co.senab.photoview.PhotoViewAttacher.OnPhotoTapListener;

public class Mine03PhotoViewPagerActivity extends BaseActivity
{
  private Mine03PhotoAdapter adapter;
  private ArrayList<FitnessPicItemModel> dataList;
  Animation down;
  Animation down_fale;
  private int index;
  private String[] itemList = { "保存", "取消" };
  private ProgressBar loader_icon;

  @Bind({2131756752})
  RTextView mine03_check_button;
  private PhotoView mine03_photo;

  @Bind({2131756748})
  TextView mine03_photo_info;

  @Bind({2131756747})
  RelativeLayout mine03_photo_info_l;

  @Bind({2131756751})
  TextView mine03_photo_train;

  @Bind({2131756749})
  LinearLayout mine_photo_weight;

  @Bind({2131756782})
  ViewPager mine_viewpager;
  private FitnessPicItemModel model;

  @Bind({2131755432})
  CustomToolBar toolbar;

  @Bind({2131755277})
  RelativeLayout toolbar_layout;
  Animation up;
  Animation up_fale;
  private UseShareModel useShareModel;
  private ArrayList<View> viewList;

  @Bind({2131756750})
  TextView weight_info;

  private String convertDate(String paramString)
  {
    try
    {
      String str1 = String.valueOf(Calendar.getInstance().get(1));
      String str2 = DateUtils.StringToFormat(String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).parse(paramString).getTime()), "yyyy年M月d日 HH:mm").replace(str1 + "年", "");
      return str2;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return "";
  }

  private void initData(int paramInt)
  {
    View localView = (View)this.viewList.get(paramInt);
    this.toolbar.setTitle(convertDate(this.model.moveTime));
    this.toolbar.setNavIcon(2130903080);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, 2131624003));
    this.toolbar.setBackgroundResource(2131624328);
    setSupportActionBar(this.toolbar);
    this.mine03_photo = ((PhotoView)localView.findViewById(2131756746));
    this.loader_icon = ((ProgressBar)localView.findViewById(2131755304));
    if (localView.getTag() == null)
    {
      RequestOptions localRequestOptions = new RequestOptions().skipMemoryCache(true).fitCenter().error(2130903536).diskCacheStrategy(DiskCacheStrategy.RESOURCE);
      Glide.with(this).load(this.model.imageURL).apply(localRequestOptions).thumbnail(0.2F).listener(new RequestListener()
      {
        public boolean onLoadFailed(@Nullable GlideException paramGlideException, Object paramObject, Target<Drawable> paramTarget, boolean paramBoolean)
        {
          return false;
        }

        public boolean onResourceReady(Drawable paramDrawable, Object paramObject, Target<Drawable> paramTarget, DataSource paramDataSource, boolean paramBoolean)
        {
          Mine03PhotoViewPagerActivity.this.loader_icon.setVisibility(8);
          return false;
        }
      }).into(this.mine03_photo);
    }
    this.mine03_photo.setOnPhotoTapListener(new PhotoViewAttacher.OnPhotoTapListener()
    {
      public void onOutsidePhotoTap()
      {
      }

      public void onPhotoTap(View paramView, float paramFloat1, float paramFloat2)
      {
        if (Mine03PhotoViewPagerActivity.this.toolbar_layout.getVisibility() == 0)
        {
          Mine03PhotoViewPagerActivity.this.toolbar_layout.startAnimation(Mine03PhotoViewPagerActivity.this.up);
          Mine03PhotoViewPagerActivity.this.mine03_photo_info_l.startAnimation(Mine03PhotoViewPagerActivity.this.up_fale);
          return;
        }
        Mine03PhotoViewPagerActivity.this.toolbar_layout.startAnimation(Mine03PhotoViewPagerActivity.this.down);
        Mine03PhotoViewPagerActivity.this.mine03_photo_info_l.startAnimation(Mine03PhotoViewPagerActivity.this.down_fale);
      }
    });
    this.mine03_check_button.setOnClickListener(new FitAction(this));
    setAnimation();
    this.useShareModel = new UseShareModel();
    this.useShareModel.shareFeeling = this.model.comment;
    this.useShareModel.shareCameraImg = this.model.imageURL;
    String str1;
    String[] arrayOfString;
    int k;
    label305: int m;
    label318: StringBuilder localStringBuilder2;
    int n;
    if (!StringUtils.isNull(this.model.trainComment))
    {
      if (!StringUtils.isNull(this.model.trainTime))
        break label491;
      str1 = "00:00";
      arrayOfString = str1.split(":");
      if (arrayOfString.length <= 2)
        break label541;
      if (!StringUtils.isNull(arrayOfString[0]))
        break label502;
      k = 0;
      if (!StringUtils.isNull(arrayOfString[1]))
        break label520;
      m = 0;
      localStringBuilder2 = new StringBuilder();
      n = k + m;
      if (!"00".equals(arrayOfString[2]))
        break label535;
    }
    String str2;
    label520: label535: for (int i1 = 0; ; i1 = 1)
    {
      str2 = i1 + n + "";
      UseShareModel localUseShareModel = this.useShareModel;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = this.model.trainComment;
      arrayOfObject[1] = str2;
      arrayOfObject[2] = this.model.calorie;
      localUseShareModel.shareInfoStr = String.format("第%s次 %s分钟 %s千卡", arrayOfObject);
      this.useShareModel.planName = this.model.planName;
      this.useShareModel.olapInfo = this.model.olapInfo;
      this.useShareModel.avgTime = this.model.moveTime;
      this.useShareModel.energyFlag = this.model.energyFlag;
      setPhotoInfo();
      localView.setTag("have.data");
      return;
      label491: str1 = this.model.trainTime;
      break;
      label502: k = 60 * Integer.valueOf(arrayOfString[0]).intValue();
      break label305;
      m = Integer.valueOf(arrayOfString[1]).intValue();
      break label318;
    }
    label541: int i;
    label554: StringBuilder localStringBuilder1;
    if (StringUtils.isNull(arrayOfString[0]))
    {
      i = 0;
      localStringBuilder1 = new StringBuilder();
      if (!"00".equals(arrayOfString[1]))
        break label617;
    }
    label617: for (int j = 0; ; j = 1)
    {
      str2 = j + i + "";
      break;
      i = Integer.valueOf(arrayOfString[0]).intValue();
      break label554;
    }
  }

  private void menuMoreClickAction()
  {
    int[] arrayOfInt = { 12, 9 };
    new PopWindowMenu(this.toolbar, arrayOfInt, this, new PopWindowMenu.OnPopViewClickListener()
    {
      public void onPopViewClick(View paramView)
      {
        switch (paramView.getId())
        {
        default:
          return;
        case 2131756598:
          Mine03PhotoViewPagerActivity.this.dialog.createDialog(new FitInterfaceUtils.DialogListener()
          {
            public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
            {
              switch (paramInt)
              {
              default:
                return;
              case 0:
                MiddleManager.getInstance().getFindPresenterImpl(Mine03PhotoViewPagerActivity.this, null).statsSaveLocalClick();
                Mine03PhotoViewPagerActivity.this.mine03_photo.setDrawingCacheEnabled(true);
                ImageUtils.saveImgToAlbum(null, Mine03PhotoViewPagerActivity.this.mine03_photo.getDrawingCache(), Mine03PhotoViewPagerActivity.this);
                ToastUtils.makeToast(Mine03PhotoViewPagerActivity.this, "图片已保存至" + Constant.STR_IMAGE_STORE_NAME + " 文件夹");
                return;
              case 1:
              }
              Mine03PhotoViewPagerActivity.this.dialog.closeDialog();
            }
          }
          , Mine03PhotoViewPagerActivity.this, Mine03PhotoViewPagerActivity.this.itemList);
          return;
        case 2131756599:
        }
        if ((Mine03PhotoViewPagerActivity.this.model != null) && (!StringUtils.isNull(Mine03PhotoViewPagerActivity.this.model.olapInfo)))
          MiddleManager.getInstance().getFindPresenterImpl(Mine03PhotoViewPagerActivity.this, null).statsTrainInfoMoreDeleteClick(Mine03PhotoViewPagerActivity.this.model.olapInfo);
        Mine03PhotoViewPagerActivity.this.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
        {
          public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
          {
            if (paramInt == -1)
            {
              if (!CompDeviceInfoUtils.checkNetwork())
                ToastUtils.makeToast(Mine03PhotoViewPagerActivity.this, StringUtils.getStringResources(2131299052));
            }
            else
              return;
            Mine03PhotoViewPagerActivity.this.dialog.createProgressDialog(Mine03PhotoViewPagerActivity.this, "请稍后...");
            RequestModel localRequestModel = new RequestModel();
            localRequestModel.histId = Mine03PhotoViewPagerActivity.this.model.historyId;
            localRequestModel.imgId = Mine03PhotoViewPagerActivity.this.model.imgId;
            MiddleManager.getInstance().getMinePresenterImpl(Mine03PhotoViewPagerActivity.this).deleteTrainPhoto(localRequestModel, Mine03PhotoViewPagerActivity.this);
          }
        }
        , Mine03PhotoViewPagerActivity.this, "", "确定要删除这张照片吗？", "删除", "取消");
      }
    });
  }

  private void setAnimation()
  {
    this.down = AnimationUtils.loadAnimation(this, 2131034157);
    this.down_fale = AnimationUtils.loadAnimation(this, 2131034158);
    this.up = AnimationUtils.loadAnimation(this, 2131034159);
    this.up_fale = AnimationUtils.loadAnimation(this, 2131034160);
    this.down.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Mine03PhotoViewPagerActivity.this.toolbar_layout.setVisibility(0);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
    this.down_fale.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Mine03PhotoViewPagerActivity.this.mine03_photo_info_l.setVisibility(0);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
    this.up.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Mine03PhotoViewPagerActivity.this.toolbar_layout.setVisibility(8);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
    this.up_fale.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Mine03PhotoViewPagerActivity.this.mine03_photo_info_l.setVisibility(8);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
  }

  private void setPhotoInfo()
  {
    int i = 8;
    TextView localTextView1 = this.mine03_photo_train;
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = this.model.planName;
    arrayOfObject[1] = this.model.trainComment;
    localTextView1.setText(String.format("完成「%s」第%s次", arrayOfObject));
    TextView localTextView2 = this.mine03_photo_train;
    int j;
    LinearLayout localLinearLayout;
    if (StringUtils.isNull(this.model.planName))
    {
      j = i;
      localTextView2.setVisibility(j);
      this.weight_info.setText(this.model.currentWeight);
      localLinearLayout = this.mine_photo_weight;
      if (!StringUtils.isNull(this.model.currentWeight))
        break label245;
    }
    while (true)
    {
      localLinearLayout.setVisibility(i);
      if ((StringUtils.isNull(this.model.planName)) && (StringUtils.isNull(this.model.currentWeight)))
        this.mine03_photo_train.setVisibility(4);
      if ((StringUtils.isNull(this.model.planName)) && (StringUtils.isNull(this.model.currentWeight)) && (StringUtils.isNull(this.model.comment)))
        this.mine03_photo_info_l.setBackgroundColor(ContextCompat.getColor(this, 2131624292));
      this.mine03_photo_info.setMaxLines(20);
      this.mine03_photo_info.setText(this.model.comment);
      this.mine03_photo_info.post(new Runnable()
      {
        public void run()
        {
          int i = 8;
          TextView localTextView;
          if (Mine03PhotoViewPagerActivity.this.mine03_photo_info.getLineCount() > 6)
          {
            Mine03PhotoViewPagerActivity.this.mine03_photo_info.setMaxLines(6);
            Mine03PhotoViewPagerActivity.this.mine03_check_button.setVisibility(0);
            localTextView = Mine03PhotoViewPagerActivity.this.mine03_photo_info;
            if (!StringUtils.isNull(Mine03PhotoViewPagerActivity.this.model.comment))
              break label85;
          }
          while (true)
          {
            localTextView.setVisibility(i);
            return;
            Mine03PhotoViewPagerActivity.this.mine03_check_button.setVisibility(i);
            break;
            label85: i = 0;
          }
        }
      });
      return;
      j = 0;
      break;
      label245: i = 0;
    }
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
      return;
    case 2131756752:
    }
    if (StringUtils.string2Int(String.valueOf(this.mine03_photo_info.getTag())) == 10)
    {
      this.mine03_photo_info.setMaxLines(6);
      this.mine03_photo_info.setTag(Integer.valueOf(6));
      this.mine03_check_button.setText(2131298986);
      this.mine03_photo_info.setMovementMethod(null);
      this.mine03_photo_info.setEllipsize(TextUtils.TruncateAt.END);
      return;
    }
    this.mine03_photo_info.setMaxLines(20);
    this.mine03_photo_info.setTag(Integer.valueOf(10));
    this.mine03_check_button.setText(2131299076);
    this.mine03_photo_info.setMovementMethod(new ScrollingMovementMethod());
    this.mine03_photo_info.setEllipsize(null);
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    EventBus.getDefault().post(new DelFitnessPhotoEvent(this.model.photoType, this.model.historyId));
    try
    {
      if (this.index == -1 + this.dataList.size());
      for (int i = -1 + this.index; i < 0; i = this.index)
      {
        finish();
        return;
      }
      this.dataList.remove(this.index);
      this.viewList = new ArrayList();
      for (int j = 0; j < this.dataList.size(); j++)
      {
        View localView = View.inflate(this, 2130968994, null);
        this.viewList.add(localView);
      }
      this.adapter = new Mine03PhotoAdapter(this.viewList);
      this.mine_viewpager.setAdapter(this.adapter);
      this.mine_viewpager.addOnPageChangeListener(new MineViewPagerListener(null));
      this.mine_viewpager.setCurrentItem(i);
      this.model = ((FitnessPicItemModel)this.dataList.get(i));
      initData(i);
      this.index = i;
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968993);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    this.dataList = new ArrayList();
    FitnessPicItemModel localFitnessPicItemModel = (FitnessPicItemModel)getIntent().getSerializableExtra("item.model");
    Iterator localIterator = ((ArrayList)getIntent().getSerializableExtra("data.list")).iterator();
    while (localIterator.hasNext())
    {
      FitnessPicModel localFitnessPicModel = (FitnessPicModel)localIterator.next();
      for (int j = 0; j < localFitnessPicModel.lstPhoto.size(); j++)
      {
        this.dataList.add(localFitnessPicModel.lstPhoto.get(j));
        if (!localFitnessPicItemModel.moveTime.equals(((FitnessPicItemModel)localFitnessPicModel.lstPhoto.get(j)).moveTime))
          continue;
        this.index = this.dataList.indexOf(localFitnessPicModel.lstPhoto.get(j));
      }
    }
    this.viewList = new ArrayList();
    for (int i = 0; i < this.dataList.size(); i++)
    {
      View localView = View.inflate(this, 2130968994, null);
      this.viewList.add(localView);
    }
    this.adapter = new Mine03PhotoAdapter(this.viewList);
    this.mine_viewpager.setAdapter(this.adapter);
    this.mine_viewpager.addOnPageChangeListener(new MineViewPagerListener(null));
    this.mine_viewpager.setCurrentItem(this.index);
    if (this.index == 0)
    {
      this.model = ((FitnessPicItemModel)this.dataList.get(this.index));
      initData(this.index);
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131820569, paramMenu);
    return true;
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    case 2131758199:
    case 2131755569:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      menuMoreClickAction();
      continue;
      if (this.useShareModel == null)
      {
        VdsAgent.handleClickResult(new Boolean(false));
        return false;
      }
      this.dialog.showShareChoiseDialog(this, 15, this.useShareModel, this.dialog);
    }
  }

  private class MineViewPagerListener
    implements ViewPager.OnPageChangeListener
  {
    private MineViewPagerListener()
    {
    }

    public void onPageScrollStateChanged(int paramInt)
    {
    }

    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
    {
    }

    public void onPageSelected(int paramInt)
    {
      if (Mine03PhotoViewPagerActivity.this.loader_icon != null)
        Mine03PhotoViewPagerActivity.this.loader_icon.setVisibility(4);
      Mine03PhotoViewPagerActivity.access$202(Mine03PhotoViewPagerActivity.this, paramInt);
      Mine03PhotoViewPagerActivity.access$302(Mine03PhotoViewPagerActivity.this, (FitnessPicItemModel)Mine03PhotoViewPagerActivity.this.dataList.get(Mine03PhotoViewPagerActivity.this.index));
      Mine03PhotoViewPagerActivity.this.initData(paramInt);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.Mine03PhotoViewPagerActivity
 * JD-Core Version:    0.6.0
 */