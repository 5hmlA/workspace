package com.sportq.fit.business.mine.activity;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class MineFitnessComPhotoActivity$$ViewBinder<T extends MineFitnessComPhotoActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.show_compare_photo_layout = ((LinearLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756836, "field 'show_compare_photo_layout'"), 2131756836, "field 'show_compare_photo_layout'"));
    paramT.compare_left_img = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756838, "field 'compare_left_img'"), 2131756838, "field 'compare_left_img'"));
    paramT.compare_right_img = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756842, "field 'compare_right_img'"), 2131756842, "field 'compare_right_img'"));
    paramT.left_img_date = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756840, "field 'left_img_date'"), 2131756840, "field 'left_img_date'"));
    paramT.right_img_date = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756844, "field 'right_img_date'"), 2131756844, "field 'right_img_date'"));
    paramT.left_img_weight = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756839, "field 'left_img_weight'"), 2131756839, "field 'left_img_weight'"));
    paramT.right_img_weight = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756843, "field 'right_img_weight'"), 2131756843, "field 'right_img_weight'"));
    paramT.apart_days_view = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756845, "field 'apart_days_view'"), 2131756845, "field 'apart_days_view'"));
    paramT.save_fitness_photo_view = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756846, "field 'save_fitness_photo_view'"), 2131756846, "field 'save_fitness_photo_view'"));
    paramT.share_to_wechatmoments = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756848, "field 'share_to_wechatmoments'"), 2131756848, "field 'share_to_wechatmoments'"));
    paramT.share_to_wechat = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756849, "field 'share_to_wechat'"), 2131756849, "field 'share_to_wechat'"));
    paramT.share_to_sina = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756850, "field 'share_to_sina'"), 2131756850, "field 'share_to_sina'"));
  }

  public void unbind(T paramT)
  {
    paramT.toolbar = null;
    paramT.show_compare_photo_layout = null;
    paramT.compare_left_img = null;
    paramT.compare_right_img = null;
    paramT.left_img_date = null;
    paramT.right_img_date = null;
    paramT.left_img_weight = null;
    paramT.right_img_weight = null;
    paramT.apart_days_view = null;
    paramT.save_fitness_photo_view = null;
    paramT.share_to_wechatmoments = null;
    paramT.share_to_wechat = null;
    paramT.share_to_sina = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.MineFitnessComPhotoActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */