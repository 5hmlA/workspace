package com.sportq.fit.business.mine.activity;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class Mine02LevelActivity$$ViewBinder<T extends Mine02LevelActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.recycler_view = ((RecyclerView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755283, "field 'recycler_view'"), 2131755283, "field 'recycler_view'"));
  }

  public void unbind(T paramT)
  {
    paramT.toolbar = null;
    paramT.recycler_view = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.Mine02LevelActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */