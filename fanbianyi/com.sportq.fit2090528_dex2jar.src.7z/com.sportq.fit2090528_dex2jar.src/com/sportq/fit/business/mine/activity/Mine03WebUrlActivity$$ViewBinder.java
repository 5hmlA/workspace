package com.sportq.fit.business.mine.activity;

import android.view.View;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class Mine03WebUrlActivity$$ViewBinder<T extends Mine03WebUrlActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.mine03FitAbout = ((WebView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756407, "field 'mine03FitAbout'"), 2131756407, "field 'mine03FitAbout'"));
    paramT.myProgressBar = ((ProgressBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756406, "field 'myProgressBar'"), 2131756406, "field 'myProgressBar'"));
    paramT.webView_layout = ((LinearLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756405, "field 'webView_layout'"), 2131756405, "field 'webView_layout'"));
  }

  public void unbind(T paramT)
  {
    paramT.toolbar = null;
    paramT.mine03FitAbout = null;
    paramT.myProgressBar = null;
    paramT.webView_layout = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.Mine03WebUrlActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */