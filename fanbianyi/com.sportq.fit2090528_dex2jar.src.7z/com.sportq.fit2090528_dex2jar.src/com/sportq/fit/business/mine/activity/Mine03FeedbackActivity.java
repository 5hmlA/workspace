package com.sportq.fit.business.mine.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.PopupWindow;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.SystemPhotoModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.SystemPhotoUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.ChatEditText;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.ImageViewDialog;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.Iterator;

public class Mine03FeedbackActivity extends BaseActivity
{
  private ArrayList<Bitmap> bitmapsList = new ArrayList();

  @Bind({2131756696})
  LinearLayout feednbackImgL;

  @Bind({2131756697})
  FrameLayout feednback_addimg;

  @Bind({2131756695})
  ChatEditText goingWriDateEt;
  private ImageViewDialog imgDialog;
  private String[] itemList = { "拍照", "相册" };
  private PopupWindow popupWindow;
  private int selectIndex = -1;

  @Bind({2131756694})
  TextView select_type_btn;

  @Bind({2131756693})
  FrameLayout select_type_layout;
  private String strPicturePath;
  private SystemPhotoUtils systemPhotoUtils;

  @Bind({2131755432})
  CustomToolBar toolbar;

  private void addImage()
  {
    this.feednbackImgL.removeAllViews();
    if (this.bitmapsList.size() < 4)
      this.feednback_addimg.setVisibility(0);
    while (true)
    {
      if (this.bitmapsList.size() < 1)
        this.feednbackImgL.setVisibility(8);
      for (int i = 0; i < this.bitmapsList.size(); i++)
      {
        this.feednbackImgL.setVisibility(0);
        View localView = LayoutInflater.from(this).inflate(2130969005, null);
        ImageView localImageView1 = (ImageView)localView.findViewById(2131756700);
        ImageView localImageView2 = (ImageView)localView.findViewById(2131756701);
        localImageView1.setImageBitmap((Bitmap)this.bitmapsList.get(i));
        localImageView2.setOnClickListener(new View.OnClickListener(i)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            Mine03FeedbackActivity.this.bitmapsList.remove(this.val$index);
            Mine03FeedbackActivity.this.addImage();
          }
        });
        localImageView1.setOnClickListener(new View.OnClickListener(i)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            Mine03FeedbackActivity.this.imgDialog.createDialog(Mine03FeedbackActivity.this.bitmapsList, this.val$imageIndex);
          }
        });
        LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, -2);
        localLayoutParams.rightMargin = CompDeviceInfoUtils.convertOfDip(this, 5.0F);
        this.feednbackImgL.addView(localView, localLayoutParams);
      }
      this.feednback_addimg.setVisibility(8);
    }
  }

  private void jumpToTakePhoto()
  {
    this.dialog.createDialog(new FitInterfaceUtils.DialogListener()
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        switch (paramInt)
        {
        default:
          return;
        case 0:
          Intent localIntent = new Intent("android.media.action.IMAGE_CAPTURE");
          localIntent.putExtra("android.intent.extra.videoQuality", 1);
          Mine03FeedbackActivity.access$602(Mine03FeedbackActivity.this, FileUtils.getPhotopath());
          localIntent.putExtra("output", FileUtils.getTakePhotoUri(Mine03FeedbackActivity.this.strPicturePath));
          localIntent.putExtra("orientation", 180);
          Mine03FeedbackActivity.this.startActivityForResult(localIntent, 1);
          return;
        case 1:
        }
        Mine03FeedbackActivity.this.systemPhotoUtils.openSystemPhoto();
      }
    }
    , this, this.itemList);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131756697:
    case 2131756693:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
      {
        public void result(boolean paramBoolean)
        {
          if (paramBoolean)
            Mine03FeedbackActivity.this.jumpToTakePhoto();
        }
      }
      , this, new String[] { "android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE" });
      continue;
      if (this.popupWindow == null)
      {
        ImageView localImageView = new ImageView(this);
        FrameLayout.LayoutParams localLayoutParams1 = new FrameLayout.LayoutParams(CompDeviceInfoUtils.convertOfDip(this, 28.0F), CompDeviceInfoUtils.convertOfDip(this, 28.0F));
        localImageView.setImageResource(2130903655);
        localImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        localLayoutParams1.gravity = 8388629;
        localLayoutParams1.rightMargin = CompDeviceInfoUtils.convertOfDip(this, 10.0F);
        localImageView.setLayoutParams(localLayoutParams1);
        LinearLayout localLinearLayout = new LinearLayout(this);
        localLinearLayout.setOrientation(1);
        localLinearLayout.setBackgroundColor(ContextCompat.getColor(this, 2131624328));
        localLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        String[] arrayOfString = { "产品建议", "定制计划", "挑战", "会员", "金牌服务（减脂营、训练营）", "课程相关（动作库等）", "看点", "其他" };
        for (int i = 0; i < arrayOfString.length; i++)
        {
          int k = i;
          FrameLayout localFrameLayout = new FrameLayout(this);
          TextView localTextView = new TextView(this);
          localTextView.setText(arrayOfString[i]);
          localTextView.setTextColor(ContextCompat.getColor(this, 2131624003));
          localTextView.setTextSize(15.0F);
          FrameLayout.LayoutParams localLayoutParams2 = new FrameLayout.LayoutParams(-2, -2);
          localLayoutParams2.gravity = 16;
          localLayoutParams2.leftMargin = CompDeviceInfoUtils.convertOfDip(this, 16.0F);
          localFrameLayout.addView(localTextView, localLayoutParams2);
          View localView = new View(this);
          localView.setBackgroundColor(ContextCompat.getColor(this, 2131624090));
          FrameLayout.LayoutParams localLayoutParams3 = new FrameLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this, 0.5F));
          localLayoutParams3.gravity = 80;
          localFrameLayout.addView(localView, localLayoutParams3);
          localLinearLayout.addView(localFrameLayout, new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this, 50.0F)));
          localFrameLayout.setOnClickListener(new View.OnClickListener(k, localLinearLayout, localImageView, arrayOfString)
          {
            @Instrumented
            public void onClick(View paramView)
            {
              VdsAgent.onClick(this, paramView);
              if (Mine03FeedbackActivity.this.selectIndex != this.val$index)
              {
                if (Mine03FeedbackActivity.this.selectIndex != -1)
                  ((FrameLayout)this.val$linearLayout.getChildAt(Mine03FeedbackActivity.this.selectIndex)).removeView(this.val$imageView);
                Mine03FeedbackActivity.access$102(Mine03FeedbackActivity.this, this.val$index);
                ((FrameLayout)this.val$linearLayout.getChildAt(Mine03FeedbackActivity.this.selectIndex)).addView(this.val$imageView);
                Mine03FeedbackActivity.this.select_type_btn.setText(this.val$contentList[this.val$index]);
              }
              Mine03FeedbackActivity.this.popupWindow.dismiss();
            }
          });
        }
        this.popupWindow = new PopupWindow(localLinearLayout, -1, -2);
        this.popupWindow.setFocusable(true);
        this.popupWindow.setBackgroundDrawable(new ColorDrawable(0));
        this.popupWindow.setOutsideTouchable(true);
        this.popupWindow.update();
      }
      PopupWindow localPopupWindow = this.popupWindow;
      CustomToolBar localCustomToolBar = this.toolbar;
      int j = CompDeviceInfoUtils.convertOfDip(this, 10.0F);
      localPopupWindow.showAsDropDown(localCustomToolBar, 0, j);
      VdsAgent.showAsDropDown((PopupWindow)localPopupWindow, localCustomToolBar, 0, j);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    ToastUtils.makeToast(this, "提交失败，请稍后尝试");
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    finish();
    ToastUtils.makeToast(this, "感谢反馈，我们会尽快处理");
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968977);
    ButterKnife.bind(this);
    this.systemPhotoUtils = new SystemPhotoUtils(this);
    this.dialog = new DialogManager();
    this.imgDialog = new ImageViewDialog(this);
    this.toolbar.setTitle(2131299018);
    this.toolbar.setNavIcon(2130903080);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, 2131624003));
    this.toolbar.setBackgroundResource(2131624328);
    setSupportActionBar(this.toolbar);
    this.feednback_addimg.setOnClickListener(new FitAction(this));
    this.goingWriDateEt.setHint(getResources().getString(2131299006));
    this.goingWriDateEt.setHeight(CompDeviceInfoUtils.convertOfDip(this, 274.0F));
    Drawable localDrawable = ContextCompat.getDrawable(this, 2130903136);
    localDrawable.setBounds(0, 0, CompDeviceInfoUtils.convertOfDip(this, 22.0F), CompDeviceInfoUtils.convertOfDip(this, 22.0F));
    this.select_type_btn.setCompoundDrawables(null, null, localDrawable, null);
    this.select_type_layout.setOnClickListener(new FitAction(this));
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    switch (paramInt1)
    {
    default:
    case 1:
    case 999:
    }
    do
    {
      Bitmap localBitmap2;
      do
      {
        return;
        localBitmap2 = ImageUtils.getImageBitmap(this.strPicturePath, 0);
      }
      while (localBitmap2 == null);
      Bitmap localBitmap3 = ImageUtils.handleCameraPhoto(localBitmap2, this.strPicturePath);
      this.bitmapsList.add(localBitmap3);
      addImage();
      return;
    }
    while (paramIntent == null);
    SystemPhotoModel localSystemPhotoModel = this.systemPhotoUtils.resultData(this, paramIntent);
    if (localSystemPhotoModel != null)
      this.strPicturePath = localSystemPhotoModel.url_pri;
    Bitmap localBitmap1 = ImageUtils.handleCameraPhoto(ImageUtils.getImageBitmap(this.strPicturePath, 1), this.strPicturePath);
    this.bitmapsList.add(localBitmap1);
    addImage();
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131820560, paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    case 2131758214:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      String str1 = this.goingWriDateEt.getText().toString().trim();
      if (this.selectIndex == -1)
      {
        ToastUtils.makeToast("请选择反馈类型");
        continue;
      }
      if (StringUtils.isNull(str1))
      {
        ToastUtils.makeToast("请填写反馈内容");
        continue;
      }
      this.dialog.createProgressDialog(this, "请稍后...");
      ArrayList localArrayList = new ArrayList();
      Iterator localIterator = this.bitmapsList.iterator();
      while (localIterator.hasNext())
        localArrayList.add(QiniuManager.uploadData((Bitmap)localIterator.next()));
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.feedComment = str1;
      localRequestModel.devInfo = StringUtils.getFixedField();
      localRequestModel.feedType = String.valueOf(7 + this.selectIndex);
      if (localArrayList.size() > 0)
      {
        String str2 = localArrayList.toString();
        localRequestModel.feedImg = str2.substring(1, -1 + str2.length());
      }
      MiddleManager.getInstance().getMinePresenterImpl(this).feedback(localRequestModel, this);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.Mine03FeedbackActivity
 * JD-Core Version:    0.6.0
 */