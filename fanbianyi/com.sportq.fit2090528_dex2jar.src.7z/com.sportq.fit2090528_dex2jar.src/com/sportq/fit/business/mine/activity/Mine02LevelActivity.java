package com.sportq.fit.business.mine.activity;

import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ScaleDrawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.LayoutParams;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.adapter.Mine02LevelAdapter;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.RankLevelModel;
import com.sportq.fit.common.reformer.RankReformer;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.middlelib.MiddleManager;

public class Mine02LevelActivity extends BaseActivity
{

  @Bind({2131755283})
  RecyclerView recycler_view;
  private Object sender;

  @Bind({2131755432})
  CustomToolBar toolbar;
  ValueAnimator valueAnimator;

  private void fontColorGradientAnimation(ProgressBar paramProgressBar, RankLevelModel paramRankLevelModel, int paramInt)
  {
    int i = -12529;
    while (true)
    {
      try
      {
        LayerDrawable localLayerDrawable = (LayerDrawable)paramProgressBar.getProgressDrawable();
        GradientDrawable localGradientDrawable = (GradientDrawable)((ScaleDrawable)localLayerDrawable.findDrawableByLayerId(16908301)).getDrawable();
        if (paramInt != 0)
          continue;
        int j = -39424;
        break label153;
        2 local2 = new TypeEvaluator()
        {
          public Object evaluate(float paramFloat, Object paramObject1, Object paramObject2)
          {
            int i = ((Integer)paramObject1).intValue();
            int j = 0xFF & i >> 24;
            int k = 0xFF & i >> 16;
            int m = 0xFF & i >> 8;
            int n = i & 0xFF;
            int i1 = ((Integer)paramObject2).intValue();
            int i2 = 0xFF & i1 >> 24;
            int i3 = 0xFF & i1 >> 16;
            int i4 = 0xFF & i1 >> 8;
            int i5 = i1 & 0xFF;
            return Integer.valueOf(j + (int)(paramFloat * (i2 - j)) << 24 | k + (int)(paramFloat * (i3 - k)) << 16 | m + (int)(paramFloat * (i4 - m)) << 8 | n + (int)(paramFloat * (i5 - n)));
          }
        };
        Object[] arrayOfObject = new Object[2];
        arrayOfObject[0] = Integer.valueOf(j);
        arrayOfObject[1] = Integer.valueOf(i);
        this.valueAnimator = ValueAnimator.ofObject(local2, arrayOfObject);
        this.valueAnimator.setDuration(500L);
        this.valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(localGradientDrawable, paramProgressBar, localLayerDrawable, i, paramRankLevelModel, paramInt)
        {
          public void onAnimationUpdate(ValueAnimator paramValueAnimator)
          {
            int i = ((Integer)paramValueAnimator.getAnimatedValue()).intValue();
            if (this.val$gradientDrawable != null)
              this.val$gradientDrawable.setColor(i);
            this.val$progress.setProgressDrawable(this.val$layerDrawable);
            Mine02LevelActivity localMine02LevelActivity;
            ProgressBar localProgressBar;
            RankLevelModel localRankLevelModel;
            if (i == this.val$endColor)
            {
              localMine02LevelActivity = Mine02LevelActivity.this;
              localProgressBar = this.val$progress;
              localRankLevelModel = this.val$model;
              if (this.val$type != 0)
                break label83;
            }
            label83: for (int j = 1; ; j = 0)
            {
              localMine02LevelActivity.fontColorGradientAnimation(localProgressBar, localRankLevelModel, j);
              return;
            }
          }
        });
        this.valueAnimator.start();
        return;
        j = i;
        break label153;
        i = -39424;
        continue;
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return;
      }
      label153: if (paramInt != 0)
        continue;
    }
  }

  private View initHeadView(RankLevelModel paramRankLevelModel)
  {
    View localView = LayoutInflater.from(this).inflate(2130968964, null);
    TextView localTextView1;
    TextView localTextView2;
    ProgressBar localProgressBar;
    TextView localTextView3;
    if (paramRankLevelModel != null)
    {
      ImageView localImageView = (ImageView)localView.findViewById(2131756619);
      localTextView1 = (TextView)localView.findViewById(2131756620);
      localTextView2 = (TextView)localView.findViewById(2131756621);
      localProgressBar = (ProgressBar)localView.findViewById(2131756622);
      localTextView3 = (TextView)localView.findViewById(2131756623);
      GlideUtils.loadImgByDefault(paramRankLevelModel.levelImageUrl, 2130903536, localImageView);
    }
    try
    {
      localTextView1.setText(paramRankLevelModel.levelName);
      String[] arrayOfString = new String[1];
      arrayOfString[0] = paramRankLevelModel.currentLevelDuration.replaceAll("分钟", "");
      localTextView2.setText(UseStringUtils.getStr(2131297357, arrayOfString));
      if ("Lv12".equals(paramRankLevelModel.levelName));
      for (String str = "膜拜大神，从此能战胜的只有你自己了，继续加油~"; ; str = paramRankLevelModel.nextLevelDuration)
      {
        localTextView3.setText(str);
        setProgressColor(localProgressBar, paramRankLevelModel);
        localView.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
        return localView;
      }
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
  }

  private void setProgressColor(ProgressBar paramProgressBar, RankLevelModel paramRankLevelModel)
  {
    try
    {
      if ((paramRankLevelModel.backgroundColor.contains(";")) || ("Lv12".equals(paramRankLevelModel.levelName)))
        fontColorGradientAnimation(paramProgressBar, paramRankLevelModel, 0);
      while (true)
      {
        ValueAnimator localValueAnimator = ValueAnimator.ofInt(new int[] { 0, (int)(100.0F * (Float.valueOf(paramRankLevelModel.currentLevelDuration.replaceAll("分钟", "")).floatValue() / Float.valueOf(paramRankLevelModel.levelDuration.replaceAll("分钟", "")).floatValue())) });
        localValueAnimator.setDuration(500L);
        localValueAnimator.setStartDelay(200L);
        localValueAnimator.setInterpolator(new LinearInterpolator());
        localValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(localValueAnimator, paramProgressBar)
        {
          public void onAnimationUpdate(ValueAnimator paramValueAnimator)
          {
            int i = ((Integer)this.val$animator1.getAnimatedValue()).intValue();
            this.val$progress.setProgress(i);
          }
        });
        localValueAnimator.start();
        return;
        LayerDrawable localLayerDrawable = (LayerDrawable)paramProgressBar.getProgressDrawable();
        ((GradientDrawable)((ScaleDrawable)localLayerDrawable.findDrawableByLayerId(16908301)).getDrawable()).setColor(Color.parseColor(paramRankLevelModel.backgroundColor));
        paramProgressBar.setProgressDrawable(localLayerDrawable);
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    if ((paramT instanceof RankReformer))
    {
      RankReformer localRankReformer = (RankReformer)paramT;
      this.sender = localRankReformer.headRankModel;
      Mine02LevelAdapter localMine02LevelAdapter = new Mine02LevelAdapter(this, localRankReformer.rankLevelListArray, 2130968965);
      localMine02LevelAdapter.addHeaderView(initHeadView(localRankReformer.headRankModel));
      this.recycler_view.setLayoutManager(new LinearLayoutManager(this));
      this.recycler_view.setAdapter(localMine02LevelAdapter);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968963);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    this.toolbar.setNavIcon(2130903080);
    this.toolbar.setAppTitle(StringUtils.getStringResources(2131297353));
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, 2131624003));
    this.toolbar.setBackgroundResource(2131624328);
    setSupportActionBar(this.toolbar);
    this.dialog.createProgressDialog(this, getString(2131299604));
    MiddleManager.getInstance().getMinePresenterImpl(this).getRankSuccess(this);
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    return super.onCreateOptionsMenu(paramMenu);
  }

  protected void onDestroy()
  {
    if (this.valueAnimator != null)
      this.valueAnimator.cancel();
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    case 2131758207:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      this.dialog.showShareChoiseDialog(this, 1, this.sender, this.dialog);
    }
  }

  protected void onResume()
  {
    if (Constant.share_state)
    {
      Constant.share_state = false;
      this.dialog.closeDialog();
    }
    super.onResume();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.Mine02LevelActivity
 * JD-Core Version:    0.6.0
 */