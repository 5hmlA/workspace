package com.sportq.fit.business.mine.activity;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.business.mine.adapter.MineFCurrencyAdapter;
import com.sportq.fit.business.mine.adapter.MineFCurrencyAdapter.OnFCurrencyItemClickListener;
import com.sportq.fit.business.mine.widget.NonScrollGridView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.logic.payutil.AlipayHandler;
import com.sportq.fit.common.logic.payutil.HuaweiPayHandler;
import com.sportq.fit.common.logic.payutil.OnPayListener;
import com.sportq.fit.common.logic.payutil.WechatPayHandler;
import com.sportq.fit.common.logic.payutil.WechatPayHandler.OnGetOrderIdListener;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CustomerServiceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.persenter.AppPresenterImpl;
import com.sportq.fit.persenter.model.GetFcoinCommodityModel;
import com.sportq.fit.persenter.reformer.GetFcoinCommodityReformer;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class MineFCurrencyActivity extends BaseActivity
  implements View.OnClickListener, OnPayListener, WechatPayHandler.OnGetOrderIdListener, MineFCurrencyAdapter.OnFCurrencyItemClickListener
{
  private MineFCurrencyAdapter adapter;
  private AlipayHandler alipayHandler;

  @Bind({2131756834})
  NonScrollGridView f_currency_grid_view;

  @Bind({2131756833})
  TextView f_currency_tv;
  private GetFcoinCommodityReformer fconReformer;
  private HuaweiPayHandler huaweiPayHandler;
  private int payType;

  @Bind({2131756830})
  TextView pay_comment;

  @Bind({2131756835})
  LinearLayout pay_layout;

  @Bind({2131756829})
  TextView pay_money_hint;

  @Bind({2131756831})
  TextView pay_tv;

  @Bind({2131755598})
  ScrollView scroll_view;
  private String strVipOrderId;

  @Bind({2131755432})
  CustomToolBar toolbar;
  private WechatPayHandler wechatPayHandler;

  @Bind({2131755626})
  RelativeLayout wechat_layout;

  @Bind({2131755627})
  ImageView wechat_select_icon;

  @Bind({2131755623})
  RelativeLayout zhifubao_layout;

  @Bind({2131755624})
  ImageView zhifubao_select_icon;

  private void payAction()
  {
    String str1 = String.valueOf(this.pay_money_hint.getTag());
    if (StringUtils.isNull(str1))
      return;
    GetFcoinCommodityModel localGetFcoinCommodityModel = (GetFcoinCommodityModel)this.fconReformer.lstFcoinCommodity.get(Integer.valueOf(str1).intValue());
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.commodityId = localGetFcoinCommodityModel.commodityId;
    localRequestModel.quantity = "1";
    String str2 = StringUtils.convertPrice02(localGetFcoinCommodityModel.price);
    localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + localGetFcoinCommodityModel.commodityId + NdkUtils.getSignBaseUrl()).toUpperCase();
    localRequestModel.callType = "7";
    if (CompDeviceInfoUtils.isHuaweiChannel())
    {
      localRequestModel.totalPrice = str2;
      this.huaweiPayHandler.executeCallHuaweipay(localRequestModel);
      return;
    }
    switch (this.payType)
    {
    default:
      return;
    case 0:
      localRequestModel.aliJson = this.alipayHandler.getAlipayReqParams(str2, null, "Fit-F币充值");
      this.alipayHandler.executeCallAlipay(this, localRequestModel);
      return;
    case 1:
    }
    localRequestModel.totalPrice = str2;
    this.wechatPayHandler.executeCallWechatPay(this, localRequestModel);
  }

  private void resetPaySelectorStatus()
  {
    this.zhifubao_select_icon.setImageResource(2130903140);
    this.wechat_select_icon.setImageResource(2130903140);
  }

  private void startEnergyChangeAnim(int paramInt, String paramString)
  {
    int[] arrayOfInt = new int[2];
    arrayOfInt[0] = paramInt;
    arrayOfInt[1] = StringUtils.string2Int(paramString);
    ValueAnimator localValueAnimator = ValueAnimator.ofInt(arrayOfInt);
    localValueAnimator.setDuration(500L);
    localValueAnimator.setStartDelay(200L);
    localValueAnimator.setInterpolator(new DecelerateInterpolator());
    localValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(localValueAnimator)
    {
      public void onAnimationUpdate(ValueAnimator paramValueAnimator)
      {
        MineFCurrencyActivity.this.f_currency_tv.setText(String.valueOf(this.val$animator1.getAnimatedValue()));
      }
    });
    localValueAnimator.start();
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    int i;
    if ((paramT instanceof GetFcoinCommodityReformer))
    {
      this.fconReformer = ((GetFcoinCommodityReformer)paramT);
      if ((this.fconReformer.lstFcoinCommodity != null) && (this.fconReformer.lstFcoinCommodity.size() > 0))
      {
        if (this.adapter == null)
          break label106;
        i = this.adapter.getDefSelIndex();
        this.adapter = new MineFCurrencyAdapter(this, this.fconReformer.lstFcoinCommodity, i);
        this.f_currency_grid_view.setAdapter(this.adapter);
      }
    }
    while (true)
    {
      if (this.dialog != null)
        this.dialog.closeDialog();
      return;
      label106: i = this.fconReformer.defaultSelIndex;
      break;
      if (!"Y".equals(paramT))
        continue;
      this.scroll_view.smoothScrollTo(0, 0);
      new Handler().postDelayed(new Runnable()
      {
        public void run()
        {
          if (!StringUtils.isNull(BaseApplication.userModel.fcoinValue))
          {
            MineFCurrencyActivity.this.startEnergyChangeAnim(Integer.valueOf(MineFCurrencyActivity.this.f_currency_tv.getText().toString()).intValue(), BaseApplication.userModel.fcoinValue);
            new AppPresenterImpl(MineFCurrencyActivity.this).getFcoinCommodity(MineFCurrencyActivity.this);
          }
        }
      }
      , 200L);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969004);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.toolbar.setTitle(2131297390);
    this.toolbar.setNavIcon(2130903080);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, 2131624003));
    this.toolbar.setBackgroundResource(2131624328);
    setSupportActionBar(this.toolbar);
    this.pay_tv.setOnClickListener(this);
    this.wechat_layout.setOnClickListener(this);
    this.zhifubao_layout.setOnClickListener(this);
    this.alipayHandler = new AlipayHandler(this);
    this.wechatPayHandler = new WechatPayHandler(this, this);
    this.huaweiPayHandler = new HuaweiPayHandler(this, this);
    this.huaweiPayHandler.setPayType("3");
    this.zhifubao_select_icon.setImageResource(2130903276);
    this.f_currency_tv.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    LinearLayout localLinearLayout;
    if (StringUtils.isNull(BaseApplication.userModel.fcoinValue))
    {
      this.f_currency_tv.setText("0");
      localLinearLayout = this.pay_layout;
      if (!CompDeviceInfoUtils.isHuaweiChannel())
        break label252;
    }
    label252: for (int i = 8; ; i = 0)
    {
      localLinearLayout.setVisibility(i);
      new AppPresenterImpl(this).getFcoinCommodity(this);
      return;
      this.f_currency_tv.setText(BaseApplication.userModel.fcoinValue);
      break;
    }
  }

  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    switch (paramView.getId())
    {
    default:
      return;
    case 2131756831:
      payAction();
      return;
    case 2131755626:
      this.payType = 1;
      resetPaySelectorStatus();
      this.wechat_select_icon.setImageResource(2130903276);
      return;
    case 2131755623:
    }
    this.payType = 0;
    resetPaySelectorStatus();
    this.zhifubao_select_icon.setImageResource(2130903276);
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131820551, paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("onResp".equals(paramString))
      if (this.wechatPayHandler != null)
      {
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.orderId = this.strVipOrderId;
        localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.strVipOrderId + NdkUtils.getSignBaseUrl()).toUpperCase();
        this.wechatPayHandler.checkWechatPayResult(this, localRequestModel);
      }
    do
      return;
    while ((!"onPayError".equals(paramString)) || (this.wechatPayHandler == null));
    this.wechatPayHandler.resetPayStatus();
  }

  public void onFCurrencyItemClick(int paramInt)
  {
    this.pay_money_hint.setTag(Integer.valueOf(paramInt));
    this.pay_money_hint.setVisibility(0);
    TextView localTextView = this.pay_money_hint;
    StringBuilder localStringBuilder = new StringBuilder().append("实付：¥");
    if (((GetFcoinCommodityModel)this.fconReformer.lstFcoinCommodity.get(paramInt)).price.contains("元"));
    for (String str = ((GetFcoinCommodityModel)this.fconReformer.lstFcoinCommodity.get(paramInt)).price.replaceAll("元", ""); ; str = ((GetFcoinCommodityModel)this.fconReformer.lstFcoinCommodity.get(paramInt)).price)
    {
      localTextView.setText(String.valueOf(str));
      if (StringUtils.isNull(((GetFcoinCommodityModel)this.fconReformer.lstFcoinCommodity.get(paramInt)).buyComment))
        break;
      this.pay_comment.setVisibility(0);
      this.pay_comment.setText(((GetFcoinCommodityModel)this.fconReformer.lstFcoinCommodity.get(paramInt)).buyComment);
      return;
    }
    this.pay_comment.setVisibility(8);
  }

  public void onGetOrderId(String paramString)
  {
    this.strVipOrderId = paramString;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    case 2131758206:
    case 2131758205:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      CustomerServiceUtils.openServiceActivity(this);
      continue;
      startActivity(new Intent(this, MineFcoinInfoActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void onPayFail(int paramInt, String paramString)
  {
  }

  public void onPaySuccess(int paramInt)
  {
    this.dialog.createProgressDialog(this, getResources().getString(2131299604));
    BaseApplication.isRefresh = true;
    MiddleManager.getInstance().getMinePresenterImpl(this).getUserInfo(this);
  }

  protected void onResume()
  {
    if (this.wechatPayHandler != null)
      this.wechatPayHandler.checkWeichatVersion();
    super.onResume();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.MineFCurrencyActivity
 * JD-Core Version:    0.6.0
 */