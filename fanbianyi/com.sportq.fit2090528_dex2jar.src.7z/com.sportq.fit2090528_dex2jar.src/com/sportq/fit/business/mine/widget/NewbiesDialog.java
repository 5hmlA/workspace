package com.sportq.fit.business.mine.widget;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;

public class NewbiesDialog
{
  public void showNewbiesDialog(Context paramContext, FitInterfaceUtils.DialogListener paramDialogListener)
  {
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setCancelable(true);
    localDialog.setContentView(2130968635);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
    localLayoutParams.height = (int)(1.3077D * (0.9028000000000001D * BaseApplication.screenWidth));
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    ImageView localImageView = (ImageView)localDialog.findViewById(2131755438);
    localImageView.setImageResource(2130903603);
    localImageView.setOnClickListener(new View.OnClickListener(paramDialogListener, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (this.val$listener != null)
          this.val$listener.onDialogClick(this.val$dialog, -1);
        this.val$dialog.dismiss();
      }
    });
    localDialog.findViewById(2131755439).setOnClickListener(new View.OnClickListener(paramDialogListener, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (this.val$listener != null)
          this.val$listener.onDialogClick(this.val$dialog, -2);
        this.val$dialog.dismiss();
      }
    });
    localDialog.setOnDismissListener(new DialogInterface.OnDismissListener(paramDialogListener)
    {
      public void onDismiss(DialogInterface paramDialogInterface)
      {
        if (this.val$listener != null)
          this.val$listener.onDialogClick(paramDialogInterface, -3);
      }
    });
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.widget.NewbiesDialog
 * JD-Core Version:    0.6.0
 */