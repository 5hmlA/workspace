package com.sportq.fit.business.mine.activity;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.business.mine.widget.NonScrollGridView;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class MineFCurrencyActivity$$ViewBinder<T extends MineFCurrencyActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.pay_tv = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756831, "field 'pay_tv'"), 2131756831, "field 'pay_tv'"));
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.f_currency_tv = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756833, "field 'f_currency_tv'"), 2131756833, "field 'f_currency_tv'"));
    paramT.pay_money_hint = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756829, "field 'pay_money_hint'"), 2131756829, "field 'pay_money_hint'"));
    paramT.wechat_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755626, "field 'wechat_layout'"), 2131755626, "field 'wechat_layout'"));
    paramT.pay_layout = ((LinearLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756835, "field 'pay_layout'"), 2131756835, "field 'pay_layout'"));
    paramT.wechat_select_icon = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755627, "field 'wechat_select_icon'"), 2131755627, "field 'wechat_select_icon'"));
    paramT.zhifubao_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755623, "field 'zhifubao_layout'"), 2131755623, "field 'zhifubao_layout'"));
    paramT.zhifubao_select_icon = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755624, "field 'zhifubao_select_icon'"), 2131755624, "field 'zhifubao_select_icon'"));
    paramT.f_currency_grid_view = ((NonScrollGridView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756834, "field 'f_currency_grid_view'"), 2131756834, "field 'f_currency_grid_view'"));
    paramT.scroll_view = ((ScrollView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755598, "field 'scroll_view'"), 2131755598, "field 'scroll_view'"));
    paramT.pay_comment = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756830, "field 'pay_comment'"), 2131756830, "field 'pay_comment'"));
  }

  public void unbind(T paramT)
  {
    paramT.pay_tv = null;
    paramT.toolbar = null;
    paramT.f_currency_tv = null;
    paramT.pay_money_hint = null;
    paramT.wechat_layout = null;
    paramT.pay_layout = null;
    paramT.wechat_select_icon = null;
    paramT.zhifubao_layout = null;
    paramT.zhifubao_select_icon = null;
    paramT.f_currency_grid_view = null;
    paramT.scroll_view = null;
    paramT.pay_comment = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.MineFCurrencyActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */