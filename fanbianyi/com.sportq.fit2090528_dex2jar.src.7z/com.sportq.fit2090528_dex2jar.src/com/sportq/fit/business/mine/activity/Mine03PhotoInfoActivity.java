package com.sportq.fit.business.mine.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils.TruncateAt;
import android.text.method.ScrollingMovementMethod;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.FitnessPicItemModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.TrainPhotoReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.PopWindowMenu;
import com.sportq.fit.fitmoudle.dialogmanager.PopWindowMenu.OnPopViewClickListener;
import com.sportq.fit.fitmoudle.event.DelFitnessPhotoEvent;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import uk.co.senab.photoview.PhotoView;
import uk.co.senab.photoview.PhotoViewAttacher.OnPhotoTapListener;

public class Mine03PhotoInfoActivity extends BaseActivity
{
  public static final String FROM_PAGE = "intent.from";
  public static final String KEY_MODEL = "fitnessAlbumModel";
  public static final String TRAIN_HISTORY_ID = "train_history_id";
  Animation down;
  Animation down_fale;
  private FitnessPicItemModel fitnesspicitemmodel;
  private String fromPage;
  private String hisId;
  private String imgId;
  private boolean isShowFlg = true;
  private String[] itemList = { "保存", "取消" };

  @Bind({2131756752})
  RTextView mine03_check_button;

  @Bind({2131756746})
  PhotoView mine03_photo;

  @Bind({2131756748})
  TextView mine03_photo_info;

  @Bind({2131756747})
  RelativeLayout mine03_photo_info_l;

  @Bind({2131756751})
  TextView mine03_photo_train;

  @Bind({2131756749})
  LinearLayout mine_photo_weight;
  private RequestModel requestModel;

  @Bind({2131755432})
  CustomToolBar toolbar;

  @Bind({2131755277})
  RelativeLayout toolbar_layout;
  Animation up;
  Animation up_fale;
  private UseShareModel useShareModel;

  @Bind({2131756750})
  TextView weight_info;

  private String convertDate(String paramString)
  {
    try
    {
      String str1 = String.valueOf(Calendar.getInstance().get(1));
      String str2 = DateUtils.StringToFormat(String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).parse(paramString).getTime()), "yyyy年M月d日 HH:mm").replace(str1 + "年", "");
      return str2;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return "";
  }

  private void menuMoreClickAction()
  {
    int[] arrayOfInt = { 12, 9 };
    new PopWindowMenu(this.toolbar, arrayOfInt, this, new PopWindowMenu.OnPopViewClickListener()
    {
      public void onPopViewClick(View paramView)
      {
        switch (paramView.getId())
        {
        default:
          return;
        case 2131756598:
          Mine03PhotoInfoActivity.this.dialog.createDialog(new FitInterfaceUtils.DialogListener()
          {
            public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
            {
              switch (paramInt)
              {
              default:
                return;
              case 0:
                MiddleManager.getInstance().getFindPresenterImpl(Mine03PhotoInfoActivity.this, null).statsSaveLocalClick();
                Mine03PhotoInfoActivity.this.mine03_photo.setDrawingCacheEnabled(true);
                ImageUtils.saveImgToAlbum(null, Mine03PhotoInfoActivity.this.mine03_photo.getDrawingCache(), Mine03PhotoInfoActivity.this);
                ToastUtils.makeToast(Mine03PhotoInfoActivity.this, "图片已保存至" + Constant.STR_IMAGE_STORE_NAME + " 文件夹");
                return;
              case 1:
              }
              Mine03PhotoInfoActivity.this.dialog.closeDialog();
            }
          }
          , Mine03PhotoInfoActivity.this, Mine03PhotoInfoActivity.this.itemList);
          return;
        case 2131756599:
        }
        if ((Mine03PhotoInfoActivity.this.fitnesspicitemmodel != null) && (!StringUtils.isNull(Mine03PhotoInfoActivity.this.fitnesspicitemmodel.olapInfo)))
          MiddleManager.getInstance().getFindPresenterImpl(Mine03PhotoInfoActivity.this, null).statsTrainInfoMoreDeleteClick(Mine03PhotoInfoActivity.this.fitnesspicitemmodel.olapInfo);
        Mine03PhotoInfoActivity.this.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
        {
          public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
          {
            if (paramInt == -1)
            {
              if (!CompDeviceInfoUtils.checkNetwork())
                ToastUtils.makeToast(Mine03PhotoInfoActivity.this, StringUtils.getStringResources(2131299052));
            }
            else
              return;
            Mine03PhotoInfoActivity.this.dialog.createProgressDialog(Mine03PhotoInfoActivity.this, "请稍后...");
            MiddleManager.getInstance().getMinePresenterImpl(Mine03PhotoInfoActivity.this).deleteTrainPhoto(Mine03PhotoInfoActivity.this.requestModel, Mine03PhotoInfoActivity.this);
          }
        }
        , Mine03PhotoInfoActivity.this, "", "确定要删除这张照片吗？", "删除", "取消");
      }
    });
  }

  private void setAnimation()
  {
    this.down = AnimationUtils.loadAnimation(this, 2131034157);
    this.down_fale = AnimationUtils.loadAnimation(this, 2131034158);
    this.up = AnimationUtils.loadAnimation(this, 2131034159);
    this.up_fale = AnimationUtils.loadAnimation(this, 2131034160);
    this.down.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Mine03PhotoInfoActivity.access$002(Mine03PhotoInfoActivity.this, true);
        Mine03PhotoInfoActivity.this.toolbar_layout.setVisibility(0);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
    this.down_fale.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Mine03PhotoInfoActivity.access$002(Mine03PhotoInfoActivity.this, true);
        Mine03PhotoInfoActivity.this.mine03_photo_info_l.setVisibility(0);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
    this.up.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Mine03PhotoInfoActivity.access$002(Mine03PhotoInfoActivity.this, false);
        Mine03PhotoInfoActivity.this.toolbar_layout.setVisibility(8);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
    this.up_fale.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        Mine03PhotoInfoActivity.access$002(Mine03PhotoInfoActivity.this, false);
        Mine03PhotoInfoActivity.this.mine03_photo_info_l.setVisibility(8);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
  }

  private void setPhotoInfo()
  {
    TextView localTextView1 = this.mine03_photo_train;
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = this.fitnesspicitemmodel.planName;
    arrayOfObject[1] = this.fitnesspicitemmodel.trainComment;
    localTextView1.setText(String.format("完成「%s」第%s次", arrayOfObject));
    TextView localTextView2 = this.mine03_photo_train;
    int i;
    int j;
    if (StringUtils.isNull(this.fitnesspicitemmodel.planName))
    {
      i = 8;
      localTextView2.setVisibility(i);
      this.weight_info.setText(this.fitnesspicitemmodel.currentWeight);
      LinearLayout localLinearLayout = this.mine_photo_weight;
      if (!StringUtils.isNull(this.fitnesspicitemmodel.currentWeight))
        break label299;
      j = 8;
      label105: localLinearLayout.setVisibility(j);
      if ((StringUtils.isNull(this.fitnesspicitemmodel.planName)) && (StringUtils.isNull(this.fitnesspicitemmodel.currentWeight)))
        this.mine03_photo_train.setVisibility(4);
      if ((StringUtils.isNull(this.fitnesspicitemmodel.planName)) && (StringUtils.isNull(this.fitnesspicitemmodel.currentWeight)) && (StringUtils.isNull(this.fitnesspicitemmodel.comment)))
        this.mine03_photo_info_l.setBackgroundColor(ContextCompat.getColor(this, 2131624292));
      this.mine03_photo_info.setText(this.fitnesspicitemmodel.comment);
      if (this.mine03_photo_info.getLineCount() <= 6)
        break label305;
      this.mine03_photo_info.setMaxLines(6);
      this.mine03_check_button.setVisibility(0);
    }
    while (true)
    {
      this.mine03_photo_info.setVisibility(0);
      if ("0".equals(this.fromPage))
      {
        this.toolbar.setTitle(convertDate(this.fitnesspicitemmodel.moveTime));
        showImage(this.fitnesspicitemmodel.imageURL);
      }
      return;
      i = 0;
      break;
      label299: j = 0;
      break label105;
      label305: this.mine03_check_button.setVisibility(8);
    }
  }

  private void showImage(String paramString)
  {
    RequestOptions localRequestOptions = new RequestOptions().skipMemoryCache(true).error(2130903536).fitCenter().diskCacheStrategy(DiskCacheStrategy.RESOURCE);
    Glide.with(this).load(paramString).apply(localRequestOptions).thumbnail(0.2F).into(this.mine03_photo);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
      return;
    case 2131756752:
    }
    if (StringUtils.string2Int(String.valueOf(this.mine03_photo_info.getTag())) == 10)
    {
      this.mine03_photo_info.setMaxLines(6);
      this.mine03_photo_info.setTag(Integer.valueOf(6));
      this.mine03_check_button.setText(2131298986);
      this.mine03_photo_info.setMovementMethod(null);
      this.mine03_photo_info.setEllipsize(TextUtils.TruncateAt.END);
      return;
    }
    this.mine03_photo_info.setMaxLines(20);
    this.mine03_photo_info.setTag(Integer.valueOf(10));
    this.mine03_check_button.setText(2131299076);
    this.mine03_photo_info.setMovementMethod(new ScrollingMovementMethod());
    this.mine03_photo_info.setEllipsize(null);
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof TrainPhotoReformer))
    {
      this.fitnesspicitemmodel = ((TrainPhotoReformer)paramT).model;
      String str1;
      String[] arrayOfString;
      int k;
      label120: int m;
      label132: StringBuilder localStringBuilder2;
      int n;
      if (this.fitnesspicitemmodel != null)
      {
        this.useShareModel = new UseShareModel();
        this.useShareModel.shareFeeling = this.fitnesspicitemmodel.comment;
        this.useShareModel.shareCameraImg = this.fitnesspicitemmodel.imageURL;
        if (!StringUtils.isNull(this.fitnesspicitemmodel.trainComment))
        {
          if (!StringUtils.isNull(this.fitnesspicitemmodel.trainTime))
            break label297;
          str1 = "00:00";
          arrayOfString = str1.split(":");
          if (arrayOfString.length <= 2)
            break label345;
          if (!StringUtils.isNull(arrayOfString[0]))
            break label308;
          k = 0;
          if (!StringUtils.isNull(arrayOfString[1]))
            break label325;
          m = 0;
          localStringBuilder2 = new StringBuilder();
          n = k + m;
          if (!"00".equals(arrayOfString[2]))
            break label339;
        }
      }
      String str2;
      label297: label308: label325: label339: for (int i1 = 0; ; i1 = 1)
      {
        str2 = i1 + n + "";
        UseShareModel localUseShareModel = this.useShareModel;
        Object[] arrayOfObject = new Object[3];
        arrayOfObject[0] = this.fitnesspicitemmodel.trainComment;
        arrayOfObject[1] = str2;
        arrayOfObject[2] = this.fitnesspicitemmodel.calorie;
        localUseShareModel.shareInfoStr = String.format("第%s次 %s分钟 %s千卡", arrayOfObject);
        this.useShareModel.planName = this.fitnesspicitemmodel.planName;
        this.useShareModel.olapInfo = this.fitnesspicitemmodel.olapInfo;
        this.useShareModel.avgTime = this.fitnesspicitemmodel.moveTime;
        this.useShareModel.energyFlag = this.fitnesspicitemmodel.energyFlag;
        setPhotoInfo();
        return;
        str1 = this.fitnesspicitemmodel.trainTime;
        break;
        k = 60 * Integer.valueOf(arrayOfString[0]).intValue();
        break label120;
        m = Integer.valueOf(arrayOfString[1]).intValue();
        break label132;
      }
      label345: int i;
      label357: StringBuilder localStringBuilder1;
      if (StringUtils.isNull(arrayOfString[0]))
      {
        i = 0;
        localStringBuilder1 = new StringBuilder();
        if (!"00".equals(arrayOfString[1]))
          break label418;
      }
      label418: for (int j = 0; ; j = 1)
      {
        str2 = j + i + "";
        break;
        i = Integer.valueOf(arrayOfString[0]).intValue();
        break label357;
      }
    }
    this.dialog.closeDialog();
    finish();
    EventBus.getDefault().post(new DelFitnessPhotoEvent(this.fitnesspicitemmodel.photoType, this.hisId));
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968986);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.fromPage = getIntent().getStringExtra("intent.from");
    if ("1".equals(this.fromPage))
    {
      FitnessPicItemModel localFitnessPicItemModel = (FitnessPicItemModel)getIntent().getSerializableExtra("fitnessAlbumModel");
      this.hisId = localFitnessPicItemModel.historyId;
      this.imgId = localFitnessPicItemModel.imgId;
      this.toolbar.setTitle(convertDate(localFitnessPicItemModel.moveTime));
      showImage(localFitnessPicItemModel.imageURL);
    }
    while (true)
    {
      this.toolbar.setNavIcon(2130903080);
      this.toolbar.setTitleTextColor(ContextCompat.getColor(this, 2131624003));
      this.toolbar.setBackgroundResource(2131624328);
      setSupportActionBar(this.toolbar);
      this.requestModel = new RequestModel();
      this.requestModel.historyId = this.hisId;
      this.requestModel.imgId = this.imgId;
      MiddleManager.getInstance().getMinePresenterImpl(this).getTrainPhoto(this.requestModel, this);
      this.mine03_photo.setOnPhotoTapListener(new PhotoViewAttacher.OnPhotoTapListener()
      {
        public void onOutsidePhotoTap()
        {
        }

        public void onPhotoTap(View paramView, float paramFloat1, float paramFloat2)
        {
          if (Mine03PhotoInfoActivity.this.isShowFlg)
          {
            Mine03PhotoInfoActivity.this.toolbar_layout.startAnimation(Mine03PhotoInfoActivity.this.up);
            Mine03PhotoInfoActivity.this.mine03_photo_info_l.startAnimation(Mine03PhotoInfoActivity.this.up_fale);
            return;
          }
          Mine03PhotoInfoActivity.this.toolbar_layout.startAnimation(Mine03PhotoInfoActivity.this.down);
          Mine03PhotoInfoActivity.this.mine03_photo_info_l.startAnimation(Mine03PhotoInfoActivity.this.down_fale);
        }
      });
      this.mine03_check_button.setOnClickListener(new FitAction(this));
      setAnimation();
      return;
      this.hisId = getIntent().getStringExtra("train_history_id");
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131820569, paramMenu);
    return true;
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(DelFitnessPhotoEvent paramDelFitnessPhotoEvent)
  {
    finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    case 2131758199:
    case 2131755569:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      menuMoreClickAction();
      continue;
      if (this.useShareModel == null)
      {
        VdsAgent.handleClickResult(new Boolean(false));
        return false;
      }
      this.dialog.showShareChoiseDialog(this, 15, this.useShareModel, this.dialog);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.Mine03PhotoInfoActivity
 * JD-Core Version:    0.6.0
 */