package com.sportq.fit.business.mine.activity;

import android.app.Dialog;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.text.ClipboardManager;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DownLoadListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.supportlib.download.DefaultDownloadViewHolder;
import com.sportq.fit.supportlib.download.DownloadInfo;
import com.sportq.fit.supportlib.download.DownloadManager;
import com.sportq.fit.supportlib.http.request.FitRxRequest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xutils.DbManager;
import rx.Observable;
import rx.Subscriber;

public class VideoUrlTestActivity extends BaseActivity
  implements SurfaceHolder.Callback, FitInterfaceUtils.DownLoadListener
{
  private DownloadManager downloadManager;

  @Bind({2131755811})
  TextView download_hint;
  private ArrayList<String> errorList = new ArrayList();
  private int index = 0;
  private Timer mTimer;
  private TimerTask mTimerTask;
  private MediaPlayer mediaPlayer;
  private SurfaceHolder surfaceHolder;

  @Bind({2131757818})
  SurfaceView surfaceView;
  private ArrayList<ItemModel> videoInfo;
  private ArrayList<String> videoList;

  @Bind({2131757819})
  LinearLayout video_url_layout;

  private void autoPlay()
  {
    if (this.mediaPlayer.getCurrentPosition() >= 2000)
    {
      this.video_url_layout.getChildAt(this.index).setTag("unPlay");
      this.index = (1 + this.index);
      if (this.index < this.videoList.size())
        playVideo(this.index);
    }
    else
    {
      return;
    }
    runOnUiThread(new Runnable()
    {
      public void run()
      {
        VideoUrlTestActivity.this.showPlayFinishDialog();
      }
    });
  }

  private void initData()
  {
    this.dialog.createProgressDialog(this, "请稍后...");
    FitRxRequest.getRequest(0, "/SFitWeb/sfit/getActVideoUrl", new RequestModel(), this).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
      }

      public void onNext(String paramString)
      {
        try
        {
          VideoUrlTestActivity.this.dialog.closeDialog();
          JSONArray localJSONArray = new JSONObject(paramString).getJSONArray("videoUrl");
          VideoUrlTestActivity.access$002(VideoUrlTestActivity.this, new ArrayList());
          VideoUrlTestActivity.access$102(VideoUrlTestActivity.this, new ArrayList());
          VideoUrlTestActivity.this.setDownLoadSection(localJSONArray);
          return;
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
        }
      }
    });
  }

  private void initView()
  {
    this.video_url_layout.setWeightSum(this.videoList.size());
    this.video_url_layout.removeAllViews();
    int i = 0;
    if (i < this.videoList.size())
    {
      View localView = LayoutInflater.from(this).inflate(2130969224, null);
      TextView localTextView = (TextView)localView.findViewById(2131757817);
      int j = com.sportq.fit.common.utils.StringUtils.string2Int(((ItemModel)this.videoInfo.get(i)).strSize);
      if (j > 1024);
      for (String str = com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.getM(j) + "MB"; ; str = j + "KB")
      {
        localTextView.setText(((ItemModel)this.videoInfo.get(i)).strUrl + "(" + str + ")");
        LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-1, -2);
        localLayoutParams.weight = 1.0F;
        this.video_url_layout.addView(localView, localLayoutParams);
        i++;
        break;
      }
    }
    this.video_url_layout.setVisibility(4);
  }

  private void playVideo(int paramInt)
  {
    if (this.mTimer != null)
    {
      this.mTimer.cancel();
      this.mTimer = null;
    }
    if (this.mTimerTask != null)
    {
      this.mTimerTask.cancel();
      this.mTimerTask = null;
    }
    this.video_url_layout.getChildAt(paramInt).setTag("play");
    String str = FileUtils.makeLocalFileName("testVideo", (String)this.videoList.get(paramInt));
    if (str.contains("?"))
      str = str.substring(0, str.lastIndexOf("?"));
    try
    {
      this.mediaPlayer.reset();
      this.mediaPlayer.setDataSource(str);
      this.mediaPlayer.prepareAsync();
      this.mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
      {
        public void onPrepared(MediaPlayer paramMediaPlayer)
        {
          VideoUrlTestActivity.this.mediaPlayer.start();
          VideoUrlTestActivity.access$902(VideoUrlTestActivity.this, new Timer());
          VideoUrlTestActivity.access$1002(VideoUrlTestActivity.this, new TimerTask()
          {
            public void run()
            {
              VideoUrlTestActivity.this.autoPlay();
            }
          });
          VideoUrlTestActivity.this.mTimer.schedule(VideoUrlTestActivity.this.mTimerTask, 0L, 10L);
          VideoUrlTestActivity.this.setBackBg();
        }
      });
      this.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
      {
        public void onCompletion(MediaPlayer paramMediaPlayer)
        {
        }
      });
      this.mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener(paramInt)
      {
        public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2)
        {
          VideoUrlTestActivity.this.video_url_layout.getChildAt(this.val$pos).setTag("error");
          VideoUrlTestActivity.this.errorList.add(VideoUrlTestActivity.this.videoList.get(this.val$pos));
          VideoUrlTestActivity.this.setBackBg();
          VideoUrlTestActivity.access$1408(VideoUrlTestActivity.this);
          if (VideoUrlTestActivity.this.index < VideoUrlTestActivity.this.videoList.size())
            VideoUrlTestActivity.this.playVideo(VideoUrlTestActivity.this.index);
          while (true)
          {
            return false;
            VideoUrlTestActivity.this.showPlayFinishDialog();
          }
        }
      });
      return;
    }
    catch (Exception localException1)
    {
      LogUtils.e(localException1);
      try
      {
        runOnUiThread(new Runnable(paramInt)
        {
          public void run()
          {
            VideoUrlTestActivity.this.video_url_layout.getChildAt(this.val$pos).setTag("error");
            VideoUrlTestActivity.this.errorList.add(VideoUrlTestActivity.this.videoList.get(this.val$pos));
            VideoUrlTestActivity.this.setBackBg();
            VideoUrlTestActivity.access$1408(VideoUrlTestActivity.this);
            if (VideoUrlTestActivity.this.index < VideoUrlTestActivity.this.videoList.size())
            {
              VideoUrlTestActivity.this.playVideo(VideoUrlTestActivity.this.index);
              return;
            }
            VideoUrlTestActivity.this.showPlayFinishDialog();
          }
        });
        return;
      }
      catch (Exception localException2)
      {
        LogUtils.e(localException2);
      }
    }
  }

  private void setBackBg()
  {
    for (int i = 0; ; i++)
    {
      String str;
      try
      {
        if (i >= this.videoList.size())
          break label141;
        if (this.video_url_layout.getChildAt(i).getTag() == null)
          return;
        str = this.video_url_layout.getChildAt(i).getTag().toString();
        if ("play".equals(str))
        {
          this.video_url_layout.getChildAt(i).setBackgroundColor(ContextCompat.getColor(this, 2131624074));
          continue;
        }
        if ("unPlay".equals(str))
          this.video_url_layout.getChildAt(i).setBackgroundColor(ContextCompat.getColor(this, 2131624328));
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return;
      }
      if (!"error".equals(str))
        continue;
      this.video_url_layout.getChildAt(i).setBackgroundColor(ContextCompat.getColor(this, 2131624117));
      continue;
      label141: return;
    }
  }

  private void setDownLoadSection(JSONArray paramJSONArray)
  {
    Dialog localDialog = new Dialog(this);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setCancelable(true);
    localDialog.setContentView(2130968709);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
    TextView localTextView1 = (TextView)localDialog.findViewById(2131755670);
    TextView localTextView2 = (TextView)localDialog.findViewById(2131755677);
    EditText localEditText1 = (EditText)localDialog.findViewById(2131755673);
    EditText localEditText2 = (EditText)localDialog.findViewById(2131755676);
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Integer.valueOf(paramJSONArray.length());
    localTextView1.setText(String.format("选择视频下载区间(当前视频总数为%s)", arrayOfObject));
    localTextView2.setOnClickListener(new View.OnClickListener(localEditText1, localEditText2, paramJSONArray, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        String str1 = this.val$start_edit_layout.getText().toString();
        String str2 = this.val$end_edit_layout.getText().toString();
        if ((com.sportq.fit.common.utils.StringUtils.isNull(str1)) || (com.sportq.fit.common.utils.StringUtils.isNull(str2)))
        {
          ToastUtils.makeToast(VideoUrlTestActivity.this, "区间不能为空");
          return;
        }
        if ((!str1.matches("[0-9]+")) || (!str2.matches("[0-9]+")))
        {
          ToastUtils.makeToast(VideoUrlTestActivity.this, "只能输入数字");
          return;
        }
        if (com.sportq.fit.common.utils.StringUtils.string2Int(str1) > com.sportq.fit.common.utils.StringUtils.string2Int(str2))
        {
          ToastUtils.makeToast(VideoUrlTestActivity.this, "开始下标不能小于结束下标");
          return;
        }
        if ((com.sportq.fit.common.utils.StringUtils.string2Int(str1) < 0) || (com.sportq.fit.common.utils.StringUtils.string2Int(str2) > -1 + this.val$jsonArray.length()))
        {
          ToastUtils.makeToast(VideoUrlTestActivity.this, "重新确认下标范围");
          return;
        }
        for (int i = 0; ; i++)
          try
          {
            if (i < this.val$jsonArray.length())
            {
              if (i < Integer.valueOf(str1).intValue())
                continue;
              int j = Integer.valueOf(str2).intValue();
              if (i <= j);
            }
            else
            {
              this.val$mDialog.dismiss();
              VideoUrlTestActivity.this.initView();
              VideoUrlTestActivity.this.startLoadTrainVideo(VideoUrlTestActivity.this.videoList);
              return;
            }
            VideoUrlTestActivity.ItemModel localItemModel = new VideoUrlTestActivity.ItemModel(VideoUrlTestActivity.this);
            JSONObject localJSONObject = this.val$jsonArray.getJSONObject(i);
            VideoUrlTestActivity.ItemModel.access$302(localItemModel, localJSONObject.optString("actionVideoURL"));
            VideoUrlTestActivity.ItemModel.access$402(localItemModel, localJSONObject.optString("videoSize"));
            VideoUrlTestActivity.this.videoList.add(localJSONObject.optString("actionVideoURL"));
            VideoUrlTestActivity.this.videoInfo.add(localItemModel);
          }
          catch (Exception localException)
          {
            while (true)
              LogUtils.e(localException);
          }
      }
    });
  }

  private void showPlayFinishDialog()
  {
    try
    {
      if (this.mTimer != null)
      {
        this.mTimer.cancel();
        this.mTimer = null;
      }
      if (this.mTimerTask != null)
      {
        this.mTimerTask.cancel();
        this.mTimerTask = null;
      }
      Dialog localDialog = new Dialog(this);
      localDialog.requestWindowFeature(1);
      localDialog.getWindow().setBackgroundDrawableResource(17170445);
      localDialog.setCanceledOnTouchOutside(true);
      localDialog.setCancelable(true);
      localDialog.setContentView(2130969153);
      WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
      localLayoutParams.height = -2;
      localLayoutParams.gravity = 17;
      localDialog.getWindow().setAttributes(localLayoutParams);
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      TextView localTextView1 = (TextView)localDialog.findViewById(2131757463);
      TextView localTextView2 = (TextView)localDialog.findViewById(2131755677);
      TextView localTextView3 = (TextView)localDialog.findViewById(2131756535);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(this.errorList.size());
      localTextView1.setText(String.format("播放结束，错误视频共%s个", arrayOfObject));
      localTextView2.setOnClickListener(new View.OnClickListener(localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$mDialog.dismiss();
        }
      });
      if (this.errorList.size() == 0)
      {
        localTextView3.setVisibility(8);
        return;
      }
      localTextView3.setVisibility(0);
      ClipboardManager localClipboardManager = (ClipboardManager)getSystemService("clipboard");
      String str1 = "";
      Iterator localIterator = this.errorList.iterator();
      while (localIterator.hasNext())
      {
        String str2 = (String)localIterator.next();
        str1 = str1 + str2 + "\n";
      }
      localClipboardManager.setText(str1);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void startLoadTrainVideo(ArrayList<String> paramArrayList)
  {
    new Handler().postDelayed(new Runnable(paramArrayList)
    {
      public void run()
      {
        com.sportq.fit.supportlib.CommonUtils.fileList = null;
        if (this.val$downLoadList.size() > 0)
        {
          VideoUrlTestActivity.this.downloadManager.stopAllDownload();
          int i = 0;
          while (true)
            if (i < this.val$downLoadList.size())
            {
              String str3 = (String)this.val$downLoadList.get(i);
              String str4 = FileUtils.makeLocalFileName("testVideo", str3);
              if (str4.contains("?"))
                str4 = str4.substring(0, str4.lastIndexOf("?"));
              DownloadInfo localDownloadInfo2 = new DownloadInfo();
              localDownloadInfo2.setUrl(str3);
              localDownloadInfo2.setAutoRename(true);
              localDownloadInfo2.setAutoResume(true);
              localDownloadInfo2.setLabel("testVideo");
              localDownloadInfo2.setFileSavePath(str4);
              try
              {
                VideoUrlTestActivity.this.downloadManager.db.saveBindingId(localDownloadInfo2);
                i++;
              }
              catch (Exception localException2)
              {
                while (true)
                  LogUtils.e(localException2);
              }
            }
        }
        BaseApplication.downLoadsize = this.val$downLoadList.size();
        LogUtils.e("开始循环下载视频的时间", DateUtils.getCurDate());
        Iterator localIterator = this.val$downLoadList.iterator();
        while (localIterator.hasNext())
        {
          String str1 = (String)localIterator.next();
          String str2 = FileUtils.makeLocalFileName("testVideo", str1);
          if (str2.contains("?"))
            str2 = str2.substring(0, str2.lastIndexOf("?"));
          try
          {
            DownloadInfo localDownloadInfo1 = new DownloadInfo();
            localDownloadInfo1.setUrl(str1);
            localDownloadInfo1.setAutoRename(true);
            localDownloadInfo1.setAutoResume(true);
            localDownloadInfo1.setLabel("testVideo");
            localDownloadInfo1.setFileSavePath(str2);
            VideoUrlTestActivity.this.downloadManager.startDownload(str1, "testVideo", str2, true, true, new DefaultDownloadViewHolder(localDownloadInfo1, VideoUrlTestActivity.this));
          }
          catch (Exception localException1)
          {
            LogUtils.e(localException1);
          }
        }
        LogUtils.e("结束循环下载视频的时间", DateUtils.getCurDate());
      }
    }
    , 0L);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969225);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-1, -2);
    localLayoutParams.height = (int)(0.5639D * BaseApplication.screenWidth);
    this.surfaceView.setLayoutParams(localLayoutParams);
    this.surfaceHolder = this.surfaceView.getHolder();
    this.surfaceHolder.addCallback(this);
    this.mediaPlayer = new MediaPlayer();
    this.mediaPlayer.setAudioStreamType(3);
    if (this.downloadManager == null)
      this.downloadManager = new DownloadManager();
    initData();
  }

  public void onFailure()
  {
  }

  public void onLoading(float paramFloat)
  {
    int i = (int)(100.0F * paramFloat);
    this.download_hint.setText("正在下载 " + i + "%");
    if (i == 100)
      this.download_hint.setVisibility(8);
  }

  public void onSuccess()
  {
    ToastUtils.makeToast(this, "下载完成");
    this.video_url_layout.setVisibility(0);
    this.download_hint.setVisibility(8);
    playVideo(this.index);
  }

  public void surfaceChanged(SurfaceHolder paramSurfaceHolder, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  public void surfaceCreated(SurfaceHolder paramSurfaceHolder)
  {
    this.mediaPlayer.setDisplay(this.surfaceHolder);
  }

  public void surfaceDestroyed(SurfaceHolder paramSurfaceHolder)
  {
  }

  class ItemModel
  {
    private String strSize;
    private String strUrl;

    ItemModel()
    {
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.VideoUrlTestActivity
 * JD-Core Version:    0.6.0
 */