package com.sportq.fit.business.mine.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.activity.Mine03PhotoViewPagerActivity;
import com.sportq.fit.business.mine.widget.GrapeMGridView;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.FitnessPicItemModel;
import com.sportq.fit.common.model.FitnessPicModel;
import com.sportq.fit.common.utils.stickrecycleradapter.StickyRecyclerHeadersAdapter;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.middlelib.MiddleManager;
import java.io.Serializable;
import java.util.ArrayList;

public class MinePhotoAlbumAdapter extends RecyclerView.Adapter
  implements StickyRecyclerHeadersAdapter
{
  private MineGridViewAdapter gridViewAdapter;
  private ArrayList<FitnessPicModel> list;
  private FitInterfaceUtils.UIInitListener listener;
  private Context mContext;
  private MineGridViewAdapter.SelectImgListener sListener;
  private ArrayList<FitnessPicItemModel> selectList;
  private String type;

  public MinePhotoAlbumAdapter(FitInterfaceUtils.UIInitListener paramUIInitListener, MineGridViewAdapter.SelectImgListener paramSelectImgListener, Context paramContext, ArrayList<FitnessPicModel> paramArrayList)
  {
    this.listener = paramUIInitListener;
    this.mContext = paramContext;
    this.sListener = paramSelectImgListener;
    this.list = paramArrayList;
  }

  public long getHeaderId(int paramInt)
  {
    return paramInt;
  }

  public int getItemCount()
  {
    return this.list.size();
  }

  public void onBindHeaderViewHolder(RecyclerView.ViewHolder paramViewHolder, int paramInt)
  {
    if (paramInt < this.list.size())
    {
      FitnessPicModel localFitnessPicModel = (FitnessPicModel)this.list.get(paramInt);
      ((MinePhotoTitleViewHolder)paramViewHolder).titleView.setText(localFitnessPicModel.mouth);
    }
  }

  public void onBindViewHolder(RecyclerView.ViewHolder paramViewHolder, int paramInt)
  {
    if ((paramViewHolder instanceof MinePhotoViewHolder))
    {
      int i = paramViewHolder.getAdapterPosition();
      GrapeMGridView localGrapeMGridView = ((MinePhotoViewHolder)paramViewHolder).gridView;
      this.gridViewAdapter = new MineGridViewAdapter(((FitnessPicModel)this.list.get(i)).lstPhoto, this.mContext, this.type, this.sListener, this.selectList);
      localGrapeMGridView.setAdapter(this.gridViewAdapter);
      localGrapeMGridView.setOnItemClickListener(new AdapterView.OnItemClickListener(i)
      {
        @Instrumented
        public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
        {
          VdsAgent.onItemClick(this, paramAdapterView, paramView, paramInt, paramLong);
          if ("1".equals(MinePhotoAlbumAdapter.this.type))
          {
            if (MinePhotoAlbumAdapter.this.sListener != null)
              MinePhotoAlbumAdapter.this.sListener.selectImg((FitnessPicItemModel)((FitnessPicModel)MinePhotoAlbumAdapter.this.list.get(this.val$cPos)).lstPhoto.get(paramInt));
            return;
          }
          MiddleManager.getInstance().getFindPresenterImpl(MinePhotoAlbumAdapter.this.listener, null).statsTrainInfoImgClick(((FitnessPicItemModel)((FitnessPicModel)MinePhotoAlbumAdapter.this.list.get(this.val$cPos)).lstPhoto.get(paramInt)).olapInfo);
          Intent localIntent = new Intent(MinePhotoAlbumAdapter.this.mContext, Mine03PhotoViewPagerActivity.class);
          localIntent.putExtra("index", paramInt);
          localIntent.putExtra("data.list", MinePhotoAlbumAdapter.this.list);
          Bundle localBundle = new Bundle();
          localBundle.putSerializable("item.model", (Serializable)((FitnessPicModel)MinePhotoAlbumAdapter.this.list.get(this.val$cPos)).lstPhoto.get(paramInt));
          localIntent.putExtras(localBundle);
          MinePhotoAlbumAdapter.this.mContext.startActivity(localIntent);
          AnimationUtil.pageJumpAnim((Activity)MinePhotoAlbumAdapter.this.mContext, 0);
        }
      });
    }
  }

  public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup paramViewGroup)
  {
    return new MinePhotoTitleViewHolder(LayoutInflater.from(this.mContext).inflate(2130968973, paramViewGroup, false));
  }

  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup paramViewGroup, int paramInt)
  {
    return new MinePhotoViewHolder(LayoutInflater.from(this.mContext).inflate(2130968972, null, false));
  }

  public void setList(ArrayList<FitnessPicModel> paramArrayList)
  {
    this.list = paramArrayList;
  }

  public void setSelectList(ArrayList<FitnessPicItemModel> paramArrayList)
  {
    this.selectList = paramArrayList;
  }

  public void setType(String paramString)
  {
    this.type = paramString;
  }

  private class MinePhotoTitleViewHolder extends RecyclerView.ViewHolder
  {
    CustomTextView titleView;

    MinePhotoTitleViewHolder(View arg2)
    {
      super();
      this.titleView = ((CustomTextView)localView.findViewById(2131756675));
    }
  }

  private class MinePhotoViewHolder extends RecyclerView.ViewHolder
  {
    GrapeMGridView gridView;

    MinePhotoViewHolder(View arg2)
    {
      super();
      this.gridView = ((GrapeMGridView)localView.findViewById(2131756674));
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.adapter.MinePhotoAlbumAdapter
 * JD-Core Version:    0.6.0
 */