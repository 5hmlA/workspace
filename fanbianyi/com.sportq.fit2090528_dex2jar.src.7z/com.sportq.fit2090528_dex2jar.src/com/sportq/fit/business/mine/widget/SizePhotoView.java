package com.sportq.fit.business.mine.widget;

import android.content.Context;
import android.content.res.Resources;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.business.BaseNavView;
import com.sportq.fit.business.mine.adapter.MineGridViewAdapter.SelectImgListener;
import com.sportq.fit.business.mine.adapter.MinePhotoAlbumAdapter;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.FitnessPicItemModel;
import com.sportq.fit.common.model.FitnessPicModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.FitnessAlbumPhotoReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreAdapter;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper.OnLoadMoreWarpperListener;
import com.sportq.fit.common.utils.stickrecycleradapter.StickyRecyclerHeadersDecoration;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

public class SizePhotoView extends BaseNavView
  implements LoadMoreWrapper.OnLoadMoreWarpperListener
{
  private MinePhotoAlbumAdapter adapter;
  private RelativeLayout bottom_layout;
  private RelativeLayout emptyView;
  private TextView fitness_comparison_btn;
  public String lastId;
  private MineGridViewAdapter.SelectImgListener listener;
  private LoadMoreWrapper loadMoreWrapper;
  private Context mContext;
  private ArrayList<FitnessPicModel> mList;
  private FitnessAlbumPhotoReformer mReformer;
  private RelativeLayout no_network_layout;
  private RecyclerView recyclerView;
  private TextView refresh_btn;
  private CompareBtnClickListener sListener;

  public SizePhotoView(Context paramContext)
  {
    super(paramContext);
  }

  public SizePhotoView(Context paramContext, MineGridViewAdapter.SelectImgListener paramSelectImgListener, CompareBtnClickListener paramCompareBtnClickListener)
  {
    super(paramContext);
    this.mContext = paramContext;
    this.listener = paramSelectImgListener;
    this.sListener = paramCompareBtnClickListener;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(2130969007, null);
    this.recyclerView = ((RecyclerView)localView.findViewById(2131755283));
    this.emptyView = ((RelativeLayout)localView.findViewById(2131755697));
    this.bottom_layout = ((RelativeLayout)localView.findViewById(2131755230));
    this.bottom_layout.setVisibility(0);
    this.fitness_comparison_btn = ((TextView)localView.findViewById(2131756853));
    RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)this.recyclerView.getLayoutParams();
    localLayoutParams.bottomMargin = CompDeviceInfoUtils.convertOfDip(this.mContext, 55.0F);
    this.recyclerView.setLayoutParams(localLayoutParams);
    this.fitness_comparison_btn.setTextColor(ContextCompat.getColor(this.mContext, 2131624024));
    this.fitness_comparison_btn.setOnClickListener(null);
    this.no_network_layout = ((RelativeLayout)localView.findViewById(2131755486));
    this.refresh_btn = ((TextView)localView.findViewById(2131755488));
    this.refresh_btn.setOnClickListener(new FitAction(this));
    return localView;
  }

  public void delRefreshData()
  {
    this.lastId = "";
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.recordDate = this.lastId;
    localRequestModel.photoType = "1";
    MiddleManager.getInstance().getMinePresenterImpl(this).getTrainPhotoAlbum(localRequestModel, this.mContext);
  }

  public void fitOnClick(View paramView)
  {
    if (2131756853 == paramView.getId())
    {
      paramView.setTag("p.c.c|!|g-alb|!|c.g-alb.mk|!|");
      if (this.sListener != null)
        this.sListener.compareBtnClick(this.fitness_comparison_btn);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() != 2131755488)
        continue;
      if (!CompDeviceInfoUtils.checkNetwork())
      {
        ToastUtils.makeToast(this.mContext, StringUtils.getStringResources(2131298238));
        return;
      }
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.recordDate = "";
      localRequestModel.photoType = "1";
      MiddleManager.getInstance().getMinePresenterImpl(this).getTrainPhotoAlbum(localRequestModel, this.mContext);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.fitness_comparison_btn.setTextColor(ContextCompat.getColor(this.mContext, 2131624024));
    this.fitness_comparison_btn.setOnClickListener(null);
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.mReformer = ((FitnessAlbumPhotoReformer)paramT);
    if (this.mReformer == null)
    {
      if (this.recyclerView.getTag() != null)
      {
        this.loadMoreWrapper.setLoadMoreEnabled(false);
        this.adapter.notifyDataSetChanged();
        this.recyclerView.setTag(null);
        return;
      }
      this.mList = null;
      this.emptyView.setVisibility(0);
      this.no_network_layout.setVisibility(8);
      this.recyclerView.setVisibility(8);
      this.fitness_comparison_btn.setTextColor(ContextCompat.getColor(this.mContext, 2131624024));
      this.fitness_comparison_btn.setOnClickListener(null);
      return;
    }
    if (this.mList == null)
    {
      this.mList = this.mReformer.lstAlbum;
      this.emptyView.setVisibility(8);
      this.no_network_layout.setVisibility(8);
      this.recyclerView.setVisibility(0);
      this.fitness_comparison_btn.setTextColor(ContextCompat.getColor(this.mContext, 2131624003));
      this.fitness_comparison_btn.setOnClickListener(new FitAction(this));
      this.adapter = new MinePhotoAlbumAdapter(this, this.listener, this.mContext, this.mList);
      this.recyclerView.setLayoutManager(new LinearLayoutManager(this.mContext));
      this.recyclerView.setAdapter(this.adapter);
      if (this.loadMoreWrapper == null)
        this.recyclerView.addItemDecoration(new StickyRecyclerHeadersDecoration(this.adapter));
      this.loadMoreWrapper = new LoadMoreWrapper(new LoadMoreAdapter(this.adapter), this);
      this.loadMoreWrapper.setShowNoMoreEnabled(false);
      this.loadMoreWrapper.into(this.recyclerView);
    }
    while (true)
    {
      this.lastId = this.mReformer.strHisotry;
      this.recyclerView.setTag(null);
      super.getDataSuccess(paramT);
      return;
      if (this.recyclerView.getTag() != null)
      {
        if (this.mReformer.lstAlbum.size() > 0)
        {
          this.mList.addAll(this.mReformer.lstAlbum);
          this.adapter.setList(this.mList);
          this.adapter.notifyDataSetChanged();
          continue;
        }
        this.loadMoreWrapper.setLoadMoreEnabled(false);
        this.adapter.notifyDataSetChanged();
        continue;
      }
      this.mList = this.mReformer.lstAlbum;
      this.adapter.setList(this.mList);
      this.adapter.notifyDataSetChanged();
    }
  }

  public void onLoadMore()
  {
    if (this.recyclerView == null)
      return;
    if (CompDeviceInfoUtils.checkNetwork())
    {
      this.recyclerView.setTag("load.more");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.recordDate = this.lastId;
      localRequestModel.photoType = "1";
      MiddleManager.getInstance().getMinePresenterImpl(this).getTrainPhotoAlbum(localRequestModel, this.mContext);
      return;
    }
    ToastUtils.makeToast(this.mContext, getResources().getString(2131299052));
  }

  public void refreshData(ArrayList<FitnessPicItemModel> paramArrayList, String paramString)
  {
    if (paramArrayList.size() == 0)
      if ("1".equals(paramString))
      {
        this.fitness_comparison_btn.setText(2131299043);
        this.fitness_comparison_btn.setTextColor(ContextCompat.getColor(this.mContext, 2131624071));
        this.fitness_comparison_btn.setBackgroundColor(ContextCompat.getColor(this.mContext, 2131624105));
        this.fitness_comparison_btn.setOnClickListener(null);
      }
    while (true)
    {
      if (this.adapter != null)
      {
        this.adapter.setType(paramString);
        this.adapter.setSelectList(paramArrayList);
        this.adapter.notifyDataSetChanged();
      }
      return;
      this.fitness_comparison_btn.setText(2131297430);
      this.fitness_comparison_btn.setTextColor(ContextCompat.getColor(this.mContext, 2131624003));
      this.fitness_comparison_btn.setBackgroundColor(ContextCompat.getColor(this.mContext, 2131624121));
      this.fitness_comparison_btn.setOnClickListener(new FitAction(this));
      continue;
      this.fitness_comparison_btn.setText(2131299043);
      if (paramArrayList.size() >= 2)
      {
        this.fitness_comparison_btn.setTextColor(ContextCompat.getColor(this.mContext, 2131624003));
        this.fitness_comparison_btn.setBackgroundColor(ContextCompat.getColor(this.mContext, 2131624121));
        this.fitness_comparison_btn.setOnClickListener(new FitAction(this));
        continue;
      }
      this.fitness_comparison_btn.setTextColor(ContextCompat.getColor(this.mContext, 2131624071));
      this.fitness_comparison_btn.setOnClickListener(null);
      this.fitness_comparison_btn.setBackgroundColor(ContextCompat.getColor(this.mContext, 2131624105));
    }
  }

  public void setSizePhotoData()
  {
    if ((this.adapter == null) && (!CompDeviceInfoUtils.checkNetwork()))
    {
      this.no_network_layout.setVisibility(0);
      this.emptyView.setVisibility(8);
      this.bottom_layout.setVisibility(8);
      this.recyclerView.setVisibility(8);
    }
    do
    {
      return;
      this.bottom_layout.setVisibility(0);
    }
    while ((this.adapter != null) && (this.adapter.getItemCount() > 0));
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      this.fitness_comparison_btn.setTextColor(ContextCompat.getColor(this.mContext, 2131624024));
      this.fitness_comparison_btn.setOnClickListener(null);
    }
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.recordDate = "";
    localRequestModel.photoType = "1";
    MiddleManager.getInstance().getMinePresenterImpl(this).getTrainPhotoAlbum(localRequestModel, this.mContext);
  }

  public static abstract interface CompareBtnClickListener
  {
    public abstract void compareBtnClick(TextView paramTextView);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.widget.SizePhotoView
 * JD-Core Version:    0.6.0
 */