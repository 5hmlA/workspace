package com.sportq.fit.business.mine.widget;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.activity.Mine03WebUrlActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.EntcouponDetData;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.fitmoudle13.shop.utils.MineOrderTools;
import com.sportq.fit.fitmoudle9.energy.reformer.model.ExchangeModel;
import com.sportq.fit.user_behavior.UserBehaviorImpl;

public class NewCouponDialog
{
  private Dialog dialog;
  private DialogInterface.OnDismissListener onDismissListener;

  public NewCouponDialog create(Context paramContext, EntcouponDetData paramEntcouponDetData)
  {
    if (((paramContext instanceof Activity)) && (((Activity)paramContext).isFinishing()))
      return this;
    if (this.dialog == null)
    {
      this.dialog = new Dialog(paramContext);
      this.dialog.requestWindowFeature(1);
      this.dialog.setCancelable(true);
      this.dialog.setCanceledOnTouchOutside(true);
      this.dialog.setContentView(2130968766);
      this.dialog.getWindow().setBackgroundDrawableResource(2131624292);
      WindowManager.LayoutParams localLayoutParams = this.dialog.getWindow().getAttributes();
      localLayoutParams.gravity = 17;
      this.dialog.getWindow().setAttributes(localLayoutParams);
      new Handler().post(new Runnable()
      {
        public void run()
        {
          Dialog localDialog = NewCouponDialog.this.dialog;
          localDialog.show();
          VdsAgent.showDialog((Dialog)localDialog);
        }
      });
    }
    while (true)
    {
      ((CustomTextView)this.dialog.findViewById(2131755837)).setText(paramEntcouponDetData.couponTitle);
      ((CustomTextView)this.dialog.findViewById(2131755838)).setText(paramEntcouponDetData.limitComment);
      CustomTextView localCustomTextView1 = (CustomTextView)this.dialog.findViewById(2131755835);
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = paramEntcouponDetData.couponAmount;
      localCustomTextView1.setText(String.format("¥%s", arrayOfObject1));
      CustomTextView localCustomTextView2 = (CustomTextView)this.dialog.findViewById(2131755836);
      Object[] arrayOfObject2 = new Object[1];
      arrayOfObject2[0] = paramEntcouponDetData.fullAmount;
      localCustomTextView2.setText(String.format("满%s元可用", arrayOfObject2));
      this.dialog.findViewById(2131755840).setOnClickListener(new View.OnClickListener(paramEntcouponDetData)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          new UserBehaviorImpl().newUserCouponClick("1", this.val$data.couponId);
          NewCouponDialog.this.dialog.dismiss();
        }
      });
      this.dialog.findViewById(2131755839).setOnClickListener(new View.OnClickListener(paramContext, paramEntcouponDetData)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          MineOrderTools.checkCouponJump(this.val$context, this.val$data, false);
          NewCouponDialog.this.dialog.dismiss();
          new UserBehaviorImpl().newUserCouponClick("0", this.val$data.couponId);
        }
      });
      this.dialog.setOnDismissListener(this.onDismissListener);
      return this;
      if (this.dialog.isShowing())
        continue;
      new Handler().post(new Runnable()
      {
        public void run()
        {
          Dialog localDialog = NewCouponDialog.this.dialog;
          localDialog.show();
          VdsAgent.showDialog((Dialog)localDialog);
        }
      });
    }
  }

  public void exchangeDialog(Context paramContext, int paramInt, ExchangeModel paramExchangeModel)
  {
    Dialog localDialog = new Dialog(paramContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setCancelable(true);
    localDialog.setContentView(2130968805);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.8611D * BaseApplication.screenWidth);
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    ((ImageView)localDialog.findViewById(2131755501)).setImageResource(paramInt);
    TextView localTextView = (TextView)localDialog.findViewById(2131755981);
    String str1;
    RTextView localRTextView;
    String str2;
    if (StringUtils.isNull(paramExchangeModel.title))
    {
      str1 = "兑换成功";
      localTextView.setText(str1);
      ((TextView)localDialog.findViewById(2131755502)).setText(paramExchangeModel.message);
      localRTextView = (RTextView)localDialog.findViewById(2131755503);
      if (!"MESSAGE_31".equals(paramExchangeModel.code))
        break label270;
      str2 = paramContext.getString(2131297870);
      label183: localRTextView.setText(str2);
      if (!localRTextView.getText().toString().equals(paramContext.getString(2131297870)))
        break label281;
      localRTextView.setOnClickListener(new View.OnClickListener(paramContext, paramExchangeModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          Intent localIntent = new Intent(this.val$mContext, Mine03WebUrlActivity.class);
          localIntent.putExtra("webUrl", this.val$exchangeModel.linkUrl);
          this.val$mContext.startActivity(localIntent);
        }
      });
    }
    while (true)
    {
      localDialog.findViewById(2131755439).setOnClickListener(new View.OnClickListener(localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$dialog.dismiss();
        }
      });
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      return;
      str1 = paramExchangeModel.title;
      break;
      label270: str2 = paramContext.getString(2131297578);
      break label183;
      label281: localRTextView.setOnClickListener(new View.OnClickListener(localDialog)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$dialog.dismiss();
        }
      });
    }
  }

  public void setOnDismissListener(DialogInterface.OnDismissListener paramOnDismissListener)
  {
    this.onDismissListener = paramOnDismissListener;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.widget.NewCouponDialog
 * JD-Core Version:    0.6.0
 */