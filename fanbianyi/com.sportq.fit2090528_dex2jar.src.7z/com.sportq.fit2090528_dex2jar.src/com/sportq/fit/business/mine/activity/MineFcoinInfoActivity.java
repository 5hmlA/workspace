package com.sportq.fit.business.mine.activity;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.adapter.MineFcoinInfoAdapter;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.superloadmore.SuperLoadMoreAdapter.OnLoadMoreListener;
import com.sportq.fit.persenter.AppPresenterImpl;
import com.sportq.fit.persenter.reformer.GetFcoinInfoReformer;
import java.util.ArrayList;

public class MineFcoinInfoActivity extends BaseActivity
{
  private MineFcoinInfoAdapter adapter;

  @Bind({2131755907})
  TextView empty_hint;

  @Bind({2131755906})
  ImageView empty_icon;

  @Bind({2131755697})
  LinearLayout empty_layout;
  private GetFcoinInfoReformer fcoinInfoReformer;

  @Bind({2131755532})
  RecyclerView recyclerView;

  @Bind({2131755432})
  CustomToolBar toolbar;

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof GetFcoinInfoReformer))
    {
      this.fcoinInfoReformer = ((GetFcoinInfoReformer)paramT);
      if (((this.fcoinInfoReformer.lstEnergyDet == null) || (this.fcoinInfoReformer.lstEnergyDet.size() == 0)) && (this.adapter == null))
      {
        this.recyclerView.setVisibility(8);
        this.empty_layout.setVisibility(0);
        this.empty_icon.setImageDrawable(ContextCompat.getDrawable(this, 2130903414));
        this.empty_hint.setText("还没有明细记录~");
      }
    }
    else
    {
      return;
    }
    if (this.adapter == null)
    {
      this.adapter = new MineFcoinInfoAdapter(this, this.fcoinInfoReformer.lstEnergyDet, 2130969002);
      this.adapter.setOnLoadMoreListener(new SuperLoadMoreAdapter.OnLoadMoreListener()
      {
        public void onLoadFailed()
        {
        }

        public void onLoadMore()
        {
          RequestModel localRequestModel = new RequestModel();
          localRequestModel.histId = MineFcoinInfoActivity.this.fcoinInfoReformer.tradeId;
          new AppPresenterImpl(MineFcoinInfoActivity.this).getFcoinInfo(MineFcoinInfoActivity.this, localRequestModel);
        }

        public void onLoadSucceed()
        {
        }
      });
      this.recyclerView.setAdapter(this.adapter);
    }
    while (true)
    {
      this.recyclerView.post(new Runnable()
      {
        public void run()
        {
          MineFcoinInfoAdapter localMineFcoinInfoAdapter;
          if (MineFcoinInfoActivity.this.adapter != null)
          {
            localMineFcoinInfoAdapter = MineFcoinInfoActivity.this.adapter;
            if ("1".equals(MineFcoinInfoActivity.this.fcoinInfoReformer.hasNextPage))
              break label55;
          }
          label55: for (boolean bool = true; ; bool = false)
          {
            localMineFcoinInfoAdapter.setEnd(bool);
            MineFcoinInfoActivity.this.adapter.setLoadingMore(false);
            return;
          }
        }
      });
      return;
      this.adapter.addAll(this.fcoinInfoReformer.lstEnergyDet);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969003);
    ButterKnife.bind(this);
    this.toolbar.setTitle("F币明细");
    this.toolbar.setNavIcon(2130903080);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, 2131624003));
    this.toolbar.setBackgroundResource(2131624328);
    setSupportActionBar(this.toolbar);
    this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
    new AppPresenterImpl(this).getFcoinInfo(this, new RequestModel());
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.MineFcoinInfoActivity
 * JD-Core Version:    0.6.0
 */