package com.sportq.fit.business.mine.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.widget.TextView;
import com.sportq.fit.fitmoudle.widget.superloadmore.SuperLoadMoreAdapter;
import com.sportq.fit.persenter.model.GetFcoinInfoModel;
import java.util.List;
import org.byteam.superadapter.SuperViewHolder;

public class MineFcoinInfoAdapter extends SuperLoadMoreAdapter<GetFcoinInfoModel>
{
  public MineFcoinInfoAdapter(Context paramContext, List paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, GetFcoinInfoModel paramGetFcoinInfoModel)
  {
    ((TextView)paramSuperViewHolder.findViewById(2131755041)).setText(paramGetFcoinInfoModel.comment);
    ((TextView)paramSuperViewHolder.findViewById(2131756331)).setText(paramGetFcoinInfoModel.tradeTime);
    ((TextView)paramSuperViewHolder.findViewById(2131756370)).setText(paramGetFcoinInfoModel.energyValue);
    ((TextView)paramSuperViewHolder.findViewById(2131756370)).setTextColor(ContextCompat.getColor(getContext(), paramGetFcoinInfoModel.energyColor));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.adapter.MineFcoinInfoAdapter
 * JD-Core Version:    0.6.0
 */