package com.sportq.fit.business.mine.activity;

import android.app.Application;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Switch;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.business.account.activity.Account02VideoGuideActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CustomerServiceUtils;
import com.sportq.fit.common.utils.HwIdUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.supportlib.CommonUtils;
import com.sportq.fit.supportlib.http.request.SptQJsonObjectRequest;
import com.sportq.fit.supportlib.http.response.dataparser.ResultParser;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.FormEncodingBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Request.Builder;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.ResponseBody;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import org.greenrobot.eventbus.EventBus;
import org.json.JSONObject;

public class TestFunctionActivity extends BaseActivity
{
  private ImageView aloneApiView;
  private ImageView aloneDbApiView;
  private RotateAnimation animation;

  @Bind({2131757448})
  RadioButton apiButton01;

  @Bind({2131757450})
  RadioButton apiButton02;

  @Bind({2131757451})
  RadioButton apiButton03;

  @Bind({2131757452})
  RadioButton apiButton04;

  @Bind({2131757453})
  RadioButton apiButton05;

  @Bind({2131757454})
  RadioButton apiButton06;

  @Bind({2131757449})
  RadioButton apiButton07;
  private int apiIndex = -1;
  private ArrayList<String> apiList;

  @Bind({2131757447})
  RadioGroup apiRadioGroup;

  @Bind({2131757461})
  RadioButton bdButton01;

  @Bind({2131757462})
  RadioButton bdButton02;

  @Bind({2131757460})
  RadioGroup bdRadioGroup;

  @Bind({2131757435})
  TextView cache_switch_hint;

  @Bind({2131757436})
  Switch cache_switch_item;

  @Bind({2131757432})
  TextView change_channel_name;

  @Bind({2131755478})
  EditText edit_text;
  private String initApiAddress;
  private ImageView loading_img;
  private Dialog mDialog;

  @Bind({2131757434})
  Switch quickFinishSwitchLayout;

  @Bind({2131757433})
  TextView quickFinishSwitchText;
  private HashMap<String, String> resultMap = new HashMap();
  private TextView result_view;
  private LinearLayout start_view;
  CompoundButton.OnCheckedChangeListener switchListener = new CompoundButton.OnCheckedChangeListener()
  {
    @Instrumented
    public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
    {
      float f = 1.0F;
      VdsAgent.onCheckedChanged(this, paramCompoundButton, paramBoolean);
      switch (paramCompoundButton.getId())
      {
      case 2131757435:
      default:
        return;
      case 2131757434:
        VersionUpdateCheck.QUICK_FINISH_TRAIN = paramBoolean;
        TextView localTextView2 = TestFunctionActivity.this.quickFinishSwitchText;
        if (paramBoolean);
        while (true)
        {
          localTextView2.setAlpha(f);
          return;
          f = 0.4F;
        }
      case 2131757436:
      }
      TextView localTextView1 = TestFunctionActivity.this.cache_switch_hint;
      if (paramBoolean);
      while (true)
      {
        localTextView1.setAlpha(f);
        SharePreferenceUtils.putGlobalUseCacheFlg(paramBoolean);
        return;
        f = 0.4F;
      }
    }
  };
  private Dialog testDialog;
  private String testName;

  @Bind({2131755432})
  CustomToolBar toolbar;

  @Bind({2131757431})
  TextView video_url_test_function;

  private void initAddress()
  {
    int i = 0;
    if (i < this.apiRadioGroup.getChildCount())
    {
      if (i != -1 + this.apiRadioGroup.getChildCount())
        break label112;
      this.edit_text.setHint(VersionUpdateCheck.HOST_ADDRESS.replace("https://", ""));
      ((RadioButton)this.apiRadioGroup.getChildAt(i)).setChecked(true);
    }
    label58: for (int j = 0; ; j++)
    {
      if (j < this.bdRadioGroup.getChildCount())
      {
        String str1 = this.bdRadioGroup.getChildAt(j).getTag().toString();
        if (!VersionUpdateCheck.STATISTICS_HOST_ADDRESS.equals(str1))
          continue;
        ((RadioButton)this.bdRadioGroup.getChildAt(j)).setChecked(true);
      }
      return;
      label112: String str2 = this.apiRadioGroup.getChildAt(i).getTag().toString();
      if (VersionUpdateCheck.HOST_ADDRESS.equals(str2))
      {
        ((RadioButton)this.apiRadioGroup.getChildAt(i)).setChecked(true);
        break label58;
      }
      i++;
      break;
    }
  }

  private void initSwitch()
  {
    float f1 = 1.0F;
    this.quickFinishSwitchLayout.setChecked(VersionUpdateCheck.QUICK_FINISH_TRAIN);
    TextView localTextView1 = this.quickFinishSwitchText;
    float f2;
    TextView localTextView2;
    if (VersionUpdateCheck.QUICK_FINISH_TRAIN)
    {
      f2 = f1;
      localTextView1.setAlpha(f2);
      localTextView2 = this.cache_switch_hint;
      if (!SharePreferenceUtils.getGlobalUseCacheFlg())
        break label65;
    }
    while (true)
    {
      localTextView2.setAlpha(f1);
      this.cache_switch_item.setChecked(SharePreferenceUtils.getGlobalUseCacheFlg());
      return;
      f2 = 0.4F;
      break;
      label65: f1 = 0.4F;
    }
  }

  private HashMap<String, Object> modelToJSONObject(String paramString, RequestModel paramRequestModel)
  {
    HashMap localHashMap1 = new HashMap();
    FormEncodingBuilder localFormEncodingBuilder = new FormEncodingBuilder();
    HashMap localHashMap2 = new HashMap();
    localFormEncodingBuilder.add("form.userId", "30461");
    localHashMap2.put("form.userId", "30461");
    localFormEncodingBuilder.add("form.mySex", "0");
    localHashMap2.put("form.mySex", "0");
    localFormEncodingBuilder.add("form.sex", "1");
    localHashMap2.put("form.sex", "1");
    String str1 = CompDeviceInfoUtils.getVersionCode();
    localFormEncodingBuilder.add("form.version", str1);
    localHashMap2.put("form.version", str1);
    String str2 = SharePreferenceUtils.getUserDeviceId(BaseApplication.appliContext);
    localFormEncodingBuilder.add("form.device", str2);
    localHashMap2.put("form.device", str2);
    localFormEncodingBuilder.add("form.phoneType", "0");
    localHashMap2.put("form.phoneType", "0");
    String str3;
    if (VersionUpdateCheck.BUGTAGS_ON)
      str3 = "1";
    while (true)
    {
      localFormEncodingBuilder.add("form.isBuild", str3);
      localHashMap2.put("form.isBuild", str3);
      String str4 = CompDeviceInfoUtils.generateMD5Encrypt("30461" + str1 + str2 + paramString + NdkUtils.getSignBaseUrl()).toUpperCase();
      localFormEncodingBuilder.add("form.sign", str4);
      localHashMap2.put("form.sign", str4);
      if (paramRequestModel == null)
        break;
      Field[] arrayOfField = paramRequestModel.getClass().getDeclaredFields();
      int i = arrayOfField.length;
      int j = 0;
      label299: if (j >= i)
        break;
      Field localField = arrayOfField[j];
      localField.setAccessible(true);
      try
      {
        String str5 = String.valueOf(localField.get(paramRequestModel));
        if ((!"null".equals(str5)) && (!"serialVersionUID".equals(localField.getName())) && (!"strKey".equals(localField.getName())) && (!"strTrainStatus".equals(localField.getName())) && (!"strIsUseCache".equals(localField.getName())))
        {
          localFormEncodingBuilder.add("form." + localField.getName(), str5);
          localHashMap2.put("form." + localField.getName(), str5);
        }
        j++;
        break label299;
        str3 = "0";
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return localHashMap1;
      }
    }
    localHashMap1.put("0", localFormEncodingBuilder.build());
    localHashMap1.put("1", localHashMap2);
    return localHashMap1;
  }

  private void reLoginDialog()
  {
    if (!this.initApiAddress.equals(VersionUpdateCheck.HOST_ADDRESS))
    {
      this.mDialog = this.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          if (paramInt == -1)
          {
            VersionUpdateCheck.BACK_ADDRESS = VersionUpdateCheck.HOST_ADDRESS;
            VersionUpdateCheck.HOST_ADDRESS01 = VersionUpdateCheck.HOST_ADDRESS;
            Intent localIntent = new Intent(TestFunctionActivity.this, Account02VideoGuideActivity.class);
            TestFunctionActivity.this.startActivity(localIntent);
            EventBus.getDefault().post("change.api");
            CommonUtils.deleteAllCache();
            CustomerServiceUtils.logout();
            SharePreferenceUtils.putLoginStatus(TestFunctionActivity.this, "");
            PreferencesTools.delValueToTable("tbl_usermodel", "usermodel");
            BaseApplication.userModel.password = "";
            SharePreferenceUtils.putWechatUnionId(TestFunctionActivity.this, "");
            SharePreferenceUtils.putUnionid(TestFunctionActivity.this, "");
            SharePreferenceUtils.putQQtoken(TestFunctionActivity.this, "");
            FitJumpImpl.getInstance().exitRemoveTag(TestFunctionActivity.this);
            MiddleManager.getInstance().getRegisterPresenterImpl(TestFunctionActivity.this).ssoRemoveAccount(TestFunctionActivity.this, "Wechat");
            MiddleManager.getInstance().getRegisterPresenterImpl(TestFunctionActivity.this).ssoRemoveAccount(TestFunctionActivity.this, "SinaWeibo");
            MiddleManager.getInstance().getRegisterPresenterImpl(TestFunctionActivity.this).ssoRemoveAccount(TestFunctionActivity.this, "QQ");
            MiddleManager.getInstance().getRegisterPresenterImpl(TestFunctionActivity.this).ssoRemoveAccount(TestFunctionActivity.this, "huawei");
            TestFunctionActivity.this.finish();
          }
        }
      }
      , this, "", "服务器地址已更换，请重新登录", "重新登录", "");
      this.mDialog.setCancelable(false);
      this.mDialog.setCanceledOnTouchOutside(false);
      return;
    }
    finish();
  }

  private void requestApi()
  {
    this.apiIndex = (1 + this.apiIndex);
    if (this.apiIndex > -1 + this.apiList.size())
    {
      StringBuilder localStringBuilder = new StringBuilder();
      Iterator localIterator = this.apiList.iterator();
      while (localIterator.hasNext())
      {
        String str1 = (String)localIterator.next();
        localStringBuilder.append(str1 + ":" + (String)this.resultMap.get(str1));
        if (this.apiList.indexOf(str1) == -1 + this.apiList.size())
          continue;
        localStringBuilder.append("\n");
      }
      showResultDialog(localStringBuilder.toString());
      return;
    }
    String str2 = "http://" + (String)this.apiList.get(this.apiIndex) + "/SFitWeb/sfit/getLevel";
    OkHttpClient localOkHttpClient = new OkHttpClient();
    localOkHttpClient.setReadTimeout(20L, TimeUnit.SECONDS);
    localOkHttpClient.setWriteTimeout(20L, TimeUnit.SECONDS);
    localOkHttpClient.setConnectTimeout(20L, TimeUnit.SECONDS);
    HashMap localHashMap = modelToJSONObject("/SFitWeb/sfit/getLevel", new RequestModel());
    String str3 = SptQJsonObjectRequest.getParams((HashMap)localHashMap.get("1"));
    LogUtils.e("请求的网络链接", str2 + str3);
    localOkHttpClient.newCall(new Request.Builder().url(str2).post((RequestBody)localHashMap.get("0")).build()).enqueue(new Callback()
    {
      public void onFailure(Request paramRequest, IOException paramIOException)
      {
        TestFunctionActivity.this.resultMap.put(TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "未通过");
        LogUtils.e((String)TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "未通过");
        TestFunctionActivity.this.requestApi();
      }

      public void onResponse(Response paramResponse)
      {
        try
        {
          JSONObject localJSONObject1 = new JSONObject(paramResponse.body().string());
          if (ResultParser.isOK(localJSONObject1).booleanValue())
          {
            JSONObject localJSONObject2 = localJSONObject1.optJSONObject("entRet");
            ResponseModel localResponseModel = (ResponseModel)new Gson().fromJson(localJSONObject2.toString(), ResponseModel.class);
            if ((localResponseModel.lstLevel != null) && (localResponseModel.lstLevel.size() > 0))
            {
              TestFunctionActivity.this.resultMap.put(TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "通过");
              TestFunctionActivity.this.requestApi();
              return;
            }
            TestFunctionActivity.this.resultMap.put(TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "未通过");
            TestFunctionActivity.this.requestApi();
            return;
          }
        }
        catch (Exception localException)
        {
          TestFunctionActivity.this.resultMap.put(TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "未通过");
          TestFunctionActivity.this.requestApi();
          return;
        }
        TestFunctionActivity.this.resultMap.put(TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "未通过");
        TestFunctionActivity.this.requestApi();
      }
    });
  }

  private void requestApi02()
  {
    this.apiIndex = (1 + this.apiIndex);
    if (this.apiIndex > -1 + this.apiList.size())
    {
      StringBuilder localStringBuilder = new StringBuilder();
      Iterator localIterator = this.apiList.iterator();
      while (localIterator.hasNext())
      {
        String str1 = (String)localIterator.next();
        localStringBuilder.append(str1 + ":" + (String)this.resultMap.get(str1));
        if (this.apiList.indexOf(str1) == -1 + this.apiList.size())
          continue;
        localStringBuilder.append("\n");
      }
      showResultDialog(localStringBuilder.toString());
      return;
    }
    String str2 = "http://" + (String)this.apiList.get(this.apiIndex) + "/SFitWeb/sfit/getUserInfo";
    OkHttpClient localOkHttpClient = new OkHttpClient();
    localOkHttpClient.setReadTimeout(20L, TimeUnit.SECONDS);
    localOkHttpClient.setWriteTimeout(20L, TimeUnit.SECONDS);
    localOkHttpClient.setConnectTimeout(20L, TimeUnit.SECONDS);
    HashMap localHashMap = modelToJSONObject("/SFitWeb/sfit/getUserInfo", new RequestModel());
    String str3 = SptQJsonObjectRequest.getParams((HashMap)localHashMap.get("1"));
    LogUtils.e("请求的网络链接", str2 + str3);
    localOkHttpClient.newCall(new Request.Builder().url(str2).post((RequestBody)localHashMap.get("0")).build()).enqueue(new Callback()
    {
      public void onFailure(Request paramRequest, IOException paramIOException)
      {
        TestFunctionActivity.this.resultMap.put(TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "请求失败");
        TestFunctionActivity.this.requestApi02();
      }

      public void onResponse(Response paramResponse)
      {
        while (true)
        {
          try
          {
            JSONObject localJSONObject1 = new JSONObject(paramResponse.body().string());
            if (ResultParser.isOK(localJSONObject1).booleanValue())
            {
              JSONObject localJSONObject2 = localJSONObject1.optJSONObject("entRet");
              ResponseModel localResponseModel = (ResponseModel)new Gson().fromJson(localJSONObject2.toString(), ResponseModel.class);
              if (localResponseModel.mineinfo == null)
                continue;
              HashMap localHashMap = TestFunctionActivity.this.resultMap;
              Object localObject = TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex);
              if (!TestFunctionActivity.this.testName.equals(localResponseModel.mineinfo.userName))
                break label249;
              str = "同步";
              localHashMap.put(localObject, str);
              TestFunctionActivity.this.requestApi02();
              return;
              TestFunctionActivity.this.resultMap.put(TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "请求异常，未返回");
              TestFunctionActivity.this.requestApi02();
              return;
            }
          }
          catch (Exception localException)
          {
            TestFunctionActivity.this.resultMap.put(TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "请求失败");
            TestFunctionActivity.this.requestApi02();
            return;
          }
          TestFunctionActivity.this.resultMap.put(TestFunctionActivity.this.apiList.get(TestFunctionActivity.this.apiIndex), "请求失败");
          TestFunctionActivity.this.requestApi02();
          return;
          label249: String str = "未同步";
        }
      }
    });
  }

  private void selectOnFouce(RadioGroup paramRadioGroup, String paramString)
  {
    paramRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(paramString)
    {
      @Instrumented
      public void onCheckedChanged(RadioGroup paramRadioGroup, int paramInt)
      {
        VdsAgent.onCheckedChanged(this, paramRadioGroup, paramInt);
        if ("0".equals(this.val$flg))
          switch (paramInt)
          {
          default:
          case 2131757448:
          case 2131757450:
          case 2131757451:
          case 2131757452:
          case 2131757453:
          case 2131757449:
          case 2131757454:
          }
        while (true)
        {
          SharePreferenceUtils.putTestPath(TestFunctionActivity.this, VersionUpdateCheck.HOST_ADDRESS);
          SharePreferenceUtils.putBdTestPath(TestFunctionActivity.this, VersionUpdateCheck.STATISTICS_HOST_ADDRESS);
          do
          {
            return;
            VersionUpdateCheck.HOST_ADDRESS = "https://bea.sportq.com";
            TestFunctionActivity.this.apiButton01.setChecked(true);
            break;
            VersionUpdateCheck.HOST_ADDRESS = "https://bea.staging.sportq.com";
            TestFunctionActivity.this.apiButton02.setChecked(true);
            break;
            VersionUpdateCheck.HOST_ADDRESS = "https://bea.dev.sportq.com";
            TestFunctionActivity.this.apiButton03.setChecked(true);
            break;
            VersionUpdateCheck.HOST_ADDRESS = "http://192.168.10.234:7001";
            TestFunctionActivity.this.apiButton04.setChecked(true);
            break;
            VersionUpdateCheck.HOST_ADDRESS = "http://192.168.10.235:7001";
            TestFunctionActivity.this.apiButton05.setChecked(true);
            break;
            VersionUpdateCheck.HOST_ADDRESS = "http://111.231.59.23:8001";
            TestFunctionActivity.this.apiButton07.setChecked(true);
            break;
          }
          while ((TestFunctionActivity.this.edit_text.getText() == null) || (StringUtils.isNull(TestFunctionActivity.this.edit_text.getText().toString())));
          VersionUpdateCheck.HOST_ADDRESS = "http://" + TestFunctionActivity.this.edit_text.getText().toString();
          TestFunctionActivity.this.apiButton06.setChecked(true);
          continue;
          if (!"1".equals(this.val$flg))
            continue;
          switch (paramInt)
          {
          default:
            break;
          case 2131757461:
            VersionUpdateCheck.STATISTICS_HOST_ADDRESS = "https://rest.dev.sportq.com/";
            TestFunctionActivity.this.bdButton01.setChecked(true);
            break;
          case 2131757462:
            VersionUpdateCheck.STATISTICS_HOST_ADDRESS = "http://211.152.49.153:8800/";
            TestFunctionActivity.this.bdButton02.setChecked(true);
          }
        }
      }
    });
  }

  private void showResultDialog(String paramString)
  {
    runOnUiThread(new Runnable(paramString)
    {
      public void run()
      {
        if ((TestFunctionActivity.this.animation != null) && (TestFunctionActivity.this.animation.hasStarted()))
          TestFunctionActivity.this.animation.cancel();
        TestFunctionActivity.this.start_view.setVisibility(8);
        TestFunctionActivity.this.result_view.setVisibility(0);
        TestFunctionActivity.this.result_view.setText(this.val$result);
        TestFunctionActivity.this.testDialog.setCanceledOnTouchOutside(true);
        TestFunctionActivity.this.testDialog.setCancelable(true);
      }
    });
  }

  private void showStartDialog()
  {
    runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (TestFunctionActivity.this.testDialog == null)
        {
          TestFunctionActivity.access$702(TestFunctionActivity.this, new Dialog(TestFunctionActivity.this));
          TestFunctionActivity.this.testDialog.requestWindowFeature(1);
          TestFunctionActivity.this.testDialog.getWindow().setBackgroundDrawableResource(17170445);
          TestFunctionActivity.this.testDialog.setContentView(2130969151);
          WindowManager.LayoutParams localLayoutParams = TestFunctionActivity.this.testDialog.getWindow().getAttributes();
          localLayoutParams.width = (int)(0.81944D * BaseApplication.screenWidth);
          localLayoutParams.gravity = 17;
          TestFunctionActivity.this.testDialog.getWindow().setAttributes(localLayoutParams);
          TestFunctionActivity.access$802(TestFunctionActivity.this, (ImageView)TestFunctionActivity.this.testDialog.findViewById(2131755888));
          TestFunctionActivity.access$902(TestFunctionActivity.this, (LinearLayout)TestFunctionActivity.this.testDialog.findViewById(2131757428));
          TestFunctionActivity.access$1002(TestFunctionActivity.this, (TextView)TestFunctionActivity.this.testDialog.findViewById(2131757429));
        }
        TestFunctionActivity.this.testDialog.setCanceledOnTouchOutside(false);
        TestFunctionActivity.this.testDialog.setCancelable(false);
        TestFunctionActivity.this.start_view.setVisibility(0);
        TestFunctionActivity.this.result_view.setVisibility(8);
        if (TestFunctionActivity.this.animation == null)
          TestFunctionActivity.access$1102(TestFunctionActivity.this, TestFunctionActivity.this.viewRotateAnimation());
        TestFunctionActivity.this.animation.reset();
        TestFunctionActivity.this.loading_img.startAnimation(TestFunctionActivity.this.animation);
        Dialog localDialog = TestFunctionActivity.this.testDialog;
        localDialog.show();
        VdsAgent.showDialog((Dialog)localDialog);
      }
    });
  }

  private void startCheckApi()
  {
    showStartDialog();
    this.apiList = new ArrayList();
    this.apiList.add("211.152.49.180:8001");
    this.apiList.add("211.152.49.180:8002");
    this.apiList.add("211.152.49.180:8003");
    this.apiList.add("211.152.49.180:8004");
    this.apiList.add("211.152.49.155:8001");
    this.apiList.add("211.152.49.155:8002");
    this.apiList.add("211.152.49.155:8003");
    this.apiList.add("211.152.49.155:8004");
    if ("select".equals(this.aloneApiView.getTag().toString()))
    {
      this.apiList.add("111.231.59.23:8001");
      this.apiList.add("111.231.59.23:8002");
      this.apiList.add("111.231.59.23:8003");
      this.apiList.add("111.231.59.23:8004");
    }
    this.apiIndex = -1;
    this.resultMap = new HashMap();
    requestApi();
  }

  private void startCheckDb()
  {
    showStartDialog();
    this.apiList = new ArrayList();
    this.apiList.add("211.152.49.180:8001");
    this.apiList.add("211.152.49.155:8001");
    if ("select".equals(this.aloneDbApiView.getTag().toString()))
      this.apiList.add("111.231.59.23:8001");
    this.testName = ("测试同步" + StringUtils.getRandom02(1000, 9999));
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.userName = this.testName;
    String str1 = "http://" + (String)this.apiList.get(0) + "/SFitWeb/sfit/updateUserInfo";
    OkHttpClient localOkHttpClient = new OkHttpClient();
    localOkHttpClient.setReadTimeout(20L, TimeUnit.SECONDS);
    localOkHttpClient.setWriteTimeout(20L, TimeUnit.SECONDS);
    localOkHttpClient.setConnectTimeout(20L, TimeUnit.SECONDS);
    HashMap localHashMap = modelToJSONObject("/SFitWeb/sfit/updateUserInfo", localRequestModel);
    String str2 = SptQJsonObjectRequest.getParams((HashMap)localHashMap.get("1"));
    LogUtils.e("请求的网络链接", str1 + str2);
    localOkHttpClient.newCall(new Request.Builder().url(str1).post((RequestBody)localHashMap.get("0")).build()).enqueue(new Callback()
    {
      public void onFailure(Request paramRequest, IOException paramIOException)
      {
        TestFunctionActivity.this.showResultDialog("更新失败");
      }

      public void onResponse(Response paramResponse)
      {
        try
        {
          JSONObject localJSONObject1 = new JSONObject(paramResponse.body().string());
          if (ResultParser.isOK(localJSONObject1).booleanValue())
          {
            JSONObject localJSONObject2 = localJSONObject1.optJSONObject("entRet");
            if (((ResponseModel)new Gson().fromJson(localJSONObject2.toString(), ResponseModel.class)).mineinfo != null)
            {
              TestFunctionActivity.access$002(TestFunctionActivity.this, -1);
              TestFunctionActivity.access$202(TestFunctionActivity.this, new HashMap());
              TestFunctionActivity.this.requestApi02();
              return;
            }
            TestFunctionActivity.this.showResultDialog("更新失败");
            return;
          }
        }
        catch (Exception localException)
        {
          TestFunctionActivity.this.showResultDialog("更新失败");
          return;
        }
        TestFunctionActivity.this.showResultDialog("更新失败");
      }
    });
  }

  private RotateAnimation viewRotateAnimation()
  {
    RotateAnimation localRotateAnimation = new RotateAnimation(0.0F, 360.0F, 1, 0.5F, 1, 0.5F);
    localRotateAnimation.setDuration(2000L);
    localRotateAnimation.setRepeatCount(-1);
    localRotateAnimation.setInterpolator(new LinearInterpolator());
    return localRotateAnimation;
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == 2131757431)
    {
      startActivity(new Intent(this, VideoUrlTestActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
    }
    do
      while (true)
      {
        super.fitOnClick(paramView);
        return;
        if (paramView.getId() == 2131755665)
        {
          startCheckApi();
          continue;
        }
        if (paramView.getId() == 2131755668)
        {
          startCheckDb();
          continue;
        }
        if (paramView.getId() == 2131755664)
        {
          if ("unSelect".equals(this.aloneApiView.getTag().toString()))
          {
            this.aloneApiView.setTag("select");
            this.aloneApiView.setImageResource(2130903276);
            continue;
          }
          this.aloneApiView.setTag("unSelect");
          this.aloneApiView.setImageResource(2130903475);
          continue;
        }
        if (paramView.getId() != 2131755667)
          break;
        if ("unSelect".equals(this.aloneDbApiView.getTag().toString()))
        {
          this.aloneDbApiView.setTag("select");
          this.aloneDbApiView.setImageResource(2130903276);
          continue;
        }
        this.aloneDbApiView.setTag("unSelect");
        this.aloneDbApiView.setImageResource(2130903475);
      }
    while (paramView.getId() != 2131757432);
    if ("Fit渠道包".equals(this.change_channel_name.getText().toString()))
      VersionUpdateCheck.DEFAULT_CHANNEL = "fit";
    while (true)
    {
      HwIdUtils.init((Application)BaseApplication.appliContext);
      HwIdUtils.connect(this);
      startActivity(new Intent(this, Account02VideoGuideActivity.class));
      EventBus.getDefault().post("change.api");
      SharePreferenceUtils.putLoginStatus(this, "");
      PreferencesTools.delValueToTable("tbl_usermodel", "usermodel");
      BaseApplication.userModel.password = "";
      SharePreferenceUtils.putWechatUnionId(this, "");
      SharePreferenceUtils.putUnionid(this, "");
      SharePreferenceUtils.putQQtoken(this, "");
      FitJumpImpl.getInstance().exitRemoveTag(this);
      MiddleManager.getInstance().getRegisterPresenterImpl(this).ssoRemoveAccount(this, "Wechat");
      MiddleManager.getInstance().getRegisterPresenterImpl(this).ssoRemoveAccount(this, "SinaWeibo");
      MiddleManager.getInstance().getRegisterPresenterImpl(this).ssoRemoveAccount(this, "QQ");
      MiddleManager.getInstance().getRegisterPresenterImpl(this).ssoRemoveAccount(this, "huawei");
      finish();
      break;
      VersionUpdateCheck.DEFAULT_CHANNEL = "huawei";
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969152);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    this.toolbar.setTitle(2131299536);
    this.toolbar.setNavIcon(-1);
    this.toolbar.setTitleTextColor(-1);
    this.toolbar.setBackgroundResource(2131624003);
    setSupportActionBar(this.toolbar);
    TextView localTextView = this.change_channel_name;
    if (CompDeviceInfoUtils.isHuaweiChannel());
    for (String str = "Fit渠道包"; ; str = "华为渠道包")
    {
      localTextView.setText(str);
      this.initApiAddress = VersionUpdateCheck.HOST_ADDRESS;
      initSwitch();
      initAddress();
      this.quickFinishSwitchLayout.setOnCheckedChangeListener(this.switchListener);
      this.cache_switch_item.setOnCheckedChangeListener(this.switchListener);
      this.aloneApiView = ((ImageView)findViewById(2131755664));
      this.aloneDbApiView = ((ImageView)findViewById(2131755667));
      selectOnFouce(this.apiRadioGroup, "0");
      selectOnFouce(this.bdRadioGroup, "1");
      return;
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      reLoginDialog();
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      reLoginDialog();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.TestFunctionActivity
 * JD-Core Version:    0.6.0
 */