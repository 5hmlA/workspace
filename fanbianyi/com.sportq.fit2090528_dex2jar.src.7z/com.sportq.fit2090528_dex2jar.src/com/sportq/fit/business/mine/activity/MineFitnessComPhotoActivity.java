package com.sportq.fit.business.mine.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.FitnessPicItemModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CustomLoad.DoneProgress.DoneProgressInterface;
import com.sportq.fit.common.utils.CustomLoad.FeedbackLoadDialog;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.LuBanUtils;
import com.sportq.fit.common.utils.LuBanUtils.PressCallBack;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.sharemanager.ShareListenerFunction;
import com.sportq.fit.fitmoudle.sharemanager.ShareManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.PlayPointModel;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle2.camera.presenter.PresenterImpl;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.http.ApiImpl;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;

public class MineFitnessComPhotoActivity extends BaseActivity
{

  @Bind({2131756845})
  TextView apart_days_view;

  @Bind({2131756838})
  ImageView compare_left_img;

  @Bind({2131756842})
  ImageView compare_right_img;
  private String fitness_days_hint;
  String fromFlg;

  @Bind({2131756840})
  TextView left_img_date;

  @Bind({2131756839})
  TextView left_img_weight;

  @Bind({2131756844})
  TextView right_img_date;

  @Bind({2131756843})
  TextView right_img_weight;

  @Bind({2131756846})
  RTextView save_fitness_photo_view;
  private ArrayList<FitnessPicItemModel> selectList;

  @Bind({2131756850})
  ImageView share_to_sina;

  @Bind({2131756849})
  ImageView share_to_wechat;

  @Bind({2131756848})
  ImageView share_to_wechatmoments;

  @Bind({2131756836})
  LinearLayout show_compare_photo_layout;
  private String strPath;

  @Bind({2131755432})
  CustomToolBar toolbar;
  String type = "";

  private void actionToShare(String paramString)
  {
    if (StringUtils.isNull(paramString))
      return;
    convertViewToBitmap(this.show_compare_photo_layout, new PressCallBack(paramString)
    {
      public void callBack(Bitmap paramBitmap)
      {
        if (paramBitmap == null)
        {
          ToastUtils.makeToast(MineFitnessComPhotoActivity.this, "图片保存失败");
          return;
        }
        new Thread(new Runnable(paramBitmap)
        {
          public void run()
          {
            if ("0".equals(MineFitnessComPhotoActivity.3.this.val$fromFlg))
              MineFitnessComPhotoActivity.this.type = "2";
            while (true)
            {
              UseShareModel localUseShareModel = new UseShareModel();
              MineFitnessComPhotoActivity.this.runOnUiThread(new Runnable(localUseShareModel)
              {
                public void run()
                {
                  this.val$model.camera_bitmap = MineFitnessComPhotoActivity.3.1.this.val$pBitmap;
                  this.val$model.camera_info = MineFitnessComPhotoActivity.this.fitness_days_hint;
                  PlayPointModel localPlayPointModel = ShareListenerFunction.pointPut(19, MineFitnessComPhotoActivity.3.this.val$fromFlg, this.val$model);
                  ShareManager localShareManager = new ShareManager(MineFitnessComPhotoActivity.this, MineFitnessComPhotoActivity.this.dialog);
                  localShareManager.setPlayPointModel(localPlayPointModel);
                  localShareManager.shareFitData(this.val$model, 19, Integer.valueOf(MineFitnessComPhotoActivity.this.type).intValue());
                }
              });
              return;
              if ("1".equals(MineFitnessComPhotoActivity.3.this.val$fromFlg))
              {
                MineFitnessComPhotoActivity.this.type = "0";
                continue;
              }
              if (!"2".equals(MineFitnessComPhotoActivity.3.this.val$fromFlg))
                continue;
              MineFitnessComPhotoActivity.this.type = "1";
            }
          }
        }).start();
      }
    });
  }

  private void init()
  {
    this.toolbar.setTitle(getString(2131298613));
    this.toolbar.setNavIcon(2130903098);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, 2131624003));
    this.toolbar.setBackgroundResource(2131624328);
    setSupportActionBar(this.toolbar);
    this.selectList = ((ArrayList)getIntent().getSerializableExtra("select.list"));
    LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)this.show_compare_photo_layout.getLayoutParams();
    localLayoutParams.height = BaseApplication.screenWidth;
    this.show_compare_photo_layout.setLayoutParams(localLayoutParams);
    setData(this.selectList);
    this.save_fitness_photo_view.setOnClickListener(new FitAction(this));
    this.share_to_wechatmoments.setOnClickListener(new FitAction(this));
    this.share_to_wechat.setOnClickListener(new FitAction(this));
    this.share_to_sina.setOnClickListener(new FitAction(this));
  }

  // ERROR //
  private String saveBitmapToLocal(Bitmap paramBitmap)
  {
    // Byte code:
    //   0: ldc 191
    //   2: invokestatic 197	com/sportq/fit/common/utils/FileUtils:getDiskCacheDir	(Ljava/lang/String;)Ljava/io/File;
    //   5: astore_2
    //   6: aload_2
    //   7: invokevirtual 203	java/io/File:exists	()Z
    //   10: ifne +8 -> 18
    //   13: aload_2
    //   14: invokevirtual 206	java/io/File:mkdirs	()Z
    //   17: pop
    //   18: new 199	java/io/File
    //   21: dup
    //   22: new 208	java/lang/StringBuilder
    //   25: dup
    //   26: invokespecial 209	java/lang/StringBuilder:<init>	()V
    //   29: aload_2
    //   30: invokevirtual 213	java/io/File:getAbsolutePath	()Ljava/lang/String;
    //   33: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   36: invokestatic 223	java/lang/System:currentTimeMillis	()J
    //   39: invokevirtual 226	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   42: ldc 228
    //   44: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   47: invokevirtual 231	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   50: invokespecial 233	java/io/File:<init>	(Ljava/lang/String;)V
    //   53: astore_3
    //   54: aconst_null
    //   55: astore 4
    //   57: new 235	java/io/FileOutputStream
    //   60: dup
    //   61: aload_3
    //   62: invokespecial 238	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   65: astore 5
    //   67: aload_1
    //   68: getstatic 244	android/graphics/Bitmap$CompressFormat:PNG	Landroid/graphics/Bitmap$CompressFormat;
    //   71: bipush 100
    //   73: aload 5
    //   75: invokevirtual 250	android/graphics/Bitmap:compress	(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    //   78: pop
    //   79: aload 5
    //   81: ifnull +8 -> 89
    //   84: aload 5
    //   86: invokevirtual 253	java/io/FileOutputStream:close	()V
    //   89: aload_1
    //   90: ifnull +7 -> 97
    //   93: aload_1
    //   94: invokevirtual 256	android/graphics/Bitmap:recycle	()V
    //   97: aload_3
    //   98: invokevirtual 213	java/io/File:getAbsolutePath	()Ljava/lang/String;
    //   101: areturn
    //   102: astore 12
    //   104: aload 12
    //   106: invokestatic 262	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   109: ldc 51
    //   111: areturn
    //   112: astore 11
    //   114: aload 11
    //   116: invokestatic 262	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   119: goto -22 -> 97
    //   122: astore 6
    //   124: aload 6
    //   126: invokestatic 262	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   129: aload 4
    //   131: ifnull +8 -> 139
    //   134: aload 4
    //   136: invokevirtual 253	java/io/FileOutputStream:close	()V
    //   139: aload_1
    //   140: ifnull -43 -> 97
    //   143: aload_1
    //   144: invokevirtual 256	android/graphics/Bitmap:recycle	()V
    //   147: goto -50 -> 97
    //   150: astore 9
    //   152: aload 9
    //   154: invokestatic 262	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   157: goto -60 -> 97
    //   160: astore 7
    //   162: aload 4
    //   164: ifnull +8 -> 172
    //   167: aload 4
    //   169: invokevirtual 253	java/io/FileOutputStream:close	()V
    //   172: aload_1
    //   173: ifnull +7 -> 180
    //   176: aload_1
    //   177: invokevirtual 256	android/graphics/Bitmap:recycle	()V
    //   180: aload 7
    //   182: athrow
    //   183: astore 8
    //   185: aload 8
    //   187: invokestatic 262	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   190: goto -10 -> 180
    //   193: astore 7
    //   195: aload 5
    //   197: astore 4
    //   199: goto -37 -> 162
    //   202: astore 6
    //   204: aload 5
    //   206: astore 4
    //   208: goto -84 -> 124
    //
    // Exception table:
    //   from	to	target	type
    //   13	18	102	java/lang/Exception
    //   84	89	112	java/lang/Exception
    //   93	97	112	java/lang/Exception
    //   57	67	122	java/lang/Exception
    //   134	139	150	java/lang/Exception
    //   143	147	150	java/lang/Exception
    //   57	67	160	finally
    //   124	129	160	finally
    //   167	172	183	java/lang/Exception
    //   176	180	183	java/lang/Exception
    //   67	79	193	finally
    //   67	79	202	java/lang/Exception
  }

  private void setData(ArrayList<FitnessPicItemModel> paramArrayList)
  {
    String str1 = ((FitnessPicItemModel)paramArrayList.get(0)).moveTime;
    String str2 = ((FitnessPicItemModel)paramArrayList.get(1)).moveTime;
    try
    {
      String str3 = String.valueOf(Calendar.getInstance().get(1));
      SimpleDateFormat localSimpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA);
      Date localDate1 = localSimpleDateFormat1.parse(str1);
      Date localDate2 = localSimpleDateFormat1.parse(str2);
      int i;
      if (localDate1.getTime() > localDate2.getTime())
      {
        i = 1;
        if (localDate1.getTime() <= localDate2.getTime())
          break label504;
      }
      label504: for (int j = 0; ; j = 1)
      {
        RequestOptions localRequestOptions = new RequestOptions().skipMemoryCache(true).placeholder(2130903536).error(2130903536).fitCenter().diskCacheStrategy(DiskCacheStrategy.RESOURCE);
        Glide.with(this).load(((FitnessPicItemModel)this.selectList.get(i)).imageURL).apply(localRequestOptions).thumbnail(0.2F).into(this.compare_left_img);
        Glide.with(this).load(((FitnessPicItemModel)this.selectList.get(j)).imageURL).apply(localRequestOptions).thumbnail(0.2F).into(this.compare_right_img);
        String str4 = DateUtils.StringToFormat(String.valueOf(localSimpleDateFormat1.parse(((FitnessPicItemModel)paramArrayList.get(i)).moveTime).getTime()), "yyyy年M月d日");
        String str5 = DateUtils.StringToFormat(String.valueOf(localSimpleDateFormat1.parse(((FitnessPicItemModel)paramArrayList.get(j)).moveTime).getTime()), "yyyy年M月d日");
        this.left_img_date.setText(str4.replace(str3 + "年", ""));
        this.right_img_date.setText(str5.replace(str3 + "年", ""));
        SimpleDateFormat localSimpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA);
        Date localDate3 = localSimpleDateFormat2.parse(str1.split(" ")[0]);
        Date localDate4 = localSimpleDateFormat2.parse(str2.split(" ")[0]);
        String str6 = String.valueOf(Math.abs((localDate3.getTime() - localDate4.getTime()) / 86400000L));
        this.fitness_days_hint = String.format(getString(2131296830), new Object[] { str6 });
        this.apart_days_view.setText(this.fitness_days_hint);
        this.left_img_weight.setText(((FitnessPicItemModel)this.selectList.get(i)).currentWeight);
        this.right_img_weight.setText(((FitnessPicItemModel)this.selectList.get(j)).currentWeight);
        return;
        i = 0;
        break;
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void convertViewToBitmap(View paramView, PressCallBack paramPressCallBack)
  {
    try
    {
      paramView.setDrawingCacheEnabled(true);
      paramView.buildDrawingCache();
      Bitmap localBitmap = Bitmap.createBitmap(paramView.getDrawingCache());
      paramView.setDrawingCacheEnabled(false);
      LuBanUtils.luBanPressBitmap(localBitmap, new LuBanUtils.PressCallBack(paramPressCallBack)
      {
        public void callBackError(Bitmap paramBitmap)
        {
          if (this.val$pressCallBack != null)
            this.val$pressCallBack.callBack(paramBitmap);
        }

        public void callBackStart()
        {
        }

        public void callBackSuccess(File paramFile, Bitmap paramBitmap)
        {
          if (this.val$pressCallBack != null)
            this.val$pressCallBack.callBack(paramBitmap);
        }
      });
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    case 2131756847:
    default:
    case 2131756846:
    case 2131756848:
    case 2131756849:
    case 2131756850:
    }
    while (true)
    {
      actionToShare(this.fromFlg);
      super.fitOnClick(paramView);
      return;
      this.fromFlg = "";
      convertViewToBitmap(this.show_compare_photo_layout, new PressCallBack()
      {
        public void callBack(Bitmap paramBitmap)
        {
          if (paramBitmap == null)
          {
            ToastUtils.makeToast(MineFitnessComPhotoActivity.this, "图片保存失败");
            return;
          }
          MineFitnessComPhotoActivity.this.dialog.createProgressDialog(MineFitnessComPhotoActivity.this, "请稍后...");
          new Thread(new Runnable(paramBitmap)
          {
            public void run()
            {
              MineFitnessComPhotoActivity.access$002(MineFitnessComPhotoActivity.this, MineFitnessComPhotoActivity.this.saveBitmapToLocal(this.val$pBitmap));
              RequestModel localRequestModel = new RequestModel();
              localRequestModel.moveTime = "";
              localRequestModel.comment = "";
              localRequestModel.imageURL = MineFitnessComPhotoActivity.this.strPath;
              localRequestModel.imageType = "1";
              localRequestModel.photoType = "0";
              localRequestModel.bodyDirection = "";
              localRequestModel.currentWeight = "";
              new PresenterImpl(MineFitnessComPhotoActivity.this, new ApiImpl()).addTrainPhoto(localRequestModel, MineFitnessComPhotoActivity.this);
            }
          }).start();
        }
      });
      continue;
      this.fromFlg = "2";
      continue;
      this.fromFlg = "1";
      continue;
      this.fromFlg = "0";
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    ToastUtils.makeToast(this, getString(2131298238));
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    FeedbackLoadDialog localFeedbackLoadDialog = new FeedbackLoadDialog(this);
    localFeedbackLoadDialog.createDialog(new DoneProgress.DoneProgressInterface(localFeedbackLoadDialog)
    {
      public void DoneProgressFinish()
      {
        this.val$doneDialog.closeDialog();
      }
    });
    localFeedbackLoadDialog.startSuccessAnima(StringUtils.getStringResources(2131299089));
    EventBus.getDefault().post("保存成功");
    super.getDataSuccess(paramT);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969006);
    ButterKnife.bind(this);
    this.dialog = new DialogManager();
    init();
  }

  protected void onDestroy()
  {
    FileUtils.delAllFile(VersionUpdateCheck.ALBUM_FILE_BASE_PATH + "fitness/");
    super.onDestroy();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }

  private static abstract interface PressCallBack
  {
    public abstract void callBack(Bitmap paramBitmap);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.MineFitnessComPhotoActivity
 * JD-Core Version:    0.6.0
 */