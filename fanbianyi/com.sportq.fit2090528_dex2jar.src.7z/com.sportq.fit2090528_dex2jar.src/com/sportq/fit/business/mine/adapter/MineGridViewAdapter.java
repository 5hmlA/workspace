package com.sportq.fit.business.mine.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.FitnessPicItemModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

public class MineGridViewAdapter extends BaseAdapter
{
  private SelectImgListener listener;
  private Context mConetxt;
  private ArrayList<FitnessPicItemModel> monthLstPhoto;
  private ArrayList<FitnessPicItemModel> selectList;
  private String type;

  public MineGridViewAdapter(ArrayList<FitnessPicItemModel> paramArrayList1, Context paramContext, String paramString, SelectImgListener paramSelectImgListener, ArrayList<FitnessPicItemModel> paramArrayList2)
  {
    this.monthLstPhoto = paramArrayList1;
    this.mConetxt = paramContext;
    this.type = paramString;
    this.listener = paramSelectImgListener;
    if (paramArrayList2 == null)
      paramArrayList2 = new ArrayList();
    this.selectList = paramArrayList2;
  }

  public int getCount()
  {
    return this.monthLstPhoto.size();
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    int i;
    if (paramView == null)
    {
      localViewHolder = new ViewHolder(null);
      paramView = LayoutInflater.from(this.mConetxt).inflate(2130969013, null);
      localViewHolder.imageView = ((ImageView)paramView.findViewById(2131756903));
      RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)localViewHolder.imageView.getLayoutParams();
      localLayoutParams.width = ((BaseApplication.screenWidth - CompDeviceInfoUtils.convertOfDip(this.mConetxt, 15.0F)) / 3);
      localLayoutParams.height = ((BaseApplication.screenWidth - CompDeviceInfoUtils.convertOfDip(this.mConetxt, 15.0F)) / 3);
      localViewHolder.select_icon = ((ImageView)paramView.findViewById(2131756905));
      localViewHolder.img_select_layout = ((FrameLayout)paramView.findViewById(2131756904));
      paramView.setTag(localViewHolder);
      GlideUtils.loadImgByDefault(QiniuManager.getImgUrl(((FitnessPicItemModel)this.monthLstPhoto.get(paramInt)).imageURL, 250), 2130903536, localViewHolder.imageView);
      FrameLayout localFrameLayout = localViewHolder.img_select_layout;
      if (!"1".equals(this.type))
        break label249;
      i = 0;
      label182: localFrameLayout.setVisibility(i);
      if (!this.selectList.contains(this.monthLstPhoto.get(paramInt)))
        break label255;
      localViewHolder.select_icon.setImageResource(2130903189);
    }
    while (true)
    {
      localViewHolder.img_select_layout.setOnClickListener(new FitAction(null, paramInt)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (MineGridViewAdapter.this.listener != null)
            MineGridViewAdapter.this.listener.selectImg((FitnessPicItemModel)MineGridViewAdapter.this.monthLstPhoto.get(this.val$position));
        }
      });
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
      break;
      label249: i = 4;
      break label182;
      label255: localViewHolder.select_icon.setImageResource(2130903190);
    }
  }

  public static abstract interface SelectImgListener
  {
    public abstract void selectImg(FitnessPicItemModel paramFitnessPicItemModel);
  }

  private class ViewHolder
  {
    ImageView imageView;
    FrameLayout img_select_layout;
    ImageView select_icon;

    private ViewHolder()
    {
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.adapter.MineGridViewAdapter
 * JD-Core Version:    0.6.0
 */