package com.sportq.fit.business.mine.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.adapter.MineGridViewAdapter.SelectImgListener;
import com.sportq.fit.business.mine.widget.AllPhotoView;
import com.sportq.fit.business.mine.widget.OrdinaryPhotoView;
import com.sportq.fit.business.mine.widget.SizePhotoView;
import com.sportq.fit.business.mine.widget.SizePhotoView.CompareBtnClickListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.model.FitnessPicItemModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.DelFitnessPhotoEvent;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.NoScrollViewPager;
import com.sportq.fit.fitmoudle2.camera.activity.AlbumImageActivity;
import com.sportq.fit.fitmoudle2.camera.activity.NewCameraActivity;
import com.sportq.fit.user_behavior.UserBehaviorImpl;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class MineFitnessPhotoAlbumActivity extends BaseActivity
  implements MineGridViewAdapter.SelectImgListener, SizePhotoView.CompareBtnClickListener
{
  private AllPhotoView allPhotoView;

  @Bind({2131755320})
  CustomTabLayout customTabLayout;
  private OrdinaryPhotoView ordinaryPhotoView;
  private ArrayList<FitnessPicItemModel> selectImgList = new ArrayList();
  private String[] selectList;
  private SizePhotoView sizePhotoView;
  private Menu tMenu;

  @Bind({2131755432})
  CustomToolBar toolbar;

  @Bind({2131755321})
  NoScrollViewPager view_pager;

  private void initElement()
  {
    if (this.toolbar != null)
    {
      this.toolbar.setTitle(getString(2131299012));
      this.toolbar.setNavIcon(2130903080);
      this.toolbar.setToolbarBg(2131624328);
      this.toolbar.setToolbarTitleColor(2131624003);
      setSupportActionBar(this.toolbar);
    }
    String[] arrayOfString1 = new String[2];
    arrayOfString1[0] = getString(2131297509);
    arrayOfString1[1] = getString(2131297510);
    this.selectList = arrayOfString1;
    ArrayList localArrayList = new ArrayList();
    this.allPhotoView = new AllPhotoView(this);
    this.ordinaryPhotoView = new OrdinaryPhotoView(this);
    this.sizePhotoView = new SizePhotoView(this, this, this);
    localArrayList.add(this.allPhotoView);
    localArrayList.add(this.ordinaryPhotoView);
    localArrayList.add(this.sizePhotoView);
    this.view_pager.setAdapter(new CustomViewPagerAdapter(localArrayList));
    this.view_pager.addOnPageChangeListener(new MineViewChangeListener(null));
    String[] arrayOfString2 = new String[3];
    arrayOfString2[0] = getString(2131297426);
    arrayOfString2[1] = getString(2131297427);
    arrayOfString2[2] = getString(2131297428);
    this.customTabLayout.setViewPager(this.view_pager, arrayOfString2);
    this.view_pager.setCurrentItem(0);
    this.allPhotoView.setAllPhotoData();
  }

  private void showDefaultView()
  {
    this.customTabLayout.setVisibility(0);
    this.toolbar.setNavIcon(2130903080);
    if (this.tMenu != null)
      this.tMenu.findItem(2131758215).setVisible(true);
    this.view_pager.setNoScroll(false);
    this.selectImgList.clear();
    this.sizePhotoView.refreshData(new ArrayList(), "0");
  }

  private void showSelectLimitView()
  {
    RelativeLayout localRelativeLayout = (RelativeLayout)findViewById(2131756851);
    if (localRelativeLayout != null)
    {
      Animation localAnimation = AnimationUtils.loadAnimation(this, 2131034159);
      localAnimation.setFillAfter(true);
      localRelativeLayout.setAnimation(localAnimation);
      localRelativeLayout.setVisibility(0);
      new Handler().postDelayed(new Runnable(localRelativeLayout)
      {
        public void run()
        {
          Animation localAnimation = AnimationUtils.loadAnimation(MineFitnessPhotoAlbumActivity.this, 2131034157);
          this.val$select_limit_hint.startAnimation(localAnimation);
          this.val$select_limit_hint.setVisibility(8);
        }
      }
      , 2000L);
    }
  }

  public void compareBtnClick(TextView paramTextView)
  {
    if (StringUtils.getStringResources(2131299043).equals(paramTextView.getText().toString()))
    {
      Intent localIntent = new Intent(this, MineFitnessComPhotoActivity.class);
      localIntent.putExtra("select.list", this.selectImgList);
      startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this, 0);
      return;
    }
    this.customTabLayout.setVisibility(8);
    this.toolbar.setNavIcon(2130903098);
    if (this.tMenu != null)
      this.tMenu.findItem(2131758215).setVisible(false);
    this.view_pager.setNoScroll(true);
    this.sizePhotoView.refreshData(new ArrayList(), "1");
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130968855);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    initElement();
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    this.tMenu = paramMenu;
    getMenuInflater().inflate(2131820561, paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    com.sportq.fit.fitmoudle2.camera.activity.FitnessPicPubRelease.strPubType = null;
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(DelFitnessPhotoEvent paramDelFitnessPhotoEvent)
  {
    this.allPhotoView.refreshData();
    if ("1".equals(paramDelFitnessPhotoEvent.photoType))
    {
      this.sizePhotoView.delRefreshData();
      return;
    }
    this.ordinaryPhotoView.refreshData();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("保存成功".equals(paramString))
    {
      showDefaultView();
      this.view_pager.setCurrentItem(1);
      new Handler().postDelayed(new Runnable()
      {
        public void run()
        {
          MineFitnessPhotoAlbumActivity.this.allPhotoView.refreshData();
          MineFitnessPhotoAlbumActivity.this.ordinaryPhotoView.refreshData();
        }
      }
      , 500L);
    }
    if ("fitness.pic.finish".equals(paramString))
      new Handler().postDelayed(new Runnable()
      {
        public void run()
        {
          MineFitnessPhotoAlbumActivity.this.allPhotoView.refreshData();
          MineFitnessPhotoAlbumActivity.this.sizePhotoView.delRefreshData();
          MineFitnessPhotoAlbumActivity.this.ordinaryPhotoView.refreshData();
        }
      }
      , 500L);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      if (this.customTabLayout.getVisibility() == 8)
      {
        showDefaultView();
        return false;
      }
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    case 2131758215:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      if (this.customTabLayout.getVisibility() == 8)
      {
        showDefaultView();
        continue;
      }
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
      {
        public void result(boolean paramBoolean)
        {
          if (paramBoolean)
            MineFitnessPhotoAlbumActivity.this.dialog.createDialog(new FitInterfaceUtils.DialogListener()
            {
              public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
              {
                switch (paramInt)
                {
                default:
                  return;
                case 0:
                  new UserBehaviorImpl().fitnessAlbumCameraBtnClick();
                  com.sportq.fit.fitmoudle2.camera.activity.FitnessPicPubRelease.strPubType = "1";
                  Intent localIntent2 = new Intent(MineFitnessPhotoAlbumActivity.this, NewCameraActivity.class);
                  MineFitnessPhotoAlbumActivity.this.startActivity(localIntent2);
                  AnimationUtil.pageJumpAnim(MineFitnessPhotoAlbumActivity.this, 0);
                  return;
                case 1:
                }
                Intent localIntent1 = new Intent(MineFitnessPhotoAlbumActivity.this, AlbumImageActivity.class);
                com.sportq.fit.fitmoudle2.camera.activity.FitnessPicPubRelease.bodyDirection = "-1";
                com.sportq.fit.fitmoudle2.camera.activity.FitnessPicPubRelease.strPubType = "1";
                MineFitnessPhotoAlbumActivity.this.startActivity(localIntent1);
                AnimationUtil.pageJumpAnim(MineFitnessPhotoAlbumActivity.this, 0);
              }
            }
            , MineFitnessPhotoAlbumActivity.this, MineFitnessPhotoAlbumActivity.this.selectList);
        }
      }
      , this, new String[] { "android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE" });
    }
  }

  protected void onResume()
  {
    super.onResume();
  }

  public void selectImg(FitnessPicItemModel paramFitnessPicItemModel)
  {
    if (paramFitnessPicItemModel == null)
      return;
    if ((this.selectImgList.size() == 2) && (!this.selectImgList.contains(paramFitnessPicItemModel)))
    {
      showSelectLimitView();
      return;
    }
    if (this.selectImgList.contains(paramFitnessPicItemModel))
      this.selectImgList.remove(paramFitnessPicItemModel);
    while (true)
    {
      this.sizePhotoView.refreshData(this.selectImgList, "1");
      return;
      this.selectImgList.add(paramFitnessPicItemModel);
    }
  }

  private class MineViewChangeListener
    implements ViewPager.OnPageChangeListener
  {
    private MineViewChangeListener()
    {
    }

    public void onPageScrollStateChanged(int paramInt)
    {
    }

    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
    {
    }

    public void onPageSelected(int paramInt)
    {
      switch (paramInt)
      {
      default:
        return;
      case 0:
        new Handler().postDelayed(new Runnable()
        {
          public void run()
          {
            MineFitnessPhotoAlbumActivity.this.allPhotoView.setAllPhotoData();
          }
        }
        , 100L);
        return;
      case 1:
        new Handler().postDelayed(new Runnable()
        {
          public void run()
          {
            MineFitnessPhotoAlbumActivity.this.ordinaryPhotoView.setOrdinaryPhotoData();
          }
        }
        , 100L);
        return;
      case 2:
      }
      new Handler().postDelayed(new Runnable()
      {
        public void run()
        {
          MineFitnessPhotoAlbumActivity.this.sizePhotoView.setSizePhotoData();
        }
      }
      , 100L);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.MineFitnessPhotoAlbumActivity
 * JD-Core Version:    0.6.0
 */