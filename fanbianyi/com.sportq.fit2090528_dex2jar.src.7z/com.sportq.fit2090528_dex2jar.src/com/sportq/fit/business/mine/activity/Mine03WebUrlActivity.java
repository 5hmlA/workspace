package com.sportq.fit.business.mine.activity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.view.MenuItemCompat;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.business.find.activity.FitCourseJumpMidActivity;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.event.CustomJumpEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.ShareDoListener;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.logic.JDPayHandler;
import com.sportq.fit.common.logic.payutil.AlipayHandler;
import com.sportq.fit.common.logic.payutil.HuaweiPayHandler;
import com.sportq.fit.common.logic.payutil.OnPayListener;
import com.sportq.fit.common.logic.payutil.WechatPayHandler;
import com.sportq.fit.common.logic.payutil.WechatPayHandler.OnGetOrderIdListener;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.CustomerServiceUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.ImageUtils.OnSaveImgListener;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.SystemPhotoUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.imageloader.BitmapCache;
import com.sportq.fit.common.utils.imageloader.QueueCallback;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.activity.VipCenterActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.UpgradeProgressDialog;
import com.sportq.fit.fitmoudle.event.GotoShopTabEvent;
import com.sportq.fit.fitmoudle.event.ReceiveMedalEvent;
import com.sportq.fit.fitmoudle.sharemanager.ShareListenerFunction;
import com.sportq.fit.fitmoudle.sharemanager.ShareManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.PlayPointModel;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.ShareQRCodeModel;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle.sharemanager.sharetools.SharePriTools;
import com.sportq.fit.fitmoudle.task.activity.Task02ChallengeDetailsActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseVideoDetailsActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MallGoodsInfoActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MineCouponActivity;
import com.sportq.fit.fitmoudle13.shop.activity.ShopRecommendListActivity;
import com.sportq.fit.fitmoudle13.shop.model.EntclassInfoData;
import com.sportq.fit.fitmoudle5.activity.MasterClassDetailsActivity;
import com.sportq.fit.fitmoudle5.activity.MasterClassListActivity;
import com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity;
import com.sportq.fit.fitmoudle7.customize.activity.CustomStartActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.fitmoudle8.activity.action_library.ActionClassifyActivity;
import com.sportq.fit.fitmoudle8.activity.action_library.ActionUnLockActivity;
import com.sportq.fit.fitmoudle9.energy.activity.EnergyActionActivity;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.persenter.model.WebJumpModel;
import com.sportq.fit.supportlib.http.cache.FitCacheStoreUtils;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.json.JSONArray;
import org.json.JSONObject;

@SuppressLint({"SetJavaScriptEnabled"})
public class Mine03WebUrlActivity extends BaseActivity
  implements OnPayListener, WechatPayHandler.OnGetOrderIdListener
{
  private static final int FILECHOOSER_RESULTCODE = 2;
  public static final int REQUEST_SELECT_FILE = 100;
  private AlipayHandler alipayHandler;
  private String cTitle;
  private String callType;
  private String callback;
  private String comefrom;
  private String comment;
  private String commodityId;
  private String commodityTitle;
  private String commodityType;
  private String dealEnergyValue = "0";
  private String describe;

  @SuppressLint({"HandlerLeak"})
  private Handler handler = new Handler()
  {
    public void handleMessage(Message paramMessage)
    {
      super.handleMessage(paramMessage);
      switch (paramMessage.arg1)
      {
      default:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
        while (true)
        {
          return;
          while (true)
          {
            try
            {
              if ((paramMessage.obj == null) || (StringUtils.isNull(String.valueOf(paramMessage.obj))))
                continue;
              JSONObject localJSONObject12 = new JSONObject(String.valueOf(paramMessage.obj));
              Mine03WebUrlActivity.access$002(Mine03WebUrlActivity.this, localJSONObject12.optString("desc"));
              Mine03WebUrlActivity.access$102(Mine03WebUrlActivity.this, localJSONObject12.optString("title"));
              Mine03WebUrlActivity.access$202(Mine03WebUrlActivity.this, localJSONObject12.optString("ctitle"));
              Mine03WebUrlActivity.access$302(Mine03WebUrlActivity.this, localJSONObject12.optString("imgUrl"));
              Mine03WebUrlActivity.access$402(Mine03WebUrlActivity.this, localJSONObject12.optString("link"));
              Mine03WebUrlActivity.access$502(Mine03WebUrlActivity.this, localJSONObject12.optString("weiboTitle"));
              Mine03WebUrlActivity.access$602(Mine03WebUrlActivity.this, localJSONObject12.optString("weiboImg"));
              Mine03WebUrlActivity.access$702(Mine03WebUrlActivity.this, localJSONObject12.optString("imgActUrl"));
              Mine03WebUrlActivity.access$802(Mine03WebUrlActivity.this, localJSONObject12.optString("olapflg"));
              MenuItem localMenuItem = Mine03WebUrlActivity.this.tMenu.findItem(2131758207);
              if ((paramMessage.obj != null) && (!StringUtils.isNull(String.valueOf(paramMessage.obj))))
              {
                bool2 = true;
                localMenuItem.setVisible(bool2);
                return;
              }
            }
            catch (Exception localException13)
            {
              LogUtils.e(localException13);
              return;
            }
            boolean bool2 = false;
          }
          try
          {
            if (paramMessage.obj == null)
              continue;
            JSONObject localJSONObject10 = new JSONObject(String.valueOf(paramMessage.obj));
            Mine03WebUrlActivity.access$002(Mine03WebUrlActivity.this, localJSONObject10.optString("desc"));
            Mine03WebUrlActivity.access$102(Mine03WebUrlActivity.this, localJSONObject10.optString("title"));
            Mine03WebUrlActivity.access$202(Mine03WebUrlActivity.this, localJSONObject10.optString("ctitle"));
            Mine03WebUrlActivity.access$302(Mine03WebUrlActivity.this, localJSONObject10.optString("imgUrl"));
            Mine03WebUrlActivity.access$402(Mine03WebUrlActivity.this, localJSONObject10.optString("link"));
            Mine03WebUrlActivity.access$1002(Mine03WebUrlActivity.this, localJSONObject10.optString("type"));
            Mine03WebUrlActivity.access$1102(Mine03WebUrlActivity.this, localJSONObject10.optString("isphoto"));
            Mine03WebUrlActivity.access$502(Mine03WebUrlActivity.this, localJSONObject10.optString("weiboTitle"));
            Mine03WebUrlActivity.access$602(Mine03WebUrlActivity.this, localJSONObject10.optString("weiboImg"));
            Mine03WebUrlActivity.access$702(Mine03WebUrlActivity.this, localJSONObject10.optString("imgActUrl"));
            Mine03WebUrlActivity.access$802(Mine03WebUrlActivity.this, localJSONObject10.optString("olapflg"));
            if (!localJSONObject10.has("content"))
              break label640;
            JSONObject localJSONObject11 = localJSONObject10.optJSONObject("content");
            Mine03WebUrlActivity.access$1202(Mine03WebUrlActivity.this, (ShareQRCodeModel)new Gson().fromJson(localJSONObject11.toString(), ShareQRCodeModel.class));
            Mine03WebUrlActivity.this.shareQRCodeModel.localImgUrl = Mine03WebUrlActivity.this.qrImgUrl;
            if ("5".equals(Mine03WebUrlActivity.this.type))
            {
              CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
              {
                public void result(boolean paramBoolean)
                {
                  if (paramBoolean)
                  {
                    Mine03WebUrlActivity.this.dialog.createProgressDialog(Mine03WebUrlActivity.this, "请稍后...");
                    new SharePriTools().createInviteQRCode2(Mine03WebUrlActivity.this, Mine03WebUrlActivity.this.shareQRCodeModel, new FitInterfaceUtils.ShareDoListener()
                    {
                      public void readyiFinish(String paramString)
                      {
                        Mine03WebUrlActivity.this.runOnUiThread(new Runnable(paramString)
                        {
                          public void run()
                          {
                            Mine03WebUrlActivity.access$1302(Mine03WebUrlActivity.this, this.val$imgUrl);
                            Mine03WebUrlActivity.this.dialog.closeDialog();
                            ToastUtils.makeToast(Mine03WebUrlActivity.this, "保存成功");
                          }
                        });
                      }
                    });
                  }
                }
              }
              , Mine03WebUrlActivity.this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
              return;
            }
          }
          catch (Exception localException12)
          {
            LogUtils.e(localException12);
            return;
          }
          Mine03WebUrlActivity.this.actionToShare();
          return;
          Mine03WebUrlActivity.this.actionToShare();
          return;
          try
          {
            Mine03WebUrlActivity localMine03WebUrlActivity2 = Mine03WebUrlActivity.this;
            String[] arrayOfString = new String[2];
            arrayOfString[0] = Mine03WebUrlActivity.this.getString(2131296805);
            arrayOfString[1] = Mine03WebUrlActivity.this.getString(2131298126);
            Mine03WebUrlActivity.access$1502(localMine03WebUrlActivity2, arrayOfString);
            if ((paramMessage.obj == null) || (StringUtils.isNull(String.valueOf(paramMessage.obj))))
              continue;
            String str7 = String.valueOf(paramMessage.obj);
            Mine03WebUrlActivity.this.dialog.createDialog(new FitInterfaceUtils.DialogListener(str7)
            {
              public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
              {
                if (paramInt == 0)
                  new BitmapCache().getSingletonImage(this.val$imgUrl, 1, new QueueCallback()
                  {
                    public void onErrorResponse()
                    {
                    }

                    public void onResponse(Object paramObject)
                    {
                      Bitmap localBitmap = (Bitmap)paramObject;
                      if (localBitmap != null)
                      {
                        ImageUtils.saveImgToAlbum(new ImageUtils.OnSaveImgListener()
                        {
                          public void saveSuccess(String paramString)
                          {
                            if (!StringUtils.isNull(paramString))
                            {
                              ToastUtils.makeToast(Mine03WebUrlActivity.this, StringUtils.getStringResources(2131298926));
                              return;
                            }
                            ToastUtils.makeToast(Mine03WebUrlActivity.this, StringUtils.getStringResources(2131298925));
                          }
                        }
                        , localBitmap, Mine03WebUrlActivity.this);
                        return;
                      }
                      ToastUtils.makeToast(Mine03WebUrlActivity.this, StringUtils.getStringResources(2131298925));
                    }
                  });
              }
            }
            , Mine03WebUrlActivity.this, Mine03WebUrlActivity.this.itemList);
            return;
          }
          catch (Exception localException11)
          {
            LogUtils.e(localException11);
            return;
          }
          try
          {
            if (paramMessage.obj == null)
              continue;
            JSONObject localJSONObject9 = new JSONObject(String.valueOf(paramMessage.obj));
            String str5 = localJSONObject9.optString("page");
            String str6 = localJSONObject9.optString("id");
            Mine03WebUrlActivity.this.jumpAppointPage(str5, str6);
            if (!"7".equals(str5))
              continue;
            Mine03WebUrlActivity.this.finish();
            return;
          }
          catch (Exception localException10)
          {
            LogUtils.e(localException10);
            return;
          }
          try
          {
            if ((paramMessage.obj == null) || (!"查看我的能量".equals(String.valueOf(paramMessage.obj))))
              continue;
            Intent localIntent = new Intent(Mine03WebUrlActivity.this, EnergyActionActivity.class);
            Mine03WebUrlActivity.this.startActivity(localIntent);
            AnimationUtil.pageJumpAnim(Mine03WebUrlActivity.this, 0);
            return;
          }
          catch (Exception localException9)
          {
            LogUtils.e(localException9);
            return;
          }
          try
          {
            if (paramMessage.obj == null)
              continue;
            JSONObject localJSONObject8 = new JSONObject(String.valueOf(paramMessage.obj));
            Mine03WebUrlActivity.access$1702(Mine03WebUrlActivity.this, localJSONObject8.optString("commodityId"));
            Mine03WebUrlActivity.access$1802(Mine03WebUrlActivity.this, localJSONObject8.optString("commodityTitle"));
            Mine03WebUrlActivity.access$1902(Mine03WebUrlActivity.this, localJSONObject8.optString("comment"));
            Mine03WebUrlActivity.access$2002(Mine03WebUrlActivity.this, localJSONObject8.optString("price"));
            Mine03WebUrlActivity.access$2102(Mine03WebUrlActivity.this, localJSONObject8.optString("type"));
            Mine03WebUrlActivity.access$2202(Mine03WebUrlActivity.this, localJSONObject8.optString("energyVal"));
            Mine03WebUrlActivity.access$2302(Mine03WebUrlActivity.this, localJSONObject8.optString("url"));
            Mine03WebUrlActivity.access$2402(Mine03WebUrlActivity.this, localJSONObject8.optString("productType"));
            Mine03WebUrlActivity.access$2502(Mine03WebUrlActivity.this, localJSONObject8.optString("source"));
            Mine03WebUrlActivity.access$2602(Mine03WebUrlActivity.this, localJSONObject8.optString("commodityType"));
            Mine03WebUrlActivity.access$2702(Mine03WebUrlActivity.this, localJSONObject8.optString("callback"));
            Mine03WebUrlActivity.this.initPay();
            return;
          }
          catch (Exception localException8)
          {
            LogUtils.e(localException8);
            return;
          }
          if (paramMessage.obj == null)
            continue;
          if ("0".equals(String.valueOf(paramMessage.obj)))
          {
            SharePreferenceUtils.putNeedFillInfo(Mine03WebUrlActivity.this, "0");
            if (Mine03WebUrlActivity.this.mine03FitAbout.canGoBack())
              Mine03WebUrlActivity.this.mine03FitAbout.goBack();
          }
          while (true)
          {
            EventBus.getDefault().post("write.user.address");
            return;
            Mine03WebUrlActivity.this.finish();
            AnimationUtil.pageJumpAnim(Mine03WebUrlActivity.this, 1);
            continue;
            if (!"1".equals(String.valueOf(paramMessage.obj)))
              continue;
            SharePreferenceUtils.putNeedFillInfo(Mine03WebUrlActivity.this, "1");
            Mine03WebUrlActivity.this.finish();
            AnimationUtil.pageJumpAnim(Mine03WebUrlActivity.this, 1);
          }
          if ((paramMessage.obj == null) || (!"跳转下载".equals(paramMessage.obj.toString())))
            continue;
          CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
          {
            public void result(boolean paramBoolean)
            {
              if (paramBoolean)
                new UpgradeProgressDialog().downloadApk(Mine03WebUrlActivity.this, "");
            }
          }
          , Mine03WebUrlActivity.this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
          return;
          if (paramMessage.obj == null)
            continue;
          TextUtils.copyToClipboard(String.valueOf(paramMessage.obj));
          ToastUtils.makeToast(Mine03WebUrlActivity.this, Mine03WebUrlActivity.this.getString(2131298235));
          return;
          new SystemPhotoUtils(Mine03WebUrlActivity.this).openSystemPhoto();
          return;
          while (true)
          {
            JSONObject localJSONObject7;
            WebJumpModel localWebJumpModel;
            try
            {
              localJSONObject7 = new JSONObject(String.valueOf(paramMessage.obj));
              String str4 = "0";
              if (!localJSONObject7.has("jsonType"))
                continue;
              str4 = localJSONObject7.optString("jsonType");
              localWebJumpModel = new WebJumpModel();
              localWebJumpModel.jsonType = str4;
              if ("0".equals(str4))
              {
                localWebJumpModel.jumpJson = String.valueOf(paramMessage.obj);
                AppSharePreferenceUtils.putCustomH5JumpJson(new Gson().toJson(localWebJumpModel));
                EventBus.getDefault().post(new CustomJumpEvent(Mine03WebUrlActivity.this));
                return;
              }
            }
            catch (Exception localException7)
            {
              LogUtils.e(localException7);
              return;
            }
            localWebJumpModel.jumpJson = localJSONObject7.optString("jumpJson");
          }
          while (true)
          {
            try
            {
              JSONObject localJSONObject6 = new JSONObject(String.valueOf(paramMessage.obj));
              if (!StringUtils.isNull(localJSONObject6.optString("service")))
              {
                Mine03WebUrlActivity.this.tMenu.findItem(2131758208).setVisible("1".equals(localJSONObject6.optString("service")));
                String str3 = localJSONObject6.optString("load");
                Mine03WebUrlActivity localMine03WebUrlActivity1 = Mine03WebUrlActivity.this;
                if ((StringUtils.isNull(str3)) || (!"1".equals(str3)))
                  break label1631;
                bool1 = true;
                Mine03WebUrlActivity.access$2902(localMine03WebUrlActivity1, bool1);
                return;
              }
            }
            catch (Exception localException6)
            {
              LogUtils.e(localException6);
              return;
            }
            Mine03WebUrlActivity.this.tMenu.findItem(2131758208).setVisible(false);
            continue;
            boolean bool1 = false;
          }
          Mine03WebUrlActivity.this.finish();
          AnimationUtil.pageJumpAnim(Mine03WebUrlActivity.this, 1);
          return;
          try
          {
            JSONObject localJSONObject5 = new JSONObject(String.valueOf(paramMessage.obj));
            int i = StringUtils.string2Int(localJSONObject5.optString("index"));
            JSONArray localJSONArray = localJSONObject5.optJSONArray("imgList");
            ArrayList localArrayList = new ArrayList();
            for (int j = 0; j < localJSONArray.length(); j++)
              localArrayList.add(localJSONArray.getString(j));
            if (localArrayList.size() == 0)
              continue;
            Mine03WebUrlActivity.this.dialog.showWebImg(Mine03WebUrlActivity.this, Mine03WebUrlActivity.this.getWindow().getDecorView().getWidth(), Mine03WebUrlActivity.this.getWindow().getDecorView().getHeight(), localArrayList, i);
            return;
          }
          catch (Exception localException5)
          {
            LogUtils.e(localException5);
            return;
          }
          try
          {
            JSONObject localJSONObject4 = new JSONObject(String.valueOf(paramMessage.obj));
            CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener(localJSONObject4.optString("url"), localJSONObject4.optString("isOpenWeixin"))
            {
              public void result(boolean paramBoolean)
              {
                if (paramBoolean)
                {
                  Mine03WebUrlActivity.this.dialog.createProgressDialog(Mine03WebUrlActivity.this, "正在保存...");
                  GlideUtils.loadUrlToBitmap(Mine03WebUrlActivity.this, this.val$imgUrl, new QueueCallback()
                  {
                    public void onErrorResponse()
                    {
                    }

                    public void onResponse(Object paramObject)
                    {
                      if (paramObject == null)
                      {
                        ToastUtils.makeToast(Mine03WebUrlActivity.this, "保存失败");
                        return;
                      }
                      String str1 = DateUtils.getCurDateTime() + ".jpg";
                      String str2 = Environment.getExternalStorageDirectory() + "/DCIM/fit/";
                      File localFile = ImageUtils.bitmapToImg((Bitmap)paramObject, str2, str1, "1");
                      try
                      {
                        Mine03WebUrlActivity.this.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", FileUtils.getTakePhotoUri(localFile.getAbsolutePath())));
                        if ("1".equals(Mine03WebUrlActivity.1.4.this.val$isOpenWeixin))
                          CompDeviceInfoUtils.openWeixinToQE_Code(Mine03WebUrlActivity.this);
                        Mine03WebUrlActivity.this.dialog.closeDialog();
                        return;
                      }
                      catch (Exception localException)
                      {
                        while (true)
                          localException.printStackTrace();
                      }
                    }
                  });
                }
              }
            }
            , Mine03WebUrlActivity.this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
            return;
          }
          catch (Exception localException4)
          {
            LogUtils.e(localException4);
            return;
          }
          try
          {
            JSONObject localJSONObject3 = new JSONObject(String.valueOf(paramMessage.obj));
            String str1 = localJSONObject3.optString("text");
            String str2 = localJSONObject3.optString("needOpenWexin");
            ClipboardManager localClipboardManager = (ClipboardManager)Mine03WebUrlActivity.this.getSystemService("clipboard");
            if (localClipboardManager == null)
              break;
            localClipboardManager.setPrimaryClip(ClipData.newPlainText("Label", str1));
            ToastUtils.makeToast(Mine03WebUrlActivity.this, "复制成功");
            if (!"1".equals(str2))
              continue;
            CompDeviceInfoUtils.openWeixin(Mine03WebUrlActivity.this);
            return;
          }
          catch (Exception localException3)
          {
            LogUtils.e(localException3);
            return;
          }
        }
        ToastUtils.makeToast(Mine03WebUrlActivity.this, "复制失败");
        return;
      case 17:
        try
        {
          label640: label1631: JSONObject localJSONObject2 = new JSONObject(String.valueOf(paramMessage.obj));
          Mine03WebUrlActivity.this.tMenu.findItem(2131758209).setVisible("1".equals(localJSONObject2.optString("skip")));
          return;
        }
        catch (Exception localException2)
        {
          LogUtils.e(localException2);
          return;
        }
      case 18:
      }
      try
      {
        JSONObject localJSONObject1 = new JSONObject(String.valueOf(paramMessage.obj));
        CompDeviceInfoUtils.openQQ(Mine03WebUrlActivity.this, StringUtils.string2Int(localJSONObject1.optString("page")), localJSONObject1.getString("text"));
        return;
      }
      catch (Exception localException1)
      {
        LogUtils.e(localException1);
      }
    }
  };
  private HuaweiPayHandler huaweiPayHandler;
  private String imgActUrl;
  private String imgUrl;
  private boolean isNeedRefresh = false;
  private String isPhoto;
  private String[] itemList;
  private JDPayHandler jdPayHandler;
  private String link;
  private ValueCallback<Uri> mUploadMessage;

  @Bind({2131756407})
  WebView mine03FitAbout;

  @Bind({2131756406})
  ProgressBar myProgressBar;
  private String nUrl;
  private String olapflg;
  private String paySource;
  private String payType;
  private String price;
  private String qrImgUrl;
  private String shareFlg;
  private ShareQRCodeModel shareQRCodeModel;
  private String strJdId;
  private String strOrderId;
  private Menu tMenu;
  private String title;

  @Bind({2131755432})
  CustomToolBar toolbar;
  private String type;
  public ValueCallback<Uri[]> uploadMessage;
  private String wTitle;
  private String webUrl = "http://www.dev.fitapp.cn/about_us.html";

  @Bind({2131756405})
  LinearLayout webView_layout;
  private WechatPayHandler wechatPayHandler;
  private String weiboImg;

  private void actionToShare()
  {
    UseShareModel localUseShareModel = new UseShareModel();
    localUseShareModel.title = this.title;
    localUseShareModel.describe = this.describe;
    localUseShareModel.link = this.link;
    localUseShareModel.cTitle = this.cTitle;
    localUseShareModel.imgUrl = this.imgUrl;
    localUseShareModel.isPhoto = this.isPhoto;
    localUseShareModel.wTitle = this.wTitle;
    localUseShareModel.weiboImg = this.weiboImg;
    localUseShareModel.imgActUrl = this.imgActUrl;
    localUseShareModel.olapflg = this.olapflg;
    localUseShareModel.shareQRCodeModel = this.shareQRCodeModel;
    if (StringUtils.isNull(this.type))
      return;
    String str1 = "0";
    if ("0".equals(this.type))
    {
      this.type = "1";
      str1 = "2";
      this.shareFlg = this.olapflg;
      if (("29".equals(this.shareFlg)) || ("32".equals(this.shareFlg)))
        if (!"2".equals(this.isPhoto))
          break label382;
    }
    label382: for (String str2 = "0"; ; str2 = "1")
    {
      localUseShareModel.olapInfo = str2;
      if ("5".equals(this.type))
        break label388;
      PlayPointModel localPlayPointModel = ShareListenerFunction.pointPut(Integer.valueOf(this.shareFlg).intValue(), str1, localUseShareModel);
      ShareManager localShareManager = new ShareManager(this, this.dialog);
      localShareManager.setPlayPointModel(localPlayPointModel);
      localShareManager.shareFitData(localUseShareModel, Integer.valueOf(this.shareFlg).intValue(), Integer.valueOf(this.type).intValue());
      return;
      if ("1".equals(this.type))
      {
        this.type = "0";
        str1 = "1";
        break;
      }
      if ("2".equals(this.type))
      {
        str1 = "0";
        break;
      }
      if ("4".equals(this.type))
      {
        this.type = "3";
        str1 = "3";
        break;
      }
      if ("3".equals(this.type))
      {
        this.type = "5";
        break;
      }
      if (!"6".equals(this.type))
        break;
      str1 = "7";
      this.type = "4";
      break;
    }
    label388: this.dialog.showShareChoiseDialog(this, Integer.valueOf(this.shareFlg).intValue(), localUseShareModel, this.dialog);
  }

  private void hideKeyboard()
  {
    try
    {
      View localView = getWindow().peekDecorView();
      if (localView != null)
      {
        InputMethodManager localInputMethodManager = (InputMethodManager)getSystemService("input_method");
        if (localInputMethodManager != null)
          localInputMethodManager.hideSoftInputFromWindow(localView.getWindowToken(), 0);
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void initControl()
  {
    String str = this.mine03FitAbout.getSettings().getUserAgentString();
    this.mine03FitAbout.getSettings().setUserAgentString(str + "useragent:Fit_" + CompDeviceInfoUtils.getVersionCode() + " " + "FitUID/" + BaseApplication.userModel.userId + " " + "FitSex/" + BaseApplication.userModel.coachSexf + " " + "FitChannel/" + CompDeviceInfoUtils.getFitSource());
    this.mine03FitAbout.getSettings().setCacheMode(2);
    this.mine03FitAbout.getSettings().setDomStorageEnabled(true);
    this.mine03FitAbout.addJavascriptInterface(new MyJavaScriptInterface(null), "Fitapp");
    this.mine03FitAbout.getSettings().setJavaScriptEnabled(true);
    this.mine03FitAbout.setWebViewClient(new WebViewClient()
    {
      @SuppressLint({"NewApi"})
      public void onPageFinished(WebView paramWebView, String paramString)
      {
        super.onPageFinished(paramWebView, paramString);
        CustomToolBar localCustomToolBar;
        if ((StringUtils.isNull(Mine03WebUrlActivity.this.comefrom)) && (!Mine03WebUrlActivity.this.webUrl.contains("energyInfo")))
        {
          localCustomToolBar = Mine03WebUrlActivity.this.toolbar;
          if (!StringUtils.isNull(paramWebView.getTitle()))
            break label133;
        }
        label133: for (String str = ""; ; str = paramWebView.getTitle())
        {
          localCustomToolBar.setTitle(str);
          if (Build.VERSION.SDK_INT < 19)
            break;
          Mine03WebUrlActivity.this.mine03FitAbout.evaluateJavascript("javascript:getShareInfo(0)", new ValueCallback()
          {
            public void onReceiveValue(String paramString)
            {
              Message localMessage = new Message();
              localMessage.arg1 = 1;
              localMessage.obj = paramString;
              Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
            }
          });
          Mine03WebUrlActivity.this.mine03FitAbout.evaluateJavascript("javascript:androidShowFn(0)", new ValueCallback()
          {
            public void onReceiveValue(String paramString)
            {
              if (StringUtils.isNull(paramString))
                return;
              Message localMessage = new Message();
              localMessage.arg1 = 12;
              localMessage.obj = paramString;
              Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
            }
          });
          Mine03WebUrlActivity.this.mine03FitAbout.evaluateJavascript("javascript:androidShow(0)", new ValueCallback()
          {
            public void onReceiveValue(String paramString)
            {
              if (StringUtils.isNull(paramString))
                return;
              Message localMessage = new Message();
              localMessage.arg1 = 17;
              localMessage.obj = paramString;
              Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
            }
          });
          return;
        }
        WebView localWebView1 = Mine03WebUrlActivity.this.mine03FitAbout;
        localWebView1.loadUrl("javascript:getShareInfo(1)");
        VdsAgent.loadUrl((View)localWebView1, "javascript:getShareInfo(1)");
        WebView localWebView2 = Mine03WebUrlActivity.this.mine03FitAbout;
        localWebView2.loadUrl("javascript:androidShowFn(1)");
        VdsAgent.loadUrl((View)localWebView2, "javascript:androidShowFn(1)");
        WebView localWebView3 = Mine03WebUrlActivity.this.mine03FitAbout;
        localWebView3.loadUrl("javascript:androidShow(1)");
        VdsAgent.loadUrl((View)localWebView3, "javascript:androidShow(1)");
      }

      public boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString)
      {
        if ("mailto:love@sportq.com".equals(paramString))
        {
          Intent localIntent1 = new Intent();
          localIntent1.setAction("android.intent.action.SENDTO");
          localIntent1.setData(Uri.parse("mailto:love@sportq.com"));
          Mine03WebUrlActivity.this.startActivity(localIntent1);
        }
        do
          return true;
        while ((StringUtils.isNull(paramString)) || ((!paramString.contains("http")) && (!paramString.contains("tel:"))));
        if ((paramString.contains("fitapp")) || (paramString.contains("duiba")))
          return false;
        Intent localIntent2 = new Intent("android.intent.action.VIEW", Uri.parse(paramString));
        Mine03WebUrlActivity.this.startActivity(localIntent2);
        return true;
      }
    });
    WebView localWebView = this.mine03FitAbout;
    3 local3 = new WebChromeClient()
    {
      public void onProgressChanged(WebView paramWebView, int paramInt)
      {
        VdsAgent.onProgressChangedStart(paramWebView, paramInt);
        int i;
        if (paramInt == 100)
        {
          i = Mine03WebUrlActivity.this.myProgressBar.getProgress();
          if (i >= 100)
          {
            Mine03WebUrlActivity.this.myProgressBar.setProgress(100);
            Mine03WebUrlActivity.this.myProgressBar.setVisibility(8);
          }
        }
        while (true)
        {
          super.onProgressChanged(paramWebView, paramInt);
          VdsAgent.onProgressChangedEnd(paramWebView, paramInt);
          return;
          Mine03WebUrlActivity.this.setProMaxAction(i);
          continue;
          if (8 == Mine03WebUrlActivity.this.myProgressBar.getVisibility())
            Mine03WebUrlActivity.this.myProgressBar.setVisibility(0);
          Mine03WebUrlActivity.this.myProgressBar.setProgress(paramInt);
        }
      }

      public void onReceivedTitle(WebView paramWebView, String paramString)
      {
        super.onReceivedTitle(paramWebView, paramString);
      }

      public boolean onShowFileChooser(WebView paramWebView, ValueCallback<Uri[]> paramValueCallback, WebChromeClient.FileChooserParams paramFileChooserParams)
      {
        if (Mine03WebUrlActivity.this.uploadMessage != null)
        {
          Mine03WebUrlActivity.this.uploadMessage.onReceiveValue(null);
          Mine03WebUrlActivity.this.uploadMessage = null;
        }
        Mine03WebUrlActivity.this.uploadMessage = paramValueCallback;
        int i = Build.VERSION.SDK_INT;
        Intent localIntent = null;
        if (i >= 21)
          localIntent = paramFileChooserParams.createIntent();
        try
        {
          Mine03WebUrlActivity.this.startActivityForResult(localIntent, 100);
          return true;
        }
        catch (ActivityNotFoundException localActivityNotFoundException)
        {
          Mine03WebUrlActivity.this.uploadMessage = null;
          Toast localToast = Toast.makeText(Mine03WebUrlActivity.this.getBaseContext(), "Cannot Open File Chooser", 1);
          localToast.show();
          VdsAgent.showToast((Toast)localToast);
        }
        return false;
      }

      public void openFileChooser(ValueCallback<Uri> paramValueCallback)
      {
        Mine03WebUrlActivity.access$3502(Mine03WebUrlActivity.this, paramValueCallback);
        Intent localIntent = new Intent("android.intent.action.GET_CONTENT");
        localIntent.addCategory("android.intent.category.OPENABLE");
        localIntent.setType("image/*");
        Mine03WebUrlActivity.this.startActivityForResult(Intent.createChooser(localIntent, "File Chooser"), 2);
      }

      public void openFileChooser(ValueCallback paramValueCallback, String paramString)
      {
        Mine03WebUrlActivity.access$3502(Mine03WebUrlActivity.this, paramValueCallback);
        Intent localIntent = new Intent("android.intent.action.GET_CONTENT");
        localIntent.addCategory("android.intent.category.OPENABLE");
        localIntent.setType("image/*");
        Mine03WebUrlActivity.this.startActivityForResult(Intent.createChooser(localIntent, "File Browser"), 2);
      }

      public void openFileChooser(ValueCallback<Uri> paramValueCallback, String paramString1, String paramString2)
      {
        Mine03WebUrlActivity.access$3502(Mine03WebUrlActivity.this, paramValueCallback);
        Intent localIntent = new Intent("android.intent.action.GET_CONTENT");
        localIntent.addCategory("android.intent.category.OPENABLE");
        localIntent.setType("image/*");
        Mine03WebUrlActivity.this.startActivityForResult(Intent.createChooser(localIntent, "File Browser"), 2);
      }
    };
    localWebView.setWebChromeClient(local3);
    VdsAgent.setWebChromeClient((WebView)localWebView, local3);
    this.mine03FitAbout.setDownloadListener(new DownloadListener()
    {
      public void onDownloadStart(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong)
      {
        try
        {
          Intent localIntent = new Intent();
          localIntent.setAction("android.intent.action.VIEW");
          localIntent.setData(Uri.parse(paramString1));
          Mine03WebUrlActivity.this.startActivity(localIntent);
          return;
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
        }
      }
    });
  }

  private void initPay()
  {
    if (StringUtils.isNull(this.payType));
    RequestModel localRequestModel;
    do
    {
      return;
      localRequestModel = new RequestModel();
      localRequestModel.commodityId = this.commodityId;
      localRequestModel.quantity = "1";
      if (StringUtils.isNull(this.callType));
      for (String str = "0"; ; str = this.callType)
      {
        this.callType = str;
        localRequestModel.callType = this.callType;
        localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.commodityId + NdkUtils.getSignBaseUrl()).toUpperCase();
        if (!"1".equals(this.payType))
          break;
        this.wechatPayHandler = new WechatPayHandler(this, this);
        this.wechatPayHandler.setPayType(this.paySource);
        this.wechatPayHandler.executeCallWechatPay(this, localRequestModel);
        return;
      }
      if ("0".equals(this.payType))
      {
        this.alipayHandler = new AlipayHandler(this, this);
        this.alipayHandler.setPayType(this.paySource);
        localRequestModel.aliJson = this.alipayHandler.getAlipayReqParams(this.price, this.comment, this.commodityTitle);
        this.alipayHandler.executeCallAlipay(this, localRequestModel);
        return;
      }
      if (!"3".equals(this.payType))
        continue;
      this.jdPayHandler = new JDPayHandler(this, this);
      this.jdPayHandler.setPayType(this.paySource);
      this.jdPayHandler.executeCallJDPay(this, localRequestModel);
      return;
    }
    while (!"4".equals(this.payType));
    localRequestModel.totalPrice = this.price;
    this.huaweiPayHandler.executeCallHuaweipay(localRequestModel);
  }

  private void jumpAppointPage(String paramString1, String paramString2)
  {
    int i = -1;
    Intent localIntent;
    switch (paramString1.hashCode())
    {
    default:
      localIntent = null;
      switch (i)
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      }
    case 48:
    case 49:
    case 50:
    case 51:
    case 53:
    case 54:
    case 55:
    case 56:
    case 57:
    case 1567:
    case 1568:
    case 1570:
    case 1571:
    case 1572:
    case 1573:
    case 1574:
    }
    while (true)
    {
      if (localIntent != null)
      {
        startActivity(localIntent);
        AnimationUtil.pageJumpAnim(this, 0);
      }
      return;
      if (!paramString1.equals("0"))
        break;
      i = 0;
      break;
      if (!paramString1.equals("1"))
        break;
      i = 1;
      break;
      if (!paramString1.equals("2"))
        break;
      i = 2;
      break;
      if (!paramString1.equals("3"))
        break;
      i = 3;
      break;
      if (!paramString1.equals("5"))
        break;
      i = 4;
      break;
      if (!paramString1.equals("6"))
        break;
      i = 5;
      break;
      if (!paramString1.equals("7"))
        break;
      i = 6;
      break;
      if (!paramString1.equals("8"))
        break;
      i = 7;
      break;
      if (!paramString1.equals("9"))
        break;
      i = 8;
      break;
      if (!paramString1.equals("10"))
        break;
      i = 9;
      break;
      if (!paramString1.equals("11"))
        break;
      i = 10;
      break;
      if (!paramString1.equals("13"))
        break;
      i = 11;
      break;
      if (!paramString1.equals("14"))
        break;
      i = 12;
      break;
      if (!paramString1.equals("15"))
        break;
      i = 13;
      break;
      if (!paramString1.equals("16"))
        break;
      i = 14;
      break;
      if (!paramString1.equals("17"))
        break;
      i = 15;
      break;
      localIntent = new Intent(this, Find04GenTrainInfoActivity.class);
      localIntent.putExtra("plan.id", paramString2);
      localIntent.putExtra("single.type", "0");
      continue;
      localIntent = new Intent(this, FitCourseJumpMidActivity.class);
      localIntent.putExtra("plan.id", paramString2);
      continue;
      localIntent = new Intent(this, Task02ChallengeDetailsActivity.class);
      localIntent.putExtra("missionId", paramString2);
      continue;
      if ("1".equals(FitApplication.userModel.orderf))
      {
        localIntent = new Intent(this, CustomDetailActivity.class);
        continue;
      }
      localIntent = new Intent(this, CustomStartActivity.class);
      continue;
      localIntent = new Intent(this, BrowseVideoDetailsActivity.class);
      localIntent.putExtra("tpc.id", paramString2);
      continue;
      EventBus.getDefault().post(new GotoShopTabEvent());
      localIntent = null;
      continue;
      localIntent = new Intent(this, ShopRecommendListActivity.class);
      if ("7".equals(paramString1))
      {
        EntclassInfoData localEntclassInfoData = new EntclassInfoData();
        localEntclassInfoData.proClassCode = paramString2;
        localIntent.putExtra("ShopRecommendListActivity.key.entclassInfoData", localEntclassInfoData);
        continue;
      }
      localIntent.putExtra("key.jumpFlg", paramString2);
      continue;
      localIntent = new Intent(this, MallGoodsInfoActivity.class);
      localIntent.putExtra(MallGoodsInfoActivity.GOODSID, paramString2);
      continue;
      CustomerServiceUtils.openServiceActivity(this, 1214204L);
      localIntent = null;
      continue;
      SharePreferenceUtils.putBuyVipFromPage("11");
      localIntent = new Intent(this, VipCenterActivity.class);
      continue;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      localIntent = null;
      continue;
      if ("1".equals(BaseApplication.userModel.isVip));
      for (Object localObject = ActionClassifyActivity.class; ; localObject = ActionUnLockActivity.class)
      {
        localIntent = new Intent(this, (Class)localObject);
        break;
      }
      localIntent = new Intent(this, MasterClassListActivity.class);
      continue;
      localIntent = new Intent(this, MasterClassDetailsActivity.class);
      localIntent.putExtra("lesson.id", paramString2);
      continue;
      localIntent = new Intent(this, MineCouponActivity.class);
    }
  }

  private void setProMaxAction(int paramInt)
  {
    int i = 1;
    int j = paramInt;
    if (j <= 101)
    {
      int k = j;
      if (j == 101);
      for (i = 800; ; i += 5)
      {
        new Handler().postDelayed(new Runnable(k)
        {
          public void run()
          {
            if (this.val$curPro <= 100)
            {
              Mine03WebUrlActivity.this.myProgressBar.setProgress(this.val$curPro);
              return;
            }
            Mine03WebUrlActivity.this.myProgressBar.setVisibility(8);
          }
        }
        , i);
        j++;
        break;
      }
    }
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ("Y".equals(paramT))
    {
      if ((StringUtils.isNull(BaseApplication.userModel.wechatNum)) || (!"2".equals(this.callType)) || (!"3".equals(this.commodityType)))
        break label72;
      this.dialog.zeroVipShareDialog(this, BaseApplication.userModel.wechatNum, new FitInterfaceUtils.DialogListener()
      {
        public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          ClipboardManager localClipboardManager;
          if (paramInt == -1)
          {
            localClipboardManager = (ClipboardManager)Mine03WebUrlActivity.this.getSystemService("clipboard");
            if (localClipboardManager == null)
              ToastUtils.makeToast(Mine03WebUrlActivity.this, "复制失败");
          }
          else
          {
            return;
          }
          localClipboardManager.setPrimaryClip(ClipData.newPlainText("Label", BaseApplication.userModel.wechatNum));
          ToastUtils.makeToast(Mine03WebUrlActivity.this, "复制成功");
        }
      });
    }
    label72: 
    do
      return;
    while ((!"3".equals(this.paySource)) || (!"3".equals(this.commodityType)));
    EventBus.getDefault().post(new ReceiveMedalEvent("11", this));
  }

  public void initLayout(Bundle paramBundle)
  {
    getWindow().setFormat(-3);
    setContentView(2130968922);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.huaweiPayHandler = new HuaweiPayHandler(this, this);
    this.huaweiPayHandler.setPayType(this.paySource);
    this.comefrom = getIntent().getExtras().getString("fromFlg");
    this.webUrl = getIntent().getExtras().getString("webUrl");
    if ((!StringUtils.isNull(this.webUrl)) && (this.webUrl.contains("duiba")))
    {
      FitCacheStoreUtils.setApiCacheInvalid(new ReformerImpl().getURL(EnumConstant.FitUrl.GetUserBusInfo));
      FitCacheStoreUtils.setApiCacheInvalid(new ReformerImpl().getURL(EnumConstant.FitUrl.GetUserBaseInfo));
    }
    this.shareFlg = getIntent().getStringExtra("share.flg");
    String str1 = getIntent().getStringExtra("url");
    String str3;
    if (!StringUtils.isNull(str1))
      str3 = str1.replaceAll("%(?![0-9a-fA-F]{2})", "%25");
    try
    {
      this.webUrl = URLDecoder.decode(str3, "UTF-8");
      this.shareFlg = "13";
      if (this.webUrl.contains("2017Fat"))
        this.shareFlg = "25";
      if (StringUtils.isNull(this.shareFlg))
        this.shareFlg = "13";
      this.link = getIntent().getExtras().getString("webUrl");
      this.describe = getIntent().getStringExtra("describe");
      this.title = getIntent().getExtras().getString("fromFlg");
      this.toolbar.setTitle("");
      if ((!StringUtils.isNull(this.comefrom)) && (!this.comefrom.equals("")))
        this.toolbar.setTitle(this.comefrom);
      this.toolbar.setNavIcon(2130903098);
      this.toolbar.setTitleTextColor(ContextCompat.getColor(this, 2131624003));
      this.toolbar.setBackgroundResource(2131624328);
      setSupportActionBar(this.toolbar);
      this.myProgressBar.setMax(100);
      initControl();
      synCookies(this.webUrl);
      WebView localWebView = this.mine03FitAbout;
      String str2 = this.webUrl;
      localWebView.loadUrl(str2);
      VdsAgent.loadUrl((View)localWebView, str2);
      return;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      while (true)
        localUnsupportedEncodingException.printStackTrace();
    }
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    Uri localUri;
    ContentResolver localContentResolver;
    if (paramIntent != null)
    {
      if (1024 == paramInt2)
      {
        String str4 = paramIntent.getStringExtra("jdpay_Result");
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.jdOrderId = this.strJdId;
        localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.strJdId + NdkUtils.getSignBaseUrl()).toUpperCase();
        localRequestModel.extraMsg = str4;
        this.jdPayHandler.checkJDPayResult(this, localRequestModel);
      }
      if (paramInt1 == 999)
      {
        localUri = paramIntent.getData();
        localContentResolver = getContentResolver();
      }
    }
    label286: 
    do
      try
      {
        String str1 = QiniuManager.uploadData(BitmapFactory.decodeStream(localContentResolver.openInputStream(localUri)));
        if (Build.VERSION.SDK_INT >= 19)
        {
          String str3 = "javascript:upPhotoFn('" + str1 + "')";
          this.mine03FitAbout.evaluateJavascript(str3, null);
        }
        while (true)
        {
          if (paramInt1 != 100)
            break label286;
          if (this.uploadMessage != null)
            break;
          return;
          WebView localWebView = this.mine03FitAbout;
          String str2 = "javascript:upPhotoFn('" + str1 + "')";
          localWebView.loadUrl(str2);
          VdsAgent.loadUrl((View)localWebView, str2);
        }
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        while (true)
          LogUtils.e(localFileNotFoundException);
        if (Build.VERSION.SDK_INT >= 21)
          this.uploadMessage.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(paramInt2, paramIntent));
        this.uploadMessage = null;
        return;
      }
    while ((paramInt1 != 2) || (this.mUploadMessage == null));
    if (paramInt2 != -1);
    for (Object localObject = null; ; localObject = paramIntent.getData())
    {
      this.mUploadMessage.onReceiveValue(localObject);
      this.mUploadMessage = null;
      return;
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    this.tMenu = paramMenu;
    getMenuInflater().inflate(2131820555, paramMenu);
    TextView localTextView = (TextView)MenuItemCompat.getActionView(paramMenu.findItem(2131758209));
    localTextView.setTextSize(16.0F);
    localTextView.setTextColor(ResourcesCompat.getColor(getResources(), 2131624071, null));
    localTextView.setText("跳过");
    int i = CompDeviceInfoUtils.convertOfDip(this, 16.0F);
    localTextView.setPadding(i, 0, i, 0);
    localTextView.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (Build.VERSION.SDK_INT >= 19)
        {
          Mine03WebUrlActivity.this.mine03FitAbout.evaluateJavascript("javascript:skipFn()", null);
          return;
        }
        WebView localWebView = Mine03WebUrlActivity.this.mine03FitAbout;
        localWebView.loadUrl("javascript:skipFn()");
        VdsAgent.loadUrl((View)localWebView, "javascript:skipFn()");
      }
    });
    return super.onCreateOptionsMenu(paramMenu);
  }

  protected void onDestroy()
  {
    try
    {
      if (this.mine03FitAbout != null)
      {
        this.webView_layout.removeView(this.mine03FitAbout);
        this.mine03FitAbout.destroy();
      }
      EventBus.getDefault().unregister(this);
      super.onDestroy();
      return;
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
  }

  @Subscribe
  public void onEventMainThread(GotoShopTabEvent paramGotoShopTabEvent)
  {
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if (("onResp".equals(paramString)) && (this.wechatPayHandler != null))
    {
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.orderId = this.strOrderId;
      localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.strOrderId + NdkUtils.getSignBaseUrl()).toUpperCase();
      this.wechatPayHandler.checkWechatPayResult(this, localRequestModel);
    }
  }

  public void onGetOrderId(String paramString)
  {
    if (paramString.contains("±"))
    {
      this.strJdId = paramString.split("±")[0];
      this.strOrderId = paramString.split("±")[1];
      return;
    }
    this.strOrderId = paramString;
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      String str;
      try
      {
        str = this.mine03FitAbout.getUrl();
        if (StringUtils.isNull(str))
        {
          finish();
          return false;
        }
        if ((!str.contains("mall-address")) && (!str.contains("2017FatOrderInfo")) && (!str.contains("inviter/index")))
          break label120;
        if (Build.VERSION.SDK_INT >= 19)
        {
          this.mine03FitAbout.evaluateJavascript("javascript:cancelFill()", null);
          return false;
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        finish();
        return false;
      }
      WebView localWebView = this.mine03FitAbout;
      localWebView.loadUrl("javascript:cancelFill()");
      VdsAgent.loadUrl((View)localWebView, "javascript:cancelFill()");
      return false;
      label120: if (str.contains("mall-type"))
      {
        finish();
        AnimationUtil.pageJumpAnim(this, 1);
        return false;
      }
      if (this.mine03FitAbout.canGoBack())
      {
        this.mine03FitAbout.goBack();
        return false;
      }
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    case 2131758207:
    case 2131758208:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      try
      {
        String str2 = this.mine03FitAbout.getUrl();
        if (StringUtils.isNull(str2))
        {
          finish();
          VdsAgent.handleClickResult(new Boolean(false));
          return false;
        }
        if ((!str2.contains("mall-address")) && (!str2.contains("2017FatOrderInfo")) && (!str2.contains("inviter/index")))
          break label198;
        if (Build.VERSION.SDK_INT < 19)
          break label170;
        this.mine03FitAbout.evaluateJavascript("javascript:cancelFill()", null);
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        finish();
      }
      continue;
      label170: WebView localWebView = this.mine03FitAbout;
      localWebView.loadUrl("javascript:cancelFill()");
      VdsAgent.loadUrl((View)localWebView, "javascript:cancelFill()");
      continue;
      label198: finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      com.sportq.fit.common.constant.Constant.share_state = true;
      UseShareModel localUseShareModel = new UseShareModel();
      localUseShareModel.title = this.title;
      localUseShareModel.describe = this.describe;
      localUseShareModel.link = this.link;
      localUseShareModel.cTitle = this.cTitle;
      localUseShareModel.imgUrl = this.imgUrl;
      localUseShareModel.wTitle = this.wTitle;
      localUseShareModel.weiboImg = this.weiboImg;
      localUseShareModel.imgActUrl = this.imgActUrl;
      localUseShareModel.olapflg = this.olapflg;
      if (StringUtils.isNull(this.olapflg));
      for (String str1 = this.shareFlg; ; str1 = this.olapflg)
      {
        this.shareFlg = str1;
        this.dialog.showShareChoiseDialog(this, Integer.valueOf(this.shareFlg).intValue(), localUseShareModel, this.dialog);
        break;
      }
      CustomerServiceUtils.openServiceActivity(this, 1214204L);
    }
  }

  public void onPayFail(int paramInt, String paramString)
  {
  }

  public void onPaySuccess(int paramInt)
  {
    try
    {
      ToastUtils.makeToast(this, "支付成功");
      BaseApplication.userModel.energyValue = String.valueOf(StringUtils.string2Int(BaseApplication.userModel.energyValue) + Integer.valueOf(this.dealEnergyValue).intValue());
      BaseApplication.isRefresh = true;
      MiddleManager.getInstance().getMinePresenterImpl(this).getUserInfo(this);
      EventBus.getDefault().post(new ReceiveMedalEvent("0", this));
      if ((!StringUtils.isNull(this.nUrl)) && (this.mine03FitAbout != null))
      {
        if ("2".equals(this.callType))
        {
          EventBus.getDefault().post("renew.success");
          this.nUrl = (this.nUrl + "&order=" + this.strOrderId);
        }
        WebView localWebView2 = this.mine03FitAbout;
        String str2 = this.nUrl;
        localWebView2.loadUrl(str2);
        VdsAgent.loadUrl((View)localWebView2, str2);
      }
      this.dealEnergyValue = "0";
      if (!StringUtils.isNull(this.callback))
      {
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = this.callback;
        String str1 = String.format("javascript:%s()", arrayOfObject);
        if (Build.VERSION.SDK_INT >= 19)
        {
          this.mine03FitAbout.evaluateJavascript(str1, null);
          return;
        }
        WebView localWebView1 = this.mine03FitAbout;
        localWebView1.loadUrl(str1);
        VdsAgent.loadUrl((View)localWebView1, str1);
        return;
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  protected void onResume()
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
    if (this.wechatPayHandler != null)
      this.wechatPayHandler.checkWeichatVersion();
    if (this.isNeedRefresh)
      this.mine03FitAbout.reload();
    hideKeyboard();
    super.onResume();
  }

  public void synCookies(String paramString)
  {
    CookieSyncManager.createInstance(this);
    CookieManager localCookieManager = CookieManager.getInstance();
    localCookieManager.setAcceptCookie(true);
    localCookieManager.removeSessionCookie();
    if (StringUtils.isNull(BaseApplication.userModel.userId));
    for (String str = ""; ; str = BaseApplication.userModel.userId)
    {
      localCookieManager.setCookie(paramString, "Fit_uid=" + str);
      CookieSyncManager.getInstance().sync();
      return;
    }
  }

  private class MyJavaScriptInterface
  {
    private MyJavaScriptInterface()
    {
    }

    @JavascriptInterface
    public void androidCopy(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 9;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void androidOpenPage(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 4;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void androidSaveImg(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 3;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void androidShow(String paramString)
    {
      if (StringUtils.isNull(paramString))
        return;
      Message localMessage = new Message();
      localMessage.arg1 = 12;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void blackAction(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 13;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void clickDw(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 8;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void clickEnergy(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 5;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void clickFill(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 7;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void clickOnAndroid(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 1;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void copyAction(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 16;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void fitPay(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 6;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void openPage(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 11;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void openQQ(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 18;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void savePhoto(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 15;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void upPhoto()
    {
      Message localMessage = new Message();
      localMessage.arg1 = 10;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void viewImg(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 14;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void webViewShare(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 2;
      localMessage.obj = paramString;
      Mine03WebUrlActivity.this.handler.sendMessage(localMessage);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.Mine03WebUrlActivity
 * JD-Core Version:    0.6.0
 */