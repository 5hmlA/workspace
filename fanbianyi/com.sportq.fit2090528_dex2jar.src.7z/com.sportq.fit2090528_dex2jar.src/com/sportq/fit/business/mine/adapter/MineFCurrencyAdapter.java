package com.sportq.fit.business.mine.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.mine.activity.MineFCurrencyActivity;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RFrameLayout;
import com.sportq.fit.common.utils.superView.helper.RBaseHelper;
import com.sportq.fit.persenter.model.GetFcoinCommodityModel;
import java.util.ArrayList;

public class MineFCurrencyAdapter extends BaseAdapter
{
  private Context context;
  private int defSelIndex;
  private OnFCurrencyItemClickListener itemClickListener;
  private ArrayList<GetFcoinCommodityModel> lstFcoinCommodity;

  public MineFCurrencyAdapter(Context paramContext, ArrayList<GetFcoinCommodityModel> paramArrayList, int paramInt)
  {
    this.context = paramContext;
    if ((paramArrayList == null) || (paramArrayList.size() == 0))
      paramArrayList = new ArrayList();
    this.lstFcoinCommodity = paramArrayList;
    this.itemClickListener = ((MineFCurrencyActivity)paramContext);
    this.defSelIndex = paramInt;
    if (this.defSelIndex == -1)
      this.defSelIndex = 1;
  }

  private String replaceDot(String paramString)
  {
    if (StringUtils.isNull(paramString))
      paramString = "";
    do
      return paramString;
    while (!paramString.contains("."));
    return paramString.substring(0, paramString.indexOf("."));
  }

  public int getCount()
  {
    return this.lstFcoinCommodity.size();
  }

  public int getDefSelIndex()
  {
    return this.defSelIndex;
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    GetFcoinCommodityModel localGetFcoinCommodityModel;
    label229: String str;
    TextView localTextView;
    if (paramView == null)
    {
      localViewHolder = new ViewHolder(null);
      paramView = LayoutInflater.from(this.context).inflate(2130968818, null);
      ViewHolder.access$102(localViewHolder, (RFrameLayout)paramView.findViewById(2131756043));
      ViewHolder.access$202(localViewHolder, (TextView)paramView.findViewById(2131756045));
      ViewHolder.access$302(localViewHolder, (TextView)paramView.findViewById(2131756046));
      ViewHolder.access$402(localViewHolder, (TextView)paramView.findViewById(2131756047));
      ViewHolder.access$502(localViewHolder, (ImageView)paramView.findViewById(2131756048));
      ViewHolder.access$602(localViewHolder, (ImageView)paramView.findViewById(2131756049));
      paramView.setTag(localViewHolder);
      localGetFcoinCommodityModel = (GetFcoinCommodityModel)this.lstFcoinCommodity.get(paramInt);
      int i = (int)((BaseApplication.screenWidth - CompDeviceInfoUtils.convertOfDip(this.context, 60.0F)) / 3.0F);
      localViewHolder.fcurrency_layout.getLayoutParams().width = i;
      localViewHolder.fcurrency_layout.getLayoutParams().height = i;
      localViewHolder.cur_fcurrency_tv.setText(localGetFcoinCommodityModel.commodityTitle);
      if (StringUtils.isNull(localGetFcoinCommodityModel.disComment))
        break label429;
      localViewHolder.give_fcurrency_tv.setVisibility(0);
      localViewHolder.give_fcurrency_tv.setText(localGetFcoinCommodityModel.disComment);
      str = replaceDot(localGetFcoinCommodityModel.price);
      localTextView = localViewHolder.fcurrency_price;
      if (!str.contains("元"))
        break label442;
    }
    while (true)
    {
      localTextView.setText(str);
      if (!StringUtils.isNull(localGetFcoinCommodityModel.activeImageUrl))
      {
        GlideUtils.loadImgByAdjust(localGetFcoinCommodityModel.activeImageUrl, localViewHolder.vip_package_tag);
        localViewHolder.vip_package_tag.setVisibility(0);
        Animation localAnimation = AnimationUtils.loadAnimation(this.context, 2131034173);
        localViewHolder.promotion_anim.startAnimation(localAnimation);
      }
      localViewHolder.fcurrency_layout.setOnClickListener(new View.OnClickListener(localViewHolder, paramInt)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (MineFCurrencyAdapter.ViewHolder.access$100(this.val$holder).getTag() == null)
          {
            MineFCurrencyAdapter.access$702(MineFCurrencyAdapter.this, -1);
            MineFCurrencyAdapter.this.notifyDataSetChanged();
            MineFCurrencyAdapter.ViewHolder.access$100(this.val$holder).getHelper().setBackgroundColorNormal(ContextCompat.getColor(MineFCurrencyAdapter.this.context, 2131623997)).setBorderColorNormal(ContextCompat.getColor(MineFCurrencyAdapter.this.context, 2131624121)).setBorderWidthNormal(CompDeviceInfoUtils.dipToPx(1.0F));
            MineFCurrencyAdapter.ViewHolder.access$100(this.val$holder).setTag(Integer.valueOf(this.val$position));
            MineFCurrencyAdapter.access$702(MineFCurrencyAdapter.this, this.val$position);
            if (MineFCurrencyAdapter.this.itemClickListener != null)
              MineFCurrencyAdapter.this.itemClickListener.onFCurrencyItemClick(this.val$position);
          }
        }
      });
      if (this.defSelIndex != paramInt)
        break label467;
      localViewHolder.fcurrency_layout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this.context, 2131623997)).setBorderColorNormal(ContextCompat.getColor(this.context, 2131624121)).setBorderWidthNormal(CompDeviceInfoUtils.dipToPx(1.0F));
      localViewHolder.fcurrency_layout.setTag(Integer.valueOf(paramInt));
      if (this.itemClickListener != null)
        this.itemClickListener.onFCurrencyItemClick(paramInt);
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
      break;
      label429: localViewHolder.give_fcurrency_tv.setVisibility(8);
      break label229;
      label442: str = str + "元";
    }
    label467: localViewHolder.fcurrency_layout.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this.context, 2131624292)).setBorderColorNormal(ContextCompat.getColor(this.context, 2131624090)).setBorderWidthNormal(CompDeviceInfoUtils.dipToPx(1.0F));
    localViewHolder.fcurrency_layout.setTag(null);
    return paramView;
  }

  public static abstract interface OnFCurrencyItemClickListener
  {
    public abstract void onFCurrencyItemClick(int paramInt);
  }

  private static final class ViewHolder
  {
    private TextView cur_fcurrency_tv;
    private RFrameLayout fcurrency_layout;
    private TextView fcurrency_price;
    private TextView give_fcurrency_tv;
    private ImageView promotion_anim;
    private ImageView vip_package_tag;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.adapter.MineFCurrencyAdapter
 * JD-Core Version:    0.6.0
 */