package com.sportq.fit.business.mine.activity;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class MineFcoinInfoActivity$$ViewBinder<T extends MineFcoinInfoActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.recyclerView = ((RecyclerView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755532, "field 'recyclerView'"), 2131755532, "field 'recyclerView'"));
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.empty_layout = ((LinearLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755697, "field 'empty_layout'"), 2131755697, "field 'empty_layout'"));
    paramT.empty_icon = ((ImageView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755906, "field 'empty_icon'"), 2131755906, "field 'empty_icon'"));
    paramT.empty_hint = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755907, "field 'empty_hint'"), 2131755907, "field 'empty_hint'"));
  }

  public void unbind(T paramT)
  {
    paramT.recyclerView = null;
    paramT.toolbar = null;
    paramT.empty_layout = null;
    paramT.empty_icon = null;
    paramT.empty_hint = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.MineFcoinInfoActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */