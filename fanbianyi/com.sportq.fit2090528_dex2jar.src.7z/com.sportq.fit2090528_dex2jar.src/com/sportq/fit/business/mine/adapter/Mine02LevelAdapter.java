package com.sportq.fit.business.mine.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.MedalModel;
import com.sportq.fit.common.model.RankLevelModel;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle10.organize.activity.Mine03MedalDetailsActivity;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class Mine02LevelAdapter extends SuperAdapter<RankLevelModel>
{
  public Mine02LevelAdapter(Context paramContext, List<RankLevelModel> paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, RankLevelModel paramRankLevelModel)
  {
    FrameLayout localFrameLayout = (FrameLayout)paramSuperViewHolder.findViewById(2131755225);
    GlideUtils.loadImgByDefault(paramRankLevelModel.levelImageUrl, 2130903536, (ImageView)paramSuperViewHolder.findViewById(2131756624));
    ((TextView)paramSuperViewHolder.findViewById(2131756625)).setText(paramRankLevelModel.levelName);
    TextView localTextView = (TextView)paramSuperViewHolder.findViewById(2131756621);
    localTextView.setTypeface(TextUtils.getFontFaceImpact());
    localTextView.setText(paramRankLevelModel.levelDuration);
    if ("1".equals(paramRankLevelModel.isLight))
    {
      paramSuperViewHolder.setText(2131756626, paramRankLevelModel.getData);
      paramSuperViewHolder.findViewById(2131755687).setVisibility(4);
      localFrameLayout.setOnClickListener(new FitAction(null, paramRankLevelModel)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          Intent localIntent = new Intent(Mine02LevelAdapter.this.getContext(), Mine03MedalDetailsActivity.class);
          MedalModel localMedalModel = new MedalModel();
          localMedalModel.medalBigPic = this.val$rankLevelModel.levelBigImageUrl;
          localMedalModel.medalName = this.val$rankLevelModel.levelName;
          localMedalModel.medalGetDate = this.val$rankLevelModel.getData;
          localMedalModel.medalIntroduce = this.val$rankLevelModel.medalIntr;
          localMedalModel.medalGetNum = this.val$rankLevelModel.numberOfOwn;
          localMedalModel.durationText = this.val$rankLevelModel.levelDuration;
          localMedalModel.numberColor = this.val$rankLevelModel.numberColor;
          localMedalModel.medalType = "MED01";
          localMedalModel.medalTypel = Constant.STR_1;
          localMedalModel.isLight = "1".equals(this.val$rankLevelModel.isLight);
          Bundle localBundle = new Bundle();
          localBundle.putSerializable("model", localMedalModel);
          localIntent.putExtras(localBundle);
          Mine02LevelAdapter.this.getContext().startActivity(localIntent);
          super.onClick(paramView);
        }
      });
      return;
    }
    paramSuperViewHolder.setText(2131756626, "");
    paramSuperViewHolder.findViewById(2131755687).setVisibility(0);
    localFrameLayout.setOnClickListener(null);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.adapter.Mine02LevelAdapter
 * JD-Core Version:    0.6.0
 */