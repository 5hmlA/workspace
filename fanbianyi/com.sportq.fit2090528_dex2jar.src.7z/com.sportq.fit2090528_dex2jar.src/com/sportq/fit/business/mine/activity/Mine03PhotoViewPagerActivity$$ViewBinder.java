package com.sportq.fit.business.mine.activity;

import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class Mine03PhotoViewPagerActivity$$ViewBinder<T extends Mine03PhotoViewPagerActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.mine_viewpager = ((ViewPager)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756782, "field 'mine_viewpager'"), 2131756782, "field 'mine_viewpager'"));
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.mine03_photo_info = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756748, "field 'mine03_photo_info'"), 2131756748, "field 'mine03_photo_info'"));
    paramT.mine03_photo_train = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756751, "field 'mine03_photo_train'"), 2131756751, "field 'mine03_photo_train'"));
    paramT.mine03_check_button = ((RTextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756752, "field 'mine03_check_button'"), 2131756752, "field 'mine03_check_button'"));
    paramT.mine03_photo_info_l = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756747, "field 'mine03_photo_info_l'"), 2131756747, "field 'mine03_photo_info_l'"));
    paramT.toolbar_layout = ((RelativeLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755277, "field 'toolbar_layout'"), 2131755277, "field 'toolbar_layout'"));
    paramT.weight_info = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756750, "field 'weight_info'"), 2131756750, "field 'weight_info'"));
    paramT.mine_photo_weight = ((LinearLayout)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131756749, "field 'mine_photo_weight'"), 2131756749, "field 'mine_photo_weight'"));
  }

  public void unbind(T paramT)
  {
    paramT.mine_viewpager = null;
    paramT.toolbar = null;
    paramT.mine03_photo_info = null;
    paramT.mine03_photo_train = null;
    paramT.mine03_check_button = null;
    paramT.mine03_photo_info_l = null;
    paramT.toolbar_layout = null;
    paramT.weight_info = null;
    paramT.mine_photo_weight = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.Mine03PhotoViewPagerActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */