package com.sportq.fit.business.mine.widget;

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.sportq.fit.business.BaseNavView;
import com.sportq.fit.business.mine.adapter.MinePhotoAlbumAdapter;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.FitnessPicModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.FitnessAlbumPhotoReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreAdapter;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper.OnLoadMoreWarpperListener;
import com.sportq.fit.common.utils.stickrecycleradapter.StickyRecyclerHeadersDecoration;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

public class AllPhotoView extends BaseNavView
  implements LoadMoreWrapper.OnLoadMoreWarpperListener
{
  private MinePhotoAlbumAdapter adapter;
  private RelativeLayout emptyView;
  public String lastId;
  private LoadMoreWrapper loadMoreWrapper;
  private Context mContext;
  private ArrayList<FitnessPicModel> mList;
  private FitnessAlbumPhotoReformer mReformer;
  private RelativeLayout no_network_layout;
  private RecyclerView recyclerView;
  private TextView refresh_btn;

  public AllPhotoView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(2130969007, null);
    this.recyclerView = ((RecyclerView)localView.findViewById(2131755283));
    this.emptyView = ((RelativeLayout)localView.findViewById(2131755697));
    this.no_network_layout = ((RelativeLayout)localView.findViewById(2131755486));
    this.refresh_btn = ((TextView)localView.findViewById(2131755488));
    this.refresh_btn.setOnClickListener(new FitAction(this));
    return localView;
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == 2131755488)
    {
      if (!CompDeviceInfoUtils.checkNetwork())
      {
        ToastUtils.makeToast(this.mContext, StringUtils.getStringResources(2131298238));
        return;
      }
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.recordDate = "";
      localRequestModel.photoType = "";
      MiddleManager.getInstance().getMinePresenterImpl(this).getTrainPhotoAlbum(localRequestModel, this.mContext);
    }
    super.fitOnClick(paramView);
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.mReformer = ((FitnessAlbumPhotoReformer)paramT);
    if (this.mReformer == null)
    {
      if (this.recyclerView.getTag() != null)
      {
        this.loadMoreWrapper.setLoadMoreEnabled(false);
        this.adapter.notifyDataSetChanged();
        this.recyclerView.setTag(null);
        return;
      }
      this.mList = null;
      this.emptyView.setVisibility(0);
      this.no_network_layout.setVisibility(8);
      this.recyclerView.setVisibility(8);
      return;
    }
    if (this.mList == null)
    {
      this.mList = this.mReformer.lstAlbum;
      this.emptyView.setVisibility(8);
      this.no_network_layout.setVisibility(8);
      this.recyclerView.setVisibility(0);
      this.adapter = new MinePhotoAlbumAdapter(this, null, this.mContext, this.mList);
      this.recyclerView.setLayoutManager(new LinearLayoutManager(this.mContext));
      this.recyclerView.setAdapter(this.adapter);
      if (this.loadMoreWrapper == null)
        this.recyclerView.addItemDecoration(new StickyRecyclerHeadersDecoration(this.adapter));
      this.loadMoreWrapper = new LoadMoreWrapper(new LoadMoreAdapter(this.adapter), this);
      this.loadMoreWrapper.setShowNoMoreEnabled(false);
      this.loadMoreWrapper.into(this.recyclerView);
    }
    while (true)
    {
      this.lastId = this.mReformer.strHisotry;
      this.recyclerView.setTag(null);
      super.getDataSuccess(paramT);
      return;
      if (this.recyclerView.getTag() != null)
      {
        if (this.mReformer.lstAlbum.size() > 0)
        {
          this.mList.addAll(this.mReformer.lstAlbum);
          this.adapter.setList(this.mList);
          this.adapter.notifyDataSetChanged();
          continue;
        }
        this.loadMoreWrapper.setLoadMoreEnabled(false);
        this.adapter.notifyDataSetChanged();
        continue;
      }
      this.mList = this.mReformer.lstAlbum;
      this.emptyView.setVisibility(8);
      this.no_network_layout.setVisibility(8);
      this.recyclerView.setVisibility(0);
      this.adapter.setList(this.mList);
      this.adapter.notifyDataSetChanged();
    }
  }

  public void onLoadMore()
  {
    if (this.recyclerView == null)
      return;
    if (CompDeviceInfoUtils.checkNetwork())
    {
      this.recyclerView.setTag("load.more");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.recordDate = this.lastId;
      localRequestModel.photoType = "";
      MiddleManager.getInstance().getMinePresenterImpl(this).getTrainPhotoAlbum(localRequestModel, this.mContext);
      return;
    }
    ToastUtils.makeToast(this.mContext, getResources().getString(2131299052));
  }

  public void refreshData()
  {
    this.lastId = "";
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.recordDate = this.lastId;
    localRequestModel.photoType = "";
    MiddleManager.getInstance().getMinePresenterImpl(this).getTrainPhotoAlbum(localRequestModel, this.mContext);
  }

  public void setAllPhotoData()
  {
    if ((this.adapter == null) && (!CompDeviceInfoUtils.checkNetwork()))
    {
      this.no_network_layout.setVisibility(0);
      this.emptyView.setVisibility(8);
      this.recyclerView.setVisibility(8);
    }
    do
      return;
    while ((this.adapter != null) && (this.adapter.getItemCount() > 0));
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.recordDate = "";
    localRequestModel.photoType = "";
    MiddleManager.getInstance().getMinePresenterImpl(this).getTrainPhotoAlbum(localRequestModel, this.mContext);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.widget.AllPhotoView
 * JD-Core Version:    0.6.0
 */