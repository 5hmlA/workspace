package com.sportq.fit.business.mine.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build.VERSION;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.qiyukf.unicorn.api.Unicorn;
import com.sportq.fit.business.BaseNavView;
import com.sportq.fit.business.FitApplication;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.AppUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.CheckRedPointUtils;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.MessageModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.reformer.MineReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.XUtilDB;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.RView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.activity.VipCenterActivity;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.network.model.SignSearchModel;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;
import com.sportq.fit.fitmoudle.network.reformer.SignSearchReformer;
import com.sportq.fit.fitmoudle.widget.FitVipUserView;
import com.sportq.fit.fitmoudle.widget.FitVipUserView.OnUserIconClickListener;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02FragmentMedalActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02NoticeActivity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02WeightActivity;
import com.sportq.fit.fitmoudle10.organize.activity.PerfectInfoFirstActivity;
import com.sportq.fit.fitmoudle10.organize.activity.TrainRecordsActivity;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.FitnessTestPreviewActivity;
import com.sportq.fit.fitmoudle12.browse.activity.BrowseMyLikeActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MineCouponActivity;
import com.sportq.fit.fitmoudle13.shop.activity.MineOrderActivity;
import com.sportq.fit.fitmoudle4.setting.activity.Mine02SettingActivity;
import com.sportq.fit.fitmoudle4.setting.activity.Mine03AccountActivity;
import com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity;
import com.sportq.fit.fitmoudle4.setting.common.SettingSharePreferenceUtils;
import com.sportq.fit.fitmoudle5.activity.MasterCourseActivity;
import com.sportq.fit.fitmoudle8.widget.CustomScrollView;
import com.sportq.fit.fitmoudle8.widget.CustomScrollView.ScrollViewListener;
import com.sportq.fit.fitmoudle9.energy.activity.EnergyInvitCodeActivity;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.http.cache.FitCacheStoreUtils;

public class MineTabView extends BaseNavView
{
  private TextView F_coin_records_num;
  private TextView can_draw_tv;
  private RView coupon_icon_hint;
  private TextView coupon_icon_records_num;
  private TextView fitness_level;
  private TextView invite_status;
  private TextView invite_tv;
  private Context mContext;
  private TextView master_class_records_num;
  private RView master_class_status;
  private TextView mineFragmentName;
  private RTextView mineFragmentNoticeNum;
  RelativeLayout mineFragmentPersonalTraining;
  private TextView mineFragmentRecordsNum;
  RelativeLayout mineFragmentTrainingRecordsL;
  private MineReformer mineReformer;
  private RelativeLayout mineTabLayout;
  private RView mine_F_coin_hint;
  private TextView mine_energy_value;
  private RView mine_fragment_no_punch_hint;
  private ImageView mine_fragment_notice;
  RelativeLayout mine_fragment_photo_album_l;
  private ImageView mine_fragment_setting;
  private RTextView mine_fragment_setting_point;
  private TextView mine_fragment_weight_num;
  RelativeLayout mine_fragment_weight_records_l;
  private RTextView mine_level;
  private ImageView mine_level_img;
  private RTextView mine_medal;
  private RTextView mine_order_hint;
  private TextView mine_photo_album_num;
  CustomScrollView mine_scrollview;
  private FrameLayout mine_tab_title;
  private View mine_title_split_line;
  private RelativeLayout mine_vip_schedule_layout;
  private TextView mine_vip_schedule_num;
  private ImageView money_icon;
  private SignSearchReformer signSearchReformer;
  private RTextView sign_btn;
  private TextView title_userName;
  private RelativeLayout unBindIphoneLayout;
  RelativeLayout unbind_close_img;
  TextView unbind_hint;
  private FitVipUserView user_icon;
  private FrameLayout user_info_layout;
  private ImageView vip_icon;
  private TextView vip_status_tv;
  private TextView vip_tv;

  public MineTabView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
  }

  private String getNoticeStr(MineReformer paramMineReformer)
  {
    int i = StringUtils.string2Int(paramMineReformer.messageModel.messageNumber);
    int j = StringUtils.string2Int(paramMineReformer.messageModel.commentNumber);
    int k = StringUtils.string2Int(paramMineReformer.messageModel.likeNum);
    int m = StringUtils.string2Int(paramMineReformer.messageModel.remindNumber);
    return m + (k + (i + j)) + "";
  }

  private void setUserInfo()
  {
    this.mineFragmentName.setText(FitApplication.userModel.userName);
    RTextView localRTextView1 = this.mine_level;
    int i;
    int j;
    label62: label114: String str1;
    label178: String str2;
    label207: int k;
    label277: label415: label495: String str3;
    label601: TextView localTextView5;
    if ("Lv12".equals(FitApplication.userModel.gradeName))
    {
      i = 8;
      localRTextView1.setVisibility(i);
      ImageView localImageView = this.mine_level_img;
      if (!"Lv12".equals(FitApplication.userModel.gradeName))
        break label738;
      j = 0;
      localImageView.setVisibility(j);
      if (StringUtils.string2Int(FitApplication.userModel.trainTime) >= 30)
        break label745;
      this.mine_level.setText(getResources().getString(2131297394));
      this.mine_level.setTextColor(ContextCompat.getColor(this.mContext, 2131624066));
      this.mine_medal.setVisibility(0);
      RTextView localRTextView3 = this.mine_medal;
      Object[] arrayOfObject2 = new Object[1];
      arrayOfObject2[0] = FitApplication.userModel.decoratioCount;
      localRTextView3.setText(String.format("勋章 %s", arrayOfObject2));
      TextView localTextView1 = this.mine_energy_value;
      if (!StringUtils.isNull(BaseApplication.userModel.energyValue))
        break label829;
      str1 = "0";
      localTextView1.setText(str1);
      TextView localTextView2 = this.F_coin_records_num;
      if (!StringUtils.isNull(BaseApplication.userModel.fcoinValue))
        break label840;
      str2 = "0";
      localTextView2.setText(str2);
      this.mineFragmentRecordsNum.setText(String.valueOf(FitApplication.userModel.trainCount + "次"));
      if (!StringUtils.isNull(FitApplication.userModel.currentWeight))
        break label851;
      this.mine_fragment_weight_num.setText(this.mContext.getString(2131297437));
      this.mine_photo_album_num.setText(String.valueOf(FitApplication.userModel.photoNumber + "张"));
      this.user_icon.loadUserIcon(FitApplication.userModel.userImg).setVipTagSize(CompDeviceInfoUtils.convertOfDip(this.mContext, 82.0F), 0.243902D);
      this.user_icon.setListener(new FitVipUserView.OnUserIconClickListener()
      {
        public void onUserIconClick()
        {
          MineTabView.this.mContext.startActivity(new Intent(MineTabView.this.mContext, Mine03PersonalActivity.class));
          AnimationUtil.pageJumpAnim((Activity)MineTabView.this.mContext, 0);
        }
      });
      this.vip_status_tv.setVisibility(0);
      this.vip_status_tv.setTextColor(getResources().getColor(2131624044));
      if (!AppUtils.isVip())
        break label889;
      this.user_icon.setIsVip(1);
      this.vip_icon.setImageResource(2130903720);
      this.user_info_layout.setBackgroundResource(2130903703);
      this.vip_status_tv.setText(BaseApplication.userModel.vipComment);
      this.vip_tv.setText(BaseApplication.userModel.vipText);
      this.invite_status.setText(BaseApplication.userModel.inviteIntr);
      this.invite_status.setTextColor(getResources().getColor(2131624044));
      TextView localTextView3 = this.can_draw_tv;
      if (!"1".equals(BaseApplication.userModel.canDraw))
        break label937;
      k = 0;
      localTextView3.setVisibility(k);
      GlideUtils.loadImgByDefault(BaseApplication.userModel.inviteImg, 2130903056, this.money_icon);
      this.invite_tv.setText(BaseApplication.userModel.inviteTitle);
      this.fitness_level.setVisibility(0);
      if ((StringUtils.isNull(BaseApplication.userModel.levelCode)) || ("未测试".equals(BaseApplication.userModel.levelCode)))
        break label943;
      this.fitness_level.setText(String.valueOf(BaseApplication.userModel.levelCode + " 级"));
      if (StringUtils.isNull(BaseApplication.userModel.zeroRate))
        break label966;
      this.mine_vip_schedule_layout.setVisibility(0);
      this.mine_vip_schedule_layout.setOnClickListener(new FitAction(this));
      this.mine_vip_schedule_num.setText(BaseApplication.userModel.zeroRate);
      label649: TextView localTextView4 = this.coupon_icon_records_num;
      if (!StringUtils.isNull(BaseApplication.userModel.couponNum))
        break label978;
      str3 = "0 张";
      label672: localTextView4.setText(str3);
      localTextView5 = this.master_class_records_num;
      if (!StringUtils.isNull(BaseApplication.userModel.lessonNum))
        break label1011;
    }
    label738: label745: label1011: for (String str4 = "0 节"; ; str4 = String.valueOf(BaseApplication.userModel.lessonNum + " 节"))
    {
      localTextView5.setText(str4);
      setSpotsState(this.mineReformer);
      new PresenterImpl(this).signSearch(this.mContext);
      return;
      i = 0;
      break;
      j = 8;
      break label62;
      if ("Lv12".equals(FitApplication.userModel.gradeName))
      {
        GlideUtils.loadImgByDefault(FitApplication.userModel.gradeImage, this.mine_level_img);
        break label114;
      }
      RTextView localRTextView2 = this.mine_level;
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = FitApplication.userModel.gradeName;
      localRTextView2.setText(String.format("等级 %s", arrayOfObject1));
      this.mine_level.setTextColor(Color.parseColor(FitApplication.userModel.gradeColor));
      break label114;
      str1 = BaseApplication.userModel.energyValue;
      break label178;
      str2 = BaseApplication.userModel.fcoinValue;
      break label207;
      this.mine_fragment_weight_num.setText(String.valueOf(FitApplication.userModel.currentWeight + "kg"));
      break label277;
      label889: this.user_icon.setIsVip(0);
      this.vip_icon.setImageResource(2130903721);
      this.user_info_layout.setBackgroundResource(2130903702);
      this.vip_status_tv.setTextColor(getResources().getColor(2131624044));
      break label415;
      k = 4;
      break label495;
      this.fitness_level.setText(this.mContext.getResources().getString(2131297384));
      break label601;
      this.mine_vip_schedule_layout.setVisibility(8);
      break label649;
      str3 = String.valueOf(BaseApplication.userModel.couponNum + " 张");
      break label672;
    }
  }

  private void translateAnimation()
  {
    TranslateAnimation localTranslateAnimation = new TranslateAnimation(0.0F, 0.0F, 0.0F, -this.unBindIphoneLayout.getMeasuredHeight());
    localTranslateAnimation.setDuration(300L);
    localTranslateAnimation.setAnimationListener(new Animation.AnimationListener()
    {
      public void onAnimationEnd(Animation paramAnimation)
      {
        MineTabView.this.unBindIphoneLayout.setVisibility(8);
      }

      public void onAnimationRepeat(Animation paramAnimation)
      {
      }

      public void onAnimationStart(Animation paramAnimation)
      {
      }
    });
    this.unBindIphoneLayout.startAnimation(localTranslateAnimation);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131756912:
    case 2131756915:
    case 2131756937:
    case 2131756620:
    case 2131756926:
    case 2131756928:
    case 2131756927:
    case 2131756954:
    case 2131756933:
    case 2131756949:
    case 2131756952:
    case 2131756969:
    case 2131756973:
    case 2131756920:
    case 2131756919:
    case 2131756958:
    case 2131756960:
    case 2131756965:
    case 2131756179:
    case 2131757844:
    case 2131757847:
    case 2131756941:
    case 2131756956:
    case 2131756945:
    case 2131756955:
    case 2131756925:
    }
    while (true)
    {
      super.fitOnClick(paramView);
      do
      {
        return;
        if (this.mineFragmentNoticeNum.getVisibility() == 0)
          FitCacheStoreUtils.setApiCacheInvalid("/SFitWeb/sfit/getMessageList");
        Intent localIntent16 = new Intent(this.mContext, Mine02NoticeActivity.class);
        this.mContext.startActivity(localIntent16);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        Intent localIntent15 = new Intent(this.mContext, Mine02SettingActivity.class);
        this.mContext.startActivity(localIntent15);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        Intent localIntent14 = new Intent(this.mContext, MineFitnessPhotoAlbumActivity.class);
        this.mContext.startActivity(localIntent14);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        Intent localIntent13 = new Intent(this.mContext, Mine02LevelActivity.class);
        this.mContext.startActivity(localIntent13);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        Intent localIntent12 = new Intent(this.mContext, TrainRecordsActivity.class);
        this.mContext.startActivity(localIntent12);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        Intent localIntent11 = new Intent(this.mContext, Mine02FragmentMedalActivity.class);
        this.mContext.startActivity(localIntent11);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        FitJumpImpl.getInstance().trainerJumpWebView(this.mContext, Constant.STR_1, VersionUpdateCheck.WEB_ADDRESS + "question");
        break;
        CompDeviceInfoUtils.applyPermission(new CompDeviceInfoUtils.applyPerListener()
        {
          public void result(boolean paramBoolean)
          {
            if (paramBoolean)
            {
              XUtilDB.getInstance();
              UserModel localUserModel = BaseApplication.userModel;
              Intent localIntent = new Intent(MineTabView.this.mContext, Mine02WeightActivity.class);
              if (StringUtils.isNull(localUserModel.initialWeight))
                localIntent.setClass(MineTabView.this.mContext, PerfectInfoFirstActivity.class);
              MineTabView.this.mContext.startActivity(localIntent);
              AnimationUtil.pageJumpAnim((Activity)MineTabView.this.mContext, 0);
            }
          }
        }
        , this.mContext, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
        break;
        paramView.setTag("p.c.c|!|m-idx|!|c.m-idx.e|!|");
        if ((this.signSearchReformer == null) || (StringUtils.isNull(this.signSearchReformer.duibaEnt.mallurl)))
          break;
        Intent localIntent10 = new Intent(this.mContext, Mine03WebUrlActivity.class);
        localIntent10.putExtra("webUrl", this.signSearchReformer.duibaEnt.mallurl);
        this.mContext.startActivity(localIntent10);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        Intent localIntent9 = new Intent(this.mContext, BrowseMyLikeActivity.class);
        this.mContext.startActivity(localIntent9);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        Intent localIntent8 = new Intent(this.mContext, MineOrderActivity.class);
        this.mContext.startActivity(localIntent8);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        Intent localIntent7 = new Intent(this.mContext, MineFCurrencyActivity.class);
        this.mContext.startActivity(localIntent7);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        translateAnimation();
        SharePreferenceUtils.putIsClickUnbindCloseBtn(this.mContext, BaseApplication.userModel.userId, Constant.STR_0);
        break;
        SharePreferenceUtils.putIsClickUnbindCloseBtn(this.mContext, BaseApplication.userModel.userId, Constant.STR_0);
        this.mContext.startActivity(new Intent(this.mContext, Mine03AccountActivity.class));
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        this.mContext.startActivity(new Intent(this.mContext, TestFunctionActivity.class));
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        Intent localIntent6 = new Intent(this.mContext, MasterCourseActivity.class);
        AppSharePreferenceUtils.putMasterClass(this.mContext, BaseApplication.userModel.lessonNum);
        this.mContext.startActivity(localIntent6);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        this.master_class_status.setVisibility(4);
        break;
        this.mContext.startActivity(new Intent(this.mContext, MineCouponActivity.class));
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        AppSharePreferenceUtils.putCouponId(this.mContext, this.mineReformer.messageModel.couponId);
        break;
        this.mContext.startActivity(new Intent(this.mContext, Mine03PersonalActivity.class));
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
        SharePreferenceUtils.putBuyVipFromPage("0");
        this.mContext.startActivity(new Intent(this.mContext, VipCenterActivity.class));
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
      }
      while (StringUtils.isNull(BaseApplication.userModel.inviteLink));
      if (BaseApplication.userModel.inviteLink.contains("http"));
      for (String str = BaseApplication.userModel.inviteLink; ; str = "http://" + BaseApplication.userModel.inviteLink)
      {
        Intent localIntent5 = new Intent(this.mContext, Mine03WebUrlActivity.class);
        localIntent5.putExtra("webUrl", str);
        this.mContext.startActivity(localIntent5);
        AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
        break;
      }
      SharePreferenceUtils.putPhyFromPage("1");
      this.mContext.startActivity(new Intent(this.mContext, FitnessTestPreviewActivity.class));
      AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
      continue;
      Intent localIntent4 = new Intent(this.mContext, EnergyInvitCodeActivity.class);
      localIntent4.putExtra("from.type", "2");
      this.mContext.startActivity(localIntent4);
      AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
      continue;
      Intent localIntent3 = new Intent(this.mContext, Mine03WebUrlActivity.class);
      localIntent3.putExtra("webUrl", VersionUpdateCheck.WEB_ADDRESS + "h5/dabiao");
      this.mContext.startActivity(localIntent3);
      AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
      continue;
      Intent localIntent2 = new Intent(this.mContext, Mine03FeedbackActivity.class);
      this.mContext.startActivity(localIntent2);
      AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
      continue;
      if ((this.signSearchReformer == null) || (StringUtils.isNull(this.signSearchReformer.duibaEnt.autourl)))
        continue;
      Intent localIntent1 = new Intent(this.mContext, Mine03WebUrlActivity.class);
      localIntent1.putExtra("webUrl", this.signSearchReformer.duibaEnt.autourl);
      this.mContext.startActivity(localIntent1);
      AnimationUtil.pageJumpAnim((Activity)this.mContext, 0);
    }
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof SignSearchReformer))
    {
      this.signSearchReformer = ((SignSearchReformer)paramT);
      if ((this.signSearchReformer.duibaEnt == null) || (StringUtils.isNull(this.signSearchReformer.duibaEnt.autourl)))
        break label215;
      BaseApplication.duibaSignUrl = this.signSearchReformer.duibaEnt.autourl;
      this.sign_btn.setVisibility(0);
      if ("true".equals(this.signSearchReformer.duibaEnt.todaySigned))
      {
        this.sign_btn.setText(String.valueOf("今日已签到"));
        this.sign_btn.getHelper().setIconNormal(this.mContext.getResources().getDrawable(2130903364));
      }
    }
    else
    {
      return;
    }
    if (!StringUtils.isNull(this.signSearchReformer.duibaEnt.credits))
    {
      this.sign_btn.setText(String.valueOf("签到领" + this.signSearchReformer.duibaEnt.credits + "能量"));
      this.sign_btn.getHelper().setIconNormal(this.mContext.getResources().getDrawable(2130903606));
      return;
    }
    this.sign_btn.setVisibility(8);
    return;
    label215: this.sign_btn.setVisibility(8);
  }

  public boolean isNoticeNumVisibility()
  {
    return (this.mineFragmentNoticeNum != null) && (this.mineFragmentNoticeNum.getVisibility() == 0);
  }

  public View onCreateView()
  {
    View localView1 = LayoutInflater.from(this.mContext).inflate(2130969016, null);
    this.mineTabLayout = ((RelativeLayout)localView1.findViewById(2131756909));
    this.mine_tab_title = ((FrameLayout)localView1.findViewById(2131756911));
    this.mine_title_split_line = localView1.findViewById(2131756917);
    this.mine_fragment_notice = ((ImageView)localView1.findViewById(2131756912));
    this.mine_fragment_notice.setOnClickListener(new FitAction(this));
    this.mineFragmentNoticeNum = ((RTextView)localView1.findViewById(2131756913));
    this.mine_fragment_setting_point = ((RTextView)localView1.findViewById(2131756916));
    this.mine_fragment_setting = ((ImageView)localView1.findViewById(2131756915));
    this.mine_fragment_setting.setOnClickListener(new FitAction(this));
    this.user_icon = ((FitVipUserView)localView1.findViewById(2131756179));
    this.user_icon.setIsVip(0);
    this.mineFragmentName = ((TextView)localView1.findViewById(2131756922));
    this.mine_fragment_weight_records_l = ((RelativeLayout)localView1.findViewById(2131756933));
    this.mine_fragment_weight_num = ((TextView)localView1.findViewById(2131756936));
    this.mine_fragment_photo_album_l = ((RelativeLayout)localView1.findViewById(2131756937));
    this.mine_photo_album_num = ((TextView)localView1.findViewById(2131756940));
    this.mineFragmentPersonalTraining = ((RelativeLayout)localView1.findViewById(2131756954));
    this.mineFragmentPersonalTraining.setOnClickListener(new FitAction(this));
    this.mine_fragment_photo_album_l.setOnClickListener(new FitAction(this));
    this.mineFragmentRecordsNum = ((TextView)localView1.findViewById(2131756931));
    this.mineFragmentTrainingRecordsL = ((RelativeLayout)localView1.findViewById(2131756928));
    this.mine_fragment_no_punch_hint = ((RView)localView1.findViewById(2131756932));
    RelativeLayout localRelativeLayout1 = (RelativeLayout)localView1.findViewById(2131756949);
    this.mine_energy_value = ((TextView)localView1.findViewById(2131755949));
    RelativeLayout localRelativeLayout2 = (RelativeLayout)localView1.findViewById(2131756952);
    RelativeLayout localRelativeLayout3 = (RelativeLayout)localView1.findViewById(2131756969);
    this.mine_order_hint = ((RTextView)localView1.findViewById(2131756972));
    RelativeLayout localRelativeLayout4 = (RelativeLayout)localView1.findViewById(2131756960);
    this.master_class_status = ((RView)localView1.findViewById(2131756963));
    this.master_class_records_num = ((TextView)localView1.findViewById(2131756964));
    RelativeLayout localRelativeLayout5 = (RelativeLayout)localView1.findViewById(2131756965);
    this.coupon_icon_hint = ((RView)localView1.findViewById(2131756967));
    this.coupon_icon_records_num = ((TextView)localView1.findViewById(2131756968));
    this.unBindIphoneLayout = ((RelativeLayout)localView1.findViewById(2131756918));
    this.mine_scrollview = ((CustomScrollView)localView1.findViewById(2131756910));
    this.unbind_close_img = ((RelativeLayout)localView1.findViewById(2131756920));
    this.title_userName = ((TextView)localView1.findViewById(2131756914));
    this.unbind_hint = ((TextView)localView1.findViewById(2131756919));
    this.user_info_layout = ((FrameLayout)localView1.findViewById(2131755236));
    this.user_icon.setOnClickListener(new FitAction(this));
    ((RelativeLayout)localView1.findViewById(2131757844)).setOnClickListener(new FitAction(this));
    ((RelativeLayout)localView1.findViewById(2131757847)).setOnClickListener(new FitAction(this));
    this.mineFragmentTrainingRecordsL.setOnClickListener(new FitAction(this));
    this.mine_fragment_weight_records_l.setOnClickListener(new FitAction(this));
    localRelativeLayout1.setOnClickListener(new FitAction(this));
    localRelativeLayout2.setOnClickListener(new FitAction(this));
    this.unbind_hint.setOnClickListener(new FitAction(this));
    localRelativeLayout3.setOnClickListener(new FitAction(this));
    localRelativeLayout4.setOnClickListener(new FitAction(this));
    localRelativeLayout5.setOnClickListener(new FitAction(this));
    ((RelativeLayout)localView1.findViewById(2131756973)).setOnClickListener(new FitAction(this));
    this.F_coin_records_num = ((TextView)localView1.findViewById(2131756977));
    this.mine_F_coin_hint = ((RView)localView1.findViewById(2131756976));
    localView1.findViewById(2131756955).setOnClickListener(new FitAction(this));
    this.vip_icon = ((ImageView)localView1.findViewById(2131757835));
    this.vip_icon.setImageResource(2130903721);
    this.vip_tv = ((TextView)localView1.findViewById(2131757845));
    this.vip_status_tv = ((TextView)localView1.findViewById(2131757846));
    this.money_icon = ((ImageView)localView1.findViewById(2131757848));
    this.money_icon.setImageResource(0);
    this.invite_tv = ((TextView)localView1.findViewById(2131757849));
    this.invite_tv.setText("");
    this.invite_status = ((TextView)localView1.findViewById(2131757850));
    this.can_draw_tv = ((TextView)localView1.findViewById(2131757851));
    ((RelativeLayout)localView1.findViewById(2131756956)).setOnClickListener(new FitAction(this));
    this.mine_vip_schedule_layout = ((RelativeLayout)localView1.findViewById(2131756945));
    this.mine_vip_schedule_num = ((TextView)localView1.findViewById(2131756947));
    ((RelativeLayout)localView1.findViewById(2131756941)).setOnClickListener(new FitAction(this));
    this.fitness_level = ((TextView)localView1.findViewById(2131756944));
    this.mine_level = ((RTextView)localView1.findViewById(2131756620));
    this.mine_level.setOnClickListener(new FitAction(this));
    this.mine_level_img = ((ImageView)localView1.findViewById(2131756926));
    this.mine_level_img.setOnClickListener(new FitAction(this));
    this.sign_btn = ((RTextView)localView1.findViewById(2131756925));
    this.sign_btn.setOnClickListener(new FitAction(this));
    this.sign_btn.setVisibility(8);
    this.mine_medal = ((RTextView)localView1.findViewById(2131756927));
    this.mine_medal.setOnClickListener(new FitAction(this));
    this.unBindIphoneLayout.setOnClickListener(new FitAction(this));
    this.unbind_close_img.setOnClickListener(new FitAction(this));
    this.mine_scrollview.setScrollViewListener(new CustomScrollView.ScrollViewListener()
    {
      public void onScrollChanged(CustomScrollView paramCustomScrollView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
      {
        if (paramInt2 > 0)
          if (MineTabView.this.mine_tab_title.getTag() == null)
          {
            MineTabView.this.mine_tab_title.setTag("mine");
            MineTabView.this.mine_tab_title.setBackgroundResource(2131624328);
            if (Build.VERSION.SDK_INT >= 21)
            {
              MineTabView.this.mine_tab_title.setElevation(CompDeviceInfoUtils.convertOfDip(MineTabView.this.getContext(), 3.0F));
              MineTabView.this.mine_title_split_line.setVisibility(8);
              MineTabView.this.title_userName.setText("我的");
              MineTabView.this.mine_fragment_notice.setImageResource(2130903142);
              MineTabView.this.mine_fragment_setting.setImageResource(2130903169);
            }
          }
          else
          {
            if (Math.abs(paramInt2) / 150.0F < 1.0F)
              break label159;
            MineTabView.this.mine_tab_title.setAlpha(1.0F);
          }
        label159: 
        do
        {
          return;
          MineTabView.this.mine_title_split_line.setVisibility(0);
          break;
          MineTabView.this.mine_tab_title.setAlpha(Math.abs(paramInt2) / 150.0F);
          return;
        }
        while (MineTabView.this.mine_tab_title.getTag() == null);
        MineTabView.this.mine_tab_title.setTag(null);
        MineTabView.this.mine_tab_title.setBackgroundResource(0);
        if (Build.VERSION.SDK_INT >= 21)
        {
          MineTabView.this.mine_tab_title.setElevation(0.0F);
          MineTabView.this.mine_title_split_line.setVisibility(8);
        }
        while (true)
        {
          MineTabView.this.title_userName.setText("");
          MineTabView.this.mine_fragment_notice.setImageResource(2130903143);
          MineTabView.this.mine_fragment_setting.setImageResource(2130903170);
          MineTabView.this.mine_tab_title.setAlpha(1.0F);
          return;
          MineTabView.this.mine_title_split_line.setVisibility(8);
        }
      }
    });
    View localView2;
    if ((StringUtils.isNull(BaseApplication.userModel.phoneNumber)) && (!"0".equals(SharePreferenceUtils.getIsClickUnbindCloseBtn(this.mContext, BaseApplication.userModel.userId))))
    {
      this.unBindIphoneLayout.setVisibility(0);
      if (SettingSharePreferenceUtils.getAccountBindPoint())
        SettingSharePreferenceUtils.putAccountBindPoint(StringUtils.isNull(BaseApplication.userModel.password));
      localView2 = localView1.findViewById(2131756958);
      if (!VersionUpdateCheck.changeTestPathFlg)
        break label1326;
    }
    label1326: for (int i = 0; ; i = 8)
    {
      localView2.setVisibility(i);
      localView1.findViewById(2131756958).setOnClickListener(new FitAction(this));
      TextView localTextView = (TextView)localView1.findViewById(2131756959);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = BaseApplication.userModel.userId;
      localTextView.setText(String.format("测试功能入口 (用户ID:%s)", arrayOfObject));
      localView1.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
      return localView1;
      this.unBindIphoneLayout.setVisibility(8);
      break;
    }
  }

  public void reSetMineOrderUnreadCount(int paramInt)
  {
    int j;
    if (this.mine_order_hint != null)
    {
      MineReformer localMineReformer = this.mineReformer;
      int i = 0;
      if (localMineReformer != null)
      {
        MessageModel localMessageModel = this.mineReformer.messageModel;
        i = 0;
        if (localMessageModel != null)
          i = StringUtils.string2Int(this.mineReformer.messageModel.orderNum);
      }
      j = i + paramInt;
      if (j <= 99)
        break label101;
      this.mine_order_hint.setText(String.valueOf("99+"));
      this.mine_order_hint.setVisibility(0);
    }
    while (true)
    {
      if (this.mine_F_coin_hint != null)
      {
        if (paramInt <= 0)
          break;
        this.mine_F_coin_hint.setVisibility(0);
      }
      return;
      label101: if (j > 0)
      {
        this.mine_order_hint.setText(String.valueOf(j));
        this.mine_order_hint.setVisibility(0);
        continue;
      }
      this.mine_order_hint.setVisibility(4);
    }
    this.mine_F_coin_hint.setVisibility(4);
  }

  public void refreshLayout()
  {
    if (this.mineTabLayout == null)
      addView(onCreateView());
    boolean bool2;
    if ("login".equals(SharePreferenceUtils.getLoginStatus(this.mContext)))
    {
      this.mineTabLayout.setVisibility(0);
      this.mine_tab_title.setVisibility(0);
      if ((FitApplication.userModel != null) && (!StringUtils.isNull(this.mineFragmentName.getText().toString())))
        break label155;
      bool2 = true;
      FitApplication.isRefresh = bool2;
      MiddleManager.getInstance().getMinePresenterImpl(this).getUserInfo(this.mContext);
      if ((this.unBindIphoneLayout.getVisibility() == 0) && ("0".equals(SharePreferenceUtils.getIsClickUnbindCloseBtn(this.mContext, BaseApplication.userModel.userId))))
        translateAnimation();
    }
    trainRecordNoPunchHint();
    RTextView localRTextView = this.mine_fragment_setting_point;
    boolean bool1 = SettingSharePreferenceUtils.getAccountBindPoint();
    int i = 0;
    if (bool1);
    while (true)
    {
      localRTextView.setVisibility(i);
      return;
      label155: bool2 = false;
      break;
      i = 8;
    }
  }

  public void refreshMineData()
  {
    if (this.mineTabLayout == null)
      addView(onCreateView());
    setUserInfo();
  }

  public <T> void setSpotsState(T paramT)
  {
    this.mineReformer = ((MineReformer)paramT);
    if (this.mineTabLayout == null)
      return;
    label84: String str1;
    switch (CheckRedPointUtils.isNotice(this.mineReformer))
    {
    default:
      switch (CheckRedPointUtils.isOrder(this.mineReformer, 0))
      {
      default:
        str1 = AppSharePreferenceUtils.getCouponId(this.mContext);
        if ((!StringUtils.isNull(this.mineReformer.messageModel.couponId)) && (StringUtils.isNull(str1)))
        {
          this.coupon_icon_hint.setVisibility(0);
          label123: String str2 = AppSharePreferenceUtils.getMasterClass(this.mContext);
          if ((StringUtils.string2Int(BaseApplication.userModel.lessonNum) <= 0) || (str2.equals(BaseApplication.userModel.lessonNum)))
            break label377;
          this.master_class_status.setVisibility(0);
        }
      case 0:
      case 1:
      case 2:
      }
    case 0:
    case 1:
    case 2:
    }
    while (true)
    {
      if (CheckRedPointUtils.isOrder(this.mineReformer, 1) != 0)
        break label388;
      this.mine_F_coin_hint.setVisibility(4);
      return;
      this.mineFragmentNoticeNum.setVisibility(4);
      break;
      this.mineFragmentNoticeNum.setText(getNoticeStr(this.mineReformer));
      this.mineFragmentNoticeNum.setVisibility(0);
      break;
      this.mineFragmentNoticeNum.setText(String.valueOf("99+"));
      this.mineFragmentNoticeNum.setVisibility(0);
      break;
      this.mine_order_hint.setVisibility(4);
      break label84;
      int i = StringUtils.string2Int(this.mineReformer.messageModel.orderNum) + Unicorn.getUnreadCount();
      this.mine_order_hint.setText(String.valueOf(i));
      this.mine_order_hint.setVisibility(0);
      break label84;
      this.mine_order_hint.setText(String.valueOf("99+"));
      this.mine_order_hint.setVisibility(0);
      break label84;
      if ((!StringUtils.isNull(this.mineReformer.messageModel.couponId)) && (!this.mineReformer.messageModel.couponId.equals(str1)))
      {
        this.coupon_icon_hint.setVisibility(0);
        break label123;
      }
      this.coupon_icon_hint.setVisibility(4);
      break label123;
      label377: this.master_class_status.setVisibility(4);
    }
    label388: this.mine_F_coin_hint.setVisibility(0);
  }

  public void trainRecordNoPunchHint()
  {
    if (this.mine_fragment_no_punch_hint == null)
      return;
    if (CheckRedPointUtils.isTrainingRecords())
    {
      this.mine_fragment_no_punch_hint.setVisibility(0);
      return;
    }
    this.mine_fragment_no_punch_hint.setVisibility(4);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.MineTabView
 * JD-Core Version:    0.6.0
 */