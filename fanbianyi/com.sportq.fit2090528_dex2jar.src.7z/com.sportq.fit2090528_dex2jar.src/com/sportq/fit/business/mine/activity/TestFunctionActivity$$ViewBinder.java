package com.sportq.fit.business.mine.activity;

import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import butterknife.ButterKnife.Finder;
import butterknife.ButterKnife.ViewBinder;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;

public class TestFunctionActivity$$ViewBinder<T extends TestFunctionActivity>
  implements ButterKnife.ViewBinder<T>
{
  public void bind(ButterKnife.Finder paramFinder, T paramT, Object paramObject)
  {
    paramT.toolbar = ((CustomToolBar)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755432, "field 'toolbar'"), 2131755432, "field 'toolbar'"));
    paramT.quickFinishSwitchLayout = ((Switch)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757434, "field 'quickFinishSwitchLayout'"), 2131757434, "field 'quickFinishSwitchLayout'"));
    paramT.quickFinishSwitchText = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757433, "field 'quickFinishSwitchText'"), 2131757433, "field 'quickFinishSwitchText'"));
    paramT.cache_switch_item = ((Switch)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757436, "field 'cache_switch_item'"), 2131757436, "field 'cache_switch_item'"));
    paramT.cache_switch_hint = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757435, "field 'cache_switch_hint'"), 2131757435, "field 'cache_switch_hint'"));
    paramT.apiRadioGroup = ((RadioGroup)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757447, "field 'apiRadioGroup'"), 2131757447, "field 'apiRadioGroup'"));
    paramT.apiButton01 = ((RadioButton)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757448, "field 'apiButton01'"), 2131757448, "field 'apiButton01'"));
    paramT.apiButton02 = ((RadioButton)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757450, "field 'apiButton02'"), 2131757450, "field 'apiButton02'"));
    paramT.apiButton03 = ((RadioButton)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757451, "field 'apiButton03'"), 2131757451, "field 'apiButton03'"));
    paramT.apiButton04 = ((RadioButton)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757452, "field 'apiButton04'"), 2131757452, "field 'apiButton04'"));
    paramT.apiButton05 = ((RadioButton)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757453, "field 'apiButton05'"), 2131757453, "field 'apiButton05'"));
    paramT.apiButton07 = ((RadioButton)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757449, "field 'apiButton07'"), 2131757449, "field 'apiButton07'"));
    paramT.bdRadioGroup = ((RadioGroup)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757460, "field 'bdRadioGroup'"), 2131757460, "field 'bdRadioGroup'"));
    paramT.bdButton01 = ((RadioButton)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757461, "field 'bdButton01'"), 2131757461, "field 'bdButton01'"));
    paramT.bdButton02 = ((RadioButton)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757462, "field 'bdButton02'"), 2131757462, "field 'bdButton02'"));
    paramT.video_url_test_function = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757431, "field 'video_url_test_function'"), 2131757431, "field 'video_url_test_function'"));
    paramT.edit_text = ((EditText)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131755478, "field 'edit_text'"), 2131755478, "field 'edit_text'"));
    paramT.apiButton06 = ((RadioButton)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757454, "field 'apiButton06'"), 2131757454, "field 'apiButton06'"));
    paramT.change_channel_name = ((TextView)paramFinder.castView((View)paramFinder.findRequiredView(paramObject, 2131757432, "field 'change_channel_name'"), 2131757432, "field 'change_channel_name'"));
  }

  public void unbind(T paramT)
  {
    paramT.toolbar = null;
    paramT.quickFinishSwitchLayout = null;
    paramT.quickFinishSwitchText = null;
    paramT.cache_switch_item = null;
    paramT.cache_switch_hint = null;
    paramT.apiRadioGroup = null;
    paramT.apiButton01 = null;
    paramT.apiButton02 = null;
    paramT.apiButton03 = null;
    paramT.apiButton04 = null;
    paramT.apiButton05 = null;
    paramT.apiButton07 = null;
    paramT.bdRadioGroup = null;
    paramT.bdButton01 = null;
    paramT.bdButton02 = null;
    paramT.video_url_test_function = null;
    paramT.edit_text = null;
    paramT.apiButton06 = null;
    paramT.change_channel_name = null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.mine.activity.TestFunctionActivity..ViewBinder
 * JD-Core Version:    0.6.0
 */