package com.sportq.fit.business;

import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;

public class BaseNavView extends RelativeLayout
  implements FitInterfaceUtils.UIInitListener
{
  public BaseNavView(Context paramContext)
  {
    super(paramContext);
  }

  public BaseNavView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public void fitOnClick(View paramView)
  {
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
  }

  public void initLayout(Bundle paramBundle)
  {
  }

  public <T> void onRefresh(T paramT)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.BaseNavView
 * JD-Core Version:    0.6.0
 */