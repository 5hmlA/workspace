package com.sportq.fit.business;

import android.content.Context;
import android.support.multidex.MultiDex;
import android.util.Log;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.growingio.android.sdk.collection.Configuration;
import com.growingio.android.sdk.collection.GrowingIO;
import com.growingio.android.sdk.deeplink.DeeplinkCallback;
import com.kitnew.ble.QNApiManager;
import com.kitnew.ble.QNBleApi;
import com.kitnew.ble.QNResultCallback;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.train.TrainPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CustomerServiceUtils;
import com.sportq.fit.common.utils.HwIdUtils;
import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.manager.jump.FitJump;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.persenter.model.WebJumpModel;
import com.stub.StubApp;
import com.tencent.bugly.Bugly;
import com.tencent.bugly.beta.Beta;
import com.tencent.bugly.beta.tinker.TinkerManager;
import com.umeng.analytics.MobclickAgent;
import com.umeng.analytics.MobclickAgent.UMAnalyticsConfig;
import java.util.ArrayList;
import java.util.Map;
import me.weishu.reflection.Reflection;
import org.xutils.x.Ext;

public class FitApplication extends BaseApplication
{
  private void initUserInfo()
  {
    BaseApplication.userModel = new UserModel();
    String str = PreferencesTools.getValueToKey("tbl_usermodel", "usermodel");
    if (!StringUtils.isNull(str))
    {
      ResponseModel localResponseModel = (ResponseModel)new Gson().fromJson(str, ResponseModel.class);
      if ((localResponseModel != null) && (localResponseModel.mineinfo != null))
      {
        BaseApplication.qiniuToken = localResponseModel.mineinfo.qiniuToken;
        if (!StringUtils.isNull(localResponseModel.mineinfo.userId))
          BaseApplication.userModel = localResponseModel.mineinfo;
        if (!"0".equals(BaseApplication.userModel.loginTerrace))
          break label110;
        BaseApplication.userModel.uid = BaseApplication.userModel.weiboUid;
      }
    }
    label110: 
    do
    {
      return;
      if ("1".equals(BaseApplication.userModel.loginTerrace))
      {
        BaseApplication.userModel.uid = BaseApplication.userModel.qqUid;
        return;
      }
      if (!"7".equals(BaseApplication.userModel.loginTerrace))
        continue;
      BaseApplication.userModel.uid = BaseApplication.userModel.weixinUid;
      return;
    }
    while (!"11".equals(BaseApplication.userModel.loginTerrace));
    BaseApplication.userModel.uid = BaseApplication.userModel.huaweiUid;
  }

  private boolean isDevelopmentUser()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add("30461");
    return localArrayList.indexOf(BaseApplication.userModel.userId) >= 0;
  }

  public void attachBaseContext(Context paramContext)
  {
    super.attachBaseContext(paramContext);
    Reflection.unseal(paramContext);
    MultiDex.install(paramContext);
    Beta.installTinker();
  }

  public void onCreate()
  {
    try
    {
      appliContext = this;
      VersionUpdateCheck.BUGTAGS_ON = false;
      super.onCreate();
      thirdUserModel = new UserModel();
      initUserInfo();
      if (VersionUpdateCheck.BUGTAGS_ON)
        GrowingIO.startWithConfiguration(this, new Configuration().setDebugMode(true).setTestMode(true).setDeeplinkCallback(new DeeplinkCallback()
        {
          public void onReceive(Map<String, String> paramMap, int paramInt)
          {
            String str = (String)paramMap.get("jsonType");
            WebJumpModel localWebJumpModel = new WebJumpModel();
            localWebJumpModel.jsonType = str;
            if ("0".equals(str));
            for (localWebJumpModel.jumpJson = String.valueOf(paramMap); ; localWebJumpModel.jumpJson = ((String)paramMap.get("jumpJson")))
            {
              AppSharePreferenceUtils.putCustomH5JumpJson(new Gson().toJson(localWebJumpModel));
              return;
            }
          }
        }).trackAllFragments().setChannel(CompDeviceInfoUtils.getFitSource()));
      while (true)
      {
        HwIdUtils.init(this);
        MiddleManager.getInstance().getTrainPresenterImpl(null).getQuestionnaireInfo(null);
        MobclickAgent.setCatchUncaughtExceptions(false);
        MobclickAgent.startWithConfigure(new MobclickAgent.UMAnalyticsConfig(this, "5705d27f67e58e6167000f4e", CompDeviceInfoUtils.getFitSource()));
        CustomerServiceUtils.initService(appliContext);
        x.Ext.init(this);
        x.Ext.setDebug(false);
        QNApiManager.getApi(StubApp.getOrigApplicationContext(getApplicationContext())).initSDK("qudong2018012921", new QNResultCallback()
        {
          public void onCompete(int paramInt)
          {
            Log.i("hdr", "执行结果校验:" + paramInt);
          }
        });
        FitJumpImpl.init(new FitJump());
        Bugly.setAppChannel(TinkerManager.getApplication(), CompDeviceInfoUtils.getFitSource());
        Bugly.init(appliContext, "0382c29e19", false);
        if ((!"login".equals(SharePreferenceUtils.getLoginStatus(appliContext))) || (BaseApplication.userModel == null))
          break;
        Bugly.setUserId(appliContext, BaseApplication.userModel.userId);
        Bugly.setIsDevelopmentDevice(appliContext, isDevelopmentUser());
        return;
        GrowingIO.startWithConfiguration(this, new Configuration().setDeeplinkCallback(new DeeplinkCallback()
        {
          public void onReceive(Map<String, String> paramMap, int paramInt)
          {
            String str = (String)paramMap.get("jsonType");
            WebJumpModel localWebJumpModel = new WebJumpModel();
            localWebJumpModel.jsonType = str;
            if ("0".equals(str));
            for (localWebJumpModel.jumpJson = String.valueOf(paramMap); ; localWebJumpModel.jumpJson = ((String)paramMap.get("jumpJson")))
            {
              AppSharePreferenceUtils.putCustomH5JumpJson(new Gson().toJson(localWebJumpModel));
              return;
            }
          }
        }).trackAllFragments().setChannel(CompDeviceInfoUtils.getFitSource()));
      }
    }
    catch (Exception localException)
    {
    }
  }

  public void onLowMemory()
  {
    super.onLowMemory();
    Glide.get(this).clearMemory();
  }

  public void onTrimMemory(int paramInt)
  {
    super.onTrimMemory(paramInt);
    if (paramInt == 20)
      Glide.get(this).clearMemory();
    Glide.get(this).trimMemory(paramInt);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.FitApplication
 * JD-Core Version:    0.6.0
 */