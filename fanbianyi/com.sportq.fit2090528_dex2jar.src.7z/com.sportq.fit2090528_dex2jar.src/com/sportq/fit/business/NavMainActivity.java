package com.sportq.fit.business;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import butterknife.Bind;
import butterknife.ButterKnife;
import com.baidu.location.BDLocation;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.business.browse.BrowseTabView;
import com.sportq.fit.business.find.activity.FindTabView;
import com.sportq.fit.business.mine.activity.MineTabView;
import com.sportq.fit.business.mine.widget.NewCouponDialog;
import com.sportq.fit.business.mine.widget.NewbiesDialog;
import com.sportq.fit.business.train.activity.BindPhoneActivity;
import com.sportq.fit.business.train.activity.FitTabViewNew;
import com.sportq.fit.business.train.adapter.FitAdapterNew02;
import com.sportq.fit.business.train.widget.RecommendCourseDialog.RecommendClickListener;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.AppUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.CheckRedPointUtils;
import com.sportq.fit.common.event.CountDownFinishEvent;
import com.sportq.fit.common.event.CustomBannerJumpEvent;
import com.sportq.fit.common.event.CustomJumpEvent;
import com.sportq.fit.common.event.EnergyInvitSuccess;
import com.sportq.fit.common.event.EnergyUnlockSuccessEvent;
import com.sportq.fit.common.event.ExitAtVideo02Event;
import com.sportq.fit.common.event.MainToastEvent;
import com.sportq.fit.common.event.PushTokenEvent;
import com.sportq.fit.common.event.TrainFinishPageFinishBtnClickEvent;
import com.sportq.fit.common.event.TrainHeadAnimEvent;
import com.sportq.fit.common.event.UnReadNumEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.interfaces.presenter.train.TrainPresenterInterface;
import com.sportq.fit.common.model.GetBindScaleModel;
import com.sportq.fit.common.model.MessageModel;
import com.sportq.fit.common.model.NoticeModel;
import com.sportq.fit.common.model.NoticeWeekModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.VersionModel;
import com.sportq.fit.common.model.WelcomeModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.reformer.GetBindScaleReformer;
import com.sportq.fit.common.reformer.MineReformer;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.reformer.StoreCommentReformer;
import com.sportq.fit.common.reformer.VersionReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CustomerServiceUtils;
import com.sportq.fit.common.utils.CustomerServiceUtils.UnReadCountChangeListener;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.LocationHandler;
import com.sportq.fit.common.utils.LocationHandler.OnLocSuccessListener;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.TestUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.activity.VipCenterActivity;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.compdevicemanager.SharePreferenceUtils2;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UpgradeManager;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.UpdateDialog;
import com.sportq.fit.fitmoudle.dialogmanager.UpdateDialog.OnDownloadCallBack;
import com.sportq.fit.fitmoudle.event.GotoShopTabEvent;
import com.sportq.fit.fitmoudle.event.NoPuchEvent;
import com.sportq.fit.fitmoudle.event.PubAddWeightEvent;
import com.sportq.fit.fitmoudle.event.ReceiveMedalEvent;
import com.sportq.fit.fitmoudle.network.data.CoursePhotoData;
import com.sportq.fit.fitmoudle.network.presenter.impl.MedalPresenterImpl;
import com.sportq.fit.fitmoudle.widget.NoScrollViewPager;
import com.sportq.fit.fitmoudle.widget.ReminderDialog;
import com.sportq.fit.fitmoudle10.organize.activity.Mine03SetNoticeActivity;
import com.sportq.fit.fitmoudle10.organize.presenter.FitMoudle10ApiPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.commender.WeightCommender;
import com.sportq.fit.fitmoudle10.organize.presenter.model.WeightModel2;
import com.sportq.fit.fitmoudle10.organize.utils.BodyFastBindStoreUtils;
import com.sportq.fit.fitmoudle10.organize.utils.DateUtils10;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseEventEntity;
import com.sportq.fit.fitmoudle13.shop.presenter.ShopMainPresenter;
import com.sportq.fit.fitmoudle2.camera.activity.FitnessPicPubRelease;
import com.sportq.fit.fitmoudle2.camera.util.CameraSharePreference;
import com.sportq.fit.fitmoudle3.video.activity.Video01Activity;
import com.sportq.fit.fitmoudle3.video.activity.Video02FinishActivity;
import com.sportq.fit.fitmoudle3.video.utils.SharePreferenceUtils3;
import com.sportq.fit.fitmoudle7.customize.activity.CustomDetailActivity;
import com.sportq.fit.fitmoudle7.customize.activity.CustomStartActivity;
import com.sportq.fit.fitmoudle8.activity.Find02TrainCategoryActivity;
import com.sportq.fit.fitmoudle8.activity.Find03GenTrainListActivity;
import com.sportq.fit.fitmoudle8.activity.Find04GenTrainInfoActivity;
import com.sportq.fit.fitmoudle9.energy.activity.EnergyInvitCodeActivity;
import com.sportq.fit.fitmoudle9.energy.reformer.model.ExchangeModel;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer;
import com.sportq.fit.fitmoudle9.energy.widget.GetEnergyDialog;
import com.sportq.fit.manager.accountmanager.MedalManager;
import com.sportq.fit.manager.accountmanager.RecommendCourseManager;
import com.sportq.fit.manager.verupgrademanager.ForcedUpGradeDialog;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.api.APIManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior;
import com.sportq.fit.middlelib.statistics.GrowingIOVariables;
import com.sportq.fit.minepresenter.reformer.GetMessageNumberReformer;
import com.sportq.fit.persenter.model.WeChatH5Model;
import com.sportq.fit.push.CheckPushManager;
import com.sportq.fit.push.JumpManager;
import com.stub.StubApp;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import rx.Observable;
import rx.Subscriber;

public class NavMainActivity extends BaseActivity
  implements CustomerServiceUtils.UnReadCountChangeListener
{
  private BrowseTabView browseTabView;

  @Bind({2131757007})
  ImageView browse_icon;

  @Bind({2131757006})
  RelativeLayout browse_tab_layout;
  private boolean canReceiveMedal = false;
  private FindTabView findTabView;

  @Bind({2131757005})
  ImageView find_icon;

  @Bind({2131757004})
  RelativeLayout find_tab_layout;
  private FitTabViewNew fitTabViewNew;
  private MedalManager mMedalManager;
  private PlanRecommendReformer mPlanRecommendReformer;
  private Context medalContext = this;
  MineReformer mineReformer = null;
  private MineTabView mineTabView;

  @Bind({2131757008})
  ImageView mine_icon;

  @Bind({2131756909})
  RelativeLayout mine_tab_layout;
  private int msgCount;
  private boolean needShowContinueTrain = false;
  private RecommendCourseManager recommendCourseManager;
  private ReminderDialog reminderDialog;
  private boolean showDialog = false;

  @Bind({2131756929})
  ImageView train_icon;

  @Bind({2131757003})
  RelativeLayout train_tab_layout;

  @Bind({2131755321})
  public NoScrollViewPager view_pager;

  private void checkNewRegisterUsers()
  {
    if ("0".equals(BaseApplication.userModel.isFillInvite));
    do
      return;
    while (!inviteCodeFormatCheck(TextUtils.getClipboardValue()));
    new ReminderDialog(this).createDialog().setPopupTitleText(getText(2131297203)).setPopupMainTitleText(getText(2131297202)).setImageRes(2130903430).setButtonText(getText(2131297204)).setButtonLayoutOnClick(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        Intent localIntent = new Intent(NavMainActivity.this, EnergyInvitCodeActivity.class);
        localIntent.putExtra("from.type", "0");
        NavMainActivity.this.startActivity(localIntent);
        AnimationUtil.pageJumpAnim(NavMainActivity.this, 0);
      }
    }).setCloseLayoutOnClick(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        TextUtils.copyToClipboard("");
      }
    }).setOnDismissListener(new DialogInterface.OnDismissListener()
    {
      public void onDismiss(android.content.DialogInterface paramDialogInterface)
      {
      }
    });
  }

  private void checkTrainNeedGoOn()
  {
    this.needShowContinueTrain = SharePreferenceUtils2.getBeKilledAtTrain(this);
    PlanReformer localPlanReformer;
    if (this.needShowContinueTrain)
    {
      localPlanReformer = SharePreferenceUtils3.getPlanDataBeKilled(this);
      if (!"0".equals(localPlanReformer._individualInfo.energyFlag))
        break label45;
      isContinueToTrain();
    }
    while (true)
    {
      showFitDialog(2);
      return;
      label45: if (!CompDeviceInfoUtils.checkNetwork())
      {
        SharePreferenceUtils2.putBeKilledAtTrain(this, true);
        showFitDialog(2);
        return;
      }
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.planId = localPlanReformer._individualInfo.planId;
      localRequestModel.individualId = "";
      MiddleManager.getInstance().getFindPresenterImpl(this, null).startPlan(localRequestModel, this);
    }
  }

  private void checkUpdateUserInfo(MessageModel paramMessageModel)
  {
    if (paramMessageModel != null)
      if (paramMessageModel.isVip != null)
        break label53;
    label53: for (String str = ""; ; str = paramMessageModel.isVip)
    {
      paramMessageModel.isVip = str;
      if (!paramMessageModel.isVip.equals(BaseApplication.userModel.isVip))
      {
        FitApplication.isRefresh = true;
        MiddleManager.getInstance().getMinePresenterImpl(this).getUserInfo(this);
      }
      return;
    }
  }

  private void checkVersionUpdate()
  {
    APIManager.checkVersion(this).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        new UpgradeManager().delApk(NavMainActivity.this);
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        VersionReformer localVersionReformer = new VersionReformer();
        localVersionReformer.dataToVersionReformer(paramResponseModel);
        if (com.sportq.fit.common.utils.StringUtils.isNull(localVersionReformer._versionModel.title));
        String str1;
        do
        {
          return;
          str1 = SharePreferenceUtils.getUpdateTag(NavMainActivity.this);
        }
        while ("0".equals(str1));
        if ("1".equals(str1));
        try
        {
          File localFile = new File(VersionUpdateCheck.UPGRADE_APK_URL);
          if (localFile.exists())
            if (!localFile.delete())
              break label113;
          label113: for (String str2 = "刪除成功"; ; str2 = "刪除失敗")
          {
            Log.e("取消更新的場合：刪除本地apk", str2);
            UpdateDialog.versionUpdateLogic(new UpdateDialog.OnDownloadCallBack()
            {
              public void onCallback(int paramInt)
              {
                if (paramInt == 0)
                  UpdateDialog.showFreeFlowDialog(NavMainActivity.this);
                do
                  return;
                while (paramInt != 1);
                UpdateDialog.showFreeFlowDialog(NavMainActivity.this);
              }
            }
            , NavMainActivity.this, localVersionReformer._versionModel);
            return;
          }
        }
        catch (Exception localException)
        {
          while (true)
            localException.printStackTrace();
        }
      }
    });
  }

  private void getAdPopData()
  {
    WelcomeModel localWelcomeModel = MiddleManager.getInstance().getLoginPresenterImpl(this).getAdPopData(this);
    if (localWelcomeModel != null)
    {
      this.dialog.createAdPopDialog(new FitInterfaceUtils.DialogListener(localWelcomeModel)
      {
        public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
        {
          switch (paramInt)
          {
          default:
            return;
          case -1:
            AppUtils.navAdJump(NavMainActivity.this, this.val$welcomeModel);
            RegisterPresenterInterface localRegisterPresenterInterface2 = MiddleManager.getInstance().getRegisterPresenterImpl(NavMainActivity.this);
            String str4 = this.val$welcomeModel.adId;
            String str5 = this.val$welcomeModel.flg;
            if (com.sportq.fit.common.utils.StringUtils.isNull(this.val$welcomeModel.planId));
            for (String str6 = ""; ; str6 = this.val$welcomeModel.planId)
            {
              localRegisterPresenterInterface2.statsFitAdClick("1", str4, "2", str5, str6);
              return;
            }
          case -2:
            RegisterPresenterInterface localRegisterPresenterInterface1 = MiddleManager.getInstance().getRegisterPresenterImpl(NavMainActivity.this);
            String str1 = this.val$welcomeModel.adId;
            String str2 = this.val$welcomeModel.flg;
            if (com.sportq.fit.common.utils.StringUtils.isNull(this.val$welcomeModel.planId));
            for (String str3 = ""; ; str3 = this.val$welcomeModel.planId)
            {
              localRegisterPresenterInterface1.statsFitAdClick("0", str1, "2", str2, str3);
              return;
            }
          case -3:
          }
          NavMainActivity.access$602(NavMainActivity.this, true);
          NavMainActivity.this.showFitDialog(3);
          GrowingIOVariables localGrowingIOVariables = new GrowingIOVariables();
          localGrowingIOVariables.eventid = "ad_interstitial_click";
          localGrowingIOVariables.ad_id = this.val$welcomeModel.adId;
          GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
        }
      }
      , localWelcomeModel.useUrl, this);
      GrowingIOVariables localGrowingIOVariables = new GrowingIOVariables();
      localGrowingIOVariables.eventid = "ad_interstitial_show";
      localGrowingIOVariables.ad_id = localWelcomeModel.adId;
      GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
      return;
    }
    this.canReceiveMedal = true;
    showFitDialog(3);
  }

  private void getBodyFatDevice()
  {
    ArrayList localArrayList = BodyFastBindStoreUtils.getBodyFastDataList(this);
    if ((localArrayList == null) || (localArrayList.size() == 0))
      new FitMoudle10ApiPresenter(this).getBindScale(this);
  }

  private String getDefSportTime()
  {
    int i = com.sportq.fit.common.utils.StringUtils.getRandom(39600000, 46800000);
    return new SimpleDateFormat("HH:mm", new Locale("zh", "CN")).format(new Date(i));
  }

  private void getPhoneNumDeviceId()
  {
    String str = "";
    try
    {
      if (CompDeviceInfoUtils.checkPermission(this, "android.permission.READ_PHONE_STATE"))
        str = ((TelephonyManager)FitApplication.appliContext.getSystemService("phone")).getLine1Number();
      SharePreferenceUtils.putUserPhoneNumber(this, str);
      if (com.sportq.fit.common.utils.StringUtils.isNull(SharePreferenceUtils.getUserDeviceId(this)))
        SharePreferenceUtils.putUserDeviceId(this, CompDeviceInfoUtils.getDeviceId());
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void initViewPager()
  {
    this.train_tab_layout.setOnClickListener(new FitAction(this));
    this.find_tab_layout.setOnClickListener(new FitAction(this));
    this.browse_tab_layout.setOnClickListener(new FitAction(this));
    this.mine_tab_layout.setOnClickListener(new FitAction(this));
    ArrayList localArrayList = new ArrayList();
    this.fitTabViewNew = new FitTabViewNew(this, this.dialog);
    this.findTabView = new FindTabView(this);
    this.browseTabView = new BrowseTabView(this);
    this.mineTabView = new MineTabView(this);
    localArrayList.add(this.fitTabViewNew);
    localArrayList.add(this.findTabView);
    localArrayList.add(this.browseTabView);
    localArrayList.add(this.mineTabView);
    this.view_pager.setAdapter(new CustomViewPagerAdapter(localArrayList));
    this.view_pager.addOnPageChangeListener(new NavPageViewChangeListener(null));
    this.view_pager.setOffscreenPageLimit(3);
    String str = SharePreferenceUtils.getLoginStatus(this);
    NoScrollViewPager localNoScrollViewPager = this.view_pager;
    if (!"login".equals(str));
    for (int i = 1; ; i = 0)
    {
      localNoScrollViewPager.setCurrentItem(i);
      return;
    }
  }

  private boolean inviteCodeFormatCheck(String paramString)
  {
    if ((!com.sportq.fit.common.utils.StringUtils.isNull(paramString)) && (paramString.length() == 6))
    {
      int i = 0;
      int j = 0;
      int k = 0;
      int m = 0;
      if (m < paramString.length())
      {
        int n = paramString.charAt(m);
        if ((n >= 48) && (n <= 57))
          i++;
        while (true)
        {
          m++;
          break;
          if ((n >= 65) && (n <= 90))
          {
            j++;
            continue;
          }
          k++;
        }
      }
      return (i == 1) && (j == 5) && (k == 0);
    }
    return false;
  }

  private void isContinueToTrain()
  {
    Dialog localDialog = this.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener()
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        if (paramInt != -1)
        {
          paramDialogInterface.cancel();
          return;
        }
        Intent localIntent = new Intent(NavMainActivity.this, Video01Activity.class);
        localIntent.putExtra("is.be.killed.back", true);
        NavMainActivity.this.startActivity(localIntent);
        paramDialogInterface.cancel();
      }
    }
    , this, "", com.sportq.fit.common.utils.StringUtils.getStringResources(2131298552), com.sportq.fit.common.utils.StringUtils.getStringResources(2131298554), com.sportq.fit.common.utils.StringUtils.getStringResources(2131298553));
    localDialog.setCanceledOnTouchOutside(false);
    localDialog.setCancelable(false);
  }

  private void showNewestMedal(MainToastEvent paramMainToastEvent)
  {
    monitorenter;
    while (true)
    {
      try
      {
        if (paramMainToastEvent.index != 0)
          continue;
        if (this.mMedalManager == null)
          continue;
        this.mMedalManager.show();
        return;
        if (this.mPlanRecommendReformer == null)
          continue;
        if (com.sportq.fit.common.utils.StringUtils.isNull(this.mPlanRecommendReformer._isFirstTrain))
        {
          EventBus.getDefault().post("MedalManager.event.showTrainNotice");
          continue;
        }
      }
      finally
      {
        monitorexit;
      }
      if (com.sportq.fit.common.utils.StringUtils.isNull(this.mPlanRecommendReformer._planType))
      {
        EventBus.getDefault().post("MedalManager.event.showTrainNotice");
        continue;
      }
      if (2 == paramMainToastEvent.index)
      {
        if ((this.recommendCourseManager != null) && (this.recommendCourseManager._recomPlan != null))
        {
          setTabSelectorIcon(0);
          this.view_pager.setCurrentItem(0, false);
          this.recommendCourseManager.showRecommend();
          this.recommendCourseManager = null;
          continue;
        }
        showNewestMedal(new MainToastEvent(3));
        continue;
      }
      if (3 == paramMainToastEvent.index)
      {
        if ("show".equals(AppSharePreferenceUtils.getNewbiesDialogGuideTag(this)))
        {
          AppSharePreferenceUtils.putNewbiesDialogGuideTag(this, "have.been.show");
          new NewbiesDialog().showNewbiesDialog(this, new FitInterfaceUtils.DialogListener()
          {
            public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
            {
              switch (paramInt)
              {
              case -2:
              default:
              case -1:
              }
              while (true)
              {
                NavMainActivity.this.showNewestMedal(new MainToastEvent(4));
                return;
                NavMainActivity.this.fitTabViewNew.jumpNewbiesActivity();
              }
            }
          });
          continue;
        }
        showNewestMedal(new MainToastEvent(4));
        continue;
      }
      if ((4 != paramMainToastEvent.index) || ((!NavMainActivity.class.getSimpleName().equals(CompDeviceInfoUtils.getTopActivityName(this))) && ((this.medalContext instanceof NavMainActivity))))
        continue;
      onEventMainThread("MedalManager.event.showTrainNotice");
    }
  }

  private void showTrainNotice()
  {
    if ((MiddleManager.getInstance().getFindPresenterImpl(this, null).noticeToast(this)) && (SharePreferenceUtils.getIsTrained()) && (this.reminderDialog == null))
      this.reminderDialog = new ReminderDialog(this).createDialog().setImageRes(2130903468).setButtonText(getString(2131299132)).setPopupMainTitleText(getString(2131299567)).setPopupTitleText(getString(2131299568)).setCloseLayoutOnClick(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          super.onClick(paramView);
        }
      }).setButtonLayoutOnClick(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          Intent localIntent = new Intent(NavMainActivity.this, Mine03SetNoticeActivity.class);
          NavMainActivity.this.startActivity(localIntent);
          super.onClick(paramView);
        }
      }).setOnDismissListener(new DialogInterface.OnDismissListener()
      {
        public void onDismiss(android.content.DialogInterface paramDialogInterface)
        {
          MiddleManager.getInstance().getFindPresenterImpl(NavMainActivity.this, null).noticeToastClick(StubApp.getOrigApplicationContext(NavMainActivity.this.getApplicationContext()));
        }
      });
  }

  private void uploadPushTime()
  {
    String str1 = SharePreferenceUtils.getPushTimeStatus(this);
    String str2 = SharePreferenceUtils.getPushTimeLogin(this);
    if ((!com.sportq.fit.common.utils.StringUtils.isNull(str1)) || (com.sportq.fit.common.utils.StringUtils.isNull(str2)))
    {
      SharePreferenceUtils.putPushTimeLogin(this);
      SharePreferenceUtils.putPushTimeStatus(FitApplication.appliContext, "");
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.remindf = FitApplication.userModel.remindf;
      localRequestModel.remindTime = FitApplication.userModel.remindTime;
      localRequestModel.messageRemindFlag = BaseApplication.userModel.messageRemindFlag;
      localRequestModel.systemRemindFlag = BaseApplication.userModel.systemRemindFlag;
      localRequestModel.reminderFlag = BaseApplication.userModel.reminderFlag;
      localRequestModel.commentRemindFlag = BaseApplication.userModel.commentRemindFlag;
      localRequestModel.likeRemindFlag = BaseApplication.userModel.likeRemindFlag;
      MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(localRequestModel, this);
      ArrayList localArrayList1 = new ArrayList();
      NoticeModel localNoticeModel = new NoticeModel();
      localNoticeModel.noticeOnOff = "1";
      localNoticeModel.noticeTime = getDefSportTime();
      localNoticeModel.showListOff = "0";
      localNoticeModel.userId = FitApplication.userModel.userId;
      ArrayList localArrayList2 = new ArrayList();
      String[] arrayOfString = { "一", "二", "三", "四", "五", "六", "日" };
      for (int i = 0; i < 7; i++)
      {
        NoticeWeekModel localNoticeWeekModel = new NoticeWeekModel();
        localNoticeWeekModel.userId = FitApplication.userModel.userId;
        localNoticeWeekModel.showOnOff = "1";
        localNoticeWeekModel.day = arrayOfString[i];
        localArrayList2.add(localNoticeWeekModel);
      }
      localNoticeModel.weekList = localArrayList2;
      localArrayList1.add(localNoticeModel);
      MiddleManager.getInstance().getMinePresenterImpl(this).saveNoticeItemsInfo(this, localRequestModel, localArrayList1, "1");
    }
  }

  public void checkPublishDataHaveNoUpload()
  {
    if (!"login".equals(SharePreferenceUtils.getLoginStatus(this)))
      return;
    CoursePhotoData localCoursePhotoData = com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.getAlbumCoursePhotosData("-1", this);
    boolean bool1;
    String str1;
    label52: String str2;
    if ((localCoursePhotoData != null) && ("1".equals(localCoursePhotoData.strPubType)))
    {
      bool1 = true;
      if (!bool1)
        break label110;
      str1 = com.sportq.fit.common.utils.StringUtils.getStringResources(2131298650);
      if (!bool1)
        break label120;
      str2 = com.sportq.fit.common.utils.StringUtils.getStringResources(2131298651);
      label64: if (!bool1)
        break label131;
    }
    boolean bool2;
    label131: for (String str3 = com.sportq.fit.common.utils.StringUtils.getStringResources(2131298652); ; str3 = com.sportq.fit.common.utils.StringUtils.getStringResources(2131298551))
    {
      String str4 = CameraSharePreference.getPublishStatusTag(this);
      bool2 = SharePreferenceUtils2.getExitAtVideo02FinishActivity();
      if (!bool1)
        break label142;
      if (!com.sportq.fit.common.utils.StringUtils.isNull(str4))
        break label153;
      showFitDialog(1);
      return;
      bool1 = false;
      break;
      label110: str1 = com.sportq.fit.common.utils.StringUtils.getStringResources(2131298549);
      break label52;
      label120: str2 = com.sportq.fit.common.utils.StringUtils.getStringResources(2131299534);
      break label64;
    }
    label142: if (!bool2)
    {
      showFitDialog(1);
      return;
    }
    label153: Dialog localDialog = this.dialog.createChoiceDialog(new FitInterfaceUtils.DialogListener(bool1, localCoursePhotoData)
    {
      public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
      {
        NavMainActivity.this.showFitDialog(1);
        if (paramInt != -1)
        {
          SharePreferenceUtils2.putExitAtVideo02FinishActivity(false);
          CameraSharePreference.putPublishStatusTag(NavMainActivity.this, "");
        }
        PlanReformer localPlanReformer;
        while (true)
        {
          return;
          if (this.val$typeFlg)
          {
            Intent localIntent1 = new Intent(NavMainActivity.this, FitnessPicPubRelease.class);
            localIntent1.putExtra("jump.flg", "nav.main.jump");
            localIntent1.putExtra("course.info", this.val$photoData);
            localIntent1.putExtra("wmfilter.olapinfo", this.val$photoData.wmfOlapinfo);
            localIntent1.putExtra("poster.olapinfo", this.val$photoData.posterOlapinfo);
            FitnessPicPubRelease.strImageType = this.val$photoData.strImageType;
            FitnessPicPubRelease.strImgPath = this.val$photoData.strImgPath;
            localIntent1.putExtra("comment", this.val$photoData.feeling);
            localIntent1.putExtra("cur.weight", this.val$photoData.currentWeight);
            FitnessPicPubRelease.bodyDirection = this.val$photoData.bodyDirection;
            FitnessPicPubRelease.strPubType = this.val$photoData.strPubType;
            NavMainActivity.this.startActivity(localIntent1);
            AnimationUtil.pageJumpAnim(NavMainActivity.this, 0);
            paramDialogInterface.cancel();
            return;
          }
          localPlanReformer = SharePreferenceUtils2.getNewLocalTrainDataPlanReformer();
          if (localPlanReformer != null)
            break;
          SharePreferenceUtils2.putExitAtVideo02FinishActivity(false);
          CameraSharePreference.putPublishStatusTag(NavMainActivity.this, "");
          if (this.val$photoData == null)
            continue;
          com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.delAlbumCoursePhotoData(this.val$photoData.strMoveTime, NavMainActivity.this);
          return;
        }
        Intent localIntent2 = new Intent(NavMainActivity.this, Video02FinishActivity.class);
        localIntent2.putExtra("intent.planReformer", localPlanReformer);
        localIntent2.putExtra("intent.from", 1);
        localIntent2.putExtra("intent.isOverOneThirdOfTime", true);
        NavMainActivity.this.startActivity(localIntent2);
        AnimationUtil.pageJumpAnim(NavMainActivity.this, 0);
      }
    }
    , this, "", str1, str3, str2);
    localDialog.setCanceledOnTouchOutside(false);
    localDialog.setCancelable(false);
  }

  public void fitOnClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
      return;
    case 2131757003:
      this.view_pager.setCurrentItem(0, false);
      return;
    case 2131757004:
      this.view_pager.setCurrentItem(1, false);
      return;
    case 2131757006:
      this.view_pager.setCurrentItem(2, false);
      return;
    case 2131756909:
    }
    this.view_pager.setCurrentItem(3, false);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof GetBindScaleReformer))
    {
      GetBindScaleReformer localGetBindScaleReformer = (GetBindScaleReformer)paramT;
      if ((localGetBindScaleReformer.lstScaleDevice != null) && (localGetBindScaleReformer.lstScaleDevice.size() > 0))
      {
        Iterator localIterator = localGetBindScaleReformer.lstScaleDevice.iterator();
        while (localIterator.hasNext())
        {
          GetBindScaleModel localGetBindScaleModel = (GetBindScaleModel)localIterator.next();
          BodyFastBindStoreUtils.appendCourseData(localGetBindScaleModel.scaleName + "±" + localGetBindScaleModel.scaleDeviceId + "±" + "null", localGetBindScaleModel.scaleName, this);
        }
      }
    }
    if (((paramT instanceof StoreCommentReformer)) && ("Y".equals(((StoreCommentReformer)paramT).result)))
    {
      this.mineTabView.refreshLayout();
      new ReminderDialog(this).createDialog().setPopupMainTitleText("获得3天VIP会员").setPopupTitleText("感谢对Fit的鼓励，已获得3天VIP会员").setImageRes(2130903486).setButtonText("去看看").setButtonLayoutOnClick(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          SharePreferenceUtils.putBuyVipFromPage("13");
          NavMainActivity.this.startActivity(new Intent(NavMainActivity.this, VipCenterActivity.class));
          AnimationUtil.pageJumpAnim(NavMainActivity.this, 0);
        }
      });
    }
    PlanReformer localPlanReformer;
    if ((paramT instanceof PlanReformer))
    {
      localPlanReformer = (PlanReformer)paramT;
      if ("2".equals(localPlanReformer.tag))
        if ((!"MESSAGE_2".equals(localPlanReformer.message)) && (this.needShowContinueTrain))
          isContinueToTrain();
    }
    do
      while (true)
      {
        return;
        while (true)
        {
          try
          {
            if ((localPlanReformer._individualInfo != null) && (localPlanReformer._individualInfo.stageArray.size() > 0))
            {
              localIntent = new Intent(this, Find04GenTrainInfoActivity.class);
              Bundle localBundle = new Bundle();
              localBundle.putSerializable("message.model", null);
              localIntent.putExtras(localBundle);
              localIntent.putExtra("click.flg", "click");
              localIntent.putExtra("plan.id", "");
              startActivity(localIntent);
              return;
            }
          }
          catch (Exception localException)
          {
            LogUtils.e(localException);
            return;
          }
          Intent localIntent = new Intent(this, Find03GenTrainListActivity.class);
        }
        if (!(paramT instanceof BaseReformer))
          break;
        if ((paramT instanceof GetMessageNumberReformer))
        {
          this.mineReformer = new MineReformer();
          this.mineReformer.messageModel = ((GetMessageNumberReformer)paramT).messageModel;
          if (this.mineReformer.messageModel == null)
            continue;
          LogUtils.e("GetMessageNumberReformer：", "刷新界面");
          this.mineTabView.setSpotsState(this.mineReformer);
          setTabSelectorIcon(this.view_pager.getCurrentItem());
          this.findTabView.setMineReformer(this.mineReformer);
          if (!com.sportq.fit.common.utils.StringUtils.isNull(AppSharePreferenceUtils.getVersionCache(CompDeviceInfoUtils.getVersionCode())))
            ForcedUpGradeDialog.createDialog(this, this.mineReformer.messageModel.isForceUpdate);
          while (true)
          {
            checkUpdateUserInfo(this.mineReformer.messageModel);
            this.fitTabViewNew.setIsHasPhy(this.mineReformer.messageModel.isHasPhy);
            return;
            AppSharePreferenceUtils.putVersionCache(CompDeviceInfoUtils.getVersionCode(), "0");
          }
        }
        if (!PlanRecommendReformer.class.getName().equals(((BaseReformer)paramT).tag))
          continue;
        if ((paramT instanceof PlanRecommendReformer))
        {
          PlanRecommendReformer localPlanRecommendReformer = (PlanRecommendReformer)paramT;
          this.mPlanRecommendReformer = localPlanRecommendReformer;
          this.mMedalManager = new MedalManager(this.medalContext, localPlanRecommendReformer);
          this.recommendCourseManager = new RecommendCourseManager(new RecommendCourseDialog.RecommendClickListener()
          {
            public void clickAction(String paramString1, String paramString2)
            {
              MiddleManager.getInstance().getTrainPresenterImpl(NavMainActivity.this).recommendCourseAction(paramString1, paramString2);
            }
          }
          , this, localPlanRecommendReformer);
          showNewestMedal(new MainToastEvent(0));
          return;
        }
        showTrainNotice();
        return;
      }
    while (!(paramT instanceof MineReformer));
    this.mineReformer = ((MineReformer)paramT);
    this.mineTabView.setSpotsState(paramT);
    setTabSelectorIcon(this.view_pager.getCurrentItem());
    this.findTabView.setMineReformer((MineReformer)paramT);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(2130969029);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    SharePreferenceUtils.putLoginStatus(this, "login");
    checkNewRegisterUsers();
    CheckPushManager.register(this);
    initViewPager();
    checkVersionUpdate();
    getPhoneNumDeviceId();
    uploadPushTime();
    getBodyFatDevice();
    MiddleManager.getInstance().getLoginPresenterImpl(this).getWelcome(this);
    try
    {
      CustomerServiceUtils.initUserInfo();
      CustomerServiceUtils.addUnreadCountChangeListener(true, this);
      new ShopMainPresenter(this).getpublicInfo(this);
      return;
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
  }

  protected void onDestroy()
  {
    CustomerServiceUtils.addUnreadCountChangeListener(false, this);
    EventBus.getDefault().unregister(this);
    FileUtils.delAllFile(FileUtils.getDiskCacheDir("shareCache").getAbsolutePath());
    TestUtils.getInstance().clear();
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(CountDownFinishEvent paramCountDownFinishEvent)
  {
    if (this.fitTabViewNew != null)
      this.fitTabViewNew.countDownEndRefresh(paramCountDownFinishEvent);
  }

  @Subscribe
  public void onEventMainThread(CustomBannerJumpEvent paramCustomBannerJumpEvent)
  {
    if (com.sportq.fit.common.utils.StringUtils.isNull(paramCustomBannerJumpEvent.pageType))
      return;
    AppUtils.customBannerJump(paramCustomBannerJumpEvent.mContext, paramCustomBannerJumpEvent.pageType, paramCustomBannerJumpEvent.jumpId);
  }

  @Subscribe
  public void onEventMainThread(CustomJumpEvent paramCustomJumpEvent)
  {
    AppUtils.webJumpCheck(paramCustomJumpEvent.mContext, 1, this.view_pager);
  }

  @Subscribe
  public void onEventMainThread(EnergyInvitSuccess paramEnergyInvitSuccess)
  {
    if ((this.view_pager != null) && (this.view_pager.getCurrentItem() != 0))
    {
      setTabSelectorIcon(0);
      this.view_pager.setCurrentItem(0, false);
    }
    new Handler().postDelayed(new Runnable(paramEnergyInvitSuccess)
    {
      public void run()
      {
        GetEnergyDialog localGetEnergyDialog = new GetEnergyDialog(NavMainActivity.this);
        localGetEnergyDialog.createDialog(new FitInterfaceUtils.DialogListener()
        {
          public void onDialogClick(android.content.DialogInterface paramDialogInterface, int paramInt)
          {
            if (paramInt == -2)
            {
              Intent localIntent = new Intent(NavMainActivity.this, Find02TrainCategoryActivity.class);
              localIntent.putExtra("classify.type", "4");
              localIntent.putExtra("type.id", NavMainActivity.3.this.val$event.classifyId);
              NavMainActivity.this.startActivity(localIntent);
              AnimationUtil.pageJumpAnim(NavMainActivity.this, 0);
            }
          }
        }
        , 0);
        localGetEnergyDialog.setChangeEnergyValue(com.sportq.fit.common.utils.StringUtils.string2Int(this.val$event.energyValue));
      }
    }
    , 200L);
  }

  @Subscribe
  public void onEventMainThread(EnergyUnlockSuccessEvent paramEnergyUnlockSuccessEvent)
  {
    if (this.fitTabViewNew != null)
      this.fitTabViewNew.initUI();
  }

  @Subscribe
  public void onEventMainThread(ExitAtVideo02Event paramExitAtVideo02Event)
  {
    CheckRedPointUtils.reTrainingRecords();
  }

  @Subscribe
  public void onEventMainThread(MainToastEvent paramMainToastEvent)
  {
    showNewestMedal(paramMainToastEvent);
  }

  @Subscribe(threadMode=ThreadMode.MAIN)
  public void onEventMainThread(PushTokenEvent paramPushTokenEvent)
  {
    CheckPushManager.updatePushToken(paramPushTokenEvent.strType, paramPushTokenEvent.strToken);
  }

  @Subscribe
  public void onEventMainThread(TrainFinishPageFinishBtnClickEvent paramTrainFinishPageFinishBtnClickEvent)
  {
    setTabSelectorIcon(0);
    this.view_pager.setCurrentItem(0, false);
  }

  @Subscribe
  public void onEventMainThread(TrainHeadAnimEvent paramTrainHeadAnimEvent)
  {
    this.fitTabViewNew.closeHeader();
  }

  @Subscribe
  public void onEventMainThread(UnReadNumEvent paramUnReadNumEvent)
  {
    if (paramUnReadNumEvent != null)
      try
      {
        if (this.mineTabView == null)
          return;
        this.mineTabView.reSetMineOrderUnreadCount(paramUnReadNumEvent.unReadNum);
        return;
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
      }
  }

  @Subscribe
  public void onEventMainThread(GotoShopTabEvent paramGotoShopTabEvent)
  {
    if ((this.view_pager != null) && (this.view_pager.getCurrentItem() != 2))
      this.view_pager.setCurrentItem(2, false);
    if (this.browseTabView != null)
      this.browseTabView.jumpShopTab();
  }

  @Subscribe
  public void onEventMainThread(NoPuchEvent paramNoPuchEvent)
  {
    this.mineTabView.trainRecordNoPunchHint();
    this.fitTabViewNew.setUnreadPointState(CheckRedPointUtils.isTrainingRecords());
  }

  @Subscribe
  public void onEventMainThread(PubAddWeightEvent paramPubAddWeightEvent)
  {
    WeightModel2 localWeightModel2 = new WeightModel2();
    localWeightModel2.weight = String.valueOf(paramPubAddWeightEvent.addWeight);
    localWeightModel2.girthType = "0";
    try
    {
      if (com.sportq.fit.common.utils.StringUtils.isNull(paramPubAddWeightEvent.addTime));
      String str;
      for (Object localObject2 = DateUtils10.date2String(new Date()); ; localObject2 = str)
      {
        localWeightModel2.recordDate = ((String)localObject2);
        localWeightModel2.setDMY(localWeightModel2.recordDate);
        return;
        String[] arrayOfString = paramPubAddWeightEvent.addTime.split(" ")[0].split("-");
        str = arrayOfString[0] + "-" + arrayOfString[1] + "-" + arrayOfString[2];
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      localWeightModel2.recordDate = DateUtils10.date2String(new Date());
      localWeightModel2.setDMY(localWeightModel2.recordDate);
      return;
    }
    finally
    {
      WeightCommender.getInstance().addWeight(localWeightModel2);
      if (BaseApplication.userModel != null)
      {
        BaseApplication.userModel.currentWeight = localWeightModel2.weight;
        BaseApplication.userModel.currentWeightDate = String.valueOf(System.currentTimeMillis());
      }
      if (this.mineTabView != null)
        this.mineTabView.refreshMineData();
    }
    throw localObject1;
  }

  @Subscribe
  public void onEventMainThread(ReceiveMedalEvent paramReceiveMedalEvent)
  {
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.medalType = paramReceiveMedalEvent.medalType;
    if (paramReceiveMedalEvent.context == null);
    for (Object localObject = this; ; localObject = paramReceiveMedalEvent.context)
    {
      this.medalContext = ((Context)localObject);
      if (!com.sportq.fit.common.utils.StringUtils.isNull(paramReceiveMedalEvent.missionId))
        localRequestModel.missionId = paramReceiveMedalEvent.missionId;
      localRequestModel.strIsUseCache = "-1";
      new MedalPresenterImpl(this).getReceiveMedalsSuccess(this, localRequestModel);
      return;
    }
  }

  @Subscribe
  public void onEventMainThread(BrowseEventEntity paramBrowseEventEntity)
  {
    if (paramBrowseEventEntity == null);
    while (true)
    {
      return;
      try
      {
        if (this.browseTabView == null)
          continue;
        this.browseTabView.refreshIsLikeStatus(paramBrowseEventEntity);
        return;
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
      }
    }
  }

  @Subscribe
  public void onEventMainThread(EnergyReformer paramEnergyReformer)
  {
    if ((paramEnergyReformer == null) || (paramEnergyReformer.entMessage == null));
    do
      return;
    while ((!"MESSAGE_24".equals(paramEnergyReformer.entMessage.code)) && (!"MESSAGE_25".equals(paramEnergyReformer.entMessage.code)) && (!"MESSAGE_26".equals(paramEnergyReformer.entMessage.code)) && (!"MESSAGE_29".equals(paramEnergyReformer.entMessage.code)) && (!"MESSAGE_31".equals(paramEnergyReformer.entMessage.code)));
    new NewCouponDialog().exchangeDialog(this, 2130903329, paramEnergyReformer.entMessage);
  }

  @Subscribe
  public void onEventMainThread(WeChatH5Model paramWeChatH5Model)
  {
    AppUtils.checkWeChatH5Jump(this);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("fitness.custom".equals(paramString));
    try
    {
      Intent localIntent1;
      if (this.fitTabViewNew != null)
      {
        boolean bool = this.fitTabViewNew.fitAdapterNew.isCustomized();
        str1 = this.fitTabViewNew.fitAdapterNew.getHasCusFlag();
        str2 = this.fitTabViewNew.fitAdapterNew.getHasHistoryFlag();
        if (!bool)
          break label392;
        if ((!"1".equals(BaseApplication.userModel.isVip)) && (!"3".equals(BaseApplication.userModel.isVip)))
          break label346;
        localIntent1 = new Intent(this, CustomDetailActivity.class);
      }
      while (true)
      {
        startActivity(localIntent1);
        AnimationUtil.pageJumpAnim(this, 0);
        if ("上传历史数据".equals(paramString))
          onEventMainThread(new ReceiveMedalEvent("0"));
        if ("quick.login".equals(paramString))
          finish();
        if ("register.finish".equals(paramString))
          finish();
        if ("sign.out.account".equals(paramString))
          finish();
        if ("change.api".equals(paramString))
          finish();
        if (("refresh.mine.page.data".equals(paramString)) && (this.mineTabView != null) && (this.view_pager.getCurrentItem() == 3))
          this.mineTabView.refreshMineData();
        if (("close.page".equals(paramString)) && (this.fitTabViewNew != null) && (this.view_pager.getCurrentItem() != 0))
        {
          setTabSelectorIcon(0);
          this.view_pager.setCurrentItem(0, false);
        }
        if ("MedalManager.event.showTrainNotice".equals(paramString))
          showTrainNotice();
        if (paramString.equals("trainrecord_notrain_starttrain"))
        {
          setTabSelectorIcon(0);
          this.view_pager.setCurrentItem(0, false);
        }
        if (paramString.equals("pay.success.look.around"))
          EventBus.getDefault().post(new GotoShopTabEvent());
        if (!paramString.equals("show.medal.dialog"))
          break label483;
        if (!this.showDialog)
          break;
        return;
        label346: localIntent1 = new Intent(this, CustomStartActivity.class);
        localIntent1.putExtra("custom_hascusflag", str1);
        localIntent1.putExtra("custom_hasHistoryFlag", str2);
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        String str1;
        String str2;
        localException.printStackTrace();
        continue;
        label392: Intent localIntent2 = new Intent(this, CustomStartActivity.class);
        localIntent2.putExtra("custom_hascusflag", str1);
        localIntent2.putExtra("custom_hasHistoryFlag", str2);
        startActivity(localIntent2);
        AnimationUtil.pageJumpAnim(this, 0);
      }
      this.showDialog = true;
      if (!AppUtils.isNeedBindPhoneNum())
        break label594;
    }
    if (CompDeviceInfoUtils.checkPermission(this, "android.permission.ACCESS_COARSE_LOCATION"))
      new LocationHandler(this, null, null).gpsLocationStart(new LocationHandler.OnLocSuccessListener()
      {
        public void locSuccess(BDLocation paramBDLocation)
        {
          if (paramBDLocation.getLocationWhere() != 0)
          {
            NavMainActivity.this.startActivity(new Intent(NavMainActivity.this, BindPhoneActivity.class));
            AnimationUtil.pageJumpAnim(NavMainActivity.this, 0);
          }
        }
      });
    while (true)
    {
      label483: if (paramString.equals("close.bind.phone"))
        showFitDialog(0);
      if (paramString.equals("to.store.comment"))
      {
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.commentFlag = "0";
        MiddleManager.getInstance().getMinePresenterImpl(this).storeComment(this, localRequestModel);
      }
      if ((!"jump.mine.tab".equals(paramString)) || (this.view_pager.getCurrentItem() == 3))
        break;
      setTabSelectorIcon(3);
      this.view_pager.setCurrentItem(3);
      return;
      startActivity(new Intent(this, BindPhoneActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
      continue;
      label594: showFitDialog(0);
    }
  }

  @Subscribe
  public void onEventMainThread(Map<String, String> paramMap)
  {
    if ("updateMinePoint".equals(paramMap.get("key")))
    {
      this.msgCount = Integer.valueOf((String)paramMap.get("msgCount")).intValue();
      if (this.msgCount <= 0)
        break label88;
      if (this.view_pager.getCurrentItem() == 4)
        this.mine_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837712));
    }
    else
    {
      return;
    }
    this.mine_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837708));
    return;
    label88: if (this.view_pager.getCurrentItem() == 4)
    {
      this.mine_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837711));
      return;
    }
    this.mine_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837707));
  }

  @SuppressLint({"SimpleDateFormat"})
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
      try
      {
        String str = SharePreferenceUtils.getExitAppTime(this);
        if ((!"".equals(str)) && (str != null))
        {
          Date localDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(str);
          if (Math.abs(new Date().getTime() - localDate.getTime()) / 1000L < 2L)
          {
            moveTaskToBack(true);
            MiddleManager.closeInstance();
            return true;
          }
          SharePreferenceUtils.putExitAppTime(this, DateUtils.getStrCurrentTime());
          if ((this.view_pager != null) && (this.view_pager.getCurrentItem() != 0))
          {
            setTabSelectorIcon(0);
            this.view_pager.setCurrentItem(0, false);
          }
          ToastUtils.makeToast(this, "再按一次退出Fit");
        }
        else
        {
          SharePreferenceUtils.putExitAppTime(this, DateUtils.getStrCurrentTime());
          if ((this.view_pager != null) && (this.view_pager.getCurrentItem() != 0))
          {
            setTabSelectorIcon(0);
            this.view_pager.setCurrentItem(0, false);
          }
          ToastUtils.makeToast(this, "再按一次退出Fit");
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
      }
    return false;
  }

  @Instrumented
  protected void onNewIntent(Intent paramIntent)
  {
    VdsAgent.onNewIntent(this, paramIntent);
    super.onNewIntent(paramIntent);
    String str1;
    if (paramIntent != null)
    {
      str1 = paramIntent.getStringExtra("childIndex");
      if (!com.sportq.fit.common.utils.StringUtils.isNull(str1))
        break label30;
    }
    label30: String[] arrayOfString;
    do
    {
      return;
      arrayOfString = str1.split("\\.");
      String str2 = arrayOfString[0];
      int i = -1;
      switch (str2.hashCode())
      {
      default:
      case 48:
      case 49:
      case 50:
      case 51:
      }
      while (true)
        switch (i)
        {
        default:
          return;
        case 0:
          this.view_pager.setCurrentItem(0);
          return;
          if (!str2.equals("0"))
            continue;
          i = 0;
          continue;
          if (!str2.equals("1"))
            continue;
          i = 1;
          continue;
          if (!str2.equals("2"))
            continue;
          i = 2;
          continue;
          if (!str2.equals("3"))
            continue;
          i = 3;
        case 1:
        case 2:
        case 3:
        }
      this.view_pager.setCurrentItem(1);
      return;
      this.view_pager.setCurrentItem(2);
    }
    while (arrayOfString.length <= 1);
    this.browseTabView.checkDataForPage(com.sportq.fit.common.utils.StringUtils.string2Int(arrayOfString[1]));
    return;
    this.view_pager.setCurrentItem(3);
  }

  protected void onResume()
  {
    super.onResume();
    if (this.view_pager == null)
      return;
    if ((FitApplication.userModel == null) || (com.sportq.fit.common.utils.StringUtils.isNull(FitApplication.userModel.userId)))
      MiddleManager.getInstance().getLoginPresenterImpl(null).login(null, null);
    AppUtils.checkWeChatH5Jump(this);
    AppUtils.webJumpCheck(this, 0, this.view_pager);
    JumpManager.customPushJump(this);
    switch (this.view_pager.getCurrentItem())
    {
    case 2:
    default:
    case 0:
    case 1:
    case 3:
    }
    while (true)
    {
      MiddleManager.getInstance().getMinePresenterImpl(this).getMessageNumber(new RequestModel(), this);
      if (("login".equals(SharePreferenceUtils.getLoginStatus(this))) && (CompDeviceInfoUtils.checkNetwork()))
        MiddleManager.getInstance().getFindPresenterImpl(this, null).uploadLocalTrainData(this, this.dialog);
      showFitDialog(3);
      return;
      try
      {
        this.fitTabViewNew.initUI();
      }
      catch (Exception localException3)
      {
        LogUtils.e(localException3);
      }
      continue;
      try
      {
        this.findTabView.setDataForPage();
      }
      catch (Exception localException2)
      {
        LogUtils.e(localException2);
      }
      continue;
      try
      {
        this.mineTabView.refreshLayout();
      }
      catch (Exception localException1)
      {
        LogUtils.e(localException1);
      }
    }
  }

  protected void onStart()
  {
    super.onStart();
  }

  protected void onStop()
  {
    super.onStop();
  }

  public void setTabSelectorIcon(int paramInt)
  {
    label32: label68: ImageView localImageView;
    switch (CheckRedPointUtils.isSportTab(paramInt))
    {
    default:
      switch (CheckRedPointUtils.isProjectTab(this.mineReformer, paramInt))
      {
      default:
        localImageView = this.browse_icon;
        if (paramInt != 2);
      case 0:
      case 1:
      case 2:
      }
    case 0:
    case 1:
    case 2:
    }
    for (int i = 2130837607; ; i = 2130837606)
    {
      localImageView.setImageBitmap(ImageUtils.readBitMapBase(this, i));
      switch (CheckRedPointUtils.isMineTab(this.mineReformer, this.msgCount, paramInt))
      {
      default:
        return;
        this.train_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837835));
        break label32;
        this.train_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837834));
        break label32;
        this.train_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837833));
        break label32;
        this.find_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837658));
        break label68;
        this.find_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837657));
        break label68;
        this.find_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837656));
        break label68;
      case 0:
      case 1:
      case 2:
      case 3:
      }
    }
    this.mine_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837711));
    return;
    this.mine_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837708));
    return;
    if ((this.mineTabView != null) && (this.mineTabView.isNoticeNumVisibility()))
    {
      this.mine_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837708));
      return;
    }
    this.mine_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837707));
    return;
    this.mine_icon.setImageBitmap(ImageUtils.readBitMapBase(this, 2130837712));
  }

  public void showFitDialog(int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 0:
    case 1:
    case 2:
    case 3:
    }
    do
    {
      return;
      checkPublishDataHaveNoUpload();
      return;
      checkTrainNeedGoOn();
      return;
      getAdPopData();
      return;
    }
    while (!this.canReceiveMedal);
    onEventMainThread(new ReceiveMedalEvent("0"));
  }

  public void unreadAllNum(int paramInt)
  {
  }

  public void unreadNum(int paramInt)
  {
    EventBus.getDefault().post(new UnReadNumEvent(paramInt));
  }

  private class NavPageViewChangeListener
    implements ViewPager.OnPageChangeListener
  {
    private NavPageViewChangeListener()
    {
    }

    public void onPageScrollStateChanged(int paramInt)
    {
      NavMainActivity.this.fitTabViewNew.viewPagerState = paramInt;
    }

    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
    {
      if (NavMainActivity.this.fitTabViewNew.viewPagerState == 1);
      do
        return;
      while ((paramFloat != 0.0F) || (paramInt2 != 0));
      switch (paramInt1)
      {
      default:
        return;
      case 0:
        new Handler().postDelayed(new Runnable()
        {
          public void run()
          {
            NavMainActivity.this.fitTabViewNew.initUI();
          }
        }
        , 10L);
        return;
      case 1:
        new Handler().postDelayed(new Runnable()
        {
          public void run()
          {
            NavMainActivity.this.findTabView.setDataForPage();
          }
        }
        , 10L);
        return;
      case 2:
        new Handler().postDelayed(new Runnable()
        {
          public void run()
          {
            NavMainActivity.this.browseTabView.checkDataForPage(-1);
          }
        }
        , 10L);
        return;
      case 3:
      }
      new Handler().postDelayed(new Runnable()
      {
        public void run()
        {
          NavMainActivity.this.mineTabView.refreshLayout();
        }
      }
      , 10L);
    }

    public void onPageSelected(int paramInt)
    {
      switch (paramInt)
      {
      default:
        return;
      case 0:
        NavMainActivity.this.setTabSelectorIcon(0);
        return;
      case 1:
        NavMainActivity.this.setTabSelectorIcon(1);
        return;
      case 2:
        NavMainActivity.this.setTabSelectorIcon(2);
        return;
      case 3:
      }
      NavMainActivity.this.setTabSelectorIcon(3);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.NavMainActivity
 * JD-Core Version:    0.6.0
 */