package com.sportq.fit.business;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import java.util.List;
import org.byteam.superadapter.IMulItemViewType;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public abstract class BaseFitAdapter<T> extends SuperAdapter<T>
  implements FitInterfaceUtils.UIInitListener
{
  public BaseFitAdapter(Context paramContext, List<T> paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public BaseFitAdapter(Context paramContext, List<T> paramList, IMulItemViewType<T> paramIMulItemViewType)
  {
    super(paramContext, paramList, paramIMulItemViewType);
  }

  public void fitOnClick(View paramView)
  {
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
  }

  public void initLayout(Bundle paramBundle)
  {
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, T paramT)
  {
  }

  public <T> void onRefresh(T paramT)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.business.BaseFitAdapter
 * JD-Core Version:    0.6.0
 */