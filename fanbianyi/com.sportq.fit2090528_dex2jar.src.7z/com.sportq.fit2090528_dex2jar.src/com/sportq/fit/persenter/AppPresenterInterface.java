package com.sportq.fit.persenter;

import android.content.Context;
import com.sportq.fit.common.model.request.RequestModel;

public abstract interface AppPresenterInterface
{
  public abstract void getBrowseArticleList(Context paramContext, RequestModel paramRequestModel);

  public abstract void getBrowseVideoList(Context paramContext, RequestModel paramRequestModel);

  public abstract void getFcoinCommodity(Context paramContext);

  public abstract void getFcoinInfo(Context paramContext, RequestModel paramRequestModel);

  public abstract void getGoldService(Context paramContext);

  public abstract void getPlanClassify(Context paramContext);

  public abstract void getPlanTab(Context paramContext);

  public abstract void getRecommendInfo(Context paramContext, RequestModel paramRequestModel);

  public abstract void getSelectedPlan(Context paramContext, RequestModel paramRequestModel);

  public abstract void getTrainTab(Context paramContext);

  public abstract void setTopCourse(Context paramContext, RequestModel paramRequestModel);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.AppPresenterInterface
 * JD-Core Version:    0.6.0
 */