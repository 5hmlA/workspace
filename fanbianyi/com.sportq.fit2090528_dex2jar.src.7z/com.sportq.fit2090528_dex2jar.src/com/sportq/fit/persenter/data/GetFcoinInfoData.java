package com.sportq.fit.persenter.data;

import com.sportq.fit.common.BaseData;
import com.sportq.fit.persenter.model.GetFcoinInfoModel;
import java.util.ArrayList;

public class GetFcoinInfoData extends BaseData
{
  public String hasNextPage;
  public ArrayList<GetFcoinInfoModel> lstEnergyDet;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.data.GetFcoinInfoData
 * JD-Core Version:    0.6.0
 */