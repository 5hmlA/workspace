package com.sportq.fit.persenter.data;

import com.sportq.fit.common.BaseData;
import com.sportq.fit.persenter.model.GetFcoinCommodityModel;
import java.util.ArrayList;

public class GetFcoinCommodityData extends BaseData
{
  public ArrayList<GetFcoinCommodityModel> lstFcoinCommodity;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.data.GetFcoinCommodityData
 * JD-Core Version:    0.6.0
 */