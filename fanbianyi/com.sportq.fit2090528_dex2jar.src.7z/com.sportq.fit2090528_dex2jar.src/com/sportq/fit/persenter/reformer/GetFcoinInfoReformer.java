package com.sportq.fit.persenter.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.persenter.model.GetFcoinInfoModel;
import java.util.ArrayList;

public class GetFcoinInfoReformer extends BaseReformer
{
  public String hasNextPage;
  public ArrayList<GetFcoinInfoModel> lstEnergyDet;
  public String tradeId;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.reformer.GetFcoinInfoReformer
 * JD-Core Version:    0.6.0
 */