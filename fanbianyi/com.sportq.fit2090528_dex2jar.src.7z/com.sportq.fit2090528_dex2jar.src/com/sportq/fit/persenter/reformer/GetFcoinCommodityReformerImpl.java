package com.sportq.fit.persenter.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.persenter.data.GetFcoinCommodityData;
import com.sportq.fit.persenter.model.GetFcoinCommodityModel;
import java.util.ArrayList;
import java.util.Iterator;

public class GetFcoinCommodityReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    GetFcoinCommodityData localGetFcoinCommodityData = (GetFcoinCommodityData)paramBaseData;
    GetFcoinCommodityReformer localGetFcoinCommodityReformer = new GetFcoinCommodityReformer();
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localGetFcoinCommodityData.lstFcoinCommodity.iterator();
    while (localIterator.hasNext())
    {
      GetFcoinCommodityModel localGetFcoinCommodityModel1 = (GetFcoinCommodityModel)localIterator.next();
      GetFcoinCommodityModel localGetFcoinCommodityModel2 = new GetFcoinCommodityModel();
      localGetFcoinCommodityModel2.commodityId = localGetFcoinCommodityModel1.commodityId;
      localGetFcoinCommodityModel2.commodityTitle = localGetFcoinCommodityModel1.commodityTitle;
      if (!StringUtils.isNull(localGetFcoinCommodityModel1.price))
        localGetFcoinCommodityModel2.price = localGetFcoinCommodityModel1.price;
      localGetFcoinCommodityModel2.disComment = localGetFcoinCommodityModel1.disComment;
      localGetFcoinCommodityModel2.activeImageUrl = localGetFcoinCommodityModel1.activeImageUrl;
      localGetFcoinCommodityModel2.activeImageSize = localGetFcoinCommodityModel1.activeImageSize;
      localGetFcoinCommodityModel2.defaultFlag = localGetFcoinCommodityModel1.defaultFlag;
      localGetFcoinCommodityModel2.buyTitle = localGetFcoinCommodityModel1.buyTitle;
      localGetFcoinCommodityModel2.buyComment = localGetFcoinCommodityModel1.buyComment;
      if ("1".equals(localGetFcoinCommodityModel2.defaultFlag))
        localGetFcoinCommodityReformer.defaultSelIndex = localGetFcoinCommodityData.lstFcoinCommodity.indexOf(localGetFcoinCommodityModel1);
      localArrayList.add(localGetFcoinCommodityModel2);
    }
    localGetFcoinCommodityReformer.lstFcoinCommodity = localArrayList;
    return localGetFcoinCommodityReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (GetFcoinCommodityData)FitGsonFactory.create().fromJson(paramString2, GetFcoinCommodityData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.reformer.GetFcoinCommodityReformerImpl
 * JD-Core Version:    0.6.0
 */