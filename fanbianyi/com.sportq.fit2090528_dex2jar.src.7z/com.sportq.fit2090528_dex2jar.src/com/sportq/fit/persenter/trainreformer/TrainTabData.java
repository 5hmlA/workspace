package com.sportq.fit.persenter.trainreformer;

import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.model.CourseActItemModel;
import com.sportq.fit.common.model.CurriculumModel;
import com.sportq.fit.common.model.EntloseFatData;
import com.sportq.fit.common.model.GoldServiceModel;
import com.sportq.fit.common.model.response.ResponseModel.HeadData;
import com.sportq.fit.common.model.response.ResponseModel.TrainData;
import com.sportq.fit.persenter.model.NewBiesModel;
import java.util.ArrayList;

public class TrainTabData extends BaseData
{
  public CurriculumModel entCus;
  public NewBiesModel entNewGift;
  public ResponseModel.HeadData entTotal;
  public ArrayList<EntloseFatData> lstCamp;
  public ArrayList<GoldServiceModel> lstGoldService;
  public ArrayList<CourseActItemModel> lstMission;
  public ArrayList<ResponseModel.TrainData> lstRecommend;
  public ArrayList<ResponseModel.TrainData> lstTraint;
  public String missionJoinFlag;
  public String orderNumber;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.trainreformer.TrainTabData
 * JD-Core Version:    0.6.0
 */