package com.sportq.fit.persenter.trainreformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.model.CourseActItemModel;
import com.sportq.fit.common.model.CurriculumModel;
import com.sportq.fit.common.model.EntloseFatData;
import com.sportq.fit.common.model.GoldServiceModel;
import com.sportq.fit.common.model.HeadModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.persenter.model.NewBiesModel;
import java.util.ArrayList;

public class TrainTabReformer extends BaseReformer
{
  public HeadModel _headModel;
  public CurriculumModel customizeInfo;
  public NewBiesModel entNewGift;
  public ArrayList<EntloseFatData> lstCamp;
  public ArrayList<GoldServiceModel> lstGoldService;
  public ArrayList<PlanModel> lstMine;
  public ArrayList<CourseActItemModel> lstMission;
  public ArrayList<PlanModel> lstRecommend;
  public String missionJoinFlag;
  public String orderNumber;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.trainreformer.TrainTabReformer
 * JD-Core Version:    0.6.0
 */