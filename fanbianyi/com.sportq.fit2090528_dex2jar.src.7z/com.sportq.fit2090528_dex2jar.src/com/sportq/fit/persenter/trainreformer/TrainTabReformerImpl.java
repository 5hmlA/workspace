package com.sportq.fit.persenter.trainreformer;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.HeadModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.response.ResponseModel.HeadData;
import com.sportq.fit.common.model.response.ResponseModel.TrainData;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.widget.CustomTypefaceSpan;
import java.util.ArrayList;
import java.util.Iterator;

public class TrainTabReformerImpl
  implements ReformerInterface
{
  private SpannableString convertInfo(PlanModel paramPlanModel)
  {
    if ((StringUtils.isNull(paramPlanModel.finishSection)) || (StringUtils.isNull(paramPlanModel.sectionCount)))
      return null;
    String str = paramPlanModel.finishSection + "/" + paramPlanModel.sectionCount;
    SpannableString localSpannableString = new SpannableString(str);
    localSpannableString.setSpan(new AbsoluteSizeSpan(28, true), 0, str.indexOf("/"), 17);
    localSpannableString.setSpan(new AbsoluteSizeSpan(13, true), str.indexOf("/"), str.length(), 17);
    localSpannableString.setSpan(new CustomTypefaceSpan(TextUtils.getFontFaceImpact()), 0, str.length(), 17);
    Context localContext = BaseApplication.appliContext;
    if (isFinished(paramPlanModel));
    for (int i = 2131624121; ; i = 2131624328)
    {
      localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(localContext, i)), 0, str.length(), 17);
      return localSpannableString;
    }
  }

  private boolean isFinished(PlanModel paramPlanModel)
  {
    return paramPlanModel.finishSection.equals(paramPlanModel.sectionCount);
  }

  private SpannableString setPointColor(String paramString)
  {
    SpannableString localSpannableString = new SpannableString(paramString);
    for (int i = 0; i < paramString.length(); i++)
    {
      if (!"•".equals(String.valueOf(paramString.charAt(i))))
        continue;
      localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(BaseApplication.appliContext, 2131624071)), i, i + 1, 33);
    }
    int j = paramString.indexOf("钟");
    if (j > 0)
      localSpannableString.setSpan(new StyleSpan(1), 0, j + 1, 33);
    return localSpannableString;
  }

  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    TrainTabData localTrainTabData = (TrainTabData)paramBaseData;
    TrainTabReformer localTrainTabReformer = new TrainTabReformer();
    localTrainTabReformer.lstMine = new ArrayList();
    localTrainTabReformer.lstRecommend = new ArrayList();
    localTrainTabReformer.orderNumber = localTrainTabData.orderNumber;
    localTrainTabReformer._headModel = new HeadModel();
    if (localTrainTabData.entTotal != null)
    {
      localTrainTabReformer._headModel.trainNums = localTrainTabData.entTotal.trainNums;
      BaseApplication.trainNums = localTrainTabData.entTotal.trainNums;
      localTrainTabReformer._headModel.trainDays = localTrainTabData.entTotal.trainDays;
      localTrainTabReformer._headModel.continuousDays = localTrainTabData.entTotal.continuousDays;
      localTrainTabReformer._headModel.calorie = localTrainTabData.entTotal.calorie;
      localTrainTabReformer._headModel.trainDuration = localTrainTabData.entTotal.trainDuration;
      localTrainTabReformer._headModel.sectionDuration = localTrainTabData.entTotal.nextTrainDuration;
      localTrainTabReformer._headModel.lastTrainDuration = localTrainTabData.entTotal.lastTrainDuration;
      localTrainTabReformer._headModel.levelName = localTrainTabData.entTotal.levelName;
      int i = StringUtils.string2Int(localTrainTabData.entTotal.nextTrainDuration);
      int j = StringUtils.string2Int(localTrainTabData.entTotal.trainDuration);
      if (i > 0)
      {
        HeadModel localHeadModel = localTrainTabReformer._headModel;
        String str2 = StringUtils.getStringResources(2131296717);
        Object[] arrayOfObject8 = new Object[1];
        arrayOfObject8[0] = Integer.valueOf(i - j);
        localHeadModel.differDuration = String.format(str2, arrayOfObject8);
      }
    }
    localTrainTabReformer.lstGoldService = localTrainTabData.lstGoldService;
    localTrainTabReformer.customizeInfo = localTrainTabData.entCus;
    ArrayList localArrayList1;
    ArrayList localArrayList2;
    label354: ResponseModel.TrainData localTrainData2;
    label400: PlanModel localPlanModel2;
    if (localTrainTabData.lstCamp == null)
    {
      localArrayList1 = new ArrayList();
      localTrainTabReformer.lstCamp = localArrayList1;
      localTrainTabReformer.missionJoinFlag = localTrainTabData.missionJoinFlag;
      if (localTrainTabData.lstMission != null)
        break label865;
      localArrayList2 = new ArrayList();
      localTrainTabReformer.lstMission = localArrayList2;
      localTrainTabReformer.entNewGift = localTrainTabData.entNewGift;
      if ((localTrainTabData.lstTraint == null) || (localTrainTabData.lstTraint.size() <= 0))
        break label883;
      Iterator localIterator2 = localTrainTabData.lstTraint.iterator();
      if (!localIterator2.hasNext())
        break label883;
      localTrainData2 = (ResponseModel.TrainData)localIterator2.next();
      localPlanModel2 = new PlanModel();
      localPlanModel2.planId = localTrainData2.planId;
      localPlanModel2.individuaId = localTrainData2.individualId;
      localPlanModel2.planName = localTrainData2.planName;
      localPlanModel2.trainType = localTrainData2.type;
      Object[] arrayOfObject4 = new Object[1];
      arrayOfObject4[0] = localTrainData2.numberOfParticipants;
      localPlanModel2.planNumberOfParticipants = String.format("%s人已参加", arrayOfObject4);
      localPlanModel2.planImageURL = localTrainData2.imageURL;
      localPlanModel2.isNewTag = localTrainData2.isNewTag;
      localPlanModel2.isUpdate = localTrainData2.isUpdate;
      localPlanModel2.planStateCode = localTrainData2.stateCode;
      localPlanModel2.topFlag = localTrainData2.topFlag;
      localPlanModel2.energyFlag = localTrainData2.energyFlag;
      localPlanModel2.effectTime = localTrainData2.effectTime;
      localPlanModel2.planState = "已参加";
      localPlanModel2.olapInfo = localTrainData2.olapInfo;
      localPlanModel2.currentSection = localTrainData2.sectionNum;
      localPlanModel2.finishSection = localTrainData2.trainNums;
      localPlanModel2.sectionCount = localTrainData2.totalTrainNum;
      if (!"2".equals(localTrainData2.stateCode))
        break label875;
    }
    label865: label875: for (String str1 = "完成"; ; str1 = "")
    {
      localPlanModel2.planState = str1;
      localPlanModel2.planTrainDuration = localTrainData2.time;
      Object[] arrayOfObject5 = new Object[3];
      arrayOfObject5[0] = localTrainData2.calorie;
      arrayOfObject5[1] = StringUtils.difficultyLevel(localTrainData2.difficultyLevel);
      arrayOfObject5[2] = localTrainData2.apparatus;
      localPlanModel2.planSummary = String.format("%s千卡 %s %s", arrayOfObject5);
      localPlanModel2.trainDuration = localTrainData2.trainDuration;
      if ("0".equals(localPlanModel2.trainType))
      {
        Object[] arrayOfObject6 = new Object[3];
        arrayOfObject6[0] = localTrainData2.calorie;
        arrayOfObject6[1] = StringUtils.difficultyLevel(localTrainData2.difficultyLevel);
        arrayOfObject6[2] = localTrainData2.apparatus;
        localPlanModel2.planSummary = String.format("%s千卡 %s %s", arrayOfObject6);
        Object[] arrayOfObject7 = new Object[3];
        arrayOfObject7[0] = localTrainData2.trainDuration;
        arrayOfObject7[1] = localTrainData2.calorie;
        arrayOfObject7[2] = StringUtils.difficultyLevel(localTrainData2.difficultyLevel);
        localPlanModel2.courseInfo = String.format("%s分钟  •  %s千卡  •  %s", arrayOfObject7);
        localPlanModel2.scheduleInfo = setPointColor(TextUtils.replacePointSize(localPlanModel2.courseInfo));
      }
      localTrainTabReformer.lstMine.add(localPlanModel2);
      break label400;
      localArrayList1 = localTrainTabData.lstCamp;
      break;
      localArrayList2 = localTrainTabData.lstMission;
      break label354;
    }
    label883: if ((localTrainTabData.lstRecommend != null) && (localTrainTabData.lstRecommend.size() > 0))
    {
      Iterator localIterator1 = localTrainTabData.lstRecommend.iterator();
      while (localIterator1.hasNext())
      {
        ResponseModel.TrainData localTrainData1 = (ResponseModel.TrainData)localIterator1.next();
        PlanModel localPlanModel1 = new PlanModel();
        localPlanModel1.planId = localTrainData1.planId;
        localPlanModel1.individuaId = localTrainData1.individualId;
        localPlanModel1.planName = localTrainData1.planName;
        localPlanModel1.trainType = localTrainData1.type;
        Object[] arrayOfObject1 = new Object[1];
        arrayOfObject1[0] = localTrainData1.numberOfParticipants;
        localPlanModel1.planNumberOfParticipants = String.format("%s人已参加", arrayOfObject1);
        localPlanModel1.planImageURL = localTrainData1.imageURL;
        localPlanModel1.isNewTag = localTrainData1.isNewTag;
        localPlanModel1.isUpdate = localTrainData1.isUpdate;
        localPlanModel1.planStateCode = localTrainData1.stateCode;
        localPlanModel1.topFlag = localTrainData1.topFlag;
        localPlanModel1.energyFlag = localTrainData1.energyFlag;
        localPlanModel1.effectTime = localTrainData1.effectTime;
        localPlanModel1.olapInfo = localTrainData1.olapInfo;
        localPlanModel1.trainDuration = localTrainData1.trainDuration;
        if ("0".equals(localPlanModel1.trainType))
        {
          Object[] arrayOfObject2 = new Object[4];
          arrayOfObject2[0] = localTrainData1.trainDuration;
          arrayOfObject2[1] = localTrainData1.calorie;
          arrayOfObject2[2] = StringUtils.difficultyLevel(localTrainData1.difficultyLevel);
          arrayOfObject2[3] = localTrainData1.apparatus;
          localPlanModel1.planSummary = String.format("%s %s千卡 %s %s", arrayOfObject2);
          Object[] arrayOfObject3 = new Object[3];
          arrayOfObject3[0] = localTrainData1.trainDuration;
          arrayOfObject3[1] = localTrainData1.calorie;
          arrayOfObject3[2] = StringUtils.difficultyLevel(localTrainData1.difficultyLevel);
          localPlanModel1.courseInfo = String.format("%s分钟  •  %s千卡  •  %s", arrayOfObject3);
          localPlanModel1.scheduleInfo = setPointColor(TextUtils.replacePointSize(localPlanModel1.courseInfo));
        }
        localTrainTabReformer.lstRecommend.add(localPlanModel1);
      }
    }
    if (!StringUtils.isNull(localTrainTabReformer._headModel.calorie))
    {
      BaseApplication.headModel = localTrainTabReformer._headModel;
      PreferencesTools.saveValueToTable("tbl_headmodel", "key_headmodel", new GsonBuilder().create().toJson(BaseApplication.headModel));
    }
    return localTrainTabReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (TrainTabData)FitGsonFactory.create().fromJson(paramString2, TrainTabData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.trainreformer.TrainTabReformerImpl
 * JD-Core Version:    0.6.0
 */