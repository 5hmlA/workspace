package com.sportq.fit.persenter.model;

import com.sportq.fit.common.model.BaseModel;

public class NewBiesModel extends BaseModel
{
  public String flag;
  public String popContent;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.model.NewBiesModel
 * JD-Core Version:    0.6.0
 */