package com.sportq.fit.persenter.model;

public class CustomH5JumpModel
{
  public String childIndex;
  public String id;
  public String name;
  public String page;
  public String type;
  public String url;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.model.CustomH5JumpModel
 * JD-Core Version:    0.6.0
 */