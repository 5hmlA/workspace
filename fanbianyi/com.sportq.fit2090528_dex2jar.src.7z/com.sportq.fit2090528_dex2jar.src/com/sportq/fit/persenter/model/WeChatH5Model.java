package com.sportq.fit.persenter.model;

public class WeChatH5Model
{
  public String isone;
  public String loseFatId;
  public String text;
  public String unionid;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.model.WeChatH5Model
 * JD-Core Version:    0.6.0
 */