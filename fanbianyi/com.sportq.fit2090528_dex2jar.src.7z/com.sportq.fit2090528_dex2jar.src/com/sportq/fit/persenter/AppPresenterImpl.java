package com.sportq.fit.persenter;

import android.content.Context;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle7.customize.refermer.NoResultReformerImpl;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.persenter.reformer.GetFcoinCommodityReformerImpl;
import com.sportq.fit.persenter.reformer.GetFcoinInfoReformerImpl;
import com.sportq.fit.persenter.trainreformer.TrainTabReformerImpl;
import com.sportq.fit.supportlib.CommonUtils;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.reformer.BannerReformerImpl;
import com.sportq.fit.supportlib.http.reformer.BrowseArticleListReformerImpl;
import com.sportq.fit.supportlib.http.reformer.BrowseVideoListReformerImpl;
import com.sportq.fit.supportlib.http.reformer.GetRecommendReformerImpl;
import com.sportq.fit.supportlib.http.reformer.GoldServiceReformerImpl;
import com.sportq.fit.supportlib.http.reformer.PlanClassifyReformerImpl;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;

public class AppPresenterImpl
  implements AppPresenterInterface
{
  private ApiInterface api = new ApiImpl();
  private FitInterfaceUtils.UIInitListener uiListener;

  public AppPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.uiListener = paramUIInitListener;
  }

  public ApiInterface getApi()
  {
    return this.api;
  }

  public void getBrowseArticleList(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new BrowseArticleListReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetBrowseArticleList);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetBrowseArticleList);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("AppPresenterImpl.getBrowseArticleList", localException);
    }
  }

  public void getBrowseVideoList(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new BrowseVideoListReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetBrowseVideoList);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetBrowseVideoList);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("AppPresenterImpl.getBrowseVideoList", localException);
    }
  }

  public void getFcoinCommodity(Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GetFcoinCommodityReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetFcoinCommodity);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetFcoinCommodity);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void getFcoinInfo(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetFcoinInfo);
      this.api.getHttp(str, paramContext, this.uiListener, new GetFcoinInfoReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void getGoldService(Context paramContext)
  {
    try
    {
      CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.getGoldService);
      ReformerImpl localReformerImpl = new ReformerImpl(new GoldServiceReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.getGoldService);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.getGoldService);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("AppPresenterImpl.getGoldService", localException);
    }
  }

  public void getPlanClassify(Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new PlanClassifyReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.getPlanClassify);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.getPlanClassify);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("AppPresenterImpl.getPlanClassify", localException);
    }
  }

  public void getPlanTab(Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new BannerReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetPlanTab);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetPlanTab);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("AppPresenterImpl.getPlanTab", localException);
    }
  }

  public void getRecommendInfo(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetRecPlan);
      this.api.getHttp(str, paramContext, this.uiListener, new GetRecommendReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("AppPresenterImpl.getRecommendInfo", localException);
    }
  }

  public void getSelectedPlan(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GoldServiceReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.getSelectedPlan);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.getSelectedPlan);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("AppPresenterImpl.getSelectedPlan", localException);
    }
  }

  public void getTrainTab(Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new TrainTabReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.getTrainTab);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.getTrainTab);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void setTopCourse(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new NoResultReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.SetTopCourse);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.SetTopCourse);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("AppPresenterImpl.setTopCourse", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.persenter.AppPresenterImpl
 * JD-Core Version:    0.6.0
 */