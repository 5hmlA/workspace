package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstTopicData;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

public class CustomKnowledgeView extends RelativeLayout
{
  private View itemView;
  private Context mContext;

  public CustomKnowledgeView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    this.itemView = View.inflate(this.mContext, R.layout.custom_title_view, null);
    TextView localTextView = (TextView)this.itemView.findViewById(R.id.custom_title);
    this.itemView.findViewById(R.id.item_layout).setBackgroundColor(getResources().getColor(R.color.white));
    localTextView.setText(this.mContext.getString(R.string.a_4_13_8));
    ImageView localImageView = (ImageView)this.itemView.findViewById(R.id.diet_type_img);
    localImageView.setImageResource(R.mipmap.img_knowledge);
    localImageView.setVisibility(0);
    return this.itemView;
  }

  public void initData(ArrayList<EntlstTopicData> paramArrayList)
  {
    LinearLayout localLinearLayout = (LinearLayout)this.itemView.findViewById(R.id.content_layout);
    localLinearLayout.removeAllViews();
    if ((paramArrayList == null) || (paramArrayList.size() == 0))
      this.itemView.setVisibility(8);
    while (true)
    {
      return;
      localLinearLayout.setWeightSum(paramArrayList.size());
      for (int i = 0; i < paramArrayList.size(); i++)
      {
        int j = i;
        View localView = View.inflate(this.mContext, R.layout.konwlege_item_view, null);
        ((TextView)localView.findViewById(R.id.article_title)).setText(((EntlstTopicData)paramArrayList.get(i)).tpcTitle);
        LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 60.0F));
        localLayoutParams.weight = 1.0F;
        localView.setOnClickListener(new FitAction(null, paramArrayList, j)
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            FitJumpImpl.getInstance().pushJumpArticleActivtiy(CustomKnowledgeView.this.getContext(), ((EntlstTopicData)this.val$lstTopic.get(this.val$index)).tpcUrl, null);
            super.onClick(paramView);
          }
        });
        localLinearLayout.addView(localView, localLayoutParams);
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomKnowledgeView
 * JD-Core Version:    0.6.0
 */