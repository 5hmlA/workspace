package com.sportq.fit.fitmoudle7.customize.widget;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.View;
import com.sportq.fit.fitmoudle7.R.animator;

public class FatCampFlipAnimation
{
  private AnimationListener animationListener;
  private int distance = 25000;
  private Context mContext;
  private View mFlCardBack;
  private View mFlCardFront;
  private boolean mIsShowBack;
  private AnimatorSet mLeftInSet;
  private AnimatorSet mRightOutSet;

  public FatCampFlipAnimation(Context paramContext, View paramView1, View paramView2, AnimationListener paramAnimationListener)
  {
    this.mContext = paramContext;
    this.mFlCardFront = paramView1;
    this.mFlCardBack = paramView2;
    setAnimators();
    setCameraDistance();
    this.animationListener = paramAnimationListener;
  }

  private void setAnimators()
  {
    this.mRightOutSet = ((AnimatorSet)AnimatorInflater.loadAnimator(this.mContext, R.animator.anim_out));
    this.mLeftInSet = ((AnimatorSet)AnimatorInflater.loadAnimator(this.mContext, R.animator.anim_in));
    this.mRightOutSet.addListener(new AnimatorListenerAdapter()
    {
      public void onAnimationStart(Animator paramAnimator)
      {
        super.onAnimationStart(paramAnimator);
        FatCampFlipAnimation.this.mFlCardFront.bringToFront();
        FatCampFlipAnimation.this.mFlCardBack.setVisibility(0);
      }
    });
    this.mLeftInSet.addListener(new AnimatorListenerAdapter()
    {
      public void onAnimationEnd(Animator paramAnimator)
      {
        super.onAnimationEnd(paramAnimator);
        FatCampFlipAnimation.this.animationListener.finish();
        FatCampFlipAnimation.this.mFlCardBack.bringToFront();
      }
    });
  }

  private void setCameraDistance()
  {
    float f = this.mContext.getResources().getDisplayMetrics().density * this.distance;
    this.mFlCardFront.setCameraDistance(f);
    this.mFlCardBack.setCameraDistance(f);
  }

  public void flipAnimationStart()
  {
    this.mRightOutSet.setTarget(this.mFlCardFront);
    this.mLeftInSet.setTarget(this.mFlCardBack);
    this.mRightOutSet.start();
    this.mLeftInSet.start();
  }

  public static abstract interface AnimationListener
  {
    public abstract void finish();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.FatCampFlipAnimation
 * JD-Core Version:    0.6.0
 */