package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.RectF;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle7.R.color;

public class FatCampShareProgress extends View
{
  private Paint allArcPaint;
  private int bgArcColor = R.color.color_f7f7f7;
  private int bgArcWidth = CompDeviceInfoUtils.convertOfDip(getContext(), 7.0F);
  private Paint bgCirclePaint;
  private int bgColor = R.color.transparent;
  private RectF bgRect;
  private int centerX;
  private int centerY;
  private float currentAngle = 90.0F;
  private PaintFlagsDrawFilter mDrawFilter;
  private int progressColor = R.color.color_2ac77d;
  private Paint progressPaint;
  private float progressWidth = CompDeviceInfoUtils.convertOfDip(getContext(), 7.1F);
  private float width;

  public FatCampShareProgress(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    for (int i = 0; ; i++)
    {
      if (i < paramAttributeSet.getAttributeCount())
      {
        if (!"layout_width".equals(paramAttributeSet.getAttributeName(i)))
          continue;
        this.width = Float.valueOf(paramAttributeSet.getAttributeValue(i).replace("dip", "")).floatValue();
      }
      initView();
      return;
    }
  }

  private void initView()
  {
    int i = CompDeviceInfoUtils.convertOfDip(getContext(), this.width);
    this.bgRect = new RectF();
    this.bgRect.top = CompDeviceInfoUtils.convertOfDip(getContext(), 3.5F);
    this.bgRect.left = CompDeviceInfoUtils.convertOfDip(getContext(), 3.5F);
    this.bgRect.right = (i - CompDeviceInfoUtils.convertOfDip(getContext(), 3.5F));
    this.bgRect.bottom = (i - CompDeviceInfoUtils.convertOfDip(getContext(), 3.5F));
    this.centerX = (i / 2);
    this.centerY = (i / 2);
    this.allArcPaint = new Paint();
    this.allArcPaint.setAntiAlias(true);
    this.allArcPaint.setStyle(Paint.Style.STROKE);
    this.allArcPaint.setStrokeWidth(this.bgArcWidth);
    this.allArcPaint.setColor(ContextCompat.getColor(getContext(), this.bgArcColor));
    this.allArcPaint.setStrokeCap(Paint.Cap.ROUND);
    this.progressPaint = new Paint();
    this.progressPaint.setAntiAlias(true);
    this.progressPaint.setStyle(Paint.Style.STROKE);
    this.progressPaint.setStrokeCap(Paint.Cap.ROUND);
    this.progressPaint.setStrokeWidth(this.progressWidth);
    this.progressPaint.setColor(ContextCompat.getColor(getContext(), this.progressColor));
    this.bgCirclePaint = new Paint();
    this.bgCirclePaint.setColor(ContextCompat.getColor(getContext(), this.bgColor));
    this.mDrawFilter = new PaintFlagsDrawFilter(0, 3);
  }

  protected void onDraw(Canvas paramCanvas)
  {
    paramCanvas.drawCircle(this.centerX, this.centerY, this.centerX, this.bgCirclePaint);
    paramCanvas.setDrawFilter(this.mDrawFilter);
    paramCanvas.drawArc(this.bgRect, 270, 360, false, this.allArcPaint);
    paramCanvas.drawArc(this.bgRect, 270, this.currentAngle, false, this.progressPaint);
    paramCanvas.drawArc(this.bgRect, 270, 1.0F, false, this.progressPaint);
  }

  public void setValue(float paramFloat, int paramInt)
  {
    this.currentAngle = paramFloat;
    this.progressPaint.setColor(ContextCompat.getColor(getContext(), paramInt));
    invalidate();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.FatCampShareProgress
 * JD-Core Version:    0.6.0
 */