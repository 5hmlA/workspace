package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;

public class CustomStartItemView extends RelativeLayout
{
  private String[] contentList;
  private int[] imgList;
  private TextView item_content;
  private ImageView item_img;
  private ImageView item_title;
  private TextView see_other_content;
  private int[] titleList;

  public CustomStartItemView(Context paramContext)
  {
    this(paramContext, null);
  }

  public CustomStartItemView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public CustomStartItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    int[] arrayOfInt1 = new int[5];
    arrayOfInt1[0] = R.mipmap.img_custom_made1;
    arrayOfInt1[1] = R.mipmap.img_custom_made2;
    arrayOfInt1[2] = R.mipmap.img_custom_made3;
    arrayOfInt1[3] = R.mipmap.img_custom_made4;
    arrayOfInt1[4] = R.mipmap.img_custom_made5;
    this.imgList = arrayOfInt1;
    int[] arrayOfInt2 = new int[5];
    arrayOfInt2[0] = R.mipmap.word_01;
    arrayOfInt2[1] = R.mipmap.word_02;
    arrayOfInt2[2] = R.mipmap.word_03;
    arrayOfInt2[3] = R.mipmap.word_04;
    arrayOfInt2[4] = R.mipmap.word_05;
    this.titleList = arrayOfInt2;
    String[] arrayOfString = new String[5];
    arrayOfString[0] = paramContext.getString(R.string.a_2_1_2);
    arrayOfString[1] = paramContext.getString(R.string.a_2_11_2);
    arrayOfString[2] = paramContext.getString(R.string.a_2_12_2);
    arrayOfString[3] = paramContext.getString(R.string.a_2_13_2);
    arrayOfString[4] = paramContext.getString(R.string.a_2_14_2);
    this.contentList = arrayOfString;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), R.layout.start_view_pager_item, null);
    this.item_img = ((ImageView)localView.findViewById(R.id.item_img));
    this.item_title = ((ImageView)localView.findViewById(R.id.item_title));
    this.item_content = ((TextView)localView.findViewById(R.id.item_content));
    this.see_other_content = ((TextView)localView.findViewById(R.id.see_other_content));
    this.see_other_content.setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        new AboutCustomizeDialog(CustomStartItemView.this.getContext()).appCommentDialog();
      }
    });
    return localView;
  }

  public void initData(int paramInt)
  {
    this.item_img.setImageDrawable(ContextCompat.getDrawable(getContext(), this.imgList[paramInt]));
    this.item_title.setImageDrawable(ContextCompat.getDrawable(getContext(), this.titleList[paramInt]));
    this.item_content.setText(this.contentList[paramInt]);
    TextView localTextView = this.see_other_content;
    if (paramInt == 4);
    for (int i = 0; ; i = 8)
    {
      localTextView.setVisibility(i);
      return;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomStartItemView
 * JD-Core Version:    0.6.0
 */