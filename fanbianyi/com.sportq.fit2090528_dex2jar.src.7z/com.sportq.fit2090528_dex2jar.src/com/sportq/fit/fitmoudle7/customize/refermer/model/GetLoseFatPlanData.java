package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;
import java.util.ArrayList;

public class GetLoseFatPlanData extends BaseData
  implements Serializable
{
  public EntloseFatData entLoseFatData;
  public ArrayList<EntloseFatPlanData> lstLoseFatPlan;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.GetLoseFatPlanData
 * JD-Core Version:    0.6.0
 */