package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstMonthCusData;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;

public class CustomWeekItemView extends RelativeLayout
{
  private ArrayList<EntlstMonthCusData> dataList;
  private int itemIndex = 0;
  private Context mContext;
  private String nWeekId;
  private RTextViewHelper rTextViewHelper;

  public CustomWeekItemView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public CustomWeekItemView(Context paramContext, ArrayList<EntlstMonthCusData> paramArrayList, int paramInt, String paramString)
  {
    super(paramContext);
    this.mContext = paramContext;
    this.dataList = paramArrayList;
    this.itemIndex = paramInt;
    this.nWeekId = paramString;
    addView(onCreateView());
  }

  private String convertWeekDay(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return "";
    case 0:
      return "日";
    case 1:
      return "一";
    case 2:
      return "二";
    case 3:
      return "三";
    case 4:
      return "四";
    case 5:
      return "五";
    case 6:
    }
    return "六";
  }

  private int dayForWeek(String paramString)
  {
    try
    {
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", new Locale("zh", "CN"));
      Calendar localCalendar = Calendar.getInstance();
      localCalendar.setTime(localSimpleDateFormat.parse(paramString));
      if (localCalendar.get(7) == 1)
        return 0;
      int i = localCalendar.get(7);
      return i - 1;
    }
    catch (ParseException localParseException)
    {
      LogUtils.e(localParseException);
    }
    return -1;
  }

  public View onCreateView()
  {
    LinearLayout localLinearLayout = (LinearLayout)View.inflate(getContext(), R.layout.fat_camp_viewpager_item, null).findViewById(R.id.linearLayout);
    localLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(getContext(), 74.0F)));
    int i = ((BaseApplication.screenWidth - CompDeviceInfoUtils.convertOfDip(getContext(), 8.0F)) / 7 - CompDeviceInfoUtils.convertOfDip(getContext(), 34.0F)) / 2;
    localLinearLayout.removeAllViews();
    localLinearLayout.setWeightSum(7.0F);
    for (int j = 0; j < 7; j++)
    {
      View localView1 = View.inflate(getContext(), R.layout.custom_week_day_view, null);
      LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, CompDeviceInfoUtils.convertOfDip(getContext(), 74.0F));
      localLayoutParams.weight = 1.0F;
      if (j == 0)
        localLayoutParams.leftMargin = (CompDeviceInfoUtils.convertOfDip(getContext(), 8.0F) - i);
      if (j == 6)
        localLayoutParams.rightMargin = (CompDeviceInfoUtils.convertOfDip(getContext(), 8.0F) - i);
      localView1.setLayoutParams(localLayoutParams);
      RTextView localRTextView = (RTextView)localView1.findViewById(R.id.calendar_tagIcon);
      this.rTextViewHelper = localRTextView.getHelper();
      TextView localTextView1 = (TextView)localView1.findViewById(R.id.week_day);
      TextView localTextView2 = (TextView)localView1.findViewById(R.id.calendar_tvDate);
      TextView localTextView3 = (TextView)localView1.findViewById(R.id.calendar_noteInfo);
      View localView2 = localView1.findViewById(R.id.calendar_indicator);
      ImageView localImageView = (ImageView)localView1.findViewById(R.id.calendar_finishedoral);
      localTextView1.setText(convertWeekDay(j));
      int k = 0;
      if (k < this.dataList.size())
      {
        EntlstMonthCusData localEntlstMonthCusData = (EntlstMonthCusData)this.dataList.get(k);
        int m;
        label336: int n;
        label414: label455: int i1;
        if (dayForWeek(localEntlstMonthCusData.cusDate) == j)
        {
          localTextView3.setText("反馈日");
          if (!"1".equals(localEntlstMonthCusData.isFeedBackDay))
            break label704;
          m = 0;
          localTextView3.setVisibility(m);
          String str = localEntlstMonthCusData.cusDate.split("-")[2];
          if ("0".equals(String.valueOf(str.charAt(0))))
            str = str.replaceFirst("0", "");
          localTextView2.setText(str);
          localTextView2.setVisibility(0);
          if (!"1".equals(localEntlstMonthCusData.isTrainDay))
            break label710;
          n = 0;
          localRTextView.setVisibility(n);
          if (!"0".equals(localEntlstMonthCusData.isTrainDay))
            break label716;
          localRTextView.setVisibility(4);
          localTextView2.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
          if (!"1".equals(localEntlstMonthCusData.trainWeekState))
            localTextView2.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_c8c8c8));
          if (("3".equals(BaseApplication.userModel.isVip)) && (!"1".equals(localEntlstMonthCusData.trainWeekState)))
            localTextView2.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_c8c8c8));
          if (!"1".equals(localEntlstMonthCusData.isFinish))
            break label856;
          i1 = 0;
          label542: localImageView.setVisibility(i1);
          if (!localEntlstMonthCusData.isToday)
            break label880;
          if (!"2".equals(localEntlstMonthCusData.isTrainDay))
            localTextView3.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_dbb76a));
          if (localRTextView.getVisibility() != 0)
            break label862;
          this.rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_dbb76a));
          localTextView2.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
          label627: localTextView2.setTypeface(Typeface.DEFAULT_BOLD);
          localView2.setVisibility(0);
        }
        while (true)
        {
          localView1.setTag(localEntlstMonthCusData.cusDate);
          1 local1 = new View.OnClickListener(localEntlstMonthCusData)
          {
            @Instrumented
            public void onClick(View paramView)
            {
              VdsAgent.onClick(this, paramView);
              EventBus.getDefault().post(this.val$entlstMonthCusData);
            }
          };
          localView1.setOnClickListener(local1);
          if ((StringUtils.isNull(this.nWeekId)) && (this.itemIndex == 0) && (k == 0))
            localView2.setVisibility(0);
          k++;
          break;
          label704: m = 4;
          break label336;
          label710: n = 4;
          break label414;
          label716: if ("1".equals(localEntlstMonthCusData.isTrainDay))
          {
            this.rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_e6e6e6));
            localRTextView.setVisibility(0);
            localTextView2.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
            break label455;
          }
          if (!"2".equals(localEntlstMonthCusData.isTrainDay))
            break label455;
          this.rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_313131));
          localRTextView.setVisibility(0);
          localTextView2.setTextColor(ContextCompat.getColor(this.mContext, R.color.white));
          localTextView3.setText("请假");
          localTextView3.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
          localTextView3.setVisibility(0);
          break label455;
          label856: i1 = 4;
          break label542;
          label862: localTextView2.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_dbb76a));
          break label627;
          label880: localView2.setVisibility(4);
        }
      }
      localLinearLayout.addView(localView1);
    }
    return localLinearLayout;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomWeekItemView
 * JD-Core Version:    0.6.0
 */