package com.sportq.fit.fitmoudle7.customize.persenter;

import android.content.Context;
import com.sportq.fit.common.model.request.RequestModel;

public abstract interface CustomPresenterInterface
{
  public abstract void changeCusDietary(RequestModel paramRequestModel, Context paramContext);

  public abstract void exitMonthCus(RequestModel paramRequestModel, Context paramContext);

  public abstract void feedBackCus(RequestModel paramRequestModel, Context paramContext);

  public abstract void finishMonthCus(RequestModel paramRequestModel, Context paramContext);

  public abstract void getCusData(RequestModel paramRequestModel, Context paramContext);

  public abstract void getCusDietary(Context paramContext);

  public abstract void getCusHistory(RequestModel paramRequestModel, Context paramContext);

  public abstract void getCusHistoryDet(RequestModel paramRequestModel, Context paramContext);

  public abstract void getCusPlan(Context paramContext);

  public abstract void getCusPlanCal(RequestModel paramRequestModel, Context paramContext);

  public abstract void getCusSel(RequestModel paramRequestModel, Context paramContext);

  public abstract void getLoseFatPlan(RequestModel paramRequestModel, Context paramContext);

  public abstract void getMonthCusPrev(RequestModel paramRequestModel, Context paramContext);

  public abstract void getTrainActId4Resource(RequestModel paramRequestModel, Context paramContext);

  public abstract void getUserCampComplete(Context paramContext);

  public abstract void getWeekCusPlan(RequestModel paramRequestModel, Context paramContext);

  public abstract void getWeekCusUrl(RequestModel paramRequestModel, Context paramContext);

  public abstract void phyPause(RequestModel paramRequestModel, Context paramContext);

  public abstract void recoveryTraining(RequestModel paramRequestModel, Context paramContext);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterInterface
 * JD-Core Version:    0.6.0
 */