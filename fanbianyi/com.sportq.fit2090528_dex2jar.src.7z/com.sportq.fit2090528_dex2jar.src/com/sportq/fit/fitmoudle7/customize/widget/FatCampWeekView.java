package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RRelativeLayout;
import com.sportq.fit.common.utils.superView.helper.RBaseHelper;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatPlanData;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;

public class FatCampWeekView extends RelativeLayout
{
  private String campType;
  private ArrayList<EntloseFatPlanData> dataList;
  private RBaseHelper rBaseHelper;

  public FatCampWeekView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public FatCampWeekView(Context paramContext, ArrayList<EntloseFatPlanData> paramArrayList, String paramString)
  {
    super(paramContext);
    this.dataList = paramArrayList;
    this.campType = paramString;
    addView(onCreateView());
  }

  private String convertWeekDay(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return "周一";
    case 1:
      return "周一";
    case 2:
      return "周二";
    case 3:
      return "周三";
    case 4:
      return "周四";
    case 5:
      return "周五";
    case 6:
      return "周六";
    case 7:
    }
    return "周日";
  }

  private int dayForWeek(String paramString)
  {
    try
    {
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", new Locale("zh", "CN"));
      Calendar localCalendar = Calendar.getInstance();
      localCalendar.setTime(localSimpleDateFormat.parse(paramString));
      if (localCalendar.get(7) == 1)
        return 7;
      int i = localCalendar.get(7);
      return i - 1;
    }
    catch (ParseException localParseException)
    {
      LogUtils.e(localParseException);
    }
    return -1;
  }

  public View onCreateView()
  {
    LinearLayout localLinearLayout = (LinearLayout)View.inflate(getContext(), R.layout.fat_camp_viewpager_item, null).findViewById(R.id.linearLayout);
    localLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(getContext(), 70.0F)));
    localLinearLayout.setPadding(CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F), 0, 0, 0);
    localLinearLayout.removeAllViews();
    localLinearLayout.setWeightSum(7.0F);
    int i = (BaseApplication.screenWidth - CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F)) / 7 - CompDeviceInfoUtils.convertOfDip(getContext(), 40.0F);
    for (int j = 0; j < 7; j++)
    {
      View localView1 = View.inflate(getContext(), R.layout.fat_camp_day_view, null);
      LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, CompDeviceInfoUtils.convertOfDip(getContext(), 70.0F));
      localLayoutParams.weight = 1.0F;
      if (j == 6)
        localLayoutParams.rightMargin = (CompDeviceInfoUtils.convertOfDip(getContext(), 16.0F) - i);
      localView1.setLayoutParams(localLayoutParams);
      RRelativeLayout localRRelativeLayout = (RRelativeLayout)localView1.findViewById(R.id.fat_camp_day_layout);
      this.rBaseHelper = localRRelativeLayout.getHelper();
      ImageView localImageView1 = (ImageView)localView1.findViewById(R.id.fat_camp_today_img);
      TextView localTextView = (TextView)localView1.findViewById(R.id.fat_camp_day);
      ImageView localImageView2 = (ImageView)localView1.findViewById(R.id.fat_camp_day_state);
      Iterator localIterator = this.dataList.iterator();
      while (localIterator.hasNext())
      {
        EntloseFatPlanData localEntloseFatPlanData = (EntloseFatPlanData)localIterator.next();
        if (dayForWeek(localEntloseFatPlanData.loseFatDate) != j + 1)
          continue;
        if (localEntloseFatPlanData.isToday)
        {
          localImageView1.setVisibility(0);
          if ("2".equals(localEntloseFatPlanData.isTrainDay))
          {
            localRRelativeLayout.setVisibility(0);
            this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_e6e6e6));
            localTextView.setText(convertWeekDay(j + 1));
            localTextView.setVisibility(0);
            localTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
            localView1.findViewById(R.id.delay_hint_view).setVisibility(0);
          }
        }
        while (true)
        {
          localView1.setTag(localEntloseFatPlanData.loseFatDate);
          1 local1 = new View.OnClickListener(localEntloseFatPlanData)
          {
            @Instrumented
            public void onClick(View paramView)
            {
              VdsAgent.onClick(this, paramView);
              if ("2".equals(this.val$entloseFatPlanData.isTrainDay))
                return;
              EventBus.getDefault().post(this.val$entloseFatPlanData);
            }
          };
          localRRelativeLayout.setOnClickListener(local1);
          break;
          if ("3".equals(localEntloseFatPlanData.isTrainDay))
          {
            localRRelativeLayout.setVisibility(0);
            this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.transparent));
            localTextView.setText(convertWeekDay(j + 1));
            localTextView.setVisibility(0);
            localTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_626262));
            continue;
          }
          if ((!StringUtils.isNull(localEntloseFatPlanData.isFinish)) && ("1".equals(localEntloseFatPlanData.isFinish)))
          {
            localRRelativeLayout.setVisibility(0);
            this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_2ac77d));
            localTextView.setVisibility(8);
            localImageView2.setVisibility(0);
            localImageView2.setImageResource(R.mipmap.fat_camp_finished_day);
            continue;
          }
          localRRelativeLayout.setVisibility(0);
          this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_ff6a49));
          localTextView.setVisibility(0);
          localTextView.setText(convertWeekDay(j + 1));
          localTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
          continue;
          localImageView1.setVisibility(4);
          View localView2 = localView1.findViewById(R.id.delay_hint_view);
          if ("2".equals(localEntloseFatPlanData.isTrainDay));
          for (int k = 0; ; k = 4)
          {
            localView2.setVisibility(k);
            if (!"2".equals(localEntloseFatPlanData.trainWeekState))
              break label731;
            localRRelativeLayout.setVisibility(0);
            this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_e6e6e6));
            localTextView.setText(convertWeekDay(j + 1));
            localTextView.setVisibility(0);
            localTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_c8c8c8));
            break;
          }
          label731: if ("3".equals(localEntloseFatPlanData.isTrainDay))
          {
            localRRelativeLayout.setVisibility(0);
            this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.transparent));
            localTextView.setText(convertWeekDay(j + 1));
            localTextView.setVisibility(0);
            localTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_626262));
            continue;
          }
          if ((localEntloseFatPlanData.isNextDay) && ("1".equals(localEntloseFatPlanData.trainWeekState)))
          {
            localRRelativeLayout.setVisibility(0);
            this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.white));
            localTextView.setText(convertWeekDay(j + 1));
            localTextView.setVisibility(0);
            localTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_626262));
            continue;
          }
          if ("2".equals(localEntloseFatPlanData.isTrainDay))
          {
            localRRelativeLayout.setVisibility(0);
            this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_e6e6e6));
            localTextView.setText(convertWeekDay(j + 1));
            localTextView.setVisibility(0);
            localTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
            continue;
          }
          if (StringUtils.isNull(localEntloseFatPlanData.isFinish))
            continue;
          if ("1".equals(localEntloseFatPlanData.isFinish))
          {
            localRRelativeLayout.setVisibility(0);
            this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.color_2ac77d));
            localTextView.setVisibility(8);
            localImageView2.setVisibility(0);
            localImageView2.setImageResource(R.mipmap.fat_camp_finished_day);
            continue;
          }
          if (!"0".equals(localEntloseFatPlanData.isFinish))
            continue;
          localRRelativeLayout.setVisibility(0);
          this.rBaseHelper.setBackgroundColorNormal(ContextCompat.getColor(getContext(), R.color.white));
          localTextView.setVisibility(8);
          localImageView2.setVisibility(0);
          localImageView2.setImageResource(R.mipmap.fat_camp_unfinished_day);
        }
      }
      localLinearLayout.addView(localView1);
    }
    return localLinearLayout;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.FatCampWeekView
 * JD-Core Version:    0.6.0
 */