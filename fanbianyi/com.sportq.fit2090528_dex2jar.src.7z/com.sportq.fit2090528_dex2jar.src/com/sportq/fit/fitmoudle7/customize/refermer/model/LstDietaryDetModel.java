package com.sportq.fit.fitmoudle7.customize.refermer.model;

import java.io.Serializable;
import java.util.ArrayList;

public class LstDietaryDetModel
  implements Serializable
{
  public String calorie;
  public ArrayList<LstMealModel> lstMeal;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.LstDietaryDetModel
 * JD-Core Version:    0.6.0
 */