package com.sportq.fit.fitmoudle7.customize.persenter;

import android.content.Context;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle7.customize.refermer.ChangeCusDietReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.DietRecommendReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.FinishMonthCusReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetCusDataReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetCusHistoryDetReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetCusHistoryReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetCusPlanCalReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetCusSelReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetCustomPlanReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetLoseFatPlanReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetMonthCusPrevReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetTrainActId4ReleaseReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetWeekCusPlanReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.GetWeekCusUrlReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.NoResultReformerImpl;
import com.sportq.fit.fitmoudle7.customize.refermer.UserCampReformerImpl;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.CommonUtils;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;

public class CustomPresenterImpl
  implements CustomPresenterInterface
{
  private ApiInterface api = new ApiImpl();
  private ReformerInterface reformerInterface;
  private FitInterfaceUtils.UIInitListener uiListener;

  public CustomPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.uiListener = paramUIInitListener;
  }

  public void changeCusDietary(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.ChangeCusDietary);
      this.api.getHttp(str, paramContext, this.uiListener, new ChangeCusDietReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusHistoryDet", localException);
    }
  }

  public void exitMonthCus(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.ExitMonthCus);
      ReformerImpl localReformerImpl = new ReformerImpl(new NoResultReformerImpl());
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.exitMonthCus", localException);
    }
  }

  public void feedBackCus(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.FeedBackCus);
      ReformerImpl localReformerImpl = new ReformerImpl(new NoResultReformerImpl());
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.feedBackCus", localException);
    }
  }

  public void finishMonthCus(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.FinishMonthCus);
      this.api.getHttp(str, paramContext, this.uiListener, new FinishMonthCusReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.finishMonthCus", localException);
    }
  }

  public void getCusData(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GetCusData);
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetCusData);
      ReformerImpl localReformerImpl = new ReformerImpl(new GetCusDataReformerImpl());
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusData", localException);
    }
  }

  public void getCusDietary(Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetCusDietary);
      this.api.getHttp(str, paramContext, this.uiListener, new DietRecommendReformerImpl(), new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusHistoryDet", localException);
    }
  }

  public void getCusHistory(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GetCusHistoryReformerImpl());
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetCusHistory);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusHistory", localException);
    }
  }

  public void getCusHistoryDet(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GetCusHistoryDetReformerImpl());
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetCusHistoryDet);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusHistoryDet", localException);
    }
  }

  public void getCusPlan(Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GetCustomPlanReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetCusPlan);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetCusPlan);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusPlan", localException);
    }
  }

  public void getCusPlanCal(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetCusPlanCal);
      ReformerImpl localReformerImpl = new ReformerImpl(new GetCusPlanCalReformerImpl());
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusPlanCal", localException);
    }
  }

  public void getCusSel(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetCusSel);
      ReformerImpl localReformerImpl = new ReformerImpl(new GetCusSelReformerImpl());
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusSel", localException);
    }
  }

  public void getLoseFatPlan(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GetLoseFatPlanReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetLoseFatPlan);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetLoseFatPlan);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusHistoryDet", localException);
    }
  }

  public void getMonthCusPrev(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetMonthCusPrev);
      ReformerImpl localReformerImpl = new ReformerImpl(new GetMonthCusPrevReformerImpl());
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getMonthCusPrev", localException);
    }
  }

  public void getTrainActId4Resource(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetTrainActId4Resource);
      this.api.getHttp(str, paramContext, this.uiListener, new GetTrainActId4ReleaseReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusHistoryDet", localException);
    }
  }

  public void getUserCampComplete(Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetUserCampComplete);
      this.api.getHttp(str, paramContext, this.uiListener, new UserCampReformerImpl(), new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getCusHistoryDet", localException);
    }
  }

  public void getWeekCusPlan(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GetWeekCusPlanReformerImpl());
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetWeekCusPlan);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getWeekCusPlan", localException);
    }
  }

  public void getWeekCusUrl(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetWeekCusUrl);
      ReformerImpl localReformerImpl = new ReformerImpl(new GetWeekCusUrlReformerImpl());
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.getWeekCusUrl", localException);
    }
  }

  public void phyPause(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.PhyPause);
      ReformerImpl localReformerImpl = new ReformerImpl(new NoResultReformerImpl());
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.phyPause", localException);
    }
  }

  public void recoveryTraining(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.RecoveryTraining);
      ReformerImpl localReformerImpl = new ReformerImpl(new NoResultReformerImpl());
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("CustomPresenterImpl.recoveryTraining", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.persenter.CustomPresenterImpl
 * JD-Core Version:    0.6.0
 */