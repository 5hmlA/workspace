package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.CustomizeModel.CustomCalendarEntity;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle7.customize.refermer.model.CustomizeData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer;
import java.util.ArrayList;
import java.util.Iterator;

public class GetCusPlanReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    CustomizeReformer localCustomizeReformer = null;
    if (paramBaseData == null);
    while (true)
    {
      return localCustomizeReformer;
      CustomizeData localCustomizeData = (CustomizeData)paramBaseData;
      ArrayList localArrayList = localCustomizeData.lstMonthCus;
      localCustomizeReformer = null;
      if (localArrayList == null)
        continue;
      int i = localCustomizeData.lstMonthCus.size();
      localCustomizeReformer = null;
      if (i == 0)
        continue;
      localCustomizeReformer = new CustomizeReformer();
      CustomizeModel.CustomDataEntity localCustomDataEntity = new CustomizeModel.CustomDataEntity();
      localCustomDataEntity.curriculumName = localCustomizeData.entCusData.curriculumName;
      localCustomDataEntity.customId = localCustomizeData.entCusData.customId;
      localCustomDataEntity.curriculumDate = localCustomizeData.entCusData.curriculumDate;
      localCustomDataEntity.trainDays = localCustomizeData.entCusData.trainDays;
      localCustomDataEntity.customDays = localCustomizeData.entCusData.customDays;
      localCustomDataEntity.hasTrainNum = localCustomizeData.entCusData.hasTrainNum;
      localCustomDataEntity.trainNum = localCustomizeData.entCusData.trainNum;
      localCustomDataEntity.numberOfParticipants = localCustomizeData.entCusData.numberOfParticipants;
      localCustomDataEntity.imageURL = localCustomizeData.entCusData.imageURL;
      localCustomDataEntity.olapInfo = localCustomizeData.entCusData.olapInfo;
      localCustomDataEntity.shareCurriculumDate = localCustomizeData.entCusData.shareCurriculumDate;
      localCustomDataEntity.shareCustomTotalDays = localCustomizeData.entCusData.shareCustomTotalDays;
      localCustomDataEntity.shareCalorie = localCustomizeData.entCusData.shareCalorie;
      localCustomDataEntity.shareDiffcultName = localCustomizeData.entCusData.shareDiffcultName;
      localCustomDataEntity.targetCode = localCustomizeData.entCusData.targetCode;
      localCustomDataEntity.hasPhyTag = localCustomizeData.entCusData.hasPhyTag;
      localCustomDataEntity.hasHistoryFlag = localCustomizeData.entCusData.hasHistoryFlag;
      localCustomDataEntity.cusIsFinish = localCustomizeData.entCusData.cusIsFinish;
      localCustomizeReformer.entCusData = localCustomDataEntity;
      localCustomizeReformer.lstMonthCus = new ArrayList();
      Iterator localIterator1 = localCustomizeData.lstMonthCus.iterator();
      while (localIterator1.hasNext())
      {
        CustomizeModel.CustomCalendarEntity localCustomCalendarEntity1 = (CustomizeModel.CustomCalendarEntity)localIterator1.next();
        CustomizeModel.CustomCalendarEntity localCustomCalendarEntity2 = new CustomizeModel.CustomCalendarEntity();
        localCustomCalendarEntity2.cusDate = localCustomCalendarEntity1.cusDate;
        localCustomCalendarEntity2.isTrainDay = localCustomCalendarEntity1.isTrainDay;
        localCustomCalendarEntity2.isFeedBackDay = localCustomCalendarEntity1.isFeedBackDay;
        localCustomCalendarEntity2.isFeedBack = localCustomCalendarEntity1.isFeedBack;
        localCustomCalendarEntity2.isFinish = localCustomCalendarEntity1.isFinish;
        localCustomCalendarEntity2.weekId = localCustomCalendarEntity1.weekId;
        localCustomCalendarEntity2.classifyId = localCustomCalendarEntity1.classifyId;
        localCustomCalendarEntity2.feedBackComment = localCustomCalendarEntity1.feedBackComment;
        localCustomCalendarEntity2.lstDayPlan = new ArrayList();
        Iterator localIterator2 = localCustomCalendarEntity1.lstDayPlan.iterator();
        while (localIterator2.hasNext())
        {
          PlanModel localPlanModel1 = (PlanModel)localIterator2.next();
          PlanModel localPlanModel2 = new PlanModel();
          localPlanModel2.customDetailId = localPlanModel1.customDetailId;
          localPlanModel2.histId = localPlanModel1.histId;
          localPlanModel2.planId = localPlanModel1.planId;
          localPlanModel2.planName = localPlanModel1.planName;
          localPlanModel2.trainDuration = localPlanModel1.trainDuration;
          localPlanModel2.calorie = localPlanModel1.calorie;
          localPlanModel2.difficultyLevel = localPlanModel1.difficultyLevel;
          localPlanModel2.apparatus = localPlanModel1.apparatus;
          localPlanModel2.imageURL = localPlanModel1.imageURL;
          localPlanModel2.stateCode = localPlanModel1.stateCode;
          localPlanModel2.olapInfo = localPlanModel1.olapInfo;
          localPlanModel2.isNewTag = localPlanModel1.isNewTag;
          localPlanModel2.isUpdate = localPlanModel1.isUpdate;
          localPlanModel2.trainableDay = localPlanModel1.trainableDay;
          localCustomCalendarEntity2.lstDayPlan.add(localPlanModel2);
        }
        localCustomizeReformer.lstMonthCus.add(localCustomCalendarEntity2);
      }
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (CustomizeData)FitGsonFactory.create().fromJson(paramString2, CustomizeData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.GetCusPlanReformerImpl
 * JD-Core Version:    0.6.0
 */