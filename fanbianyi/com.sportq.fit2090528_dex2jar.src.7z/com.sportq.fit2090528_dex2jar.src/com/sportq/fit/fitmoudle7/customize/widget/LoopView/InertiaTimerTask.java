package com.sportq.fit.fitmoudle7.customize.widget.LoopView;

import android.os.Handler;
import java.util.List;
import java.util.TimerTask;

final class InertiaTimerTask extends TimerTask
{
  float a;
  final LoopView loopView;
  final float velocityY;

  InertiaTimerTask(LoopView paramLoopView, float paramFloat)
  {
    this.loopView = paramLoopView;
    this.velocityY = paramFloat;
    this.a = 2.147484E+009F;
  }

  public final void run()
  {
    if (this.a == 2.147484E+009F)
    {
      if (Math.abs(this.velocityY) <= 2000.0F)
        break label94;
      if (this.velocityY <= 0.0F)
        break label85;
      this.a = 2000.0F;
    }
    while ((Math.abs(this.a) >= 0.0F) && (Math.abs(this.a) <= 20.0F))
    {
      this.loopView.cancelFuture();
      this.loopView.handler.sendEmptyMessage(2000);
      return;
      label85: this.a = -2000.0F;
      continue;
      label94: this.a = this.velocityY;
    }
    int i = (int)(10.0F * this.a / 1000.0F);
    LoopView localLoopView = this.loopView;
    localLoopView.totalScrollY -= i;
    float f;
    if (!this.loopView.isLoop)
    {
      f = this.loopView.lineSpacingMultiplier * this.loopView.maxTextHeight;
      if (this.loopView.totalScrollY <= (int)(f * -this.loopView.initPosition))
      {
        this.a = 40.0F;
        this.loopView.totalScrollY = (int)(f * -this.loopView.initPosition);
      }
    }
    else
    {
      if (this.a >= 0.0F)
        break label324;
      this.a = (20.0F + this.a);
    }
    while (true)
    {
      this.loopView.handler.sendEmptyMessage(1000);
      return;
      if (this.loopView.totalScrollY < (int)(f * (-1 + this.loopView.items.size() - this.loopView.initPosition)))
        break;
      this.loopView.totalScrollY = (int)(f * (-1 + this.loopView.items.size() - this.loopView.initPosition));
      this.a = -40.0F;
      break;
      label324: this.a -= 20.0F;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.LoopView.InertiaTimerTask
 * JD-Core Version:    0.6.0
 */