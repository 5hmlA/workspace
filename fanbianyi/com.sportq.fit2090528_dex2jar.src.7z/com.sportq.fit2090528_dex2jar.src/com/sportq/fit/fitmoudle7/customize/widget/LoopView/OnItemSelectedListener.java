package com.sportq.fit.fitmoudle7.customize.widget.LoopView;

public abstract interface OnItemSelectedListener
{
  public abstract void onItemSelected(int paramInt);
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.LoopView.OnItemSelectedListener
 * JD-Core Version:    0.6.0
 */