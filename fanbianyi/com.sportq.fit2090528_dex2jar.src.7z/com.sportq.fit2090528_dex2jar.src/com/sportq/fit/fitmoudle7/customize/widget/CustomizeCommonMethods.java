package com.sportq.fit.fitmoudle7.customize.widget;

import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.nineoldandroids.view.ViewHelper;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.TrainCustomInfoEntity;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;

public class CustomizeCommonMethods
{
  private int FOCUSCOLOR;
  private int UNFOCUSCOLOR;
  private int animaDuration = 200;
  private int clickIndex;
  private View focusIcon;
  private boolean initFlg;
  private TextView[] introduceViewList;
  private int[] location;
  private Context mContext;
  private TextView[] referViewList;
  private TextView[] titleViewList;

  public CustomizeCommonMethods(Context paramContext, String paramString, FitInterfaceUtils.UIInitListener paramUIInitListener, TextView[] paramArrayOfTextView1, TextView[] paramArrayOfTextView2, View paramView, TextView[] paramArrayOfTextView3)
  {
    this.FOCUSCOLOR = i;
    this.UNFOCUSCOLOR = -10329502;
    this.location = new int[2];
    this.clickIndex = -1;
    this.mContext = paramContext;
    this.titleViewList = paramArrayOfTextView1;
    this.introduceViewList = paramArrayOfTextView2;
    this.referViewList = paramArrayOfTextView3;
    this.focusIcon = paramView;
    if ("0".equals(paramString));
    while (true)
    {
      this.FOCUSCOLOR = i;
      this.initFlg = true;
      return;
      i = -11768;
    }
  }

  public CustomizeCommonMethods(String paramString)
  {
    this.FOCUSCOLOR = i;
    this.UNFOCUSCOLOR = -10329502;
    this.location = new int[2];
    this.clickIndex = -1;
    if ("0".equals(paramString));
    while (true)
    {
      this.FOCUSCOLOR = i;
      return;
      i = -11768;
    }
  }

  private void titleColorAnima(TextView paramTextView, boolean paramBoolean)
  {
    int i;
    if (paramBoolean)
      i = this.UNFOCUSCOLOR;
    for (int j = this.FOCUSCOLOR; ; j = this.UNFOCUSCOLOR)
    {
      2 local2 = new TypeEvaluator()
      {
        public Object evaluate(float paramFloat, Object paramObject1, Object paramObject2)
        {
          int i = ((Integer)paramObject1).intValue();
          int j = 0xFF & i >> 24;
          int k = 0xFF & i >> 16;
          int m = 0xFF & i >> 8;
          int n = i & 0xFF;
          int i1 = ((Integer)paramObject2).intValue();
          int i2 = 0xFF & i1 >> 24;
          int i3 = 0xFF & i1 >> 16;
          int i4 = 0xFF & i1 >> 8;
          int i5 = i1 & 0xFF;
          return Integer.valueOf(j + (int)(paramFloat * (i2 - j)) << 24 | k + (int)(paramFloat * (i3 - k)) << 16 | m + (int)(paramFloat * (i4 - m)) << 8 | n + (int)(paramFloat * (i5 - n)));
        }
      };
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(i);
      arrayOfObject[1] = Integer.valueOf(j);
      ValueAnimator localValueAnimator = ValueAnimator.ofObject(local2, arrayOfObject);
      localValueAnimator.setDuration(this.animaDuration);
      localValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(paramTextView)
      {
        public void onAnimationUpdate(ValueAnimator paramValueAnimator)
        {
          int i = ((Integer)paramValueAnimator.getAnimatedValue()).intValue();
          this.val$textView.setTextColor(i);
        }
      });
      localValueAnimator.start();
      return;
      i = this.FOCUSCOLOR;
    }
  }

  public void introShowOrHideAnima(View paramView1, View paramView2, View paramView3)
  {
    AlphaAnimation localAlphaAnimation1 = new AlphaAnimation(0.0F, 1.0F);
    localAlphaAnimation1.setDuration(this.animaDuration);
    AlphaAnimation localAlphaAnimation2 = new AlphaAnimation(1.0F, 0.0F);
    localAlphaAnimation2.setDuration(this.animaDuration);
    if (paramView1.getVisibility() == 4)
    {
      paramView1.startAnimation(localAlphaAnimation1);
      paramView1.setVisibility(0);
    }
    if (paramView2.getVisibility() == 0)
    {
      paramView2.startAnimation(localAlphaAnimation2);
      paramView2.setVisibility(4);
    }
    if (paramView3.getVisibility() == 0)
    {
      paramView3.startAnimation(localAlphaAnimation2);
      paramView3.setVisibility(4);
    }
  }

  public void introShowOrHideAnima(View[] paramArrayOfView, int paramInt)
  {
    AlphaAnimation localAlphaAnimation1 = new AlphaAnimation(0.0F, 1.0F);
    localAlphaAnimation1.setDuration(this.animaDuration);
    AlphaAnimation localAlphaAnimation2 = new AlphaAnimation(1.0F, 0.0F);
    localAlphaAnimation2.setDuration(this.animaDuration);
    int i = 0;
    if (i < paramArrayOfView.length)
    {
      if (i == paramInt)
        if (paramArrayOfView[i].getVisibility() == 4)
        {
          paramArrayOfView[i].startAnimation(localAlphaAnimation1);
          paramArrayOfView[i].setVisibility(0);
        }
      while (true)
      {
        i++;
        break;
        if (paramArrayOfView[i].getVisibility() != 0)
          continue;
        paramArrayOfView[i].startAnimation(localAlphaAnimation2);
        paramArrayOfView[i].setVisibility(4);
      }
    }
  }

  public void jumpActivity(Context paramContext, TrainCustomInfoEntity paramTrainCustomInfoEntity, Class<?> paramClass)
  {
    Intent localIntent = new Intent(paramContext, paramClass);
    Bundle localBundle = new Bundle();
    localBundle.putSerializable("custom_info_entity", paramTrainCustomInfoEntity);
    localIntent.putExtras(localBundle);
    paramContext.startActivity(localIntent);
    AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
  }

  public void setColors(int paramInt1, int paramInt2)
  {
    this.FOCUSCOLOR = paramInt1;
    this.UNFOCUSCOLOR = paramInt2;
  }

  public void startClickAnimation(int paramInt)
  {
    while (true)
    {
      int j;
      try
      {
        if (this.clickIndex == paramInt)
          return;
        this.clickIndex = paramInt;
        this.introduceViewList[paramInt].setVisibility(0);
        j = 0;
        if (j >= this.titleViewList.length)
          continue;
        if (j != paramInt)
          continue;
        if (this.titleViewList[paramInt].getCurrentTextColor() != this.FOCUSCOLOR)
        {
          this.titleViewList[paramInt].setTextColor(this.FOCUSCOLOR);
          break label223;
          if (this.titleViewList[j].getCurrentTextColor() == this.FOCUSCOLOR)
          {
            this.introduceViewList[j].setVisibility(8);
            this.titleViewList[j].setTextColor(this.UNFOCUSCOLOR);
          }
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        this.focusIcon.setVisibility(4);
        if (this.clickIndex == -1)
          continue;
        int i = 0;
        if (i >= this.titleViewList.length)
          continue;
        if (i != this.clickIndex)
          continue;
        this.titleViewList[this.clickIndex].setTextColor(this.FOCUSCOLOR);
        i++;
        continue;
        this.titleViewList[paramInt].post(new Runnable(paramInt)
        {
          public void run()
          {
            int i = 0;
            try
            {
              int[] arrayOfInt1 = new int[2];
              CustomizeCommonMethods.this.referViewList[this.val$index].getLocationInWindow(arrayOfInt1);
              if (CustomizeCommonMethods.this.initFlg)
              {
                RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)CustomizeCommonMethods.this.focusIcon.getLayoutParams();
                localLayoutParams.height = CompDeviceInfoUtils.convertOfDip(CustomizeCommonMethods.this.mContext, 28.0F);
                CustomizeCommonMethods.this.focusIcon.setLayoutParams(localLayoutParams);
                CustomizeCommonMethods.this.focusIcon.setX(CompDeviceInfoUtils.convertOfDip(CustomizeCommonMethods.this.mContext, 60.0F));
                CustomizeCommonMethods.this.focusIcon.setY(arrayOfInt1[1] + CompDeviceInfoUtils.convertOfDip(CustomizeCommonMethods.this.mContext, 9.0F) - CompDeviceInfoUtils.getStatusBarHeight(CustomizeCommonMethods.this.mContext));
                new Handler().postDelayed(new Runnable()
                {
                  public void run()
                  {
                    CustomizeCommonMethods.this.focusIcon.setVisibility(0);
                  }
                }
                , CustomizeCommonMethods.this.animaDuration);
                TextView[] arrayOfTextView = CustomizeCommonMethods.this.titleViewList;
                int j = arrayOfTextView.length;
                while (i < j)
                {
                  TextView localTextView = arrayOfTextView[i];
                  int[] arrayOfInt2 = new int[2];
                  localTextView.getLocationInWindow(arrayOfInt2);
                  int k = -(arrayOfInt2[0] - CompDeviceInfoUtils.convertOfDip(CustomizeCommonMethods.this.mContext, 60.0F) - CompDeviceInfoUtils.convertOfDip(CustomizeCommonMethods.this.mContext, 17.0F));
                  TranslateAnimation localTranslateAnimation2 = new TranslateAnimation(0.0F, k, 0.0F, 0.0F);
                  localTranslateAnimation2.setDuration(CustomizeCommonMethods.this.animaDuration);
                  localTextView.startAnimation(localTranslateAnimation2);
                  localTranslateAnimation2.setAnimationListener(new Animation.AnimationListener(localTextView, k)
                  {
                    public void onAnimationEnd(Animation paramAnimation)
                    {
                      this.val$textView.clearAnimation();
                      ViewHelper.setTranslationX(this.val$textView, this.val$transX);
                    }

                    public void onAnimationRepeat(Animation paramAnimation)
                    {
                    }

                    public void onAnimationStart(Animation paramAnimation)
                    {
                    }
                  });
                  i++;
                }
                CustomizeCommonMethods.access$202(CustomizeCommonMethods.this, false);
              }
              CustomizeCommonMethods.this.focusIcon.getLocationInWindow(CustomizeCommonMethods.this.location);
              TranslateAnimation localTranslateAnimation1 = new TranslateAnimation(0.0F, 0.0F, 0.0F, arrayOfInt1[1] + CompDeviceInfoUtils.convertOfDip(CustomizeCommonMethods.this.mContext, 9.0F) - CustomizeCommonMethods.this.location[1]);
              localTranslateAnimation1.setDuration(CustomizeCommonMethods.this.animaDuration);
              CustomizeCommonMethods.this.focusIcon.startAnimation(localTranslateAnimation1);
              localTranslateAnimation1.setAnimationListener(new Animation.AnimationListener(arrayOfInt1)
              {
                public void onAnimationEnd(Animation paramAnimation)
                {
                  CustomizeCommonMethods.this.focusIcon.clearAnimation();
                  ViewHelper.setTranslationX(CustomizeCommonMethods.this.focusIcon, CompDeviceInfoUtils.convertOfDip(CustomizeCommonMethods.this.mContext, 60.0F));
                  ViewHelper.setTranslationY(CustomizeCommonMethods.this.focusIcon, this.val$initLocation[1] + CompDeviceInfoUtils.convertOfDip(CustomizeCommonMethods.this.mContext, 9.0F) - CompDeviceInfoUtils.getStatusBarHeight(CustomizeCommonMethods.this.mContext));
                }

                public void onAnimationRepeat(Animation paramAnimation)
                {
                }

                public void onAnimationStart(Animation paramAnimation)
                {
                }
              });
              return;
            }
            catch (Exception localException)
            {
              LogUtils.e(localException);
              CustomizeCommonMethods.this.focusIcon.setVisibility(4);
            }
          }
        });
        return;
        this.titleViewList[this.clickIndex].setTextColor(this.UNFOCUSCOLOR);
        continue;
        return;
      }
      label223: j++;
    }
  }

  public void titleColorIsAnima(TextView paramTextView1, TextView paramTextView2, TextView paramTextView3)
  {
    if (this.FOCUSCOLOR != paramTextView1.getCurrentTextColor())
      titleColorAnima(paramTextView1, true);
    if (this.UNFOCUSCOLOR != paramTextView2.getCurrentTextColor())
      titleColorAnima(paramTextView2, false);
    if (this.UNFOCUSCOLOR != paramTextView3.getCurrentTextColor())
      titleColorAnima(paramTextView3, false);
  }

  public void titleColorIsAnima(RelativeLayout[] paramArrayOfRelativeLayout, TextView[] paramArrayOfTextView, View[] paramArrayOfView, int paramInt)
  {
    introShowOrHideAnima(paramArrayOfView, paramInt);
    int i = 0;
    if (i < paramArrayOfTextView.length)
    {
      if (i == paramInt)
        if (this.FOCUSCOLOR != paramArrayOfTextView[i].getCurrentTextColor())
          AnimationUtil.fontColorGradientAnimation(paramArrayOfTextView[i], this.UNFOCUSCOLOR, this.FOCUSCOLOR, this.animaDuration).addUpdateListener(new ValueAnimator.AnimatorUpdateListener(paramArrayOfRelativeLayout)
          {
            public void onAnimationUpdate(ValueAnimator paramValueAnimator)
            {
              if (((Integer)paramValueAnimator.getAnimatedValue()).intValue() != CustomizeCommonMethods.this.FOCUSCOLOR)
              {
                RelativeLayout[] arrayOfRelativeLayout2 = this.val$contentList;
                int k = arrayOfRelativeLayout2.length;
                for (int m = 0; m < k; m++)
                  arrayOfRelativeLayout2[m].setEnabled(false);
              }
              RelativeLayout[] arrayOfRelativeLayout1 = this.val$contentList;
              int i = arrayOfRelativeLayout1.length;
              for (int j = 0; j < i; j++)
                arrayOfRelativeLayout1[j].setEnabled(true);
            }
          });
      while (true)
      {
        i++;
        break;
        if (this.UNFOCUSCOLOR == paramArrayOfTextView[i].getCurrentTextColor())
          continue;
        AnimationUtil.fontColorGradientAnimation(paramArrayOfTextView[i], this.FOCUSCOLOR, this.UNFOCUSCOLOR, this.animaDuration);
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomizeCommonMethods
 * JD-Core Version:    0.6.0
 */