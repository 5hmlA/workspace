package com.sportq.fit.fitmoudle7.customize.widget.Calendar;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.sportq.fit.common.model.CustomizeModel.CustomCalendarListEntity;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle7.R.layout;
import java.util.ArrayList;

public class CustomizeCalendarView extends LinearLayout
{
  private CalendarAdapter calV = null;
  private Context mContext;
  private SpecialCalendar sc = null;

  public CustomizeCalendarView(Context paramContext)
  {
    super(paramContext);
    setOrientation(1);
    this.mContext = paramContext;
    addView(LayoutInflater.from(this.mContext).inflate(R.layout.whole_week_title, null));
  }

  public CustomizeCalendarView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    setOrientation(1);
    this.mContext = paramContext;
    addView(LayoutInflater.from(this.mContext).inflate(R.layout.whole_week_title, null));
  }

  public CustomizeCalendarView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    setOrientation(1);
    this.mContext = paramContext;
    addView(LayoutInflater.from(this.mContext).inflate(R.layout.whole_week_title, null));
  }

  public void onCreateCalendar(ArrayList<CustomizeModel.CustomCalendarListEntity> paramArrayList, boolean paramBoolean)
  {
    removeViews(1, -1 + getChildCount());
    this.sc = new SpecialCalendar();
    int i = 0;
    if (i < paramArrayList.size())
    {
      int j;
      label39: GridView localGridView;
      int k;
      if (i == 0)
      {
        j = 0;
        this.calV = new CalendarAdapter(this.mContext, j, ((CustomizeModel.CustomCalendarListEntity)paramArrayList.get(i)).lstMonthCus, paramBoolean);
        localGridView = new GridView(this.mContext);
        localGridView.setNumColumns(7);
        localGridView.setGravity(17);
        localGridView.setSelector(new ColorDrawable(0));
        localGridView.setVerticalSpacing(0);
        localGridView.setHorizontalSpacing(0);
        localGridView.setAdapter(this.calV);
        k = localGridView.getCount() / 7;
        if (localGridView.getCount() % 7 != 0)
          break label235;
      }
      label235: for (int m = 0; ; m = 1)
      {
        int n = k + m;
        int i1 = CompDeviceInfoUtils.convertOfDip(this.mContext, 50.0F);
        localGridView.setLayoutParams(new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 80.5F) + i1 * (n - 1)));
        addView(localGridView);
        i++;
        break;
        if (i == -1 + paramArrayList.size())
        {
          j = 1;
          break label39;
        }
        j = 2;
        break label39;
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.Calendar.CustomizeCalendarView
 * JD-Core Version:    0.6.0
 */