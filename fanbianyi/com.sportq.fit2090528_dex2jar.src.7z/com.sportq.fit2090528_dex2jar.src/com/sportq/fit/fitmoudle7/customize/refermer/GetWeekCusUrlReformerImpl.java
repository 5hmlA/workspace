package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.data.VideoInfoData;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.CustomizeModel.CustomUrlEntity;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle7.customize.refermer.model.CustomizeData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.DownLoadReformer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class GetWeekCusUrlReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    DownLoadReformer localDownLoadReformer = null;
    if (paramBaseData == null);
    while (true)
    {
      return localDownLoadReformer;
      CustomizeData localCustomizeData = (CustomizeData)paramBaseData;
      ArrayList localArrayList = localCustomizeData.lstRet;
      localDownLoadReformer = null;
      if (localArrayList == null)
        continue;
      int i = localCustomizeData.lstRet.size();
      localDownLoadReformer = null;
      if (i == 0)
        continue;
      localDownLoadReformer = new DownLoadReformer();
      localDownLoadReformer.linkUrls = new ArrayList();
      localDownLoadReformer.linkSizes = new ArrayList();
      localDownLoadReformer.musicInfoList = new ArrayList();
      Iterator localIterator1 = localCustomizeData.lstRet.iterator();
      while (localIterator1.hasNext())
      {
        CustomizeModel.CustomUrlEntity localCustomUrlEntity = (CustomizeModel.CustomUrlEntity)localIterator1.next();
        localDownLoadReformer.linkUrls.add(localCustomUrlEntity.linkUrl);
        localDownLoadReformer.linkSizes.add(localCustomUrlEntity.linkSize);
        if (StringUtils.isNull(localCustomUrlEntity.musicId))
          continue;
        VideoInfoData localVideoInfoData = new VideoInfoData();
        localVideoInfoData.musicId = localCustomUrlEntity.musicId;
        localVideoInfoData.categoryId = localCustomUrlEntity.categoryId;
        localVideoInfoData.musicName = localCustomUrlEntity.musicName;
        localVideoInfoData.linkUrl = localCustomUrlEntity.linkUrl;
        localDownLoadReformer.musicInfoList.add(localVideoInfoData);
      }
      localDownLoadReformer.linkIds = new ArrayList();
      Iterator localIterator2 = localCustomizeData.lstPid.iterator();
      while (localIterator2.hasNext())
      {
        String str = (String)localIterator2.next();
        localDownLoadReformer.linkIds.add(str);
      }
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    CustomizeData localCustomizeData = (CustomizeData)FitGsonFactory.create().fromJson(paramString2, CustomizeData.class);
    LogUtils.d("FileCache设置一级缓存", paramString1);
    BaseApplication.dataCache.put(paramString1, localCustomizeData);
    return dataToReformer(paramString1, localCustomizeData, paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.GetWeekCusUrlReformerImpl
 * JD-Core Version:    0.6.0
 */