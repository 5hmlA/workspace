package com.sportq.fit.fitmoudle7.customize.widget.Calendar;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.model.CustomizeModel.CustomCalendarEntity;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.activity.TrainAboutFeedbackActivity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class CalendarAdapter extends BaseAdapter
{
  private Calendar calendarNow = Calendar.getInstance();
  private String currentDay = "";
  private String currentMonth = "";
  private String currentYear = "";
  private CalendarDayEntity[] dayNumber = null;
  private int dayOfWeek = 0;
  private int daysOfMonth = 0;
  private boolean isLeapyear = false;
  private Context mContext;
  private RTextViewHelper rTextViewHelper;
  private SpecialCalendar sc = null;
  private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
  private int tag;
  private boolean todayShowFlg;

  public CalendarAdapter()
  {
  }

  public CalendarAdapter(Context paramContext, int paramInt, ArrayList<CustomizeModel.CustomCalendarEntity> paramArrayList, boolean paramBoolean)
  {
    this();
    this.mContext = paramContext;
    this.tag = paramInt;
    this.todayShowFlg = paramBoolean;
    this.sc = new SpecialCalendar();
    this.currentYear = ((CustomizeModel.CustomCalendarEntity)paramArrayList.get(0)).cusDate.split("-")[0];
    this.currentMonth = ((CustomizeModel.CustomCalendarEntity)paramArrayList.get(0)).cusDate.split("-")[1];
    int i;
    if (paramInt == 0)
    {
      this.currentDay = ((CustomizeModel.CustomCalendarEntity)paramArrayList.get(0)).cusDate.split("-")[2];
      this.dayOfWeek = this.sc.getWeekdayOfMonth(Integer.parseInt(this.currentYear), Integer.parseInt(this.currentMonth), Integer.parseInt(this.currentDay));
      if (Integer.parseInt(this.currentDay) - this.dayOfWeek > 0)
        i = Integer.parseInt(this.currentDay) - this.dayOfWeek;
    }
    for (this.currentDay = String.valueOf(i); ; this.currentDay = String.valueOf(1))
    {
      getCalendar(Integer.parseInt(this.currentYear), Integer.parseInt(this.currentMonth), Integer.parseInt(this.currentDay), paramArrayList);
      return;
      i = 1;
      break;
    }
  }

  private void getWeek(int paramInt1, int paramInt2, int paramInt3, ArrayList<CustomizeModel.CustomCalendarEntity> paramArrayList)
  {
    int i = 0;
    label38: label174: if (i < this.dayNumber.length)
    {
      CalendarDayEntity localCalendarDayEntity = new CalendarDayEntity();
      if (i < this.dayOfWeek)
      {
        localCalendarDayEntity.dayNum = "";
        if (i >= 7)
          break label413;
        localCalendarDayEntity.monthTitle = String.valueOf(paramInt2);
      }
      label54: label453: label462: label487: for (int j = 0; ; j++)
        while (true)
        {
          String str;
          label127: boolean bool;
          Calendar localCalendar;
          if (j < paramArrayList.size())
          {
            if (!"0".equals(((CustomizeModel.CustomCalendarEntity)paramArrayList.get(j)).cusDate.split("-")[2].substring(0, 1)))
              break label423;
            str = ((CustomizeModel.CustomCalendarEntity)paramArrayList.get(j)).cusDate.split("-")[2].substring(1, 2);
            if (!String.valueOf(paramInt3 + (i - this.dayOfWeek)).equals(str))
              break label487;
            if (!"1".equals(((CustomizeModel.CustomCalendarEntity)paramArrayList.get(j)).isFeedBackDay))
              break label453;
            localCalendarDayEntity.isFeedBackDay = true;
            localCalendarDayEntity.isTrainDay = ((CustomizeModel.CustomCalendarEntity)paramArrayList.get(j)).isTrainDay;
            if ((StringUtils.isNull(((CustomizeModel.CustomCalendarEntity)paramArrayList.get(j)).isFinish)) || ("0".equals(((CustomizeModel.CustomCalendarEntity)paramArrayList.get(j)).isFinish)))
              break label462;
            bool = true;
            localCalendarDayEntity.isFinish = bool;
            localCalendarDayEntity.isDaysOfTrainWeek = true;
            localCalendar = null;
          }
          try
          {
            Date localDate = this.sdf.parse(((CustomizeModel.CustomCalendarEntity)paramArrayList.get(j)).cusDate);
            localCalendar = Calendar.getInstance();
            localCalendar.setTime(localDate);
            if ((localCalendar != null) && (this.calendarNow.get(1) == localCalendar.get(1)) && (this.calendarNow.get(2) == localCalendar.get(2)) && (this.calendarNow.get(5) == localCalendar.get(5)))
            {
              localCalendarDayEntity.isToday = true;
              this.dayNumber[i] = localCalendarDayEntity;
              i++;
              break;
              if (i > this.daysOfMonth - paramInt3 + this.dayOfWeek)
                break label38;
              localCalendarDayEntity.dayNum = (paramInt3 + (i - this.dayOfWeek) + "");
              break label38;
              localCalendarDayEntity.monthTitle = "";
              break label54;
              str = ((CustomizeModel.CustomCalendarEntity)paramArrayList.get(j)).cusDate.split("-")[2].substring(0, 2);
              break label127;
              localCalendarDayEntity.isFeedBackDay = false;
              break label174;
              bool = false;
            }
          }
          catch (ParseException localParseException)
          {
            while (true)
            {
              localParseException.printStackTrace();
              continue;
              localCalendarDayEntity.isToday = false;
            }
          }
        }
    }
    label413: label423: return;
  }

  public void getCalendar(int paramInt1, int paramInt2, int paramInt3, ArrayList<CustomizeModel.CustomCalendarEntity> paramArrayList)
  {
    this.isLeapyear = this.sc.isLeapYear(paramInt1);
    this.daysOfMonth = this.sc.getDaysOfMonth(this.isLeapyear, paramInt2);
    this.dayOfWeek = this.sc.getWeekdayOfMonth(paramInt1, paramInt2, paramInt3);
    if (this.tag != 1);
    for (this.dayNumber = new CalendarDayEntity[1 + (this.daysOfMonth - paramInt3 + this.dayOfWeek)]; ; this.dayNumber = new CalendarDayEntity[7 * this.sc.getWeek(paramInt1, paramInt2, Integer.parseInt(((CustomizeModel.CustomCalendarEntity)paramArrayList.get(-1 + paramArrayList.size())).cusDate.split("-")[2]))])
    {
      getWeek(paramInt1, paramInt2, paramInt3, paramArrayList);
      return;
    }
  }

  public int getCount()
  {
    return this.dayNumber.length;
  }

  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView1 = LayoutInflater.from(this.mContext).inflate(R.layout.calendar_item, null);
    RTextView localRTextView = (RTextView)localView1.findViewById(R.id.calendar_tagIcon);
    this.rTextViewHelper = localRTextView.getHelper();
    TextView localTextView1 = (TextView)localView1.findViewById(R.id.calendar_tvDate);
    TextView localTextView2 = (TextView)localView1.findViewById(R.id.calendar_noteInfo);
    TextView localTextView3 = (TextView)localView1.findViewById(R.id.month_title);
    View localView2 = localView1.findViewById(R.id.month_line);
    ImageView localImageView = (ImageView)localView1.findViewById(R.id.calendar_finishedoral);
    RelativeLayout localRelativeLayout = (RelativeLayout)localView1.findViewById(R.id.item_rl);
    CalendarDayEntity localCalendarDayEntity = this.dayNumber[paramInt];
    String str1 = localCalendarDayEntity.dayNum;
    String str2 = localCalendarDayEntity.monthTitle;
    if (!StringUtils.isNull(str1))
      localTextView1.setText(str1);
    if ((!StringUtils.isNull(str2)) && (!StringUtils.isNull(str1)))
    {
      localTextView3.setText(String.valueOf(str2 + this.mContext.getString(R.string.month)));
      label384: if (paramInt == this.dayOfWeek)
      {
        localTextView3.setVisibility(0);
        localView2.setVisibility(0);
        label222: if (!StringUtils.isNull(str1))
          break label435;
        localRTextView.setVisibility(4);
        localTextView2.setVisibility(4);
        label242: if (!localCalendarDayEntity.isDaysOfTrainWeek)
          break label653;
        localTextView1.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
        if (!"0".equals(localCalendarDayEntity.isTrainDay))
          break label474;
        localRTextView.setVisibility(4);
        localTextView1.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
        label299: if ((this.todayShowFlg) && (localCalendarDayEntity.isToday))
        {
          if (!"2".equals(localCalendarDayEntity.isTrainDay))
            localTextView2.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_dbb76a));
          if (localRTextView.getVisibility() != 0)
            break label617;
          localTextView1.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
          this.rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this.mContext, R.color.color_dbb76a));
          localTextView1.setTypeface(Typeface.DEFAULT_BOLD);
        }
      }
    }
    while (true)
    {
      if (!localCalendarDayEntity.isFinish)
        break label668;
      localImageView.setVisibility(0);
      return localView1;
      localTextView3.setVisibility(4);
      break;
      localTextView3.setVisibility(8);
      localView2.setVisibility(8);
      break label222;
      label435: if (localCalendarDayEntity.isFeedBackDay)
      {
        localTextView2.setVisibility(0);
        localRelativeLayout.setOnClickListener(new View.OnClickListener()
        {
          @Instrumented
          public void onClick(View paramView)
          {
            VdsAgent.onClick(this, paramView);
            Intent localIntent = new Intent(CalendarAdapter.this.mContext, TrainAboutFeedbackActivity.class);
            CalendarAdapter.this.mContext.startActivity(localIntent);
            AnimationUtil.pageJumpAnim((Activity)CalendarAdapter.this.mContext, 0);
          }
        });
        break label242;
      }
      localTextView2.setVisibility(4);
      break label242;
      label474: if ("1".equals(localCalendarDayEntity.isTrainDay))
      {
        this.rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this.mContext, R.color.color_e6e6e6));
        localRTextView.setVisibility(0);
        localTextView1.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
        break label299;
      }
      if (!"2".equals(localCalendarDayEntity.isTrainDay))
        break label299;
      this.rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this.mContext, R.color.color_313131));
      localRTextView.setVisibility(0);
      localTextView1.setTextColor(ContextCompat.getColor(this.mContext, R.color.white));
      localTextView2.setText(UseStringUtils.getStr(R.string.a_8_2_1));
      localTextView2.setVisibility(0);
      localTextView2.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_313131));
      break label299;
      label617: this.rTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(this.mContext, R.color.color_e6e6e6));
      localTextView1.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_dbb76a));
      break label384;
      label653: localRTextView.setVisibility(4);
      localTextView1.setVisibility(4);
    }
    label668: localImageView.setVisibility(4);
    return localView1;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.Calendar.CalendarAdapter
 * JD-Core Version:    0.6.0
 */