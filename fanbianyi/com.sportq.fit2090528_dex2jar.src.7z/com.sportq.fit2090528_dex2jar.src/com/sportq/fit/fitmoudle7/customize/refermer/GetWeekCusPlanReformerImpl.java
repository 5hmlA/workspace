package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.CustomizeModel.CustomSinglePlanEntity;
import com.sportq.fit.common.model.CustomizeModel.CustomWeekEntity;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle7.customize.refermer.model.CustomizeData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer;
import java.util.ArrayList;
import java.util.Iterator;

public class GetWeekCusPlanReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    CustomizeReformer localCustomizeReformer = null;
    if (paramBaseData == null);
    while (true)
    {
      return localCustomizeReformer;
      CustomizeData localCustomizeData = (CustomizeData)paramBaseData;
      ArrayList localArrayList = localCustomizeData.lstWeekPlan;
      localCustomizeReformer = null;
      if (localArrayList == null)
        continue;
      int i = localCustomizeData.lstWeekPlan.size();
      localCustomizeReformer = null;
      if (i == 0)
        continue;
      localCustomizeReformer = new CustomizeReformer();
      localCustomizeReformer.adjustComment = localCustomizeData.adjustComment;
      localCustomizeReformer.lstWeekPlan = new ArrayList();
      Iterator localIterator1 = localCustomizeData.lstWeekPlan.iterator();
      while (localIterator1.hasNext())
      {
        CustomizeModel.CustomWeekEntity localCustomWeekEntity1 = (CustomizeModel.CustomWeekEntity)localIterator1.next();
        CustomizeModel.CustomWeekEntity localCustomWeekEntity2 = new CustomizeModel.CustomWeekEntity();
        localCustomWeekEntity2.curriculumDate = localCustomWeekEntity1.curriculumDate;
        localCustomWeekEntity2.noDay = localCustomWeekEntity1.noDay;
        localCustomWeekEntity2.isTrainDay = localCustomWeekEntity1.isTrainDay;
        localCustomWeekEntity2.isFeedBackDay = localCustomWeekEntity1.isFeedBackDay;
        localCustomWeekEntity2.lstDayPlan = new ArrayList();
        Iterator localIterator2 = localCustomWeekEntity1.lstDayPlan.iterator();
        while (localIterator2.hasNext())
        {
          CustomizeModel.CustomSinglePlanEntity localCustomSinglePlanEntity1 = (CustomizeModel.CustomSinglePlanEntity)localIterator2.next();
          CustomizeModel.CustomSinglePlanEntity localCustomSinglePlanEntity2 = new CustomizeModel.CustomSinglePlanEntity();
          localCustomSinglePlanEntity2.planId = localCustomSinglePlanEntity1.planId;
          localCustomSinglePlanEntity2.histId = localCustomSinglePlanEntity1.histId;
          localCustomSinglePlanEntity2.planName = localCustomSinglePlanEntity1.planName;
          localCustomSinglePlanEntity2.trainDuration = localCustomSinglePlanEntity1.trainDuration;
          localCustomSinglePlanEntity2.calorie = localCustomSinglePlanEntity1.calorie;
          localCustomSinglePlanEntity2.difficultyLevel = localCustomSinglePlanEntity1.difficultyLevel;
          localCustomSinglePlanEntity2.apparatus = localCustomSinglePlanEntity1.apparatus;
          localCustomSinglePlanEntity2.stateCode = localCustomSinglePlanEntity1.stateCode;
          localCustomSinglePlanEntity2.olapInfo = localCustomSinglePlanEntity1.olapInfo;
          localCustomSinglePlanEntity2.trainableDay = localCustomSinglePlanEntity1.trainableDay;
          localCustomWeekEntity2.lstDayPlan.add(localCustomSinglePlanEntity2);
        }
        localCustomizeReformer.lstWeekPlan.add(localCustomWeekEntity2);
      }
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (CustomizeData)FitGsonFactory.create().fromJson(paramString2, CustomizeData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.GetWeekCusPlanReformerImpl
 * JD-Core Version:    0.6.0
 */