package com.sportq.fit.fitmoudle7.customize.widget.Calendar;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SpecialCalendar
{
  private int dayOfWeek = 0;
  private int daysOfMonth = 0;

  public int countMonths(String paramString1, String paramString2, String paramString3)
    throws ParseException
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(paramString3);
    Calendar localCalendar1 = Calendar.getInstance();
    Calendar localCalendar2 = Calendar.getInstance();
    localCalendar1.setTime(localSimpleDateFormat.parse(paramString1));
    localCalendar2.setTime(localSimpleDateFormat.parse(paramString2));
    int i = localCalendar2.get(1) - localCalendar1.get(1);
    if (i < 0)
      return 12 * -i + localCalendar1.get(2) - localCalendar2.get(2);
    return 1 + (i * 12 + localCalendar2.get(2) - localCalendar1.get(2));
  }

  public int daysBetween(Date paramDate1, Date paramDate2)
    throws ParseException
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date localDate1 = localSimpleDateFormat.parse(localSimpleDateFormat.format(paramDate1));
    Date localDate2 = localSimpleDateFormat.parse(localSimpleDateFormat.format(paramDate2));
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.setTime(localDate1);
    long l = localCalendar.getTimeInMillis();
    localCalendar.setTime(localDate2);
    return Integer.parseInt(String.valueOf((localCalendar.getTimeInMillis() - l) / 86400000L));
  }

  public int getDaysOfMonth(boolean paramBoolean, int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
    case 4:
    case 6:
    case 9:
    case 11:
    case 2:
    }
    while (true)
    {
      return this.daysOfMonth;
      this.daysOfMonth = 31;
      continue;
      this.daysOfMonth = 30;
      continue;
      if (paramBoolean)
      {
        this.daysOfMonth = 29;
        continue;
      }
      this.daysOfMonth = 28;
    }
  }

  public int getWeek(int paramInt1, int paramInt2, int paramInt3)
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(paramInt1, paramInt2 - 1, paramInt3);
    return localCalendar.get(4);
  }

  public int getWeekdayOfMonth(int paramInt1, int paramInt2, int paramInt3)
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(paramInt1, paramInt2 - 1, paramInt3);
    if (paramInt3 == -1)
    {
      localCalendar.set(paramInt1, paramInt2 - 1, 1);
      localCalendar.add(5, -1);
    }
    this.dayOfWeek = (-1 + localCalendar.get(7));
    return this.dayOfWeek;
  }

  public boolean isLeapYear(int paramInt)
  {
    if ((paramInt % 100 == 0) && (paramInt % 400 == 0));
    do
      return true;
    while ((paramInt % 100 != 0) && (paramInt % 4 == 0));
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.Calendar.SpecialCalendar
 * JD-Core Version:    0.6.0
 */