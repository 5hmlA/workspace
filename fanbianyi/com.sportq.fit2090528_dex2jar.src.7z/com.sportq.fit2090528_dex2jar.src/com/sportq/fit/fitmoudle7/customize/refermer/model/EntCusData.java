package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.BaseData;
import java.io.Serializable;

public class EntCusData extends BaseData
  implements Serializable
{
  public String curriculumDate;
  public String curriculumName;
  public String cusIsFinish;
  public String customDays;
  public String customId;
  public String finishCalorie;
  public String finishDays;
  public String hasHistoryFlag;
  public String hasPhyTag;
  public String hasTrainNum;
  public String imageURL;
  public String numberOfParticipants;
  public String olapInfo;
  public String shareCalorie;
  public String shareCurriculumDate;
  public String shareCustomTotalDays;
  public String shareDiffcultName;
  public String targetCode;
  public String totalCalorie;
  public String totalDays;
  public String trainDays;
  public String trainNum;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusData
 * JD-Core Version:    0.6.0
 */