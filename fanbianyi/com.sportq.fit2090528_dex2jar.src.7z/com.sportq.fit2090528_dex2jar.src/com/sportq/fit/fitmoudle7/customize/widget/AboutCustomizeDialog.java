package com.sportq.fit.fitmoudle7.customize.widget;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.LuBanUtils;
import com.sportq.fit.common.utils.LuBanUtils.PressCallBack;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.sharemanager.ShareListenerFunction;
import com.sportq.fit.fitmoudle.sharemanager.ShareManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.PlayPointModel;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.R.style;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntCusData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntloseFatData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstDayPlanData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstMonthCusData;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;

public class AboutCustomizeDialog
{
  private Context mContext;
  private Dialog mDialog;

  public AboutCustomizeDialog(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private View initCustomizeView(View paramView, EntCusData paramEntCusData, EntlstMonthCusData paramEntlstMonthCusData)
  {
    ImageView localImageView1 = (ImageView)paramView.findViewById(R.id.share_user_img);
    GlideUtils.loadImgByCircle(BaseApplication.userModel.userImg, R.mipmap.avatar_default, localImageView1);
    ((TextView)paramView.findViewById(R.id.share_user_name)).setText(BaseApplication.userModel.userName);
    TextView localTextView1 = (TextView)paramView.findViewById(R.id.fat_camp_class_hint);
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramEntCusData.curriculumName;
    localTextView1.setText(String.format("28天%s", arrayOfObject));
    ((TextView)paramView.findViewById(R.id.share_date)).setText(new SimpleDateFormat("yyyy年M月d日", new Locale("zh", "CN")).format(Calendar.getInstance().getTime()));
    LinearLayout localLinearLayout1 = (LinearLayout)paramView.findViewById(R.id.train_date_layout);
    localLinearLayout1.removeViews(2, -2 + localLinearLayout1.getChildCount());
    Iterator localIterator = paramEntlstMonthCusData.lstDayPlan.iterator();
    while (localIterator.hasNext())
    {
      EntlstDayPlanData localEntlstDayPlanData = (EntlstDayPlanData)localIterator.next();
      LinearLayout localLinearLayout2 = new LinearLayout(this.mContext);
      localLinearLayout2.setOrientation(0);
      localLinearLayout2.setGravity(16);
      ImageView localImageView2 = new ImageView(this.mContext);
      localImageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
      localImageView2.setImageResource(R.mipmap.fat_camp_train_icn_finish);
      localLinearLayout2.addView(localImageView2, new LinearLayout.LayoutParams(CompDeviceInfoUtils.convertOfDip(this.mContext, 15.0F), CompDeviceInfoUtils.convertOfDip(this.mContext, 15.0F)));
      TextView localTextView4 = new TextView(this.mContext);
      localTextView4.setTextColor(ContextCompat.getColor(this.mContext, R.color.color_828282));
      localTextView4.setTextSize(13.0F);
      localTextView4.setText(localEntlstDayPlanData.planName);
      LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-2, -2);
      localLayoutParams1.leftMargin = CompDeviceInfoUtils.convertOfDip(this.mContext, 1.0F);
      localLinearLayout2.addView(localTextView4, localLayoutParams1);
      LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-2, -2);
      localLayoutParams2.topMargin = CompDeviceInfoUtils.convertOfDip(this.mContext, 2.5F);
      localLinearLayout1.addView(localLinearLayout2, localLayoutParams2);
    }
    TextView localTextView2 = (TextView)paramView.findViewById(R.id.finished_day);
    localTextView2.setTypeface(TextUtils.getFontFaceImpact());
    localTextView2.setText(paramEntCusData.finishDays);
    TextView localTextView3 = (TextView)paramView.findViewById(R.id.finished_calorie);
    localTextView3.setTypeface(TextUtils.getFontFaceImpact());
    localTextView3.setText(paramEntCusData.finishCalorie);
    int i = (int)(360.0F * (Float.parseFloat(paramEntCusData.finishDays) / Float.parseFloat(paramEntCusData.totalDays)));
    ((FatCampShareProgress)paramView.findViewById(R.id.share_left_progress)).setValue(i, R.color.color_2ac77d);
    int j = (int)(360.0F * (Float.parseFloat(paramEntCusData.finishCalorie) / Float.parseFloat(paramEntCusData.totalCalorie)));
    if (Long.parseLong(paramEntCusData.finishCalorie) > Long.parseLong(paramEntCusData.totalCalorie))
      j = 360;
    ((FatCampShareProgress)paramView.findViewById(R.id.share_right_progress)).setValue(j, R.color.color_ff6a49);
    return paramView;
  }

  private boolean isExist()
  {
    return (this.mContext != null) && (!((Activity)this.mContext).isFinishing());
  }

  public void appCommentDialog()
  {
    Dialog localDialog = new Dialog(this.mContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    localDialog.setCanceledOnTouchOutside(true);
    localDialog.setCancelable(true);
    localDialog.setContentView(R.layout.app_comment_view);
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
    localLayoutParams.height = (int)(1.5385D * (0.9028000000000001D * BaseApplication.screenWidth));
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    RelativeLayout localRelativeLayout = (RelativeLayout)localDialog.findViewById(R.id.close_btn);
    WebView localWebView = (WebView)localDialog.findViewById(R.id.app_comment_webView);
    String str = VersionUpdateCheck.WEB_ADDRESS + "h5/fatAppComment";
    localWebView.loadUrl(str);
    VdsAgent.loadUrl((View)localWebView, str);
    localRelativeLayout.setOnClickListener(new View.OnClickListener(localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        this.val$dialog.dismiss();
      }
    });
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public void createCustomizeShareDialog(EntCusData paramEntCusData, EntlstMonthCusData paramEntlstMonthCusData, DialogInterface paramDialogInterface, View paramView)
  {
    if (!isExist())
      return;
    this.mDialog = new Dialog(this.mContext);
    this.mDialog.requestWindowFeature(1);
    this.mDialog.getWindow().setBackgroundDrawableResource(17170445);
    this.mDialog.setCanceledOnTouchOutside(false);
    this.mDialog.setCancelable(false);
    View localView = initCustomizeView(View.inflate(this.mContext, R.layout.fat_camp_share_view, null), paramEntCusData, paramEntlstMonthCusData);
    this.mDialog.setContentView(localView);
    ((ImageView)this.mDialog.findViewById(R.id.share_btn_back)).setOnClickListener(new FitAction(null)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        AboutCustomizeDialog.this.mDialog.dismiss();
        super.onClick(paramView);
      }
    });
    ((RTextView)this.mDialog.findViewById(R.id.to_share_btn)).setOnClickListener(new FitAction(null, paramDialogInterface, paramView, paramEntCusData, paramEntlstMonthCusData)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        this.val$dialogManager.createProgressDialog(AboutCustomizeDialog.this.mContext, "请稍后...");
        View localView = AboutCustomizeDialog.this.initCustomizeView(this.val$shareView, this.val$entCusData, this.val$entlstMonthCusData);
        localView.postDelayed(new Runnable(localView)
        {
          public void run()
          {
            try
            {
              this.val$shareView02.setDrawingCacheEnabled(true);
              this.val$shareView02.buildDrawingCache();
              Bitmap localBitmap = Bitmap.createBitmap(this.val$shareView02.getDrawingCache());
              this.val$shareView02.setDrawingCacheEnabled(false);
              LuBanUtils.luBanPressBitmap(localBitmap, new LuBanUtils.PressCallBack()
              {
                public void callBackError(Bitmap paramBitmap)
                {
                }

                public void callBackStart()
                {
                }

                public void callBackSuccess(File paramFile, Bitmap paramBitmap)
                {
                  AboutCustomizeDialog.6.this.val$dialogManager.closeDialog();
                  UseShareModel localUseShareModel = new UseShareModel();
                  localUseShareModel.cropBitmap = paramBitmap;
                  localUseShareModel.olapInfo = "0";
                  PlayPointModel localPlayPointModel = ShareListenerFunction.pointPut(31, "2", new UseShareModel());
                  ShareManager localShareManager = new ShareManager(AboutCustomizeDialog.this.mContext, AboutCustomizeDialog.6.this.val$dialogManager);
                  localShareManager.setPlayPointModel(localPlayPointModel);
                  localShareManager.shareFitData(localUseShareModel, 31, 1);
                  AboutCustomizeDialog.this.mDialog.dismiss();
                }
              });
              return;
            }
            catch (Exception localException)
            {
              LogUtils.e(localException);
            }
          }
        }
        , 200L);
        super.onClick(paramView);
      }
    });
    WindowManager.LayoutParams localLayoutParams = this.mDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
    localLayoutParams.gravity = 17;
    this.mDialog.getWindow().setAttributes(localLayoutParams);
    this.mDialog.setCancelable(true);
    this.mDialog.setCanceledOnTouchOutside(false);
    Dialog localDialog = this.mDialog;
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public void createDialog()
  {
    this.mDialog = new Dialog(this.mContext, R.style.DialogStyle);
    this.mDialog.requestWindowFeature(1);
    this.mDialog.setCanceledOnTouchOutside(false);
    this.mDialog.setCancelable(false);
    this.mDialog.setContentView(R.layout.about_customizedialog_layout);
    ((ImageView)this.mDialog.findViewById(R.id.aboutCustomzie_close)).setOnClickListener(new FitAction(null)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        AboutCustomizeDialog.this.mDialog.dismiss();
        super.onClick(paramView);
      }
    });
    WindowManager.LayoutParams localLayoutParams = this.mDialog.getWindow().getAttributes();
    localLayoutParams.width = BaseApplication.screenWidth;
    localLayoutParams.height = BaseApplication.screenRealHeight;
    this.mDialog.getWindow().setAttributes(localLayoutParams);
    this.mDialog.setCancelable(true);
    this.mDialog.setCanceledOnTouchOutside(false);
    Dialog localDialog = this.mDialog;
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public void createDietDialog(String paramString, int paramInt1, int paramInt2)
  {
    this.mDialog = new Dialog(this.mContext);
    this.mDialog.requestWindowFeature(1);
    this.mDialog.getWindow().setBackgroundDrawableResource(17170445);
    this.mDialog.setContentView(R.layout.about_dietdialog_layout);
    TextView localTextView1 = (TextView)this.mDialog.findViewById(R.id.diet_dialog_title);
    TextView localTextView2 = (TextView)this.mDialog.findViewById(R.id.diet_dialog_comment);
    if ("0".equals(paramString))
    {
      localTextView1.setText("减脂饮食介绍");
      localTextView2.setText("减脂期间总摄入量应低于总消耗，蛋白供能比在15%-20%为最优，充足的蛋白供应可以防止减脂期间的肌肉流失，同时应注意粗杂粮和新鲜蔬菜的摄入，他们除了提供丰富的维生素和矿物质以外，还富含纤维，可增加饱腹感。");
    }
    while (true)
    {
      ((ImageView)this.mDialog.findViewById(R.id.about_diet_close)).setOnClickListener(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          AboutCustomizeDialog.this.mDialog.dismiss();
          super.onClick(paramView);
        }
      });
      WindowManager.LayoutParams localLayoutParams = this.mDialog.getWindow().getAttributes();
      localLayoutParams.width = paramInt1;
      localLayoutParams.height = paramInt2;
      this.mDialog.getWindow().setAttributes(localLayoutParams);
      this.mDialog.setCancelable(true);
      this.mDialog.setCanceledOnTouchOutside(true);
      Dialog localDialog = this.mDialog;
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      return;
      if ("1".equals(paramString))
      {
        localTextView1.setText("塑型饮食介绍");
        localTextView2.setText("塑型期间遵循热量平衡原则，产能营养素的供能比符合均衡膳食的要求，适量的谷类、肉类、蔬菜水果及乳制品能满足机体的营养需求，帮助机体维持健康体重，增加瘦体重和减少脂肪比例。");
        continue;
      }
      if (!"2".equals(paramString))
        continue;
      localTextView1.setText("增肌饮食介绍");
      localTextView2.setText("增肌期间总摄入应大于总消耗，足量的蛋白能是合成肌肉的基础，充足的碳水可以防止肌肉中的蛋白被转化成葡萄糖作为燃料。");
    }
  }

  public void createExpireHintDialog(FitInterfaceUtils.DialogListener paramDialogListener)
  {
    Dialog localDialog = new Dialog(this.mContext);
    localDialog.requestWindowFeature(1);
    localDialog.getWindow().setBackgroundDrawableResource(17170445);
    View localView1 = LayoutInflater.from(this.mContext).inflate(R.layout.energy_hint_layout, null);
    View localView2 = LayoutInflater.from(this.mContext).inflate(R.layout.energy_header_layout04, null);
    TextView localTextView = (TextView)localView2.findViewById(R.id.course_expire_hint);
    ((TextView)localView2.findViewById(R.id.course_expire)).setText(this.mContext.getString(R.string.a_36_1_1));
    localTextView.setGravity(17);
    localTextView.setLineSpacing(0.0F, 1.2F);
    localTextView.setText(this.mContext.getString(R.string.a_36_1_2));
    ((RelativeLayout)localView1.findViewById(R.id.custom_view)).addView(localView2);
    localDialog.setContentView(localView1);
    RTextView localRTextView1 = (RTextView)localDialog.findViewById(R.id.view_cancel);
    RTextView localRTextView2 = (RTextView)localDialog.findViewById(R.id.view_confirm);
    localRTextView1.setText(this.mContext.getString(R.string.a_36_1_3));
    localRTextView2.setText(this.mContext.getString(R.string.a_36_1_4));
    localRTextView1.setOnClickListener(new FitAction(null, localDialog)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        this.val$dialog.dismiss();
        super.onClick(paramView);
      }
    });
    localRTextView2.setOnClickListener(new FitAction(null, localDialog, paramDialogListener)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        this.val$dialog.dismiss();
        this.val$listener.onDialogClick(this.val$dialog, -2);
        super.onClick(paramView);
      }
    });
    WindowManager.LayoutParams localLayoutParams = localDialog.getWindow().getAttributes();
    localLayoutParams.width = (int)(0.9028000000000001D * BaseApplication.screenWidth);
    localLayoutParams.height = -2;
    localLayoutParams.gravity = 17;
    localDialog.getWindow().setAttributes(localLayoutParams);
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public void createFatCampDialog(EntloseFatData paramEntloseFatData)
  {
    this.mDialog = new Dialog(this.mContext, R.style.DialogStyle);
    this.mDialog.requestWindowFeature(1);
    this.mDialog.setCanceledOnTouchOutside(false);
    this.mDialog.setCancelable(false);
    String[] arrayOfString = paramEntloseFatData.loseFatIntr.split("\\[b]");
    View localView1 = View.inflate(this.mContext, R.layout.about_fatcamp_layout, null);
    ((TextView)localView1.findViewById(R.id.about_fat_camp)).setText("关于服务");
    LinearLayout localLinearLayout = (LinearLayout)localView1.findViewById(R.id.introduce_layout);
    localLinearLayout.removeAllViews();
    localLinearLayout.setWeightSum(arrayOfString.length);
    for (int i = 0; i < arrayOfString.length; i++)
    {
      View localView2 = View.inflate(this.mContext, R.layout.about_fatcamp_item_layout, null);
      ((TextView)localView2.findViewById(R.id.fatcamp_introduce_view)).setText(arrayOfString[i]);
      LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-1, -2);
      localLayoutParams1.weight = 1.0F;
      localLayoutParams1.topMargin = CompDeviceInfoUtils.convertOfDip(this.mContext, 16.0F);
      localLinearLayout.addView(localView2, localLayoutParams1);
    }
    this.mDialog.setContentView(localView1);
    ((ImageView)this.mDialog.findViewById(R.id.about_fat_camp_close)).setOnClickListener(new FitAction(null)
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        AboutCustomizeDialog.this.mDialog.dismiss();
        super.onClick(paramView);
      }
    });
    WindowManager.LayoutParams localLayoutParams = this.mDialog.getWindow().getAttributes();
    localLayoutParams.width = BaseApplication.screenWidth;
    localLayoutParams.height = BaseApplication.screenRealHeight;
    this.mDialog.getWindow().setAttributes(localLayoutParams);
    this.mDialog.setCancelable(true);
    this.mDialog.setCanceledOnTouchOutside(false);
    Dialog localDialog = this.mDialog;
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.AboutCustomizeDialog
 * JD-Core Version:    0.6.0
 */