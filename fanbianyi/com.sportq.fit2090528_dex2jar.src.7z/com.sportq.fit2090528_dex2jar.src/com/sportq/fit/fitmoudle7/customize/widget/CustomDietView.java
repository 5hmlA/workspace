package com.sportq.fit.fitmoudle7.customize.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.mipmap;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.activity.DietRecommendActivity;
import com.sportq.fit.fitmoudle7.customize.activity.PerfectDietActivity;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntDietaryData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstMonthCusData;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

public class CustomDietView extends RelativeLayout
{
  private ImageView diet_type_img;
  private RTextView diet_type_info;
  private int[] drawableList;
  private int[] iconList;
  private View itemView;
  private Context mContext;
  private int[] nameList;
  private int pos = 0;
  private RTextViewHelper rTextViewHelper;

  public CustomDietView(Context paramContext)
  {
    super(paramContext);
    int[] arrayOfInt1 = new int[5];
    arrayOfInt1[0] = R.mipmap.img_breakfast;
    arrayOfInt1[1] = R.mipmap.img_lunch;
    arrayOfInt1[2] = R.mipmap.img_snacks;
    arrayOfInt1[3] = R.mipmap.img_dinner;
    arrayOfInt1[4] = R.mipmap.img_diet_unlock;
    this.iconList = arrayOfInt1;
    int[] arrayOfInt2 = new int[4];
    arrayOfInt2[0] = R.string.a_4_13_4;
    arrayOfInt2[1] = R.string.a_4_13_5;
    arrayOfInt2[2] = R.string.a_4_13_6;
    arrayOfInt2[3] = R.string.a_4_13_7;
    this.nameList = arrayOfInt2;
    int[] arrayOfInt3 = new int[4];
    arrayOfInt3[0] = R.color.color_dbb76a;
    arrayOfInt3[1] = R.color.color_db8e6a;
    arrayOfInt3[2] = R.color.color_8dbd61;
    arrayOfInt3[3] = R.color.color_9f5fb9;
    this.drawableList = arrayOfInt3;
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    this.itemView = View.inflate(this.mContext, R.layout.custom_title_view, null);
    this.itemView.findViewById(R.id.item_layout).setBackgroundColor(getResources().getColor(R.color.white));
    ((TextView)this.itemView.findViewById(R.id.custom_title)).setText(this.mContext.getString(R.string.a_4_13_2));
    this.diet_type_info = ((RTextView)this.itemView.findViewById(R.id.diet_type_info));
    this.rTextViewHelper = this.diet_type_info.getHelper();
    this.diet_type_img = ((ImageView)this.itemView.findViewById(R.id.diet_type_img));
    return this.itemView;
  }

  public void initData(EntlstMonthCusData paramEntlstMonthCusData)
  {
    int k;
    String str1;
    label67: int i;
    label104: ImageView localImageView;
    if (DateUtils.getStrCurrentTimee().equals(paramEntlstMonthCusData.cusDate))
    {
      k = StringUtils.string2Int(DateUtils.getCurDate().split(" ")[1].split(":")[0]);
      if (k < 9)
        this.pos = 0;
    }
    else
    {
      RTextView localRTextView = this.diet_type_info;
      if (!StringUtils.isNull(BaseApplication.userModel.phyLevel))
        break label281;
      str1 = "未开启";
      localRTextView.setText(str1);
      RTextViewHelper localRTextViewHelper = this.rTextViewHelper;
      Context localContext = getContext();
      if (!StringUtils.isNull(BaseApplication.userModel.phyLevel))
        break label301;
      i = this.drawableList[0];
      localRTextViewHelper.setBackgroundColorNormal(ContextCompat.getColor(localContext, i));
      this.diet_type_info.setVisibility(0);
      localImageView = this.diet_type_img;
      if (!StringUtils.isNull(BaseApplication.userModel.phyLevel))
        break label315;
    }
    LinearLayout localLinearLayout;
    label281: label301: label315: for (int j = this.iconList[4]; ; j = this.iconList[this.pos])
    {
      localImageView.setImageResource(j);
      this.diet_type_img.setVisibility(0);
      this.itemView.setOnClickListener(new FitAction(null, paramEntlstMonthCusData)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          Context localContext = CustomDietView.this.getContext();
          Object localObject;
          Intent localIntent;
          if (StringUtils.isNull(BaseApplication.userModel.phyLevel))
          {
            localObject = PerfectDietActivity.class;
            localIntent = new Intent(localContext, (Class)localObject);
            localIntent.putExtra("cur.date", this.val$entlstMonthCusData.cusDate);
            localIntent.putExtra("cur.pos", CustomDietView.this.pos);
            if (!StringUtils.isNull(BaseApplication.userModel.phyLevel))
              break label133;
          }
          label133: for (String str = "0"; ; str = "1")
          {
            localIntent.putExtra("cur.jump", str);
            CustomDietView.this.mContext.startActivity(localIntent);
            AnimationUtil.pageJumpAnim((Activity)CustomDietView.this.mContext, 0);
            super.onClick(paramView);
            return;
            localObject = DietRecommendActivity.class;
            break;
          }
        }
      });
      localLinearLayout = (LinearLayout)this.itemView.findViewById(R.id.content_layout);
      localLinearLayout.removeAllViews();
      if ((paramEntlstMonthCusData.entDietary != null) && (paramEntlstMonthCusData.entDietary.lstDayDietary != null) && (paramEntlstMonthCusData.entDietary.lstDayDietary.size() != 0))
        break label329;
      this.itemView.setVisibility(8);
      return;
      if (k < 14)
      {
        this.pos = 1;
        break;
      }
      if (k < 16)
      {
        this.pos = 2;
        break;
      }
      this.pos = 3;
      break;
      str1 = this.mContext.getString(this.nameList[this.pos]);
      break label67;
      i = this.drawableList[this.pos];
      break label104;
    }
    label329: View localView = View.inflate(this.mContext, R.layout.diet_item_view, null);
    TextView localTextView = (TextView)localView.findViewById(R.id.diet_content);
    if (StringUtils.isNull(BaseApplication.userModel.phyLevel));
    for (String str2 = StringUtils.getStringResources(R.string.a_2_12_2); ; str2 = (String)paramEntlstMonthCusData.entDietary.lstDayDietary.get(this.pos))
    {
      localTextView.setText(str2);
      LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-1, -2);
      localLayoutParams.weight = 1.0F;
      localLinearLayout.addView(localView, localLayoutParams);
      return;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomDietView
 * JD-Core Version:    0.6.0
 */