package com.sportq.fit.fitmoudle7.customize.refermer.model;

import com.sportq.fit.common.BaseData;
import java.util.ArrayList;

public class GetTrainActData extends BaseData
{
  public ArrayList<GetTrainActModel> lstTargetClasType;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.model.GetTrainActData
 * JD-Core Version:    0.6.0
 */