package com.sportq.fit.fitmoudle7.customize.widget;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.widget.BaseDialog;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;

public class SelectPhyActLevelDialog extends BaseDialog
{
  private RTextView cancel_btn;
  private RTextView confirm_btn;
  private Dialog dialog;
  private RelativeLayout msg_img_1;
  private RelativeLayout msg_img_2;
  private RelativeLayout msg_img_3;
  private ImageView msg_select_1;
  private ImageView msg_select_2;
  private ImageView msg_select_3;
  private String phyLevel;

  private void init()
  {
    this.msg_img_1 = ((RelativeLayout)this.dialog.findViewById(R.id.msg_img_1));
    this.msg_img_2 = ((RelativeLayout)this.dialog.findViewById(R.id.msg_img_2));
    this.msg_img_3 = ((RelativeLayout)this.dialog.findViewById(R.id.msg_img_3));
    this.msg_select_1 = ((ImageView)this.dialog.findViewById(R.id.msg_select_1));
    this.msg_select_2 = ((ImageView)this.dialog.findViewById(R.id.msg_select_2));
    this.msg_select_3 = ((ImageView)this.dialog.findViewById(R.id.msg_select_3));
    this.confirm_btn = ((RTextView)this.dialog.findViewById(R.id.confirm_btn));
    this.cancel_btn = ((RTextView)this.dialog.findViewById(R.id.cancel_btn));
  }

  public Dialog createDialog(OnActLevelSelectorListener paramOnActLevelSelectorListener, Context paramContext, String paramString)
  {
    if (paramOnActLevelSelectorListener == null)
      return null;
    this.dialog = new Dialog(paramContext);
    this.dialog.requestWindowFeature(1);
    this.dialog.getWindow().setBackgroundDrawableResource(17170445);
    this.dialog.setCanceledOnTouchOutside(true);
    this.dialog.setCancelable(true);
    this.dialog.setContentView(R.layout.select_phy_act_level_dialog_layout);
    init();
    this.phyLevel = paramString;
    if ("3".equals(this.phyLevel))
      this.msg_select_3.setVisibility(0);
    while (true)
    {
      WindowManager.LayoutParams localLayoutParams = this.dialog.getWindow().getAttributes();
      localLayoutParams.gravity = 17;
      localLayoutParams.width = (int)(0.861D * BaseApplication.screenWidth);
      this.dialog.getWindow().setAttributes(localLayoutParams);
      Dialog localDialog = this.dialog;
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      this.msg_img_1.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          SelectPhyActLevelDialog.this.msg_select_1.setVisibility(0);
          SelectPhyActLevelDialog.this.msg_select_2.setVisibility(8);
          SelectPhyActLevelDialog.this.msg_select_3.setVisibility(8);
          SelectPhyActLevelDialog.access$302(SelectPhyActLevelDialog.this, "1");
        }
      });
      this.msg_img_2.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          SelectPhyActLevelDialog.this.msg_select_2.setVisibility(0);
          SelectPhyActLevelDialog.this.msg_select_1.setVisibility(8);
          SelectPhyActLevelDialog.this.msg_select_3.setVisibility(8);
          SelectPhyActLevelDialog.access$302(SelectPhyActLevelDialog.this, "2");
        }
      });
      this.msg_img_3.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          SelectPhyActLevelDialog.this.msg_select_3.setVisibility(0);
          SelectPhyActLevelDialog.this.msg_select_1.setVisibility(8);
          SelectPhyActLevelDialog.this.msg_select_2.setVisibility(8);
          SelectPhyActLevelDialog.access$302(SelectPhyActLevelDialog.this, "3");
        }
      });
      this.confirm_btn.setOnClickListener(new View.OnClickListener(paramOnActLevelSelectorListener)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          this.val$listener.onSelect(SelectPhyActLevelDialog.this.phyLevel);
          SelectPhyActLevelDialog.this.dialog.dismiss();
        }
      });
      this.cancel_btn.setOnClickListener(new View.OnClickListener()
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          SelectPhyActLevelDialog.this.dialog.dismiss();
        }
      });
      return this.dialog;
      if ("2".equals(this.phyLevel))
      {
        this.msg_select_2.setVisibility(0);
        continue;
      }
      this.msg_select_1.setVisibility(0);
    }
  }

  public static abstract interface OnActLevelSelectorListener
  {
    public abstract void onSelect(String paramString);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.SelectPhyActLevelDialog
 * JD-Core Version:    0.6.0
 */