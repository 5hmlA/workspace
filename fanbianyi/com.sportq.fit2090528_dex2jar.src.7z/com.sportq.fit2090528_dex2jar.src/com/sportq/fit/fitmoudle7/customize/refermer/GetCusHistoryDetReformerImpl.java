package com.sportq.fit.fitmoudle7.customize.refermer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle7.customize.refermer.model.CustomizeData;
import com.sportq.fit.fitmoudle7.customize.refermer.reformer.CustomizeReformer;
import java.util.ArrayList;
import java.util.Iterator;

public class GetCusHistoryDetReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    CustomizeReformer localCustomizeReformer;
    if (paramBaseData == null)
      localCustomizeReformer = null;
    while (true)
    {
      return localCustomizeReformer;
      localCustomizeReformer = new CustomizeReformer();
      CustomizeData localCustomizeData = (CustomizeData)paramBaseData;
      CustomizeModel.CustomDataEntity localCustomDataEntity1 = new CustomizeModel.CustomDataEntity();
      localCustomDataEntity1.customId = localCustomizeData.entCusData.customId;
      localCustomDataEntity1.curriculumName = localCustomizeData.entCusData.curriculumName;
      localCustomDataEntity1.imageURL = localCustomizeData.entCusData.imageURL;
      localCustomDataEntity1.customDays = localCustomizeData.entCusData.customDays;
      localCustomDataEntity1.finishNum = localCustomizeData.entCusData.finishNum;
      localCustomDataEntity1.calorie = localCustomizeData.entCusData.calorie;
      localCustomDataEntity1.trainNum = localCustomizeData.entCusData.trainNum;
      localCustomDataEntity1.apparatus = localCustomizeData.entCusData.apparatus;
      localCustomDataEntity1.exitComment = localCustomizeData.entCusData.exitComment;
      localCustomizeReformer.entCusData = localCustomDataEntity1;
      localCustomizeReformer.lstCusWeek = new ArrayList();
      Iterator localIterator = localCustomizeData.lstCusWeek.iterator();
      while (localIterator.hasNext())
      {
        CustomizeModel.CustomDataEntity localCustomDataEntity2 = (CustomizeModel.CustomDataEntity)localIterator.next();
        CustomizeModel.CustomDataEntity localCustomDataEntity3 = new CustomizeModel.CustomDataEntity();
        localCustomDataEntity3.weekId = localCustomDataEntity2.weekId;
        localCustomDataEntity3.noWeek = localCustomDataEntity2.noWeek;
        localCustomDataEntity3.curriculumDate = localCustomDataEntity2.curriculumDate;
        localCustomDataEntity3.trainNum = localCustomDataEntity2.trainNum;
        localCustomDataEntity3.finishNum = localCustomDataEntity2.finishNum;
        localCustomDataEntity3.phyDays = localCustomDataEntity2.phyDays;
        localCustomizeReformer.lstCusWeek.add(localCustomDataEntity3);
      }
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (CustomizeData)FitGsonFactory.create().fromJson(paramString2, CustomizeData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.refermer.GetCusHistoryDetReformerImpl
 * JD-Core Version:    0.6.0
 */