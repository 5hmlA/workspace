package com.sportq.fit.fitmoudle7.customize.widget;

import android.content.Context;
import android.content.res.Resources;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView;
import com.sportq.fit.fitmoudle.widget.SinglePlanTrainView.DetailsBtnInterface;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.dimen;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.common.CustomizeSharePreferenceUtils;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstDayPlanData;
import com.sportq.fit.fitmoudle7.customize.refermer.model.EntlstMonthCusData;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;

public class CustomTrainView extends RelativeLayout
{
  private CustomizeShareClickListener clickListener;
  private String customId;
  private Context mContext;
  private String[] shareCopy = { "你的朋友在偷懒，只有你在坚持", "你的坚持要让朋友们看见", "每天让自己进步一点点", "这波操作666，快去炫耀吧！", "坚持下去，拒绝葛优躺", "就算再困难，也请咬牙坚持！", "成功其实很简单，只要你有决心！", "总有一天，别人会羡慕你的身材", "不要心急，也不要放弃" };

  public CustomTrainView(Context paramContext)
  {
    super(paramContext);
  }

  public CustomTrainView(Context paramContext, EntlstMonthCusData paramEntlstMonthCusData, String paramString)
  {
    super(paramContext);
    this.mContext = paramContext;
    this.customId = paramString;
    addView(onCreateView(paramEntlstMonthCusData));
  }

  private PlanModel convertData(EntlstDayPlanData paramEntlstDayPlanData)
  {
    Gson localGson = new Gson();
    return (PlanModel)localGson.fromJson(localGson.toJson(paramEntlstDayPlanData), PlanModel.class);
  }

  private View getShareItemView()
  {
    String str = DateUtils.StringToFormat(String.valueOf(System.currentTimeMillis()), "yyyy-MM-dd");
    View localView = View.inflate(this.mContext, R.layout.fat_camp_share_item_layout, null);
    TextView localTextView = (TextView)localView.findViewById(R.id.share_hint_content);
    int i = CustomizeSharePreferenceUtils.getCustomizeShareCopy(str);
    if (i == -1)
      i = StringUtils.getRandom02(0, 8);
    CustomizeSharePreferenceUtils.putCustomizeShareCopy(str, i);
    localTextView.setText(this.shareCopy[i]);
    localView.findViewById(R.id.to_share_btn).setOnClickListener(new View.OnClickListener()
    {
      @Instrumented
      public void onClick(View paramView)
      {
        VdsAgent.onClick(this, paramView);
        if (CustomTrainView.this.clickListener != null)
          CustomTrainView.this.clickListener.toShare();
      }
    });
    return localView;
  }

  private View onCreateView(EntlstMonthCusData paramEntlstMonthCusData)
  {
    String str;
    label15: label44: int i;
    if (!StringUtils.isNull(paramEntlstMonthCusData.isTrainDay))
    {
      str = paramEntlstMonthCusData.isTrainDay;
      switch (str.hashCode())
      {
      default:
        i = -1;
      case 48:
      case 49:
      case 50:
      }
    }
    while (true)
      switch (i)
      {
      default:
        return View.inflate(this.mContext, R.layout.customized_day_recover, null);
        str = "0";
        break label15;
        if (!str.equals("0"))
          break label44;
        i = 0;
        continue;
        if (!str.equals("1"))
          break label44;
        i = 1;
        continue;
        if (!str.equals("2"))
          break label44;
        i = 2;
      case 0:
      case 1:
      case 2:
      }
    return View.inflate(this.mContext, R.layout.customized_day_recover, null);
    return View.inflate(this.mContext, R.layout.custom_title_view, null);
    return View.inflate(this.mContext, R.layout.customized_day_leave, null);
  }

  public void initData(View paramView, EntlstMonthCusData paramEntlstMonthCusData)
  {
    if ("1".equals(paramEntlstMonthCusData.isTrainDay))
    {
      ((TextView)paramView.findViewById(R.id.custom_title)).setText(this.mContext.getString(R.string.a_4_13_1));
      LinearLayout localLinearLayout2 = (LinearLayout)paramView.findViewById(R.id.title_item_layout);
      LinearLayout localLinearLayout3 = (LinearLayout)paramView.findViewById(R.id.content_layout);
      localLinearLayout3.removeAllViews();
      View localView1 = new View(this.mContext);
      RelativeLayout.LayoutParams localLayoutParams1 = new RelativeLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 10.0F));
      localView1.setBackgroundColor(ContextCompat.getColor(this.mContext, R.color.color_f7f7f7));
      localLinearLayout2.addView(localView1, 0, localLayoutParams1);
      if (("1".equals(paramEntlstMonthCusData.isFinish)) && (paramEntlstMonthCusData.cusDate.equals(DateUtils.StringToFormat(String.valueOf(System.currentTimeMillis()), "yyyy-MM-dd"))) && (localLinearLayout2.getChildAt(1).getId() == R.id.item_layout))
        localLinearLayout2.addView(getShareItemView(), 1);
      View localView2 = new View(this.mContext);
      RelativeLayout.LayoutParams localLayoutParams2 = new RelativeLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 0.5F));
      localView2.setBackgroundColor(ContextCompat.getColor(this.mContext, R.color.color_e6e6e6));
      localLinearLayout3.addView(localView2, localLayoutParams2);
      for (int j = 0; j < paramEntlstMonthCusData.lstDayPlan.size(); j++)
      {
        SinglePlanTrainView localSinglePlanTrainView = new SinglePlanTrainView(this.mContext);
        localSinglePlanTrainView.initView(convertData((EntlstDayPlanData)paramEntlstMonthCusData.lstDayPlan.get(j)), 5);
        localSinglePlanTrainView.setBackgroundColor(ContextCompat.getColor(this.mContext, R.color.white));
        String str = ((EntlstDayPlanData)paramEntlstMonthCusData.lstDayPlan.get(j)).trainableDay;
        View localView3 = new View(this.mContext);
        RelativeLayout.LayoutParams localLayoutParams3 = new RelativeLayout.LayoutParams(-1, getResources().getDimensionPixelSize(R.dimen.unified_split_size));
        localView3.setBackgroundColor(ContextCompat.getColor(this.mContext, R.color.color_f7f7f7));
        localView3.setLayoutParams(localLayoutParams3);
        localSinglePlanTrainView.setDetailsBtnInterface(new SinglePlanTrainView.DetailsBtnInterface(paramEntlstMonthCusData, j, str)
        {
          public void contentClick()
          {
            if (!"3".equals(((EntlstDayPlanData)this.val$itemEntity.lstDayPlan.get(this.val$finalI)).stateCode))
            {
              if (!"0".equals(((EntlstDayPlanData)this.val$itemEntity.lstDayPlan.get(this.val$finalI)).stateCode))
                break label132;
              FitJumpImpl.getInstance().customizeJumpCourse(CustomTrainView.this.mContext, ((EntlstDayPlanData)this.val$itemEntity.lstDayPlan.get(this.val$finalI)).planId, "hide", ((EntlstDayPlanData)this.val$itemEntity.lstDayPlan.get(this.val$finalI)).customDetailId, this.val$itemEntity.weekId, CustomTrainView.this.customId, this.val$days);
            }
            label132: 
            do
            {
              return;
              if (!"1".equals(((EntlstDayPlanData)this.val$itemEntity.lstDayPlan.get(this.val$finalI)).stateCode))
                continue;
              FitJumpImpl.getInstance().customizeJumpCourse(CustomTrainView.this.mContext, ((EntlstDayPlanData)this.val$itemEntity.lstDayPlan.get(this.val$finalI)).planId, "", ((EntlstDayPlanData)this.val$itemEntity.lstDayPlan.get(this.val$finalI)).customDetailId, this.val$itemEntity.weekId, CustomTrainView.this.customId, "");
              return;
            }
            while (!"2".equals(((EntlstDayPlanData)this.val$itemEntity.lstDayPlan.get(this.val$finalI)).stateCode));
            FitJumpImpl.getInstance().jumpRecordDetail(CustomTrainView.this.mContext, CustomTrainView.this.convertData((EntlstDayPlanData)this.val$itemEntity.lstDayPlan.get(this.val$finalI)), this.val$itemEntity.weekId, CustomTrainView.this.customId);
          }

          public void detailBtnClick()
          {
          }
        });
        localLinearLayout3.addView(localSinglePlanTrainView);
        if (j == -1 + paramEntlstMonthCusData.lstDayPlan.size())
          continue;
        localLinearLayout3.addView(localView3);
      }
      if (("1".equals(paramEntlstMonthCusData.isFeedBackDay)) && ("0".equals(paramEntlstMonthCusData.isFeedBack)) && (!StringUtils.isNull(paramEntlstMonthCusData.feedBackComment)))
      {
        View localView4 = View.inflate(getContext(), R.layout.about_feedback_hint, null);
        LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 100.0F));
        ((TextView)localView4.findViewById(R.id.reach_content)).setText(paramEntlstMonthCusData.feedBackComment);
        localLinearLayout3.addView(localView4, localLayoutParams);
        paramView.findViewById(R.id.split_line_view).setVisibility(8);
      }
    }
    do
      return;
    while (!"2".equals(paramEntlstMonthCusData.isTrainDay));
    LinearLayout localLinearLayout1 = (LinearLayout)paramView.findViewById(R.id.period_ll);
    TextView localTextView1 = (TextView)paramView.findViewById(R.id.period_bt_tv);
    TextView localTextView2 = (TextView)paramView.findViewById(R.id.period_text);
    if (!"0".equals(BaseApplication.userModel.userSex));
    for (int i = 0; ; i = 8)
    {
      localLinearLayout1.setVisibility(i);
      localTextView2.setText(UseStringUtils.getStr(R.string.a_21_1_3));
      2 local2 = new FitAction(null, paramEntlstMonthCusData)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          FitJumpImpl.getInstance().JumpTrainCategoryActivity(CustomTrainView.this.mContext, this.val$itemEntity.classifyId, CustomTrainView.this.mContext.getString(R.string.period_course));
          super.onClick(paramView);
        }
      };
      localTextView1.setOnClickListener(local2);
      return;
    }
  }

  public void setClickListener(CustomizeShareClickListener paramCustomizeShareClickListener)
  {
    this.clickListener = paramCustomizeShareClickListener;
  }

  public static abstract interface CustomizeShareClickListener
  {
    public abstract void toShare();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomTrainView
 * JD-Core Version:    0.6.0
 */