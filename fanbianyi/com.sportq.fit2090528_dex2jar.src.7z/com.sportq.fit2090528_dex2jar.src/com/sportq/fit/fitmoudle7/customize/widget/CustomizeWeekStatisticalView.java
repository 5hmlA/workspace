package com.sportq.fit.fitmoudle7.customize.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.model.CustomizeModel.CustomDataEntity;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle7.R.color;
import com.sportq.fit.fitmoudle7.R.id;
import com.sportq.fit.fitmoudle7.R.layout;
import com.sportq.fit.fitmoudle7.R.string;
import com.sportq.fit.fitmoudle7.customize.activity.WeekDataInfoActivity;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CustomizeWeekStatisticalView extends RelativeLayout
{
  private String customId;
  private TextView customWeekTimeInterval;
  private TextView customWeekTitle;
  private TextView customWeekTrainNum;
  private RelativeLayout layout;
  private Context mContext;
  private String pageFlag;
  private ImageView ti_icon_img;
  private TextView tvProgress;
  private String useWeekId;
  private String weekId;
  private String weekTitle;
  private View yellowTag;

  public CustomizeWeekStatisticalView(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeWeekStatisticalView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  public CustomizeWeekStatisticalView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
    addView(onCreateView());
  }

  private View onCreateView()
  {
    View localView = LayoutInflater.from(this.mContext).inflate(R.layout.customize_week_statistical, null);
    this.layout = ((RelativeLayout)localView.findViewById(R.id.layout));
    this.customWeekTitle = ((TextView)localView.findViewById(R.id.custom_week_title));
    this.customWeekTimeInterval = ((TextView)localView.findViewById(R.id.custom_week_timeInterval));
    this.customWeekTrainNum = ((TextView)localView.findViewById(R.id.custom_week_trainNum));
    this.yellowTag = localView.findViewById(R.id.custom_week_yellowTag);
    this.tvProgress = ((TextView)localView.findViewById(R.id.custom_week_progress));
    this.ti_icon_img = ((ImageView)localView.findViewById(R.id.ti_icon_img));
    localView.setLayoutParams(new RelativeLayout.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(this.mContext, 107.5F)));
    return localView;
  }

  public String getUseWeekId()
  {
    return this.useWeekId;
  }

  public void setCustomId(String paramString)
  {
    this.customId = paramString;
  }

  public void setWeekStatValue(CustomizeModel.CustomDataEntity paramCustomDataEntity, int paramInt)
  {
    setWeekStatValue(paramCustomDataEntity, paramInt, true);
  }

  public void setWeekStatValue(CustomizeModel.CustomDataEntity paramCustomDataEntity, int paramInt, boolean paramBoolean)
  {
    this.weekId = paramCustomDataEntity.weekId;
    this.customWeekTitle.setText(paramCustomDataEntity.noWeek);
    this.weekTitle = paramCustomDataEntity.noWeek;
    TextView localTextView1 = this.customWeekTimeInterval;
    StringBuilder localStringBuilder = new StringBuilder().append(paramCustomDataEntity.curriculumDate).append(" ");
    String str1;
    if (!StringUtils.isNull(paramCustomDataEntity.phyDays))
      str1 = paramCustomDataEntity.phyDays;
    while (true)
    {
      localTextView1.setText(str1);
      this.customWeekTrainNum.setText(paramCustomDataEntity.trainNum);
      TextView localTextView2 = this.tvProgress;
      String str2;
      label118: int i;
      label172: int j;
      label205: int k;
      label238: int m;
      label263: Calendar localCalendar;
      Date localDate1;
      if (!StringUtils.isNull(paramCustomDataEntity.finishNum))
      {
        str2 = paramCustomDataEntity.finishNum;
        localTextView2.setText(str2);
        this.tvProgress.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
        this.pageFlag = String.valueOf(paramInt);
        TextView localTextView3 = this.customWeekTitle;
        Context localContext1 = this.mContext;
        if (!paramBoolean)
          break label611;
        i = R.color.color_313131;
        localTextView3.setTextColor(ContextCompat.getColor(localContext1, i));
        TextView localTextView4 = this.customWeekTimeInterval;
        Context localContext2 = this.mContext;
        if (!paramBoolean)
          break label619;
        j = R.color.color_828282;
        localTextView4.setTextColor(ContextCompat.getColor(localContext2, j));
        TextView localTextView5 = this.customWeekTrainNum;
        Context localContext3 = this.mContext;
        if (!paramBoolean)
          break label627;
        k = R.color.color_313131;
        localTextView5.setTextColor(ContextCompat.getColor(localContext3, k));
        ImageView localImageView = this.ti_icon_img;
        if (!paramBoolean)
          break label635;
        m = 0;
        localImageView.setVisibility(m);
        localCalendar = Calendar.getInstance();
        localCalendar.set(11, 0);
        localCalendar.set(12, 0);
        localCalendar.set(13, 0);
        localCalendar.set(14, 0);
        localDate1 = localCalendar.getTime();
        this.yellowTag.setVisibility(4);
        if (StringUtils.isNull(paramCustomDataEntity.curriculumDate));
      }
      try
      {
        String[] arrayOfString = paramCustomDataEntity.curriculumDate.split("-");
        if (!arrayOfString[0].contains("年"))
          arrayOfString[0] = (localCalendar.get(1) + this.mContext.getString(R.string.year) + arrayOfString[0]);
        if (!arrayOfString[1].contains("年"))
          arrayOfString[1] = (localCalendar.get(1) + this.mContext.getString(R.string.year) + arrayOfString[1]);
        SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日");
        Date localDate2 = localSimpleDateFormat.parse(arrayOfString[0]);
        Date localDate3 = localSimpleDateFormat.parse(arrayOfString[1]);
        if ((localDate2.compareTo(localDate1) <= 0) && (localDate1.compareTo(localDate3) <= 0))
        {
          this.yellowTag.setVisibility(0);
          this.useWeekId = this.weekId;
        }
        while (true)
        {
          if ((localDate2.compareTo(localDate1) >= 0) || (localDate1.compareTo(localDate3) <= 0))
            break label662;
          this.tvProgress.setVisibility(0);
          if (paramInt != 0)
            break label673;
          this.yellowTag.setVisibility(4);
          this.tvProgress.setVisibility(4);
          RelativeLayout localRelativeLayout = this.layout;
          if (paramBoolean)
            break label697;
          localObject = null;
          localRelativeLayout.setOnClickListener((View.OnClickListener)localObject);
          return;
          str1 = "";
          break;
          str2 = "";
          break label118;
          label611: i = R.color.color_c8c8c8;
          break label172;
          label619: j = R.color.color_c8c8c8;
          break label205;
          label627: k = R.color.color_c8c8c8;
          break label238;
          label635: m = 4;
          break label263;
          this.yellowTag.setVisibility(4);
        }
      }
      catch (ParseException localParseException)
      {
        while (true)
        {
          localParseException.printStackTrace();
          continue;
          label662: this.tvProgress.setVisibility(4);
          continue;
          label673: if (paramInt != 2)
            continue;
          this.yellowTag.setVisibility(4);
          this.tvProgress.setVisibility(0);
          continue;
          label697: Object localObject = new FitAction(null)
          {
            @Instrumented
            public void onClick(View paramView)
            {
              VdsAgent.onClick(this, paramView);
              Intent localIntent = new Intent(CustomizeWeekStatisticalView.this.mContext, WeekDataInfoActivity.class);
              localIntent.putExtra("custom_weekId", CustomizeWeekStatisticalView.this.weekId);
              localIntent.putExtra("custom_preFlag", CustomizeWeekStatisticalView.this.pageFlag);
              localIntent.putExtra("custom_weekNo", CustomizeWeekStatisticalView.this.weekTitle);
              localIntent.putExtra("custom_customId", CustomizeWeekStatisticalView.this.customId);
              if (CustomizeWeekStatisticalView.this.yellowTag.getVisibility() == 0);
              for (boolean bool = true; ; bool = false)
              {
                localIntent.putExtra("custom_this_week", bool);
                CustomizeWeekStatisticalView.this.mContext.startActivity(localIntent);
                AnimationUtil.pageJumpAnim((Activity)CustomizeWeekStatisticalView.this.mContext, 0);
                super.onClick(paramView);
                return;
              }
            }
          };
        }
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle7.customize.widget.CustomizeWeekStatisticalView
 * JD-Core Version:    0.6.0
 */