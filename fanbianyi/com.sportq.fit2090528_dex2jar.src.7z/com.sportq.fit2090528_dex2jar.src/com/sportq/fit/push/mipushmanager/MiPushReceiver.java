package com.sportq.fit.push.mipushmanager;

import android.content.Context;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.event.PushTokenEvent;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior;
import com.sportq.fit.middlelib.statistics.GrowingIOVariables;
import com.sportq.fit.push.PushModel;
import com.sportq.fit.push.notificationmanager.NotificationUtil;
import com.xiaomi.mipush.sdk.MiPushCommandMessage;
import com.xiaomi.mipush.sdk.MiPushMessage;
import com.xiaomi.mipush.sdk.PushMessageReceiver;
import java.util.List;
import java.util.Map;
import org.greenrobot.eventbus.EventBus;

public class MiPushReceiver extends PushMessageReceiver
{
  public void onCommandResult(Context paramContext, MiPushCommandMessage paramMiPushCommandMessage)
  {
    String str1 = paramMiPushCommandMessage.getCommand();
    List localList = paramMiPushCommandMessage.getCommandArguments();
    if ((localList != null) && (localList.size() > 0));
    for (String str2 = (String)localList.get(0); ; str2 = null)
    {
      LogUtils.e("MiPushManager", str1);
      if (("register".equals(str1)) && (paramMiPushCommandMessage.getResultCode() == 0L))
        EventBus.getDefault().post(new PushTokenEvent("1", str2));
      return;
    }
  }

  public void onNotificationMessageArrived(Context paramContext, MiPushMessage paramMiPushMessage)
  {
    VdsAgent.onXiaoMiMessageArrived(this, paramContext, paramMiPushMessage);
    LogUtils.e("MiPushReceiver--", "onNotificationMessageArrived");
    try
    {
      String str = String.valueOf(paramMiPushMessage.getExtra().get("intent_uri"));
      if (!StringUtils.isNull(str))
      {
        PushModel localPushModel = (PushModel)new Gson().fromJson(str, PushModel.class);
        GrowingIOVariables localGrowingIOVariables = new GrowingIOVariables();
        localGrowingIOVariables.eventid = "notification_show";
        localGrowingIOVariables.notification_manual = "1";
        localGrowingIOVariables.notification_content = localPushModel.pushCon;
        localGrowingIOVariables.notification_title = localPushModel.pushTitle;
        localGrowingIOVariables.notification_id = localPushModel.jumppushid;
        GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void onNotificationMessageClicked(Context paramContext, MiPushMessage paramMiPushMessage)
  {
    VdsAgent.onXiaoMiMessageClick(this, paramContext, paramMiPushMessage);
    LogUtils.e("MiPushReceiver--", "onNotificationMessageClicked");
    AppSharePreferenceUtils.putPushJumpJson(String.valueOf(paramMiPushMessage.getExtra().get("intent_uri")));
    FitJumpImpl.getInstance().pushJumpNavMainActivity(paramContext);
  }

  public void onReceivePassThroughMessage(Context paramContext, MiPushMessage paramMiPushMessage)
  {
    String str = paramMiPushMessage.getDescription();
    new NotificationUtil(paramContext).makeNotification(str);
    LogUtils.e("MiPushManager", str);
  }

  public void onReceiveRegisterResult(Context paramContext, MiPushCommandMessage paramMiPushCommandMessage)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.mipushmanager.MiPushReceiver
 * JD-Core Version:    0.6.0
 */