package com.sportq.fit.push.mipushmanager;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Process;
import android.text.TextUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.xiaomi.mipush.sdk.MiPushClient;
import java.util.Iterator;
import java.util.List;

public class MiPushManager
{
  private static final String XIAOMI = "Xiaomi".toLowerCase();
  private static final String phoneBrand = Build.BRAND;

  public static boolean checkDevice()
  {
    try
    {
      PackageManager localPackageManager = BaseApplication.appliContext.getPackageManager();
      boolean bool = TextUtils.equals(XIAOMI, phoneBrand.toLowerCase());
      int i = 0;
      if (bool)
      {
        PackageInfo localPackageInfo = localPackageManager.getPackageInfo("com.xiaomi.xmsf", 4);
        i = 0;
        if (localPackageInfo != null)
        {
          int j = localPackageInfo.versionCode;
          i = 0;
          if (j >= 105)
            i = 1;
        }
      }
      return i;
    }
    catch (Throwable localThrowable)
    {
    }
    return false;
  }

  public static void register(Context paramContext)
  {
    try
    {
      if (shouldInit(paramContext))
      {
        LogUtils.e("MiPushManager", "注册推送---start");
        MiPushClient.registerPush(paramContext, "2882303761517451674", "5961745164674");
        MiPushClient.subscribe(paramContext, CompDeviceInfoUtils.getVersionCode(), null);
        MiPushClient.subscribe(paramContext, "FitAll", null);
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e("MiPushManager", "注册推送---fail");
      LogUtils.e(localException);
    }
  }

  private static boolean shouldInit(Context paramContext)
  {
    List localList = ((ActivityManager)paramContext.getSystemService("activity")).getRunningAppProcesses();
    String str = paramContext.getPackageName();
    int i = Process.myPid();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      ActivityManager.RunningAppProcessInfo localRunningAppProcessInfo = (ActivityManager.RunningAppProcessInfo)localIterator.next();
      if ((localRunningAppProcessInfo.pid == i) && (str.equals(localRunningAppProcessInfo.processName)))
        return true;
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.mipushmanager.MiPushManager
 * JD-Core Version:    0.6.0
 */