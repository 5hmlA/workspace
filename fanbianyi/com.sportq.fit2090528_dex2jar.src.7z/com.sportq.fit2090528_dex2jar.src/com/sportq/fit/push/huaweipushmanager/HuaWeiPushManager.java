package com.sportq.fit.push.huaweipushmanager;

import android.content.Context;
import android.os.Build;
import com.huawei.android.pushagent.api.PushManager;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import java.util.HashMap;

public class HuaWeiPushManager
{
  private static final String phoneBrand = Build.BRAND;

  public static boolean checkDevice()
  {
    try
    {
      if (!phoneBrand.equalsIgnoreCase("huawei"))
      {
        boolean bool = phoneBrand.equalsIgnoreCase("honor");
        if (!bool)
          return false;
      }
      return true;
    }
    catch (Throwable localThrowable)
    {
    }
    return false;
  }

  public static void register(Context paramContext)
  {
    try
    {
      LogUtils.e("HuaWeiPushManager", "注册推送---start");
      PushManager.requestToken(paramContext);
      HashMap localHashMap = new HashMap();
      localHashMap.put("version", CompDeviceInfoUtils.getVersionCode());
      PushManager.setTags(paramContext, localHashMap);
      LogUtils.e("HuaWeiPushManager", "注册推送---ing");
      return;
    }
    catch (Throwable localThrowable)
    {
      LogUtils.e("HuaWeiPushManager", "注册推送---fail");
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.huaweipushmanager.HuaWeiPushManager
 * JD-Core Version:    0.6.0
 */