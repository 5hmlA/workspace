package com.sportq.fit.push.huaweipushmanager;

import android.content.Context;
import android.os.Bundle;
import com.huawei.android.pushagent.PushReceiver.Event;
import com.huawei.android.pushagent.api.PushEventReceiver;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.event.PushTokenEvent;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import org.greenrobot.eventbus.EventBus;

public class HuaWeiReceiver extends PushEventReceiver
{
  public void onEvent(Context paramContext, PushReceiver.Event paramEvent, Bundle paramBundle)
  {
    if ((PushReceiver.Event.NOTIFICATION_OPENED.equals(paramEvent)) || (PushReceiver.Event.NOTIFICATION_CLICK_BTN.equals(paramEvent)))
    {
      LogUtils.e("PushManager", "HuaWei-推送点击");
      String str = paramBundle.getString("pushMsg");
      if (!StringUtils.isNull(str))
      {
        LogUtils.e("PushManager", "HuaWei-" + str);
        AppSharePreferenceUtils.putPushJumpJson(str.replace("[{", "{").replace("}]", "}"));
        FitJumpImpl.getInstance().pushJumpNavMainActivity(paramContext);
      }
    }
    super.onEvent(paramContext, paramEvent, paramBundle);
  }

  public boolean onPushMsg(Context paramContext, byte[] paramArrayOfByte, Bundle paramBundle)
  {
    return false;
  }

  public void onToken(Context paramContext, String paramString, Bundle paramBundle)
  {
    EventBus.getDefault().post(new PushTokenEvent("2", paramString));
    LogUtils.e("HuaWeiPushManager", "注册推送---success");
    LogUtils.e("HuaWeiPushManager", "token:" + paramString);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.huaweipushmanager.HuaWeiReceiver
 * JD-Core Version:    0.6.0
 */