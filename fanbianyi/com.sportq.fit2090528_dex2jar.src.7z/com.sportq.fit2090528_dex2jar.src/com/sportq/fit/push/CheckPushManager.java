package com.sportq.fit.push;

import android.content.Context;
import android.content.Intent;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.push.getuipushmanager.GetuiPushManager;
import com.sportq.fit.push.huaweipushmanager.HuaWeiPushManager;
import com.sportq.fit.push.mipushmanager.MiPushManager;
import com.sportq.fit.supportlib.http.ApiImpl;
import rx.Observable;
import rx.Subscriber;

public class CheckPushManager
{
  public static Intent intent;

  public static String getPushChannel()
  {
    if (MiPushManager.checkDevice())
      return "1";
    if (HuaWeiPushManager.checkDevice())
      return "2";
    return "3";
  }

  public static void register(Context paramContext)
  {
    if (MiPushManager.checkDevice())
    {
      MiPushManager.register(paramContext);
      return;
    }
    if (HuaWeiPushManager.checkDevice())
    {
      HuaWeiPushManager.register(paramContext);
      return;
    }
    GetuiPushManager.register(paramContext);
  }

  public static void updatePushToken(String paramString1, String paramString2)
  {
    try
    {
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.pushType = paramString1;
      localRequestModel.token = paramString2;
      LogUtils.e("推送token---", paramString2);
      new ApiImpl().genDevReq(localRequestModel, null).subscribe(new Subscriber()
      {
        public void onCompleted()
        {
        }

        public void onError(Throwable paramThrowable)
        {
          LogUtils.e("推送--token", "上传失败");
        }

        public void onNext(ResponseModel paramResponseModel)
        {
          LogUtils.e("推送--token", "上传成功");
        }
      });
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.CheckPushManager
 * JD-Core Version:    0.6.0
 */