package com.sportq.fit.push;

import java.io.Serializable;

public class PushModel
  implements Serializable
{
  public static final long serialVersionUID = 1L;
  public String jump;
  public String jumpplanid;
  public String jumpptype;
  public String jumppushid;
  public String jumptype;
  public String pushCon;
  public Long pushTime;
  public String pushTitle;
  public String terrace;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.PushModel
 * JD-Core Version:    0.6.0
 */