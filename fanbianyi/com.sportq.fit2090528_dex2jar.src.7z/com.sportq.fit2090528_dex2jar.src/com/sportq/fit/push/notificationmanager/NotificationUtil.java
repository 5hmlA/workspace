package com.sportq.fit.push.notificationmanager;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build.VERSION;
import android.support.v4.app.NotificationCompat.Builder;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior;
import com.sportq.fit.middlelib.statistics.GrowingIOVariables;
import com.sportq.fit.push.PushModel;

public class NotificationUtil
{
  private Context mContext;

  public NotificationUtil(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private NotificationCompat.Builder getBuilder(PushModel paramPushModel, PendingIntent paramPendingIntent)
  {
    String str1 = paramPushModel.pushTitle;
    String str2 = paramPushModel.pushCon;
    long l = paramPushModel.pushTime.longValue();
    Uri localUri = Uri.parse("android.resource://" + this.mContext.getPackageName() + "/" + 2131230721);
    NotificationCompat.Builder localBuilder = new NotificationCompat.Builder(this.mContext, "Fit");
    localBuilder.setLargeIcon(BitmapFactory.decodeResource(this.mContext.getResources(), 2130903369)).setSmallIcon(2130837716).setContentTitle(str1).setContentText(str2).setWhen(l).setSound(localUri).setOngoing(true).setAutoCancel(true);
    localBuilder.setContentIntent(paramPendingIntent);
    return localBuilder;
  }

  public void makeNotification(String paramString)
  {
    if (StringUtils.isNull(paramString));
    while (true)
    {
      return;
      PushModel localPushModel = (PushModel)new Gson().fromJson(paramString, PushModel.class);
      if ((localPushModel == null) || (StringUtils.isNull(localPushModel.jumppushid)) || (AppSharePreferenceUtils.getPushNoticeIsShow(String.valueOf(localPushModel.jumppushid))))
        continue;
      int i = StringUtils.getRandom(1, 100000);
      Intent localIntent = new Intent(this.mContext, UpPushInfoReceiver.class);
      localIntent.putExtra("push.json", paramString);
      Context localContext = this.mContext;
      VdsAgent.onPendingIntentGetBroadcastBefore(localContext, i, localIntent, 134217728);
      PendingIntent localPendingIntent = PendingIntent.getBroadcast(localContext, i, localIntent, 134217728);
      VdsAgent.onPendingIntentGetBroadcastAfter(localContext, i, localIntent, 134217728, localPendingIntent);
      NotificationManager localNotificationManager = (NotificationManager)this.mContext.getSystemService("notification");
      if (localNotificationManager == null)
        continue;
      if (Build.VERSION.SDK_INT >= 26)
        localNotificationManager.createNotificationChannel(new NotificationChannel("Fit", "Fit通知", 4));
      Notification localNotification = getBuilder(localPushModel, localPendingIntent).build();
      localNotification.ledARGB = -16711936;
      localNotification.ledOnMS = 1000;
      localNotification.ledOffMS = 1000;
      localNotification.flags = 17;
      localNotificationManager.notify(i, localNotification);
      VdsAgent.onNotify((NotificationManager)localNotificationManager, i, localNotification);
      AppSharePreferenceUtils.putPushNoticeIsShow(String.valueOf(localPushModel.jumppushid));
      try
      {
        if (StringUtils.isNull(paramString))
          continue;
        GrowingIOVariables localGrowingIOVariables = new GrowingIOVariables();
        localGrowingIOVariables.eventid = "notification_show";
        localGrowingIOVariables.notification_manual = "1";
        localGrowingIOVariables.notification_content = localPushModel.pushCon;
        localGrowingIOVariables.notification_title = localPushModel.pushTitle;
        localGrowingIOVariables.notification_id = localPushModel.jumppushid;
        GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
        return;
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.notificationmanager.NotificationUtil
 * JD-Core Version:    0.6.0
 */