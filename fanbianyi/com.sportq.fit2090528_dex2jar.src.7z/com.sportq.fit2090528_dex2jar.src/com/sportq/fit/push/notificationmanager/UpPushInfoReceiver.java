package com.sportq.fit.push.notificationmanager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;

public class UpPushInfoReceiver extends BroadcastReceiver
{
  public static final String PUSH_JSON = "push.json";

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    VdsAgent.onBroadcastReceiver(this, paramContext, paramIntent);
    AppSharePreferenceUtils.putPushJumpJson(paramIntent.getStringExtra("push.json"));
    FitJumpImpl.getInstance().pushJumpNavMainActivity(paramContext);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.notificationmanager.UpPushInfoReceiver
 * JD-Core Version:    0.6.0
 */