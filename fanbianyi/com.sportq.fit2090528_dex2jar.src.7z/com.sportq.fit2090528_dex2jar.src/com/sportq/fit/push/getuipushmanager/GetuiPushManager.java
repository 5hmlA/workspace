package com.sportq.fit.push.getuipushmanager;

import android.content.Context;
import com.igexin.sdk.PushManager;
import com.igexin.sdk.Tag;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;

public class GetuiPushManager
{
  public static void register(Context paramContext)
  {
    try
    {
      LogUtils.e("GetuiPushManager", "register");
      PushManager.getInstance().initialize(paramContext, FitGetuiPushService.class);
      PushManager.getInstance().registerPushIntentService(paramContext, GetuiIntentService.class);
      Tag localTag = new Tag();
      localTag.setName(CompDeviceInfoUtils.getVersionCode());
      Tag[] arrayOfTag = { localTag };
      PushManager.getInstance().setTag(paramContext, arrayOfTag, System.currentTimeMillis() + "");
      return;
    }
    catch (Throwable localThrowable)
    {
      LogUtils.e("GetuiPushManager", "注册推送--fail");
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.getuipushmanager.GetuiPushManager
 * JD-Core Version:    0.6.0
 */