package com.sportq.fit.push.getuipushmanager;

import android.content.Context;
import com.igexin.sdk.GTIntentService;
import com.igexin.sdk.message.GTCmdMessage;
import com.igexin.sdk.message.GTNotificationMessage;
import com.igexin.sdk.message.GTTransmitMessage;
import com.sportq.fit.common.event.PushTokenEvent;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.push.notificationmanager.NotificationUtil;
import org.greenrobot.eventbus.EventBus;

public class GetuiIntentService extends GTIntentService
{
  public void onNotificationMessageArrived(Context paramContext, GTNotificationMessage paramGTNotificationMessage)
  {
    LogUtils.e("GetuiIntentService---", "onNotificationMessageArrived");
  }

  public void onNotificationMessageClicked(Context paramContext, GTNotificationMessage paramGTNotificationMessage)
  {
    LogUtils.e("GetuiIntentService---", "onNotificationMessageClicked");
  }

  public void onReceiveClientId(Context paramContext, String paramString)
  {
    LogUtils.e("GetuiIntentService---", "onReceiveClientId-" + paramString);
    if (StringUtils.isNull(paramString))
      return;
    EventBus.getDefault().post(new PushTokenEvent("3", paramString));
  }

  public void onReceiveCommandResult(Context paramContext, GTCmdMessage paramGTCmdMessage)
  {
  }

  public void onReceiveMessageData(Context paramContext, GTTransmitMessage paramGTTransmitMessage)
  {
    String str = new String(paramGTTransmitMessage.getPayload());
    LogUtils.e("GetuiIntentService---", "onReceiveMessageData" + str);
    new NotificationUtil(paramContext).makeNotification(str);
  }

  public void onReceiveOnlineState(Context paramContext, boolean paramBoolean)
  {
    LogUtils.e("GetuiIntentService---", "onReceiveOnlineState");
  }

  public void onReceiveServicePid(Context paramContext, int paramInt)
  {
    LogUtils.e("GetuiIntentService---", "onReceiveServicePid" + String.valueOf(paramInt));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.getuipushmanager.GetuiIntentService
 * JD-Core Version:    0.6.0
 */