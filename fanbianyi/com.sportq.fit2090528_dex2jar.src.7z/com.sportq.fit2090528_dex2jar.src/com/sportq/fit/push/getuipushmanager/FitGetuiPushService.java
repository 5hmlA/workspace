package com.sportq.fit.push.getuipushmanager;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.igexin.sdk.GTServiceManager;
import com.stub.StubApp;

public class FitGetuiPushService extends Service
{
  public static final String TAG;

  static
  {
    StubApp.interface11(12713);
    TAG = FitGetuiPushService.class.getName();
  }

  public IBinder onBind(Intent paramIntent)
  {
    Log.d(TAG, "onBind -------");
    return GTServiceManager.getInstance().onBind(paramIntent);
  }

  public void onCreate()
  {
    Log.d(TAG, TAG + " call -> onCreate -------");
    super.onCreate();
    GTServiceManager.getInstance().onCreate(this);
  }

  public void onDestroy()
  {
    Log.d(TAG, "onDestroy -------");
    super.onDestroy();
    GTServiceManager.getInstance().onDestroy();
  }

  public void onLowMemory()
  {
    super.onLowMemory();
    GTServiceManager.getInstance().onLowMemory();
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    VdsAgent.onServiceStartCommand(this, paramIntent, paramInt1, paramInt2);
    Log.d(TAG, TAG + " call -> onStartCommand -------");
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    return GTServiceManager.getInstance().onStartCommand(this, paramIntent, paramInt1, paramInt2);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.getuipushmanager.FitGetuiPushService
 * JD-Core Version:    0.6.0
 */