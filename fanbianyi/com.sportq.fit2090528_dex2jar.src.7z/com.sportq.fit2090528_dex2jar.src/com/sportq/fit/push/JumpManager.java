package com.sportq.fit.push;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.google.gson.Gson;
import com.sportq.fit.common.AppSharePreferenceUtils;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.activity.VipCenterActivity;
import com.sportq.fit.fitmoudle.event.GotoShopTabEvent;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import org.greenrobot.eventbus.EventBus;

public class JumpManager
{
  private static String[] commentLst;
  private static String[] likeLst;
  private static String[] noticeLst;
  private static String[] pushLst = { "0", "1", "3", "4", "7", "8", "10", "11", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "29", "30", "31", "32" };
  private static String[] remindLst;

  static
  {
    noticeLst = new String[] { "0", "1", "3", "4", "11", "17", "18", "20", "21", "22", "24", "25", "26", "29", "30", "31" };
    likeLst = new String[0];
    commentLst = new String[0];
    remindLst = new String[] { "4", "12", "13", "14", "19", "24", "25", "28" };
  }

  private static boolean checkIsJumpInfoFlg(String[] paramArrayOfString, String paramString)
  {
    int i = paramArrayOfString.length;
    for (int j = 0; ; j++)
    {
      int k = 0;
      if (j < i)
      {
        if (!paramArrayOfString[j].equals(paramString))
          continue;
        k = 1;
      }
      return k;
    }
  }

  public static void customPushJump(Context paramContext)
  {
    PushModel localPushModel;
    try
    {
      String str = AppSharePreferenceUtils.getPushJumpJson();
      if (StringUtils.isNull(str))
        return;
      AppSharePreferenceUtils.putPushJumpJson("");
      localPushModel = (PushModel)new Gson().fromJson(str, PushModel.class);
      switch (Integer.valueOf(localPushModel.jumpptype).intValue())
      {
      case 1:
        if (!checkIsJumpInfoFlg(pushLst, localPushModel.jumptype))
          break label240;
        managerJump(localPushModel, paramContext);
        return;
      case 2:
      case 3:
      case 4:
      case 5:
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      return;
    }
    if (checkIsJumpInfoFlg(noticeLst, localPushModel.jumptype))
    {
      managerJump(localPushModel, paramContext);
      return;
    }
    FitJumpImpl.getInstance().pushJumpNoticeActivity(paramContext, Constant.STR_2, null);
    return;
    if (checkIsJumpInfoFlg(likeLst, localPushModel.jumptype))
    {
      managerJump(localPushModel, paramContext);
      return;
    }
    FitJumpImpl.getInstance().pushJumpLikeListActivity(paramContext, Constant.STR_3);
    return;
    if (checkIsJumpInfoFlg(commentLst, localPushModel.jumptype))
    {
      managerJump(localPushModel, paramContext);
      return;
    }
    FitJumpImpl.getInstance().pushJumpCommentListActivity(paramContext, Constant.STR_4);
    return;
    if (checkIsJumpInfoFlg(remindLst, localPushModel.jumptype))
    {
      managerJump(localPushModel, paramContext);
      return;
    }
    FitJumpImpl.getInstance().pushJumpRemindListActivity(paramContext);
    label240: return;
  }

  private static void managerJump(PushModel paramPushModel, Context paramContext)
  {
    switch (Integer.valueOf(paramPushModel.jumptype).intValue())
    {
    case 1:
    case 2:
    case 5:
    case 6:
    case 7:
    case 15:
    case 16:
    case 27:
    default:
      return;
    case 0:
      FitJumpImpl.getInstance().pushJumpTrainInfoActivity(paramContext, paramPushModel.jumpplanid, "0", "clic", null);
      return;
    case 3:
      FitJumpImpl.getInstance().pushJumpArticleActivtiy(paramContext, paramPushModel.jumpplanid, null);
      return;
    case 4:
      FitJumpImpl.getInstance().pushJumpWebViewActivtiy(paramContext, "", paramPushModel.jumpplanid, "内容", "13", "clic", null);
      return;
    case 8:
      FitJumpImpl.getInstance().pushJumpSecActivity(paramContext, Constant.STR_1, "clic", null);
      return;
    case 9:
      FitJumpImpl.getInstance().pushJumpMissonActivity(paramContext, paramPushModel.jumpplanid, "clic", null);
      return;
    case 10:
      FitJumpImpl.getInstance().pushJumpTrainCustomizedActivity(paramContext);
      return;
    case 11:
      FitJumpImpl.getInstance().pushJumpChallengeActivity(paramContext, paramPushModel.jumpplanid, "", "clic", null);
      return;
    case 12:
      FitJumpImpl.getInstance().pushJumpEnergyDetailActivity(paramContext);
      return;
    case 13:
      FitJumpImpl.getInstance().pushJumpTrainRecordsActivity(paramContext, paramPushModel.jumpplanid, "1");
      return;
    case 14:
      FitJumpImpl.getInstance().pushJumpTrainRecordsActivity(paramContext, paramPushModel.jumpplanid, "2");
      return;
    case 17:
      FitJumpImpl.getInstance().pushBrowseVideoDetailsActivity(paramContext, paramPushModel.jumpplanid);
      return;
    case 18:
      FitJumpImpl.getInstance().pushMedalActivity(paramContext, paramPushModel.jumpplanid);
      return;
    case 19:
      FitJumpImpl.getInstance().pushFeedbackActivity(paramContext, paramPushModel.jumpplanid);
      return;
    case 20:
      FitJumpImpl.getInstance().pushShopRecommendListActivity(paramContext, paramPushModel.jumpplanid);
      return;
    case 21:
      FitJumpImpl.getInstance().pushMallGoodsInfoActivity(paramContext, paramPushModel.jumpplanid);
      return;
    case 22:
      EventBus.getDefault().post(new GotoShopTabEvent());
      return;
    case 23:
      FitJumpImpl.getInstance().pushMineOrderTrackActivity(paramContext, paramPushModel.jumpplanid);
      return;
    case 24:
      SharePreferenceUtils.putBuyVipFromPage("8");
      paramContext.startActivity(new Intent(paramContext, VipCenterActivity.class));
      AnimationUtil.pageJumpAnim((Activity)paramContext, 0);
      return;
    case 25:
      FitJumpImpl.getInstance().jumpEnergyActivity(paramContext);
      return;
    case 26:
      SharePreferenceUtils.putPhyFromPage("3");
      FitJumpImpl.getInstance().jumpFitnessTest(paramContext);
      return;
    case 28:
      FitJumpImpl.getInstance().jumpCourseAct(paramContext, "0");
      return;
    case 29:
      FitJumpImpl.getInstance().jumpMasterDetailAct(paramContext, paramPushModel.jumpplanid);
      return;
    case 30:
      FitJumpImpl.getInstance().jumpMasterListAct(paramContext);
      return;
    case 31:
      FitJumpImpl.getInstance().jumpCouponAct(paramContext);
      return;
    case 32:
    }
    EventBus.getDefault().post("jump.mine.tab");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.push.JumpManager
 * JD-Core Version:    0.6.0
 */