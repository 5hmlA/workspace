package com.sportq.fit.middlelib.presenter.mine;

import android.content.Context;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.interfaces.statistics.mine.MineStatisticsInterface;
import com.sportq.fit.common.model.NoticeModel;
import com.sportq.fit.common.model.PersonalCoachModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.middlelib.DexManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.statistics.find.MineStatistics;
import com.sportq.fit.supportlib.http.reformer.VipCommodityReformerImpl;
import com.sportq.fit.supportlib.http.reformer.VipHistReformerImpl;
import java.util.ArrayList;
import java.util.List;

public class MinePresenterImpl
  implements MinePresenterInterface
{
  private ApiInterface api;
  private MinePresenterInterface minePresenterInterface;
  private ReformerInterface reformerInterface;
  private FitInterfaceUtils.UIInitListener uiListener;

  public MinePresenterImpl()
  {
    this.api = DexManager.getInstance().getApi();
    this.minePresenterInterface = DexManager.getInstance().getMinePresenterInterface();
  }

  public MinePresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    setMinePresenter(paramUIInitListener, null);
  }

  public void addPhoneNumber(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.addPhoneNumber(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.addPhoneNumber", localException);
    }
  }

  public void checkPhoneNumber(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.checkPhoneNumber(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.checkPhoneNumber", localException);
    }
  }

  public Boolean checkTodayWeight()
  {
    try
    {
      Boolean localBoolean = this.minePresenterInterface.checkTodayWeight();
      return localBoolean;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.checkTodayWeight", localException);
    }
    return Boolean.valueOf(false);
  }

  public void checkWeightCommender()
  {
    try
    {
      this.minePresenterInterface.checkWeightCommender();
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.checkWeightCommender", localException);
    }
  }

  public void deleteCoach(PersonalCoachModel paramPersonalCoachModel)
  {
    try
    {
      this.minePresenterInterface.deleteCoach(paramPersonalCoachModel);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void deleteTrainPhoto(RequestModel paramRequestModel, Context paramContext)
  {
    this.minePresenterInterface.deleteTrainPhoto(paramRequestModel, paramContext);
  }

  public void exitLogin(Context paramContext)
  {
    try
    {
      this.minePresenterInterface.exitLogin(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.exitLogin", localException);
    }
  }

  public void feedback(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.feedback(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.feedback", localException);
    }
  }

  public int getBackgroundColor(String paramString)
  {
    try
    {
      int i = this.minePresenterInterface.getBackgroundColor(paramString);
      return i;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getBackgroundColor", localException);
    }
    return 0;
  }

  public void getCollect(Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getCollect(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getCollect", localException);
    }
  }

  public void getDataWithWelcome(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    try
    {
      this.minePresenterInterface.getDataWithWelcome(paramContext, paramString1, paramString2, paramString3);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public NoticeModel getDefaultModel(String paramString)
  {
    try
    {
      NoticeModel localNoticeModel = this.minePresenterInterface.getDefaultModel(paramString);
      return localNoticeModel;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getDefaultModel", localException);
    }
    return null;
  }

  public void getHealthAndDiet(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getHealthAndDiet(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getHealthAndDiet", localException);
    }
  }

  public ArrayList<PersonalCoachModel> getHistoryInfo(int paramInt)
  {
    try
    {
      ArrayList localArrayList = this.minePresenterInterface.getHistoryInfo(paramInt);
      return localArrayList;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return new ArrayList();
  }

  public void getMedalSuccess(Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getMedalSuccess(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getMedalSuccess", localException);
    }
  }

  public void getMessageList(RequestModel paramRequestModel, String paramString, List<Object> paramList, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getMessageList(paramRequestModel, paramString, paramList, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getMessageList", localException);
    }
  }

  public void getMessageNumber(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getMessageNumber(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getMessageNumber", localException);
    }
  }

  public void getMessageNumberC()
  {
    try
    {
      this.minePresenterInterface.getMessageNumberC();
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getMessageNumberC", localException);
    }
  }

  public void getNewResource(Context paramContext, String paramString)
  {
    try
    {
      this.minePresenterInterface.getNewResource(paramContext, paramString);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public long getNoticeCount()
  {
    try
    {
      long l = this.minePresenterInterface.getNoticeCount();
      return l;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.setNoticeItems", localException);
    }
    return 0L;
  }

  public ArrayList<NoticeModel> getNoticeItems(int paramInt)
  {
    try
    {
      ArrayList localArrayList = this.minePresenterInterface.getNoticeItems(paramInt);
      return localArrayList;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getNoticeItems", localException);
    }
    return null;
  }

  public void getNoticeItemsInfo()
  {
    try
    {
      this.minePresenterInterface.getNoticeItemsInfo();
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getNoticeItemsInfo", localException);
    }
  }

  public String getPersonalBMI(String paramString1, String paramString2)
  {
    try
    {
      String str = this.minePresenterInterface.getPersonalBMI(paramString1, paramString2);
      return str;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getPersonalBMI", localException);
    }
    return "";
  }

  public void getPhoneCode(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getPhoneCode(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getPhoneCode", localException);
    }
  }

  public void getRankSuccess(Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getRankSuccess(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getRankSuccess", localException);
    }
  }

  public void getTrainDetails(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getTrainDetails(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getTrainDetails", localException);
    }
  }

  public void getTrainPhoto(RequestModel paramRequestModel, Context paramContext)
  {
    this.minePresenterInterface.getTrainPhoto(paramRequestModel, paramContext);
  }

  public void getTrainPhotoAlbum(RequestModel paramRequestModel, Context paramContext)
  {
    String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GetTrainPhotoAlbum);
    this.reformerInterface = this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GetTrainPhotoAlbum);
    this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface, paramRequestModel);
  }

  public void getTrainRecord(String paramString, Context paramContext, int paramInt)
  {
    try
    {
      this.minePresenterInterface.getTrainRecord(paramString, paramContext, paramInt);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getTrainRecord", localException);
    }
  }

  public void getUserInfo(Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getUserInfo(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getUserInfo", localException);
    }
  }

  public void getVipCommodity(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      VipCommodityReformerImpl localVipCommodityReformerImpl = new VipCommodityReformerImpl();
      this.api.getHttp("/SFitWeb/sfit/getVipCommodity", paramContext, this.uiListener, localVipCommodityReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("getVipCommodity", localException);
    }
  }

  public void getVipHist(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      VipHistReformerImpl localVipHistReformerImpl = new VipHistReformerImpl();
      this.api.getHttp("/SFitWeb/sfit/getVipHist", paramContext, this.uiListener, localVipHistReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("getVipHist", localException);
    }
  }

  public void getWeight(RequestModel paramRequestModel, String paramString1, String paramString2, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.getWeight(paramRequestModel, paramString1, paramString2, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.getWeight", localException);
    }
  }

  public boolean password(String paramString1, String paramString2, Context paramContext)
  {
    try
    {
      boolean bool = this.minePresenterInterface.password(paramString1, paramString2, paramContext);
      return bool;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.password", localException);
    }
    return false;
  }

  public void reSendFeed(Context paramContext, ArrayList<PersonalCoachModel> paramArrayList, int paramInt)
  {
    try
    {
      this.minePresenterInterface.reSendFeed(paramContext, paramArrayList, paramInt);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void saveNoticeItemsInfo(Context paramContext, RequestModel paramRequestModel, List<NoticeModel> paramList, String paramString)
  {
    try
    {
      this.minePresenterInterface.saveNoticeItemsInfo(paramContext, paramRequestModel, paramList, paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.saveNoticeItemsInfo", localException);
    }
  }

  public void sendFeed(PersonalCoachModel paramPersonalCoachModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.sendFeed(paramPersonalCoachModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void setGenDevReq(Context paramContext)
  {
    try
    {
      this.minePresenterInterface.setGenDevReq(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.setGenDevReq", localException);
    }
  }

  public void setMinePresenter(FitInterfaceUtils.UIInitListener paramUIInitListener, ApiInterface paramApiInterface)
  {
    this.minePresenterInterface = DexManager.getInstance().getMinePresenterInterface();
    this.minePresenterInterface.setMinePresenter(paramUIInitListener, DexManager.getInstance().getApi());
    this.reformerInterface = DexManager.getInstance().getReformerInterface();
    if (this.api == null)
      this.api = DexManager.getInstance().getApi();
    if (paramUIInitListener != null)
      this.uiListener = paramUIInitListener;
  }

  public void setNoticeItems(List<NoticeModel> paramList)
  {
    try
    {
      this.minePresenterInterface.setNoticeItems(paramList);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.setNoticeItems", localException);
    }
  }

  public void setPassword(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.setPassword(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.setPassword", localException);
    }
  }

  public void setTodayWeight(String paramString)
  {
    try
    {
      this.minePresenterInterface.setTodayWeight(paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.setTodayWeight", localException);
    }
  }

  public String standbyPushInfo(List<NoticeModel> paramList)
  {
    try
    {
      String str = this.minePresenterInterface.standbyPushInfo(paramList);
      return str;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.standbyPushInfo", localException);
    }
    return "";
  }

  public void statsHealthDietArticleClick(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new MineStatistics().statsHealthDietArticleClick(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.statsHealthDietArticleClick", localException);
    }
  }

  public void statsTrainFeedBackUp(String paramString1, String paramString2)
  {
    try
    {
      MineStatistics localMineStatistics = new MineStatistics();
      String str = paramString1 + "|!|" + paramString2;
      FitAction.temporaryPCB(localMineStatistics.statsTrainFeedBackUp(), str);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.statsTrainFeedBackUp", localException);
    }
  }

  public void storeComment(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      this.minePresenterInterface.storeComment(paramContext, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.storeComment", localException);
    }
  }

  public void updateToNewInfo(ArrayList<PersonalCoachModel> paramArrayList, PersonalCoachModel paramPersonalCoachModel)
  {
    try
    {
      this.minePresenterInterface.updateToNewInfo(paramArrayList, paramPersonalCoachModel);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void updateUserInfo(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.minePresenterInterface.updateUserInfo(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MinePresenterImpl.updateUserInfo", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.presenter.mine.MinePresenterImpl
 * JD-Core Version:    0.6.0
 */