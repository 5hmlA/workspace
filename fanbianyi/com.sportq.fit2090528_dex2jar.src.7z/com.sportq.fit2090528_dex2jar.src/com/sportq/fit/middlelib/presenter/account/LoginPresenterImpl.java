package com.sportq.fit.middlelib.presenter.account;

import android.content.Context;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.statistics.AccountStatisticsInterface;
import com.sportq.fit.common.interfaces.support.PushInterface;
import com.sportq.fit.common.model.WelcomeModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.middlelib.DexManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.middlelib.support.PushImpl;
import com.sportq.fit.statistics.find.AccountStatistics;
import java.util.ArrayList;

public class LoginPresenterImpl
  implements LoginPresenterInterface
{
  private LoginPresenterInterface loginPresenterInterface;

  public LoginPresenterImpl()
  {
    this(null);
  }

  public LoginPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    setLoginPresenter(paramUIInitListener, new PushImpl(), DexManager.getInstance().getApi());
  }

  public void appPraiseBtnClick(String paramString)
  {
    try
    {
      AccountStatistics localAccountStatistics = new AccountStatistics();
      FitAction.temporaryPCC(localAccountStatistics.appPraiseBtnClick() + paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.appPraiseBtnClick", localException);
    }
  }

  public void checkPhoneNumber(String paramString1, String paramString2, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.checkPhoneNumber(paramString1, paramString2, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.checkPhoneNumber", localException);
    }
  }

  public WelcomeModel getAdLocalCacheData(Context paramContext)
  {
    try
    {
      WelcomeModel localWelcomeModel = this.loginPresenterInterface.getAdLocalCacheData(paramContext);
      return localWelcomeModel;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.getAdLocalCacheData", localException);
    }
    return new WelcomeModel();
  }

  public WelcomeModel getAdPopData(Context paramContext)
  {
    try
    {
      WelcomeModel localWelcomeModel = this.loginPresenterInterface.getAdPopData(paramContext);
      return localWelcomeModel;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.getAdPopData", localException);
    }
    return null;
  }

  public ArrayList<WelcomeModel> getAdRecommendData(Context paramContext)
  {
    try
    {
      ArrayList localArrayList = this.loginPresenterInterface.getAdRecommendData(paramContext);
      return localArrayList;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.getAdRecommendData", localException);
    }
    return null;
  }

  public WelcomeModel getAdTrainTabData(Context paramContext)
  {
    try
    {
      WelcomeModel localWelcomeModel = this.loginPresenterInterface.getAdTrainTabData(paramContext);
      return localWelcomeModel;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.getAdTrainTabData", localException);
    }
    return null;
  }

  public WelcomeModel getAdVipData(Context paramContext)
  {
    try
    {
      WelcomeModel localWelcomeModel = this.loginPresenterInterface.getAdVipData(paramContext);
      return localWelcomeModel;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.getAdVipData", localException);
    }
    return null;
  }

  public WelcomeModel getTrivia(Context paramContext)
  {
    try
    {
      WelcomeModel localWelcomeModel = this.loginPresenterInterface.getTrivia(paramContext);
      return localWelcomeModel;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.getTrivia", localException);
    }
    return new WelcomeModel();
  }

  public void getVerification(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.getVerification(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.checkPhoneNumber", localException);
    }
  }

  public void getVerification(String paramString1, String paramString2, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.getVerification(paramString1, paramString2, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.getVerification", localException);
    }
  }

  public void getWelcome(Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.getWelcome(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.getWelcome", localException);
    }
  }

  public void initLogin()
  {
    try
    {
      this.loginPresenterInterface.initLogin();
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.initLogin", localException);
    }
  }

  public void login(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.login(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.login", localException);
    }
  }

  public void mobileLogin(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.mobileLogin(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.mobileLogin", localException);
    }
  }

  public void postCheckVerification(String paramString1, String paramString2, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.postCheckVerification(paramString1, paramString2, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.postCheckVerification", localException);
    }
  }

  public void postPassword(String paramString1, String paramString2, String paramString3, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.postPassword(paramString1, paramString2, paramString3, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.postPassword", localException);
    }
  }

  public void quickLogin(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.quickLogin(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.quickLogin", localException);
    }
  }

  public void registerDownload()
  {
    try
    {
      this.loginPresenterInterface.registerDownload();
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.registerDownload", localException);
    }
  }

  public void setLoginPresenter(FitInterfaceUtils.UIInitListener paramUIInitListener, PushInterface paramPushInterface, ApiInterface paramApiInterface)
  {
    this.loginPresenterInterface = DexManager.getInstance().getLoginPresenterInterface();
    this.loginPresenterInterface.setLoginPresenter(paramUIInitListener, new PushImpl(), DexManager.getInstance().getApi());
  }

  public void setPasswordWithCode(String paramString1, String paramString2, String paramString3, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.setPasswordWithCode(paramString1, paramString2, paramString3, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.postPassword", localException);
    }
  }

  public void userRegister(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.loginPresenterInterface.userRegister(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("LoginPresenterImpl.userRegister", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.presenter.account.LoginPresenterImpl
 * JD-Core Version:    0.6.0
 */