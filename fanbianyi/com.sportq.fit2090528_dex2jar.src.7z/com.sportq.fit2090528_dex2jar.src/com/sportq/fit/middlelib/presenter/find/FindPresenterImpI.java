package com.sportq.fit.middlelib.presenter.find;

import android.content.Context;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.event.TrainFinishEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DownLoadListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.interfaces.statistics.find.FindStatisticsInterface;
import com.sportq.fit.common.interfaces.support.DownloadInterface;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.GetuiDataModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.CurriculumReformer;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.middlelib.DexManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.statistics.find.FindStatistics;
import com.sportq.fit.supportlib.CommonUtils;
import java.util.ArrayList;

public class FindPresenterImpI
  implements FindPresenterInterface
{
  private ApiInterface api = DexManager.getInstance().getApi();
  private FitInterfaceUtils.DownLoadListener downLoadListener;
  private DownloadInterface findDownloadInterface;
  private FindPresenterInterface findPresenterInterface;
  private ReformerInterface reformerInterface;
  private FitInterfaceUtils.UIInitListener uiListener;

  public FindPresenterImpI()
  {
    this(null, null);
  }

  public FindPresenterImpI(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this(paramUIInitListener, null);
  }

  public FindPresenterImpI(FitInterfaceUtils.UIInitListener paramUIInitListener, FitInterfaceUtils.DownLoadListener paramDownLoadListener)
  {
    setFindPresenter(paramUIInitListener, paramDownLoadListener, this.api);
  }

  public ArrayList<ActionModel> actionPreview(PlanModel paramPlanModel)
  {
    try
    {
      ArrayList localArrayList = this.findPresenterInterface.actionPreview(paramPlanModel);
      return localArrayList;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.actionPreview", localException);
    }
    return null;
  }

  public void addTrainPhoto(String paramString1, String paramString2, String paramString3, Context paramContext)
  {
    this.findPresenterInterface.addTrainPhoto(paramString1, paramString2, paramString3, paramContext);
  }

  public boolean checkDownLoad(ArrayList<String> paramArrayList)
  {
    try
    {
      boolean bool = this.findDownloadInterface.checkDownLoad(paramArrayList);
      return bool;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.checkDownLoad", localException);
    }
    return false;
  }

  public void choiceSinPlan(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.findPresenterInterface.choiceSinPlan(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.choiceSinPlan", localException);
    }
  }

  public void colPlan(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.findPresenterInterface.colPlan(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.colPlan", localException);
    }
  }

  public void distributionAction(Context paramContext, String paramString1, String paramString2, boolean paramBoolean, String paramString3)
  {
    try
    {
      FindStatistics localFindStatistics = new FindStatistics();
      FitAction.temporaryPCB(localFindStatistics.distributionAction(paramContext, paramString1, paramString2, paramBoolean, "0"), localFindStatistics.distributionAction(paramContext, paramString1, paramString2, paramBoolean, "1") + paramString3);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.distributionAction", localException);
    }
  }

  public boolean downLoadFile(ArrayList<String> paramArrayList, Context paramContext, String paramString1, String paramString2, DialogInterface paramDialogInterface, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    try
    {
      boolean bool = this.findDownloadInterface.downLoadFile(paramArrayList, paramContext, paramString1, paramString2, paramDialogInterface, paramString3, paramString4, paramString5, paramString6);
      return bool;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.downLoadFile", localException);
    }
    return false;
  }

  public void finishPlan(TrainFinishEvent paramTrainFinishEvent, boolean paramBoolean, Context paramContext)
  {
    try
    {
      this.findPresenterInterface.finishPlan(paramTrainFinishEvent, paramBoolean, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.finishPlan", localException);
    }
  }

  public void geTuiNoticeClick(GetuiDataModel paramGetuiDataModel)
  {
    try
    {
      FindStatistics localFindStatistics = new FindStatistics();
      String str = "p1|!|" + paramGetuiDataModel.jump + "|!|" + paramGetuiDataModel.jumptype + "|!|" + paramGetuiDataModel.jumpplanid + "|!|" + paramGetuiDataModel.jumppushid + "|!|" + paramGetuiDataModel.terrace + "|!|" + paramGetuiDataModel.pushFunction + "|!|" + paramGetuiDataModel.jumpptype;
      FitAction.temporaryPCB(localFindStatistics.statsGeTuiNoticeClick() + "0", str);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.geTuiNoticeClick", localException);
    }
  }

  public void getDiscoveryInfo(Context paramContext)
  {
    this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.Find);
    this.api.getHttp(this.reformerInterface.getURL(EnumConstant.FitUrl.Find), paramContext, this.uiListener, this.reformerInterface, new RequestModel());
  }

  public void getGrpWithClassifyId(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GrpPlan);
      this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GrpPlan);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getGrpWithClassifyId", localException);
    }
  }

  public void getMission(Context paramContext)
  {
    try
    {
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GetMission);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GetMission), new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getMission", localException);
    }
  }

  public void getMissionDet(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GetMissionDet);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GetMissionDet), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getMissionDet", localException);
    }
  }

  public void getMissionPlan(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GetMissionPlan);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GetMissionPlan), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getMissionPlan", localException);
    }
  }

  public void getPlanInfoWithPlanId(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.PlanDet);
      this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.PlanDet);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getPlanInfoWithPlanId", localException);
    }
  }

  public void getPlanProgressWithPlanId(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.findPresenterInterface.getPlanProgressWithPlanId(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getPlanProgressWithPlanId", localException);
    }
  }

  public void getPoster(Context paramContext)
  {
    String str = this.reformerInterface.getURL(EnumConstant.FitUrl.PosterAndWaterMark);
    this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.PosterAndWaterMark), new RequestModel());
  }

  public void getReceiveMedalsSuccess(Context paramContext, FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    try
    {
      this.findPresenterInterface.getReceiveMedalsSuccess(paramContext, paramUIInitListener);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getReceiveMedalsSuccess", localException);
    }
  }

  public void getReceiveMedalsSuccessAndShowMedal(Context paramContext)
  {
    try
    {
      this.findPresenterInterface.getReceiveMedalsSuccessAndShowMedal(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getReceiveMedalsSuccessAndShowMedal", localException);
    }
  }

  public void getRelatedCourses(String paramString, Context paramContext)
  {
    String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GetRelatedCourses);
    this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GetRelatedCourses);
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.planId = paramString;
    this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface, localRequestModel);
  }

  public float getSecondKaluri(PlanModel paramPlanModel)
  {
    try
    {
      float f = this.findPresenterInterface.getSecondKaluri(paramPlanModel);
      return f;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getSecondKaluri", localException);
    }
    return 0.0F;
  }

  public void getSystemTime(Context paramContext)
  {
    try
    {
      CommonUtils.deleteFile(EnumConstant.FitUrl.GetSystemTime);
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GetSystemTime);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GetSystemTime), new RequestModel());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getSystemTime", localException);
    }
  }

  public float getTotalConsumeKaluri(int paramInt, PlanModel paramPlanModel)
  {
    try
    {
      float f = this.findPresenterInterface.getTotalConsumeKaluri(paramInt, paramPlanModel);
      return f;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getTotalConsumeKaluri", localException);
    }
    return 0.0F;
  }

  public void getTypeListWithTypeId(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.ClassifyPlan);
      this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.ClassifyPlan);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getTypeListWithTypeId", localException);
    }
  }

  public void getVideoURL(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.findPresenterInterface.getVideoURL(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getVideoURL", localException);
    }
  }

  public void getWinners(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GetWinners);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GetWinners), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.getWinners", localException);
    }
  }

  public boolean gradeToast(Context paramContext)
  {
    try
    {
      boolean bool = this.findPresenterInterface.gradeToast(paramContext);
      return bool;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.gradeToast", localException);
    }
    return false;
  }

  public void gradeToastClick(Context paramContext, String paramString)
  {
    try
    {
      this.findPresenterInterface.gradeToastClick(paramContext, paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.gradeToastClick", localException);
    }
  }

  public void joinMission(RequestModel paramRequestModel, Context paramContext)
  {
    this.findPresenterInterface.joinMission(paramRequestModel, paramContext);
  }

  public void joinPlan(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.findPresenterInterface.joinPlan(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.joinPlan", localException);
    }
  }

  public boolean noticeToast(Context paramContext)
  {
    try
    {
      boolean bool = this.findPresenterInterface.noticeToast(paramContext);
      return bool;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.noticeToast", localException);
    }
    return false;
  }

  public void noticeToastClick(Context paramContext)
  {
    try
    {
      this.findPresenterInterface.noticeToastClick(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.noticeToastClick", localException);
    }
  }

  public void onStopDownLoad()
  {
    try
    {
      this.findDownloadInterface.onStopDownLoad();
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.onStopDownLoad", localException);
    }
  }

  public void puseDownload(ArrayList<String> paramArrayList, Context paramContext, String paramString1, String paramString2, DialogInterface paramDialogInterface, String paramString3, String paramString4, String paramString5)
  {
    try
    {
      this.findDownloadInterface.puseDownload(paramArrayList, paramContext, paramString1, paramString2, paramDialogInterface, paramString3, paramString4, paramString5);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.puseDownload", localException);
    }
  }

  public void saveTrainData(RequestModel paramRequestModel)
  {
    try
    {
      this.findPresenterInterface.saveTrainData(paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.saveTrainData", localException);
    }
  }

  public void sereenCurriculumInfo(CurriculumReformer paramCurriculumReformer, Context paramContext)
  {
    try
    {
      this.findPresenterInterface.sereenCurriculumInfo(paramCurriculumReformer, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.sereenCurriculumInfo", localException);
    }
  }

  public void setFindPresenter(FitInterfaceUtils.UIInitListener paramUIInitListener, FitInterfaceUtils.DownLoadListener paramDownLoadListener, ApiInterface paramApiInterface)
  {
    this.findPresenterInterface = DexManager.getInstance().getFindPresenterInterface();
    if (paramUIInitListener != null)
      this.uiListener = paramUIInitListener;
    if (paramDownLoadListener != null)
    {
      this.downLoadListener = paramDownLoadListener;
      this.findDownloadInterface = DexManager.getInstance().getFindDownloadInterface();
      this.findDownloadInterface.setDownloadInterface(this.downLoadListener, this);
    }
    if (paramApiInterface == null)
      paramApiInterface = DexManager.getInstance().getApi();
    this.reformerInterface = DexManager.getInstance().getReformerInterface();
    this.findPresenterInterface.setFindPresenter(paramUIInitListener, paramDownLoadListener, paramApiInterface);
  }

  public void socialShare(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      this.findPresenterInterface.socialShare(paramContext, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.socialShare", localException);
    }
  }

  public void startPlan(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.findPresenterInterface.startPlan(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.startPlan", localException);
    }
  }

  public void statsCustomizedExit(String paramString)
  {
    try
    {
      FindStatistics localFindStatistics = new FindStatistics();
      FitAction.temporaryPCC(localFindStatistics.statsCustomizedExit() + paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsCustomizedExit", localException);
    }
  }

  public void statsPlanRelatedCoursesClick(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsPlanRelatedCoursesClick(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsPlanRelatedCoursesClick", localException);
    }
  }

  public void statsPlanRelatedCoursesClick02(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsPlanRelatedCoursesClick02(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsPlanRelatedCoursesClick02", localException);
    }
  }

  public void statsPublishFinishBtnClick(String paramString1, String paramString2)
  {
    try
    {
      FindStatistics localFindStatistics = new FindStatistics();
      FitAction.temporaryPCB(localFindStatistics.statsPublishFinishBtnClick() + paramString2, paramString1);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsPublishFinishBtnClick", localException);
    }
  }

  public void statsRecommendItemClick(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsRecommendItemClick(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsRecommendItemClick", localException);
    }
  }

  public void statsRelatedCoursesItemClick(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsRelatedCoursesItemClick(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsRelatedCoursesItemClick", localException);
    }
  }

  public void statsSaveLocalClick()
  {
    try
    {
      FitAction.temporaryPCC(new FindStatistics().statsSaveLocalClick());
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsSaveLocalClick", localException);
    }
  }

  public void statsSingleRelatedCoursesClick(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsSingleRelatedCoursesClick(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsSingleRelatedCoursesClick", localException);
    }
  }

  public void statsTakePhotoPermission(String paramString1, String paramString2)
  {
    try
    {
      FindStatistics localFindStatistics = new FindStatistics();
      FitAction.temporaryPCB(localFindStatistics.statsTakePhotoPermission(), paramString1);
      FitAction.temporaryPCB(localFindStatistics.statsTakePhotoPermission(), paramString2);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsTakePhotoPermission", localException);
    }
  }

  public void statsTrainFinishCameraClick(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsTrainFinishCameraClick(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsTrainFinishCameraClick", localException);
    }
  }

  public void statsTrainFinishFeedBackBtn(String paramString1, String paramString2, String paramString3)
  {
    try
    {
      FindStatistics localFindStatistics = new FindStatistics();
      String str = paramString1 + "|!|" + paramString2;
      FitAction.temporaryPCB(localFindStatistics.statsTrainFinishFeedBackBtn() + paramString3, str);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsTrainFinishFeedBackBtn", localException);
    }
  }

  public void statsTrainInfoImgClick(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsTrainInfoImgClick(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsTrainInfoImgClick", localException);
    }
  }

  public void statsTrainInfoMoreDeleteClick(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsTrainInfoMoreDeleteClick(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsTrainInfoMoreDeleteClick", localException);
    }
  }

  public void statsTrainInfoMoreFeedBackBtn(String paramString1, String paramString2, String paramString3)
  {
    try
    {
      FindStatistics localFindStatistics = new FindStatistics();
      String str = paramString2 + "|!|" + paramString3;
      FitAction.temporaryPCB(localFindStatistics.statsTrainInfoMoreFeedBackBtn(paramString1), str);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsTrainInfoMoreFeedBackBtn", localException);
    }
  }

  public void statsTrainListMoreFeedBackBtn(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsTrainListMoreFeedBackBtn(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsTrainListMoreFeedBackBtn", localException);
    }
  }

  public void statsTrainRecordAlbumClick(String paramString)
  {
    try
    {
      FitAction.temporaryPCB(new FindStatistics().statsTrainRecordAlbumClick(), paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsTrainRecordAlbumClick", localException);
    }
  }

  public void statsVideoDownLoadFinish(String paramString1, String paramString2, String paramString3)
  {
    try
    {
      FindStatistics localFindStatistics = new FindStatistics();
      String str = paramString1 + "|!|" + paramString2 + "|!||!|" + DateUtils.getCurDateTime() + paramString3;
      FitAction.temporaryPCB(localFindStatistics.statsVideoDownLoadFinish() + "1", str);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.statsVideoDownLoadFinish", localException);
    }
  }

  public void trainInfoAction(String paramString, PlanReformer paramPlanReformer)
  {
    try
    {
      FindStatistics localFindStatistics = new FindStatistics();
      if ("0".equals(paramString));
      for (PlanModel localPlanModel = paramPlanReformer._individualInfo; ; localPlanModel = paramPlanReformer._planInfo)
      {
        FitAction.temporaryPCB(localFindStatistics.trainInfoAction(paramString), localPlanModel.olapInfo);
        return;
      }
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.trainInfoAction", localException);
    }
  }

  public void uploadLocalTrainData(Context paramContext, DialogInterface paramDialogInterface)
  {
    try
    {
      this.findPresenterInterface.uploadLocalTrainData(paramContext, paramDialogInterface);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPresenterImpI.uploadLocalTrainData", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.presenter.find.FindPresenterImpI
 * JD-Core Version:    0.6.0
 */