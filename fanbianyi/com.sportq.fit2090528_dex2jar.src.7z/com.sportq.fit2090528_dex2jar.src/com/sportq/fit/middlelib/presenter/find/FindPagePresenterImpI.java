package com.sportq.fit.middlelib.presenter.find;

import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPagePresenterInterface;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.reformer.TrainingReformer;
import com.sportq.fit.middlelib.DexManager;
import com.sportq.fit.middlelib.statistics.FitAction;

public class FindPagePresenterImpI
  implements FindPagePresenterInterface
{
  private ApiInterface apiInterface;
  private FindPagePresenterInterface findPagePresenterInterface;

  public FindPagePresenterImpI()
  {
    DexManager localDexManager = DexManager.getInstance();
    this.findPagePresenterInterface = localDexManager.getFindPagePresenterInterface();
    this.apiInterface = localDexManager.getApi();
  }

  public void getCurrentStageAndActionModel(TrainingReformer paramTrainingReformer)
  {
    try
    {
      this.findPagePresenterInterface.getCurrentStageAndActionModel(paramTrainingReformer);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPagePresenterImpI.getCurrentStageAndActionModel", localException);
    }
  }

  public boolean lastActionEvent(TrainingReformer paramTrainingReformer)
  {
    try
    {
      boolean bool = this.findPagePresenterInterface.lastActionEvent(paramTrainingReformer);
      return bool;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPagePresenterImpI.lastActionEvent", localException);
    }
    return false;
  }

  public boolean nextActionEvent(TrainingReformer paramTrainingReformer)
  {
    try
    {
      boolean bool = this.findPagePresenterInterface.nextActionEvent(paramTrainingReformer);
      return bool;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPagePresenterImpI.nextActionEvent", localException);
    }
    return false;
  }

  public TrainingReformer planReformerToTrainingReformer(PlanReformer paramPlanReformer)
  {
    try
    {
      TrainingReformer localTrainingReformer = this.findPagePresenterInterface.planReformerToTrainingReformer(paramPlanReformer);
      return localTrainingReformer;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("FindPagePresenterImpI.planReformerToTrainingReformer", localException);
    }
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.presenter.find.FindPagePresenterImpI
 * JD-Core Version:    0.6.0
 */