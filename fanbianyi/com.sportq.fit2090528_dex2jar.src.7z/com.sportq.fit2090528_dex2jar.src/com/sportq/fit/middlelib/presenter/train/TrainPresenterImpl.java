package com.sportq.fit.middlelib.presenter.train;

import android.content.Context;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.presenter.train.TrainPresenterInterface;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.interfaces.statistics.TrainStatisticsInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.middlelib.DexManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.statistics.find.TrainStatistics;

public class TrainPresenterImpl
  implements TrainPresenterInterface
{
  private ApiInterface api = DexManager.getInstance().getApi();
  private ReformerInterface reformerInterface;
  private TrainPresenterInterface trainInterface;
  private FitInterfaceUtils.UIInitListener uiListener;

  public TrainPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    setTrainPresenter(paramUIInitListener, this.api);
  }

  public void customizedDifficultcomment(int paramInt)
  {
    try
    {
      this.trainInterface.customizedDifficultcomment(paramInt);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.customizedDifficultcomment", localException);
    }
  }

  public void customizedDifficultcommentWithCode()
  {
    try
    {
      this.trainInterface.customizedDifficultcommentWithCode();
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.customizedDifficultcommentWithCode", localException);
    }
  }

  public void customizedDifficultcommentWithCode(String paramString)
  {
    try
    {
      this.trainInterface.customizedDifficultcommentWithCode(paramString);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.customizedDifficultcommentWithCode", localException);
    }
  }

  public void getCustomInfo(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GetCustomInfo);
      this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GetCustomInfo);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.getCustomInfo", localException);
    }
  }

  public void getQuestionnaireInfo(Context paramContext)
  {
    try
    {
      this.trainInterface.getQuestionnaireInfo(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.getQuestionnaireInfo", localException);
    }
  }

  public void getRecommendInfo(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = this.reformerInterface.getURL(EnumConstant.FitUrl.GetRecommendInfo);
      this.reformerInterface.getReformerInterface(EnumConstant.FitUrl.GetRecommendInfo);
      this.api.getHttp(str, paramContext, this.uiListener, this.reformerInterface, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.getRecommendInfo", localException);
    }
  }

  public void getTailorbranch(Context paramContext)
  {
    try
    {
      this.trainInterface.getTailorbranch(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.getTailorbranch", localException);
    }
  }

  public void outOrder(Context paramContext)
  {
    try
    {
      this.trainInterface.outOrder(paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.outOrder", localException);
    }
  }

  public void recommendCourseAction(String paramString1, String paramString2)
  {
    try
    {
      TrainStatistics localTrainStatistics = new TrainStatistics();
      FitAction.temporaryPCB(localTrainStatistics.recommendCourseAction() + paramString1, paramString2);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.recommendCourseAction", localException);
    }
  }

  public void setTrainPresenter(FitInterfaceUtils.UIInitListener paramUIInitListener, ApiInterface paramApiInterface)
  {
    this.trainInterface = DexManager.getInstance().getTrainPresenterInterface();
    if (paramUIInitListener != null)
    {
      this.uiListener = paramUIInitListener;
      this.trainInterface.setTrainPresenter(paramUIInitListener, DexManager.getInstance().getApi());
    }
    if (this.api == null)
      this.api = DexManager.getInstance().getApi();
    this.reformerInterface = DexManager.getInstance().getReformerInterface();
    this.trainInterface.setTrainPresenter(paramUIInitListener, this.api);
  }

  public void trainShortTimeRemind(String paramString1, String paramString2)
  {
    try
    {
      TrainStatistics localTrainStatistics = new TrainStatistics();
      FitAction.temporaryPCB(localTrainStatistics.trainShortTimeRemind() + paramString1, paramString2);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.trainShortTimeRemind", localException);
    }
  }

  public void viewCustom(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.trainInterface.viewCustom(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.viewCustom", localException);
    }
  }

  public void viewCustomNew(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.trainInterface.viewCustomNew(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("TrainPresenterImpl.viewCustomNew", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.presenter.train.TrainPresenterImpl
 * JD-Core Version:    0.6.0
 */