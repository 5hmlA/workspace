package com.sportq.fit.middlelib.presenter.account;

import android.content.Context;
import android.content.res.Resources;
import com.huawei.android.hms.agent.HMSAgent.Hwid;
import com.huawei.android.hms.agent.hwid.handler.SignInHandler;
import com.huawei.android.hms.agent.hwid.handler.SignOutHandler;
import com.huawei.hms.support.api.hwid.SignInHuaweiId;
import com.huawei.hms.support.api.hwid.SignOutResult;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.OnRequestNetworkListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.interfaces.statistics.AccountStatisticsInterface;
import com.sportq.fit.common.interfaces.support.PushInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.middlelib.DexManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.middlelib.support.PushImpl;
import com.sportq.fit.statistics.find.AccountStatistics;
import com.sportq.fit.supportlib.share.SSOLogin;
import com.sportq.fit.uicommon.R.string;

public class RegisterPresenterImpl
  implements RegisterPresenterInterface
{
  private RegisterPresenterInterface registerPresenter;
  private FitInterfaceUtils.UIInitListener uiInitListener;

  public RegisterPresenterImpl()
  {
    this(null);
  }

  public RegisterPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    setRegisterPresenter(paramUIInitListener, null, null);
  }

  public String bmiDetials(String paramString)
  {
    try
    {
      String str = this.registerPresenter.bmiDetials(paramString);
      return str;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("RegisterPresenterImpl.bmiDetials", localException);
    }
    return "";
  }

  public void registerAccountBind(String paramString1, String paramString2, Context paramContext)
  {
    while (true)
    {
      try
      {
        if (!"2".equals(paramString2))
          continue;
        this.registerPresenter.registerAccountBind(paramString1, paramString2, paramContext);
        return;
        str = "";
        if ("0".equals(paramString1))
        {
          str = "SinaWeibo";
          ssoLogin(paramContext, str, paramString1);
          return;
        }
      }
      catch (Exception localException)
      {
        FitAction.upload_e("RegisterPresenterImpl.registerAccountBind", localException);
        return;
      }
      if ("1".equals(paramString1))
      {
        str = "QQ";
        continue;
      }
      if (!"7".equals(paramString1))
        continue;
      String str = "Wechat";
    }
  }

  public void registerBindAccount(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      this.registerPresenter.registerBindAccount(paramRequestModel, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("RegisterPresenterImpl.registerBindAccount", localException);
    }
  }

  public void registerWithImg(String paramString, Context paramContext, FitInterfaceUtils.OnRequestNetworkListener paramOnRequestNetworkListener)
  {
    try
    {
      this.registerPresenter.registerWithImg(paramString, paramContext, paramOnRequestNetworkListener);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("RegisterPresenterImpl.registerWithImg", localException);
    }
  }

  public void setRegisterPresenter(FitInterfaceUtils.UIInitListener paramUIInitListener, ApiInterface paramApiInterface, PushInterface paramPushInterface)
  {
    this.uiInitListener = paramUIInitListener;
    this.registerPresenter = DexManager.getInstance().getRegisterPresenterInterface();
    this.registerPresenter.setRegisterPresenter(paramUIInitListener, DexManager.getInstance().getApi(), new PushImpl());
  }

  public void ssoLogin(Context paramContext, String paramString1, String paramString2)
  {
    try
    {
      if ("11".equals(paramString2))
      {
        HMSAgent.Hwid.signIn(true, new SignInHandler(paramString2, paramContext)
        {
          public void onResult(int paramInt, SignInHuaweiId paramSignInHuaweiId)
          {
            if ((paramInt == 0) && (paramSignInHuaweiId != null))
            {
              LogUtils.e("华为---", "登录成功=========");
              LogUtils.e("华为---", "昵称:" + paramSignInHuaweiId.getDisplayName());
              LogUtils.e("华为---", "openid:" + paramSignInHuaweiId.getOpenId());
              LogUtils.e("华为---", "accessToken:" + paramSignInHuaweiId.getAccessToken());
              LogUtils.e("华为---", "头像url:" + paramSignInHuaweiId.getPhotoUrl());
              BaseApplication.thirdUserModel.userName = paramSignInHuaweiId.getDisplayName();
              BaseApplication.thirdUserModel.userImg = paramSignInHuaweiId.getPhotoUrl();
              BaseApplication.thirdUserModel.uid = paramSignInHuaweiId.getOpenId();
              RequestModel localRequestModel = new RequestModel();
              localRequestModel.uid = paramSignInHuaweiId.getOpenId();
              localRequestModel.terrace = this.val$choice;
              localRequestModel.strDealFlg = "1";
              RegisterPresenterImpl.this.registerBindAccount(localRequestModel, this.val$context);
              return;
            }
            if (paramInt == 2005)
              RegisterPresenterImpl.this.uiInitListener.getDataFail(this.val$context.getResources().getString(R.string.h_32_5));
            while (true)
            {
              RegisterPresenterImpl.this.uiInitListener.getDataFail("");
              LogUtils.e("华为---", "登录---error: " + paramInt);
              return;
              if (paramInt != -1005)
                continue;
              RegisterPresenterImpl.this.uiInitListener.getDataFail("华为授权取消");
            }
          }
        });
        return;
      }
      new SSOLogin(this.uiInitListener, this).login(paramContext, paramString1, paramString2);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("RegisterPresenterImpl.ssoLogin", localException);
    }
  }

  public void ssoRemoveAccount(Context paramContext, String paramString)
  {
    try
    {
      if ("huawei".equals(paramString))
      {
        if (CompDeviceInfoUtils.isHuaweiChannel())
        {
          HMSAgent.Hwid.signOut(new SignOutHandler()
          {
            public void onResult(int paramInt, SignOutResult paramSignOutResult)
            {
            }
          });
          return;
        }
      }
      else
      {
        new SSOLogin(this.uiInitListener, this).removeAccount(paramContext, paramString);
        return;
      }
    }
    catch (Exception localException)
    {
      FitAction.upload_e("RegisterPresenterImpl.ssoRemoveAccount", localException);
    }
  }

  public void statsFitAdClick(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    try
    {
      AccountStatistics localAccountStatistics = new AccountStatistics();
      String str = paramString2 + "|!|" + paramString3 + "|!|" + paramString4 + "|!|" + paramString5;
      FitAction.temporaryPCB(localAccountStatistics.statsFitAdClick() + paramString1, str);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("RegisterPresenterImpl.statsFitAdClick", localException);
    }
  }

  public void userRegister(String paramString, Context paramContext)
  {
    try
    {
      this.registerPresenter.userRegister(paramString, paramContext);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("RegisterPresenterImpl.userRegister", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.presenter.account.RegisterPresenterImpl
 * JD-Core Version:    0.6.0
 */