package com.sportq.fit.middlelib.statistics;

public class GrowingIOEventId
{
  public static final String STR_AD_BANNER_CLICK = "ad_banner_click";
  public static final String STR_AD_INTERSTITIAL_CLICK = "ad_interstitial_click";
  public static final String STR_AD_INTERSTITIAL_SHOW = "ad_interstitial_show";
  public static final String STR_BUYPRODUCT = "buyProduct";
  public static final String STR_COMPLETE_INFO = "complete_info";
  public static final String STR_COURSE_CAROUSEL = "courseCarousel";
  public static final String STR_EXISTCOURSE = "existCourse";
  public static final String STR_FINISHCOURSE = "finishCourse";
  public static final String STR_JOINCOURSE = "joinCourse";
  public static final String STR_NOTIFICATION_CLICK = "notification_click";
  public static final String STR_NOTIFICATION_SHOW = "notification_show";
  public static final String STR_REGISTER = "register";
  public static final String STR_SEARCHCOURSE = "searchCourse";
  public static final String STR_SELECT_COURSE = "regSelectCourse";
  public static final String STR_SHARE_EVENT_CLICK = "share_event";
  public static final String STR_STARTCOURSE = "startCourse";
  public static final String STR_VIEW_PAGE = "view_page";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.statistics.GrowingIOEventId
 * JD-Core Version:    0.6.0
 */