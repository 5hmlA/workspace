package com.sportq.fit.middlelib.statistics;

public class GrowingIOVariables
{
  public String actionIndex;
  public String actionName;
  public String ad_id;
  public String ad_title;
  public String apiPath;
  public String buyType;
  public String carouselId;
  public String carouselType;
  public String courseName;
  public String eventid;
  public String is_select;
  public String is_select_all;
  public String notification_content;
  public String notification_id;
  public String notification_manual;
  public String notification_title;
  public String page_id;
  public String page_title;
  public String page_type;
  public String reason;
  public String regCourseSelTag;
  public String regTimeDiff;
  public String registerType;
  public String searchKey;
  public String share_type;
  public String timeSlot;
  public String trainAllCount;
  public String trainTime;
  public String trainType;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.statistics.GrowingIOVariables
 * JD-Core Version:    0.6.0
 */