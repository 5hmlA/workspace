package com.sportq.fit.middlelib.statistics;

import android.support.v4.util.ArrayMap;
import com.google.gson.Gson;
import com.growingio.android.sdk.collection.GrowingIO;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.supportlib.CommonUtils;
import java.lang.reflect.Field;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;

public class GrowingIOUserBehavior
{
  private static final String STR_JS_NAME = "statistics.js";
  private static final String STR_METHOD_NAME = "artificialGrowingIO";
  private static final String STR_METHOD_NAME01 = "statisticsGrowingIO";

  private static void innerUploadGrowingIO(String paramString)
  {
    try
    {
      if (StringUtils.isNull(paramString))
        return;
      GrowingIO localGrowingIO = GrowingIO.getInstance();
      JSONArray localJSONArray = new JSONObject(paramString).optJSONArray("track");
      if ((localJSONArray != null) && (localJSONArray.length() > 0))
        for (int i = 0; i < localJSONArray.length(); i++)
        {
          JSONObject localJSONObject = (JSONObject)localJSONArray.get(i);
          localGrowingIO.track(localJSONObject.optString("eventid"), new JSONObject(localJSONObject.optString("variable")));
        }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  private static String paramToJson(Object paramObject)
  {
    Class localClass = paramObject.getClass();
    Object localObject = "{";
    Field[] arrayOfField = localClass.getDeclaredFields();
    int i = arrayOfField.length;
    for (int j = 0; ; j++)
      if (j < i)
      {
        Field localField = arrayOfField[j];
        localField.setAccessible(true);
        try
        {
          String str2 = String.valueOf(localField.get(paramObject));
          if ((StringUtils.isNull(str2)) || ("serialVersionUID".equals(localField.getName())) || ("strKey".equals(localField.getName())) || ("strTrainStatus".equals(localField.getName())) || ("strIsUseCache".equals(localField.getName())))
            continue;
          String str3 = localField.getName();
          String str4 = (String)localObject + "\"" + str3 + "\":" + "\"" + str2 + "\"" + ",";
          localObject = str4;
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
        }
      }
      else
      {
        String str1 = ((String)localObject).substring(0, -1 + ((String)localObject).length()) + "}";
        LogUtils.e("GrowingIO 上传数据Json：", str1);
        return str1;
      }
  }

  public static void uploadGrowingIO(ArrayMap<String, String> paramArrayMap, String paramString)
  {
    Object[] arrayOfObject = new Object[4];
    arrayOfObject[0] = new Gson().toJson(paramArrayMap);
    arrayOfObject[1] = paramString;
    arrayOfObject[2] = "0";
    arrayOfObject[3] = "";
    innerUploadGrowingIO(String.valueOf(CommonUtils.invokeJsMethod("statistics.js", "statisticsGrowingIO", arrayOfObject)));
  }

  public static void uploadGrowingIO(GrowingIOVariables paramGrowingIOVariables)
  {
    try
    {
      String str1 = new Gson().toJson(BaseApplication.userModel);
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = paramToJson(paramGrowingIOVariables);
      arrayOfObject[1] = str1;
      String str2 = String.valueOf(CommonUtils.invokeJsMethod("statistics.js", "artificialGrowingIO", arrayOfObject));
      if (StringUtils.isNull(str2))
        return;
      GrowingIO localGrowingIO = GrowingIO.getInstance();
      JSONArray localJSONArray = new JSONObject(str2).optJSONArray("track");
      if ((localJSONArray != null) && (localJSONArray.length() > 0))
        for (int i = 0; i < localJSONArray.length(); i++)
        {
          JSONObject localJSONObject = (JSONObject)localJSONArray.get(i);
          localGrowingIO.track(localJSONObject.optString("eventid"), new JSONObject(localJSONObject.optString("variable")));
        }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public static void uploadGrowingIO(HashMap<String, String> paramHashMap, String paramString)
  {
    Object[] arrayOfObject = new Object[4];
    arrayOfObject[0] = new Gson().toJson(paramHashMap);
    arrayOfObject[1] = paramString;
    arrayOfObject[2] = "0";
    arrayOfObject[3] = "";
    innerUploadGrowingIO(String.valueOf(CommonUtils.invokeJsMethod("statistics.js", "statisticsGrowingIO", arrayOfObject)));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior
 * JD-Core Version:    0.6.0
 */