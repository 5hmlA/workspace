package com.sportq.fit.middlelib;

import com.sportq.fit.common.interfaces.FitInterfaceUtils.DownLoadListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPagePresenterInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.interfaces.presenter.train.TrainPresenterInterface;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.middlelib.presenter.account.LoginPresenterImpl;
import com.sportq.fit.middlelib.presenter.account.RegisterPresenterImpl;
import com.sportq.fit.middlelib.presenter.find.FindPagePresenterImpI;
import com.sportq.fit.middlelib.presenter.find.FindPresenterImpI;
import com.sportq.fit.middlelib.presenter.mine.MinePresenterImpl;
import com.sportq.fit.middlelib.presenter.train.TrainPresenterImpl;

public class MiddleManager
{
  private static MiddleManager singleton;
  private FindPagePresenterInterface findPagePresenterImpl;
  private FindPresenterInterface findPresenterImpl;
  private FitMediaPlayer fitMediaPlayer;
  private LoginPresenterInterface loginPresenterImpl;
  private MinePresenterInterface minePresenterImpl;
  private RegisterPresenterInterface registerPresenterImpl;
  private TrainPresenterInterface trainPresenterImpl;

  public static void closeInstance()
  {
    LogUtils.d("Manager", "清空MiddleManager对象");
    if (singleton != null)
    {
      singleton.findPresenterImpl = null;
      singleton.findPagePresenterImpl = null;
      singleton.loginPresenterImpl = null;
      singleton.registerPresenterImpl = null;
      singleton.minePresenterImpl = null;
      singleton.trainPresenterImpl = null;
      singleton.fitMediaPlayer = null;
      singleton = null;
    }
    DexManager.closeInstance();
  }

  public static MiddleManager getInstance()
  {
    if (singleton == null)
    {
      LogUtils.d("Manager", "创建MiddleManager对象");
      singleton = new MiddleManager();
    }
    return singleton;
  }

  public FindPagePresenterInterface getFindPagePresenterImpl()
  {
    if (this.findPagePresenterImpl != null)
      return this.findPagePresenterImpl;
    this.findPagePresenterImpl = new FindPagePresenterImpI();
    return this.findPagePresenterImpl;
  }

  public FindPresenterInterface getFindPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener, FitInterfaceUtils.DownLoadListener paramDownLoadListener)
  {
    if (this.findPresenterImpl != null)
    {
      this.findPresenterImpl.setFindPresenter(paramUIInitListener, paramDownLoadListener, null);
      return this.findPresenterImpl;
    }
    this.findPresenterImpl = new FindPresenterImpI(paramUIInitListener, paramDownLoadListener);
    return this.findPresenterImpl;
  }

  public LoginPresenterInterface getLoginPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    if (this.loginPresenterImpl != null)
    {
      this.loginPresenterImpl.setLoginPresenter(paramUIInitListener, null, null);
      return this.loginPresenterImpl;
    }
    this.loginPresenterImpl = new LoginPresenterImpl(paramUIInitListener);
    return this.loginPresenterImpl;
  }

  public MinePresenterInterface getMinePresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    if (this.minePresenterImpl != null)
    {
      this.minePresenterImpl.setMinePresenter(paramUIInitListener, null);
      return this.minePresenterImpl;
    }
    this.minePresenterImpl = new MinePresenterImpl(paramUIInitListener);
    return this.minePresenterImpl;
  }

  public RegisterPresenterInterface getRegisterPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    if (this.registerPresenterImpl != null)
    {
      this.registerPresenterImpl.setRegisterPresenter(paramUIInitListener, null, null);
      return this.registerPresenterImpl;
    }
    this.registerPresenterImpl = new RegisterPresenterImpl(paramUIInitListener);
    return this.registerPresenterImpl;
  }

  public TrainPresenterInterface getTrainPresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    if (this.trainPresenterImpl != null)
    {
      this.trainPresenterImpl.setTrainPresenter(paramUIInitListener, null);
      return this.trainPresenterImpl;
    }
    this.trainPresenterImpl = new TrainPresenterImpl(paramUIInitListener);
    return this.trainPresenterImpl;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.MiddleManager
 * JD-Core Version:    0.6.0
 */