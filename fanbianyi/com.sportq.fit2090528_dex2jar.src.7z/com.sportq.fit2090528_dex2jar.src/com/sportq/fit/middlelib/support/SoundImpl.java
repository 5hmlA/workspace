package com.sportq.fit.middlelib.support;

import com.sportq.fit.common.interfaces.sound.SoundInterface;
import com.sportq.fit.common.interfaces.video.FitMediaPlayer.OnCompletionListener;

public class SoundImpl
  implements SoundInterface
{
  public void destroy()
  {
  }

  public String getAssetUrl(String paramString)
  {
    return null;
  }

  public float getVolume()
  {
    return 0.0F;
  }

  public void initAndPlay(String paramString)
  {
  }

  public boolean isPause()
  {
    return false;
  }

  public boolean isPreview()
  {
    return false;
  }

  public boolean isShouldPlay()
  {
    return false;
  }

  public void pause()
  {
  }

  public void playCount(int paramInt)
  {
  }

  public void playDidi(int paramInt)
  {
  }

  public void playFinish()
  {
  }

  public void playGuideAudio(String paramString)
  {
  }

  public void playGuideAudio(String paramString, FitMediaPlayer.OnCompletionListener paramOnCompletionListener)
  {
  }

  public void playSound(String paramString)
  {
  }

  public void playSound(String paramString, FitMediaPlayer.OnCompletionListener paramOnCompletionListener)
  {
  }

  public void resetMediaPlayer()
  {
  }

  public void resume()
  {
  }

  public void setDataSource(String paramString)
  {
  }

  public void setIsPause(boolean paramBoolean)
  {
  }

  public void setPreview(boolean paramBoolean)
  {
  }

  public void setShouldPlay(boolean paramBoolean)
  {
  }

  public void setVolume(float paramFloat)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.support.SoundImpl
 * JD-Core Version:    0.6.0
 */