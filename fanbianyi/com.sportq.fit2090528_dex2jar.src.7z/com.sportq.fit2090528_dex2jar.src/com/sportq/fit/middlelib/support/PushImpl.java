package com.sportq.fit.middlelib.support;

import android.content.Context;
import com.sportq.fit.common.interfaces.support.PushInterface;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.supportlib.push.Push;

public class PushImpl
  implements PushInterface
{
  private PushInterface pushInterface = new Push();

  public void initOneSDK(Context paramContext)
  {
    try
    {
      this.pushInterface.initOneSDK(paramContext);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void pushAddTag(Context paramContext)
  {
    try
    {
      this.pushInterface.pushAddTag(paramContext);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      return;
    }
    catch (ExceptionInInitializerError localExceptionInInitializerError)
    {
      LogUtils.e(localExceptionInInitializerError);
    }
  }

  public void pushClearTag(Context paramContext)
  {
    try
    {
      this.pushInterface.pushClearTag(paramContext);
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.support.PushImpl
 * JD-Core Version:    0.6.0
 */