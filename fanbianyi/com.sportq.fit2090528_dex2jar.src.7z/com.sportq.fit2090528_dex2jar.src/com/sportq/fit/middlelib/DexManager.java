package com.sportq.fit.middlelib;

import android.content.Context;
import com.sportq.fit.accountpresenter.LoginPresenter;
import com.sportq.fit.accountpresenter.RegisterPresenter;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.FitDex;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPagePresenterInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.interfaces.presenter.train.TrainPresenterInterface;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.interfaces.support.DownloadInterface;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.findpresenter.FindPagePresenter;
import com.sportq.fit.findpresenter.FindPresenter1;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.minepresenter.MinePresenter1;
import com.sportq.fit.supportlib.download.FindDownload;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;
import com.sportq.fit.trainpresenter.TrainPresenter;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class DexManager
{
  private static DexManager singleton;
  private ApiInterface api;
  private Map<EnumConstant.FitDex, DexClassLoader> dexMap = null;
  private DownloadInterface findDownloadInterface;
  private FindPagePresenterInterface findPagePresenterInterface;
  private FindPresenterInterface findPresenterInterface;
  private LoginPresenterInterface loginPresenterInterface;
  private MinePresenterInterface minePresenterInterface;
  private ReformerInterface reformerInterface;
  private RegisterPresenterInterface registerPresenterInterface;
  private TrainPresenterInterface trainPresenterInterface;

  public static void closeInstance()
  {
    LogUtils.d("Manager", "清空DexManager对象");
    if (singleton != null)
    {
      singleton.registerPresenterInterface = null;
      singleton.reformerInterface = null;
      singleton.loginPresenterInterface = null;
      singleton.minePresenterInterface = null;
      singleton.api = null;
      singleton.findPresenterInterface = null;
      singleton.trainPresenterInterface = null;
      singleton.findPagePresenterInterface = null;
      singleton.findDownloadInterface = null;
      singleton = null;
    }
  }

  private DexClassLoader getFitClass(EnumConstant.FitDex paramFitDex)
  {
    try
    {
      if ((BaseApplication.dexMap.get(paramFitDex) != null) && (((Boolean)BaseApplication.dexMap.get(paramFitDex)).booleanValue()))
      {
        if (this.dexMap == null)
          this.dexMap = new HashMap();
        DexClassLoader localDexClassLoader1 = (DexClassLoader)this.dexMap.get(paramFitDex);
        if (localDexClassLoader1 != null)
          return localDexClassLoader1;
        String str = getJarName(paramFitDex);
        File localFile1 = BaseApplication.appliContext.getDir("fitDex", 0);
        File localFile2 = BaseApplication.appliContext.getDir("fitJar", 0);
        DexClassLoader localDexClassLoader2 = new DexClassLoader(localFile2.getAbsolutePath() + str, localFile1.getAbsolutePath(), null, getClass().getClassLoader());
        if (localDexClassLoader2 != null)
        {
          this.dexMap.put(paramFitDex, localDexClassLoader2);
          return localDexClassLoader2;
        }
      }
    }
    catch (Exception localException)
    {
      FitAction.upload_e("DexManager.getFitClass", localException);
    }
    return null;
  }

  public static DexManager getInstance()
  {
    if (singleton == null)
    {
      LogUtils.d("Manager", "创建DexManager对象");
      singleton = new DexManager();
    }
    return singleton;
  }

  private String getJarName(EnumConstant.FitDex paramFitDex)
  {
    switch (1.$SwitchMap$com$sportq$fit$common$constant$EnumConstant$FitDex[paramFitDex.ordinal()])
    {
    default:
      return "";
    case 1:
      return "/findpresenter.jar";
    case 2:
      return "/minepresenter.jar";
    case 3:
      return "/accountpresenter.jar";
    case 4:
      return "/trainpresenter.jar";
    case 5:
      return "/videopresenter.jar";
    case 6:
    }
    return "/supportlib.jar";
  }

  private void getLocalClass(ClassName paramClassName)
  {
    switch (1.$SwitchMap$com$sportq$fit$middlelib$DexManager$ClassName[paramClassName.ordinal()])
    {
    default:
      return;
    case 1:
      this.findPresenterInterface = new FindPresenter1();
      return;
    case 2:
      this.findPagePresenterInterface = new FindPagePresenter();
      return;
    case 3:
      this.api = new ApiImpl();
      return;
    case 4:
      this.reformerInterface = new ReformerImpl();
      return;
    case 5:
      this.findDownloadInterface = new FindDownload();
      return;
    case 6:
      this.trainPresenterInterface = new TrainPresenter();
      return;
    case 7:
      this.minePresenterInterface = new MinePresenter1();
      return;
    case 8:
      this.loginPresenterInterface = new LoginPresenter();
      return;
    case 9:
    }
    this.registerPresenterInterface = new RegisterPresenter();
  }

  public ApiInterface getApi()
  {
    if (this.api != null)
      return this.api;
    DexClassLoader localDexClassLoader = getFitClass(EnumConstant.FitDex.Support);
    if (localDexClassLoader != null);
    while (true)
    {
      try
      {
        this.api = ((ApiInterface)localDexClassLoader.loadClass("com.sportq.fit.supportlibdex.http.ApiImpl").newInstance());
        LogUtils.d("Manager", "反射取得ApiInterface对象");
        return this.api;
      }
      catch (Exception localException)
      {
        FitAction.upload_e("DexManager.getApi", localException);
        getLocalClass(ClassName.Api);
        continue;
      }
      getLocalClass(ClassName.Api);
    }
  }

  public DownloadInterface getFindDownloadInterface()
  {
    if (this.findDownloadInterface != null)
      return this.findDownloadInterface;
    DexClassLoader localDexClassLoader = getFitClass(EnumConstant.FitDex.Support);
    if (localDexClassLoader != null);
    while (true)
    {
      try
      {
        this.findDownloadInterface = ((DownloadInterface)localDexClassLoader.loadClass("com.sportq.fit.supportlibdex.download.FindDownload").newInstance());
        LogUtils.d("Manager", "反射取得DownloadInterface对象");
        return this.findDownloadInterface;
      }
      catch (Exception localException)
      {
        FitAction.upload_e("DexManager.getFindDownloadInterface", localException);
        getLocalClass(ClassName.FindDownload);
        continue;
      }
      getLocalClass(ClassName.FindDownload);
    }
  }

  public FindPagePresenterInterface getFindPagePresenterInterface()
  {
    if (this.findPagePresenterInterface != null)
      return this.findPagePresenterInterface;
    DexClassLoader localDexClassLoader = getFitClass(EnumConstant.FitDex.Find);
    if (localDexClassLoader != null);
    while (true)
    {
      try
      {
        this.findPagePresenterInterface = ((FindPagePresenterInterface)localDexClassLoader.loadClass("com.sportq.fit.findpresenterdex.FindPagePresenter").newInstance());
        LogUtils.d("Manager", "反射取得FindPagePresenterInterface对象");
        return this.findPagePresenterInterface;
      }
      catch (Exception localException)
      {
        FitAction.upload_e("DexManager.getFindPagePresenterInterface", localException);
        getLocalClass(ClassName.FindPagePresenter);
        continue;
      }
      getLocalClass(ClassName.FindPagePresenter);
    }
  }

  public FindPresenterInterface getFindPresenterInterface()
  {
    if (this.findPresenterInterface != null)
      return this.findPresenterInterface;
    DexClassLoader localDexClassLoader = getFitClass(EnumConstant.FitDex.Find);
    if (localDexClassLoader != null);
    while (true)
    {
      try
      {
        this.findPresenterInterface = ((FindPresenterInterface)localDexClassLoader.loadClass("com.sportq.fit.findpresenterdex.FindPresenter1").newInstance());
        LogUtils.d("Manager", "反射取得FindPresenter对象");
        return this.findPresenterInterface;
      }
      catch (Exception localException)
      {
        FitAction.upload_e("DexManager.getFindPresenterInterface", localException);
        getLocalClass(ClassName.FindPresenter);
        continue;
      }
      getLocalClass(ClassName.FindPresenter);
    }
  }

  public LoginPresenterInterface getLoginPresenterInterface()
  {
    if (this.loginPresenterInterface != null)
      return this.loginPresenterInterface;
    DexClassLoader localDexClassLoader = getFitClass(EnumConstant.FitDex.Account);
    if (localDexClassLoader != null);
    while (true)
    {
      try
      {
        this.loginPresenterInterface = ((LoginPresenterInterface)localDexClassLoader.loadClass("com.sportq.fit.accountpresenterdex.LoginPresenter").newInstance());
        LogUtils.d("Manager", "反射取得LoginPresenterInterface对象");
        return this.loginPresenterInterface;
      }
      catch (Exception localException)
      {
        FitAction.upload_e("DexManager.getLoginPresenterInterface", localException);
        getLocalClass(ClassName.LoginPresenter);
        continue;
      }
      getLocalClass(ClassName.LoginPresenter);
    }
  }

  public MinePresenterInterface getMinePresenterInterface()
  {
    if (this.minePresenterInterface != null)
      return this.minePresenterInterface;
    DexClassLoader localDexClassLoader = getFitClass(EnumConstant.FitDex.Mine);
    if (localDexClassLoader != null);
    while (true)
    {
      try
      {
        this.minePresenterInterface = ((MinePresenterInterface)localDexClassLoader.loadClass("com.sportq.fit.minepresenterdex.MinePresenter1").newInstance());
        LogUtils.d("Manager", "反射取得MinePresenterInterface对象");
        return this.minePresenterInterface;
      }
      catch (Exception localException)
      {
        FitAction.upload_e("DexManager.getMinePresenterInterface", localException);
        getLocalClass(ClassName.MinePresenter);
        continue;
      }
      getLocalClass(ClassName.MinePresenter);
    }
  }

  public ReformerInterface getReformerInterface()
  {
    if (this.reformerInterface != null)
      return this.reformerInterface;
    DexClassLoader localDexClassLoader = getFitClass(EnumConstant.FitDex.Support);
    if (localDexClassLoader != null);
    while (true)
    {
      try
      {
        this.reformerInterface = ((ReformerInterface)localDexClassLoader.loadClass("com.sportq.fit.supportlibdex.http.reformer.ReformerImpl").newInstance());
        LogUtils.d("Manager", "反射取得ReformerInterface对象");
        return this.reformerInterface;
      }
      catch (Exception localException)
      {
        FitAction.upload_e("DexManager.getReformerInterface", localException);
        getLocalClass(ClassName.Reformer);
        continue;
      }
      getLocalClass(ClassName.Reformer);
    }
  }

  public RegisterPresenterInterface getRegisterPresenterInterface()
  {
    if (this.registerPresenterInterface != null)
      return this.registerPresenterInterface;
    DexClassLoader localDexClassLoader = getFitClass(EnumConstant.FitDex.Account);
    if (localDexClassLoader != null);
    while (true)
    {
      try
      {
        this.registerPresenterInterface = ((RegisterPresenterInterface)localDexClassLoader.loadClass("com.sportq.fit.accountpresenterdex.RegisterPresenter").newInstance());
        LogUtils.d("Manager", "反射取得RegisterPresenterInterface对象");
        return this.registerPresenterInterface;
      }
      catch (Exception localException)
      {
        FitAction.upload_e("DexManager.getRegisterPresenterInterface", localException);
        getLocalClass(ClassName.RegisterPresenter);
        continue;
      }
      getLocalClass(ClassName.RegisterPresenter);
    }
  }

  public TrainPresenterInterface getTrainPresenterInterface()
  {
    if (this.trainPresenterInterface != null)
      return this.trainPresenterInterface;
    DexClassLoader localDexClassLoader = getFitClass(EnumConstant.FitDex.Train);
    if (localDexClassLoader != null);
    while (true)
    {
      try
      {
        this.trainPresenterInterface = ((TrainPresenterInterface)localDexClassLoader.loadClass("com.sportq.fit.trainpresenterdex.TrainPresenter").newInstance());
        LogUtils.d("Manager", "反射取得TrainPresenterInterface对象");
        return this.trainPresenterInterface;
      }
      catch (Exception localException)
      {
        FitAction.upload_e("DexManager.getTrainPresenterInterface", localException);
        getLocalClass(ClassName.TrainPresenter);
        continue;
      }
      getLocalClass(ClassName.TrainPresenter);
    }
  }

  private static enum ClassName
  {
    static
    {
      FindPagePresenter = new ClassName("FindPagePresenter", 1);
      Api = new ClassName("Api", 2);
      Reformer = new ClassName("Reformer", 3);
      FindDownload = new ClassName("FindDownload", 4);
      TrainPresenter = new ClassName("TrainPresenter", 5);
      MinePresenter = new ClassName("MinePresenter", 6);
      LoginPresenter = new ClassName("LoginPresenter", 7);
      RegisterPresenter = new ClassName("RegisterPresenter", 8);
      FitMediaPlayer = new ClassName("FitMediaPlayer", 9);
      ClassName[] arrayOfClassName = new ClassName[10];
      arrayOfClassName[0] = FindPresenter;
      arrayOfClassName[1] = FindPagePresenter;
      arrayOfClassName[2] = Api;
      arrayOfClassName[3] = Reformer;
      arrayOfClassName[4] = FindDownload;
      arrayOfClassName[5] = TrainPresenter;
      arrayOfClassName[6] = MinePresenter;
      arrayOfClassName[7] = LoginPresenter;
      arrayOfClassName[8] = RegisterPresenter;
      arrayOfClassName[9] = FitMediaPlayer;
      $VALUES = arrayOfClassName;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.DexManager
 * JD-Core Version:    0.6.0
 */