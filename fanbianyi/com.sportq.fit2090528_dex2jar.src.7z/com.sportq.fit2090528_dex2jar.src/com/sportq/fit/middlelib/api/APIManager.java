package com.sportq.fit.middlelib.api;

import android.content.Context;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.supportlib.http.request.FitRxRequest;
import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;

public class APIManager
{
  public static Observable<ResponseModel> checkVersion(Context paramContext)
  {
    RequestModel localRequestModel = new RequestModel();
    if (CompDeviceInfoUtils.isNotificationEnabled(paramContext));
    for (String str = "0"; ; str = "1")
    {
      localRequestModel.flag = str;
      return FitRxRequest.createJsonRequest(1, "/SFitWeb/sfit/checkVersion", localRequestModel, paramContext);
    }
  }

  public static Observable<ResponseModel> uploadErrInfo(String paramString1, String paramString2, String paramString3)
  {
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber<? super ResponseModel> paramSubscriber)
      {
      }
    });
  }

  public static Observable<ResponseModel> uploadStatistics(String paramString1, String paramString2, String paramString3)
  {
    return Observable.create(new Observable.OnSubscribe()
    {
      public void call(Subscriber<? super ResponseModel> paramSubscriber)
      {
      }
    });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.middlelib.api.APIManager
 * JD-Core Version:    0.6.0
 */