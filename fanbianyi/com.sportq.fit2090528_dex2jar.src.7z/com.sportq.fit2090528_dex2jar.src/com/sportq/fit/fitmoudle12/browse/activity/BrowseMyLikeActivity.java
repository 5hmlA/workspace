package com.sportq.fit.fitmoudle12.browse.activity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.event.ActionLikeEvent;
import com.sportq.fit.common.event.UnLockActionEvent;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.event.VipServiceEvent;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle12.R.color;
import com.sportq.fit.fitmoudle12.R.id;
import com.sportq.fit.fitmoudle12.R.layout;
import com.sportq.fit.fitmoudle12.R.mipmap;
import com.sportq.fit.fitmoudle12.R.string;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseEventEntity;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseMyLikeTitle;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseMyLikeViewPager;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseMyLikeViewPager.OnLineScrollListener;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseMyLikeViewPager.OnTabColorChangeListener;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class BrowseMyLikeActivity extends BaseActivity
  implements BrowseMyLikeViewPager.OnLineScrollListener, BrowseMyLikeViewPager.OnTabColorChangeListener
{
  private BrowseMyLikeTitle second_title;
  private BrowseMyLikeViewPager viewpager;

  private void initElement()
  {
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    if (localCustomToolBar != null)
    {
      localCustomToolBar.setAppTitle(R.string.c_107_1);
      localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
      localCustomToolBar.setToolbarBg(R.color.white);
      localCustomToolBar.setToolbarTitleColor(R.color.black);
      setSupportActionBar(localCustomToolBar);
    }
    this.viewpager = ((BrowseMyLikeViewPager)findViewById(R.id.viewpager));
    if (this.viewpager != null)
      this.viewpager.initElements(this, this, this);
    this.second_title = ((BrowseMyLikeTitle)findViewById(R.id.second_title));
    if (this.second_title != null)
      this.second_title.initElements(this);
  }

  public void checkDataForPage(int paramInt)
  {
    if (this.viewpager == null)
      return;
    if (paramInt != -1)
    {
      this.viewpager.setCurrentItem(paramInt);
      return;
    }
    this.viewpager.checkCurIndexData(this.viewpager.getCurrentItem());
  }

  public void fitOnClick(View paramView)
  {
    if (R.id.video_tv == paramView.getId())
      checkDataForPage(0);
    do
    {
      return;
      if (R.id.article_tv != paramView.getId())
        continue;
      checkDataForPage(1);
      return;
    }
    while (R.id.action_tv != paramView.getId());
    checkDataForPage(2);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.browse_my_like);
    EventBus.getDefault().register(this);
    initElement();
    checkDataForPage(-1);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(ActionLikeEvent paramActionLikeEvent)
  {
    if (this.viewpager != null)
      this.viewpager.refreshMyLikeAction(paramActionLikeEvent);
  }

  @Subscribe
  public void onEventMainThread(UnLockActionEvent paramUnLockActionEvent)
  {
    if (this.viewpager != null)
      this.viewpager.refreshEnergyAction(paramUnLockActionEvent);
  }

  @Subscribe
  public void onEventMainThread(VipServiceEvent paramVipServiceEvent)
  {
    if ((this.viewpager != null) && (paramVipServiceEvent != null))
      this.viewpager.openVipSuccess();
  }

  @Subscribe
  public void onEventMainThread(BrowseEventEntity paramBrowseEventEntity)
  {
    if (paramBrowseEventEntity == null);
    do
      return;
    while (this.viewpager == null);
    this.viewpager.refreshLikeNumOrCancelLike(paramBrowseEventEntity);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  public void onLineScroll(int paramInt, float paramFloat)
  {
    if (this.second_title == null)
      return;
    this.second_title.setLineScroll(paramInt, paramFloat);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  public void onTabColorChange(int paramInt)
  {
    if (this.second_title == null)
      return;
    this.second_title.setTabSelColor(paramInt, this);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle12.browse.activity.BrowseMyLikeActivity
 * JD-Core Version:    0.6.0
 */