package com.sportq.fit.fitmoudle12.browse.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.percent.PercentRelativeLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.browsepresenter.BrowsePresenter;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.CommentEvent;
import com.sportq.fit.common.event.LikeEvent;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.browse.BrowseInterface;
import com.sportq.fit.common.model.BrowseEntity;
import com.sportq.fit.common.model.NewHotCommentModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.stickrecycleradapter.StickyRecyclerHeadersDecoration;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.ChatEditText;
import com.sportq.fit.fitmoudle.widget.ContentCommentView.CommentClickListener;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.custom.refresh.OnRefreshListener;
import com.sportq.fit.fitmoudle.widget.custom.refresh.SwipeToLoadLayout;
import com.sportq.fit.fitmoudle12.R.color;
import com.sportq.fit.fitmoudle12.R.id;
import com.sportq.fit.fitmoudle12.R.layout;
import com.sportq.fit.fitmoudle12.R.mipmap;
import com.sportq.fit.fitmoudle12.R.string;
import com.sportq.fit.fitmoudle12.browse.adapter.ContentCommentAdapter;
import com.sportq.fit.fitmoudle12.browse.event.AllDialogueEvent;
import com.sportq.fit.fitmoudle12.browse.presenter.PresenterImpl;
import com.sportq.fit.fitmoudle12.browse.reformer.reformer.AddCommentReformer;
import com.sportq.fit.fitmoudle12.browse.reformer.reformer.CommentReformer;
import com.sportq.fit.fitmoudle12.browse.reformer.reformer.DeleteCommentReformer;
import com.sportq.fit.fitmoudle12.browse.reformer.reformer.FreezeUserReformer;
import com.sportq.fit.fitmoudle12.browse.reformer.reformer.ReportReformer;
import com.sportq.fit.fitmoudle12.browse.widget.CommentDialog;
import com.sportq.fit.fitmoudle12.browse.widget.CommentInputCustomView;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseEventEntity;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class ContentCommentActivity extends BaseActivity
  implements ContentCommentView.CommentClickListener, OnRefreshListener
{
  private ContentCommentAdapter adapter;
  ArrayList<NewHotCommentModel> allList = new ArrayList();
  int bHeight = 0;
  String clickFlg;
  private String commentId;
  private int commentNum;
  CommentReformer commentReformer;
  private CommentInputCustomView comment_input_view;
  int deletePos;
  private String fromFlg;
  ArrayList<NewHotCommentModel> hotList = new ArrayList();
  private boolean isNeedRefreshTrainDet = false;
  private boolean isNeedShowEdit = false;
  NewHotCommentModel itemModel;
  ArrayList<NewHotCommentModel> newList = new ArrayList();
  private PercentRelativeLayout no_comment_view;
  private PresenterImpl presenter;
  private RecyclerView recyclerView;
  private SwipeToLoadLayout swipeToLoadLayout;
  CustomToolBar toolbar;
  private String tpcId;
  private String tpcType;

  private void addHeaderView(CommentReformer paramCommentReformer)
  {
    if ((com.sportq.fit.common.utils.StringUtils.isNull(this.fromFlg)) || (this.adapter.hasHeaderView()))
      return;
    BrowseEntity localBrowseEntity = new BrowseEntity();
    localBrowseEntity.tpcId = paramCommentReformer.tpcId;
    localBrowseEntity.imageUrl = paramCommentReformer.imageUrl;
    localBrowseEntity.tpcTitle = paramCommentReformer.tpcTitle;
    localBrowseEntity.tpcUrl = paramCommentReformer.tpcUrl;
    localBrowseEntity.likeNum = paramCommentReformer.likeNum;
    localBrowseEntity.commentNumber = paramCommentReformer.commentNumber;
    localBrowseEntity.shareNumber = paramCommentReformer.shareNumber;
    localBrowseEntity.isLike = paramCommentReformer.isLike;
    localBrowseEntity.lastDate = paramCommentReformer.lastDate;
    localBrowseEntity.categoryName = paramCommentReformer.categoryName;
    localBrowseEntity.duration = paramCommentReformer.duration;
    localBrowseEntity.videoURL = paramCommentReformer.videoUrl;
    localBrowseEntity.olapInfo = paramCommentReformer.olapInfo;
    if ("0".equals(this.tpcType))
    {
      View localView3 = View.inflate(this, R.layout.article_detail_header, null);
      ImageView localImageView3 = (ImageView)localView3.findViewById(R.id.article_iv);
      TextView localTextView5 = (TextView)localView3.findViewById(R.id.article_title);
      TextView localTextView6 = (TextView)localView3.findViewById(R.id.article_time);
      TextView localTextView7 = (TextView)localView3.findViewById(R.id.article_laud);
      int i = (int)(0.422D * BaseApplication.screenWidth);
      localImageView3.getLayoutParams().width = (int)(0.422D * BaseApplication.screenWidth);
      localImageView3.getLayoutParams().height = (int)(0.765D * i);
      GlideUtils.loadImgByDefault(paramCommentReformer.imageUrl, R.mipmap.img_default, localImageView3);
      localTextView5.setText(paramCommentReformer.tpcTitle);
      localTextView6.setText(DateUtils.convertCommentDate(paramCommentReformer.lastDate));
      localTextView7.setText(paramCommentReformer.likeNum);
      ContentCommentActivity.12 local12 = new ContentCommentActivity.12(this, localBrowseEntity);
      localView3.setOnClickListener(local12);
      this.adapter.addHeaderView(localView3);
      return;
    }
    if ("1".equals(this.tpcType))
    {
      View localView2 = View.inflate(this, R.layout.video_detail_header, null);
      ImageView localImageView2 = (ImageView)localView2.findViewById(R.id.video_iv);
      TextView localTextView3 = (TextView)localView2.findViewById(R.id.video_name);
      TextView localTextView4 = (TextView)localView2.findViewById(R.id.video_desc);
      localImageView2.getLayoutParams().width = BaseApplication.screenWidth;
      localImageView2.getLayoutParams().height = (BaseApplication.screenWidth / 2);
      GlideUtils.loadImgByDefault(paramCommentReformer.imageUrl, R.mipmap.img_default, localImageView2);
      String str;
      if (com.sportq.fit.common.utils.StringUtils.isNull(paramCommentReformer.tpcTitle))
      {
        localTextView3.setVisibility(4);
        str = "#" + paramCommentReformer.categoryName + "  •  " + com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.convertTimeByVideo(paramCommentReformer.duration);
        if (!com.sportq.fit.common.utils.StringUtils.isNull(str))
          break label538;
        localTextView4.setVisibility(4);
      }
      while (true)
      {
        ContentCommentActivity.13 local13 = new ContentCommentActivity.13(this, null, localBrowseEntity, paramCommentReformer);
        localView2.setOnClickListener(local13);
        this.adapter.addHeaderView(localView2);
        return;
        localTextView3.setVisibility(0);
        localTextView3.setText(paramCommentReformer.tpcTitle);
        break;
        label538: localTextView4.setVisibility(0);
        localTextView4.setText(str);
      }
    }
    View localView1 = View.inflate(this, R.layout.course_detail_header, null);
    ImageView localImageView1 = (ImageView)localView1.findViewById(R.id.course_img);
    TextView localTextView1 = (TextView)localView1.findViewById(R.id.course_name);
    TextView localTextView2 = (TextView)localView1.findViewById(R.id.course_info);
    GlideUtils.loadImgByDefault(paramCommentReformer.imageUrl, R.mipmap.img_fit_logo, localImageView1);
    localTextView1.setText(paramCommentReformer.tpcTitle);
    localTextView2.setText(convertInfo(paramCommentReformer));
    ContentCommentActivity.14 local14 = new ContentCommentActivity.14(this, paramCommentReformer);
    localView1.setOnClickListener(local14);
    this.adapter.addHeaderView(localView1);
  }

  private void closeDialog()
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
  }

  private SpannableString convertInfo(CommentReformer paramCommentReformer)
  {
    String str = paramCommentReformer.trainDuration + "分钟" + " • " + paramCommentReformer.calorie + "千卡" + " • " + com.sportq.fit.common.utils.StringUtils.difficultyLevel(paramCommentReformer.difficultyLevel);
    SpannableString localSpannableString = new SpannableString(str);
    for (int i = 0; i < str.length(); i++)
    {
      if (!"•".equals(String.valueOf(str.charAt(i))))
        continue;
      localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(this, R.color.color_c8c8c8)), i, i + 1, 33);
    }
    int j = str.indexOf("钟");
    if (j > 0)
      localSpannableString.setSpan(new StyleSpan(1), 0, j + 1, 33);
    return localSpannableString;
  }

  private void deleteCommentRefresh(String paramString)
  {
    ArrayList localArrayList1 = new ArrayList(this.hotList);
    int i = 0;
    if (i < localArrayList1.size())
    {
      NewHotCommentModel localNewHotCommentModel2 = (NewHotCommentModel)localArrayList1.get(i);
      if (paramString.equals(localNewHotCommentModel2.commentId))
      {
        this.hotList.remove(i);
        if (this.commentNum > 0)
        {
          this.commentNum = (-1 + this.commentNum);
          EventBus.getDefault().post(new CommentEvent(this.commentNum));
        }
      }
      while (true)
      {
        i++;
        break;
        if (!paramString.equals(localNewHotCommentModel2.fatherCommentId))
          continue;
        ((NewHotCommentModel)this.hotList.get(i)).fatherComment = (localNewHotCommentModel2.fatherUserName + " : 原评论已删除。");
        ((NewHotCommentModel)this.hotList.get(i)).fatherPopType = "0";
      }
    }
    ArrayList localArrayList2 = new ArrayList(this.newList);
    int j = 0;
    if (j < localArrayList2.size())
    {
      NewHotCommentModel localNewHotCommentModel1 = (NewHotCommentModel)localArrayList2.get(j);
      if (paramString.equals(localNewHotCommentModel1.commentId))
      {
        this.newList.remove(j);
        if (this.commentNum > 0)
        {
          this.commentNum = (-1 + this.commentNum);
          EventBus.getDefault().post(new CommentEvent(this.commentNum));
        }
      }
      while (true)
      {
        j++;
        break;
        if (!paramString.equals(localNewHotCommentModel1.fatherCommentId))
          continue;
        ((NewHotCommentModel)this.newList.get(j)).fatherComment = (localNewHotCommentModel1.fatherUserName + " : 原评论已删除。");
        ((NewHotCommentModel)this.newList.get(j)).fatherPopType = "0";
      }
    }
    this.allList.clear();
    this.allList.addAll(this.hotList);
    this.allList.addAll(this.newList);
    this.adapter.replaceAll(this.allList);
    if (this.allList.size() < 1)
    {
      this.no_comment_view.setVisibility(0);
      this.recyclerView.setVisibility(8);
      return;
    }
    this.commentId = ((NewHotCommentModel)this.allList.get(-1 + this.allList.size())).commentId;
  }

  private void init()
  {
    int j;
    label198: String str2;
    label311: CommentInputCustomView localCommentInputCustomView;
    if (getIntent() != null)
    {
      this.tpcId = getIntent().getStringExtra("tpc.id");
      this.tpcType = getIntent().getStringExtra("tpc.type");
      this.fromFlg = getIntent().getStringExtra("from.type");
      this.isNeedShowEdit = getIntent().getBooleanExtra("show.edit", false);
      if (com.sportq.fit.common.utils.StringUtils.isNull(getIntent().getStringExtra("comment.num")))
      {
        j = -1;
        this.commentNum = j;
      }
    }
    else
    {
      this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
      this.recyclerView = ((RecyclerView)findViewById(R.id.swipe_target));
      this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
      this.comment_input_view = ((CommentInputCustomView)findViewById(R.id.comment_input_view));
      this.no_comment_view = ((PercentRelativeLayout)findViewById(R.id.no_comment_view));
      this.swipeToLoadLayout = ((SwipeToLoadLayout)findViewById(R.id.swipeToLoadLayout));
      if (com.sportq.fit.common.utils.StringUtils.isNull(this.fromFlg))
        break label425;
      this.toolbar.setTitle(getString(R.string.c_116_1));
      setSupportActionBar(this.toolbar);
      this.toolbar.setNavIcon(R.mipmap.btn_back_black);
      this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
      this.toolbar.setBackgroundResource(R.color.white);
      setSupportActionBar(this.toolbar);
      this.swipeToLoadLayout.setOnTouchListener(new ContentCommentActivity.1(this));
      this.recyclerView.setOnTouchListener(new ContentCommentActivity.2(this));
      this.swipeToLoadLayout.setOnRefreshListener(this);
      if ((!"2".equals(this.tpcType)) || (this.commentNum != 0))
        break label536;
      str2 = "1";
      if (this.comment_input_view != null)
      {
        this.comment_input_view.setVisibility(0);
        if ("2".equals(this.tpcType))
          this.comment_input_view.setHintContent("评论一下你对这节课的感受~");
        localCommentInputCustomView = this.comment_input_view;
        if (!this.isNeedShowEdit)
          break label543;
      }
    }
    label536: label543: for (String str3 = "1"; ; str3 = "0")
    {
      localCommentInputCustomView.initInPutView(this, str3, "");
      if (!"1".equals(str2))
        break label550;
      this.recyclerView.setVisibility(8);
      this.no_comment_view.setVisibility(0);
      return;
      j = com.sportq.fit.common.utils.StringUtils.string2Int(getIntent().getStringExtra("comment.num"));
      break;
      label425: if ("2".equals(this.tpcType))
      {
        CustomToolBar localCustomToolBar2 = this.toolbar;
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(this.commentNum);
        localCustomToolBar2.setTitle(String.format("%s条课程评论", arrayOfObject));
        break label198;
      }
      CustomToolBar localCustomToolBar1 = this.toolbar;
      if (this.commentNum < 0);
      int i;
      String[] arrayOfString;
      for (String str1 = getString(R.string.c_110_1); ; str1 = UseStringUtils.getStr(i, arrayOfString))
      {
        localCustomToolBar1.setTitle(str1);
        break;
        i = R.string.h_23_1;
        arrayOfString = new String[1];
        arrayOfString[0] = String.valueOf(this.commentNum);
      }
      str2 = "0";
      break label311;
    }
    label550: this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.tpcId = this.tpcId;
    localRequestModel.tpcType = this.tpcType;
    localRequestModel.commentId = "";
    this.presenter.getCommentList(localRequestModel, this);
  }

  private void makeLocalData()
  {
    try
    {
      NewHotCommentModel localNewHotCommentModel = new NewHotCommentModel();
      localNewHotCommentModel.commentId = "";
      localNewHotCommentModel.userId = BaseApplication.userModel.userId;
      localNewHotCommentModel.userName = BaseApplication.userModel.userName;
      localNewHotCommentModel.userImg = BaseApplication.userModel.userImg;
      localNewHotCommentModel.lastDate = String.valueOf(System.currentTimeMillis());
      localNewHotCommentModel.comment = this.comment_input_view.getComment();
      String str1;
      String str2;
      label146: String str3;
      label173: String str4;
      if ((("0".equals(this.clickFlg)) || ("1".equals(this.clickFlg))) && (this.itemModel != null))
      {
        if ("0".equals(this.clickFlg))
        {
          str1 = this.itemModel.commentId;
          localNewHotCommentModel.fatherCommentId = str1;
          if (!"0".equals(this.clickFlg))
            break label506;
          str2 = this.itemModel.userId;
          localNewHotCommentModel.fatherUserId = str2;
          if (!"0".equals(this.clickFlg))
            break label518;
          str3 = this.itemModel.userName;
          localNewHotCommentModel.fatherUserName = str3;
          if (!"0".equals(this.clickFlg))
            break label530;
          str4 = this.itemModel.userName + " : " + this.itemModel.comment;
          label229: localNewHotCommentModel.fatherComment = str4;
        }
      }
      else
      {
        localNewHotCommentModel.dialogueId = "";
        localNewHotCommentModel.likeNum = "0";
        localNewHotCommentModel.isLike = "0";
        localNewHotCommentModel.popType = "4";
        localNewHotCommentModel.headIndex = 1;
        this.newList.add(0, localNewHotCommentModel);
        this.allList.clear();
        this.allList.addAll(this.hotList);
        this.allList.addAll(this.newList);
        this.commentId = ((NewHotCommentModel)this.allList.get(-1 + this.allList.size())).commentId;
        this.no_comment_view.setVisibility(8);
        this.recyclerView.setVisibility(0);
        if (this.adapter != null)
          break label542;
        this.adapter = new ContentCommentAdapter(this, this, this.allList, R.layout.comment_item_view);
        this.adapter.setOnLoadMoreListener(new ContentCommentActivity.9(this));
        this.recyclerView.setAdapter(this.adapter);
        this.recyclerView.addItemDecoration(new StickyRecyclerHeadersDecoration(this.adapter));
      }
      while (true)
      {
        this.recyclerView.post(new ContentCommentActivity.10(this));
        if (this.commentNum >= 0)
        {
          this.commentNum = (1 + this.commentNum);
          EventBus.getDefault().post(new CommentEvent(this.commentNum));
        }
        new Handler().postDelayed(new ContentCommentActivity.11(this, localNewHotCommentModel), 400L);
        return;
        str1 = this.itemModel.fatherCommentId;
        break;
        label506: str2 = this.itemModel.fatherUserId;
        break label146;
        label518: str3 = this.itemModel.fatherUserName;
        break label173;
        label530: str4 = this.itemModel.fatherComment;
        break label229;
        label542: this.adapter.replaceAll(this.allList);
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void moveItemToPosition(int paramInt)
  {
    int[] arrayOfInt = new int[2];
    this.comment_input_view.getLocationOnScreen(arrayOfInt);
    int i = paramInt - arrayOfInt[1];
    this.recyclerView.smoothScrollBy(0, i, new LinearInterpolator());
  }

  private void reSwipeToLoadLayoutState()
  {
    if (this.swipeToLoadLayout.isRefreshing())
      this.swipeToLoadLayout.setRefreshing(false);
  }

  public void fitOnClick(View paramView)
  {
    String str1;
    RequestModel localRequestModel;
    String str2;
    if (paramView.getId() == R.id.comment_send_btn)
    {
      if ("1".equals(BaseApplication.userModel.badFlag))
        ToastUtils.makeToast(this, getString(R.string.h_32_2));
      do
      {
        do
        {
          return;
          if (CompDeviceInfoUtils.checkNetwork())
            continue;
          ToastUtils.makeToast(this, getString(R.string.g_20_1));
          return;
        }
        while (this.comment_input_view == null);
        str1 = this.comment_input_view.getComment();
      }
      while (com.sportq.fit.common.utils.StringUtils.isNull(str1));
      this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
      if (this.comment_input_view.getComment_edit_text().getTag() == null)
        this.itemModel = null;
      localRequestModel = new RequestModel();
      localRequestModel.tpcId = this.tpcId;
      localRequestModel.tpcType = this.tpcType;
      if ((("0".equals(this.clickFlg)) || ("1".equals(this.clickFlg))) && (this.itemModel != null))
      {
        if (!"0".equals(this.clickFlg))
          break label299;
        str2 = this.itemModel.commentId;
        localRequestModel.fatherCommentId = str2;
        if (!"0".equals(this.clickFlg))
          break label311;
      }
    }
    label299: label311: for (String str3 = this.itemModel.userId; ; str3 = this.itemModel.fatherUserId)
    {
      localRequestModel.fatherUserId = str3;
      if (this.itemModel != null)
        localRequestModel.dialogueId = this.itemModel.dialogueId;
      localRequestModel.comment = str1;
      localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + str1 + NdkUtils.getSignBaseUrl()).toUpperCase();
      this.presenter.addComment(localRequestModel, this);
      super.fitOnClick(paramView);
      return;
      str2 = this.itemModel.fatherCommentId;
      break;
    }
  }

  public <T> void getDataFail(T paramT)
  {
    reSwipeToLoadLayoutState();
    closeDialog();
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    closeDialog();
    if ((paramT instanceof CommentReformer))
    {
      reSwipeToLoadLayoutState();
      this.commentReformer = ((CommentReformer)paramT);
      this.allList.clear();
      if (this.recyclerView.getTag() == null)
      {
        this.hotList.clear();
        this.newList.clear();
        if ((this.commentReformer.lstHotComment != null) && (this.commentReformer.lstHotComment.size() > 0))
          this.hotList = this.commentReformer.lstHotComment;
        if ((this.commentReformer.lstNewComment != null) && (this.commentReformer.lstNewComment.size() > 0))
          this.newList = this.commentReformer.lstNewComment;
        this.allList.addAll(this.hotList);
        this.allList.addAll(this.newList);
        if (this.allList.size() != 0)
          break label266;
        this.recyclerView.setVisibility(8);
        this.no_comment_view.setVisibility(0);
        this.recyclerView.setTag(null);
      }
    }
    while (true)
    {
      super.getDataSuccess(paramT);
      return;
      if ((this.commentReformer.lstHotComment != null) && (this.commentReformer.lstHotComment.size() > 0))
        this.hotList.addAll(this.commentReformer.lstHotComment);
      if ((this.commentReformer.lstNewComment == null) || (this.commentReformer.lstNewComment.size() <= 0))
        break;
      this.newList.addAll(this.commentReformer.lstNewComment);
      break;
      label266: this.recyclerView.setVisibility(0);
      this.no_comment_view.setVisibility(8);
      if (this.adapter == null)
      {
        this.adapter = new ContentCommentAdapter(this, this, this.allList, R.layout.comment_item_view);
        this.adapter.setOnLoadMoreListener(new ContentCommentActivity.3(this));
        addHeaderView(this.commentReformer);
        this.recyclerView.setAdapter(this.adapter);
        this.recyclerView.addItemDecoration(new StickyRecyclerHeadersDecoration(this.adapter));
      }
      while (true)
      {
        this.recyclerView.post(new ContentCommentActivity.4(this));
        this.commentId = ((NewHotCommentModel)this.allList.get(-1 + this.allList.size())).commentId;
        break;
        this.adapter.replaceAll(this.allList);
      }
      if ((paramT instanceof AddCommentReformer))
      {
        AddCommentReformer localAddCommentReformer = (AddCommentReformer)paramT;
        if ("Y".equals(localAddCommentReformer.result))
        {
          this.isNeedRefreshTrainDet = true;
          ToastUtils.makeToast(this, getString(R.string.h_32_1));
          makeLocalData();
          this.clickFlg = "";
          this.itemModel = null;
          this.comment_input_view.clearMessage("0");
          new Handler().postDelayed(new ContentCommentActivity.5(this), 300L);
          continue;
        }
        if (com.sportq.fit.common.utils.StringUtils.isNull(localAddCommentReformer.message))
          continue;
        if ("h_32_2".equals(localAddCommentReformer.message))
        {
          ToastUtils.makeToast(this, getString(R.string.h_32_2));
          continue;
        }
        if ("h_32_3".equals(localAddCommentReformer.message))
        {
          ToastUtils.makeToast(this, getString(R.string.h_32_3));
          continue;
        }
        if ("h_32_4".equals(localAddCommentReformer.message))
        {
          ToastUtils.makeToast(this, getString(R.string.h_32_4));
          continue;
        }
        ToastUtils.makeToast(this, localAddCommentReformer.message);
        continue;
      }
      if ((paramT instanceof DeleteCommentReformer))
      {
        DeleteCommentReformer localDeleteCommentReformer = (DeleteCommentReformer)paramT;
        if ("Y".equals(localDeleteCommentReformer.result))
        {
          this.isNeedRefreshTrainDet = true;
          ToastUtils.makeToast(this, getString(R.string.h_40_5));
          if (("0".equals(this.clickFlg)) || ("2".equals(this.clickFlg)));
          for (String str = this.itemModel.commentId; ; str = this.itemModel.fatherCommentId)
          {
            deleteCommentRefresh(str);
            this.clickFlg = "";
            this.itemModel = null;
            break;
          }
        }
        if (com.sportq.fit.common.utils.StringUtils.isNull(localDeleteCommentReformer.message))
          continue;
        ToastUtils.makeToast(this, localDeleteCommentReformer.message);
        continue;
      }
      if ((paramT instanceof ReportReformer))
      {
        ReportReformer localReportReformer = (ReportReformer)paramT;
        if ("Y".equals(localReportReformer.result))
        {
          ToastUtils.makeToast(this, getString(R.string.h_39_1));
          continue;
        }
        if (com.sportq.fit.common.utils.StringUtils.isNull(localReportReformer.message))
          continue;
        ToastUtils.makeToast(this, localReportReformer.message);
        continue;
      }
      if (!(paramT instanceof FreezeUserReformer))
        continue;
      FreezeUserReformer localFreezeUserReformer = (FreezeUserReformer)paramT;
      if ("Y".equals(localFreezeUserReformer.result))
      {
        ToastUtils.makeToast(this, getString(R.string.h_40_5));
        continue;
      }
      if (com.sportq.fit.common.utils.StringUtils.isNull(localFreezeUserReformer.message))
        continue;
      ToastUtils.makeToast(this, localFreezeUserReformer.message);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.content_comment_layout);
    EventBus.getDefault().register(this);
    this.presenter = new PresenterImpl(this);
    this.dialog = new DialogManager();
    init();
  }

  public void loadMore()
  {
    if ((this.swipeToLoadLayout.isRefreshing()) || (this.recyclerView == null))
      return;
    this.recyclerView.setTag("load.more");
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.tpcId = this.tpcId;
    localRequestModel.tpcType = this.tpcType;
    localRequestModel.commentId = this.commentId;
    this.presenter.getCommentList(localRequestModel, this);
  }

  protected void onDestroy()
  {
    if (this.isNeedRefreshTrainDet)
      EventBus.getDefault().post("refresh.train.info");
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(CommentEvent paramCommentEvent)
  {
    if (com.sportq.fit.common.utils.StringUtils.isNull(this.fromFlg))
    {
      if (!"2".equals(this.tpcType))
        break label68;
      CustomToolBar localCustomToolBar2 = this.toolbar;
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(this.commentNum);
      localCustomToolBar2.setTitle(String.format("%s条课程评论", arrayOfObject));
    }
    while (true)
    {
      setSupportActionBar(this.toolbar);
      return;
      label68: CustomToolBar localCustomToolBar1 = this.toolbar;
      int i = R.string.h_23_1;
      String[] arrayOfString = new String[1];
      arrayOfString[0] = String.valueOf(paramCommentEvent.commentNum);
      localCustomToolBar1.setTitle(UseStringUtils.getStr(i, arrayOfString));
    }
  }

  @Subscribe
  public void onEventMainThread(LikeEvent paramLikeEvent)
  {
    Iterator localIterator1 = this.hotList.iterator();
    NewHotCommentModel localNewHotCommentModel2;
    while (localIterator1.hasNext())
    {
      localNewHotCommentModel2 = (NewHotCommentModel)localIterator1.next();
      if (!paramLikeEvent.commentId.equals(localNewHotCommentModel2.commentId))
        continue;
      if (!LikeEvent.LIKE_ACTION.equals(paramLikeEvent.actionType))
        break label207;
      localNewHotCommentModel2.isLike = "1";
      localNewHotCommentModel2.likeNum = String.valueOf(1 + com.sportq.fit.common.utils.StringUtils.string2Int(localNewHotCommentModel2.likeNum));
    }
    Iterator localIterator2 = this.newList.iterator();
    NewHotCommentModel localNewHotCommentModel1;
    while (localIterator2.hasNext())
    {
      localNewHotCommentModel1 = (NewHotCommentModel)localIterator2.next();
      if (!paramLikeEvent.commentId.equals(localNewHotCommentModel1.commentId))
        continue;
      if (!LikeEvent.LIKE_ACTION.equals(paramLikeEvent.actionType))
        break label235;
      localNewHotCommentModel1.isLike = "1";
    }
    for (localNewHotCommentModel1.likeNum = String.valueOf(1 + com.sportq.fit.common.utils.StringUtils.string2Int(localNewHotCommentModel1.likeNum)); ; localNewHotCommentModel1.likeNum = String.valueOf(-1 + com.sportq.fit.common.utils.StringUtils.string2Int(localNewHotCommentModel1.likeNum)))
    {
      this.allList.clear();
      this.allList.addAll(this.hotList);
      this.allList.addAll(this.newList);
      this.adapter.replaceAll(this.allList);
      return;
      label207: localNewHotCommentModel2.isLike = "0";
      localNewHotCommentModel2.likeNum = String.valueOf(-1 + com.sportq.fit.common.utils.StringUtils.string2Int(localNewHotCommentModel2.likeNum));
      break;
      label235: localNewHotCommentModel1.isLike = "0";
    }
  }

  @Subscribe
  public void onEventMainThread(AllDialogueEvent paramAllDialogueEvent)
  {
    if (AllDialogueEvent.DELETE_COMMENT.equals(paramAllDialogueEvent.actionType))
      deleteCommentRefresh(paramAllDialogueEvent.commentId);
    if (AllDialogueEvent.ADD_COMMENT.equals(paramAllDialogueEvent.actionType))
      new Handler().postDelayed(new ContentCommentActivity.8(this), 600L);
  }

  @Subscribe
  public void onEventMainThread(BrowseEventEntity paramBrowseEventEntity)
  {
    if ((this.commentNum < 0) && (com.sportq.fit.common.utils.StringUtils.isNull(this.fromFlg)))
    {
      CustomToolBar localCustomToolBar = this.toolbar;
      int i = R.string.h_23_1;
      String[] arrayOfString = new String[1];
      arrayOfString[0] = paramBrowseEventEntity.strCommentNum;
      localCustomToolBar.setTitle(UseStringUtils.getStr(i, arrayOfString));
      setSupportActionBar(this.toolbar);
      this.commentNum = com.sportq.fit.common.utils.StringUtils.string2Int(paramBrowseEventEntity.strCommentNum);
    }
  }

  public void onItemClick(View paramView, NewHotCommentModel paramNewHotCommentModel, int paramInt, String paramString)
  {
    this.itemModel = paramNewHotCommentModel;
    this.deletePos = paramInt;
    this.clickFlg = paramString;
    if (("0".equals(paramString)) || ("1".equals(paramString)))
    {
      CommentDialog localCommentDialog = new CommentDialog();
      ContentCommentActivity.6 local6 = new ContentCommentActivity.6(this, paramView, paramString, paramNewHotCommentModel);
      if ("0".equals(paramString));
      for (String str = paramNewHotCommentModel.popType; ; str = paramNewHotCommentModel.fatherPopType)
      {
        localCommentDialog.createCommentDialog(local6, this, str);
        return;
      }
    }
    new CommentDialog().createReportDialog(new ContentCommentActivity.7(this, paramString), this, getString(R.string.h_40_1), "1");
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  public void onLikeClick(NewHotCommentModel paramNewHotCommentModel)
  {
    if (paramNewHotCommentModel.headIndex == 0)
    {
      Iterator localIterator2 = this.hotList.iterator();
      while (localIterator2.hasNext())
      {
        if (!((NewHotCommentModel)localIterator2.next()).commentId.equals(paramNewHotCommentModel.commentId))
          continue;
        if (!"0".equals(paramNewHotCommentModel.isLike))
          break label182;
        paramNewHotCommentModel.isLike = "1";
        paramNewHotCommentModel.likeNum = String.valueOf(1 + com.sportq.fit.common.utils.StringUtils.string2Int(paramNewHotCommentModel.likeNum));
        break label215;
      }
    }
    while (true)
    {
      this.allList.clear();
      this.allList.addAll(this.hotList);
      this.allList.addAll(this.newList);
      this.adapter.replaceAll(this.allList);
      BrowsePresenter localBrowsePresenter = new BrowsePresenter(this);
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.contentId = paramNewHotCommentModel.commentId;
      localRequestModel.likeType = "2";
      localRequestModel.flg = paramNewHotCommentModel.isLike;
      localBrowsePresenter.addLike(localRequestModel, this);
      return;
      label182: paramNewHotCommentModel.isLike = "0";
      paramNewHotCommentModel.likeNum = String.valueOf(-1 + com.sportq.fit.common.utils.StringUtils.string2Int(paramNewHotCommentModel.likeNum));
      continue;
      Iterator localIterator1 = this.newList.iterator();
      label215: if (!localIterator1.hasNext())
        continue;
      if (!((NewHotCommentModel)localIterator1.next()).commentId.equals(paramNewHotCommentModel.commentId))
        break;
      if ("0".equals(paramNewHotCommentModel.isLike))
      {
        paramNewHotCommentModel.isLike = "1";
        paramNewHotCommentModel.likeNum = String.valueOf(1 + com.sportq.fit.common.utils.StringUtils.string2Int(paramNewHotCommentModel.likeNum));
        continue;
      }
      paramNewHotCommentModel.isLike = "0";
      paramNewHotCommentModel.likeNum = String.valueOf(-1 + com.sportq.fit.common.utils.StringUtils.string2Int(paramNewHotCommentModel.likeNum));
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }

  protected void onPause()
  {
    super.onPause();
    reSwipeToLoadLayoutState();
  }

  public void onRefresh()
  {
    if ((this.recyclerView == null) || ((this.recyclerView.getTag() != null) && ("load.more".equals(this.recyclerView.getTag().toString()))))
      return;
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.tpcId = this.tpcId;
    localRequestModel.tpcType = this.tpcType;
    localRequestModel.commentId = "";
    this.presenter.getCommentList(localRequestModel, this);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle12.browse.activity.ContentCommentActivity
 * JD-Core Version:    0.6.0
 */