package com.sportq.fit.fitmoudle12.browse.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.collection.GrowingIO;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.browsepresenter.BrowsePresenter;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.CommentEvent;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.browse.BrowseInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.BrowseArticleListReformer;
import com.sportq.fit.common.utils.BrowseLikeStatusAlbumSaveTools;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.ReminderDialog;
import com.sportq.fit.fitmoudle12.R.color;
import com.sportq.fit.fitmoudle12.R.id;
import com.sportq.fit.fitmoudle12.R.layout;
import com.sportq.fit.fitmoudle12.R.mipmap;
import com.sportq.fit.fitmoudle12.R.string;
import com.sportq.fit.fitmoudle12.browse.presenter.PresenterImpl;
import com.sportq.fit.fitmoudle12.browse.presenter.PresenterInterface;
import com.sportq.fit.fitmoudle12.browse.util.BrowseSharePreference;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseEventEntity;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class BrowseArticleDetailsActivity extends BaseActivity
{
  private LinearLayout bottom_bar;
  private RTextView comment_btn;

  @SuppressLint({"HandlerLeak"})
  private Handler handler = new BrowseArticleDetailsActivity.6(this);
  private RTextView laud_btn;
  private BrowseLikeStatusAlbumSaveTools likeStatusAlbumSaveTools;
  private PresenterInterface presenter;
  private ProgressBar progressbar;
  private UseShareModel shareModel;
  private RTextView share_btn;
  private String strArticleId;
  private String strArticleUrl;
  private String strCommentNum;
  private String strHaveLike;
  private String strLikeNum;
  private String strShareNum;
  private String strWebPageTag;
  private WebView web_view;

  private void initElements()
  {
    this.dialog = new DialogManager();
    this.presenter = new PresenterImpl(this);
    this.likeStatusAlbumSaveTools = new BrowseLikeStatusAlbumSaveTools(this);
    this.laud_btn = ((RTextView)findViewById(R.id.laud_btn));
    RelativeLayout localRelativeLayout1 = (RelativeLayout)findViewById(R.id.laud_btn_layout);
    if (localRelativeLayout1 != null)
      localRelativeLayout1.setOnClickListener(new FitAction(this));
    this.comment_btn = ((RTextView)findViewById(R.id.comment_btn));
    RelativeLayout localRelativeLayout2 = (RelativeLayout)findViewById(R.id.comment_btn_layout);
    if (localRelativeLayout2 != null)
      localRelativeLayout2.setOnClickListener(new FitAction(this));
    this.share_btn = ((RTextView)findViewById(R.id.share_btn));
    RelativeLayout localRelativeLayout3 = (RelativeLayout)findViewById(R.id.share_btn_layout);
    if (localRelativeLayout3 != null)
      localRelativeLayout3.setOnClickListener(new FitAction(this));
    this.web_view = ((WebView)findViewById(R.id.web_view));
    this.progressbar = ((ProgressBar)findViewById(R.id.progressbar));
    if (this.progressbar != null)
      this.progressbar.setMax(100);
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    if (localCustomToolBar != null)
    {
      localCustomToolBar.setTitle("健康指南");
      localCustomToolBar.setNavIcon(R.mipmap.btn_close_black);
      localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
      localCustomToolBar.setBackgroundResource(R.color.white);
      setSupportActionBar(localCustomToolBar);
    }
    this.bottom_bar = ((LinearLayout)findViewById(R.id.bottom_bar));
    LinearLayout localLinearLayout = this.bottom_bar;
    if ("0".equals(this.strWebPageTag));
    for (int i = 0; ; i = 8)
    {
      localLinearLayout.setVisibility(i);
      if ((!StringUtils.isNull(this.strLikeNum)) && (!StringUtils.isNull(this.strCommentNum)) && (!StringUtils.isNull(this.strShareNum)))
        break;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.tpcId = this.strArticleId;
      this.presenter.getLikeCommentShareNum(localRequestModel, this);
      return;
    }
    setBottomBarNum();
  }

  private void loaderUrl()
  {
    String str1 = this.web_view.getSettings().getUserAgentString();
    this.web_view.getSettings().setUserAgentString(str1 + "useragent:Fit_" + CompDeviceInfoUtils.getVersionCode() + " " + "FitUID/" + BaseApplication.userModel.userId + " " + "FitSex/" + BaseApplication.userModel.coachSexf);
    this.web_view.getSettings().setDomStorageEnabled(true);
    this.web_view.getSettings().setJavaScriptEnabled(true);
    this.web_view.addJavascriptInterface(new MyJavaScriptInterface(null), "Fitapp");
    this.web_view.setWebViewClient(new BrowseArticleDetailsActivity.1(this));
    WebView localWebView1 = this.web_view;
    BrowseArticleDetailsActivity.2 local2 = new BrowseArticleDetailsActivity.2(this);
    localWebView1.setWebChromeClient(local2);
    VdsAgent.setWebChromeClient((WebView)localWebView1, local2);
    this.web_view.setDownloadListener(new BrowseArticleDetailsActivity.3(this));
    synCookies(this.strArticleUrl);
    this.web_view.getSettings().setCacheMode(2);
    WebView localWebView2 = this.web_view;
    String str2 = this.strArticleUrl;
    localWebView2.loadUrl(str2);
    VdsAgent.loadUrl((View)localWebView2, str2);
  }

  private void setBottomBarNum()
  {
    runOnUiThread(new BrowseArticleDetailsActivity.5(this));
  }

  private void setProMaxAction(int paramInt)
  {
    int i = 1;
    int j = paramInt;
    if (j <= 101)
    {
      int k = j;
      if (j == 101);
      for (i = 800; ; i += 5)
      {
        new Handler().postDelayed(new BrowseArticleDetailsActivity.4(this, k), i);
        j++;
        break;
      }
    }
  }

  public void fitOnClick(View paramView)
  {
    String str2;
    int i;
    label57: int j;
    label90: int k;
    label150: String str8;
    label189: label196: String str4;
    label336: String str5;
    label360: String str6;
    label387: String str7;
    if (paramView.getId() == R.id.laud_btn_layout)
    {
      str2 = this.laud_btn.getText().toString();
      if (StringUtils.isNull(str2))
        return;
      RTextViewHelper localRTextViewHelper = this.laud_btn.getHelper();
      if (this.laud_btn.getTag() == null)
      {
        i = R.mipmap.video_press_like_icon;
        localRTextViewHelper.setIconNormal(ContextCompat.getDrawable(this, i));
        RTextView localRTextView1 = this.laud_btn;
        if (this.laud_btn.getTag() != null)
          break label474;
        j = R.color.color_ff5630;
        localRTextView1.setTextColor(ContextCompat.getColor(this, j));
        if (("0".equals(str2)) || ("喜欢".equals(str2)))
          break label512;
        RTextView localRTextView3 = this.laud_btn;
        if (this.laud_btn.getTag() != null)
          break label482;
        k = 1 + Integer.valueOf(str2).intValue();
        localRTextView3.setText(String.valueOf(k));
        RTextView localRTextView4 = this.laud_btn;
        if (!"0".equals(String.valueOf(this.laud_btn.getText())))
          break label497;
        str8 = "喜欢";
        localRTextView4.setText(str8);
        if ((this.laud_btn.getTag() == null) && (StringUtils.isNull(BrowseSharePreference.getFirVideoOrArticlelikeBtnTag(this))))
        {
          BrowseSharePreference.putFirVideoOrArticlelikeBtnTag(this, "click");
          ReminderDialog localReminderDialog = new ReminderDialog(this);
          localReminderDialog.createDialog();
          localReminderDialog.hideCloseLayout();
          localReminderDialog.setImageRes(R.mipmap.dialog_like_store_icon);
          localReminderDialog.setPopupMainTitleText(getResources().getString(R.string.h_5_1));
          localReminderDialog.setPopupTitleText(getResources().getString(R.string.h_5_2));
          localReminderDialog.setButtonText(getResources().getString(R.string.h_5_3));
          localReminderDialog.setButtonLayoutOnClick(null);
        }
        BrowseLikeStatusAlbumSaveTools localBrowseLikeStatusAlbumSaveTools = this.likeStatusAlbumSaveTools;
        String str3 = this.strArticleId;
        if (this.laud_btn.getTag() != null)
          break label525;
        str4 = "1";
        localBrowseLikeStatusAlbumSaveTools.putArticleLikeFlg(str3, str4);
        if (this.laud_btn.getTag() != null)
          break label532;
        str5 = "1";
        this.strHaveLike = str5;
        RTextView localRTextView2 = this.laud_btn;
        if (this.laud_btn.getTag() != null)
          break label539;
        str6 = "press";
        localRTextView2.setTag(str6);
        BrowsePresenter localBrowsePresenter = new BrowsePresenter(this);
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.contentId = this.strArticleId;
        localRequestModel.likeType = "0";
        if (this.laud_btn.getTag() != null)
          break label545;
        str7 = "0";
        label443: localRequestModel.flg = str7;
        localBrowsePresenter.addLike(localRequestModel, this);
      }
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      i = R.mipmap.video_details_like_icon;
      break label57;
      label474: j = R.color.color_313131;
      break label90;
      label482: k = -1 + Integer.valueOf(str2).intValue();
      break label150;
      label497: str8 = String.valueOf(this.laud_btn.getText());
      break label189;
      label512: this.laud_btn.setText("1");
      break label196;
      label525: str4 = "0";
      break label336;
      label532: str5 = "0";
      break label360;
      label539: str6 = null;
      break label387;
      label545: str7 = "1";
      break label443;
      if (paramView.getId() == R.id.comment_btn_layout)
      {
        Intent localIntent = new Intent(this, ContentCommentActivity.class);
        localIntent.putExtra("tpc.id", this.strArticleId);
        String str1 = this.comment_btn.getText().toString();
        if ((StringUtils.isNull(str1)) || ("评论".equals(str1)))
          str1 = "0";
        localIntent.putExtra("comment.num", str1);
        localIntent.putExtra("tpc.type", "0");
        startActivity(localIntent);
        AnimationUtil.pageJumpAnim(this, 0);
        continue;
      }
      if (paramView.getId() != R.id.share_btn_layout)
        continue;
      if (this.shareModel == null)
        break;
      this.dialog.showShareChoiseDialog(this, 12, this.shareModel, this.dialog);
    }
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof BrowseArticleListReformer))
    {
      BrowseArticleListReformer localBrowseArticleListReformer = (BrowseArticleListReformer)paramT;
      this.strLikeNum = localBrowseArticleListReformer.likeNum;
      this.strCommentNum = localBrowseArticleListReformer.commentNumber;
      this.strShareNum = localBrowseArticleListReformer.shareNumber;
      setBottomBarNum();
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    String str2;
    if (getIntent() != null)
    {
      this.strArticleUrl = getIntent().getStringExtra("article.url");
      this.strArticleId = getIntent().getStringExtra("article.id");
      this.strWebPageTag = getIntent().getStringExtra("webPage.tag");
      this.strHaveLike = getIntent().getStringExtra("have.like");
      this.strLikeNum = getIntent().getStringExtra("like.num");
      this.strCommentNum = getIntent().getStringExtra("comment.num");
      this.strShareNum = getIntent().getStringExtra("share.num");
      String str1 = getIntent().getStringExtra("url");
      if (!StringUtils.isNull(str1))
        str2 = str1.replaceAll("%(?![0-9a-fA-F]{2})", "%25");
    }
    try
    {
      this.strArticleUrl = URLDecoder.decode(str2, "UTF-8");
      if ((StringUtils.isNull(this.strArticleId)) || (StringUtils.isNull(this.strArticleUrl)) || (StringUtils.isNull(this.strWebPageTag)))
      {
        finish();
        return;
      }
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      while (true)
        localUnsupportedEncodingException.printStackTrace();
      getWindow().setFormat(-3);
      setContentView(R.layout.browse_article_details);
      EventBus.getDefault().register(this);
      GrowingIO.getInstance().setPageVariable(this, "page_name", "文章");
      initElements();
      loaderUrl();
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(CommentEvent paramCommentEvent)
  {
    if (paramCommentEvent == null)
      return;
    RTextView localRTextView = this.comment_btn;
    if (paramCommentEvent.commentNum > 0);
    for (Object localObject = Integer.valueOf(paramCommentEvent.commentNum); ; localObject = "评论")
    {
      localRTextView.setText(String.valueOf(localObject));
      return;
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      while (true)
      {
        try
        {
          if (!this.web_view.canGoBack())
            continue;
          this.web_view.goBack();
          break;
          String str1 = String.valueOf(this.laud_btn.getText());
          if (StringUtils.isNull(str1))
            continue;
          EventBus localEventBus = EventBus.getDefault();
          String str2 = this.strArticleId;
          if (this.laud_btn.getTag() == null)
          {
            str3 = "0";
            if (!"喜欢".equals(str1))
              continue;
            str1 = "0";
            localEventBus.post(new BrowseEventEntity(str2, str3, str1));
            finish();
            AnimationUtil.pageJumpAnim(this, 1);
          }
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
          finish();
        }
        String str3 = "1";
      }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
    case 16908332:
    }
    String str1 = String.valueOf(this.laud_btn.getText());
    EventBus localEventBus;
    String str2;
    if (!StringUtils.isNull(str1))
    {
      localEventBus = EventBus.getDefault();
      str2 = this.strArticleId;
      if (this.laud_btn.getTag() != null)
        break label139;
    }
    label139: for (String str3 = "0"; ; str3 = "1")
    {
      if ("喜欢".equals(str1))
        str1 = "0";
      localEventBus.post(new BrowseEventEntity(str2, str3, str1));
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      break;
    }
  }

  public void synCookies(String paramString)
  {
    CookieSyncManager.createInstance(this);
    CookieManager localCookieManager = CookieManager.getInstance();
    localCookieManager.setAcceptCookie(true);
    localCookieManager.removeSessionCookie();
    if (StringUtils.isNull(BaseApplication.userModel.userId));
    for (String str = ""; ; str = BaseApplication.userModel.userId)
    {
      localCookieManager.setCookie(paramString, "Fit_uid=" + str);
      CookieSyncManager.getInstance().sync();
      return;
    }
  }

  private class MyJavaScriptInterface
  {
    private MyJavaScriptInterface()
    {
    }

    @JavascriptInterface
    public void androidOpenPage(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 4;
      localMessage.obj = paramString;
      BrowseArticleDetailsActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void androidSaveImg(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 3;
      localMessage.obj = paramString;
      BrowseArticleDetailsActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void clickDw(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 8;
      localMessage.obj = paramString;
      BrowseArticleDetailsActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void clickOnAndroid(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 0;
      localMessage.obj = paramString;
      BrowseArticleDetailsActivity.this.handler.sendMessage(localMessage);
    }

    @JavascriptInterface
    public void webViewShare(String paramString)
    {
      Message localMessage = new Message();
      localMessage.arg1 = 2;
      localMessage.obj = paramString;
      BrowseArticleDetailsActivity.this.handler.sendMessage(localMessage);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle12.browse.activity.BrowseArticleDetailsActivity
 * JD-Core Version:    0.6.0
 */