package com.sportq.fit.fitmoudle12.browse.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.collection.GrowingIO;
import com.sportq.fit.browsepresenter.BrowsePresenter;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.event.CommentEvent;
import com.sportq.fit.common.event.VideoLikeEvent;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.browse.BrowseInterface;
import com.sportq.fit.common.model.BrowseEntity;
import com.sportq.fit.common.model.CacheDBModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.BrowseVideoListReformer;
import com.sportq.fit.common.utils.BrowseLikeStatusAlbumSaveTools;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.fitmoudle.widget.ReminderDialog;
import com.sportq.fit.fitmoudle12.R.color;
import com.sportq.fit.fitmoudle12.R.id;
import com.sportq.fit.fitmoudle12.R.layout;
import com.sportq.fit.fitmoudle12.R.mipmap;
import com.sportq.fit.fitmoudle12.R.string;
import com.sportq.fit.fitmoudle12.browse.event.VideoCacheProgressEvent;
import com.sportq.fit.fitmoudle12.browse.presenter.PresenterImpl;
import com.sportq.fit.fitmoudle12.browse.presenter.PresenterInterface;
import com.sportq.fit.fitmoudle12.browse.reformer.model.BrowseVideoDetailsModel;
import com.sportq.fit.fitmoudle12.browse.reformer.reformer.BrowseVideoDetailsReformer;
import com.sportq.fit.fitmoudle12.browse.util.BrowseSharePreference;
import com.sportq.fit.fitmoudle12.browse.widget.TransImageView.OnExecuteAnimFinishListener;
import com.sportq.fit.fitmoudle12.browse.widget.mylike.BrowseEventEntity;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.middlelib.statistics.GrowingIOUserBehavior;
import com.sportq.fit.middlelib.statistics.GrowingIOVariables;
import com.sportq.fit.supportlib.CommonUtils;
import com.sportq.fit.videopresenter.manager.cachemanager.VideoCacheDBManager;
import com.sportq.fit.videopresenter.manager.cachemanager.VideoCacheManager;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class BrowseVideoDetailsActivity extends BaseActivity
  implements TransImageView.OnExecuteAnimFinishListener
{
  private BrowseVideoListReformer bReformer;
  private LinearLayout bottom_bar;
  private View bottom_line;
  private RTextView comment_btn;
  private RelativeLayout details_frame_layout;
  private ImageView downLoadImg;
  private LinearLayout downLoadLayout;
  private CustomTextView downLoadState;
  private RTextView laud_btn;
  private BrowseLikeStatusAlbumSaveTools likeStatusAlbumSaveTools;
  private ProgressBar loader_icon;
  private RTextView share_btn;
  private String strImgUrl;
  private String strTopicId;
  private BrowseVideoDetailsReformer uiReformer;
  private TextView video_desc;
  private ImageView video_details_iv;
  private TextView video_name;
  private TextView video_type;

  private boolean checkScreenRatio()
  {
    return ((BaseApplication.screenWidth == 768) && (BaseApplication.screenHeight == 1184)) || ((BaseApplication.screenWidth <= 720) && (BaseApplication.screenHeight <= 1280));
  }

  private void closePage()
  {
    String str1 = String.valueOf(this.laud_btn.getText());
    EventBus localEventBus;
    String str2;
    if (!StringUtils.isNull(str1))
    {
      localEventBus = EventBus.getDefault();
      str2 = this.strTopicId;
      if (this.laud_btn.getTag() != null)
        break label78;
    }
    label78: for (String str3 = "0"; ; str3 = "1")
    {
      if ("喜欢".equals(str1))
        str1 = "0";
      localEventBus.post(new BrowseEventEntity(str2, str3, str1));
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      return;
    }
  }

  private void initElements()
  {
    this.dialog = new DialogManager();
    this.likeStatusAlbumSaveTools = new BrowseLikeStatusAlbumSaveTools(this);
    this.laud_btn = ((RTextView)findViewById(R.id.laud_btn));
    RelativeLayout localRelativeLayout1 = (RelativeLayout)findViewById(R.id.laud_btn_layout);
    if (localRelativeLayout1 != null)
      localRelativeLayout1.setOnClickListener(new FitAction(this));
    this.comment_btn = ((RTextView)findViewById(R.id.comment_btn));
    RelativeLayout localRelativeLayout2 = (RelativeLayout)findViewById(R.id.comment_btn_layout);
    if (localRelativeLayout2 != null)
      localRelativeLayout2.setOnClickListener(new FitAction(this));
    this.share_btn = ((RTextView)findViewById(R.id.share_btn));
    RelativeLayout localRelativeLayout3 = (RelativeLayout)findViewById(R.id.share_btn_layout);
    if (localRelativeLayout3 != null)
      localRelativeLayout3.setOnClickListener(new FitAction(this));
    this.video_details_iv = ((ImageView)findViewById(R.id.video_details_iv));
    this.video_name = ((TextView)findViewById(R.id.video_name));
    this.video_type = ((TextView)findViewById(R.id.video_type));
    this.downLoadLayout = ((LinearLayout)findViewById(R.id.downLoadLayout));
    this.downLoadLayout.setOnClickListener(new FitAction(this));
    this.downLoadImg = ((ImageView)findViewById(R.id.downLoadImg));
    this.downLoadState = ((CustomTextView)findViewById(R.id.downLoadState));
    this.video_desc = ((TextView)findViewById(R.id.video_desc));
    this.details_frame_layout = ((RelativeLayout)findViewById(R.id.details_frame_layout));
    this.bottom_bar = ((LinearLayout)findViewById(R.id.bottom_bar));
    this.bottom_line = findViewById(R.id.bottom_line);
    RelativeLayout localRelativeLayout4 = (RelativeLayout)findViewById(R.id.video_details_layout);
    this.loader_icon = ((ProgressBar)findViewById(R.id.loader_icon));
    RelativeLayout localRelativeLayout5 = (RelativeLayout)findViewById(R.id.close_layout);
    if (localRelativeLayout5 != null)
      localRelativeLayout5.setOnClickListener(new FitAction(this));
    if (!StringUtils.isNull(this.strImgUrl))
    {
      int i = BaseApplication.screenWidth;
      this.video_details_iv.getLayoutParams().width = i;
      this.video_details_iv.getLayoutParams().height = i;
      GlideUtils.loadImgByDefault(this.strImgUrl, R.mipmap.img_default, this.video_details_iv);
      localRelativeLayout4.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
      onAnimFinish();
    }
    while (true)
    {
      ImageView localImageView = (ImageView)findViewById(R.id.video_play_btn);
      if (localImageView != null)
        localImageView.setOnClickListener(new FitAction(this));
      return;
      localRelativeLayout4.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    }
  }

  private void setPageData(BrowseEntity paramBrowseEntity, BrowseVideoDetailsModel paramBrowseVideoDetailsModel)
  {
    if ((paramBrowseEntity == null) && (paramBrowseVideoDetailsModel == null));
    label43: label815: label947: 
    while (true)
    {
      return;
      String str1;
      String str3;
      String str5;
      label69: int i;
      label122: int j;
      String str8;
      label187: String str9;
      label204: String str10;
      label241: String str11;
      String str12;
      label324: String str14;
      label371: String str13;
      if (paramBrowseEntity == null)
      {
        str1 = paramBrowseVideoDetailsModel.tpcTitle;
        if (!StringUtils.isNull(str1))
          break label619;
        this.video_name.setVisibility(4);
        if (paramBrowseEntity != null)
          break label662;
        str3 = paramBrowseVideoDetailsModel.strCategory;
        if (!StringUtils.isNull(str3))
          break label671;
        this.video_type.setVisibility(4);
        if (paramBrowseEntity != null)
          break label714;
        str5 = paramBrowseVideoDetailsModel.tpcDescribe;
        if (!StringUtils.isNull(str5))
          break label723;
        this.video_desc.setVisibility(4);
        String str7 = this.likeStatusAlbumSaveTools.getVideoLikeFlg(this.strTopicId);
        RTextViewHelper localRTextViewHelper = this.laud_btn.getHelper();
        if (!"1".equals(str7))
          break label766;
        i = R.mipmap.video_press_like_icon;
        localRTextViewHelper.setIconNormal(ContextCompat.getDrawable(this, i));
        RTextView localRTextView1 = this.laud_btn;
        if (!"1".equals(str7))
          break label774;
        j = R.color.color_ff5630;
        localRTextView1.setTextColor(ContextCompat.getColor(this, j));
        RTextView localRTextView2 = this.laud_btn;
        if (!"1".equals(str7))
          break label782;
        str8 = "press";
        localRTextView2.setTag(str8);
        if (paramBrowseEntity != null)
          break label788;
        str9 = paramBrowseVideoDetailsModel.likeNum;
        RTextView localRTextView3 = this.laud_btn;
        if ("0".equals(str9))
          str9 = "喜欢";
        localRTextView3.setText(str9);
        if (paramBrowseEntity != null)
          break label797;
        str10 = paramBrowseVideoDetailsModel.commentNumber;
        RTextView localRTextView4 = this.comment_btn;
        if ("0".equals(str10))
          str10 = getResources().getString(R.string.c_3_3);
        localRTextView4.setText(str10);
        if (paramBrowseEntity != null)
          break label806;
        str11 = paramBrowseVideoDetailsModel.shareNumber;
        RTextView localRTextView5 = this.share_btn;
        if ("0".equals(str11))
          str11 = "转发";
        localRTextView5.setText(str11);
        if (paramBrowseEntity != null)
          break label815;
        str12 = paramBrowseVideoDetailsModel.imageUrl;
        if (!StringUtils.isNull(str12))
        {
          int k = BaseApplication.screenWidth;
          this.video_details_iv.getLayoutParams().width = k;
          this.video_details_iv.getLayoutParams().height = k;
          if (paramBrowseEntity != null)
            break label824;
          str14 = paramBrowseVideoDetailsModel.imageUrl;
          GlideUtils.loadImgByDefault(str14, R.mipmap.img_default, this.video_details_iv);
        }
        if ((StringUtils.isNull(String.valueOf(this.laud_btn.getText()))) || (StringUtils.isNull(String.valueOf(this.comment_btn.getText()))) || (StringUtils.isNull(String.valueOf(this.share_btn.getText()))) || (StringUtils.isNull(String.valueOf(this.video_desc.getText()))))
        {
          this.loader_icon.setVisibility(0);
          PresenterImpl localPresenterImpl = new PresenterImpl(this);
          RequestModel localRequestModel = new RequestModel();
          localRequestModel.tpcId = this.strTopicId;
          localPresenterImpl.getVideoDet(localRequestModel, this);
        }
        if (paramBrowseEntity == null)
          break label833;
        str13 = paramBrowseEntity.tpcId;
        label503: if (VideoCacheDBManager.getIntance().selectCache(str13) == null)
          break label842;
        this.downLoadState.setVisibility(0);
        this.downLoadState.setText(R.string.a_3_8);
        this.downLoadLayout.setClickable(false);
        this.downLoadImg.setImageResource(R.mipmap.btn_download_grey);
      }
      while (true)
      {
        if (paramBrowseEntity == null)
          break label947;
        GrowingIOVariables localGrowingIOVariables = new GrowingIOVariables();
        localGrowingIOVariables.eventid = "view_page";
        localGrowingIOVariables.page_type = "视频详情";
        localGrowingIOVariables.page_id = paramBrowseEntity.tpcId;
        localGrowingIOVariables.page_title = this.video_name.getText().toString();
        GrowingIOUserBehavior.uploadGrowingIO(localGrowingIOVariables);
        return;
        str1 = paramBrowseEntity.tpcTitle;
        break;
        label619: this.video_name.setVisibility(0);
        TextView localTextView1 = this.video_name;
        if (paramBrowseEntity == null);
        for (String str2 = paramBrowseVideoDetailsModel.tpcTitle; ; str2 = paramBrowseEntity.tpcTitle)
        {
          localTextView1.setText(str2);
          break;
        }
        str3 = paramBrowseEntity.strCategory;
        break label43;
        this.video_type.setVisibility(0);
        TextView localTextView2 = this.video_type;
        if (paramBrowseEntity == null);
        for (String str4 = paramBrowseVideoDetailsModel.strCategory; ; str4 = paramBrowseEntity.strCategory)
        {
          localTextView2.setText(str4);
          break;
        }
        label714: str5 = paramBrowseEntity.tpcDescribe;
        break label69;
        label723: this.video_desc.setVisibility(0);
        TextView localTextView3 = this.video_desc;
        if (paramBrowseEntity == null);
        for (String str6 = paramBrowseVideoDetailsModel.tpcDescribe; ; str6 = paramBrowseEntity.tpcDescribe)
        {
          localTextView3.setText(str6);
          break;
        }
        label766: i = R.mipmap.video_details_like_icon;
        break label122;
        j = R.color.color_313131;
        break label155;
        str8 = null;
        break label187;
        str9 = paramBrowseEntity.likeNum;
        break label204;
        str10 = paramBrowseEntity.commentNumber;
        break label241;
        str11 = paramBrowseEntity.shareNumber;
        break label286;
        str12 = paramBrowseEntity.imageUrl;
        break label324;
        label824: str14 = paramBrowseEntity.imageUrl;
        break label371;
        label833: str13 = paramBrowseVideoDetailsModel.tpcId;
        break label503;
        label842: if (VideoCacheManager.getInstance().isDownloading(str13))
        {
          this.downLoadState.setVisibility(0);
          this.downLoadState.setText(String.valueOf(VideoCacheManager.getInstance().getProgress(str13) + "%"));
          this.downLoadLayout.setClickable(false);
          this.downLoadImg.setImageResource(R.mipmap.btn_download_black);
          continue;
        }
        this.downLoadState.setVisibility(8);
        this.downLoadImg.setImageResource(R.mipmap.btn_download_black);
        this.downLoadLayout.setClickable(true);
      }
    }
  }

  public void cacheVideo()
  {
    this.downLoadState.setVisibility(0);
    this.downLoadState.setText("0%");
    CacheDBModel localCacheDBModel = new CacheDBModel();
    BrowseVideoListReformer localBrowseVideoListReformer = this.bReformer;
    BrowseEntity localBrowseEntity = null;
    if (localBrowseVideoListReformer != null)
    {
      ArrayList localArrayList = this.bReformer.lstWeekVideo;
      localBrowseEntity = null;
      if (localArrayList != null)
      {
        int i = this.bReformer.lstWeekVideo.size();
        localBrowseEntity = null;
        if (i > 0)
          localBrowseEntity = (BrowseEntity)this.bReformer.lstWeekVideo.get(this.bReformer.curPlayIndex);
      }
    }
    if ((localBrowseEntity == null) && (this.uiReformer == null))
      return;
    if (localBrowseEntity == null)
    {
      localCacheDBModel.tpcId = this.uiReformer.browseVideoDetailsModel.tpcId;
      localCacheDBModel.tpcTitle = this.uiReformer.browseVideoDetailsModel.tpcTitle;
      localCacheDBModel.categoryName = this.uiReformer.browseVideoDetailsModel.categoryName;
      localCacheDBModel.imageUrl = this.uiReformer.browseVideoDetailsModel.imageUrl;
      localCacheDBModel.duration = this.uiReformer.browseVideoDetailsModel.duration;
      localCacheDBModel.tpcDescribe = this.uiReformer.browseVideoDetailsModel.tpcDescribe;
      localCacheDBModel.videoURL = this.uiReformer.browseVideoDetailsModel.videoURL;
    }
    for (localCacheDBModel.strCategory = this.uiReformer.browseVideoDetailsModel.strCategory; ; localCacheDBModel.strCategory = localBrowseEntity.strCategory)
    {
      CompDeviceInfoUtils.applyPermission(new BrowseVideoDetailsActivity.4(this, localCacheDBModel), this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
      return;
      localCacheDBModel.tpcId = localBrowseEntity.tpcId;
      localCacheDBModel.tpcTitle = localBrowseEntity.tpcTitle;
      localCacheDBModel.categoryName = localBrowseEntity.categoryName;
      localCacheDBModel.imageUrl = localBrowseEntity.imageUrl;
      localCacheDBModel.duration = localBrowseEntity.duration;
      localCacheDBModel.tpcDescribe = localBrowseEntity.tpcDescribe;
      localCacheDBModel.videoURL = localBrowseEntity.videoURL;
    }
  }

  public void checkNetAndCacheVideo()
  {
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      ToastUtils.makeToast(this, StringUtils.getStringResources(R.string.no_network_error_hint));
      return;
    }
    if (!"wifi".equals(CompDeviceInfoUtils.getNetType()))
    {
      this.dialog.createChoiceDialog(new BrowseVideoDetailsActivity.3(this), this, "", "是否使用流量缓存视频?");
      return;
    }
    cacheVideo();
  }

  public void fitOnClick(View paramView)
  {
    int i = paramView.getId();
    if (i == R.id.close_layout)
      closePage();
    while (true)
    {
      super.fitOnClick(paramView);
      label64: label106: label379: BrowseEntity localBrowseEntity;
      label165: label203: label210: label349: label492: label507: 
      do
      {
        do
        {
          while (true)
          {
            return;
            if (i != R.id.laud_btn_layout)
              break;
            String str10 = String.valueOf(this.laud_btn.getText());
            if (StringUtils.isNull(str10))
              continue;
            int k;
            int m;
            int n;
            String str15;
            String str12;
            String str13;
            BrowsePresenter localBrowsePresenter;
            RequestModel localRequestModel;
            if (this.laud_btn.getTag() == null)
            {
              k = R.mipmap.video_press_like_icon;
              Drawable localDrawable = ContextCompat.getDrawable(this, k);
              this.laud_btn.getHelper().setIconNormal(localDrawable);
              RTextView localRTextView1 = this.laud_btn;
              if (this.laud_btn.getTag() != null)
                break label469;
              m = R.color.color_ff5630;
              localRTextView1.setTextColor(ContextCompat.getColor(this, m));
              if (("0".equals(str10)) || ("喜欢".equals(str10)))
                break label507;
              RTextView localRTextView3 = this.laud_btn;
              if (this.laud_btn.getTag() != null)
                break label477;
              n = 1 + Integer.valueOf(str10).intValue();
              localRTextView3.setText(String.valueOf(n));
              RTextView localRTextView4 = this.laud_btn;
              if (!"0".equals(String.valueOf(this.laud_btn.getText())))
                break label492;
              str15 = "喜欢";
              localRTextView4.setText(str15);
              if ((this.laud_btn.getTag() == null) && (StringUtils.isNull(BrowseSharePreference.getFirVideoOrArticlelikeBtnTag(this))))
              {
                BrowseSharePreference.putFirVideoOrArticlelikeBtnTag(this, "click");
                ReminderDialog localReminderDialog = new ReminderDialog(this);
                localReminderDialog.createDialog();
                localReminderDialog.hideCloseLayout();
                localReminderDialog.setImageRes(R.mipmap.dialog_like_store_icon);
                localReminderDialog.setPopupMainTitleText(getResources().getString(R.string.h_5_1));
                localReminderDialog.setPopupTitleText(getResources().getString(R.string.h_5_2));
                localReminderDialog.setButtonText(getResources().getString(R.string.h_5_3));
                localReminderDialog.setButtonLayoutOnClick(null);
              }
              BrowseLikeStatusAlbumSaveTools localBrowseLikeStatusAlbumSaveTools = this.likeStatusAlbumSaveTools;
              String str11 = this.strTopicId;
              if (this.laud_btn.getTag() != null)
                break label519;
              str12 = "1";
              localBrowseLikeStatusAlbumSaveTools.putVideoLikeFlg(str11, str12);
              RTextView localRTextView2 = this.laud_btn;
              if (this.laud_btn.getTag() != null)
                break label526;
              str13 = "press";
              localRTextView2.setTag(str13);
              CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GET_VIDEO_DET);
              localBrowsePresenter = new BrowsePresenter(this);
              localRequestModel = new RequestModel();
              localRequestModel.contentId = this.strTopicId;
              localRequestModel.likeType = "1";
              if (this.laud_btn.getTag() != null)
                break label532;
            }
            for (String str14 = "0"; ; str14 = "1")
            {
              localRequestModel.flg = str14;
              localBrowsePresenter.addLike(localRequestModel, this);
              break;
              k = R.mipmap.video_details_like_icon;
              break label64;
              m = R.color.color_313131;
              break label106;
              n = -1 + Integer.valueOf(str10).intValue();
              break label165;
              str15 = String.valueOf(this.laud_btn.getText());
              break label203;
              this.laud_btn.setText("1");
              break label210;
              str12 = "0";
              break label349;
              str13 = null;
              break label379;
            }
          }
          if (i == R.id.comment_btn_layout)
          {
            Intent localIntent = new Intent(this, ContentCommentActivity.class);
            localIntent.putExtra("tpc.id", this.strTopicId);
            String str1 = this.comment_btn.getText().toString();
            if ((StringUtils.isNull(str1)) || (getResources().getString(R.string.c_3_3).equals(str1)))
              str1 = "0";
            localIntent.putExtra("comment.num", str1);
            localIntent.putExtra("tpc.type", "1");
            startActivity(localIntent);
            AnimationUtil.pageJumpAnim(this, 0);
            break;
          }
          if (i != R.id.share_btn_layout)
            break label1062;
        }
        while ((this.uiReformer == null) && (this.bReformer == null));
        BrowseVideoListReformer localBrowseVideoListReformer = this.bReformer;
        localBrowseEntity = null;
        if (localBrowseVideoListReformer == null)
          continue;
        ArrayList localArrayList = this.bReformer.lstWeekVideo;
        localBrowseEntity = null;
        if (localArrayList == null)
          continue;
        int j = this.bReformer.lstWeekVideo.size();
        localBrowseEntity = null;
        if (j <= 0)
          continue;
        localBrowseEntity = (BrowseEntity)this.bReformer.lstWeekVideo.get(this.bReformer.curPlayIndex);
      }
      while ((localBrowseEntity == null) && (this.uiReformer == null));
      label469: label477: UseShareModel localUseShareModel = new UseShareModel();
      label519: label526: label532: String str2;
      label774: String str3;
      label793: String str4;
      label812: String str5;
      label831: String str6;
      label850: String str7;
      label869: String str8;
      if (localBrowseEntity != null)
      {
        str2 = localBrowseEntity.tpcId;
        localUseShareModel.tpcId = str2;
        if (localBrowseEntity == null)
          break label957;
        str3 = localBrowseEntity.tpcTitle;
        localUseShareModel.title = str3;
        if (localBrowseEntity == null)
          break label972;
        str4 = localBrowseEntity.videoURL;
        localUseShareModel.link = str4;
        if (localBrowseEntity == null)
          break label987;
        str5 = localBrowseEntity.imageUrl;
        localUseShareModel.imgUrl = str5;
        if (localBrowseEntity == null)
          break label1002;
        str6 = localBrowseEntity.imageUrl;
        localUseShareModel.weiboImg = str6;
        if (localBrowseEntity == null)
          break label1017;
        str7 = localBrowseEntity.tpcDescribe;
        localUseShareModel.describe = str7;
        if (localBrowseEntity == null)
          break label1032;
        str8 = localBrowseEntity.tpcTitle;
        label888: localUseShareModel.title = str8;
        if (localBrowseEntity == null)
          break label1047;
      }
      label1032: label1047: for (String str9 = localBrowseEntity.olapInfo; ; str9 = this.uiReformer.browseVideoDetailsModel.olapInfo)
      {
        localUseShareModel.olapInfo = str9;
        localUseShareModel.shareType = "1";
        this.dialog.showShareChoiseDialog(this, 23, localUseShareModel, this.dialog);
        break;
        str2 = this.uiReformer.browseVideoDetailsModel.tpcId;
        break label774;
        label957: str3 = this.uiReformer.browseVideoDetailsModel.tpcTitle;
        break label793;
        label972: str4 = this.uiReformer.browseVideoDetailsModel.videoURL;
        break label812;
        label987: str5 = this.uiReformer.browseVideoDetailsModel.imageUrl;
        break label831;
        label1002: str6 = this.uiReformer.browseVideoDetailsModel.imageUrl;
        break label850;
        label1017: str7 = this.uiReformer.browseVideoDetailsModel.tpcDescribe;
        break label869;
        str8 = this.uiReformer.browseVideoDetailsModel.tpcTitle;
        break label888;
      }
      label1062: if (i == R.id.video_play_btn)
      {
        CompDeviceInfoUtils.applyPermission(new BrowseVideoDetailsActivity.2(this), this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
        continue;
      }
      if (i != R.id.downLoadLayout)
        continue;
      if (BrowseSharePreference.getFirVideoCacheTip())
      {
        checkNetAndCacheVideo();
        continue;
      }
      showCacheTipDialog();
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.loader_icon.setVisibility(8);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.loader_icon.setVisibility(8);
    if ((paramT instanceof BrowseVideoDetailsReformer))
    {
      if (StringUtils.isNull(this.strImgUrl))
        onAnimFinish();
      this.uiReformer = ((BrowseVideoDetailsReformer)paramT);
      setPageData(null, this.uiReformer.browseVideoDetailsModel);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    String str1;
    String str2;
    label41: BrowseVideoListReformer localBrowseVideoListReformer;
    if (getIntent() != null)
    {
      str1 = getIntent().getStringExtra("tpc.id");
      this.strTopicId = str1;
      if (getIntent() == null)
        break label135;
      str2 = getIntent().getStringExtra("video.img");
      this.strImgUrl = str2;
      if (getIntent() == null)
        break label142;
      localBrowseVideoListReformer = (BrowseVideoListReformer)getIntent().getSerializableExtra("video.list.reformer");
      label68: this.bReformer = localBrowseVideoListReformer;
      if (getIntent() == null)
        break label148;
    }
    label135: label142: label148: for (String str3 = getIntent().getStringExtra("id"); ; str3 = "")
    {
      if (StringUtils.isNull(str3))
        str3 = this.strTopicId;
      this.strTopicId = str3;
      if (!StringUtils.isNull(this.strTopicId))
        break label156;
      finish();
      return;
      str1 = "";
      break;
      str2 = "";
      break label41;
      localBrowseVideoListReformer = null;
      break label68;
    }
    label156: if (checkScreenRatio());
    for (int i = R.layout.browse_video_details_allscreen_scroll; ; i = R.layout.browse_video_details)
    {
      setContentView(i);
      EventBus.getDefault().register(this);
      GrowingIO.getInstance().setPageVariable(this, "page_name", "视频");
      initElements();
      if (this.bReformer != null)
        break;
      this.loader_icon.setVisibility(0);
      PresenterImpl localPresenterImpl = new PresenterImpl(this);
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.tpcId = this.strTopicId;
      localPresenterImpl.getVideoDet(localRequestModel, this);
      return;
    }
    BrowseEntity localBrowseEntity = (BrowseEntity)this.bReformer.lstWeekVideo.get(this.bReformer.curPlayIndex);
    new Handler().postDelayed(new BrowseVideoDetailsActivity.1(this, localBrowseEntity), 300L);
  }

  public void onAnimFinish()
  {
    if (this.details_frame_layout != null)
      this.details_frame_layout.setVisibility(0);
    if (this.bottom_bar != null)
      this.bottom_bar.setVisibility(0);
    if (this.bottom_line != null)
      this.bottom_line.setVisibility(0);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(CommentEvent paramCommentEvent)
  {
    if (paramCommentEvent == null)
      return;
    RTextView localRTextView = this.comment_btn;
    if (paramCommentEvent.commentNum > 0);
    for (int i = paramCommentEvent.commentNum; ; i = R.string.c_3_3)
    {
      localRTextView.setText(String.valueOf(i));
      return;
    }
  }

  @Subscribe
  public void onEventMainThread(VideoLikeEvent paramVideoLikeEvent)
  {
    if (paramVideoLikeEvent == null)
      break label4;
    label4: 
    do
      return;
    while (this.laud_btn == null);
    RTextViewHelper localRTextViewHelper = this.laud_btn.getHelper();
    int i;
    label31: int j;
    label59: RTextView localRTextView2;
    if (paramVideoLikeEvent.isLike)
    {
      i = R.mipmap.video_press_like_icon;
      localRTextViewHelper.setIconNormal(ContextCompat.getDrawable(this, i));
      RTextView localRTextView1 = this.laud_btn;
      if (!paramVideoLikeEvent.isLike)
        break label149;
      j = R.color.color_ff5630;
      localRTextView1.setTextColor(ContextCompat.getColor(this, j));
      localRTextView2 = this.laud_btn;
      if (!paramVideoLikeEvent.isLike)
        break label157;
    }
    String str2;
    label149: label157: for (String str1 = "press"; ; str1 = null)
    {
      localRTextView2.setTag(str1);
      str2 = String.valueOf(this.laud_btn.getText());
      if (StringUtils.isNull(str2))
        break;
      if (!paramVideoLikeEvent.isLike)
        break label184;
      if (!"喜欢".equals(str2))
        break label163;
      this.laud_btn.setText("1");
      return;
      i = R.mipmap.video_details_like_icon;
      break label31;
      j = R.color.color_313131;
      break label59;
    }
    label163: this.laud_btn.setText(String.valueOf(1 + Integer.valueOf(str2).intValue()));
    return;
    label184: if ((!"0".equals(str2)) && (!"喜欢".equals(str2)))
    {
      this.laud_btn.setText(String.valueOf(-1 + Integer.valueOf(str2).intValue()));
      RTextView localRTextView3 = this.laud_btn;
      if ("0".equals(String.valueOf(this.laud_btn.getText())));
      for (String str3 = "喜欢"; ; str3 = String.valueOf(this.laud_btn.getText()))
      {
        localRTextView3.setText(str3);
        return;
      }
    }
    this.laud_btn.setText("喜欢");
  }

  @Subscribe
  public void onEventMainThread(BrowseVideoListReformer paramBrowseVideoListReformer)
  {
    if ((paramBrowseVideoListReformer != null) && (paramBrowseVideoListReformer.lstWeekVideo != null) && (paramBrowseVideoListReformer.lstWeekVideo.size() > paramBrowseVideoListReformer.curPlayIndex))
    {
      this.bReformer.curPlayIndex = paramBrowseVideoListReformer.curPlayIndex;
      BrowseEntity localBrowseEntity = (BrowseEntity)paramBrowseVideoListReformer.lstWeekVideo.get(paramBrowseVideoListReformer.curPlayIndex);
      this.strTopicId = localBrowseEntity.tpcId;
      setPageData(localBrowseEntity, null);
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      closePage();
    return false;
  }

  public void showCacheTipDialog()
  {
    BrowseSharePreference.putFirVideoCacheTip();
    checkNetAndCacheVideo();
  }

  @Subscribe(threadMode=ThreadMode.MAIN)
  public void videoCacheProgress(VideoCacheProgressEvent paramVideoCacheProgressEvent)
  {
    if (paramVideoCacheProgressEvent.tpcId.equals(this.strTopicId));
    switch (paramVideoCacheProgressEvent.state)
    {
    default:
      return;
    case 1:
      this.downLoadState.setVisibility(0);
      VideoCacheManager.getInstance().updateProgress(this.strTopicId, paramVideoCacheProgressEvent.progress);
      this.downLoadState.setText(String.valueOf(paramVideoCacheProgressEvent.progress + "%"));
      this.downLoadLayout.setClickable(false);
      return;
    case 0:
      this.downLoadState.setVisibility(0);
      this.downLoadImg.setImageResource(R.mipmap.btn_download_grey);
      this.downLoadState.setText(R.string.b_56_2);
      this.downLoadLayout.setClickable(false);
      return;
    case 2:
    }
    ToastUtils.makeToast(BaseApplication.appliContext, getResources().getString(R.string.h_3_7_1));
    this.downLoadState.setVisibility(8);
    this.downLoadLayout.setClickable(true);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle12.browse.activity.BrowseVideoDetailsActivity
 * JD-Core Version:    0.6.0
 */