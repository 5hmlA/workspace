package com.sportq.fit.findpresenter;

import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.TrainFinishEvent;
import com.sportq.fit.common.event.TrainFinishPageFinishBtnClickEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DownLoadListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.GetuiDataModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.StageModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.reformer.BannerReformer;
import com.sportq.fit.common.reformer.CurriculumReformer;
import com.sportq.fit.common.reformer.PlanListReformer;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.reformer.VideoReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.supportlib.plandbinfo.GetPlanPresenterImpl;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import rx.Observable;
import rx.Subscriber;

public abstract class FindPresenter
  implements FindPresenterInterface
{
  protected ApiInterface apiInterface;
  FitInterfaceUtils.DownLoadListener downLoadListener;
  FitInterfaceUtils.UIInitListener view;

  // ERROR //
  private void uploadLocalTrainData(Context paramContext, DialogInterface paramDialogInterface, Map<String, ?> paramMap)
  {
    // Byte code:
    //   0: aload_3
    //   1: ifnonnull +12 -> 13
    //   4: invokestatic 30	org/greenrobot/eventbus/EventBus:getDefault	()Lorg/greenrobot/eventbus/EventBus;
    //   7: ldc 32
    //   9: invokevirtual 36	org/greenrobot/eventbus/EventBus:post	(Ljava/lang/Object;)V
    //   12: return
    //   13: aload_3
    //   14: invokeinterface 42 1 0
    //   19: ifnonnull +12 -> 31
    //   22: invokestatic 30	org/greenrobot/eventbus/EventBus:getDefault	()Lorg/greenrobot/eventbus/EventBus;
    //   25: ldc 32
    //   27: invokevirtual 36	org/greenrobot/eventbus/EventBus:post	(Ljava/lang/Object;)V
    //   30: return
    //   31: aload_3
    //   32: invokeinterface 42 1 0
    //   37: invokeinterface 48 1 0
    //   42: astore 4
    //   44: aload 4
    //   46: invokeinterface 54 1 0
    //   51: ifne +12 -> 63
    //   54: invokestatic 30	org/greenrobot/eventbus/EventBus:getDefault	()Lorg/greenrobot/eventbus/EventBus;
    //   57: ldc 32
    //   59: invokevirtual 36	org/greenrobot/eventbus/EventBus:post	(Ljava/lang/Object;)V
    //   62: return
    //   63: aload 4
    //   65: invokeinterface 58 1 0
    //   70: checkcast 60	java/lang/String
    //   73: astore 5
    //   75: new 62	com/google/gson/Gson
    //   78: dup
    //   79: invokespecial 63	com/google/gson/Gson:<init>	()V
    //   82: astore 6
    //   84: new 65	com/sportq/fit/findpresenter/FindPresenter$12
    //   87: dup
    //   88: aload_0
    //   89: invokespecial 68	com/sportq/fit/findpresenter/FindPresenter$12:<init>	(Lcom/sportq/fit/findpresenter/FindPresenter;)V
    //   92: invokevirtual 72	com/sportq/fit/findpresenter/FindPresenter$12:getType	()Ljava/lang/reflect/Type;
    //   95: astore 7
    //   97: aload 6
    //   99: aload_3
    //   100: aload 5
    //   102: invokeinterface 76 2 0
    //   107: invokevirtual 80	java/lang/Object:toString	()Ljava/lang/String;
    //   110: aload 7
    //   112: invokevirtual 84	com/google/gson/Gson:fromJson	(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;
    //   115: checkcast 86	com/sportq/fit/common/model/request/RequestModel
    //   118: astore 8
    //   120: aload 8
    //   122: getfield 90	com/sportq/fit/common/model/request/RequestModel:detailedData	Ljava/lang/String;
    //   125: astore 9
    //   127: new 92	org/json/JSONArray
    //   130: dup
    //   131: aload 9
    //   133: invokestatic 98	com/sportq/fit/common/utils/StringUtils:uncompress	(Ljava/lang/String;)Ljava/lang/String;
    //   136: invokespecial 101	org/json/JSONArray:<init>	(Ljava/lang/String;)V
    //   139: astore 10
    //   141: aload 8
    //   143: ldc 103
    //   145: putfield 90	com/sportq/fit/common/model/request/RequestModel:detailedData	Ljava/lang/String;
    //   148: aload 6
    //   150: aload 8
    //   152: invokevirtual 107	com/google/gson/Gson:toJson	(Ljava/lang/Object;)Ljava/lang/String;
    //   155: astore 11
    //   157: new 109	org/json/JSONObject
    //   160: dup
    //   161: aload 11
    //   163: invokespecial 110	org/json/JSONObject:<init>	(Ljava/lang/String;)V
    //   166: astore 12
    //   168: aload 12
    //   170: ldc 111
    //   172: aload 10
    //   174: invokevirtual 115	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   177: pop
    //   178: aload 12
    //   180: ldc 117
    //   182: invokevirtual 121	org/json/JSONObject:has	(Ljava/lang/String;)Z
    //   185: ifne +13 -> 198
    //   188: aload 12
    //   190: ldc 117
    //   192: ldc 103
    //   194: invokevirtual 115	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   197: pop
    //   198: new 86	com/sportq/fit/common/model/request/RequestModel
    //   201: dup
    //   202: invokespecial 122	com/sportq/fit/common/model/request/RequestModel:<init>	()V
    //   205: astore 15
    //   207: aload 12
    //   209: ifnull +16 -> 225
    //   212: aload 15
    //   214: aload 12
    //   216: invokevirtual 123	org/json/JSONObject:toString	()Ljava/lang/String;
    //   219: invokestatic 126	com/sportq/fit/common/utils/StringUtils:compress	(Ljava/lang/String;)Ljava/lang/String;
    //   222: putfield 129	com/sportq/fit/common/model/request/RequestModel:historyData	Ljava/lang/String;
    //   225: aload_0
    //   226: getfield 131	com/sportq/fit/findpresenter/FindPresenter:apiInterface	Lcom/sportq/fit/common/interfaces/api/ApiInterface;
    //   229: aload 15
    //   231: aload_1
    //   232: invokeinterface 137 3 0
    //   237: new 139	com/sportq/fit/findpresenter/FindPresenter$13
    //   240: dup
    //   241: aload_0
    //   242: aload 5
    //   244: aload_3
    //   245: aload_1
    //   246: aload_2
    //   247: invokespecial 142	com/sportq/fit/findpresenter/FindPresenter$13:<init>	(Lcom/sportq/fit/findpresenter/FindPresenter;Ljava/lang/String;Ljava/util/Map;Landroid/content/Context;Lcom/sportq/fit/common/interfaces/dialog/DialogInterface;)V
    //   250: invokevirtual 148	rx/Observable:subscribe	(Lrx/Subscriber;)Lrx/Subscription;
    //   253: pop
    //   254: return
    //   255: astore 19
    //   257: aload 19
    //   259: invokestatic 154	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   262: invokestatic 30	org/greenrobot/eventbus/EventBus:getDefault	()Lorg/greenrobot/eventbus/EventBus;
    //   265: ldc 32
    //   267: invokevirtual 36	org/greenrobot/eventbus/EventBus:post	(Ljava/lang/Object;)V
    //   270: return
    //   271: astore 13
    //   273: aload 13
    //   275: invokestatic 154	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   278: invokestatic 30	org/greenrobot/eventbus/EventBus:getDefault	()Lorg/greenrobot/eventbus/EventBus;
    //   281: ldc 32
    //   283: invokevirtual 36	org/greenrobot/eventbus/EventBus:post	(Ljava/lang/Object;)V
    //   286: return
    //   287: astore 17
    //   289: aload 17
    //   291: invokestatic 154	com/sportq/fit/common/utils/LogUtils:e	(Ljava/lang/Throwable;)V
    //   294: invokestatic 30	org/greenrobot/eventbus/EventBus:getDefault	()Lorg/greenrobot/eventbus/EventBus;
    //   297: ldc 32
    //   299: invokevirtual 36	org/greenrobot/eventbus/EventBus:post	(Ljava/lang/Object;)V
    //   302: return
    //   303: astore 13
    //   305: goto -32 -> 273
    //
    // Exception table:
    //   from	to	target	type
    //   127	141	255	java/lang/Exception
    //   157	168	271	java/lang/Exception
    //   212	225	287	java/lang/Exception
    //   168	198	303	java/lang/Exception
  }

  public ArrayList<ActionModel> actionPreview(PlanModel paramPlanModel)
  {
    if (paramPlanModel == null)
    {
      localArrayList = null;
      return localArrayList;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator1 = paramPlanModel.stageArray.iterator();
    while (localIterator1.hasNext())
    {
      Iterator localIterator2 = ((StageModel)localIterator1.next()).actionArray.iterator();
      while (localIterator2.hasNext())
      {
        ActionModel localActionModel = (ActionModel)localIterator2.next();
        if (!"0".equals(localActionModel.actionType))
          continue;
        localArrayList.add(localActionModel);
      }
    }
  }

  public boolean checkDownLoad(ArrayList<String> paramArrayList)
  {
    return false;
  }

  public void choiceSinPlan(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.choiceSinPlan(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        PlanListReformer localPlanListReformer = new PlanListReformer();
        localPlanListReformer.tag = "choiceSinPlan";
        if (FindPresenter.this.view != null)
          FindPresenter.this.view.getDataSuccess(localPlanListReformer);
      }
    });
  }

  public void colPlan(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public void distributionAction(Context paramContext, String paramString1, String paramString2, boolean paramBoolean, String paramString3)
  {
  }

  public boolean downLoadFile(ArrayList<String> paramArrayList, Context paramContext, String paramString1, String paramString2, DialogInterface paramDialogInterface, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    return false;
  }

  public void finishPlan(TrainFinishEvent paramTrainFinishEvent, boolean paramBoolean, Context paramContext)
  {
    PlanReformer localPlanReformer = paramTrainFinishEvent.planReformer;
    PlanModel localPlanModel1 = localPlanReformer._individualInfo;
    localPlanReformer.costTime = paramTrainFinishEvent.totalTime;
    localPlanReformer.costCalorie = getTotalConsumeKaluri(paramTrainFinishEvent.totalTime, localPlanModel1);
    RequestModel localRequestModel = new RequestModel();
    PlanModel localPlanModel2 = new PlanModel();
    String str1;
    label149: String str2;
    label200: ActionModel localActionModel1;
    ActionModel localActionModel2;
    StringBuilder localStringBuilder2;
    if ("2".equals(localPlanReformer._dataType))
    {
      localPlanModel2.planImageURL = localPlanModel1.planImageURL;
      localRequestModel.individualId = localPlanModel1.planId;
      localPlanModel2.planName = localPlanModel1.planName;
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = Integer.valueOf(1 + Integer.parseInt(localPlanModel1.finishSection));
      localPlanModel2.finishSection = String.format("第%d次", arrayOfObject1);
      if (!StringUtils.isNull(localPlanReformer._customDetailId))
        break label467;
      str1 = "";
      localRequestModel.customDetailId = str1;
      Object[] arrayOfObject2 = new Object[1];
      arrayOfObject2[0] = Float.valueOf(localPlanReformer.costCalorie);
      localRequestModel.calorie = String.format("%.0f", arrayOfObject2);
      str2 = "";
      Iterator localIterator = paramTrainFinishEvent.actionModeArray.iterator();
      if (!localIterator.hasNext())
        break label485;
      localActionModel1 = (ActionModel)localIterator.next();
      localActionModel2 = new ActionModel();
      localStringBuilder2 = new StringBuilder().append(localActionModel1.actionDuration);
      if (!localActionModel1.isSecond())
        break label477;
    }
    label467: label477: for (String str3 = "s"; ; str3 = "x")
    {
      localActionModel2.actionDuration = str3;
      localActionModel2.duration = localActionModel1.duration;
      localActionModel2.actionName = localActionModel1.actionName;
      localActionModel2.actionIndex = localActionModel1.actionIndex;
      localActionModel2.actionGroupIndex = localActionModel1.actionGroupIndex;
      localActionModel2.actionInGroupIndex = localActionModel1.actionInGroupIndex;
      localActionModel2.trainDuration = StringUtils.timeFloat2Str(localActionModel1.duration);
      if (!localActionModel1.isStage())
      {
        StageModel localStageModel = (StageModel)localPlanModel1.stageArray.get(localActionModel2.actionGroupIndex);
        localStageModel.duration = (int)(localStageModel.duration + localActionModel2.duration);
        ((StageModel)localPlanModel1.stageArray.get(localActionModel2.actionGroupIndex)).actionArray.set(localActionModel2.actionInGroupIndex, localActionModel2);
      }
      if (!StringUtils.isNull(str2))
        break label200;
      str2 = localActionModel1.actionImageURL;
      localActionModel2.actionImageURL = str2;
      break label200;
      localRequestModel.planId = localPlanReformer._planInfo.planId;
      localPlanModel2.planImageURL = localPlanReformer._planInfo.planImageURL;
      break;
      str1 = localPlanReformer._customDetailId;
      break label149;
    }
    label485: localRequestModel.customDetailId = localPlanReformer._customDetailId;
    Gson localGson = new Gson();
    try
    {
      localRequestModel.detailedData = StringUtils.compress(new JSONArray(localGson.toJson(localPlanModel1.stageArray)).toString());
      LogUtils.d("FindPresenter", "detailedData:" + localRequestModel.detailedData);
      localRequestModel.time = String.valueOf(localPlanReformer.costTime);
      localRequestModel.moveTime = localPlanReformer.startDate;
      StringBuilder localStringBuilder1 = new StringBuilder();
      localStringBuilder1.append(DateUtils.getCurDateTime());
      localStringBuilder1.append(",");
      localStringBuilder1.append(CompDeviceInfoUtils.getNetType());
      localStringBuilder1.append(",");
      localStringBuilder1.append("[FOLAPCMT]");
      localStringBuilder1.append(",");
      localStringBuilder1.append(BaseApplication.strAPIName);
      localStringBuilder1.append(",");
      localStringBuilder1.append("p.c.tan|!||!||!|");
      localRequestModel.folap1 = localStringBuilder1.toString();
      localRequestModel.folap2 = StringUtils.getFixedField();
      localPlanModel2.stageArray = localPlanModel1.stageArray;
      if ((paramBoolean) && (CompDeviceInfoUtils.checkNetwork()))
      {
        Observable localObservable = this.apiInterface.finishPlan(localRequestModel, paramContext);
        7 local7 = new Subscriber(localRequestModel, paramContext, localPlanModel1)
        {
          public void onCompleted()
          {
          }

          public void onError(Throwable paramThrowable)
          {
            Object[] arrayOfObject = new Object[1];
            arrayOfObject[0] = paramThrowable.getMessage();
            String str = String.format("finishPlan%s", arrayOfObject);
            FindPresenter.this.saveTrainData(this.val$localRequestModel);
            LogUtils.d("FindPresenter", "保存训练数据到本地");
            if (FindPresenter.this.view != null)
              FindPresenter.this.view.getDataFail(str);
          }

          public void onNext(ResponseModel paramResponseModel)
          {
            try
            {
              new GetPlanPresenterImpl(this.val$context).deletUserStateInfo(this.val$planModel.planId);
              BannerReformer localBannerReformer = new BannerReformer();
              if (FindPresenter.this.view != null)
                FindPresenter.this.view.getDataSuccess(localBannerReformer);
              return;
            }
            catch (Exception localException)
            {
              while (true)
                LogUtils.e(localException);
            }
          }
        };
        localObservable.subscribe(local7);
        localPlanModel2.planTrainDuration = StringUtils.timeInt2Str(localPlanReformer.costTime);
        Object[] arrayOfObject3 = new Object[1];
        arrayOfObject3[0] = Float.valueOf(localPlanReformer.costCalorie);
        localPlanModel2.planKaluri = String.format("%.0f千卡", arrayOfObject3);
        localPlanModel2.planState = localPlanModel1.planState;
        localPlanModel2.shareImgUrl = localPlanModel1.shareImgUrl;
        if (this.view != null)
          this.view.getDataSuccess(localPlanModel2);
        return;
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        LogUtils.e(localException);
        continue;
        saveTrainData(localRequestModel);
      }
    }
  }

  public void geTuiNoticeClick(GetuiDataModel paramGetuiDataModel)
  {
  }

  public void getDiscoveryInfo(Context paramContext)
  {
  }

  public void getGrpWithClassifyId(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public void getPlanInfoWithPlanId(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.getPlanDet(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (FindPresenter.this.view != null)
          FindPresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        PlanReformer localPlanReformer = new PlanReformer();
        localPlanReformer.tag = "0";
        localPlanReformer.dataToPlanReformer(paramResponseModel);
        if (FindPresenter.this.view != null)
          FindPresenter.this.view.getDataSuccess(localPlanReformer);
      }
    });
  }

  public void getPlanProgressWithPlanId(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.getPlanList(paramRequestModel, paramContext).subscribe(new Subscriber(paramContext)
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        MiddleManager.getInstance().getFindPresenterImpl(FindPresenter.this.view, null).getSystemTime(this.val$context);
        PlanListReformer localPlanListReformer = new PlanListReformer();
        localPlanListReformer.dataToPlanListReformer(paramResponseModel);
        if (FindPresenter.this.view != null)
          FindPresenter.this.view.getDataSuccess(localPlanListReformer);
      }
    });
  }

  public void getReceiveMedalsSuccess(Context paramContext, FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.apiInterface.getReceiveMedalsSuccess(paramContext).subscribe(new Subscriber(paramUIInitListener)
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = paramThrowable.getMessage();
        String str = String.format("getReceiveMedalsSuccess%s", arrayOfObject);
        if (this.val$mView != null)
          this.val$mView.getDataFail(str);
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        PlanRecommendReformer localPlanRecommendReformer = new PlanRecommendReformer();
        localPlanRecommendReformer.dataToPlanRecommendReformer(paramResponseModel);
        if (FindPresenter.this.view != null)
          this.val$mView.getDataSuccess(localPlanRecommendReformer);
      }
    });
  }

  public void getReceiveMedalsSuccessAndShowMedal(Context paramContext)
  {
    this.apiInterface.getReceiveMedalsSuccess(paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = paramThrowable.getMessage();
        String str = String.format("getReceiveMedalsSuccess%s", arrayOfObject);
        if (FindPresenter.this.view != null)
          FindPresenter.this.view.getDataFail(str);
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        PlanRecommendReformer localPlanRecommendReformer = new PlanRecommendReformer();
        localPlanRecommendReformer.dataToPlanRecommendReformer(paramResponseModel);
        if (localPlanRecommendReformer.medalArray == null)
          return;
        EventBus.getDefault().post(new TrainFinishPageFinishBtnClickEvent(localPlanRecommendReformer));
      }
    });
  }

  public float getSecondKaluri(PlanModel paramPlanModel)
  {
    if (paramPlanModel == null);
    float f;
    do
    {
      return 0.0F;
      f = StringUtils.string2Int(paramPlanModel.trainDuration);
    }
    while (0.0F == f);
    return StringUtils.string2Int(paramPlanModel.planKaluri.replace("大卡", "").replace("千卡", "")) / f;
  }

  public float getTotalConsumeKaluri(int paramInt, PlanModel paramPlanModel)
  {
    return paramInt * getSecondKaluri(paramPlanModel);
  }

  public void getTypeListWithTypeId(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public void getVideoURL(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.getUrl(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        VideoReformer localVideoReformer = new VideoReformer();
        localVideoReformer.dataToVideoReformer(paramResponseModel);
        localVideoReformer.tag = "4";
        if (FindPresenter.this.view != null)
          FindPresenter.this.view.getDataSuccess(localVideoReformer);
      }
    });
  }

  public void joinPlan(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.joinPlan(paramRequestModel, paramContext).subscribe(new Subscriber(paramRequestModel)
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        PlanRecommendReformer localPlanRecommendReformer = new PlanRecommendReformer();
        localPlanRecommendReformer.dataToPlanRecommendReformer(paramResponseModel);
        if ("1".equals(this.val$requestModel.flg));
        for (String str = "8"; ; str = "1")
        {
          localPlanRecommendReformer.tag = str;
          if (FindPresenter.this.view != null)
            FindPresenter.this.view.getDataSuccess(localPlanRecommendReformer);
          return;
        }
      }
    });
  }

  public void onStopDownLoad()
  {
  }

  public void puseDownload(ArrayList<String> paramArrayList, Context paramContext, String paramString1, String paramString2, DialogInterface paramDialogInterface, String paramString3, String paramString4, String paramString5)
  {
  }

  public void saveTrainData(RequestModel paramRequestModel)
  {
    Gson localGson = new Gson();
    PreferencesTools.saveValueToTable("tbl_train_data", String.valueOf(System.currentTimeMillis()), localGson.toJson(paramRequestModel));
  }

  public void sereenCurriculumInfo(CurriculumReformer paramCurriculumReformer, Context paramContext)
  {
    RequestModel localRequestModel = new RequestModel();
    if (paramCurriculumReformer != null)
    {
      paramCurriculumReformer._isFirstTime = false;
      localRequestModel.flg = "1";
      localRequestModel.part = ((String)paramCurriculumReformer._screenDic.get("0"));
      localRequestModel.apparatus = ((String)paramCurriculumReformer._screenDic.get("1"));
      localRequestModel.dfficultyLevel = ((String)paramCurriculumReformer._screenDic.get("2"));
      localRequestModel.goal = ((String)paramCurriculumReformer._screenDic.get("3"));
      localRequestModel.sortCode = ((String)paramCurriculumReformer._screenDic.get("4"));
    }
    while (true)
    {
      CurriculumReformer localCurriculumReformer = paramCurriculumReformer;
      this.apiInterface.getSelPlan(localRequestModel, paramContext).subscribe(new Subscriber(paramContext, localCurriculumReformer, localRequestModel)
      {
        public void onCompleted()
        {
        }

        public void onError(Throwable paramThrowable)
        {
        }

        public void onNext(ResponseModel paramResponseModel)
        {
          MiddleManager.getInstance().getFindPresenterImpl(FindPresenter.this.view, null).getSystemTime(this.val$context);
          this.val$mReformer.dataToCurriculumInfoReformer(paramResponseModel);
          CurriculumReformer localCurriculumReformer = this.val$mReformer;
          if ("0".equals(this.val$requestModel.flg));
          for (String str = "first.load"; ; str = "")
          {
            localCurriculumReformer.tag = str;
            if (FindPresenter.this.view != null)
              FindPresenter.this.view.getDataSuccess(this.val$mReformer);
            return;
          }
        }
      });
      return;
      paramCurriculumReformer = new CurriculumReformer();
      paramCurriculumReformer._isFirstTime = true;
      localRequestModel.flg = "0";
    }
  }

  public void setFindPresenter(FitInterfaceUtils.UIInitListener paramUIInitListener, FitInterfaceUtils.DownLoadListener paramDownLoadListener, ApiInterface paramApiInterface)
  {
    this.view = paramUIInitListener;
    this.downLoadListener = paramDownLoadListener;
    this.apiInterface = paramApiInterface;
  }

  public void socialShare(Context paramContext, RequestModel paramRequestModel)
  {
    this.apiInterface.socialShare(paramContext, paramRequestModel).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        PlanRecommendReformer localPlanRecommendReformer = new PlanRecommendReformer();
        localPlanRecommendReformer.dataToPlanRecommendReformer(paramResponseModel);
        if (FindPresenter.this.view != null)
          FindPresenter.this.view.getDataSuccess(localPlanRecommendReformer);
      }
    });
  }

  public void startPlan(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.startPlan(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        PlanReformer localPlanReformer = new PlanReformer();
        localPlanReformer.tag = "2";
        localPlanReformer.restTime = paramResponseModel.restTime;
        localPlanReformer.message = paramResponseModel.message;
        if (FindPresenter.this.view != null)
          FindPresenter.this.view.getDataSuccess(localPlanReformer);
      }
    });
  }

  public void statsTrainFinishFeedBackBtn(String paramString1, String paramString2, String paramString3)
  {
  }

  public void statsTrainInfoMoreFeedBackBtn(String paramString1, String paramString2, String paramString3)
  {
  }

  public void statsTrainListMoreFeedBackBtn(String paramString)
  {
  }

  public void trainInfoAction(String paramString, PlanReformer paramPlanReformer)
  {
  }

  public void uploadLocalTrainData(Context paramContext, DialogInterface paramDialogInterface)
  {
    uploadLocalTrainData(paramContext, paramDialogInterface, PreferencesTools.getValueFromTable("tbl_train_data"));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.findpresenter.FindPresenter
 * JD-Core Version:    0.6.0
 */