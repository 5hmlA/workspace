package com.sportq.fit.findpresenter;

import android.content.Context;
import android.graphics.Bitmap;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import rx.Observable;
import rx.Subscriber;

public class FindPresenter1 extends FindPresenter
{
  public void addTrainPhoto(String paramString1, String paramString2, String paramString3, Context paramContext)
  {
    if (StringUtils.isNull(paramString1))
      if (this.view != null)
        this.view.getDataFail(null);
    RequestModel localRequestModel;
    Bitmap localBitmap;
    while (true)
    {
      return;
      if ((StringUtils.isNull(paramString2)) || (StringUtils.isNull(paramString3)) || ("-1".equals(paramString3)))
      {
        if (this.view == null)
          continue;
        this.view.getDataFail(null);
        return;
      }
      localRequestModel = new RequestModel();
      localBitmap = ImageUtils.getImageBitmap(paramString3, 2);
      if (localBitmap != null)
        break;
      if (this.view == null)
        continue;
      this.view.getDataFail("健身图片获取异常");
      return;
    }
    localRequestModel.imageURL = QiniuManager.uploadData(localBitmap);
    localRequestModel.moveTime = paramString1;
    localRequestModel.comment = paramString2;
    this.apiInterface.addTrainPhoto(localRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (FindPresenter1.this.view != null)
          FindPresenter1.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (FindPresenter1.this.view != null)
          FindPresenter1.this.view.getDataSuccess("");
      }
    });
  }

  public void getMission(Context paramContext)
  {
  }

  public void getMissionDet(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public void getMissionPlan(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public void getPoster(Context paramContext)
  {
  }

  public void getRelatedCourses(String paramString, Context paramContext)
  {
  }

  public void getSystemTime(Context paramContext)
  {
  }

  public void getWinners(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public boolean gradeToast(Context paramContext)
  {
    if (!Constant.STR_1.equals(CompDeviceInfoUtils.getAPNType(paramContext)));
    String str;
    do
    {
      do
        return false;
      while ("1".equals(BaseApplication.userModel.giveCommentVip));
      str = SharePreferenceUtils.getHaveCommentTime(paramContext);
    }
    while (((!StringUtils.isNull(str)) && (DateUtils.getChaNowDate2(str) <= 3)) || (StringUtils.string2Int(SharePreferenceUtils.getHaveCommentCount(paramContext)) >= 3));
    return true;
  }

  public void gradeToastClick(Context paramContext, String paramString)
  {
    if (Constant.STR_0.equals(paramString))
    {
      String str = SharePreferenceUtils.getHaveCommentCount(paramContext);
      if (StringUtils.isNull(str))
        str = "0";
      SharePreferenceUtils.putHaveCommentCount(paramContext, 1 + Integer.valueOf(str).intValue() + "");
      SharePreferenceUtils.putHaveCommentTime(paramContext, DateUtils.getCurDate());
      return;
    }
    SharePreferenceUtils.putIsShowComment(BaseApplication.userModel.userId, "0");
  }

  public void joinMission(RequestModel paramRequestModel, Context paramContext)
  {
    if (StringUtils.isNull(paramRequestModel.missionId))
    {
      if (this.view != null)
        this.view.getDataFail(null);
      return;
    }
    this.apiInterface.joinMission(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (FindPresenter1.this.view != null)
          FindPresenter1.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (FindPresenter1.this.view != null)
          FindPresenter1.this.view.getDataSuccess("Y");
      }
    });
  }

  public boolean noticeToast(Context paramContext)
  {
    if ((BaseApplication.userModel == null) || (StringUtils.isNull(BaseApplication.userModel.userId)))
      return false;
    return StringUtils.isNull(SharePreferenceUtils.getNoticeToastIs(paramContext));
  }

  public void noticeToastClick(Context paramContext)
  {
    SharePreferenceUtils.putNoticeToastIs(paramContext);
  }

  public void statsCustomizedExit(String paramString)
  {
  }

  public void statsPlanRelatedCoursesClick(String paramString)
  {
  }

  public void statsPlanRelatedCoursesClick02(String paramString)
  {
  }

  public void statsPublishFinishBtnClick(String paramString1, String paramString2)
  {
  }

  public void statsRecommendItemClick(String paramString)
  {
  }

  public void statsRelatedCoursesItemClick(String paramString)
  {
  }

  public void statsSaveLocalClick()
  {
  }

  public void statsSingleRelatedCoursesClick(String paramString)
  {
  }

  public void statsTakePhotoPermission(String paramString1, String paramString2)
  {
  }

  public void statsTrainFinishCameraClick(String paramString)
  {
  }

  public void statsTrainInfoImgClick(String paramString)
  {
  }

  public void statsTrainInfoMoreDeleteClick(String paramString)
  {
  }

  public void statsTrainRecordAlbumClick(String paramString)
  {
  }

  public void statsVideoDownLoadFinish(String paramString1, String paramString2, String paramString3)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.findpresenter.FindPresenter1
 * JD-Core Version:    0.6.0
 */