package com.sportq.fit.findpresenter;

import com.sportq.fit.common.interfaces.presenter.find.FindPagePresenterInterface;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.StageModel;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.reformer.TrainingReformer;
import com.sportq.fit.common.utils.StringUtils;
import java.util.ArrayList;

public class FindPagePresenter
  implements FindPagePresenterInterface
{
  public void getCurrentStageAndActionModel(TrainingReformer paramTrainingReformer)
  {
    paramTrainingReformer.currentStageModel = ((StageModel)paramTrainingReformer.stageArr.get(paramTrainingReformer.curGrpIndex));
    paramTrainingReformer.currentActionModel = ((ActionModel)paramTrainingReformer.currentStageModel.actionArray.get(paramTrainingReformer.curIndex));
  }

  public boolean lastActionEvent(TrainingReformer paramTrainingReformer)
  {
    if (paramTrainingReformer.curIndex > 0)
    {
      paramTrainingReformer.curIndex = (-1 + paramTrainingReformer.curIndex);
      paramTrainingReformer.nextBtnAlpha = 1.0F;
      if (StringUtils.isNull(paramTrainingReformer.currentActionModel.actionNameUp));
      for (paramTrainingReformer.lastBtnAlpha = 1.0F; ; paramTrainingReformer.lastBtnAlpha = 0.0F)
        return true;
    }
    return false;
  }

  public boolean nextActionEvent(TrainingReformer paramTrainingReformer)
  {
    int i;
    float f1;
    if (paramTrainingReformer.curIndex == -1 + paramTrainingReformer.currentStageModel.actionArray.size())
      if (paramTrainingReformer.curGrpIndex < -1 + paramTrainingReformer.stageArr.size())
      {
        paramTrainingReformer.curGrpIndex = (1 + paramTrainingReformer.curGrpIndex);
        paramTrainingReformer.curIndex = 0;
        i = 1;
        if (!paramTrainingReformer.clearFlg)
          break label111;
        f1 = 0.0F;
      }
    while (true)
    {
      paramTrainingReformer.lastBtnAlpha = f1;
      if (1 + paramTrainingReformer.currentActionModel.actionIndex != -1 + paramTrainingReformer.actionNumber)
        break label116;
      paramTrainingReformer.nextBtnAlpha = 0.0F;
      return i;
      i = 0;
      break;
      paramTrainingReformer.curIndex = (1 + paramTrainingReformer.curIndex);
      i = 1;
      break;
      label111: f1 = 1.0F;
    }
    label116: if (!StringUtils.isNull(paramTrainingReformer.currentActionModel.actionNameDown))
    {
      boolean bool = paramTrainingReformer.clearFlg;
      float f2 = 0.0F;
      if (bool);
      while (true)
      {
        paramTrainingReformer.nextBtnAlpha = f2;
        return i;
        f2 = 1.0F;
      }
    }
    paramTrainingReformer.nextBtnAlpha = 0.0F;
    return i;
  }

  public TrainingReformer planReformerToTrainingReformer(PlanReformer paramPlanReformer)
  {
    TrainingReformer localTrainingReformer = new TrainingReformer();
    localTrainingReformer.planReformerToTrainingReformer(paramPlanReformer);
    localTrainingReformer.btnsHideEnable = true;
    localTrainingReformer.autorotateFlg = true;
    return localTrainingReformer;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.findpresenter.FindPagePresenter
 * JD-Core Version:    0.6.0
 */