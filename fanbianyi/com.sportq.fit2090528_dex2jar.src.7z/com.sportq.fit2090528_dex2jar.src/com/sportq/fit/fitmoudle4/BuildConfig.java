package com.sportq.fit.fitmoudle4;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "com.sportq.fit.fitmoudle4";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = 30;
  public static final String VERSION_NAME = "4.4.0";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.BuildConfig
 * JD-Core Version:    0.6.0
 */