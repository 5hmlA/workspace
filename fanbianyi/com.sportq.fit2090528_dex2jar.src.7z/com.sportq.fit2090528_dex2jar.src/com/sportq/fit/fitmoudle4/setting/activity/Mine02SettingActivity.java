package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.event.EnergyInvitSuccess;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.StoreCommentReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.ReminderDialog;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.fitmoudle4.setting.common.SettingSharePreferenceUtils;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Mine02SettingActivity extends BaseActivity
{
  RTextView account_manager_btn;
  private boolean isClickComment = false;
  private boolean isToComment = false;
  FrameLayout mineSetAbout;
  FrameLayout mineSetAccount;
  FrameLayout mineSetCache;
  FrameLayout mineSetFitnessGoals;
  private TextView mineSetFitnessSex;
  FrameLayout mineSetFitnessVideo;
  FrameLayout mineSetHighPraise;
  FrameLayout mineSetNotice;
  FrameLayout mineSetPersonalData;
  RTextView qq_group_layout;
  private TextView to_comment_hint;
  CustomToolBar toolbar;

  private void init()
  {
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.mineSetPersonalData = ((FrameLayout)findViewById(R.id.mine_set_personal_data));
    this.mineSetAccount = ((FrameLayout)findViewById(R.id.mine_set_account));
    this.account_manager_btn = ((RTextView)findViewById(R.id.account_manager_btn));
    this.mineSetFitnessGoals = ((FrameLayout)findViewById(R.id.mine_set_fitness_goals));
    this.mineSetFitnessVideo = ((FrameLayout)findViewById(R.id.mine_set_fitness_video));
    this.mineSetFitnessSex = ((TextView)findViewById(R.id.mine_set_fitness_sex));
    this.mineSetNotice = ((FrameLayout)findViewById(R.id.mine_set_notice));
    this.mineSetCache = ((FrameLayout)findViewById(R.id.mine_cache_manager));
    this.mineSetAbout = ((FrameLayout)findViewById(R.id.mine_set_about));
    this.mineSetHighPraise = ((FrameLayout)findViewById(R.id.mine_set_high_praise));
    this.to_comment_hint = ((TextView)findViewById(R.id.to_comment_hint));
    this.qq_group_layout = ((RTextView)findViewById(R.id.qq_group_layout));
    this.dialog = new DialogManager();
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(R.string.mine_setting);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    this.mineSetPersonalData.setOnClickListener(new FitAction(this));
    this.mineSetAccount.setOnClickListener(new FitAction(this));
    this.mineSetFitnessGoals.setOnClickListener(new FitAction(this));
    String str1 = BaseApplication.userModel.coachSexf;
    TextView localTextView1 = this.mineSetFitnessSex;
    String str2;
    String str3;
    label432: RTextViewHelper localRTextViewHelper;
    if ("0".equals(str1))
    {
      str2 = getString(R.string.male);
      localTextView1.setText(str2);
      this.mineSetFitnessVideo.setOnClickListener(new FitAction(this));
      this.mineSetNotice.setOnClickListener(new FitAction(this));
      this.mineSetCache.setOnClickListener(new FitAction(this));
      this.mineSetAbout.setOnClickListener(new FitAction(this));
      this.mineSetHighPraise.setOnClickListener(new FitAction(this));
      TextView localTextView2 = this.to_comment_hint;
      if (!"0".equals(BaseApplication.userModel.giveCommentVip))
        break label498;
      str3 = getString(R.string.c_7_1_1);
      localTextView2.setText(str3);
      this.qq_group_layout.setOnClickListener(new FitAction(this));
      localRTextViewHelper = this.account_manager_btn.getHelper();
      if (!SettingSharePreferenceUtils.getAccountBindPoint())
        break label505;
    }
    label498: label505: for (Drawable localDrawable = ContextCompat.getDrawable(this, R.mipmap.comm_icon_red); ; localDrawable = null)
    {
      localRTextViewHelper.setIconNormal(localDrawable);
      return;
      str2 = getString(R.string.female);
      break;
      str3 = "";
      break label432;
    }
  }

  public void fitOnClick(View paramView)
  {
    this.isClickComment = false;
    if (R.id.mine_set_personal_data == paramView.getId())
    {
      startActivity(new Intent(this, Mine03PersonalActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
    }
    do
    {
      return;
      if (R.id.mine_set_account == paramView.getId())
      {
        this.account_manager_btn.getHelper().setIconNormal(null);
        SettingSharePreferenceUtils.putAccountBindPoint(false);
        startActivity(new Intent(this, Mine03AccountActivity.class));
        AnimationUtil.pageJumpAnim(this, 0);
        return;
      }
      if (R.id.mine_set_fitness_goals == paramView.getId())
      {
        startActivity(new Intent(this, Mine03FitnessGoalsActivity.class));
        AnimationUtil.pageJumpAnim(this, 0);
        return;
      }
      if (R.id.mine_set_fitness_video == paramView.getId())
      {
        startActivityForResult(new Intent(this, Mine03FitnessVideoActivity.class), 8385);
        AnimationUtil.pageJumpAnim(this, 0);
        return;
      }
      if (R.id.mine_set_notice == paramView.getId())
      {
        CompDeviceInfoUtils.applyPermission(new Mine02SettingActivity.2(this), this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
        return;
      }
      if (R.id.mine_cache_manager == paramView.getId())
      {
        CompDeviceInfoUtils.applyPermission(new Mine02SettingActivity.3(this), this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
        return;
      }
      if (R.id.mine_set_about == paramView.getId())
      {
        startActivity(new Intent(this, Mine04AboutActivity.class));
        AnimationUtil.pageJumpAnim(this, 0);
        return;
      }
      if (R.id.mine_set_high_praise != paramView.getId())
        continue;
      this.isClickComment = true;
      Intent localIntent2 = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getPackageName()));
      try
      {
        startActivity(localIntent2);
        AnimationUtil.pageJumpAnim(this, 0);
        return;
      }
      catch (Exception localException2)
      {
        LogUtils.e(localException2);
        return;
      }
    }
    while (R.id.qq_group_layout != paramView.getId());
    Intent localIntent1 = new Intent();
    localIntent1.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3DFoAaXV0qfNw_igz5EJBRu9yVJpzlWmQ4"));
    try
    {
      startActivity(localIntent1);
      return;
    }
    catch (Exception localException1)
    {
      ToastUtils.makeToast(this, getString(R.string.not_installed_applications));
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof StoreCommentReformer))
    {
      if ("Y".equals(((StoreCommentReformer)paramT).result))
      {
        MiddleManager.getInstance().getMinePresenterImpl(this).getUserInfo(this);
        new ReminderDialog(this).createDialog().setPopupMainTitleText("获得3天VIP会员").setPopupTitleText("感谢对Fit的鼓励，已获得3天VIP会员").setImageRes(R.mipmap.icon_big_vip).setButtonText("去看看").setButtonLayoutOnClick(new Mine02SettingActivity.1(this));
      }
      this.to_comment_hint.setVisibility(8);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine02_setting);
    EventBus.getDefault().register(this);
    init();
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramIntent == null);
    do
      return;
    while ((StringUtils.isNull(paramIntent.getStringExtra("sex"))) || (paramInt1 != 8385));
    this.mineSetFitnessSex.setText(paramIntent.getStringExtra("sex"));
    EventBus.getDefault().post("修改课程教练");
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(EnergyInvitSuccess paramEnergyInvitSuccess)
  {
    if (paramEnergyInvitSuccess != null)
      finish();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("sign.out.account".equals(paramString))
      finish();
    if ("change.api".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  protected void onResume()
  {
    if (Constant.share_state)
    {
      Constant.share_state = false;
      this.dialog.closeDialog();
    }
    if (this.isToComment)
    {
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.commentFlag = "0";
      MiddleManager.getInstance().getMinePresenterImpl(this).storeComment(this, localRequestModel);
    }
    super.onResume();
  }

  protected void onStop()
  {
    super.onStop();
    if (this.isClickComment)
      this.isToComment = true;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine02SettingActivity
 * JD-Core Version:    0.6.0
 */