package com.sportq.fit.fitmoudle4.setting.activity;

import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;

class Mine03PersonalActivity$4
  implements CompDeviceInfoUtils.applyPerListener
{
  public void result(boolean paramBoolean)
  {
    if (paramBoolean)
      Mine03PersonalActivity.access$300(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity.4
 * JD-Core Version:    0.6.0
 */