package com.sportq.fit.fitmoudle4.setting.common;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;

public class SettingSharePreferenceUtils
{
  public static final String ACCOUNT_BIND_POINT = "account.bind.point";

  public static boolean getAccountBindPoint()
  {
    if (!"8".equals(BaseApplication.userModel.terrace))
      return false;
    return BaseApplication.appliContext.getSharedPreferences("account.bind.point", 0).getBoolean(BaseApplication.userModel.userId, true);
  }

  public static boolean putAccountBindPoint(boolean paramBoolean)
  {
    if (!"8".equals(BaseApplication.userModel.terrace))
      return true;
    SharedPreferences.Editor localEditor = BaseApplication.appliContext.getSharedPreferences("account.bind.point", 0).edit();
    localEditor.putBoolean(BaseApplication.userModel.userId, paramBoolean);
    return localEditor.commit();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.common.SettingSharePreferenceUtils
 * JD-Core Version:    0.6.0
 */