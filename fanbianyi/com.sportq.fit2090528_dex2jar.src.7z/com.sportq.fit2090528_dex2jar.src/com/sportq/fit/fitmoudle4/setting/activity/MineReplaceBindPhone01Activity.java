package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.LoginPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.network.presenter.impl.PresenterImpl;
import com.sportq.fit.fitmoudle.network.reformer.NeceDataUIReformer;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.middlelib.MiddleManager;
import java.util.concurrent.TimeUnit;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class MineReplaceBindPhone01Activity extends BaseActivity
{
  private RTextView confirm_btn;
  private RTextView get_verification_code;
  private TextView original_phone;
  private RTextViewHelper rTextViewHelper;
  private RTextViewHelper rTextViewHelper02;
  private Subscription subscription;
  CustomToolBar toolbar;
  private EditText verification_code;

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.get_verification_code)
    {
      this.dialog.createProgressDialog(this, StringUtils.getStringResources(R.string.wait_hint));
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = BaseApplication.userModel.phoneNumber;
      new PresenterImpl(this).getNeceData(localRequestModel, this);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() == R.id.phone_lose)
      {
        this.dialog.createChoiceDialog(new MineReplaceBindPhone01Activity.2(this), this, getString(R.string.c_48_3), "通过原手机号和密码通过安全验证", "确定", "取消");
        continue;
      }
      if (paramView.getId() != R.id.confirm_btn)
        continue;
      this.dialog.createProgressDialog(this, StringUtils.getStringResources(R.string.wait_hint));
      MiddleManager.getInstance().getLoginPresenterImpl(this).postCheckVerification(BaseApplication.userModel.phoneNumber, this.verification_code.getText().toString(), this);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, (String)paramT);
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof NeceDataUIReformer))
    {
      String str = ((NeceDataUIReformer)paramT).timeKey;
      RequestModel localRequestModel = new RequestModel();
      localRequestModel.phoneNumber = BaseApplication.userModel.phoneNumber;
      localRequestModel.acquisitionMode = "3";
      localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(str + NdkUtils.getSignBaseUrl()).toUpperCase();
      MiddleManager.getInstance().getLoginPresenterImpl(this).getVerification(localRequestModel, this);
    }
    while (true)
    {
      super.getDataSuccess(paramT);
      return;
      if (!(paramT instanceof LoginReformer))
        continue;
      this.dialog.closeDialog();
      LoginReformer localLoginReformer = (LoginReformer)paramT;
      if ("0".equals(localLoginReformer.tag))
      {
        startTimeCountdown();
        continue;
      }
      if (!"1".equals(localLoginReformer.tag))
        continue;
      Intent localIntent = new Intent(this, MineAddPhoneActivity.class);
      localIntent.putExtra("page.type", "1");
      startActivity(localIntent);
      finish();
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine_replace_phone_layout01);
    this.dialog = new DialogManager();
    EventBus.getDefault().register(this);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.original_phone = ((TextView)findViewById(R.id.original_phone));
    this.get_verification_code = ((RTextView)findViewById(R.id.get_verification_code));
    this.rTextViewHelper02 = this.get_verification_code.getHelper();
    this.verification_code = ((EditText)findViewById(R.id.verification_code));
    this.confirm_btn = ((RTextView)findViewById(R.id.confirm_btn));
    this.confirm_btn.setEnabled(false);
    this.rTextViewHelper = this.confirm_btn.getHelper();
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(getResources().getString(R.string.c_48_1));
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    this.original_phone.setText(BaseApplication.userModel.phoneNumber);
    TextUtils.onTextChange(new MineReplaceBindPhone01Activity.1(this), this.verification_code);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("close.bind01".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  public void startTimeCountdown()
  {
    this.get_verification_code.setText("60s");
    this.rTextViewHelper02.setTextColorNormal(ContextCompat.getColor(this, R.color.white));
    this.rTextViewHelper02.setBackgroundColorNormal(ContextCompat.getColor(this, R.color.color_c8c8c8));
    this.get_verification_code.setEnabled(false);
    this.subscription = Observable.interval(1L, TimeUnit.SECONDS).take(61).onBackpressureBuffer().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new MineReplaceBindPhone01Activity.3(this));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.MineReplaceBindPhone01Activity
 * JD-Core Version:    0.6.0
 */