package com.sportq.fit.fitmoudle4.setting.activity;

import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.common.utils.XUtilDB;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;

class Mine02SettingActivity$2
  implements CompDeviceInfoUtils.applyPerListener
{
  public void result(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      XUtilDB.getInstance();
      FitJumpImpl.getInstance().finishJumpSetNotice(this.this$0);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine02SettingActivity.2
 * JD-Core Version:    0.6.0
 */