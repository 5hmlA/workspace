package com.sportq.fit.fitmoudle4.setting.activity;

import android.widget.EditText;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.utils.ToastUtils;

class Mine03PersonalActivity$3
  implements FitInterfaceUtils.onTextChangeListener
{
  public void onChangeResult(String paramString)
  {
    if (paramString.length() > 32)
    {
      Mine03PersonalActivity.access$100(this.this$0).setText(paramString.substring(0, 32));
      Mine03PersonalActivity.access$100(this.this$0).setSelection(32);
      Mine03PersonalActivity.access$000(this.this$0).userName = paramString.substring(0, 32);
      ToastUtils.makeToast(this.this$0, "请输入3～32位字符，支持中英文、数字、“_”和“-”");
    }
    while (true)
    {
      Mine03PersonalActivity.access$200(this.this$0);
      return;
      Mine03PersonalActivity.access$000(this.this$0).userName = paramString;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity.3
 * JD-Core Version:    0.6.0
 */