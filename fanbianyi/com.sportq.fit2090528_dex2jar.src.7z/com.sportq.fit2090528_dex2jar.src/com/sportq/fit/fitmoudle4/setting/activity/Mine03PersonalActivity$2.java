package com.sportq.fit.fitmoudle4.setting.activity;

import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.EditText;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;

class Mine03PersonalActivity$2
  implements View.OnFocusChangeListener
{
  @Instrumented
  public void onFocusChange(View paramView, boolean paramBoolean)
  {
    VdsAgent.onFocusChange(this, paramView, paramBoolean);
    if (paramBoolean);
    String str;
    do
    {
      return;
      str = Mine03PersonalActivity.access$100(this.this$0).getText().toString();
    }
    while (StringUtils.checkName(str));
    Mine03PersonalActivity.access$000(this.this$0).userName = str;
    ToastUtils.makeToast(this.this$0, "请输入3～32位字符，支持中英文、数字、“_”和“-”");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity.2
 * JD-Core Version:    0.6.0
 */