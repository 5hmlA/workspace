package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import com.sportq.fit.common.utils.CompDeviceInfoUtils.applyPerListener;
import com.sportq.fit.fitmoudle.AnimationUtil;

class Mine02SettingActivity$3
  implements CompDeviceInfoUtils.applyPerListener
{
  public void result(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      Intent localIntent = new Intent(this.this$0, Mine03SetCacheActivity.class);
      this.this$0.startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this.this$0, 0);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine02SettingActivity.3
 * JD-Core Version:    0.6.0
 */