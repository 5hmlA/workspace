package com.sportq.fit.fitmoudle4.setting.eventbus;

public class MineAccountEventBus
{
  private String mMsg;

  public MineAccountEventBus(String paramString)
  {
    this.mMsg = paramString;
  }

  public String getMsg()
  {
    return this.mMsg;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.eventbus.MineAccountEventBus
 * JD-Core Version:    0.6.0
 */