package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.DialogInterface;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.reformer.WelcomeReformer;
import com.sportq.fit.common.utils.CustomerServiceUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.supportlib.CommonUtils;
import java.util.HashMap;
import org.greenrobot.eventbus.EventBus;

class Mine03AccountActivity$1
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -1)
    {
      FitJumpImpl.getInstance().exitRemoveTag(this.this$0);
      FitJumpImpl.getInstance().settingJumpVideoGuide(this.this$0);
      EventBus.getDefault().post("sign.out.account");
      new WelcomeReformer().deleteAllCacheData(this.this$0);
      SharePreferenceUtils.putWelcome(this.this$0, "");
      CustomerServiceUtils.logout();
      BaseApplication.requestModelCache.clear();
      BaseApplication.dataCache.clear();
      CommonUtils.deleteAllCache();
      SharePreferenceUtils.putLoginStatus(this.this$0, "exist.login");
      SharePreferenceUtils.putWechatUnionId(this.this$0, "");
      SharePreferenceUtils.putUnionid(this.this$0, "");
      SharePreferenceUtils.putQQtoken(this.this$0, "");
      MiddleManager.getInstance().getRegisterPresenterImpl(this.this$0).ssoRemoveAccount(this.this$0, "Wechat");
      MiddleManager.getInstance().getRegisterPresenterImpl(this.this$0).ssoRemoveAccount(this.this$0, "SinaWeibo");
      MiddleManager.getInstance().getRegisterPresenterImpl(this.this$0).ssoRemoveAccount(this.this$0, "QQ");
      MiddleManager.getInstance().getRegisterPresenterImpl(this.this$0).ssoRemoveAccount(this.this$0, "huawei");
      this.this$0.finish();
      MiddleManager.getInstance().getMinePresenterImpl(this.this$0).exitLogin(this.this$0);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03AccountActivity.1
 * JD-Core Version:    0.6.0
 */