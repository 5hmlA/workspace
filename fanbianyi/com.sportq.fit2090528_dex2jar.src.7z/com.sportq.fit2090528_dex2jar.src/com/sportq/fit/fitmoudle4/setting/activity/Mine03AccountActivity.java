package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.account.RegisterPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.ReceiveMedalEvent;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Mine03AccountActivity extends BaseActivity
{
  private ImageView accountPhoneIcon;
  private TextView accountPhoneNum;
  private TextView accountPhoneNumHint;
  private ImageView accountQqIcon;
  private Switch accountQqState;
  private ImageView accountSinaIcon;
  private Switch accountSinaState;
  private ImageView accountWeChatIcon;
  private Switch accountWeChatState;
  private TextView add_phone_hint;
  private FrameLayout mine03AccountPasswordL;
  private TextView mineAccountType;
  private TextView mine_password_state;
  private Boolean tellFlag = Boolean.valueOf(false);
  CustomToolBar toolbar;

  private static String changePhoneNum(String paramString)
  {
    return paramString.substring(0, 3) + "****" + paramString.substring(7, paramString.length());
  }

  private void checkShowMobilePhone()
  {
    if (!StringUtils.isNull(BaseApplication.userModel.phoneNumber))
    {
      this.accountPhoneIcon.setImageResource(R.mipmap.icon_phone);
      this.mine03AccountPasswordL.setVisibility(0);
      this.add_phone_hint.setVisibility(8);
      this.accountPhoneNum.setVisibility(0);
      this.accountPhoneNumHint.setText(getString(R.string.c_47_2));
      this.accountPhoneNum.setText(changePhoneNum(BaseApplication.userModel.phoneNumber));
      this.tellFlag = Boolean.valueOf(true);
    }
  }

  private void setLoginStatus()
  {
    int n;
    int i1;
    if ("8".equals(BaseApplication.userModel.loginTerrace))
    {
      TextView localTextView4 = this.mineAccountType;
      int m = R.string.c_42_25;
      String[] arrayOfString4 = new String[1];
      arrayOfString4[0] = getString(R.string.c_42_30);
      localTextView4.setText(UseStringUtils.getStr(m, arrayOfString4));
      this.mine03AccountPasswordL.setVisibility(0);
      this.add_phone_hint.setVisibility(8);
      this.accountPhoneNum.setVisibility(0);
      this.accountPhoneNumHint.setText(getString(R.string.c_47_2));
      this.accountPhoneNum.setText(changePhoneNum(BaseApplication.userModel.phoneNumber));
      this.tellFlag = Boolean.valueOf(true);
      this.accountPhoneIcon.setImageResource(R.mipmap.icon_phone);
      TextView localTextView5 = this.mine_password_state;
      if (StringUtils.isNull(BaseApplication.userModel.password))
      {
        n = R.string.c_14_1_1;
        localTextView5.setText(getString(n));
        TextView localTextView6 = this.mine_password_state;
        if (!StringUtils.isNull(BaseApplication.userModel.password))
          break label321;
        i1 = R.color.color_ff6a49;
        label184: localTextView6.setTextColor(ContextCompat.getColor(this, i1));
      }
    }
    while (true)
    {
      if (!StringUtils.isNull(BaseApplication.userModel.weiboUid))
      {
        this.accountSinaState.setChecked(true);
        this.accountSinaIcon.setTag("bind");
        this.accountSinaIcon.setImageResource(R.mipmap.mine_account_weibo_on);
      }
      if (!StringUtils.isNull(BaseApplication.userModel.weixinUid))
      {
        this.accountWeChatState.setChecked(true);
        this.accountWeChatIcon.setTag("bind");
        this.accountWeChatIcon.setImageResource(R.mipmap.mine_account_wechat_on);
      }
      if (!StringUtils.isNull(BaseApplication.userModel.qqUid))
      {
        this.accountQqState.setChecked(true);
        this.accountQqIcon.setTag("bind");
        this.accountQqIcon.setImageResource(R.mipmap.mine_account_qq_on);
      }
      return;
      n = R.string.c_47_4;
      break;
      label321: i1 = R.color.color_828282;
      break label184;
      if ("0".equals(BaseApplication.userModel.loginTerrace))
      {
        checkShowMobilePhone();
        TextView localTextView3 = this.mineAccountType;
        int k = R.string.c_42_25;
        String[] arrayOfString3 = new String[1];
        arrayOfString3[0] = getString(R.string.c_42_27);
        localTextView3.setText(UseStringUtils.getStr(k, arrayOfString3));
        continue;
      }
      if ("1".equals(BaseApplication.userModel.loginTerrace))
      {
        checkShowMobilePhone();
        TextView localTextView2 = this.mineAccountType;
        int j = R.string.c_42_25;
        String[] arrayOfString2 = new String[1];
        arrayOfString2[0] = getString(R.string.c_42_28);
        localTextView2.setText(UseStringUtils.getStr(j, arrayOfString2));
        continue;
      }
      if ("7".equals(BaseApplication.userModel.loginTerrace))
      {
        checkShowMobilePhone();
        TextView localTextView1 = this.mineAccountType;
        int i = R.string.c_42_25;
        String[] arrayOfString1 = new String[1];
        arrayOfString1[0] = getString(R.string.c_42_26);
        localTextView1.setText(UseStringUtils.getStr(i, arrayOfString1));
        continue;
      }
      if (!"11".equals(BaseApplication.userModel.loginTerrace))
        continue;
      checkShowMobilePhone();
      this.mineAccountType.setText(UseStringUtils.getStr(R.string.c_42_25, new String[] { "华为" }));
    }
  }

  public void fitOnClick(View paramView)
  {
    String str7;
    if (R.id.account_weChat_state == paramView.getId())
    {
      Constant.bind_state = true;
      String str6 = String.valueOf(this.accountWeChatIcon.getTag());
      this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
      RegisterPresenterInterface localRegisterPresenterInterface3 = MiddleManager.getInstance().getRegisterPresenterImpl(this);
      if (StringUtils.isNull(str6))
      {
        str7 = "1";
        localRegisterPresenterInterface3.registerAccountBind("7", str7, this);
      }
    }
    do
    {
      return;
      str7 = "2";
      break;
      if (R.id.account_sina_state == paramView.getId())
      {
        String str4 = String.valueOf(this.accountSinaIcon.getTag());
        this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
        RegisterPresenterInterface localRegisterPresenterInterface2 = MiddleManager.getInstance().getRegisterPresenterImpl(this);
        if (StringUtils.isNull(str4));
        for (String str5 = "1"; ; str5 = "2")
        {
          localRegisterPresenterInterface2.registerAccountBind("0", str5, this);
          return;
        }
      }
      if (R.id.account_qq_state == paramView.getId())
      {
        String str2 = String.valueOf(this.accountQqIcon.getTag());
        this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
        RegisterPresenterInterface localRegisterPresenterInterface1 = MiddleManager.getInstance().getRegisterPresenterImpl(this);
        if (StringUtils.isNull(str2));
        for (String str3 = "1"; ; str3 = "2")
        {
          localRegisterPresenterInterface1.registerAccountBind("1", str3, this);
          return;
        }
      }
      if (R.id.mine03_account_phone_l == paramView.getId())
      {
        Intent localIntent2;
        if (this.tellFlag.booleanValue())
          localIntent2 = new Intent(this, MineReplaceBindPhone01Activity.class);
        while (true)
        {
          startActivity(localIntent2);
          AnimationUtil.pageJumpAnim(this, 0);
          return;
          localIntent2 = new Intent(this, MineAddPhoneActivity.class);
          localIntent2.putExtra("page.type", "0");
        }
      }
      if (R.id.mine03_account_password_l != paramView.getId())
        continue;
      Intent localIntent1 = new Intent(this, MineAddPhoneActivity.class);
      if (StringUtils.isNull(BaseApplication.userModel.password));
      for (String str1 = "2"; ; str1 = "3")
      {
        localIntent1.putExtra("page.type", str1);
        startActivity(localIntent1);
        AnimationUtil.pageJumpAnim(this, 0);
        return;
      }
    }
    while (R.id.mine03_account_exit != paramView.getId());
    this.dialog.createChoiceDialog(new Mine03AccountActivity.1(this), this, "", getString(R.string.c_46_1));
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    if ("未安装微信".equals(paramT))
    {
      String str1 = BaseApplication.userModel.strBindStatus;
      this.accountWeChatState.setChecked("1".equals(str1));
      ImageView localImageView1 = this.accountWeChatIcon;
      int i;
      ImageView localImageView2;
      if ("1".equals(str1))
      {
        i = R.mipmap.mine_account_wechat_on;
        localImageView1.setImageResource(i);
        localImageView2 = this.accountWeChatIcon;
        if (!"1".equals(str1))
          break label99;
      }
      label99: for (String str2 = "bind"; ; str2 = "")
      {
        localImageView2.setTag(str2);
        return;
        i = R.mipmap.mine_account_wechat_off;
        break;
      }
    }
    if (String.valueOf(paramT).contains("SinaWeibo"))
    {
      this.accountSinaState.setChecked(false);
      return;
    }
    if (String.valueOf(paramT).contains("QQ"))
    {
      this.accountQqState.setChecked(false);
      return;
    }
    if (String.valueOf(paramT).contains("Wechat"))
    {
      this.accountWeChatState.setChecked(false);
      return;
    }
    ToastUtils.makeToast(this, getResources().getString(R.string.current_network_again_later));
  }

  public <T> void getDataSuccess(T paramT)
  {
    UserModel localUserModel;
    String str1;
    String str7;
    int i1;
    String str10;
    if ((paramT instanceof UserModel))
    {
      localUserModel = (UserModel)paramT;
      str1 = localUserModel.terrace;
      this.dialog.closeDialog();
      if ((StringUtils.isNull(localUserModel.tag)) || (!localUserModel.tag.contains(getString(R.string.bound))) || (!StringUtils.isNull(localUserModel.strBindStatus)))
        break label386;
      str7 = localUserModel.strBindStatus;
      ToastUtils.makeToast(this, getString(R.string.third_party_accounts_bound));
      if (!"1".equals(str1))
        break label189;
      this.accountQqState.setChecked("1".equals(str7));
      ImageView localImageView11 = this.accountQqIcon;
      if (!"1".equals(str7))
        break label173;
      i1 = R.mipmap.mine_account_qq_on;
      localImageView11.setImageResource(i1);
      ImageView localImageView12 = this.accountQqIcon;
      if (!"1".equals(str7))
        break label181;
      str10 = "bind";
      label151: localImageView12.setTag(str10);
      SharePreferenceUtils.putUnionid(this, "");
      SharePreferenceUtils.putQQtoken(this, "");
    }
    label173: label181: label189: 
    do
    {
      return;
      i1 = R.mipmap.mine_account_qq_off;
      break;
      str10 = "";
      break label151;
      if (!"0".equals(str1))
        continue;
      this.accountSinaState.setChecked("1".equals(str7));
      ImageView localImageView9 = this.accountSinaIcon;
      int n;
      ImageView localImageView10;
      if ("1".equals(str7))
      {
        n = R.mipmap.mine_account_weibo_on;
        localImageView9.setImageResource(n);
        localImageView10 = this.accountSinaIcon;
        if (!"1".equals(str7))
          break label276;
      }
      for (String str9 = "bind"; ; str9 = "")
      {
        localImageView10.setTag(str9);
        return;
        n = R.mipmap.mine_account_weibo_off;
        break;
      }
    }
    while (!"7".equals(str1));
    label276: this.accountWeChatState.setChecked("1".equals(str7));
    ImageView localImageView7 = this.accountWeChatIcon;
    int m;
    ImageView localImageView8;
    if ("1".equals(str7))
    {
      m = R.mipmap.mine_account_wechat_on;
      localImageView7.setImageResource(m);
      localImageView8 = this.accountWeChatIcon;
      if (!"1".equals(str7))
        break label378;
    }
    label378: for (String str8 = "bind"; ; str8 = "")
    {
      localImageView8.setTag(str8);
      SharePreferenceUtils.putWechatUnionId(this, "");
      return;
      m = R.mipmap.mine_account_wechat_off;
      break;
    }
    label386: String str2 = localUserModel.strBindStatus;
    int k;
    String str6;
    if ("1".equals(str1))
    {
      ImageView localImageView5 = this.accountQqIcon;
      if ("2".equals(str2))
      {
        k = R.mipmap.mine_account_qq_off;
        localImageView5.setImageResource(k);
        ImageView localImageView6 = this.accountQqIcon;
        if (!"1".equals(str2))
          break label511;
        str6 = "bind";
        label450: localImageView6.setTag(str6);
        if (!"1".equals(str2))
        {
          SharePreferenceUtils.putUnionid(this, "");
          SharePreferenceUtils.putQQtoken(this, "");
        }
        label481: if (!"1".equals(str2))
          break label718;
      }
    }
    label550: label710: label718: for (String str4 = "绑定成功"; ; str4 = "解除绑定成功")
    {
      ToastUtils.makeToast(this, str4);
      return;
      k = R.mipmap.mine_account_qq_on;
      break;
      label511: str6 = "";
      break label450;
      if ("0".equals(str1))
      {
        ImageView localImageView3 = this.accountSinaIcon;
        int j;
        ImageView localImageView4;
        if ("2".equals(str2))
        {
          j = R.mipmap.mine_account_weibo_off;
          localImageView3.setImageResource(j);
          localImageView4 = this.accountSinaIcon;
          if (!"1".equals(str2))
            break label595;
        }
        label595: for (String str5 = "bind"; ; str5 = "")
        {
          localImageView4.setTag(str5);
          break;
          j = R.mipmap.mine_account_weibo_on;
          break label550;
        }
      }
      if (!"7".equals(str1))
        break label481;
      ImageView localImageView1 = this.accountWeChatIcon;
      int i;
      label634: ImageView localImageView2;
      if ("2".equals(str2))
      {
        i = R.mipmap.mine_account_wechat_off;
        localImageView1.setImageResource(i);
        localImageView2 = this.accountWeChatIcon;
        if (!"1".equals(str2))
          break label710;
      }
      for (String str3 = "bind"; ; str3 = "")
      {
        localImageView2.setTag(str3);
        this.accountWeChatState.setChecked("1".equals(str2));
        if ("1".equals(str2))
          break;
        SharePreferenceUtils.putWechatUnionId(this, "");
        break;
        i = R.mipmap.mine_account_wechat_on;
        break label634;
      }
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine_account);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.mineAccountType = ((TextView)findViewById(R.id.login_mode));
    this.accountWeChatIcon = ((ImageView)findViewById(R.id.account_weChat_icon));
    this.accountWeChatState = ((Switch)findViewById(R.id.account_weChat_state));
    this.accountSinaIcon = ((ImageView)findViewById(R.id.account_sina_icon));
    this.accountSinaState = ((Switch)findViewById(R.id.account_sina_state));
    this.accountQqIcon = ((ImageView)findViewById(R.id.account_qq_icon));
    this.accountQqState = ((Switch)findViewById(R.id.account_qq_state));
    this.accountPhoneIcon = ((ImageView)findViewById(R.id.account_phone_icon));
    this.accountPhoneNum = ((TextView)findViewById(R.id.account_phone_num));
    this.accountPhoneNumHint = ((TextView)findViewById(R.id.account_phone_num_hint));
    this.mine03AccountPasswordL = ((FrameLayout)findViewById(R.id.mine03_account_password_l));
    this.mine_password_state = ((TextView)findViewById(R.id.mine_password_state));
    this.add_phone_hint = ((TextView)findViewById(R.id.add_phone_hint));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(R.string.c_34_3);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    if (!"7".equals(BaseApplication.userModel.loginTerrace))
    {
      this.accountWeChatState.setOnClickListener(new FitAction(this));
      if ("0".equals(BaseApplication.userModel.loginTerrace))
        break label395;
      this.accountSinaState.setOnClickListener(new FitAction(this));
      label335: if ("1".equals(BaseApplication.userModel.loginTerrace))
        break label406;
      this.accountQqState.setOnClickListener(new FitAction(this));
    }
    while (true)
    {
      this.mine03AccountPasswordL.setOnClickListener(new FitAction(this));
      setLoginStatus();
      return;
      this.accountWeChatState.setClickable(false);
      break;
      label395: this.accountSinaState.setClickable(false);
      break label335;
      label406: this.accountQqState.setClickable(false);
    }
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("have.phone".equals(paramString))
    {
      this.mine03AccountPasswordL.setVisibility(0);
      this.add_phone_hint.setVisibility(8);
      this.accountPhoneNum.setVisibility(0);
      this.accountPhoneNumHint.setText(getString(R.string.c_47_2));
      this.accountPhoneNum.setText(changePhoneNum(BaseApplication.userModel.phoneNumber));
      this.accountPhoneIcon.setImageResource(R.mipmap.icon_phone);
      this.tellFlag = Boolean.valueOf(true);
      EventBus.getDefault().post(new ReceiveMedalEvent("8", this));
    }
    do
    {
      return;
      if (!"update.phone.number".equals(paramString))
        continue;
      this.accountPhoneNumHint.setText(getString(R.string.c_47_2));
      this.accountPhoneNum.setText(changePhoneNum(BaseApplication.userModel.phoneNumber));
      return;
    }
    while (!"set.password.success".equals(paramString));
    this.mine_password_state.setText(getString(R.string.c_47_4));
    this.mine_password_state.setTextColor(ContextCompat.getColor(this, R.color.color_828282));
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  protected void onResume()
  {
    super.onResume();
    if (Constant.bind_state)
    {
      Constant.bind_state = false;
      this.dialog.closeDialog();
      this.accountWeChatState.setChecked(false);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03AccountActivity
 * JD-Core Version:    0.6.0
 */