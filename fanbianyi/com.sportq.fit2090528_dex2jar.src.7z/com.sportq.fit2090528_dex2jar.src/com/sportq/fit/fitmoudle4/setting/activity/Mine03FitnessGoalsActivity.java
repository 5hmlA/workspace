package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.train.TrainPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.reformer.QuestionnaireReformer;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;

public class Mine03FitnessGoalsActivity extends BaseActivity
{
  FrameLayout mineFitnessBasisL;
  private TextView mineFitnessBasisText;
  FrameLayout mineFitnessGoalL;
  private TextView mineFitnessGoalText;
  private String sBasics;
  private String sGoal;
  CustomToolBar toolbar;

  private void setData()
  {
    if ((BaseApplication.userModel != null) && (BaseApplication.quReformer != null))
      try
      {
        this.mineFitnessGoalText.setText(BaseApplication.quReformer.getCustomizedTargetName(BaseApplication.userModel.fitGoal));
        this.mineFitnessBasisText.setText(BaseApplication.quReformer.getCustomizedDifficultName(BaseApplication.userModel.fitBase));
        this.sGoal = BaseApplication.quReformer.getCustomizedTargetName(BaseApplication.userModel.fitGoal);
        this.sBasics = BaseApplication.quReformer.getCustomizedTargetName(BaseApplication.userModel.fitGoal);
        this.mineFitnessGoalL.setOnClickListener(new FitAction(this));
        this.mineFitnessBasisL.setOnClickListener(new FitAction(this));
        return;
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        this.mineFitnessGoalL.setOnClickListener(null);
        this.mineFitnessBasisL.setOnClickListener(null);
        return;
      }
    this.mineFitnessGoalL.setOnClickListener(null);
    this.mineFitnessBasisL.setOnClickListener(null);
  }

  public void fitOnClick(View paramView)
  {
    Intent localIntent = new Intent(this, Mine04FitnessBasisActivity.class);
    if (R.id.mine_fitness_goal_l == paramView.getId())
    {
      localIntent.putExtra("comeflg", "0");
      startActivityForResult(localIntent, 12545);
    }
    while (true)
    {
      AnimationUtil.pageJumpAnim(this, 0);
      return;
      if (R.id.mine_fitness_basis_l != paramView.getId())
        continue;
      localIntent.putExtra("comeflg", "1");
      startActivityForResult(localIntent, 12546);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    setData();
    super.getDataSuccess(paramT);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine03_fitness_goals);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.mineFitnessGoalText = ((TextView)findViewById(R.id.mine_fitness_goal_text));
    this.mineFitnessGoalL = ((FrameLayout)findViewById(R.id.mine_fitness_goal_l));
    this.mineFitnessBasisText = ((TextView)findViewById(R.id.mine_fitness_basis_text));
    this.mineFitnessBasisL = ((FrameLayout)findViewById(R.id.mine_fitness_basis_l));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(R.string.c_51_1);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    if (BaseApplication.quReformer == null)
    {
      MiddleManager.getInstance().getTrainPresenterImpl(this).getQuestionnaireInfo(this);
      return;
    }
    setData();
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramIntent == null);
    do
      return;
    while (StringUtils.isNull(paramIntent.getStringExtra("seceltcontext")));
    if (paramInt1 == 12545)
    {
      this.mineFitnessGoalText.setText(paramIntent.getStringExtra("seceltcontext"));
      return;
    }
    this.mineFitnessBasisText.setText(paramIntent.getStringExtra("seceltcontext"));
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4);
    try
    {
      if ((!StringUtils.isNull(this.sGoal)) && (!StringUtils.isNull(this.sBasics)) && ((!this.sGoal.equals(this.mineFitnessGoalText.getText().toString())) || (!this.sBasics.equals(this.mineFitnessBasisText.getText().toString()))))
        EventBus.getDefault().post("goal.basics.revise");
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      return false;
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      try
      {
        if ((!StringUtils.isNull(this.sGoal)) && (!StringUtils.isNull(this.sBasics)) && ((!this.sGoal.equals(this.mineFitnessGoalText.getText().toString())) || (!this.sBasics.equals(this.mineFitnessBasisText.getText().toString()))))
          EventBus.getDefault().post("goal.basics.revise");
        finish();
        AnimationUtil.pageJumpAnim(this, 1);
      }
      catch (Exception localException)
      {
        while (true)
          LogUtils.e(localException);
      }
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03FitnessGoalsActivity
 * JD-Core Version:    0.6.0
 */