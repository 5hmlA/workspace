package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.res.Resources;
import android.support.v4.content.ContextCompat;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.onTextChangeListener;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle4.R.color;

class MineReplaceBindPhone01Activity$1
  implements FitInterfaceUtils.onTextChangeListener
{
  public void onChangeResult(String paramString)
  {
    boolean bool;
    int i;
    label36: RTextViewHelper localRTextViewHelper2;
    MineReplaceBindPhone01Activity localMineReplaceBindPhone01Activity;
    if (paramString.length() == 4)
    {
      bool = true;
      RTextViewHelper localRTextViewHelper1 = MineReplaceBindPhone01Activity.access$000(this.this$0);
      Resources localResources = this.this$0.getResources();
      if (!bool)
        break label102;
      i = R.color.color_ffd208;
      localRTextViewHelper1.setBackgroundColorNormal(localResources.getColor(i));
      localRTextViewHelper2 = MineReplaceBindPhone01Activity.access$000(this.this$0);
      localMineReplaceBindPhone01Activity = this.this$0;
      if (!bool)
        break label110;
    }
    label102: label110: for (int j = R.color.color_313131; ; j = R.color.color_c8c8c8)
    {
      localRTextViewHelper2.setTextColorNormal(ContextCompat.getColor(localMineReplaceBindPhone01Activity, j));
      MineReplaceBindPhone01Activity.access$100(this.this$0).setEnabled(bool);
      return;
      bool = false;
      break;
      i = R.color.color_e6e6e6;
      break label36;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.MineReplaceBindPhone01Activity.1
 * JD-Core Version:    0.6.0
 */