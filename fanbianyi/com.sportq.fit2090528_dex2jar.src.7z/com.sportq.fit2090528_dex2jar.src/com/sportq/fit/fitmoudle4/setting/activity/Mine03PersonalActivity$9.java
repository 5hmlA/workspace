package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.DialogInterface;
import android.content.Intent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.SystemPhotoUtils;

class Mine03PersonalActivity$9
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == 0)
    {
      Intent localIntent = new Intent("android.media.action.IMAGE_CAPTURE");
      localIntent.putExtra("android.intent.extra.videoQuality", 1);
      Mine03PersonalActivity.access$802(this.this$0, FileUtils.getPhotopath());
      localIntent.putExtra("output", FileUtils.getTakePhotoUri(Mine03PersonalActivity.access$800(this.this$0)));
      localIntent.putExtra("orientation", 180);
      this.this$0.startActivityForResult(localIntent, 1);
      return;
    }
    Mine03PersonalActivity.access$900(this.this$0).openSystemPhoto();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity.9
 * JD-Core Version:    0.6.0
 */