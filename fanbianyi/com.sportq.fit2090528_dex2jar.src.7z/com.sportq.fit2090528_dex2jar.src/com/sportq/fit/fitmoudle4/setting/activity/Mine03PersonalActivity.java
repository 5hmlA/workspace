package com.sportq.fit.fitmoudle4.setting.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.SystemPhotoModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.LocationHandler;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.SystemPhotoUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.SelectDateDialog;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle4.R.color;
import com.sportq.fit.fitmoudle4.R.id;
import com.sportq.fit.fitmoudle4.R.layout;
import com.sportq.fit.fitmoudle4.R.menu;
import com.sportq.fit.fitmoudle4.R.mipmap;
import com.sportq.fit.fitmoudle4.R.string;
import com.sportq.fit.fitmoudle4.R.style;
import com.sportq.fit.fitmoudle4.setting.widget.SelectProvinceDialog;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Mine03PersonalActivity extends BaseActivity
{
  private String age;
  private String auto_city;
  private Boolean isUpdateInfo = Boolean.valueOf(false);
  private String isUpdatePhoto = "0";
  private String[] itemList;
  private Menu mMenu;
  private TextView mine03FitNumber;
  FrameLayout mine03FitNumberL;
  private TextView mine03PersonalBirthday;
  FrameLayout mine03PersonalBirthdayL;
  private TextView mine03PersonalCity;
  FrameLayout mine03PersonalCityL;
  FrameLayout mine03PersonalHeightL;
  private EditText mine03PersonalNameEdit;
  private ImageView mine03PersonalPhoto;
  FrameLayout mine03PersonalPhotoL;
  private TextView mine03PersonalSex;
  FrameLayout mine03PersonalSexL;
  private TextView mine03_personal_height;
  private RequestModel requestModel;
  private SelectProvinceDialog selectProvinceDialog;
  private String strPicturePath;
  private SystemPhotoUtils systemPhotoUtils;
  CustomToolBar toolbar;

  private void closeKryBord()
  {
    View localView = getWindow().peekDecorView();
    if (localView != null)
      ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(localView.getWindowToken(), 0);
    this.mine03PersonalNameEdit.clearFocus();
  }

  private RequestModel getRequestModel()
  {
    if (this.requestModel == null);
    for (RequestModel localRequestModel = new RequestModel(); ; localRequestModel = this.requestModel)
    {
      this.requestModel = localRequestModel;
      return this.requestModel;
    }
  }

  private void isGiveUpChange()
  {
    this.dialog.createChoiceDialogWithColor(new Mine03PersonalActivity.8(this), this, "", StringUtils.getStringResources(R.string.c_41_1), getString(R.string.c_41_3), getString(R.string.c_41_2), R.color.color_ffd208, R.color.color_e6e6e6, R.color.color_313131, R.color.color_626262);
  }

  private void jumpToTakePhoto()
  {
    this.dialog.createDialog(new Mine03PersonalActivity.9(this), this, this.itemList);
  }

  private void onBackAction()
  {
    if ((StringUtils.isNull(getRequestModel().userName)) || (!StringUtils.checkName(getRequestModel().userName)))
    {
      ToastUtils.makeToast(this, "请输入3～32位字符，支持中英文、数字、“_”和“-”");
      return;
    }
    this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
    MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(getRequestModel(), this);
  }

  private void setUpdateIcon()
  {
    if (this.mMenu != null)
    {
      if ((this.age.equals(BaseApplication.userModel.birthday)) && (this.mine03PersonalCity.getText().toString().equals(BaseApplication.userModel.region)) && (this.mine03PersonalNameEdit.getText().toString().equals(BaseApplication.userModel.userName)) && ("0".equals(this.isUpdatePhoto)))
      {
        this.isUpdateInfo = Boolean.valueOf(false);
        Drawable localDrawable2 = this.mMenu.findItem(R.id.action_save).getIcon();
        localDrawable2.setAlpha(77);
        this.mMenu.findItem(R.id.action_save).setIcon(localDrawable2);
      }
    }
    else
      return;
    this.isUpdateInfo = Boolean.valueOf(true);
    Drawable localDrawable1 = this.mMenu.findItem(R.id.action_save).getIcon();
    localDrawable1.setAlpha(255);
    this.mMenu.findItem(R.id.action_save).setIcon(localDrawable1);
  }

  private void showUserInfo()
  {
    GlideUtils.loadImgByCircle(BaseApplication.userModel.userImg, R.mipmap.avatar_default, this.mine03PersonalPhoto);
    String str;
    if (!StringUtils.isNull(BaseApplication.userModel.birthday))
    {
      this.mine03PersonalBirthday.setText(BaseApplication.userModel.birthday);
      this.age = BaseApplication.userModel.birthday;
      TextView localTextView1 = this.mine03PersonalSex;
      if (!"0".equals(BaseApplication.userModel.userSex))
        break label256;
      str = getString(R.string.male);
      label78: localTextView1.setText(str);
      if (StringUtils.isNull(BaseApplication.userModel.region))
        break label267;
      this.mine03PersonalCity.setText(BaseApplication.userModel.region);
      label108: this.mine03FitNumber.setText(BaseApplication.userModel.fitId);
      if ((StringUtils.isNull(BaseApplication.userModel.height)) || (StringUtils.isNull(BaseApplication.userModel.currentWeight)))
        break label280;
      TextView localTextView2 = this.mine03_personal_height;
      int i = R.string.c_35_8;
      String[] arrayOfString = new String[2];
      arrayOfString[0] = BaseApplication.userModel.height;
      arrayOfString[1] = BaseApplication.userModel.currentWeight;
      localTextView2.setText(UseStringUtils.getStr(i, arrayOfString));
    }
    while (true)
    {
      this.mine03PersonalNameEdit.setText(BaseApplication.userModel.userName);
      this.mine03PersonalNameEdit.setOnFocusChangeListener(new Mine03PersonalActivity.2(this));
      TextUtils.onTextChange(new Mine03PersonalActivity.3(this), this.mine03PersonalNameEdit);
      return;
      this.mine03PersonalBirthday.setText("未填写");
      this.age = "1990.06.01";
      break;
      label256: str = getString(R.string.female);
      break label78;
      label267: this.mine03PersonalCity.setText("未填写");
      break label108;
      label280: this.mine03_personal_height.setText(getString(R.string.c_31_4));
    }
  }

  private void showdataDialog()
  {
    new SelectDateDialog(this).createDialog(new Mine03PersonalActivity.7(this), this.age);
  }

  public void fitOnClick(View paramView)
  {
    if (R.id.mine03_personal_photo_l == paramView.getId())
    {
      closeKryBord();
      CompDeviceInfoUtils.applyPermission(new Mine03PersonalActivity.4(this), this, new String[] { "android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE" });
    }
    do
    {
      return;
      if (R.id.mine03_personal_birthday_l == paramView.getId())
      {
        closeKryBord();
        setTheme(R.style.AppTheme_Base03);
        showdataDialog();
        return;
      }
      if (R.id.mine03_personal_city_l == paramView.getId())
      {
        closeKryBord();
        if ((StringUtils.isNull(BaseApplication.userModel.region)) && (StringUtils.isNull(this.auto_city)))
        {
          new LocationHandler(this, new Mine03PersonalActivity.5(this), this.dialog).gpsLocationStart();
          return;
        }
        if (this.selectProvinceDialog == null);
        for (SelectProvinceDialog localSelectProvinceDialog = new SelectProvinceDialog(this); ; localSelectProvinceDialog = this.selectProvinceDialog)
        {
          this.selectProvinceDialog = localSelectProvinceDialog;
          this.selectProvinceDialog.createDialog(this.mine03PersonalCity.getText().toString(), new Mine03PersonalActivity.6(this));
          return;
        }
      }
      if (R.id.mine03_personal_height_l != paramView.getId())
        continue;
      FitJumpImpl.getInstance().settingJumpHealthData(this, Constant.STR_0);
      return;
    }
    while (R.id.mine03_personal_sex_l != paramView.getId());
    closeKryBord();
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    if (((paramT instanceof String)) && (((String)paramT).contains("[br]")))
    {
      ToastUtils.makeToast(this, getString(R.string.d_14_1));
      return;
    }
    this.dialog.createChoiceDialog(new Mine03PersonalActivity.1(this), this, "", getString(R.string.modify_data_failed), getString(R.string.click_to_try), getString(R.string.cancel_hint));
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    Toast localToast = Toast.makeText(this, "保存成功", 0);
    localToast.show();
    VdsAgent.showToast((Toast)localToast);
    finish();
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine03_personal);
    this.systemPhotoUtils = new SystemPhotoUtils(this);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.mine03PersonalPhoto = ((ImageView)findViewById(R.id.mine03_personal_photo));
    this.mine03PersonalPhotoL = ((FrameLayout)findViewById(R.id.mine03_personal_photo_l));
    this.mine03PersonalSex = ((TextView)findViewById(R.id.mine03_personal_sex));
    this.mine03PersonalSexL = ((FrameLayout)findViewById(R.id.mine03_personal_sex_l));
    this.mine03PersonalBirthday = ((TextView)findViewById(R.id.mine03_personal_birthday));
    this.mine03PersonalBirthdayL = ((FrameLayout)findViewById(R.id.mine03_personal_birthday_l));
    this.mine03PersonalCity = ((TextView)findViewById(R.id.mine03_personal_city));
    this.mine03PersonalCityL = ((FrameLayout)findViewById(R.id.mine03_personal_city_l));
    this.mine03FitNumber = ((TextView)findViewById(R.id.mine03_fit_number));
    this.mine03FitNumberL = ((FrameLayout)findViewById(R.id.mine03_fit_number_l));
    this.mine03_personal_height = ((TextView)findViewById(R.id.mine03_personal_height));
    this.mine03PersonalHeightL = ((FrameLayout)findViewById(R.id.mine03_personal_height_l));
    this.mine03PersonalNameEdit = ((EditText)findViewById(R.id.mine03_personal_name_edit));
    String[] arrayOfString = new String[2];
    arrayOfString[0] = getString(R.string.c_36_1);
    arrayOfString[1] = getString(R.string.c_36_2);
    this.itemList = arrayOfString;
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(getString(R.string.mine_personal_data));
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    getRequestModel().userName = BaseApplication.userModel.userName;
    this.mine03PersonalPhotoL.setOnClickListener(new FitAction(this));
    this.mine03PersonalBirthdayL.setOnClickListener(new FitAction(this));
    this.mine03PersonalCityL.setOnClickListener(new FitAction(this));
    this.mine03PersonalSexL.setOnClickListener(new FitAction(this));
    this.mine03PersonalHeightL.setOnClickListener(new FitAction(this));
    showUserInfo();
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    switch (paramInt1)
    {
    default:
    case 1:
    case 999:
    case 4:
    }
    while (true)
    {
      super.onActivityResult(paramInt1, paramInt2, paramIntent);
      return;
      if (StringUtils.isNull(this.strPicturePath))
        continue;
      FitJumpImpl.getInstance().settingJumpClipPicture(this, this.strPicturePath);
      continue;
      if (paramIntent == null)
        continue;
      SystemPhotoModel localSystemPhotoModel = this.systemPhotoUtils.resultData(this, paramIntent);
      if (localSystemPhotoModel == null)
        continue;
      this.strPicturePath = localSystemPhotoModel.url_pri;
      if (StringUtils.isNull(this.strPicturePath))
        continue;
      FitJumpImpl.getInstance().settingJumpClipPicture(this, this.strPicturePath);
      continue;
      if (paramIntent == null)
        continue;
      this.strPicturePath = paramIntent.getStringExtra("clip.image");
      Bitmap localBitmap = ImageUtils.getImageBitmap(this.strPicturePath, 1);
      if (localBitmap == null)
        continue;
      getRequestModel().userImg = QiniuManager.uploadBitmap(localBitmap);
      int i = CompDeviceInfoUtils.convertOfDip(this, localBitmap.getWidth() / 2.0F);
      this.mine03PersonalPhoto.setImageBitmap(ImageUtils.getRoundedCornerBitmap(localBitmap, i));
      this.isUpdatePhoto = "1";
      setUpdateIcon();
    }
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(R.menu.personal_update_icon, paramMenu);
    Drawable localDrawable = paramMenu.findItem(R.id.action_save).getIcon();
    localDrawable.setAlpha(77);
    paramMenu.findItem(R.id.action_save).setIcon(localDrawable);
    this.mMenu = paramMenu;
    return super.onCreateOptionsMenu(paramMenu);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("refresh.weight".equals(paramString))
    {
      if ((!StringUtils.isNull(BaseApplication.userModel.height)) && (!StringUtils.isNull(BaseApplication.userModel.currentWeight)))
      {
        TextView localTextView = this.mine03_personal_height;
        int i = R.string.c_35_8;
        String[] arrayOfString = new String[2];
        arrayOfString[0] = BaseApplication.userModel.height;
        arrayOfString[1] = BaseApplication.userModel.currentWeight;
        localTextView.setText(UseStringUtils.getStr(i, arrayOfString));
      }
    }
    else
      return;
    this.mine03_personal_height.setText(getString(R.string.c_31_4));
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      if (!this.isUpdateInfo.booleanValue())
        break label21;
      isGiveUpChange();
    }
    while (true)
    {
      return false;
      label21: finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
      if (this.isUpdateInfo.booleanValue())
        isGiveUpChange();
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      continue;
      if ((paramMenuItem.getItemId() != R.id.action_save) || (!this.isUpdateInfo.booleanValue()))
        continue;
      onBackAction();
    }
  }

  int[] splitAge(String paramString)
  {
    int[] arrayOfInt = new int[3];
    String[] arrayOfString = paramString.split("\\.");
    arrayOfInt[0] = Integer.parseInt(arrayOfString[0]);
    arrayOfInt[1] = Integer.parseInt(arrayOfString[1]);
    arrayOfInt[2] = Integer.parseInt(arrayOfString[2]);
    return arrayOfInt;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.activity.Mine03PersonalActivity
 * JD-Core Version:    0.6.0
 */