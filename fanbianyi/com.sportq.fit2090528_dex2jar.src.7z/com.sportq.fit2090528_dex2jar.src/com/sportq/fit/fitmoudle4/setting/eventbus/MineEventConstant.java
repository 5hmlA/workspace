package com.sportq.fit.fitmoudle4.setting.eventbus;

public class MineEventConstant
{
  public static final String CLOSE_BIND01 = "close.bind01";
  public static final String MINE_GOAL_AND_BASICS_REVISE = "goal.basics.revise";
  public static final String MINE_HAVE_PHONE = "have.phone";
  public static final String MINE_NOTICE_ERROR = "notice.error";
  public static final String MINE_NOTICE_UPDATE = "notice.update";
  public static final String MINE_UPDATE_PHONE_NUM = "update.phone.number";
  public static final String SET_PASSWORD_SUCCESS = "set.password.success";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle4.setting.eventbus.MineEventConstant
 * JD-Core Version:    0.6.0
 */