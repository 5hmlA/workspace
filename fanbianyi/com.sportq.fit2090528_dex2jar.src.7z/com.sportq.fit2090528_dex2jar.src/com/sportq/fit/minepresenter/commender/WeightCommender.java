package com.sportq.fit.minepresenter.commender;

import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.WeightModel;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.XUtilDB;
import java.util.ArrayList;
import org.xutils.common.util.KeyValue;
import org.xutils.db.Selector;
import org.xutils.db.sqlite.WhereBuilder;

public class WeightCommender
{
  private XUtilDB xdb = XUtilDB.getInstance();

  private ArrayList<WeightModel> checkWeightList(ArrayList<WeightModel> paramArrayList)
  {
    ArrayList localArrayList = new ArrayList();
    if (paramArrayList.size() > 0)
    {
      String str = ((WeightModel)paramArrayList.get(0)).recordDate;
      localArrayList.add(paramArrayList.get(0));
      for (int i = 1; i < paramArrayList.size(); i++)
      {
        if (str.equals(((WeightModel)paramArrayList.get(i)).recordDate))
          continue;
        str = ((WeightModel)paramArrayList.get(i)).recordDate;
        localArrayList.add(paramArrayList.get(i));
      }
    }
    return localArrayList;
  }

  public void addWeightToday(String paramString1, String paramString2)
  {
    WeightModel localWeightModel = new WeightModel();
    localWeightModel.isShowDot = "1";
    localWeightModel.recordDate = paramString1;
    localWeightModel.weight = paramString2;
    this.xdb.addInfo(localWeightModel);
  }

  public ArrayList<WeightModel> getAllSelectWeight()
  {
    Selector localSelector = this.xdb.getDBSelector(WeightModel.class).where("userId", "=", BaseApplication.userModel.userId).orderBy("recordDate", true);
    return checkWeightList((ArrayList)this.xdb.selectInfo(localSelector));
  }

  public WeightModel getFristWeigtDateString()
  {
    Selector localSelector = this.xdb.getDBSelector(WeightModel.class).where("userId", "=", BaseApplication.userModel.userId).orderBy("recordDate", true).limit(1);
    return (WeightModel)this.xdb.getFrist(localSelector);
  }

  public ArrayList<WeightModel> getSelectWeight(int paramInt, String paramString)
  {
    if (StringUtils.isNull(paramString));
    for (Selector localSelector = this.xdb.getDBSelector(WeightModel.class).where("userId", "=", BaseApplication.userModel.userId).orderBy("recordDate", true).limit(paramInt); ; localSelector = this.xdb.getDBSelector(WeightModel.class).where("userId", "=", BaseApplication.userModel.userId).and("recordDate", "<", paramString).orderBy("recordDate", true).limit(paramInt))
      return (ArrayList)this.xdb.selectInfo(localSelector);
  }

  public long selectWeightCount(String paramString)
  {
    if (StringUtils.isNull(paramString));
    for (Selector localSelector = this.xdb.getDBSelector(WeightModel.class).where("userId", "=", BaseApplication.userModel.userId); ; localSelector = this.xdb.getDBSelector(WeightModel.class).where("userId", "=", BaseApplication.userModel.userId).and("recordDate", "=", paramString))
      return this.xdb.getCount(localSelector);
  }

  public void updateWeightToday(String paramString1, String paramString2)
  {
    XUtilDB localXUtilDB = this.xdb;
    WhereBuilder localWhereBuilder = WhereBuilder.b("recordDate", "=", paramString1);
    KeyValue[] arrayOfKeyValue = new KeyValue[2];
    arrayOfKeyValue[0] = new KeyValue("weight", paramString2);
    arrayOfKeyValue[1] = new KeyValue("isShowDot", Integer.valueOf(1));
    localXUtilDB.updateInfo(WeightModel.class, localWhereBuilder, arrayOfKeyValue);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.minepresenter.commender.WeightCommender
 * JD-Core Version:    0.6.0
 */