package com.sportq.fit.minepresenter.commender;

import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.PersonalCoachModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.XUtilDB;
import java.util.ArrayList;
import java.util.Collections;
import org.xutils.common.util.KeyValue;
import org.xutils.db.Selector;
import org.xutils.db.sqlite.WhereBuilder;

public class PersonalCoachCommender
{
  private XUtilDB xdb = new XUtilDB();

  public void deleteCoach()
  {
    this.xdb.deletInfo(PersonalCoachModel.class, WhereBuilder.b("userId", "=", BaseApplication.userModel.userId));
  }

  public void deleteCoach(PersonalCoachModel paramPersonalCoachModel)
  {
    this.xdb.deletInfo(PersonalCoachModel.class, WhereBuilder.b("id", "=", Integer.valueOf(paramPersonalCoachModel.id)).and("userId", "=", BaseApplication.userModel.userId));
  }

  public ArrayList<PersonalCoachModel> getHistoryItems(int paramInt)
  {
    if (paramInt == -1);
    for (Selector localSelector = this.xdb.getDBSelector(PersonalCoachModel.class).where("userId", "=", BaseApplication.userModel.userId).orderBy("id", true).limit(20); ; localSelector = this.xdb.getDBSelector(PersonalCoachModel.class).where("userId", "=", BaseApplication.userModel.userId).and("id", "<", Integer.valueOf(paramInt)).orderBy("id", true).limit(20))
    {
      ArrayList localArrayList = (ArrayList)this.xdb.selectInfo(localSelector);
      Collections.reverse(localArrayList);
      if (localArrayList == null)
        localArrayList = new ArrayList();
      return localArrayList;
    }
  }

  public int insertCoachDic(PersonalCoachModel paramPersonalCoachModel)
  {
    return this.xdb.addInfoId(paramPersonalCoachModel);
  }

  public void insertCoachDic(ArrayList<PersonalCoachModel> paramArrayList)
  {
    this.xdb.addInfo(paramArrayList);
  }

  public void updateSendImg(int paramInt, String paramString)
  {
    XUtilDB localXUtilDB = this.xdb;
    WhereBuilder localWhereBuilder = WhereBuilder.b("id", "=", Integer.valueOf(paramInt)).and("userId", "=", BaseApplication.userModel.userId);
    KeyValue[] arrayOfKeyValue = new KeyValue[1];
    arrayOfKeyValue[0] = new KeyValue("imageURL", paramString);
    localXUtilDB.updateInfo(PersonalCoachModel.class, localWhereBuilder, arrayOfKeyValue);
  }

  public void updateSendState(int paramInt, String paramString)
  {
    XUtilDB localXUtilDB = this.xdb;
    WhereBuilder localWhereBuilder = WhereBuilder.b("id", "=", Integer.valueOf(paramInt)).and("userId", "=", BaseApplication.userModel.userId);
    KeyValue[] arrayOfKeyValue = new KeyValue[1];
    arrayOfKeyValue[0] = new KeyValue("sendState", paramString);
    localXUtilDB.updateInfo(PersonalCoachModel.class, localWhereBuilder, arrayOfKeyValue);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.minepresenter.commender.PersonalCoachCommender
 * JD-Core Version:    0.6.0
 */