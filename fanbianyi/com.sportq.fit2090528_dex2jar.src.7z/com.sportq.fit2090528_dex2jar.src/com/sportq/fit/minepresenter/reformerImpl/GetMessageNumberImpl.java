package com.sportq.fit.minepresenter.reformerImpl;

import android.content.Context;
import com.google.gson.Gson;
import com.qiyukf.unicorn.api.Unicorn;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.MessageModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.minepresenter.reformer.GetMessageNumberReformer;
import java.util.HashMap;
import java.util.Map;
import org.greenrobot.eventbus.EventBus;

public class GetMessageNumberImpl
  implements ReformerInterface
{
  private Context context;

  public GetMessageNumberImpl(Context paramContext)
  {
    this.context = paramContext;
  }

  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    GetMessageNumberReformer localGetMessageNumberReformer = new GetMessageNumberReformer();
    MessageModel localMessageModel1 = new MessageModel();
    MessageModel localMessageModel2 = (MessageModel)paramBaseData;
    localMessageModel1.messageNumber = localMessageModel2.messageNumber;
    localMessageModel1.contentNumber = localMessageModel2.contentNumber;
    localMessageModel1.missionUpdateTime = localMessageModel2.missionUpdateTime;
    localMessageModel1.planUpdateTime = localMessageModel2.planUpdateTime;
    localMessageModel1.tpcId = localMessageModel2.tpcId;
    localMessageModel1.musicUpdateTime = localMessageModel2.musicUpdateTime;
    localMessageModel1.isUseLocCache = localMessageModel2.isUseLocCache;
    SharePreferenceUtils.putIsUseLocCache(BaseApplication.appliContext, localMessageModel1.isUseLocCache);
    localMessageModel1.needFillInfo = localMessageModel2.needFillInfo;
    localMessageModel1.commentNumber = localMessageModel2.commentNumber;
    localMessageModel1.likeNum = localMessageModel2.likeNum;
    localMessageModel1.remindNumber = localMessageModel2.remindNumber;
    localMessageModel1.orderNum = localMessageModel2.orderNum;
    localMessageModel1.entMallAction = localMessageModel2.entMallAction;
    localMessageModel1.isShowComment = localMessageModel2.isShowComment;
    localMessageModel1.actUpdateTime = localMessageModel2.actUpdateTime;
    localMessageModel1.endTime = localMessageModel2.endTime;
    localMessageModel1.unlockValue = localMessageModel2.unlockValue;
    localMessageModel1.useDay = localMessageModel2.useDay;
    localMessageModel1.useComment = localMessageModel2.useComment;
    localMessageModel1.mechComment = localMessageModel2.mechComment;
    localMessageModel1.couponId = localMessageModel2.couponId;
    localMessageModel1.isForceUpdate = localMessageModel2.isForceUpdate;
    localMessageModel1.openWelcomeAd = localMessageModel2.openWelcomeAd;
    localMessageModel1.openBannerAd = localMessageModel2.openBannerAd;
    localMessageModel1.isVip = localMessageModel2.isVip;
    localMessageModel1.isDisplay = localMessageModel2.isDisplay;
    localMessageModel1.isHasPhy = localMessageModel2.isHasPhy;
    SharePreferenceUtils.putIsShowComment(BaseApplication.userModel.userId, localMessageModel1.isShowComment);
    SharePreferenceUtils.putNeedFillInfo(BaseApplication.appliContext, localMessageModel1.needFillInfo);
    SharePreferenceUtils.putEliminateComment(localMessageModel1.mechComment);
    SharePreferenceUtils.putMessageNumJson(new Gson().toJson(localMessageModel1));
    localMessageModel1.shareUrl = localMessageModel2.shareUrl;
    String[] arrayOfString1;
    label447: label509: String[] arrayOfString3;
    if (!StringUtils.isNull(localMessageModel2.shareUrl))
    {
      VersionUpdateCheck.WEB_ADDRESS = localMessageModel2.shareUrl + "/";
      arrayOfString1 = SharePreferenceUtils.getPlanUpdateTime();
      if (arrayOfString1 == null)
        break label758;
      if ((!StringUtils.isNull(arrayOfString1[0])) || (!StringUtils.isNull(arrayOfString1[1])))
        break label670;
      localMessageModel1.shouldActionShow = false;
      SharePreferenceUtils.putPlanUpdateTime(localMessageModel1.actUpdateTime, Constant.STR_1);
      String[] arrayOfString2 = SharePreferenceUtils.getMissionUpdateTime();
      if ((arrayOfString2 == null) || (arrayOfString2.length < 2))
        break label818;
      if (!arrayOfString2[0].equals(localMessageModel1.missionUpdateTime))
        break label798;
      if (!arrayOfString2[1].equals(Constant.STR_0))
        break label778;
      localMessageModel1.shouldChallengeShow = true;
      SharePreferenceUtils.putMissionUpdateTime(localMessageModel1.missionUpdateTime, Constant.STR_0);
      arrayOfString3 = SharePreferenceUtils.getMusicLibraryTime();
      if (arrayOfString3 == null)
        break label926;
      if ((!StringUtils.isNull(arrayOfString3[0])) || (!StringUtils.isNull(arrayOfString3[1])))
        break label838;
      localMessageModel1.shouldMusiceLibraryShow = false;
      SharePreferenceUtils.putMusicLibraryTime(localMessageModel1.musicUpdateTime, Constant.STR_1);
    }
    while (true)
    {
      localGetMessageNumberReformer.messageModel = localMessageModel1;
      HashMap localHashMap = new HashMap();
      localHashMap.put("key", "updateMinePoint");
      int i = StringUtils.string2Int(localMessageModel1.messageNumber) + StringUtils.string2Int(localMessageModel1.contentNumber) + Unicorn.getUnreadCount();
      localHashMap.put("msgCount", i + "");
      EventBus.getDefault().post(localHashMap);
      SharePreferenceUtils.putIsNewChatNum(this.context, localMessageModel1.contentNumber);
      return localGetMessageNumberReformer;
      VersionUpdateCheck.WEB_ADDRESS = VersionUpdateCheck.WEB_FORMAL_ADDRESS;
      break;
      label670: if (arrayOfString1[0].equals(localMessageModel1.actUpdateTime))
      {
        if (arrayOfString1[1].equals(Constant.STR_0))
        {
          localMessageModel1.shouldActionShow = true;
          SharePreferenceUtils.putPlanUpdateTime(localMessageModel1.actUpdateTime, Constant.STR_0);
          break label447;
        }
        localMessageModel1.shouldActionShow = false;
        SharePreferenceUtils.putPlanUpdateTime(localMessageModel1.actUpdateTime, Constant.STR_1);
        break label447;
      }
      localMessageModel1.shouldActionShow = true;
      SharePreferenceUtils.putPlanUpdateTime(localMessageModel1.actUpdateTime, Constant.STR_0);
      break label447;
      label758: localMessageModel1.shouldActionShow = true;
      SharePreferenceUtils.putPlanUpdateTime(localMessageModel1.actUpdateTime, Constant.STR_0);
      break label447;
      label778: localMessageModel1.shouldChallengeShow = false;
      SharePreferenceUtils.putMissionUpdateTime(localMessageModel1.missionUpdateTime, Constant.STR_1);
      break label509;
      label798: localMessageModel1.shouldChallengeShow = true;
      SharePreferenceUtils.putMissionUpdateTime(localMessageModel1.missionUpdateTime, Constant.STR_0);
      break label509;
      label818: localMessageModel1.shouldChallengeShow = true;
      SharePreferenceUtils.putMissionUpdateTime(localMessageModel1.missionUpdateTime, Constant.STR_0);
      break label509;
      label838: if (arrayOfString3[0].equals(localMessageModel1.musicUpdateTime))
      {
        if (arrayOfString3[1].equals(Constant.STR_0))
        {
          localMessageModel1.shouldMusiceLibraryShow = true;
          SharePreferenceUtils.putMusicLibraryTime(localMessageModel1.musicUpdateTime, Constant.STR_0);
          continue;
        }
        localMessageModel1.shouldMusiceLibraryShow = false;
        SharePreferenceUtils.putMusicLibraryTime(localMessageModel1.musicUpdateTime, Constant.STR_1);
        continue;
      }
      localMessageModel1.shouldMusiceLibraryShow = true;
      SharePreferenceUtils.putMusicLibraryTime(localMessageModel1.musicUpdateTime, Constant.STR_0);
      continue;
      label926: localMessageModel1.shouldMusiceLibraryShow = true;
      SharePreferenceUtils.putMusicLibraryTime(localMessageModel1.musicUpdateTime, Constant.STR_0);
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (MessageModel)FitGsonFactory.create().fromJson(paramString2, MessageModel.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.minepresenter.reformerImpl.GetMessageNumberImpl
 * JD-Core Version:    0.6.0
 */