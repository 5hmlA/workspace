package com.sportq.fit.minepresenter.reformerImpl;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.BaseUserBaseInfoModel;
import com.sportq.fit.common.reformer.UserBaseInfoReformer;
import com.sportq.fit.common.utils.FitGsonFactory;

public class UserBaseInfoReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    UserBaseInfoReformer localUserBaseInfoReformer = new UserBaseInfoReformer();
    localUserBaseInfoReformer.entUserBaseInfo = ((BaseUserBaseInfoModel)paramBaseData).entUserBaseInfo;
    return localUserBaseInfoReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (BaseData)FitGsonFactory.create().fromJson(paramString2, BaseUserBaseInfoModel.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.minepresenter.reformerImpl.UserBaseInfoReformerImpl
 * JD-Core Version:    0.6.0
 */