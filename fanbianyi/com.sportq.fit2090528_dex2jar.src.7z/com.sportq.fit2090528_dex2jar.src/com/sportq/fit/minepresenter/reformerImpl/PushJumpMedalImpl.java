package com.sportq.fit.minepresenter.reformerImpl;

import com.google.gson.Gson;
import com.sportq.fit.common.model.MedalModel;
import com.sportq.fit.common.model.response.ResponseModel.MedalData;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.LogUtils;

public class PushJumpMedalImpl
{
  public MedalModel getMedalModel(String paramString)
  {
    ResponseModel.MedalData localMedalData = (ResponseModel.MedalData)FitGsonFactory.create().fromJson(paramString, ResponseModel.MedalData.class);
    MedalModel localMedalModel = new MedalModel();
    localMedalModel.medalType = localMedalData.medalType;
    localMedalModel.medalNum = localMedalData.times;
    localMedalModel.medalIntroduce = localMedalData.medalIntr;
    localMedalModel.medalName = localMedalData.medalTitle;
    localMedalModel.medalCom = localMedalData.medalCom;
    localMedalModel.medalBigPic = localMedalData.medalBigImageUrl;
    localMedalModel.medalGetDate = localMedalData.getDate;
    localMedalModel.levelDuration = localMedalData.levelDuration;
    localMedalModel.numberColor = localMedalData.numberColor;
    localMedalModel.numberInImage = localMedalData.numberInImage;
    localMedalModel.medalGetNum = localMedalData.numberOfOwn;
    localMedalModel.olapInfo = localMedalData.olapInfo;
    localMedalModel.backgroundColor = localMedalData.backgroundColor;
    localMedalModel.isLight = true;
    if ("MED01".equals(localMedalModel.medalType))
    {
      localMedalModel.medalTypel = "1";
      return localMedalModel;
    }
    if (("MED02".equals(localMedalModel.medalType)) || ("MED03".equals(localMedalModel.medalType)))
    {
      localMedalModel.medalTypel = "2";
      return localMedalModel;
    }
    if ("MED12".equals(localMedalModel.medalType))
    {
      localMedalModel.medalTypel = "4";
      return localMedalModel;
    }
    while (true)
    {
      try
      {
        String[] arrayOfString = localMedalModel.olapInfo.split("\\|!\\|");
        if ("0".equals(arrayOfString[(-1 + arrayOfString.length)]))
        {
          str = "3";
          localMedalModel.medalTypel = str;
          return localMedalModel;
        }
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return localMedalModel;
      }
      String str = "16";
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.minepresenter.reformerImpl.PushJumpMedalImpl
 * JD-Core Version:    0.6.0
 */