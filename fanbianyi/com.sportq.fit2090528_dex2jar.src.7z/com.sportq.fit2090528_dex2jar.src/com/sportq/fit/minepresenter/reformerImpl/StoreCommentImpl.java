package com.sportq.fit.minepresenter.reformerImpl;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.model.StoreCommentModel;
import com.sportq.fit.common.reformer.StoreCommentReformer;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;

public class StoreCommentImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    StoreCommentReformer localStoreCommentReformer = new StoreCommentReformer();
    localStoreCommentReformer.result = ((StoreCommentModel)paramBaseData).result;
    return localStoreCommentReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    try
    {
      if (StringUtils.isNull(paramString2))
      {
        StoreCommentReformer localStoreCommentReformer = new StoreCommentReformer();
        localStoreCommentReformer.result = "Y";
        return localStoreCommentReformer;
      }
      BaseReformer localBaseReformer = dataToReformer(paramString1, (StoreCommentModel)new Gson().fromJson(paramString2, StoreCommentModel.class), paramBoolean);
      return localBaseReformer;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
    return null;
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.minepresenter.reformerImpl.StoreCommentImpl
 * JD-Core Version:    0.6.0
 */