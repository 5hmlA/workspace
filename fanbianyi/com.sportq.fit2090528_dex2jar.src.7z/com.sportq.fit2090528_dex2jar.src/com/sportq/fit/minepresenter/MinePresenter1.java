package com.sportq.fit.minepresenter;

import android.content.Context;
import com.qiniu.android.http.ResponseInfo;
import com.qiniu.android.storage.UpCompletionHandler;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.model.PersonalCoachModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.reformer.PersonalCoachReformer;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.QiniuManager;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.minepresenter.commender.PersonalCoachCommender;
import com.sportq.fit.minepresenter.reformerImpl.StoreCommentImpl;
import com.sportq.fit.supportlib.http.reformer.VipCommodityReformerImpl;
import com.sportq.fit.supportlib.http.reformer.VipHistReformerImpl;
import java.io.IOException;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.json.JSONObject;
import rx.Observable;
import rx.Subscriber;

public class MinePresenter1 extends MinePresenter
{
  private PersonalCoachCommender personalCoachCommender;

  public MinePresenter1()
  {
  }

  public MinePresenter1(FitInterfaceUtils.UIInitListener paramUIInitListener, ApiInterface paramApiInterface)
  {
    setMinePresenter(paramUIInitListener, paramApiInterface);
  }

  private void sendFeedNet(PersonalCoachModel paramPersonalCoachModel, Context paramContext)
  {
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.contentType = paramPersonalCoachModel.contentType;
    localRequestModel.comment = paramPersonalCoachModel.comment;
    localRequestModel.imageURL = paramPersonalCoachModel.imageURL;
    localRequestModel.planId = paramPersonalCoachModel.planId;
    this.apiInterface.ptFeedbackReq(localRequestModel, paramContext).subscribe(new Subscriber(paramPersonalCoachModel)
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        new PersonalCoachCommender().updateSendState(this.val$model.id, Constant.STR_2);
        this.val$model.sendState = Constant.STR_2;
        if (MinePresenter1.this.view != null)
          MinePresenter1.this.view.getDataFail(this.val$model);
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        new PersonalCoachCommender().updateSendState(this.val$model.id, Constant.STR_0);
        this.val$model.sendState = Constant.STR_0;
        if (MinePresenter1.this.view != null)
          MinePresenter1.this.view.getDataSuccess(this.val$model);
      }
    });
  }

  public void deleteCoach(PersonalCoachModel paramPersonalCoachModel)
  {
    new PersonalCoachCommender().deleteCoach(paramPersonalCoachModel);
  }

  public void getDataWithWelcome(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    if (this.personalCoachCommender == null)
      this.personalCoachCommender = new PersonalCoachCommender();
    PersonalCoachModel localPersonalCoachModel = new PersonalCoachModel();
    localPersonalCoachModel.userType = Constant.STR_0;
    localPersonalCoachModel.sendState = Constant.STR_0;
    localPersonalCoachModel.contentType = Constant.STR_0;
    localPersonalCoachModel.lastUpdateTime = DateUtils.getCurDateTime();
    localPersonalCoachModel.showTime = DateUtils.gethmStr(localPersonalCoachModel.lastUpdateTime);
    if (StringUtils.isNull(SharePreferenceUtils.getFirstComeinSijiao(paramContext)))
    {
      this.personalCoachCommender.deleteCoach();
      SharePreferenceUtils.putFirstComeinSijiao(paramContext);
      localPersonalCoachModel.comment = "Hi，我是你的Fit私人教练，你有关于健身方面的任何问题，都可以告诉我。我和我们的教练团队会为你进行专业解答。\n\r你也可以上传你的形体照片，让我为你做更有针对性的健身指导。「Fit」－ 让你身材更有型！";
      this.personalCoachCommender.insertCoachDic(localPersonalCoachModel);
      if (!Constant.STR_0.equals(paramString1));
    }
    while (true)
    {
      return;
      String[] arrayOfString = SharePreferenceUtils.getComeinPlanidSijiao(paramContext);
      String str1 = arrayOfString[0];
      String str2 = arrayOfString[1];
      String str3 = arrayOfString[2];
      if ((StringUtils.isNull(str1)) || (!str1.equals(paramString3)))
        break;
      if ((DateUtils.getChaNowDateMin(str2) < 3) && (str3.equals(paramString1)))
        continue;
      if (Constant.STR_1.equals(paramString1))
      {
        localPersonalCoachModel.comment = String.format("关于【%s】，你有任何疑问都可以告诉我。我和我们的教练团队会为你进行专业解答。", new Object[] { paramString2 });
        this.personalCoachCommender.insertCoachDic(localPersonalCoachModel);
      }
      while (true)
      {
        SharePreferenceUtils.putComeinPlanidSijiao(paramContext, paramString3, paramString1);
        return;
        if (!Constant.STR_2.equals(paramString1))
          continue;
        localPersonalCoachModel.comment = String.format("恭喜你完成了【%s】，把你的感受，以及训练过程中的所有疑问，都告诉我。我和我们的教练团队会为你进行专业解答。", new Object[] { paramString2 });
        this.personalCoachCommender.insertCoachDic(localPersonalCoachModel);
      }
    }
    if (Constant.STR_1.equals(paramString1))
    {
      localPersonalCoachModel.comment = String.format("关于【%s】，你有任何疑问都可以告诉我。我和我们的教练团队会为你进行专业解答。", new Object[] { paramString2 });
      this.personalCoachCommender.insertCoachDic(localPersonalCoachModel);
    }
    while (true)
    {
      SharePreferenceUtils.putComeinPlanidSijiao(paramContext, paramString3, paramString1);
      return;
      if (!Constant.STR_2.equals(paramString1))
        continue;
      localPersonalCoachModel.comment = String.format("恭喜你完成了【%s】，把你的感受，以及训练过程中的所有疑问，都告诉我。我和我们的教练团队会为你进行专业解答。", new Object[] { paramString2 });
      this.personalCoachCommender.insertCoachDic(localPersonalCoachModel);
    }
  }

  public ArrayList<PersonalCoachModel> getHistoryInfo(int paramInt)
  {
    if (this.personalCoachCommender == null)
      this.personalCoachCommender = new PersonalCoachCommender();
    return this.personalCoachCommender.getHistoryItems(paramInt);
  }

  public void getNewResource(Context paramContext, String paramString)
  {
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.lastUpdateTime = SharePreferenceUtils.getChatLastTime(paramContext);
    String str = SharePreferenceUtils.getIsNewChatNum(paramContext);
    if ((Constant.STR_1.equals(paramString)) || ((!StringUtils.isNull(str)) && (Integer.valueOf(str).intValue() > 0)))
      this.apiInterface.ptFeedbackResource(localRequestModel, paramContext).subscribe(new Subscriber(paramContext)
      {
        public void onCompleted()
        {
        }

        public void onError(Throwable paramThrowable)
        {
          if (MinePresenter1.this.view != null)
            MinePresenter1.this.view.getDataFail(paramThrowable.getMessage());
        }

        public void onNext(ResponseModel paramResponseModel)
        {
          SharePreferenceUtils.putIsNewChatNum(this.val$context, "0");
          PersonalCoachReformer localPersonalCoachReformer = new PersonalCoachReformer();
          localPersonalCoachReformer.dateToCoachReformer(this.val$context, paramResponseModel);
          MinePresenter1.this.personalCoachCommender.insertCoachDic(localPersonalCoachReformer._coachArray);
          if (MinePresenter1.this.view != null)
            MinePresenter1.this.view.getDataSuccess(localPersonalCoachReformer);
          EventBus.getDefault().post("refresh.mine.page.data");
        }
      });
  }

  public void getVipCommodity(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      VipCommodityReformerImpl localVipCommodityReformerImpl = new VipCommodityReformerImpl();
      this.apiInterface.getHttp("/SFitWeb/sfit/getVipCommodity", paramContext, this.view, localVipCommodityReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("getVipCommodity", localException);
    }
  }

  public void getVipHist(Context paramContext, RequestModel paramRequestModel)
  {
    try
    {
      VipHistReformerImpl localVipHistReformerImpl = new VipHistReformerImpl();
      this.apiInterface.getHttp("/SFitWeb/sfit/getVipHist", paramContext, this.view, localVipHistReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("getVipHist", localException);
    }
  }

  public void reSendFeed(Context paramContext, ArrayList<PersonalCoachModel> paramArrayList, int paramInt)
  {
    PersonalCoachModel localPersonalCoachModel = (PersonalCoachModel)paramArrayList.get(paramInt);
    localPersonalCoachModel.lastUpdateTime = DateUtils.getCurDateTime();
    localPersonalCoachModel.sendState = Constant.STR_1;
    paramArrayList.remove(paramInt);
    paramArrayList.add(localPersonalCoachModel);
    if (this.personalCoachCommender == null)
      this.personalCoachCommender = new PersonalCoachCommender();
    this.personalCoachCommender.deleteCoach(localPersonalCoachModel);
    sendFeed(localPersonalCoachModel, paramContext);
    if (this.view != null)
      this.view.getDataSuccess(paramArrayList);
  }

  public void sendFeed(PersonalCoachModel paramPersonalCoachModel, Context paramContext)
  {
    if (this.personalCoachCommender == null)
      this.personalCoachCommender = new PersonalCoachCommender();
    paramPersonalCoachModel.showTime = DateUtils.gethmStr(paramPersonalCoachModel.lastUpdateTime);
    if (Constant.STR_1.equals(paramPersonalCoachModel.contentType))
    {
      String str1;
      if (StringUtils.isNull(paramPersonalCoachModel.imageURL))
      {
        str1 = QiniuManager.makeImgUrlString();
        paramPersonalCoachModel.imageURL = QiniuManager.getUpLoadStr(str1);
      }
      try
      {
        String str2 = VersionUpdateCheck.ALBUM_FILE_BASE_PATH + "chatImg/" + str1;
        ImageUtils.saveToFile(str2, false, paramPersonalCoachModel.bitmap, true, paramContext);
        paramPersonalCoachModel.localImageURL = str2;
        paramPersonalCoachModel.id = this.personalCoachCommender.insertCoachDic(paramPersonalCoachModel);
        if (paramPersonalCoachModel.bitmap == null)
          paramPersonalCoachModel.bitmap = ImageUtils.getImageBitmap(paramPersonalCoachModel.localImageURL, 2);
        QiniuManager.uploadData(paramPersonalCoachModel.bitmap, paramPersonalCoachModel.imageURL, new UpCompletionHandler(paramPersonalCoachModel, paramContext)
        {
          public void complete(String paramString, ResponseInfo paramResponseInfo, JSONObject paramJSONObject)
          {
            if (paramResponseInfo.isOK())
              MinePresenter1.this.sendFeedNet(this.val$model, this.val$context);
            do
            {
              return;
              if ("file exists".equals(paramResponseInfo.error))
              {
                MinePresenter1.this.sendFeedNet(this.val$model, this.val$context);
                return;
              }
              this.val$model.sendState = Constant.STR_2;
              MinePresenter1.this.personalCoachCommender.updateSendState(this.val$model.id, Constant.STR_2);
            }
            while (MinePresenter1.this.view == null);
            MinePresenter1.this.view.getDataFail(this.val$model);
          }
        });
        return;
      }
      catch (IOException localIOException)
      {
        while (true)
          localIOException.printStackTrace();
      }
    }
    paramPersonalCoachModel.id = this.personalCoachCommender.insertCoachDic(paramPersonalCoachModel);
    sendFeedNet(paramPersonalCoachModel, paramContext);
  }

  public void storeComment(Context paramContext, RequestModel paramRequestModel)
  {
    this.apiInterface.getHttp("/SFitWeb/sfit/storeComment", paramContext, this.view, new StoreCommentImpl(), paramRequestModel);
  }

  public void updateToNewInfo(ArrayList<PersonalCoachModel> paramArrayList, PersonalCoachModel paramPersonalCoachModel)
  {
    if ((paramArrayList != null) && (paramArrayList.size() > 0));
    for (int i = 0; ; i++)
    {
      if (i < paramArrayList.size())
      {
        if (paramPersonalCoachModel.id != ((PersonalCoachModel)paramArrayList.get(i)).id)
          continue;
        ((PersonalCoachModel)paramArrayList.get(i)).sendState = paramPersonalCoachModel.sendState;
      }
      return;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.minepresenter.MinePresenter1
 * JD-Core Version:    0.6.0
 */