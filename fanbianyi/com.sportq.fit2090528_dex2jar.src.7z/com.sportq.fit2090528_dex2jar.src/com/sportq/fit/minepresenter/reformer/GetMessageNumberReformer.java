package com.sportq.fit.minepresenter.reformer;

import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.model.MessageModel;

public class GetMessageNumberReformer extends BaseReformer
{
  public MessageModel messageModel;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.minepresenter.reformer.GetMessageNumberReformer
 * JD-Core Version:    0.6.0
 */