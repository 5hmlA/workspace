package com.sportq.fit.minepresenter;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.AndPushModel;
import com.sportq.fit.common.model.MessageModel;
import com.sportq.fit.common.model.NoticeModel;
import com.sportq.fit.common.model.NoticeWeekModel;
import com.sportq.fit.common.model.UserBaseInfoModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.WeightModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.reformer.HealthAndDietReformer;
import com.sportq.fit.common.reformer.LoginReformer;
import com.sportq.fit.common.reformer.MedalReformer;
import com.sportq.fit.common.reformer.MessageReformer;
import com.sportq.fit.common.reformer.NoticeReformer;
import com.sportq.fit.common.reformer.PlanRecommendReformer;
import com.sportq.fit.common.reformer.RankReformer;
import com.sportq.fit.common.reformer.TrainDetialsReformer;
import com.sportq.fit.common.reformer.TrainPhotoReformer;
import com.sportq.fit.common.reformer.TrainReformer;
import com.sportq.fit.common.reformer.UserBaseInfoReformer;
import com.sportq.fit.common.reformer.UserBusInfoReformer;
import com.sportq.fit.common.reformer.WeightReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.PreferencesTools;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.XUtilDB;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.minepresenter.commender.WeightCommender;
import com.sportq.fit.minepresenter.reformerImpl.GetMessageNumberImpl;
import com.sportq.fit.minepresenter.reformerImpl.UserBaseInfoReformerImpl;
import com.sportq.fit.minepresenter.reformerImpl.UserBusInfoReformerImpl;
import com.sportq.fit.supportlib.CommonUtils;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.xutils.db.Selector;
import org.xutils.db.sqlite.WhereBuilder;
import rx.Observable;
import rx.Subscriber;

public abstract class MinePresenter
  implements MinePresenterInterface
{
  public ApiInterface apiInterface;
  public FitInterfaceUtils.UIInitListener view;
  private WeightCommender weightCommender;

  private void getWeight(RequestModel paramRequestModel, String paramString1, String paramString2, Context paramContext, WeightCommender paramWeightCommender)
  {
    this.apiInterface.getWeight(paramRequestModel, paramContext).subscribe(new Subscriber(paramString1, paramWeightCommender)
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        WeightReformer localWeightReformer = new WeightReformer();
        localWeightReformer.dateToWeightReformer(paramResponseModel);
        XUtilDB.getInstance().addInfo(localWeightReformer._weightArray);
        if ("2".equals(this.val$dateType))
        {
          localWeightReformer.getWeightDateList(7, localWeightReformer.setShowArray(this.val$weightCommender.getAllSelectWeight()));
          if (MinePresenter.this.view != null)
            MinePresenter.this.view.getDataSuccess(localWeightReformer);
        }
        do
        {
          do
            return;
          while (!"1".equals(this.val$dateType));
          localWeightReformer.getWeightDateList(30, localWeightReformer.setShowArray(this.val$weightCommender.getAllSelectWeight()));
        }
        while (MinePresenter.this.view == null);
        MinePresenter.this.view.getDataSuccess(localWeightReformer);
      }
    });
  }

  public void addPhoneNumber(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.addPhoneNumber(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        LoginReformer localLoginReformer = new LoginReformer();
        localLoginReformer.tag = "1";
        MinePresenter.this.view.getDataSuccess(localLoginReformer);
      }
    });
  }

  public void checkPhoneNumber(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.checkPhoneNumber(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess("Y");
      }
    });
  }

  public Boolean checkTodayWeight()
  {
    checkWeightCommender();
    String str = DateUtils.getCurDateTime01();
    if (this.weightCommender.selectWeightCount(str) > 0L);
    for (boolean bool = true; ; bool = false)
      return Boolean.valueOf(bool);
  }

  public void checkWeightCommender()
  {
    if (this.weightCommender == null)
      this.weightCommender = new WeightCommender();
  }

  public void deleteTrainPhoto(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.deleteTrainPhoto(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess("");
      }
    });
  }

  public void exitLogin(Context paramContext)
  {
    this.apiInterface.exitLogin(paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if ((MinePresenter.this.view != null) && (paramThrowable != null))
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess("Y");
      }
    });
  }

  public void feedback(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.feedback(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess("Y");
      }
    });
  }

  public int getBackgroundColor(String paramString)
  {
    if (("MED02".equals(paramString)) || ("MED03".equals(paramString)))
      return 0;
    if ("MED12".equals(paramString))
      return 1;
    return 2;
  }

  public void getCollect(Context paramContext)
  {
  }

  public NoticeModel getDefaultModel(String paramString)
  {
    NoticeModel localNoticeModel = new NoticeModel();
    localNoticeModel.noticeTime = paramString;
    localNoticeModel.noticeOnOff = "1";
    localNoticeModel.showListOff = "0";
    String[] arrayOfString = { "一", "二", "三", "四", "五", "六", "日" };
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < arrayOfString.length; i++)
    {
      NoticeWeekModel localNoticeWeekModel = new NoticeWeekModel();
      localNoticeWeekModel.day = arrayOfString[i];
      localNoticeWeekModel.showOnOff = "1";
      localArrayList.add(localNoticeWeekModel);
    }
    localNoticeModel.weekList = localArrayList;
    return localNoticeModel;
  }

  public void getHealthAndDiet(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.getHealthAndDiet(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        HealthAndDietReformer localHealthAndDietReformer = new HealthAndDietReformer();
        localHealthAndDietReformer.dateToHealthAndDietformer(paramResponseModel);
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess(localHealthAndDietReformer);
      }
    });
  }

  public void getMedalSuccess(Context paramContext)
  {
    this.apiInterface.getMedal(paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        MedalReformer localMedalReformer = new MedalReformer();
        localMedalReformer.dateToMedalReformer(paramResponseModel);
        MinePresenter.this.view.getDataSuccess(localMedalReformer);
      }
    });
  }

  public void getMessageList(RequestModel paramRequestModel, String paramString, List<Object> paramList, Context paramContext)
  {
    paramRequestModel.flag = paramString;
    if ("1".equals(paramString))
    {
      String str2 = PreferencesTools.getValueToKey("messagetable", "messagekey" + BaseApplication.userModel.userId);
      if (!StringUtils.isNull(str2))
        paramRequestModel.historyId = str2;
      this.apiInterface.getMessageList(paramRequestModel, paramContext).subscribe(new Subscriber(paramRequestModel)
      {
        public void onCompleted()
        {
        }

        public void onError(Throwable paramThrowable)
        {
          if (MinePresenter.this.view != null)
            MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
        }

        public void onNext(ResponseModel paramResponseModel)
        {
          MessageReformer localMessageReformer = new MessageReformer();
          localMessageReformer.dateToMessagereformer(paramResponseModel);
          boolean bool;
          if (localMessageReformer._messageArray.size() >= 10)
          {
            bool = true;
            localMessageReformer.isArrowedFrash = bool;
            if (!StringUtils.isNull(this.val$requestModel.historyId))
              break label80;
          }
          label80: for (localMessageReformer.tag = "0"; ; localMessageReformer.tag = "1")
          {
            if (MinePresenter.this.view != null)
              MinePresenter.this.view.getDataSuccess(localMessageReformer);
            return;
            bool = false;
            break;
          }
        }
      });
      return;
    }
    if ((paramList != null) && (paramList.size() > 1) && (paramList.get(-1 + paramList.size()) != null));
    for (String str1 = ((MessageModel)(MessageModel)paramList.get(-1 + paramList.size())).msgId; ; str1 = "")
    {
      paramRequestModel.historyId = str1;
      break;
    }
  }

  public void getMessageNumber(RequestModel paramRequestModel, Context paramContext)
  {
    paramRequestModel.historyId = PreferencesTools.getValueToKey("messagetable", "messagetikey" + BaseApplication.userModel.userId);
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new GetMessageNumberImpl(paramContext));
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GET_MESSAGE_NUMBER);
      this.apiInterface.getHttp(str, paramContext, this.view, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("MedalPresenterImpl.getMessageNumber", localException);
    }
  }

  public void getMessageNumberC()
  {
    CommonUtils.deleteMyAllCache(EnumConstant.FitUrl.GET_MESSAGE_NUMBER);
  }

  public long getNoticeCount()
  {
    Selector localSelector = XUtilDB.getInstance().getDBSelector(NoticeModel.class).where("userId", "=", BaseApplication.userModel.userId);
    return XUtilDB.getInstance().getCount(localSelector);
  }

  public ArrayList<NoticeModel> getNoticeItems(int paramInt)
  {
    Selector localSelector1 = XUtilDB.getInstance().getDBSelector(NoticeModel.class);
    localSelector1.where("userId", "=", BaseApplication.userModel.userId);
    ArrayList localArrayList1 = (ArrayList)XUtilDB.getInstance().selectInfo(localSelector1);
    if (localArrayList1 == null)
    {
      if (paramInt == 1)
        return null;
      localArrayList1 = new ArrayList();
      localArrayList1.add(getDefaultModel("19:55"));
    }
    while (true)
    {
      return localArrayList1;
      Selector localSelector2 = XUtilDB.getInstance().getDBSelector(NoticeWeekModel.class);
      localSelector1.where("userId", "=", BaseApplication.userModel.userId);
      ArrayList localArrayList2 = (ArrayList)XUtilDB.getInstance().selectInfo(localSelector2);
      int i = 0;
      for (int j = 0; j < localArrayList1.size(); j++)
      {
        if (((NoticeModel)localArrayList1.get(j)).weekList == null)
          ((NoticeModel)localArrayList1.get(j)).weekList = new ArrayList();
        for (int k = 0; k < 7; k++)
        {
          ((NoticeModel)localArrayList1.get(j)).weekList.add(localArrayList2.get(i));
          i++;
        }
      }
    }
  }

  public void getNoticeItemsInfo()
  {
    Selector localSelector1 = XUtilDB.getInstance().getDBSelector(NoticeModel.class);
    localSelector1.where("userId", "=", BaseApplication.userModel.userId);
    ArrayList localArrayList1 = (ArrayList)XUtilDB.getInstance().selectInfo(localSelector1);
    if (localArrayList1 == null)
    {
      NoticeReformer localNoticeReformer1 = new NoticeReformer();
      localArrayList1 = new ArrayList();
      localArrayList1.add(getDefaultModel("19:55"));
      localNoticeReformer1.noticeList = localArrayList1;
      if (this.view != null)
        this.view.getDataSuccess(localNoticeReformer1);
      if (CompDeviceInfoUtils.checkNetwork())
        break label256;
      if (this.view != null)
        this.view.getDataSuccess(localArrayList1);
    }
    label256: NoticeReformer localNoticeReformer2;
    do
    {
      return;
      Selector localSelector2 = XUtilDB.getInstance().getDBSelector(NoticeWeekModel.class);
      localSelector2.where("userId", "=", BaseApplication.userModel.userId);
      ArrayList localArrayList2 = (ArrayList)XUtilDB.getInstance().selectInfo(localSelector2);
      int i = 0;
      for (int j = 0; j < localArrayList1.size(); j++)
      {
        if (((NoticeModel)localArrayList1.get(j)).weekList == null)
          ((NoticeModel)localArrayList1.get(j)).weekList = new ArrayList();
        for (int k = 0; k < 7; k++)
        {
          ((NoticeModel)localArrayList1.get(j)).weekList.add(localArrayList2.get(i));
          i++;
        }
      }
      break;
      if (localArrayList1 == null)
        break label294;
      localNoticeReformer2 = new NoticeReformer();
      localNoticeReformer2.noticeList = localArrayList1;
    }
    while (this.view == null);
    this.view.getDataSuccess(localNoticeReformer2);
    return;
    label294: this.apiInterface.getNoticeInfo().subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        NoticeReformer localNoticeReformer = new NoticeReformer();
        ArrayList localArrayList = new ArrayList();
        localArrayList.add(MinePresenter.this.getDefaultModel("19:55"));
        localNoticeReformer.noticeList = localArrayList;
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(localNoticeReformer);
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        NoticeReformer localNoticeReformer = new NoticeReformer();
        localNoticeReformer.changePushInfo(paramResponseModel);
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess(localNoticeReformer);
      }
    });
  }

  public String getPersonalBMI(String paramString1, String paramString2)
  {
    if (("未填写".equals(paramString2)) || ("未填写".equals(paramString1)) || (StringUtils.isNull(paramString1)) || (StringUtils.isNull(paramString2)))
      return "请确认身高体重";
    float f = Float.valueOf(paramString2).floatValue() / (Float.valueOf(paramString1).floatValue() / 100.0F) * (Float.valueOf(paramString1).floatValue() / 100.0F);
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Float.valueOf(f);
    return String.format("%.1f", arrayOfObject);
  }

  public void getPhoneCode(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.getVerification(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if ((MinePresenter.this.view != null) && (paramThrowable != null))
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess("Y");
      }
    });
  }

  public void getRankSuccess(Context paramContext)
  {
    this.apiInterface.getLevel(paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        RankReformer localRankReformer = new RankReformer();
        localRankReformer.dataToRankReformer(paramResponseModel);
        MinePresenter.this.view.getDataSuccess(localRankReformer);
      }
    });
  }

  public void getTrainDetails(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.getTrainDetails(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        TrainDetialsReformer localTrainDetialsReformer = new TrainDetialsReformer();
        localTrainDetialsReformer.dateToTrainDetialsReformer(paramResponseModel);
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess(localTrainDetialsReformer);
      }
    });
  }

  public void getTrainPhoto(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.getTrainPhoto(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        TrainPhotoReformer localTrainPhotoReformer = new TrainPhotoReformer();
        localTrainPhotoReformer.dateToPlanReformer(paramResponseModel);
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess(localTrainPhotoReformer);
      }
    });
  }

  public void getTrainPhotoAlbum(RequestModel paramRequestModel, Context paramContext)
  {
  }

  public void getTrainRecord(String paramString, Context paramContext, int paramInt)
  {
    RequestModel localRequestModel = new RequestModel();
    if (!StringUtils.isNull(paramString))
      localRequestModel.moveTime = paramString;
    this.apiInterface.getTrainRecord(localRequestModel, paramContext).subscribe(new Subscriber(paramInt)
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        TrainReformer localTrainReformer = new TrainReformer();
        localTrainReformer.dateToPlanReformer(paramResponseModel, this.val$monthIdex);
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess(localTrainReformer);
      }
    });
  }

  public void getUserInfo(Context paramContext)
  {
    ReformerImpl localReformerImpl = new ReformerImpl(new UserBusInfoReformerImpl());
    String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetUserBusInfo);
    localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetUserBusInfo);
    new ApiImpl().getHttp(str, paramContext, new FitInterfaceUtils.UIInitListener(paramContext)
    {
      public void fitOnClick(View paramView)
      {
      }

      public <T> void getDataFail(T paramT)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramT);
      }

      public <T> void getDataSuccess(T paramT)
      {
        if ((paramT instanceof UserBusInfoReformer))
        {
          UserBusInfoReformer localUserBusInfoReformer = (UserBusInfoReformer)paramT;
          ReformerImpl localReformerImpl = new ReformerImpl(new UserBaseInfoReformerImpl());
          String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetUserBaseInfo);
          localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetUserBaseInfo);
          new ApiImpl().getHttp(str, this.val$context, new FitInterfaceUtils.UIInitListener(localUserBusInfoReformer)
          {
            public void fitOnClick(View paramView)
            {
            }

            public <T> void getDataFail(T paramT)
            {
              if (MinePresenter.this.view != null)
                MinePresenter.this.view.getDataFail(paramT);
            }

            public <T> void getDataSuccess(T paramT)
            {
              UserBaseInfoReformer localUserBaseInfoReformer = (UserBaseInfoReformer)paramT;
              if (localUserBaseInfoReformer.entUserBaseInfo.userId != null)
              {
                localUserBaseInfoReformer.resetUserInfo();
                this.val$userBusInfoReformer.resetUserInfo();
                BaseApplication.userModel.isLogin = true;
              }
              if (MinePresenter.this.view != null)
                MinePresenter.this.view.getDataSuccess("Y");
              EventBus.getDefault().post("refresh.mine.page.data");
            }

            public void initLayout(Bundle paramBundle)
            {
            }

            public <T> void onRefresh(T paramT)
            {
            }
          }
          , localReformerImpl, new RequestModel());
        }
      }

      public void initLayout(Bundle paramBundle)
      {
      }

      public <T> void onRefresh(T paramT)
      {
      }
    }
    , localReformerImpl, new RequestModel());
  }

  public void getWeight(RequestModel paramRequestModel, String paramString1, String paramString2, Context paramContext)
  {
    if ((StringUtils.isNull(SharePreferenceUtils.getWeightFlgIndex(paramContext))) && (this.weightCommender.selectWeightCount("") > 0L))
    {
      XUtilDB.getInstance().deletInfo(WeightModel.class);
      SharePreferenceUtils.putWeightFlgIndex(paramContext);
    }
    WeightReformer localWeightReformer = new WeightReformer();
    if (this.weightCommender.selectWeightCount("") > 0L)
    {
      String str1 = DateUtils.getCurDateTime01();
      WeightModel localWeightModel = this.weightCommender.getFristWeigtDateString();
      String str2 = localWeightModel.recordDate;
      if (StringUtils.checkWeightDate(str1, str2) == 1)
      {
        paramRequestModel.recordDate = localWeightModel.recordDate;
        getWeight(paramRequestModel, paramString1, paramString2, paramContext, this.weightCommender);
      }
      label117: 
      do
      {
        do
          while (true)
          {
            break label117;
            do
              return;
            while (StringUtils.checkWeightDate(str1, str2) != 0);
            if (!"2".equals(paramString1))
              break;
            localWeightReformer.getWeightDateList(7, localWeightReformer.setShowArray(this.weightCommender.getAllSelectWeight()));
            if (this.view == null)
              continue;
            this.view.getDataSuccess(localWeightReformer);
            return;
          }
        while (!"1".equals(paramString1));
        localWeightReformer.getWeightDateList(30, localWeightReformer.setShowArray(this.weightCommender.getAllSelectWeight()));
      }
      while (this.view == null);
      this.view.getDataSuccess(localWeightReformer);
      return;
    }
    getWeight(paramRequestModel, paramString1, paramString2, paramContext, this.weightCommender);
  }

  public boolean password(String paramString1, String paramString2, Context paramContext)
  {
    if ((StringUtils.isNull(paramString1)) || (StringUtils.isNull(paramString2)))
    {
      ToastUtils.makeToast(paramContext, "请输入密码");
      return false;
    }
    if (!paramString2.equals(paramString1))
    {
      ToastUtils.makeToast(paramContext, "密码不一致，请重新输入");
      return false;
    }
    if ((paramString1.length() < 6) || (paramString1.length() > 20))
    {
      ToastUtils.makeToast(paramContext, "密码请控制在6-20位字符");
      return false;
    }
    if ((!StringUtils.checkPassword(paramString1)) || (!StringUtils.checkPassword(paramString2)))
    {
      ToastUtils.makeToast(paramContext, "密码仅支持数字，英文字母，下划线或横线");
      return false;
    }
    return true;
  }

  public void saveNoticeItemsInfo(Context paramContext, RequestModel paramRequestModel, List<NoticeModel> paramList, String paramString)
  {
    String str = standbyPushInfo(paramList);
    paramRequestModel.json = str;
    if (Constant.STR_0.equals(paramRequestModel.messageRemindFlag))
    {
      paramRequestModel.coachNotification = Constant.STR_0;
      paramRequestModel.systemRemindFlag = Constant.STR_0;
      paramRequestModel.reminderFlag = Constant.STR_0;
      paramRequestModel.commentRemindFlag = Constant.STR_0;
      paramRequestModel.likeRemindFlag = Constant.STR_0;
    }
    this.apiInterface.upNoticeInfo(paramRequestModel, paramString).subscribe(new Subscriber(paramList, paramContext, str)
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        MinePresenter.this.setNoticeItems(this.val$list);
        SharePreferenceUtils.putLocalPushInfo(this.val$context, this.val$json);
      }
    });
  }

  public void setGenDevReq(Context paramContext)
  {
    if (StringUtils.isNull(BaseApplication.userModel.userId));
    String[] arrayOfString;
    do
    {
      return;
      arrayOfString = SharePreferenceUtils.getPushUpInfo(paramContext);
    }
    while ((arrayOfString == null) && (arrayOfString.length < 4));
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.pushType = arrayOfString[0];
    localRequestModel.token = arrayOfString[1];
    this.apiInterface.genDevReq(localRequestModel, paramContext).subscribe(new Subscriber(paramContext)
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        SharePreferenceUtils.putPushInfoCheck(this.val$context, "");
      }
    });
  }

  public void setMinePresenter(FitInterfaceUtils.UIInitListener paramUIInitListener, ApiInterface paramApiInterface)
  {
    this.view = paramUIInitListener;
    this.apiInterface = paramApiInterface;
  }

  public void setNoticeItems(List<NoticeModel> paramList)
  {
    XUtilDB.getInstance().deletInfo(NoticeModel.class, WhereBuilder.b("userId", "=", BaseApplication.userModel.userId));
    XUtilDB.getInstance().deletInfo(NoticeWeekModel.class, WhereBuilder.b("userId", "=", BaseApplication.userModel.userId));
    XUtilDB.getInstance().addInfo(paramList);
    for (int i = 0; i < paramList.size(); i++)
    {
      ArrayList localArrayList = ((NoticeModel)paramList.get(i)).weekList;
      XUtilDB.getInstance().addInfo(localArrayList);
    }
  }

  public void setPassword(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.setPassword(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (MinePresenter.this.view != null)
          MinePresenter.this.view.getDataSuccess("Y");
      }
    });
  }

  public void setTodayWeight(String paramString)
  {
    String str = DateUtils.getCurDateTime01();
    if (this.weightCommender.selectWeightCount(str) > 0L)
    {
      this.weightCommender.updateWeightToday(str, paramString);
      return;
    }
    this.weightCommender.addWeightToday(str, paramString);
  }

  public String standbyPushInfo(List<NoticeModel> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      NoticeModel localNoticeModel = (NoticeModel)localIterator.next();
      AndPushModel localAndPushModel = new AndPushModel();
      localAndPushModel.userId = localNoticeModel.userId;
      localAndPushModel.openFlg = localNoticeModel.noticeOnOff;
      localAndPushModel.remindT = localNoticeModel.noticeTime;
      localAndPushModel.inputDate = DateUtils.getStrCurrentTimee();
      int i = 0;
      if (i < localNoticeModel.weekList.size())
      {
        NoticeWeekModel localNoticeWeekModel = (NoticeWeekModel)localNoticeModel.weekList.get(i);
        switch (i)
        {
        default:
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        }
        while (true)
        {
          i++;
          break;
          localAndPushModel.monFlg = localNoticeWeekModel.showOnOff;
          continue;
          localAndPushModel.tueFlg = localNoticeWeekModel.showOnOff;
          continue;
          localAndPushModel.webFlg = localNoticeWeekModel.showOnOff;
          continue;
          localAndPushModel.thuFlg = localNoticeWeekModel.showOnOff;
          continue;
          localAndPushModel.friFlg = localNoticeWeekModel.showOnOff;
          continue;
          localAndPushModel.satFlg = localNoticeWeekModel.showOnOff;
          continue;
          localAndPushModel.sunFlg = localNoticeWeekModel.showOnOff;
        }
      }
      localArrayList.add(localAndPushModel);
    }
    return new GsonBuilder().create().toJson(localArrayList);
  }

  public void statsHealthDietArticleClick(String paramString)
  {
  }

  public void statsTrainFeedBackUp(String paramString1, String paramString2)
  {
  }

  public void updateUserInfo(RequestModel paramRequestModel, Context paramContext)
  {
    this.apiInterface.updateUserInfo(paramRequestModel, paramContext).subscribe(new Subscriber()
    {
      public void onCompleted()
      {
      }

      public void onError(Throwable paramThrowable)
      {
        if ((MinePresenter.this.view != null) && (paramThrowable != null))
          MinePresenter.this.view.getDataFail(paramThrowable.getMessage());
      }

      public void onNext(ResponseModel paramResponseModel)
      {
        if (paramResponseModel.mineinfo.userId != null)
        {
          BaseApplication.userModel = paramResponseModel.mineinfo;
          BaseApplication.userModel.isLogin = true;
        }
        if (MinePresenter.this.view != null)
        {
          MinePresenter.this.view.getDataSuccess("Y");
          PlanRecommendReformer localPlanRecommendReformer = new PlanRecommendReformer();
          localPlanRecommendReformer.dataToPlanRecommendReformer(paramResponseModel);
          MinePresenter.this.view.getDataSuccess(localPlanRecommendReformer);
        }
      }
    });
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.minepresenter.MinePresenter
 * JD-Core Version:    0.6.0
 */