package com.sportq.fit.fitmoudle5.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle5.R.color;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.reformer.model.LesSectionDetModel;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class MasterSelectClassAdapter extends SuperAdapter<LesSectionDetModel>
{
  private int currentIndex;

  public MasterSelectClassAdapter(Context paramContext, List<LesSectionDetModel> paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, LesSectionDetModel paramLesSectionDetModel)
  {
    TextView localTextView1 = (TextView)paramSuperViewHolder.findViewById(R.id.section_num);
    TextView localTextView2 = (TextView)paramSuperViewHolder.findViewById(R.id.section_name);
    localTextView1.setText(String.valueOf(paramInt2 + 1));
    Context localContext1 = getContext();
    int i;
    int j;
    label85: int k;
    label126: LinearLayout.LayoutParams localLayoutParams;
    Context localContext4;
    float f;
    if (this.currentIndex == paramInt2)
    {
      i = R.color.color_313131;
      localTextView1.setTextColor(ContextCompat.getColor(localContext1, i));
      Context localContext2 = getContext();
      if (this.currentIndex != paramInt2)
        break label186;
      j = R.color.color_ffd208;
      localTextView1.setBackgroundColor(ContextCompat.getColor(localContext2, j));
      localTextView2.setText(paramLesSectionDetModel.title);
      Context localContext3 = getContext();
      if (this.currentIndex != paramInt2)
        break label194;
      k = R.color.color_ffd208;
      localTextView2.setTextColor(ContextCompat.getColor(localContext3, k));
      localLayoutParams = new LinearLayout.LayoutParams(-2, -2);
      localContext4 = getContext();
      if (paramInt2 != 0)
        break label202;
      f = 25.0F;
    }
    while (true)
    {
      localLayoutParams.topMargin = CompDeviceInfoUtils.convertOfDip(localContext4, f);
      return;
      i = R.color.color_ffd208;
      break;
      label186: j = R.color.color_313131;
      break label85;
      label194: k = R.color.white;
      break label126;
      label202: f = 0.0F;
    }
  }

  public void setCurrentIndex(int paramInt)
  {
    this.currentIndex = paramInt;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.adapter.MasterSelectClassAdapter
 * JD-Core Version:    0.6.0
 */