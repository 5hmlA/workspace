package com.sportq.fit.fitmoudle5.adapter;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.reformer.model.AllLessonModel;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

public class MasterCourseAdapter extends SuperAdapter<AllLessonModel>
{
  public MasterCourseAdapter(Context paramContext, List<AllLessonModel> paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, AllLessonModel paramAllLessonModel)
  {
    GlideUtils.loadImgByRadius(paramAllLessonModel.imageUrl, R.mipmap.img_default, 3.0F, (ImageView)paramSuperViewHolder.findViewById(R.id.master_class_img));
    ((TextView)paramSuperViewHolder.findViewById(R.id.item_title)).setText(paramAllLessonModel.title);
    ((TextView)paramSuperViewHolder.findViewById(R.id.item_desc)).setText(paramAllLessonModel.intr);
    TextView localTextView = (TextView)paramSuperViewHolder.findViewById(R.id.item_info);
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramAllLessonModel.courseNumber;
    localTextView.setText(String.format("%s节课", arrayOfObject));
    View localView = paramSuperViewHolder.findViewById(R.id.new_icon);
    if ("1".equals(paramAllLessonModel.isNewTag));
    for (int i = 0; ; i = 8)
    {
      localView.setVisibility(i);
      paramSuperViewHolder.findViewById(R.id.go_train_tv).setVisibility(0);
      return;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.adapter.MasterCourseAdapter
 * JD-Core Version:    0.6.0
 */