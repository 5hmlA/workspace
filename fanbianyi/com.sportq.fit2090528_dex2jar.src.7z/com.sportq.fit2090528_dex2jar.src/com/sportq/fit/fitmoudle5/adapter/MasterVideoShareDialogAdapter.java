package com.sportq.fit.fitmoudle5.adapter;

import android.content.Context;
import android.widget.ImageView;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.reformer.model.LesSectionDetModel;
import com.sportq.fit.fitmoudle5.widget.MasterSquareProgressView;
import com.sportq.fit.fitmoudle5.widget.MasterSquareProgressView.OnProgressChangeListener;
import java.util.List;
import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;
import org.greenrobot.eventbus.EventBus;

public class MasterVideoShareDialogAdapter extends SuperAdapter<LesSectionDetModel>
{
  private MasterSquareProgressView firstSquareProgressView;

  public MasterVideoShareDialogAdapter(Context paramContext, List<LesSectionDetModel> paramList, int paramInt)
  {
    super(paramContext, paramList, paramInt);
  }

  public void onBind(SuperViewHolder paramSuperViewHolder, int paramInt1, int paramInt2, LesSectionDetModel paramLesSectionDetModel)
  {
    MasterSquareProgressView localMasterSquareProgressView;
    if (!StringUtils.isNull(paramLesSectionDetModel.imageUrl))
    {
      GlideUtils.loadImgByDefault(paramLesSectionDetModel.imageUrl, R.mipmap.img_fit_logo, (ImageView)paramSuperViewHolder.findViewById(R.id.image));
      localMasterSquareProgressView = (MasterSquareProgressView)paramSuperViewHolder.findViewById(R.id.squareProgressBar);
      localMasterSquareProgressView.setTimeMillis(5000L);
      localMasterSquareProgressView.setOnProgressChangeListener(new MasterSquareProgressView.OnProgressChangeListener()
      {
        public void onFinished(MasterSquareProgressView paramMasterSquareProgressView)
        {
          EventBus.getDefault().post("event.next.video");
        }

        public void onProgressChange(MasterSquareProgressView paramMasterSquareProgressView, double paramDouble)
        {
        }
      });
      if (paramInt2 == 0)
      {
        localMasterSquareProgressView.start();
        this.firstSquareProgressView = localMasterSquareProgressView;
      }
    }
    else
    {
      return;
    }
    localMasterSquareProgressView.stop();
  }

  public void squareProgressViewPause()
  {
    if (this.firstSquareProgressView != null)
      this.firstSquareProgressView.pause();
  }

  public void squareProgressViewStart()
  {
    if (this.firstSquareProgressView != null)
      this.firstSquareProgressView.start();
  }

  public void squareProgressViewStop()
  {
    if (this.firstSquareProgressView != null)
      this.firstSquareProgressView.stop();
  }

  public void squareStopAndHide()
  {
    if (this.firstSquareProgressView != null)
    {
      this.firstSquareProgressView.stop();
      this.firstSquareProgressView.setVisibility(8);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.adapter.MasterVideoShareDialogAdapter
 * JD-Core Version:    0.6.0
 */