package com.sportq.fit.fitmoudle5.activity;

import android.view.View;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.event.CustomBannerJumpEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.fitmoudle5.reformer.model.AllLessonModel;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;

class MasterClassListActivity$2 extends FitAction
{
  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    EventBus.getDefault().post(new CustomBannerJumpEvent(this.this$0, this.val$allLessonModel.bannerType, this.val$allLessonModel.advLink));
    super.onClick(paramView);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterClassListActivity.2
 * JD-Core Version:    0.6.0
 */