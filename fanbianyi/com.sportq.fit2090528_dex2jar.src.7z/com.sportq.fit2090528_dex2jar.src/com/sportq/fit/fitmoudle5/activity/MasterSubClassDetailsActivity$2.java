package com.sportq.fit.fitmoudle5.activity;

import android.content.DialogInterface;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;

class MasterSubClassDetailsActivity$2
  implements FitInterfaceUtils.DialogListener
{
  public void onDialogClick(DialogInterface paramDialogInterface, int paramInt)
  {
    if (paramInt == -1)
      MasterSubClassDetailsActivity.access$200(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterSubClassDetailsActivity.2
 * JD-Core Version:    0.6.0
 */