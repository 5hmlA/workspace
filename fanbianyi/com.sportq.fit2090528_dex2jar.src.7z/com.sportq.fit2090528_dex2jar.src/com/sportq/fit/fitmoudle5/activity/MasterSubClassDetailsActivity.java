package com.sportq.fit.fitmoudle5.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.AppBarLayout.Behavior;
import android.support.design.widget.AppBarLayout.LayoutParams;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.CoordinatorLayout.Behavior;
import android.support.design.widget.CoordinatorLayout.LayoutParams;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.constant.EnumConstant.PageType;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.masterCache.MasterCacheDBManager;
import com.sportq.fit.common.utils.masterCache.MasterCacheManager;
import com.sportq.fit.common.utils.masterCache.MasterCacheModel;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle5.R.color;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.layout;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.R.string;
import com.sportq.fit.fitmoudle5.event.DownloadProEvent;
import com.sportq.fit.fitmoudle5.event.MasterPlayVideoEvent;
import com.sportq.fit.fitmoudle5.interfaces.MasterVideoListener;
import com.sportq.fit.fitmoudle5.presenter.MasterPlayerPresenter;
import com.sportq.fit.fitmoudle5.presenter.MasterPlayerPresenter.InitPlayListener;
import com.sportq.fit.fitmoudle5.presenter.Module5PresenterImpl;
import com.sportq.fit.fitmoudle5.reformer.LesSectionDetReformer;
import com.sportq.fit.fitmoudle5.reformer.MasterVideoReformer;
import com.sportq.fit.fitmoudle5.reformer.model.EntLesSectionDetModel;
import com.sportq.fit.fitmoudle5.reformer.model.LesSectionDetModel;
import com.sportq.fit.fitmoudle5.widget.player.MasterVideoPlayer;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.xutils.ex.DbException;

public class MasterSubClassDetailsActivity extends BaseActivity
  implements MasterVideoListener, MasterPlayerPresenter.InitPlayListener
{
  public static final String STR_LESSON_DES = "str.lessonDescribe";
  public static final String STR_LESSON_ID = "str.lessonId";
  public static final String STR_LESSON_IMG = "str.lessonImg";
  public static final String STR_LESSON_TITLE = "str.lessonTitle";
  public static final String STR_SECTION_ID = "str.sectionId";
  private AppBarLayout appBarLayout;
  private AppBarLayout.LayoutParams appBarParams;
  private CollapsingToolbarLayout collapsingToolbarLayout;
  private LinearLayout course_linear;
  private ImageView download_icon;
  private FrameLayout download_layout;
  private TextView download_pro;
  private EntLesSectionDetModel entLesSectionDet;
  private WebView knowledge_details;
  private LesSectionDetModel lesSectionDet;
  private String lessonId;
  private MasterVideoPlayer mVideoPlayer;
  private int offsetY = 0;
  private MasterPlayerPresenter presenter;
  private String sectionId;
  private TextView sub_class_info;
  private TextView sub_class_name;
  private Toolbar toolbar;
  private UseShareModel useShareModel;

  private void appBarOffsetY(int paramInt)
  {
    CoordinatorLayout.Behavior localBehavior = ((CoordinatorLayout.LayoutParams)this.appBarLayout.getLayoutParams()).getBehavior();
    if ((localBehavior instanceof AppBarLayout.Behavior))
    {
      AppBarLayout.Behavior localBehavior1 = (AppBarLayout.Behavior)localBehavior;
      this.offsetY = localBehavior1.getTopAndBottomOffset();
      if (this.offsetY != paramInt)
        localBehavior1.setTopAndBottomOffset(paramInt);
    }
  }

  private void cacheMasterVideo()
  {
    try
    {
      MasterCacheManager.getInstance().updateProgress(this.sectionId, 0);
      updateProgress();
      MasterCacheModel localMasterCacheModel = new MasterCacheModel();
      LesSectionDetModel localLesSectionDetModel = (LesSectionDetModel)this.entLesSectionDet.lstLesSection.get(this.entLesSectionDet.curPlayIndex);
      localMasterCacheModel.sectionId = localLesSectionDetModel.sectionId;
      localMasterCacheModel.imageUrl = localLesSectionDetModel.imageUrl;
      localMasterCacheModel.intrHtml = localLesSectionDetModel.intrHtml;
      localMasterCacheModel.title = localLesSectionDetModel.title;
      localMasterCacheModel.videoSize = localLesSectionDetModel.videoSize;
      localMasterCacheModel.videoTime = localLesSectionDetModel.videoTime;
      localMasterCacheModel.videoURL = localLesSectionDetModel.videoURL;
      MasterCacheManager.getInstance().downLoad(localMasterCacheModel, new MasterSubClassDetailsActivity.3(this, null, localMasterCacheModel));
      return;
    }
    catch (DbException localDbException)
    {
      LogUtils.e(localDbException);
      ToastUtils.makeToast("下载失败");
    }
  }

  private void initElements()
  {
    this.dialog = new DialogManager();
    this.mVideoPlayer = ((MasterVideoPlayer)findViewById(R.id.videoPlayer));
    this.mVideoPlayer.setContext(this);
    this.appBarLayout = ((AppBarLayout)findViewById(R.id.custom_appbar));
    this.collapsingToolbarLayout = ((CollapsingToolbarLayout)findViewById(R.id.custom_collapsing));
    this.appBarParams = ((AppBarLayout.LayoutParams)this.collapsingToolbarLayout.getLayoutParams());
    this.toolbar = ((Toolbar)findViewById(R.id.toolbar));
    this.toolbar.setNavigationIcon(R.mipmap.btn_back_white);
    this.toolbar.setTitle("");
    this.toolbar.setVisibility(4);
    setSupportActionBar(this.toolbar);
    this.appBarLayout = ((AppBarLayout)findViewById(R.id.custom_appbar));
    this.appBarLayout.addOnOffsetChangedListener(new MasterSubClassDetailsActivity.1(this));
    this.sub_class_name = ((TextView)findViewById(R.id.sub_class_name));
    this.sub_class_info = ((TextView)findViewById(R.id.sub_class_info));
    this.course_linear = ((LinearLayout)findViewById(R.id.course_linear));
    this.knowledge_details = ((WebView)findViewById(R.id.knowledge_details));
    this.download_icon = ((ImageView)findViewById(R.id.download_icon));
    this.download_layout = ((FrameLayout)findViewById(R.id.download_layout));
    this.download_pro = ((TextView)findViewById(R.id.download_pro));
  }

  private boolean isLandScape()
  {
    return getResources().getConfiguration().orientation == 2;
  }

  private void reStartAutoRotation()
  {
    new Handler().postDelayed(new MasterSubClassDetailsActivity.6(this), 1000L);
  }

  private void setDefault()
  {
    this.mVideoPlayer.setPageType(EnumConstant.PageType.SHRINK);
    this.mVideoPlayer.setVisibility(4);
    play();
    setRequestedOrientation(10);
    this.useShareModel = new UseShareModel();
    this.useShareModel.lessonId = this.lessonId;
    this.useShareModel.lessonTitle = getIntent().getStringExtra("str.lessonTitle");
    this.useShareModel.lessonDescribe = getIntent().getStringExtra("str.lessonDescribe");
    this.useShareModel.lessonImg = getIntent().getStringExtra("str.lessonImg");
  }

  private void setPageData()
  {
    this.lesSectionDet = ((LesSectionDetModel)this.entLesSectionDet.lstLesSection.get(this.entLesSectionDet.curPlayIndex));
    this.sub_class_name.setText(this.lesSectionDet.title);
    String str1 = "视频课程  •  " + StringUtils.convertTimeByVideo(this.lesSectionDet.videoTime);
    this.sub_class_info.setText(str1);
    this.course_linear.removeAllViews();
    int i = 0;
    if (i < this.entLesSectionDet.lstLesSection.size())
    {
      LesSectionDetModel localLesSectionDetModel = (LesSectionDetModel)this.entLesSectionDet.lstLesSection.get(i);
      View localView = View.inflate(this, R.layout.master_sub_class_details_item, null);
      float f1;
      label134: float f2;
      label163: ImageView localImageView;
      TextView localTextView;
      if (i == 0)
      {
        f1 = 20.0F;
        int j = CompDeviceInfoUtils.convertOfDip(this, f1);
        if (i != -1 + this.entLesSectionDet.lstLesSection.size())
          break label320;
        f2 = 20.0F;
        localView.setPadding(j, 0, CompDeviceInfoUtils.convertOfDip(this, f2), 0);
        localImageView = (ImageView)localView.findViewById(R.id.image_view);
        GlideUtils.loadImgByDefault(localLesSectionDetModel.imageUrl, R.mipmap.img_fit_logo, localImageView);
        localTextView = (TextView)localView.findViewById(R.id.index_tv);
        localTextView.setText(String.valueOf(i + 1));
        if (this.entLesSectionDet.curPlayIndex != i)
          break label326;
        localTextView.setTextColor(ContextCompat.getColor(this, R.color.color_313131));
        localTextView.setBackgroundColor(ContextCompat.getColor(this, R.color.color_ffd208));
      }
      while (true)
      {
        ((TextView)localView.findViewById(R.id.name_tv)).setText(localLesSectionDetModel.title);
        this.course_linear.addView(localView);
        localImageView.setOnClickListener(new MasterSubClassDetailsActivity.4(this, localLesSectionDetModel));
        i++;
        break;
        f1 = 10.0F;
        break label134;
        label320: f2 = 0.0F;
        break label163;
        label326: localTextView.setTextColor(ContextCompat.getColor(this, R.color.color_ffd208));
        localTextView.setBackgroundColor(ContextCompat.getColor(this, R.color.color_313131));
      }
    }
    this.lesSectionDet.intrHtml = this.lesSectionDet.intrHtml.replace("<img", "<img height=\"auto\"; width=\"100%\"");
    WebView localWebView = this.knowledge_details;
    String str2 = this.lesSectionDet.intrHtml;
    localWebView.loadDataWithBaseURL("about:blank", str2, "text/html", "utf-8", null);
    VdsAgent.loadDataWithBaseURL((View)localWebView, "about:blank", str2, "text/html", "utf-8", null);
    this.download_layout.setOnClickListener(new MasterSubClassDetailsActivity.5(this));
    updateProgress();
  }

  public void checkNetAndCacheVideo()
  {
    if (this.entLesSectionDet == null)
      return;
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      ToastUtils.makeToast(StringUtils.getStringResources(R.string.g_20_1));
      return;
    }
    if ("wifi".equals(CompDeviceInfoUtils.getNetType()))
    {
      cacheMasterVideo();
      return;
    }
    this.dialog.createChoiceDialog(new MasterSubClassDetailsActivity.2(this), this, "", "是否使用流量缓存视频?");
  }

  public void expand()
  {
    setRequestedOrientation(0);
    reStartAutoRotation();
  }

  public void finished()
  {
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if ((paramT instanceof LesSectionDetReformer))
    {
      this.entLesSectionDet = ((LesSectionDetReformer)paramT).entLesSectionDet;
      Iterator localIterator = this.entLesSectionDet.lstLesSection.iterator();
      while (localIterator.hasNext())
      {
        LesSectionDetModel localLesSectionDetModel = (LesSectionDetModel)localIterator.next();
        if (!this.sectionId.equals(localLesSectionDetModel.sectionId))
          continue;
        this.entLesSectionDet.curPlayIndex = this.entLesSectionDet.lstLesSection.indexOf(localLesSectionDetModel);
      }
      pause();
      this.mVideoPlayer.setVisibility(0);
      this.presenter = new MasterPlayerPresenter(this);
      this.presenter.initReformer(this.entLesSectionDet);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    this.lessonId = getIntent().getStringExtra("str.lessonId");
    this.sectionId = getIntent().getStringExtra("str.sectionId");
    if ((StringUtils.isNull(this.lessonId)) || (StringUtils.isNull(this.sectionId)))
    {
      finish();
      return;
    }
    setContentView(R.layout.master_sub_class_details);
    EventBus.getDefault().register(this);
    initElements();
    setDefault();
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.lessonId = getIntent().getStringExtra("str.lessonId");
    localRequestModel.sectionId = getIntent().getStringExtra("str.sectionId");
    new Module5PresenterImpl(this).getLesSectionDet(localRequestModel, this);
    EventBus.getDefault().post("sub.class.create");
  }

  public void initPlay(MasterVideoReformer paramMasterVideoReformer)
  {
    this.mVideoPlayer.hideShareDialog();
    setPageData();
    this.mVideoPlayer.initData(paramMasterVideoReformer, this);
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    if (getResources().getConfiguration().orientation == 2)
    {
      this.mVideoPlayer.setPageType(EnumConstant.PageType.EXPAND);
      appBarOffsetY(0);
      this.appBarParams.setScrollFlags(0);
    }
    do
    {
      this.collapsingToolbarLayout.setLayoutParams(this.appBarParams);
      return;
    }
    while (getResources().getConfiguration().orientation != 1);
    this.mVideoPlayer.setPageType(EnumConstant.PageType.SHRINK);
    appBarOffsetY(this.offsetY);
    AppBarLayout.LayoutParams localLayoutParams = this.appBarParams;
    boolean bool = this.mVideoPlayer.isPlaying();
    int i = 0;
    if (bool);
    while (true)
    {
      localLayoutParams.setScrollFlags(i);
      break;
      i = 3;
    }
  }

  protected void onDestroy()
  {
    removeCacheIfNeed();
    this.mVideoPlayer.destroy();
    this.knowledge_details.destroy();
    EventBus.getDefault().post("sub.class.destroy");
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe(threadMode=ThreadMode.MAIN)
  public void onEventMainThread(DownloadProEvent paramDownloadProEvent)
  {
    if (this.sectionId.equals(paramDownloadProEvent.sectionId))
    {
      if (paramDownloadProEvent.state == 1)
        MasterCacheManager.getInstance().updateProgress(this.sectionId, paramDownloadProEvent.strDownloadPro);
      updateProgress();
    }
  }

  @Subscribe(threadMode=ThreadMode.MAIN)
  public void onEventMainThread(MasterPlayVideoEvent paramMasterPlayVideoEvent)
  {
    Iterator localIterator = this.entLesSectionDet.lstLesSection.iterator();
    while (true)
    {
      int i;
      if (localIterator.hasNext())
      {
        LesSectionDetModel localLesSectionDetModel = (LesSectionDetModel)localIterator.next();
        if (!localLesSectionDetModel.sectionId.equals(paramMasterPlayVideoEvent.sectionId))
          continue;
        i = this.entLesSectionDet.lstLesSection.indexOf(localLesSectionDetModel);
        if (this.entLesSectionDet.curPlayIndex != i);
      }
      else
      {
        return;
      }
      this.entLesSectionDet.curPlayIndex = i;
      this.presenter.playNext(this.entLesSectionDet);
    }
  }

  @Subscribe(threadMode=ThreadMode.MAIN)
  public void onEventMainThread(String paramString)
  {
    int i = -1;
    switch (paramString.hashCode())
    {
    default:
    case -1654407037:
    case -1246678636:
    case 2091685203:
    }
    while (true)
      switch (i)
      {
      default:
        return;
        if (!paramString.equals("detail.event.finished"))
          continue;
        i = 0;
        continue;
        if (!paramString.equals("event.next.video"))
          continue;
        i = 1;
        continue;
        if (!paramString.equals("master.share"))
          continue;
        i = 2;
      case 0:
      case 1:
      case 2:
      }
    if (isLandScape())
    {
      this.mVideoPlayer.showShareDialog(this.presenter, this.useShareModel, this.dialog);
      this.mVideoPlayer.restore();
      return;
    }
    if (this.entLesSectionDet.curPlayIndex == -1 + this.entLesSectionDet.lstLesSection.size())
    {
      this.mVideoPlayer.restore();
      pause();
      return;
    }
    EntLesSectionDetModel localEntLesSectionDetModel2 = this.entLesSectionDet;
    localEntLesSectionDetModel2.curPlayIndex = (1 + localEntLesSectionDetModel2.curPlayIndex);
    this.presenter.playNext(this.entLesSectionDet);
    return;
    EntLesSectionDetModel localEntLesSectionDetModel1 = this.entLesSectionDet;
    localEntLesSectionDetModel1.curPlayIndex = (1 + localEntLesSectionDetModel1.curPlayIndex);
    this.presenter.playNext(this.entLesSectionDet);
    return;
    if (isLandScape())
    {
      this.mVideoPlayer.onPause();
      this.mVideoPlayer.showShareDialog(this.presenter, this.useShareModel, this.dialog);
      return;
    }
    this.dialog.showShareChoiseDialog(this, 33, this.useShareModel, this.dialog);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      if (!this.mVideoPlayer.isLandScape())
        break label21;
      shrink();
    }
    while (true)
    {
      return false;
      label21: finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      if (!isLandScape())
        break label48;
      shrink();
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      label48: finished();
    }
  }

  protected void onPause()
  {
    super.onPause();
    this.mVideoPlayer.onPause();
    this.mVideoPlayer.setActivityState("pause");
    if (isLandScape())
      if (!isLandScape())
        break label43;
    label43: for (int i = 0; ; i = 1)
    {
      setRequestedOrientation(i);
      return;
    }
  }

  protected void onResume()
  {
    super.onResume();
    if (this.mVideoPlayer != null)
    {
      this.mVideoPlayer.setActivityState("");
      if (!this.mVideoPlayer.reformer.isShareDialogShowing)
        this.mVideoPlayer.onResume();
    }
    reStartAutoRotation();
  }

  public void pause()
  {
    AppBarLayout.LayoutParams localLayoutParams = this.appBarParams;
    if (!isLandScape());
    for (int i = 3; ; i = 0)
    {
      localLayoutParams.setScrollFlags(i);
      this.collapsingToolbarLayout.setLayoutParams(this.appBarParams);
      return;
    }
  }

  public void play()
  {
    this.appBarParams.setScrollFlags(0);
    this.collapsingToolbarLayout.setLayoutParams(this.appBarParams);
    appBarOffsetY(0);
  }

  public void removeCacheIfNeed()
  {
    try
    {
      if (this.entLesSectionDet == null)
        return;
      Iterator localIterator = this.entLesSectionDet.lstLesSection.iterator();
      while (localIterator.hasNext())
      {
        LesSectionDetModel localLesSectionDetModel = (LesSectionDetModel)localIterator.next();
        if (MasterCacheDBManager.getIntance().selectCache(localLesSectionDetModel.sectionId) != null)
          continue;
        MasterCacheModel localMasterCacheModel = new MasterCacheModel();
        localMasterCacheModel.videoURL = localLesSectionDetModel.videoURL;
        MasterCacheManager.getInstance().deleteCache(localMasterCacheModel);
        MasterCacheManager.getInstance().deleteDownLoadFile(localMasterCacheModel);
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void shrink()
  {
    setRequestedOrientation(1);
    reStartAutoRotation();
  }

  public void updateProgress()
  {
    if (MasterCacheDBManager.getIntance().selectCache(this.lesSectionDet.sectionId) != null)
    {
      this.download_icon.setImageResource(R.mipmap.btn_download_grey);
      this.download_pro.setVisibility(0);
      this.download_pro.setText(getString(R.string.a_3_8));
      this.download_pro.setTextColor(ContextCompat.getColor(this, R.color.color_828282));
      this.download_layout.setClickable(false);
      return;
    }
    if (MasterCacheManager.getInstance().isDownloading(this.lesSectionDet.sectionId))
    {
      this.download_icon.setImageResource(R.mipmap.btn_download_black);
      this.download_pro.setVisibility(0);
      this.download_pro.setText(String.valueOf(MasterCacheManager.getInstance().getProgress(this.lesSectionDet.sectionId)) + "%");
      this.download_pro.setTextColor(ContextCompat.getColor(this, R.color.color_313131));
      this.download_layout.setClickable(false);
      return;
    }
    this.download_icon.setImageResource(R.mipmap.btn_download_black);
    this.download_pro.setVisibility(8);
    this.download_layout.setClickable(true);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterSubClassDetailsActivity
 * JD-Core Version:    0.6.0
 */