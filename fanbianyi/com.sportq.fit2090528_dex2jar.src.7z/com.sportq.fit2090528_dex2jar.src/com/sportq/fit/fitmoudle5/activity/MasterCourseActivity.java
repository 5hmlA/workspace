package com.sportq.fit.fitmoudle5.activity;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle5.R.color;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.layout;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.R.string;
import com.sportq.fit.fitmoudle5.adapter.MasterCourseAdapter;
import com.sportq.fit.fitmoudle5.presenter.Module5PresenterImpl;
import com.sportq.fit.fitmoudle5.reformer.AllLessonReformer;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class MasterCourseActivity extends BaseActivity
{
  private TextView empty_hint;
  private ImageView empty_icn;
  private LinearLayout empty_layout;
  private RecyclerView recyclerView;

  private void initElements()
  {
    this.recyclerView = ((RecyclerView)findViewById(R.id.master_class_recyclerView));
    this.empty_layout = ((LinearLayout)findViewById(R.id.empty_layout));
    this.empty_hint = ((TextView)findViewById(R.id.empty_hint));
    this.empty_icn = ((ImageView)findViewById(R.id.empty_icon));
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setAppTitle(R.string.b_1_1_6);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    localCustomToolBar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(localCustomToolBar);
    initEmptyLayout();
  }

  private void initEmptyLayout()
  {
    RTextView localRTextView = new RTextView(this);
    localRTextView.setText(R.string.b_1_1_8);
    localRTextView.getHelper().setCornerRadius(CompDeviceInfoUtils.convertOfDip(this, 20.0F));
    localRTextView.getHelper().setBackgroundColorNormal(ContextCompat.getColor(this, R.color.color_ffd208));
    localRTextView.setTextColor(getResources().getColor(R.color.color_313131));
    localRTextView.setTextSize(15.0F);
    localRTextView.setGravity(17);
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(CompDeviceInfoUtils.convertOfDip(this, 130.0F), CompDeviceInfoUtils.convertOfDip(this, 40.0F));
    localLayoutParams.topMargin = CompDeviceInfoUtils.convertOfDip(this, 30.0F);
    localLayoutParams.gravity = 1;
    this.empty_layout.addView(localRTextView, localLayoutParams);
    localRTextView.setOnClickListener(new MasterCourseActivity.3(this));
    this.empty_hint.setText("大师课程这么精彩，快去学习一下吧~");
    this.empty_icn.setImageResource(R.mipmap.master_class_no_data_icon);
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    AllLessonReformer localAllLessonReformer;
    if ((paramT instanceof AllLessonReformer))
    {
      localAllLessonReformer = (AllLessonReformer)paramT;
      if ((localAllLessonReformer.lstLesson == null) || (localAllLessonReformer.lstLesson.size() == 0))
      {
        this.empty_layout.setVisibility(0);
        this.recyclerView.setVisibility(8);
      }
    }
    else
    {
      return;
    }
    this.empty_layout.setVisibility(8);
    this.recyclerView.setVisibility(0);
    this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
    MasterCourseAdapter localMasterCourseAdapter = new MasterCourseAdapter(this, localAllLessonReformer.lstLesson, R.layout.master_class_item02);
    TextView localTextView = new TextView(this);
    localTextView.setText("购买更多课程");
    localTextView.setTextSize(15.0F);
    localTextView.setGravity(17);
    localTextView.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    localTextView.setTextColor(ContextCompat.getColor(this, R.color.color_626262));
    localTextView.setOnClickListener(new MasterCourseActivity.1(this));
    localMasterCourseAdapter.addFooterView(localTextView);
    localMasterCourseAdapter.getFooterView().getLayoutParams().height = CompDeviceInfoUtils.convertOfDip(this, 50.0F);
    localMasterCourseAdapter.setOnItemClickListener(new MasterCourseActivity.2(this, localAllLessonReformer));
    this.recyclerView.setAdapter(localMasterCourseAdapter);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.master_course_layout);
    EventBus.getDefault().register(this);
    initElements();
    new Module5PresenterImpl(this).getUserLesson(new RequestModel(), this);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("buy.master.success".equals(paramString))
      new Module5PresenterImpl(this).getUserLesson(new RequestModel(), this);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterCourseActivity
 * JD-Core Version:    0.6.0
 */