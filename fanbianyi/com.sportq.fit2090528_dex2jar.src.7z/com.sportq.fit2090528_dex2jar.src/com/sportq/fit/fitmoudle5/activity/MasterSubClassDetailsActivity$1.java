package com.sportq.fit.fitmoudle5.activity;

import android.support.design.widget.AppBarLayout;
import android.support.design.widget.AppBarLayout.OnOffsetChangedListener;
import android.support.v7.widget.Toolbar;
import com.sportq.fit.fitmoudle5.reformer.model.EntLesSectionDetModel;
import com.sportq.fit.fitmoudle5.reformer.model.LesSectionDetModel;
import java.util.ArrayList;

class MasterSubClassDetailsActivity$1
  implements AppBarLayout.OnOffsetChangedListener
{
  public void onOffsetChanged(AppBarLayout paramAppBarLayout, int paramInt)
  {
    if ((paramInt != 0) && (Math.abs(paramInt) >= paramAppBarLayout.getTotalScrollRange()))
    {
      if (MasterSubClassDetailsActivity.access$000(this.this$0) != null)
      {
        MasterSubClassDetailsActivity.access$100(this.this$0).setVisibility(0);
        MasterSubClassDetailsActivity.access$100(this.this$0).setTitle(((LesSectionDetModel)MasterSubClassDetailsActivity.access$000(this.this$0).lstLesSection.get(MasterSubClassDetailsActivity.access$000(this.this$0).curPlayIndex)).title);
      }
      return;
    }
    MasterSubClassDetailsActivity.access$100(this.this$0).setVisibility(4);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterSubClassDetailsActivity.1
 * JD-Core Version:    0.6.0
 */