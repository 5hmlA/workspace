package com.sportq.fit.fitmoudle5.activity;

import android.content.Intent;
import android.view.View;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle5.reformer.AllLessonReformer;
import com.sportq.fit.fitmoudle5.reformer.model.AllLessonModel;
import java.util.ArrayList;
import org.byteam.superadapter.OnItemClickListener;

class MasterCourseActivity$2
  implements OnItemClickListener
{
  public void onItemClick(View paramView, int paramInt1, int paramInt2)
  {
    Intent localIntent = new Intent(this.this$0, MasterClassDetailsActivity.class);
    localIntent.putExtra("lesson.id", ((AllLessonModel)this.val$masterCourseReformer.lstLesson.get(paramInt2)).lessonId);
    this.this$0.startActivity(localIntent);
    AnimationUtil.pageJumpAnim(this.this$0, 0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterCourseActivity.2
 * JD-Core Version:    0.6.0
 */