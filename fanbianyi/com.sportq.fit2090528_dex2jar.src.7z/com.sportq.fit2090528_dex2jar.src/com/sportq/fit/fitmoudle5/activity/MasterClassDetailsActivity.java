package com.sportq.fit.fitmoudle5.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.AppBarLayout.Behavior;
import android.support.design.widget.AppBarLayout.LayoutParams;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.CoordinatorLayout.Behavior;
import android.support.design.widget.CoordinatorLayout.LayoutParams;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.collection.GrowingIO;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.PageType;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.masterCache.MasterCacheDBManager;
import com.sportq.fit.common.utils.masterCache.MasterCacheManager;
import com.sportq.fit.common.utils.masterCache.MasterCacheModel;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout;
import com.sportq.fit.fitmoudle5.R.anim;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.layout;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.event.DownloadProEvent;
import com.sportq.fit.fitmoudle5.interfaces.MasterVideoListener;
import com.sportq.fit.fitmoudle5.presenter.MasterPlayerPresenter;
import com.sportq.fit.fitmoudle5.presenter.MasterPlayerPresenter.InitPlayListener;
import com.sportq.fit.fitmoudle5.presenter.Module5PresenterImpl;
import com.sportq.fit.fitmoudle5.reformer.LessonDetReformer;
import com.sportq.fit.fitmoudle5.reformer.MasterVideoReformer;
import com.sportq.fit.fitmoudle5.reformer.model.EntLessonDetModel;
import com.sportq.fit.fitmoudle5.utils.CacheManager;
import com.sportq.fit.fitmoudle5.widget.MasterClassBuyView;
import com.sportq.fit.fitmoudle5.widget.MasterViewPager;
import com.sportq.fit.fitmoudle5.widget.player.MasterVideoPlayer;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class MasterClassDetailsActivity extends BaseActivity
  implements MasterVideoListener, MasterPlayerPresenter.InitPlayListener
{
  public static final String LESSON_ID = "lesson.id";
  private AppBarLayout appBarLayout;
  private AppBarLayout.LayoutParams appBarParams;
  private CollapsingToolbarLayout collapsingToolbarLayout;
  private CustomTabLayout customTabLayout;
  private EntLessonDetModel entLessonDet;
  private boolean isSubClassExist = false;
  private MasterVideoPlayer mVideoPlayer;
  private MasterClassBuyView masterClassBuyView;
  private ImageView master_activity_icon;
  private FrameLayout master_activity_icon_layout;
  private int offsetY = 0;
  private MasterPlayerPresenter presenter;
  private Toolbar toolbar;
  private UseShareModel useShareModel;
  private MasterViewPager viewPager;
  private FrameLayout warning_view;

  private void appBarOffsetY(int paramInt)
  {
    CoordinatorLayout.Behavior localBehavior = ((CoordinatorLayout.LayoutParams)this.appBarLayout.getLayoutParams()).getBehavior();
    if ((localBehavior instanceof AppBarLayout.Behavior))
    {
      AppBarLayout.Behavior localBehavior1 = (AppBarLayout.Behavior)localBehavior;
      this.offsetY = localBehavior1.getTopAndBottomOffset();
      if (this.offsetY != paramInt)
        localBehavior1.setTopAndBottomOffset(paramInt);
    }
  }

  private void initView()
  {
    this.dialog = new DialogManager();
    this.mVideoPlayer = ((MasterVideoPlayer)findViewById(R.id.videoPlayer));
    this.mVideoPlayer.setContext(this);
    this.customTabLayout = ((CustomTabLayout)findViewById(R.id.custom_tab_layout));
    this.viewPager = ((MasterViewPager)findViewById(R.id.view_pager));
    this.viewPager.setNoScroll(true);
    this.appBarLayout = ((AppBarLayout)findViewById(R.id.custom_appbar));
    this.appBarLayout.addOnOffsetChangedListener(new MasterClassDetailsActivity.1(this));
    this.collapsingToolbarLayout = ((CollapsingToolbarLayout)findViewById(R.id.custom_collapsing));
    this.appBarParams = ((AppBarLayout.LayoutParams)this.collapsingToolbarLayout.getLayoutParams());
    this.masterClassBuyView = ((MasterClassBuyView)findViewById(R.id.master_class_buy_layout));
    this.warning_view = ((FrameLayout)findViewById(R.id.warning_view));
    this.master_activity_icon_layout = ((FrameLayout)findViewById(R.id.master_activity_icon_layout));
    this.master_activity_icon = ((ImageView)findViewById(R.id.master_activity_icon));
    this.toolbar = ((Toolbar)findViewById(R.id.toolbar));
    this.toolbar.setNavigationIcon(R.mipmap.btn_back_white);
    this.toolbar.setTitle("");
    this.toolbar.setVisibility(4);
    setSupportActionBar(this.toolbar);
    this.appBarLayout = ((AppBarLayout)findViewById(R.id.custom_appbar));
  }

  private boolean isLandScape()
  {
    return getResources().getConfiguration().orientation == 2;
  }

  private void reStartAutoRotation()
  {
    new Handler().postDelayed(new MasterClassDetailsActivity.2(this), 1000L);
  }

  private void setDefault()
  {
    this.mVideoPlayer.setPageType(EnumConstant.PageType.SHRINK);
    this.mVideoPlayer.setVisibility(4);
    play();
    this.masterClassBuyView.setVisibility(8);
    this.master_activity_icon.setVisibility(8);
  }

  public void expand()
  {
    setRequestedOrientation(0);
    reStartAutoRotation();
  }

  public void finished()
  {
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  public void fitOnClick(View paramView)
  {
    super.fitOnClick(paramView);
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof LessonDetReformer))
    {
      this.entLessonDet = ((LessonDetReformer)paramT).entLessonDet;
      this.useShareModel = new UseShareModel();
      this.useShareModel.lessonId = this.entLessonDet.lessonId;
      this.useShareModel.lessonTitle = this.entLessonDet.title;
      this.useShareModel.lessonDescribe = this.entLessonDet.intr;
      this.useShareModel.lessonImg = this.entLessonDet.imageUrl;
      this.presenter = new MasterPlayerPresenter(this);
      this.presenter.initReformer(this.entLessonDet);
      this.viewPager.initView(this.customTabLayout, this.entLessonDet);
      this.mVideoPlayer.showIntroView(this.entLessonDet.title, this.entLessonDet.intr);
      pause();
      if (!"0".equals(this.entLessonDet.isBuy))
        break label308;
      this.masterClassBuyView.setVisibility(0);
      this.masterClassBuyView.initView(this.entLessonDet);
      if (!StringUtils.isNull(this.entLessonDet.activityImgUrl))
        break label229;
      this.master_activity_icon.setVisibility(8);
    }
    while (true)
    {
      if (StringUtils.isNull(this.entLessonDet.videoURL))
        setRequestedOrientation(1);
      super.getDataSuccess(paramT);
      return;
      label229: int i = CompDeviceInfoUtils.convertOfDip(this, 15.0F);
      if ("1".equals(this.entLessonDet.freeFlg))
        i += (BaseApplication.screenWidth - CompDeviceInfoUtils.convertOfDip(this, 80.0F)) / 2;
      ((RelativeLayout.LayoutParams)this.master_activity_icon_layout.getLayoutParams()).rightMargin = i;
      this.master_activity_icon.setVisibility(0);
      GlideUtils.loadImgByAdjust(this.entLessonDet.activityImgUrl, this.master_activity_icon);
      continue;
      label308: this.master_activity_icon.setVisibility(8);
      this.masterClassBuyView.setVisibility(8);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.master_details_layout);
    EventBus.getDefault().register(this);
    GrowingIO.getInstance().setPageVariable(this, "page_name", "大师课程");
    initView();
    setDefault();
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.lessonId = getIntent().getStringExtra("lesson.id");
    new Module5PresenterImpl(this).getLessonDet(localRequestModel, this);
  }

  public void initPlay(MasterVideoReformer paramMasterVideoReformer)
  {
    this.mVideoPlayer.setVisibility(0);
    this.mVideoPlayer.initData(paramMasterVideoReformer, this);
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    int i = 8;
    super.onConfigurationChanged(paramConfiguration);
    if (getResources().getConfiguration().orientation == 2)
    {
      this.appBarParams.setScrollFlags(0);
      appBarOffsetY(0);
      this.masterClassBuyView.setVisibility(i);
      this.master_activity_icon.setVisibility(i);
      this.mVideoPlayer.setPageType(EnumConstant.PageType.EXPAND);
    }
    do
    {
      this.collapsingToolbarLayout.setLayoutParams(this.appBarParams);
      return;
    }
    while (getResources().getConfiguration().orientation != 1);
    AppBarLayout.LayoutParams localLayoutParams = this.appBarParams;
    int j;
    label105: int k;
    label144: ImageView localImageView;
    if (this.mVideoPlayer.isPlaying())
    {
      j = 0;
      localLayoutParams.setScrollFlags(j);
      appBarOffsetY(this.offsetY);
      MasterClassBuyView localMasterClassBuyView = this.masterClassBuyView;
      if (!"1".equals(this.entLessonDet.isBuy))
        break label195;
      k = i;
      localMasterClassBuyView.setVisibility(k);
      localImageView = this.master_activity_icon;
      if (!StringUtils.isNull(this.entLessonDet.activityImgUrl))
        break label201;
    }
    while (true)
    {
      localImageView.setVisibility(i);
      this.mVideoPlayer.setPageType(EnumConstant.PageType.SHRINK);
      break;
      j = 3;
      break label105;
      label195: k = 0;
      break label144;
      label201: i = 0;
    }
  }

  protected void onDestroy()
  {
    removeCacheIfNeed();
    CacheManager.destroy();
    this.mVideoPlayer.destroy();
    this.masterClassBuyView.onDestroy();
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe(threadMode=ThreadMode.MAIN)
  public void onEventMainThread(DownloadProEvent paramDownloadProEvent)
  {
    if (paramDownloadProEvent.state == 0)
      this.viewPager.downloadSuccessRefresh();
  }

  @Subscribe(threadMode=ThreadMode.MAIN)
  public void onEventMainThread(String paramString)
  {
    if ("sub.class.create".equals(paramString))
      this.isSubClassExist = true;
    do
    {
      while (true)
      {
        return;
        if ("sub.class.destroy".equals(paramString))
        {
          this.isSubClassExist = false;
          return;
        }
        if ("show.error.hint".equals(paramString))
        {
          showErrorHint();
          return;
        }
        if (!"detail.event.finished".equals(paramString))
          break;
        if (this.isSubClassExist)
          continue;
        if (isLandScape())
          this.mVideoPlayer.showShareDialog(this.presenter, this.useShareModel, this.dialog);
        this.mVideoPlayer.restore();
        this.mVideoPlayer.showIntroView(this.entLessonDet.title, this.entLessonDet.intr);
        pause();
        return;
      }
      if ("refresh.mine.page.data".equals(paramString))
      {
        this.entLessonDet.fcoinValue = BaseApplication.userModel.fcoinValue;
        this.masterClassBuyView.initView(this.entLessonDet);
        this.master_activity_icon.setVisibility(8);
        return;
      }
      if ("buy.master.success".equals(paramString))
      {
        this.entLessonDet.isBuy = "1";
        this.viewPager.refreshRightData();
        this.masterClassBuyView.setVisibility(8);
        this.master_activity_icon.setVisibility(8);
        return;
      }
      if (!"fcoin.buy.master.success".equals(paramString))
        continue;
      String str = String.valueOf(Float.valueOf(this.entLessonDet.fcoinValue).floatValue() - Float.valueOf(this.entLessonDet.fcoinPrice).floatValue());
      this.entLessonDet.fcoinValue = str;
      BaseApplication.userModel.fcoinValue = str;
      this.entLessonDet.isBuy = "1";
      this.viewPager.refreshRightData();
      this.masterClassBuyView.setVisibility(8);
      this.master_activity_icon.setVisibility(8);
      return;
    }
    while ((!"master.share".equals(paramString)) || (this.isSubClassExist));
    if (isLandScape())
    {
      this.mVideoPlayer.onPause();
      this.mVideoPlayer.showShareDialog(this.presenter, this.useShareModel, this.dialog);
      return;
    }
    this.dialog.showShareChoiseDialog(this, 33, this.useShareModel, this.dialog);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      if (!this.mVideoPlayer.isLandScape())
        break label21;
      shrink();
    }
    while (true)
    {
      return false;
      label21: finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      if (!isLandScape())
        break label48;
      shrink();
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      label48: finished();
    }
  }

  protected void onPause()
  {
    this.mVideoPlayer.onPause();
    this.mVideoPlayer.setActivityState("pause");
    if (isLandScape())
      if (!isLandScape())
        break label43;
    label43: for (int i = 0; ; i = 1)
    {
      setRequestedOrientation(i);
      super.onPause();
      return;
    }
  }

  protected void onResume()
  {
    if (this.mVideoPlayer != null)
    {
      this.mVideoPlayer.setActivityState("");
      if (!this.mVideoPlayer.reformer.isShareDialogShowing)
        this.mVideoPlayer.onResume();
    }
    reStartAutoRotation();
    super.onResume();
  }

  public void pause()
  {
    AppBarLayout.LayoutParams localLayoutParams = this.appBarParams;
    if (!isLandScape());
    for (int i = 3; ; i = 0)
    {
      localLayoutParams.setScrollFlags(i);
      this.collapsingToolbarLayout.setLayoutParams(this.appBarParams);
      return;
    }
  }

  public void play()
  {
    this.appBarParams.setScrollFlags(0);
    this.collapsingToolbarLayout.setLayoutParams(this.appBarParams);
    appBarOffsetY(0);
  }

  public void removeCacheIfNeed()
  {
    try
    {
      if ((this.entLessonDet != null) && (MasterCacheDBManager.getIntance().selectCache(this.entLessonDet.lessonId) == null))
      {
        MasterCacheModel localMasterCacheModel = new MasterCacheModel();
        localMasterCacheModel.videoURL = this.entLessonDet.videoURL;
        MasterCacheManager.getInstance().deleteCache(localMasterCacheModel);
        MasterCacheManager.getInstance().deleteDownLoadFile(localMasterCacheModel);
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void showErrorHint()
  {
    if (this.warning_view != null)
    {
      Animation localAnimation = AnimationUtils.loadAnimation(this, R.anim.roll_up);
      localAnimation.setFillAfter(true);
      this.warning_view.setAnimation(localAnimation);
      this.warning_view.setVisibility(0);
      new Handler().postDelayed(new MasterClassDetailsActivity.3(this), 2000L);
    }
  }

  public void shrink()
  {
    setRequestedOrientation(1);
    reStartAutoRotation();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterClassDetailsActivity
 * JD-Core Version:    0.6.0
 */