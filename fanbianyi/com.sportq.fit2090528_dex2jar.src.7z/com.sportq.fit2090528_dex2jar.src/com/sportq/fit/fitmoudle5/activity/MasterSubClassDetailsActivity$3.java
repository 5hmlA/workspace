package com.sportq.fit.fitmoudle5.activity;

import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.masterCache.MasterCacheDBManager;
import com.sportq.fit.common.utils.masterCache.MasterCacheManager;
import com.sportq.fit.common.utils.masterCache.MasterCacheModel;
import com.sportq.fit.fitmoudle5.event.DownloadProEvent;
import com.sportq.fit.supportlib.download.DownloadInfo;
import com.sportq.fit.supportlib.download.DownloadViewHolder;
import java.io.File;
import org.greenrobot.eventbus.EventBus;
import org.xutils.common.Callback.CancelledException;

class MasterSubClassDetailsActivity$3 extends DownloadViewHolder
{
  public void onCancelled(Callback.CancelledException paramCancelledException)
  {
    MasterCacheManager.getInstance().removeFromDownloadingSet(this.val$cacheModel.sectionId);
  }

  public void onError(Throwable paramThrowable, boolean paramBoolean)
  {
    MasterCacheManager.getInstance().removeFromDownloadingSet(this.val$cacheModel.sectionId);
    EventBus.getDefault().post(new DownloadProEvent(this.val$cacheModel.sectionId, 2));
  }

  public void onLoading(long paramLong1, long paramLong2)
  {
    LogUtils.d("缓存进度：", String.valueOf(paramLong2));
    int i = (int)(100.0F * ((float)paramLong2 / (float)paramLong1));
    EventBus.getDefault().post(new DownloadProEvent(this.val$cacheModel.sectionId, i, 1));
  }

  public void onStarted()
  {
  }

  public void onSuccess(File paramFile)
  {
    MasterCacheDBManager.getIntance().add(this.val$cacheModel);
    MasterCacheManager.getInstance().removeFromDownloadingSet(this.val$cacheModel.sectionId);
    EventBus.getDefault().post(new DownloadProEvent(this.val$cacheModel.sectionId, 0));
  }

  public void onWaiting()
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterSubClassDetailsActivity.3
 * JD-Core Version:    0.6.0
 */