package com.sportq.fit.fitmoudle5.activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle5.R.color;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.layout;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.R.string;
import com.sportq.fit.fitmoudle5.adapter.MasterClassListAdapter;
import com.sportq.fit.fitmoudle5.presenter.Module5PresenterImpl;
import com.sportq.fit.fitmoudle5.reformer.AllLessonReformer;
import com.sportq.fit.fitmoudle5.reformer.model.AllLessonModel;
import com.sportq.fit.fitmoudle5.widget.viewpager.CustomViewPager;
import com.sportq.fit.fitmoudle5.widget.viewpager.FixedSpeedScroller;
import java.lang.reflect.Field;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class MasterClassListActivity extends BaseActivity
{
  private MasterClassListAdapter adapter;
  private RecyclerView recycler_view;
  private TextView vPagerText;

  private void initElements()
  {
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setAppTitle(R.string.b_1_1_6);
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setToolbarBg(R.color.white);
    localCustomToolBar.setToolbarTitleColor(R.color.color_313131);
    setSupportActionBar(localCustomToolBar);
    this.recycler_view = ((RecyclerView)findViewById(R.id.recycler_view));
  }

  private View initHeaderView(View paramView, AllLessonReformer paramAllLessonReformer)
  {
    ArrayList localArrayList = new ArrayList();
    LinearLayout localLinearLayout = (LinearLayout)paramView.findViewById(R.id.page_index_layout);
    int i = (int)(0.552486D * BaseApplication.screenWidth);
    CustomViewPager localCustomViewPager = (CustomViewPager)paramView.findViewById(R.id.view_pager);
    RelativeLayout.LayoutParams localLayoutParams = new RelativeLayout.LayoutParams(BaseApplication.screenWidth, i);
    localCustomViewPager.setLayoutParams(localLayoutParams);
    localLinearLayout.removeAllViews();
    int j = 0;
    if (j < paramAllLessonReformer.lstBanner.size())
    {
      View localView = View.inflate(this, R.layout.master_class_viewpager_item, null);
      AllLessonModel localAllLessonModel = (AllLessonModel)paramAllLessonReformer.lstBanner.get(j);
      ImageView localImageView = (ImageView)localView.findViewById(R.id.scroll_image);
      GlideUtils.loadImgByDefault(localAllLessonModel.imageUrl, R.mipmap.img_default, localImageView);
      MasterClassListActivity.2 local2 = new MasterClassListActivity.2(this, this, localAllLessonModel);
      localImageView.setOnClickListener(local2);
      localArrayList.add(localView);
      TextView localTextView = new TextView(this);
      int k = CompDeviceInfoUtils.convertOfDip(this, 9.0F);
      int m = CompDeviceInfoUtils.convertOfDip(this, 7.0F);
      LinearLayout.LayoutParams localLayoutParams1;
      if (j != 0)
      {
        localLayoutParams1 = new LinearLayout.LayoutParams(m, m);
        localLayoutParams1.leftMargin = CompDeviceInfoUtils.convertOfDip(this, 8.0F);
        localTextView.setBackgroundResource(R.mipmap.icn_slider2);
      }
      while (true)
      {
        localLayoutParams1.gravity = 16;
        localTextView.setLayoutParams(localLayoutParams1);
        localLinearLayout.addView(localTextView);
        j++;
        break;
        localLayoutParams1 = new LinearLayout.LayoutParams(k, k);
        localTextView.setBackgroundResource(R.mipmap.icn_slider1);
        this.vPagerText = localTextView;
      }
    }
    if (localArrayList.size() > 0)
    {
      if (localArrayList.size() > 1)
      {
        CustomViewPagerAdapter localCustomViewPagerAdapter1 = new CustomViewPagerAdapter(localArrayList);
        localCustomViewPager.setAdapter(localCustomViewPagerAdapter1);
        localCustomViewPager.startScroll(localArrayList.size());
      }
    }
    else
      try
      {
        Field localField = ViewPager.class.getDeclaredField("mScroller");
        localField.setAccessible(true);
        FixedSpeedScroller localFixedSpeedScroller = new FixedSpeedScroller(this, new LinearInterpolator());
        localFixedSpeedScroller.setmDuration(100);
        localField.set(localCustomViewPager, localFixedSpeedScroller);
        MasterClassListActivity.MyOnPageChangeListener localMyOnPageChangeListener = new MasterClassListActivity.MyOnPageChangeListener(this, localArrayList, localFixedSpeedScroller, localLinearLayout);
        localCustomViewPager.addOnPageChangeListener(localMyOnPageChangeListener);
        return paramView;
      }
      catch (Exception localException)
      {
        LogUtils.e(localException);
        return paramView;
      }
    localLinearLayout.setVisibility(4);
    CustomViewPagerAdapter localCustomViewPagerAdapter2 = new CustomViewPagerAdapter(localArrayList);
    localCustomViewPager.setAdapter(localCustomViewPagerAdapter2);
    localCustomViewPager.setCurrentItem(0);
    return paramView;
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    AllLessonReformer localAllLessonReformer;
    if ((paramT instanceof AllLessonReformer))
    {
      localAllLessonReformer = (AllLessonReformer)paramT;
      if (this.adapter == null)
      {
        this.adapter = new MasterClassListAdapter(this, localAllLessonReformer.lstLesson, R.layout.master_class_item02);
        if ((localAllLessonReformer.lstBanner != null) && (localAllLessonReformer.lstBanner.size() != 0))
        {
          View localView4 = View.inflate(this, R.layout.master_class_item_broadcast, null);
          this.adapter.addHeaderView(initHeaderView(localView4, localAllLessonReformer));
        }
        View localView3 = new View(this);
        localView3.setBackgroundResource(R.color.color_f7f7f7);
        this.adapter.addFooterView(localView3);
        this.adapter.getFooterView().getLayoutParams().height = CompDeviceInfoUtils.convertOfDip(this, 10.0F);
        this.adapter.setOnItemClickListener(new MasterClassListActivity.1(this, localAllLessonReformer));
        this.recycler_view.setLayoutManager(new LinearLayoutManager(this));
        this.recycler_view.setAdapter(this.adapter);
      }
    }
    else
    {
      return;
    }
    View localView1;
    if ((localAllLessonReformer.lstBanner != null) && (localAllLessonReformer.lstBanner.size() != 0))
    {
      localView1 = this.adapter.getHeaderView();
      if (localView1 != null)
        break label239;
      View localView2 = View.inflate(this, R.layout.master_class_item_broadcast, null);
      this.adapter.addHeaderView(initHeaderView(localView2, localAllLessonReformer));
    }
    while (true)
    {
      this.adapter.replaceAll(localAllLessonReformer.lstLesson);
      return;
      label239: initHeaderView(localView1, localAllLessonReformer);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.master_class_list);
    EventBus.getDefault().register(this);
    initElements();
    new Module5PresenterImpl(this).getAllLesson(new RequestModel(), this);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("buy.master.success".equals(paramString))
      new Module5PresenterImpl(this).getAllLesson(new RequestModel(), this);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterClassListActivity
 * JD-Core Version:    0.6.0
 */