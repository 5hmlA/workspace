package com.sportq.fit.fitmoudle5.activity;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import com.sportq.fit.fitmoudle5.R.anim;

class MasterClassDetailsActivity$3
  implements Runnable
{
  public void run()
  {
    Animation localAnimation = AnimationUtils.loadAnimation(this.this$0, R.anim.roll_down);
    MasterClassDetailsActivity.access$200(this.this$0).startAnimation(localAnimation);
    MasterClassDetailsActivity.access$200(this.this$0).setVisibility(8);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.activity.MasterClassDetailsActivity.3
 * JD-Core Version:    0.6.0
 */