package com.sportq.fit.fitmoudle5.widget;

class MasterSquareProgressView$DrawStop
{
  private float location;
  private MasterSquareProgressView.Place place;

  public MasterSquareProgressView$DrawStop(MasterSquareProgressView paramMasterSquareProgressView)
  {
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.MasterSquareProgressView.DrawStop
 * JD-Core Version:    0.6.0
 */