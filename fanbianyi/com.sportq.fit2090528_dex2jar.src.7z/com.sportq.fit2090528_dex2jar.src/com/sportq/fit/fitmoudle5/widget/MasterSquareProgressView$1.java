package com.sportq.fit.fitmoudle5.widget;

import com.sportq.fit.common.utils.LogUtils;

class MasterSquareProgressView$1
  implements Runnable
{
  public void run()
  {
    MasterSquareProgressView.access$202(this.this$0, 0.5D + MasterSquareProgressView.access$200(this.this$0));
    MasterSquareProgressView.access$202(this.this$0, MasterSquareProgressView.access$300(this.this$0, MasterSquareProgressView.access$200(this.this$0)));
    if ((MasterSquareProgressView.access$200(this.this$0) > 0.0D) && (MasterSquareProgressView.access$200(this.this$0) < 100.0D))
    {
      this.this$0.setProgress(MasterSquareProgressView.access$200(this.this$0));
      LogUtils.d("SquareProgressView->run->progress:", String.valueOf(MasterSquareProgressView.access$200(this.this$0)));
      if (MasterSquareProgressView.access$400(this.this$0) != null)
        MasterSquareProgressView.access$400(this.this$0).onProgressChange(this.this$0, MasterSquareProgressView.access$200(this.this$0));
    }
    do
    {
      this.this$0.postDelayed(MasterSquareProgressView.access$500(this.this$0), MasterSquareProgressView.access$600(this.this$0) / 200L);
      do
        return;
      while (100.0D < MasterSquareProgressView.access$200(this.this$0));
      this.this$0.stop();
    }
    while (MasterSquareProgressView.access$400(this.this$0) == null);
    MasterSquareProgressView.access$400(this.this$0).onFinished(this.this$0);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.MasterSquareProgressView.1
 * JD-Core Version:    0.6.0
 */