package com.sportq.fit.fitmoudle5.widget.player;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatSeekBar;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.constant.EnumConstant.PageType;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.fitmoudle5.R.anim;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.layout;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.reformer.MasterVideoReformer;

public class MasterControllerView extends FrameLayout
{
  private AppCompatSeekBar action_seekBar;
  private ImageView btn_back;
  private ImageView btn_share;
  private LinearLayout controller_bottom_layout;
  private CustomTextView currentTime;
  private TextView master_title;
  protected SeekBar.OnSeekBarChangeListener onSeekBarChangeListener = new SeekBar.OnSeekBarChangeListener()
  {
    public void onProgressChanged(SeekBar paramSeekBar, int paramInt, boolean paramBoolean)
    {
      if ((MasterControllerView.this.videoPlayer.mediaPlayer != null) && (MasterControllerView.this.videoPlayer.reformer.duration > 0))
      {
        MasterControllerView.this.setCurrentTime(paramInt);
        long l = MasterControllerView.this.getPosition(paramInt);
        if (!MasterControllerView.this.videoPlayer.isProgressRunning)
          MasterControllerView.this.videoPlayer.reformer.currentPosition = l;
        LogUtils.d("onProgressChanged->currentPosition:", String.valueOf(l));
      }
    }

    public void onStartTrackingTouch(SeekBar paramSeekBar)
    {
      MasterControllerView.this.videoPlayer.progressTimerStop();
      MasterControllerView.this.videoPlayer.cancelHideTimer();
    }

    @Instrumented
    public void onStopTrackingTouch(SeekBar paramSeekBar)
    {
      VdsAgent.onStopTrackingTouch(this, paramSeekBar);
      MasterControllerView.this.videoPlayer.seekTo(MasterControllerView.this.videoPlayer.reformer.currentPosition);
      if (!MasterControllerView.this.videoPlayer.isPlaying())
        MasterControllerView.this.videoPlayer.play();
      MasterControllerView.this.videoPlayer.hideController();
    }
  };
  private ImageView playBtn;
  private ImageView portrait_change_btn;
  private ImageView portrait_pause_btn;
  private TextView select_class_btn;
  private CustomTextView totalTime;
  private BaseVideoPlayer videoPlayer;

  public MasterControllerView(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public MasterControllerView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public MasterControllerView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    addView(onCreateView());
  }

  private long getPosition(int paramInt)
  {
    if (this.videoPlayer.reformer.duration == 0)
      return 0L;
    return ()(paramInt / this.videoPlayer.reformer.duration * (float)this.videoPlayer.getDuration());
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), R.layout.master_controller_layout, null);
    this.btn_back = ((ImageView)localView.findViewById(R.id.btn_back));
    this.master_title = ((TextView)localView.findViewById(R.id.master_title));
    this.btn_share = ((ImageView)localView.findViewById(R.id.master_share_btn));
    this.playBtn = ((ImageView)localView.findViewById(R.id.playBtn));
    this.controller_bottom_layout = ((LinearLayout)localView.findViewById(R.id.controller_bottom_layout));
    this.portrait_pause_btn = ((ImageView)localView.findViewById(R.id.portrait_pause_btn));
    this.currentTime = ((CustomTextView)localView.findViewById(R.id.currentTime));
    this.action_seekBar = ((AppCompatSeekBar)localView.findViewById(R.id.action_seekBar));
    this.action_seekBar.setOnSeekBarChangeListener(this.onSeekBarChangeListener);
    this.totalTime = ((CustomTextView)localView.findViewById(R.id.totalTime));
    this.portrait_change_btn = ((ImageView)localView.findViewById(R.id.portrait_change_btn));
    this.select_class_btn = ((TextView)localView.findViewById(R.id.select_class_btn));
    return localView;
  }

  private int verifyProgress(int paramInt)
  {
    if (paramInt < 0)
      paramInt = 0;
    do
      return paramInt;
    while (paramInt <= this.videoPlayer.reformer.duration);
    return this.videoPlayer.reformer.duration;
  }

  public void expand()
  {
    this.portrait_pause_btn.setVisibility(8);
    this.portrait_change_btn.setVisibility(8);
    this.currentTime.setTextSize(14.0F);
    ((LinearLayout.LayoutParams)this.currentTime.getLayoutParams()).leftMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 20.0F);
    LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)this.action_seekBar.getLayoutParams();
    localLayoutParams.rightMargin = 0;
    localLayoutParams.leftMargin = 0;
    this.action_seekBar.setPadding(CompDeviceInfoUtils.convertOfDip(getContext(), 7.5F), 0, CompDeviceInfoUtils.convertOfDip(getContext(), 7.5F), 0);
    this.totalTime.setTextSize(14.0F);
    ((LinearLayout.LayoutParams)this.totalTime.getLayoutParams()).rightMargin = 0;
    this.select_class_btn.setVisibility(0);
    RelativeLayout.LayoutParams localLayoutParams1 = (RelativeLayout.LayoutParams)this.playBtn.getLayoutParams();
    int i = CompDeviceInfoUtils.convertOfDip(getContext(), 90.0F);
    localLayoutParams1.height = i;
    localLayoutParams1.width = i;
    this.playBtn.setVisibility(0);
  }

  public void hideBottomView()
  {
    this.controller_bottom_layout.setVisibility(8);
  }

  public void hideController()
  {
    startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_out));
    setVisibility(8);
  }

  public void hideTitle()
  {
    this.master_title.setVisibility(8);
  }

  public boolean isVisibility()
  {
    return getVisibility() == 0;
  }

  public void loadFail()
  {
    hideBottomView();
    this.btn_share.setVisibility(8);
    this.master_title.setVisibility(8);
  }

  public void setCurrentTime(int paramInt)
  {
    this.currentTime.setText(StringUtils.timeInt2Str(verifyProgress(paramInt)));
  }

  public void setListener(BaseVideoPlayer paramBaseVideoPlayer, View.OnClickListener paramOnClickListener)
  {
    this.videoPlayer = paramBaseVideoPlayer;
    this.btn_back.setOnClickListener(paramOnClickListener);
    this.btn_share.setOnClickListener(paramOnClickListener);
    this.playBtn.setOnClickListener(paramOnClickListener);
    this.portrait_pause_btn.setOnClickListener(paramOnClickListener);
    this.portrait_change_btn.setOnClickListener(paramOnClickListener);
    this.select_class_btn.setOnClickListener(paramOnClickListener);
  }

  public void setMax(int paramInt)
  {
    this.action_seekBar.setMax(paramInt);
  }

  public void setPageData(BaseVideoPlayer paramBaseVideoPlayer)
  {
    this.videoPlayer = paramBaseVideoPlayer;
    this.master_title.setText(this.videoPlayer.reformer.title);
    TextView localTextView1 = this.select_class_btn;
    boolean bool;
    TextView localTextView2;
    float f;
    if (!this.videoPlayer.reformer.isGuideVideo)
    {
      bool = true;
      localTextView1.setEnabled(bool);
      localTextView2 = this.select_class_btn;
      if (!this.videoPlayer.reformer.isGuideVideo)
        break label84;
      f = 0.4F;
    }
    while (true)
    {
      localTextView2.setAlpha(f);
      return;
      bool = false;
      break;
      label84: f = 1.0F;
    }
  }

  public void setPlayBtnState(boolean paramBoolean)
  {
    ImageView localImageView = this.playBtn;
    if (paramBoolean);
    for (int i = 0; ; i = 8)
    {
      localImageView.setVisibility(i);
      return;
    }
  }

  public void setSecondProgress(int paramInt)
  {
    this.action_seekBar.setSecondaryProgress(paramInt);
  }

  public void setSeekBarProgress(int paramInt)
  {
    this.action_seekBar.setProgress(verifyProgress(paramInt));
  }

  public void setTotalTime(int paramInt)
  {
    this.totalTime.setText(StringUtils.timeInt2Str(paramInt));
  }

  public void showController()
  {
    this.btn_share.setVisibility(0);
    this.master_title.setVisibility(0);
    this.controller_bottom_layout.setVisibility(0);
    setVisibility(0);
    startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_in));
  }

  public void shrink()
  {
    this.portrait_pause_btn.setVisibility(0);
    this.portrait_change_btn.setVisibility(0);
    this.currentTime.setTextSize(11.0F);
    ((LinearLayout.LayoutParams)this.currentTime.getLayoutParams()).leftMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 8.0F);
    LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)this.action_seekBar.getLayoutParams();
    int i = CompDeviceInfoUtils.convertOfDip(getContext(), 4.0F);
    localLayoutParams.rightMargin = i;
    localLayoutParams.leftMargin = i;
    this.action_seekBar.setPadding(CompDeviceInfoUtils.convertOfDip(getContext(), 6.0F), 0, CompDeviceInfoUtils.convertOfDip(getContext(), 6.0F), 0);
    this.totalTime.setTextSize(11.0F);
    ((LinearLayout.LayoutParams)this.totalTime.getLayoutParams()).rightMargin = CompDeviceInfoUtils.convertOfDip(getContext(), 11.0F);
    this.select_class_btn.setVisibility(8);
    ImageView localImageView = this.playBtn;
    if (this.videoPlayer.isInit());
    for (int j = 0; ; j = 8)
    {
      localImageView.setVisibility(j);
      RelativeLayout.LayoutParams localLayoutParams1 = (RelativeLayout.LayoutParams)this.playBtn.getLayoutParams();
      int k = CompDeviceInfoUtils.convertOfDip(getContext(), 50.0F);
      localLayoutParams1.height = k;
      localLayoutParams1.width = k;
      return;
    }
  }

  public void updatePlayBtnUI()
  {
    if (this.playBtn == null)
      return;
    ImageView localImageView;
    switch (2.$SwitchMap$com$sportq$fit$fitmoudle5$widget$player$BaseVideoPlayer$PlayState[this.videoPlayer.playState.ordinal()])
    {
    default:
      this.playBtn.setImageResource(R.mipmap.btn_play_landscape2);
      localImageView = this.playBtn;
      if ((!this.videoPlayer.isLoading()) && (this.videoPlayer.pageType != EnumConstant.PageType.SHRINK))
        break;
    case 1:
    case 2:
    case 3:
    }
    for (int i = 8; ; i = 0)
    {
      localImageView.setVisibility(i);
      return;
      this.playBtn.setImageResource(R.mipmap.btn_retry_landscape);
      break;
      this.playBtn.setImageResource(R.mipmap.btn_stop_landscape);
      this.portrait_pause_btn.setImageResource(R.mipmap.master_btn_pause);
      break;
      this.playBtn.setImageResource(R.mipmap.btn_play_landscape2);
      this.portrait_pause_btn.setImageResource(R.mipmap.mater_btn_play);
      break;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.player.MasterControllerView
 * JD-Core Version:    0.6.0
 */