package com.sportq.fit.fitmoudle5.widget;

import android.content.Context;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.AppBarLayout.Behavior;
import android.support.design.widget.CoordinatorLayout;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.OverScroller;
import java.lang.reflect.Field;

public class FixAppBarLayoutBehavior extends AppBarLayout.Behavior
{
  private static final String TAG = "AppBarLayoutBehavior";

  public FixAppBarLayoutBehavior()
  {
  }

  public FixAppBarLayoutBehavior(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  private Object getSuperSuperField(Object paramObject, String paramString)
  {
    try
    {
      Field localField = paramObject.getClass().getSuperclass().getSuperclass().getDeclaredField(paramString);
      localField.setAccessible(true);
      Object localObject = localField.get(paramObject);
      return localObject;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }

  public boolean onInterceptTouchEvent(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, MotionEvent paramMotionEvent)
  {
    if (paramMotionEvent.getAction() == 0)
    {
      Object localObject = getSuperSuperField(this, "mScroller");
      if ((localObject != null) && ((localObject instanceof OverScroller)))
        ((OverScroller)localObject).abortAnimation();
    }
    return super.onInterceptTouchEvent(paramCoordinatorLayout, paramAppBarLayout, paramMotionEvent);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.FixAppBarLayoutBehavior
 * JD-Core Version:    0.6.0
 */