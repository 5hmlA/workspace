package com.sportq.fit.fitmoudle5.widget.player;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import com.danikula.videocache.HttpProxyCacheServer;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle5.R.anim;
import com.sportq.fit.fitmoudle5.interfaces.MasterVideoListener;
import com.sportq.fit.fitmoudle5.reformer.MasterVideoReformer;
import com.sportq.fit.fitmoudle5.utils.CacheManager;
import com.sportq.fit.fitmoudle5.utils.SharePreferenceUtils5;
import java.util.Timer;
import tv.danmaku.ijk.media.player.IMediaPlayer;
import tv.danmaku.ijk.media.player.IMediaPlayer.OnInfoListener;

public class MasterVideoPlayer extends BaseVideoPlayer
{
  float mBrightnessData = -1.0F;
  private AudioManager.OnAudioFocusChangeListener onAudioFocusChangeListener = new AudioManager.OnAudioFocusChangeListener()
  {
    public void onAudioFocusChange(int paramInt)
    {
      switch (paramInt)
      {
      case -1:
      case 0:
      case 1:
      default:
      case -2:
      }
      do
        return;
      while (!MasterVideoPlayer.this.isPlaying());
      MasterVideoPlayer.this.pause();
    }
  };
  private IMediaPlayer.OnInfoListener onInfoListener;

  public MasterVideoPlayer(@NonNull Context paramContext)
  {
    this(paramContext, null);
  }

  public MasterVideoPlayer(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public MasterVideoPlayer(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, @AttrRes int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  public void dismissBrightnessDialog()
  {
    if ((this.mBrightnessDialog != null) && (this.mBrightnessDialog.getVisibility() == 0))
    {
      this.mBrightnessDialog.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_out));
      this.mBrightnessDialog.setVisibility(8);
      if ((getContext() instanceof Activity))
        SharePreferenceUtils5.putBrightness(getContext(), ((Activity)(Activity)getContext()).getWindow().getAttributes().screenBrightness);
    }
  }

  public void dismissVolumeDialog()
  {
    if ((this.mVolumeDialog != null) && (this.mVolumeDialog.getVisibility() == 0))
    {
      this.mVolumeDialog.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_out));
      this.mVolumeDialog.setVisibility(8);
    }
  }

  public AudioManager.OnAudioFocusChangeListener getOnAudioFocusChangeListener()
  {
    if (this.onAudioFocusChangeListener == null)
      this.onAudioFocusChangeListener = new AudioManager.OnAudioFocusChangeListener()
      {
        public void onAudioFocusChange(int paramInt)
        {
          switch (paramInt)
          {
          case -1:
          case 0:
          case 1:
          default:
          case -2:
          }
          do
            return;
          while (!MasterVideoPlayer.this.isPlaying());
          MasterVideoPlayer.this.pause();
        }
      };
    return this.onAudioFocusChangeListener;
  }

  public IMediaPlayer.OnInfoListener getOnInfoListener()
  {
    if (this.onInfoListener == null)
      this.onInfoListener = new IMediaPlayer.OnInfoListener()
      {
        public boolean onInfo(IMediaPlayer paramIMediaPlayer, int paramInt1, int paramInt2)
        {
          if (MasterVideoPlayer.this.reformer.isShareDialogShowing);
          do
            while (true)
            {
              return false;
              if (paramInt1 != 701)
                break;
              LogUtils.d("SptVideoPlayerOL->onInfo->", "MEDIA_INFO_BUFFERING_START");
              MasterVideoPlayer.this.progressTimerStop();
              if ((MasterVideoPlayer.this.isLandScape()) && (!SharePreferenceUtils5.getMasterVideoGuide(MasterVideoPlayer.this.getContext())))
                continue;
              MasterVideoPlayer.this.loading();
              return false;
            }
          while (paramInt1 != 702);
          LogUtils.d("SptVideoPlayerOL->onInfo->", "MEDIA_INFO_BUFFERING_END");
          MasterVideoPlayer.this.progressTimerStart();
          MasterVideoPlayer.this.loadFinish();
          return false;
        }
      };
    return this.onInfoListener;
  }

  public void initData(MasterVideoReformer paramMasterVideoReformer, MasterVideoListener paramMasterVideoListener)
  {
    this.reformer = paramMasterVideoReformer;
    this.listener = paramMasterVideoListener;
    if (this.reformer == null)
      this.reformer = new MasterVideoReformer();
    this.reformer.currentPosition = 0L;
    this.reformer.currentPlayTime = 0;
    this.reformer.isCompleted = false;
    this.reformer.isPrepared = false;
    this.playState = BaseVideoPlayer.PlayState.PLAY;
    this.mBlackView.setVisibility(0);
    releaseMediaPlayer();
    setTotalTime(this.reformer.duration);
    setProgress(0);
    this.progressTimer = new Timer();
    this.progressTimerTask = new BaseVideoPlayer.ProgressTimerTask(this);
    this.controllerView.setPlayBtnState(paramMasterVideoReformer.isShowPlayBtn);
    if (!CacheManager.getProxy().isCached(this.reformer.videoURL))
    {
      LogUtils.d("SptVideoPlayerOL->initData->", "当前视频没有缓存，如果有临时文件的话删除临时文件");
      CacheManager.deleteCacheDownFile(this.mContext, this.reformer.videoURL);
    }
    if (paramMasterVideoReformer.isCanPlay)
    {
      openVideo();
      return;
    }
    this.mBlackView.setVisibility(8);
    this.preview_img.setVisibility(0);
    GlideUtils.loadCacheImg(getContext(), paramMasterVideoReformer.imageUrl, this.preview_img);
  }

  public void showBrightnessDialog(float paramFloat)
  {
    this.mBrightnessData = ((Activity)this.mContext).getWindow().getAttributes().screenBrightness;
    WindowManager.LayoutParams localLayoutParams;
    if (this.mBrightnessData <= 0.0F)
    {
      this.mBrightnessData = 0.5F;
      LogUtils.d("MasterVpTouchHelper->onBrightnessSlide->percent:", String.valueOf(paramFloat));
      localLayoutParams = ((Activity)(Activity)this.mContext).getWindow().getAttributes();
      localLayoutParams.screenBrightness = (paramFloat + this.mBrightnessData);
      if (localLayoutParams.screenBrightness <= 1.0F)
        break label114;
      localLayoutParams.screenBrightness = 1.0F;
    }
    while (true)
    {
      if (this.mBrightnessDialog != null)
        break label135;
      return;
      if (this.mBrightnessData >= 0.01F)
        break;
      this.mBrightnessData = 0.01F;
      break;
      label114: if (localLayoutParams.screenBrightness >= 0.01F)
        continue;
      localLayoutParams.screenBrightness = 0.01F;
    }
    label135: if (this.mBrightnessDialog.getVisibility() == 8)
    {
      this.mBrightnessDialog.setVisibility(0);
      this.mBrightnessDialog.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_in));
    }
    LogUtils.d("SptVideoPlayerOL->showBrightnessDialog->screenBrightness:", String.valueOf(localLayoutParams.screenBrightness));
    this.mBrightnessProgress.setProgress((int)(100.0F * localLayoutParams.screenBrightness));
    ((Activity)(Activity)this.mContext).getWindow().setAttributes(localLayoutParams);
  }

  public void showVolumeDialog(float paramFloat, int paramInt)
  {
    if (this.mVolumeDialog == null)
      return;
    if (this.mVolumeDialog.getVisibility() == 8)
    {
      this.mVolumeDialog.setVisibility(0);
      this.mVolumeDialog.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_in));
    }
    this.mVolumeProgress.setProgress(paramInt);
    LogUtils.d("SptVideoPlayerOL->showVolumeDialog->volumePercent:", String.valueOf(paramInt));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.player.MasterVideoPlayer
 * JD-Core Version:    0.6.0
 */