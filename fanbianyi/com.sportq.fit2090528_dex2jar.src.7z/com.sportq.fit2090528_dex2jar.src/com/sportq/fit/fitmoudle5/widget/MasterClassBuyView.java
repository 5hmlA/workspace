package com.sportq.fit.fitmoudle5.widget;

import android.app.Dialog;
import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.sportq.fit.NdkUtils;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.logic.payutil.AlipayHandler;
import com.sportq.fit.common.logic.payutil.HuaweiPayHandler;
import com.sportq.fit.common.logic.payutil.OnPayListener;
import com.sportq.fit.common.logic.payutil.WechatPayHandler;
import com.sportq.fit.common.logic.payutil.WechatPayHandler.OnGetOrderIdListener;
import com.sportq.fit.common.model.EntErrorModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.persenter.PayPresenterImpl;
import com.sportq.fit.common.reformer.PayFcoinReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.CustomerServiceUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.BaseNavView;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle5.R.color;
import com.sportq.fit.fitmoudle5.R.id;
import com.sportq.fit.fitmoudle5.R.layout;
import com.sportq.fit.fitmoudle5.R.mipmap;
import com.sportq.fit.fitmoudle5.R.string;
import com.sportq.fit.fitmoudle5.R.style;
import com.sportq.fit.fitmoudle5.reformer.model.EntLessonDetModel;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class MasterClassBuyView extends BaseNavView
  implements OnPayListener, WechatPayHandler.OnGetOrderIdListener
{
  private AlipayHandler alipayHandler;
  ImageView btn_buy_close;
  TextView btn_confirm;
  private String buyType = "-1";
  private TextView commodity_name;
  private TextView commodity_real_price;
  private Dialog confirmBuyDialog;
  private DialogInterface dialog;
  private EntLessonDetModel entLessonDet;
  private TextView fb_num;
  FrameLayout fb_pay_layout;
  private ImageView fb_pay_select;
  private Dialog freeDialog;
  private ImageView free_close_btn;
  private ImageView free_img;
  private TextView free_open_wechat;
  private TextView free_replay;
  private TextView free_wechat_num;
  private HuaweiPayHandler huaweiPayHandler;
  FrameLayout huawei_pay_layout;
  private ImageView huawei_pay_select;
  TextView master_buy_btn;
  TextView master_free_btn;
  View master_service_layout;
  private String strVipOrderId;
  FrameLayout warning_view;
  private WechatPayHandler wechatPayHandler;
  FrameLayout wechat_pay_layout;
  private ImageView wechat_pay_select;
  FrameLayout zhifubao_pay_layout;
  private ImageView zhifubao_pay_select;

  public MasterClassBuyView(Context paramContext)
  {
    this(paramContext, null);
  }

  public MasterClassBuyView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    addView(onCreateView());
  }

  private void initBuyDialog()
  {
    this.confirmBuyDialog = new Dialog(getContext());
    this.confirmBuyDialog.requestWindowFeature(1);
    this.confirmBuyDialog.getWindow().setBackgroundDrawableResource(17170445);
    this.confirmBuyDialog.setContentView(R.layout.master_buy_confirm_layout);
    this.btn_buy_close = ((ImageView)this.confirmBuyDialog.findViewById(R.id.btn_buy_close));
    this.btn_buy_close.setOnClickListener(new FitAction(this));
    this.commodity_name = ((TextView)this.confirmBuyDialog.findViewById(R.id.commodity_name));
    this.commodity_real_price = ((TextView)this.confirmBuyDialog.findViewById(R.id.commodity_real_price));
    this.wechat_pay_layout = ((FrameLayout)this.confirmBuyDialog.findViewById(R.id.wechat_pay_layout));
    this.wechat_pay_layout.setOnClickListener(new FitAction(this));
    FrameLayout localFrameLayout1 = this.wechat_pay_layout;
    int i;
    int j;
    label228: FrameLayout localFrameLayout3;
    int k;
    if (CompDeviceInfoUtils.isHuaweiChannel())
    {
      i = 8;
      localFrameLayout1.setVisibility(i);
      this.wechat_pay_select = ((ImageView)this.confirmBuyDialog.findViewById(R.id.wechat_pay_select));
      this.zhifubao_pay_layout = ((FrameLayout)this.confirmBuyDialog.findViewById(R.id.zhifubao_pay_layout));
      this.zhifubao_pay_layout.setOnClickListener(new FitAction(this));
      FrameLayout localFrameLayout2 = this.zhifubao_pay_layout;
      if (!CompDeviceInfoUtils.isHuaweiChannel())
        break label483;
      j = 8;
      localFrameLayout2.setVisibility(j);
      this.zhifubao_pay_select = ((ImageView)this.confirmBuyDialog.findViewById(R.id.zhifubao_pay_select));
      this.huawei_pay_layout = ((FrameLayout)this.confirmBuyDialog.findViewById(R.id.huawei_pay_layout));
      this.huawei_pay_layout.setOnClickListener(new FitAction(this));
      localFrameLayout3 = this.huawei_pay_layout;
      boolean bool = CompDeviceInfoUtils.isHuaweiChannel();
      k = 0;
      if (!bool)
        break label489;
    }
    while (true)
    {
      localFrameLayout3.setVisibility(k);
      this.huawei_pay_select = ((ImageView)this.confirmBuyDialog.findViewById(R.id.huawei_pay_select));
      this.fb_pay_layout = ((FrameLayout)this.confirmBuyDialog.findViewById(R.id.fb_pay_layout));
      this.fb_pay_layout.setOnClickListener(new FitAction(this));
      this.fb_pay_select = ((ImageView)this.confirmBuyDialog.findViewById(R.id.fb_pay_select));
      this.fb_num = ((TextView)this.confirmBuyDialog.findViewById(R.id.fb_num));
      this.btn_confirm = ((TextView)this.confirmBuyDialog.findViewById(R.id.btn_confirm));
      this.btn_confirm.setOnClickListener(new FitAction(this));
      this.confirmBuyDialog.getWindow().setWindowAnimations(R.style.AnimBottom);
      WindowManager.LayoutParams localLayoutParams = this.confirmBuyDialog.getWindow().getAttributes();
      localLayoutParams.width = BaseApplication.screenWidth;
      localLayoutParams.gravity = 80;
      this.confirmBuyDialog.getWindow().setAttributes(localLayoutParams);
      return;
      i = 0;
      break;
      label483: j = 0;
      break label228;
      label489: k = 8;
    }
  }

  private void initFreeDialog()
  {
    this.freeDialog = new Dialog(getContext());
    this.freeDialog.requestWindowFeature(1);
    this.freeDialog.getWindow().setBackgroundDrawableResource(17170445);
    this.freeDialog.setContentView(R.layout.master_free_layout);
    this.free_close_btn = ((ImageView)this.freeDialog.findViewById(R.id.free_close_btn));
    this.free_close_btn.setOnClickListener(new FitAction(this));
    this.free_wechat_num = ((TextView)this.freeDialog.findViewById(R.id.free_wechat_num));
    this.free_replay = ((TextView)this.freeDialog.findViewById(R.id.free_replay));
    this.free_img = ((ImageView)this.freeDialog.findViewById(R.id.free_img));
    this.free_open_wechat = ((TextView)this.freeDialog.findViewById(R.id.free_open_wechat));
    this.free_open_wechat.setOnClickListener(new FitAction(this));
    this.freeDialog.getWindow().setWindowAnimations(R.style.AnimBottom);
    WindowManager.LayoutParams localLayoutParams = this.freeDialog.getWindow().getAttributes();
    localLayoutParams.width = BaseApplication.screenWidth;
    localLayoutParams.gravity = 80;
    this.freeDialog.getWindow().setAttributes(localLayoutParams);
  }

  private View onCreateView()
  {
    View localView = View.inflate(getContext(), R.layout.master_class_buy_layout, null);
    this.master_service_layout = localView.findViewById(R.id.master_service_layout);
    this.master_service_layout.setOnClickListener(new FitAction(this));
    this.master_buy_btn = ((TextView)localView.findViewById(R.id.master_buy_btn));
    this.master_buy_btn.setOnClickListener(new FitAction(this));
    this.master_free_btn = ((TextView)localView.findViewById(R.id.master_free_btn));
    this.master_free_btn.setOnClickListener(new FitAction(this));
    this.warning_view = ((FrameLayout)localView.findViewById(R.id.warning_view));
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    initBuyDialog();
    if (CompDeviceInfoUtils.isHuaweiChannel());
    for (String str = "2"; ; str = "0")
    {
      setBuyType(str);
      this.alipayHandler = new AlipayHandler(this, this);
      this.wechatPayHandler = new WechatPayHandler(this, this);
      this.huaweiPayHandler = new HuaweiPayHandler(this, getContext());
      this.huaweiPayHandler.setPayType("6");
      localView.setLayoutParams(new ViewGroup.LayoutParams(-1, CompDeviceInfoUtils.convertOfDip(getContext(), 55.0F)));
      return localView;
    }
  }

  private void payAction(String paramString)
  {
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.commodityId = this.entLessonDet.lessonId;
    localRequestModel.quantity = "1";
    String str = StringUtils.convertPrice02(this.entLessonDet.price);
    localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.entLessonDet.lessonId + NdkUtils.getSignBaseUrl()).toUpperCase();
    localRequestModel.callType = "6";
    int i = -1;
    switch (paramString.hashCode())
    {
    default:
    case 48:
    case 49:
    case 50:
    case 51:
    }
    while (true)
      switch (i)
      {
      default:
        return;
        if (!paramString.equals("0"))
          continue;
        i = 0;
        continue;
        if (!paramString.equals("1"))
          continue;
        i = 1;
        continue;
        if (!paramString.equals("2"))
          continue;
        i = 2;
        continue;
        if (!paramString.equals("3"))
          continue;
        i = 3;
      case 0:
      case 1:
      case 2:
      case 3:
      }
    localRequestModel.aliJson = this.alipayHandler.getAlipayReqParams(str, null, "Fit-大师课堂");
    this.alipayHandler.executeCallAlipay(getContext(), localRequestModel);
    return;
    localRequestModel.totalPrice = str;
    this.wechatPayHandler.executeCallWechatPay(getContext(), localRequestModel);
    return;
    localRequestModel.totalPrice = str;
    this.huaweiPayHandler.executeCallHuaweipay(localRequestModel);
    return;
    this.dialog.createProgressDialog(getContext(), "请稍后...");
    localRequestModel.callType = "0";
    localRequestModel.quantity = "";
    localRequestModel.fcoinPrice = this.entLessonDet.fcoinPrice;
    new PayPresenterImpl(this).payFcoin(localRequestModel, getContext());
  }

  private void setBuyType(String paramString)
  {
    if (this.buyType.equals(paramString))
      return;
    this.buyType = paramString;
    ImageView localImageView1 = this.zhifubao_pay_select;
    int i;
    int j;
    label68: int k;
    label99: ImageView localImageView4;
    if ("0".equals(this.buyType))
    {
      i = R.mipmap.comm_btn_selected;
      localImageView1.setImageResource(i);
      ImageView localImageView2 = this.wechat_pay_select;
      if (!"1".equals(this.buyType))
        break label202;
      j = R.mipmap.comm_btn_selected;
      localImageView2.setImageResource(j);
      ImageView localImageView3 = this.huawei_pay_select;
      if (!"2".equals(this.buyType))
        break label210;
      k = R.mipmap.comm_btn_selected;
      localImageView3.setImageResource(k);
      localImageView4 = this.fb_pay_select;
      if (!"3".equals(this.buyType))
        break label218;
    }
    label202: label210: label218: for (int m = R.mipmap.comm_btn_selected; ; m = R.mipmap.btn_normal)
    {
      localImageView4.setImageResource(m);
      if ((!"3".equals(paramString)) || (Float.valueOf(this.entLessonDet.fcoinPrice).floatValue() <= Float.valueOf(this.entLessonDet.fcoinValue).floatValue()))
        break label226;
      this.btn_confirm.setText(getContext().getString(R.string.b_38_10_1));
      return;
      i = R.mipmap.btn_normal;
      break;
      j = R.mipmap.btn_normal;
      break label68;
      k = R.mipmap.btn_normal;
      break label99;
    }
    label226: this.btn_confirm.setText(getContext().getString(R.string.b_38_5_6));
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.master_service_layout)
      CustomerServiceUtils.openServiceActivity(getContext(), 1214204L);
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() == R.id.master_buy_btn)
      {
        showBuyConfirmView();
        continue;
      }
      if (paramView.getId() == R.id.btn_buy_close)
      {
        this.confirmBuyDialog.dismiss();
        continue;
      }
      if (paramView.getId() == R.id.zhifubao_pay_layout)
      {
        setBuyType("0");
        continue;
      }
      if (paramView.getId() == R.id.wechat_pay_layout)
      {
        setBuyType("1");
        continue;
      }
      if (paramView.getId() == R.id.huawei_pay_layout)
      {
        setBuyType("2");
        continue;
      }
      if (paramView.getId() == R.id.fb_pay_layout)
      {
        setBuyType("3");
        continue;
      }
      if (paramView.getId() == R.id.btn_confirm)
      {
        if (getContext().getString(R.string.b_38_5_6).equals(this.btn_confirm.getText().toString()))
        {
          payAction(this.buyType);
          continue;
        }
        FitJumpImpl.getInstance().jumpFcoinAct(getContext());
        continue;
      }
      if (paramView.getId() == R.id.master_free_btn)
      {
        TextUtils.copyToClipboard(this.entLessonDet.wechatNum);
        showFreeView();
        continue;
      }
      if (paramView.getId() == R.id.free_close_btn)
      {
        this.freeDialog.dismiss();
        continue;
      }
      if (paramView.getId() != R.id.free_open_wechat)
        continue;
      CompDeviceInfoUtils.openWeixin(getContext());
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.dialog.closeDialog();
    if ((paramT instanceof String))
      ToastUtils.makeToast((String)paramT);
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    this.dialog.closeDialog();
    PayFcoinReformer localPayFcoinReformer;
    if ((paramT instanceof PayFcoinReformer))
    {
      localPayFcoinReformer = (PayFcoinReformer)paramT;
      if (!"Y".equals(localPayFcoinReformer.result))
        break label69;
      ToastUtils.makeToast(getContext().getString(R.string.b_38_7_1));
      EventBus.getDefault().post("buy.master.success");
      this.confirmBuyDialog.dismiss();
    }
    while (true)
    {
      super.getDataSuccess(paramT);
      return;
      label69: if (StringUtils.isNull(localPayFcoinReformer.entError.errorMessage))
        continue;
      ToastUtils.makeToast(localPayFcoinReformer.entError.errorMessage);
    }
  }

  public void initView(EntLessonDetModel paramEntLessonDetModel)
  {
    this.entLessonDet = paramEntLessonDetModel;
    this.commodity_name.setText(this.entLessonDet.title);
    TextView localTextView1 = this.master_buy_btn;
    Object[] arrayOfObject1 = new Object[1];
    arrayOfObject1[0] = this.entLessonDet.price;
    localTextView1.setText(String.format("加入学习 ¥%s", arrayOfObject1));
    TextView localTextView2 = this.commodity_real_price;
    Object[] arrayOfObject2 = new Object[2];
    arrayOfObject2[0] = this.entLessonDet.price;
    arrayOfObject2[1] = this.entLessonDet.fcoinPrice;
    localTextView2.setText(String.format("¥%s（%sF币）", arrayOfObject2));
    TextView localTextView3 = this.master_buy_btn;
    Context localContext1 = getContext();
    int i;
    int j;
    if ("1".equals(this.entLessonDet.freeFlg))
    {
      i = R.color.color_626262;
      localTextView3.setBackgroundColor(ContextCompat.getColor(localContext1, i));
      TextView localTextView4 = this.master_buy_btn;
      Context localContext2 = getContext();
      if (!"1".equals(this.entLessonDet.freeFlg))
        break label453;
      j = R.color.white;
      label175: localTextView4.setTextColor(ContextCompat.getColor(localContext2, j));
      TextView localTextView5 = this.fb_num;
      int k = R.string.b_38_5_5;
      String[] arrayOfString = new String[1];
      arrayOfString[0] = this.entLessonDet.fcoinValue;
      localTextView5.setText(UseStringUtils.getStr(k, arrayOfString));
      if ((!"3".equals(this.buyType)) || (Float.valueOf(this.entLessonDet.fcoinPrice).floatValue() <= Float.valueOf(this.entLessonDet.fcoinValue).floatValue()))
        break label461;
      this.btn_confirm.setText(getContext().getString(R.string.b_38_10_1));
    }
    while (true)
    {
      initFreeDialog();
      if (!"1".equals(this.entLessonDet.freeFlg))
        break label481;
      this.master_free_btn.setVisibility(0);
      Object[] arrayOfObject3 = new Object[1];
      arrayOfObject3[0] = paramEntLessonDetModel.wechatNum;
      SpannableString localSpannableString = new SpannableString(String.format("添加微信服务号:%s", arrayOfObject3));
      localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getContext(), R.color.color_ff6a49)), 8, localSpannableString.length(), 17);
      this.free_wechat_num.setText(localSpannableString);
      TextView localTextView6 = this.free_replay;
      Object[] arrayOfObject4 = new Object[2];
      arrayOfObject4[0] = paramEntLessonDetModel.wechatKeyword;
      arrayOfObject4[1] = paramEntLessonDetModel.title;
      localTextView6.setText(String.format("回复【%s】免费领取《%s》", arrayOfObject4));
      GlideUtils.loadImgByRadius(paramEntLessonDetModel.imageUrl, R.mipmap.img_default, 7.0F, this.free_img);
      return;
      i = R.color.color_ffd208;
      break;
      label453: j = R.color.color_313131;
      break label175;
      label461: this.btn_confirm.setText(getContext().getString(R.string.b_38_5_6));
    }
    label481: this.master_free_btn.setVisibility(8);
  }

  public void onDestroy()
  {
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("onResp".equals(paramString))
      if (this.wechatPayHandler != null)
      {
        RequestModel localRequestModel = new RequestModel();
        localRequestModel.orderId = this.strVipOrderId;
        localRequestModel.keySign = CompDeviceInfoUtils.generateMD5Encrypt(BaseApplication.userModel.userId + this.strVipOrderId + NdkUtils.getSignBaseUrl()).toUpperCase();
        this.wechatPayHandler.checkWechatPayResult(getContext(), localRequestModel);
      }
    do
      return;
    while ((!"onPayError".equals(paramString)) || (this.wechatPayHandler == null));
    this.wechatPayHandler.resetPayStatus();
  }

  public void onGetOrderId(String paramString)
  {
    if (paramString.contains("±"))
    {
      this.strVipOrderId = paramString.split("±")[1];
      return;
    }
    this.strVipOrderId = paramString;
  }

  public void onPayFail(int paramInt, String paramString)
  {
  }

  public void onPaySuccess(int paramInt)
  {
    ToastUtils.makeToast(getContext().getString(R.string.b_38_7_1));
    EventBus.getDefault().post("buy.master.success");
    this.confirmBuyDialog.dismiss();
  }

  public void showBuyConfirmView()
  {
    if (this.confirmBuyDialog == null)
      initBuyDialog();
    Dialog localDialog = this.confirmBuyDialog;
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }

  public void showFreeView()
  {
    if (this.freeDialog == null)
      initFreeDialog();
    Dialog localDialog = this.freeDialog;
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.MasterClassBuyView
 * JD-Core Version:    0.6.0
 */