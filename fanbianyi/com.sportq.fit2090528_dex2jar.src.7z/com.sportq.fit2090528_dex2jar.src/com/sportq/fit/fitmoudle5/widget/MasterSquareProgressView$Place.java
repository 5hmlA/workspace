package com.sportq.fit.fitmoudle5.widget;

public enum MasterSquareProgressView$Place
{
  static
  {
    RIGHT = new Place("RIGHT", 1);
    BOTTOM = new Place("BOTTOM", 2);
    LEFT = new Place("LEFT", 3);
    Place[] arrayOfPlace = new Place[4];
    arrayOfPlace[0] = TOP;
    arrayOfPlace[1] = RIGHT;
    arrayOfPlace[2] = BOTTOM;
    arrayOfPlace[3] = LEFT;
    $VALUES = arrayOfPlace;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.MasterSquareProgressView.Place
 * JD-Core Version:    0.6.0
 */