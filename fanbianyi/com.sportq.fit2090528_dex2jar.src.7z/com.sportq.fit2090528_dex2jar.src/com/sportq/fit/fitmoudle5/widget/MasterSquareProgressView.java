package com.sportq.fit.fitmoudle5.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle5.R.color;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class MasterSquareProgressView extends View
{
  public static final String EVENT_START = "SquareProgressView.start.event";
  public static final String EVENT_STOP = "SquareProgressView.stop.event";
  private Canvas canvas;
  private boolean centerLine = false;
  private boolean clearOnHundred = false;
  private int indeterminate_count = 1;
  private float indeterminate_width = 20.0F;
  private boolean isIndeterminate = false;
  private MasterSquareProgressView.OnProgressChangeListener onProgressChangeListener;
  private boolean outLine = false;
  private Paint outlinePaint;
  private double progress;
  private Paint progressBarPaint;
  private Runnable progressTaskRunnable = new MasterSquareProgressView.1(this);
  private boolean showProgress = false;
  private boolean startLine = false;
  private float strokeWidth = 0.0F;
  private Paint textPaint;
  private long timeMillis = 5000L;
  private float widthInDp = 2.0F;

  public MasterSquareProgressView(Context paramContext)
  {
    super(paramContext);
    initializePaints(paramContext);
  }

  public MasterSquareProgressView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    initializePaints(paramContext);
  }

  public MasterSquareProgressView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    initializePaints(paramContext);
  }

  private void drawCenterLine(float paramFloat)
  {
    float f = paramFloat / 2.0F;
    Path localPath = new Path();
    localPath.moveTo(f, f);
    localPath.lineTo(this.canvas.getWidth() - f, f);
    localPath.lineTo(this.canvas.getWidth() - f, this.canvas.getHeight() - f);
    localPath.lineTo(f, this.canvas.getHeight() - f);
    localPath.lineTo(f, f);
    this.canvas.drawPath(localPath, this.outlinePaint);
  }

  private void drawOutLine()
  {
    Path localPath = new Path();
    localPath.moveTo(0.0F, 0.0F);
    localPath.lineTo(this.canvas.getWidth(), 0.0F);
    localPath.lineTo(this.canvas.getWidth(), this.canvas.getHeight());
    localPath.lineTo(0.0F, this.canvas.getHeight());
    localPath.lineTo(0.0F, 0.0F);
    this.canvas.drawPath(localPath, this.outlinePaint);
  }

  private void drawStartLine()
  {
    Path localPath = new Path();
    localPath.moveTo(this.canvas.getWidth() / 2, 0.0F);
    localPath.lineTo(this.canvas.getWidth() / 2, this.strokeWidth);
    this.canvas.drawPath(localPath, this.outlinePaint);
  }

  private void initializePaints(Context paramContext)
  {
    this.progressBarPaint = new Paint();
    this.progressBarPaint.setColor(paramContext.getResources().getColor(R.color.color_ffd208));
    this.progressBarPaint.setStrokeWidth(CompDeviceInfoUtils.dipToPx(this.widthInDp));
    this.progressBarPaint.setAntiAlias(true);
    this.progressBarPaint.setStyle(Paint.Style.STROKE);
    this.outlinePaint = new Paint();
    this.outlinePaint.setColor(paramContext.getResources().getColor(17170444));
    this.outlinePaint.setStrokeWidth(1.0F);
    this.outlinePaint.setAntiAlias(true);
    this.outlinePaint.setStyle(Paint.Style.STROKE);
    this.textPaint = new Paint();
    this.textPaint.setColor(paramContext.getResources().getColor(17170444));
    this.textPaint.setAntiAlias(true);
    this.textPaint.setStyle(Paint.Style.STROKE);
  }

  private double validateProgress(double paramDouble)
  {
    if (paramDouble > 100.0D)
      paramDouble = 100.0D;
    do
      return paramDouble;
    while (paramDouble >= 0.0D);
    return 0.0D;
  }

  public MasterSquareProgressView.DrawStop getDrawEnd(float paramFloat, Canvas paramCanvas)
  {
    MasterSquareProgressView.DrawStop localDrawStop = new MasterSquareProgressView.DrawStop(this);
    this.strokeWidth = CompDeviceInfoUtils.dipToPx(this.widthInDp);
    float f1 = paramCanvas.getWidth();
    if (paramFloat > f1)
    {
      float f2 = paramFloat - f1;
      if (f2 > paramCanvas.getHeight())
      {
        float f3 = f2 - paramCanvas.getHeight();
        if (f3 > paramCanvas.getWidth())
        {
          float f4 = f3 - paramCanvas.getWidth();
          if (f4 > paramCanvas.getHeight())
          {
            float f5 = f4 - paramCanvas.getHeight();
            if (f5 == f1)
            {
              MasterSquareProgressView.DrawStop.access$002(localDrawStop, MasterSquareProgressView.Place.TOP);
              MasterSquareProgressView.DrawStop.access$102(localDrawStop, f1);
              return localDrawStop;
            }
            MasterSquareProgressView.DrawStop.access$002(localDrawStop, MasterSquareProgressView.Place.TOP);
            MasterSquareProgressView.DrawStop.access$102(localDrawStop, f5 + this.strokeWidth);
            return localDrawStop;
          }
          MasterSquareProgressView.DrawStop.access$002(localDrawStop, MasterSquareProgressView.Place.LEFT);
          MasterSquareProgressView.DrawStop.access$102(localDrawStop, paramCanvas.getHeight() - f4);
          return localDrawStop;
        }
        MasterSquareProgressView.DrawStop.access$002(localDrawStop, MasterSquareProgressView.Place.BOTTOM);
        MasterSquareProgressView.DrawStop.access$102(localDrawStop, paramCanvas.getWidth() - f3);
        return localDrawStop;
      }
      MasterSquareProgressView.DrawStop.access$002(localDrawStop, MasterSquareProgressView.Place.RIGHT);
      MasterSquareProgressView.DrawStop.access$102(localDrawStop, f2 + this.strokeWidth);
      return localDrawStop;
    }
    MasterSquareProgressView.DrawStop.access$002(localDrawStop, MasterSquareProgressView.Place.TOP);
    MasterSquareProgressView.DrawStop.access$102(localDrawStop, paramFloat);
    return localDrawStop;
  }

  public boolean isCenterLine()
  {
    return this.centerLine;
  }

  public boolean isClearOnHundred()
  {
    return this.clearOnHundred;
  }

  public boolean isIndeterminate()
  {
    return this.isIndeterminate;
  }

  public boolean isOutLine()
  {
    return this.outLine;
  }

  public boolean isStartLine()
  {
    return this.startLine;
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    EventBus.getDefault().register(this);
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    EventBus.getDefault().unregister(this);
  }

  protected void onDraw(Canvas paramCanvas)
  {
    this.canvas = paramCanvas;
    super.onDraw(paramCanvas);
    this.strokeWidth = CompDeviceInfoUtils.dipToPx(this.widthInDp);
    float f = paramCanvas.getWidth() + paramCanvas.getHeight() + paramCanvas.getHeight() + paramCanvas.getWidth() - this.strokeWidth;
    if (isOutLine())
      drawOutLine();
    if (isStartLine())
      drawStartLine();
    if (isCenterLine())
      drawCenterLine(this.strokeWidth);
    if (((isClearOnHundred()) && (this.progress == 100.0D)) || (this.progress <= 0.0D));
    Path localPath;
    MasterSquareProgressView.DrawStop localDrawStop1;
    do
    {
      return;
      localPath = new Path();
      if (isIndeterminate())
      {
        MasterSquareProgressView.DrawStop localDrawStop2 = getDrawEnd(f / 100.0F * Float.valueOf(String.valueOf(this.indeterminate_count)).floatValue(), paramCanvas);
        if (MasterSquareProgressView.DrawStop.access$000(localDrawStop2) == MasterSquareProgressView.Place.TOP)
        {
          localPath.moveTo(MasterSquareProgressView.DrawStop.access$100(localDrawStop2) - this.indeterminate_width - this.strokeWidth, this.strokeWidth / 2.0F);
          localPath.lineTo(MasterSquareProgressView.DrawStop.access$100(localDrawStop2), this.strokeWidth / 2.0F);
          paramCanvas.drawPath(localPath, this.progressBarPaint);
        }
        if (MasterSquareProgressView.DrawStop.access$000(localDrawStop2) == MasterSquareProgressView.Place.RIGHT)
        {
          localPath.moveTo(paramCanvas.getWidth() - this.strokeWidth / 2.0F, MasterSquareProgressView.DrawStop.access$100(localDrawStop2) - this.indeterminate_width);
          localPath.lineTo(paramCanvas.getWidth() - this.strokeWidth / 2.0F, this.strokeWidth + MasterSquareProgressView.DrawStop.access$100(localDrawStop2));
          paramCanvas.drawPath(localPath, this.progressBarPaint);
        }
        if (MasterSquareProgressView.DrawStop.access$000(localDrawStop2) == MasterSquareProgressView.Place.BOTTOM)
        {
          localPath.moveTo(MasterSquareProgressView.DrawStop.access$100(localDrawStop2) - this.indeterminate_width - this.strokeWidth, paramCanvas.getHeight() - this.strokeWidth / 2.0F);
          localPath.lineTo(MasterSquareProgressView.DrawStop.access$100(localDrawStop2), paramCanvas.getHeight() - this.strokeWidth / 2.0F);
          paramCanvas.drawPath(localPath, this.progressBarPaint);
        }
        if (MasterSquareProgressView.DrawStop.access$000(localDrawStop2) == MasterSquareProgressView.Place.LEFT)
        {
          localPath.moveTo(this.strokeWidth / 2.0F, MasterSquareProgressView.DrawStop.access$100(localDrawStop2) - this.indeterminate_width - this.strokeWidth);
          localPath.lineTo(this.strokeWidth / 2.0F, MasterSquareProgressView.DrawStop.access$100(localDrawStop2));
          paramCanvas.drawPath(localPath, this.progressBarPaint);
        }
        this.indeterminate_count = (1 + this.indeterminate_count);
        if (this.indeterminate_count > 100)
          this.indeterminate_count = 0;
        invalidate();
        return;
      }
      localDrawStop1 = getDrawEnd(f / 100.0F * Float.valueOf(String.valueOf(this.progress)).floatValue(), paramCanvas);
      LogUtils.d("SquareProgressView->onDraw->location:", "" + MasterSquareProgressView.DrawStop.access$100(localDrawStop1));
      if (MasterSquareProgressView.DrawStop.access$000(localDrawStop1) == MasterSquareProgressView.Place.TOP)
      {
        localPath.moveTo(0.0F, this.strokeWidth / 2.0F);
        localPath.lineTo(MasterSquareProgressView.DrawStop.access$100(localDrawStop1), this.strokeWidth / 2.0F);
        paramCanvas.drawPath(localPath, this.progressBarPaint);
      }
      if (MasterSquareProgressView.DrawStop.access$000(localDrawStop1) == MasterSquareProgressView.Place.RIGHT)
      {
        localPath.moveTo(0.0F, this.strokeWidth / 2.0F);
        localPath.lineTo(paramCanvas.getWidth() - this.strokeWidth / 2.0F, this.strokeWidth / 2.0F);
        localPath.lineTo(paramCanvas.getWidth() - this.strokeWidth / 2.0F, this.strokeWidth / 2.0F + MasterSquareProgressView.DrawStop.access$100(localDrawStop1));
        paramCanvas.drawPath(localPath, this.progressBarPaint);
      }
      if (MasterSquareProgressView.DrawStop.access$000(localDrawStop1) != MasterSquareProgressView.Place.BOTTOM)
        continue;
      localPath.moveTo(0.0F, this.strokeWidth / 2.0F);
      localPath.lineTo(paramCanvas.getWidth() - this.strokeWidth / 2.0F, this.strokeWidth / 2.0F);
      localPath.lineTo(paramCanvas.getWidth() - this.strokeWidth / 2.0F, paramCanvas.getHeight());
      localPath.moveTo(paramCanvas.getWidth(), paramCanvas.getHeight() - this.strokeWidth / 2.0F);
      localPath.lineTo(MasterSquareProgressView.DrawStop.access$100(localDrawStop1), paramCanvas.getHeight() - this.strokeWidth / 2.0F);
      paramCanvas.drawPath(localPath, this.progressBarPaint);
    }
    while (MasterSquareProgressView.DrawStop.access$000(localDrawStop1) != MasterSquareProgressView.Place.LEFT);
    localPath.moveTo(0.0F, this.strokeWidth / 2.0F);
    localPath.lineTo(paramCanvas.getWidth() - this.strokeWidth / 2.0F, this.strokeWidth / 2.0F);
    localPath.lineTo(paramCanvas.getWidth() - this.strokeWidth / 2.0F, paramCanvas.getHeight() - this.strokeWidth / 2.0F);
    localPath.lineTo(0.0F, paramCanvas.getHeight() - this.strokeWidth / 2.0F);
    localPath.moveTo(this.strokeWidth / 2.0F, paramCanvas.getHeight() - this.strokeWidth / 2.0F);
    localPath.lineTo(this.strokeWidth / 2.0F, MasterSquareProgressView.DrawStop.access$100(localDrawStop1));
    paramCanvas.drawPath(localPath, this.progressBarPaint);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("SquareProgressView.stop.event".equals(paramString))
      stop();
    do
      return;
    while (!"SquareProgressView.start.event".equals(paramString));
    start();
  }

  public void pause()
  {
    removeCallbacks(this.progressTaskRunnable);
  }

  public void setCenterLine(boolean paramBoolean)
  {
    this.centerLine = paramBoolean;
    invalidate();
  }

  public void setColor(int paramInt)
  {
    this.progressBarPaint.setColor(paramInt);
    invalidate();
  }

  public void setIndeterminate(boolean paramBoolean)
  {
    this.isIndeterminate = paramBoolean;
    invalidate();
  }

  public void setOnProgressChangeListener(MasterSquareProgressView.OnProgressChangeListener paramOnProgressChangeListener)
  {
    this.onProgressChangeListener = paramOnProgressChangeListener;
  }

  public void setProgress(double paramDouble)
  {
    this.progress = paramDouble;
    invalidate();
  }

  public void setTimeMillis(long paramLong)
  {
    this.timeMillis = paramLong;
  }

  public void setWidthInDp(int paramInt)
  {
    this.widthInDp = paramInt;
    this.progressBarPaint.setStrokeWidth(CompDeviceInfoUtils.dipToPx(this.widthInDp));
    invalidate();
  }

  public void start()
  {
    pause();
    post(this.progressTaskRunnable);
  }

  public void stop()
  {
    pause();
    this.progress = 0.0D;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.widget.MasterSquareProgressView
 * JD-Core Version:    0.6.0
 */