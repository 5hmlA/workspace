package com.sportq.fit.fitmoudle5.event;

public class DownloadProEvent
{
  public static final int ERROR = 2;
  public static final int LOADING = 1;
  public static final int SUCCESS;
  public String sectionId;
  public int state = 1;
  public int strDownloadPro;

  public DownloadProEvent(String paramString, int paramInt)
  {
    this.sectionId = paramString;
    this.state = paramInt;
  }

  public DownloadProEvent(String paramString, int paramInt1, int paramInt2)
  {
    this.sectionId = paramString;
    this.strDownloadPro = paramInt1;
    this.state = paramInt2;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.event.DownloadProEvent
 * JD-Core Version:    0.6.0
 */