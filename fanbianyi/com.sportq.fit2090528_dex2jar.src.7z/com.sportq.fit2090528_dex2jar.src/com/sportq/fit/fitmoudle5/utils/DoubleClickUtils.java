package com.sportq.fit.fitmoudle5.utils;

import android.view.MotionEvent;

public class DoubleClickUtils
{
  public static final int DEFAULT_DOUBLE_CLICK_SCOPE = 400;
  private long curClick;
  private long preClick;

  public boolean onDoubleClick(MotionEvent paramMotionEvent)
  {
    return onDoubleClick(paramMotionEvent, 400);
  }

  public boolean onDoubleClick(MotionEvent paramMotionEvent, int paramInt)
  {
    if (1 == paramMotionEvent.getAction())
    {
      this.curClick = System.currentTimeMillis();
      if (this.curClick - this.preClick < paramInt)
      {
        this.preClick = 0L;
        return true;
      }
      this.preClick = this.curClick;
    }
    return false;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.utils.DoubleClickUtils
 * JD-Core Version:    0.6.0
 */