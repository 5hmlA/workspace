package com.sportq.fit.fitmoudle5.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Window;
import android.view.WindowManager.LayoutParams;

public class SharePreferenceUtils5
{
  private static final String VIDEO_BRIGHTNESS = "video.brightness";
  private static final String VIDEO_GUIDE = "video.guide";

  public static void clearMasterVideoGuide(Context paramContext)
  {
    if (paramContext != null)
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("video.guide", 0).edit();
      localEditor.clear();
      localEditor.apply();
    }
  }

  public static float getBrightness(Context paramContext)
  {
    float f = 0.5F;
    if ((paramContext instanceof Activity))
      f = ((Activity)(Activity)paramContext).getWindow().getAttributes().screenBrightness;
    if (paramContext == null)
      return f;
    return paramContext.getSharedPreferences("video.brightness", 0).getFloat("video.brightness", f);
  }

  public static boolean getMasterVideoGuide(Context paramContext)
  {
    if (paramContext == null)
      return false;
    return paramContext.getSharedPreferences("video.guide", 0).getBoolean("video.guide", false);
  }

  public static void putBrightness(Context paramContext, float paramFloat)
  {
    if (paramContext != null)
    {
      if (paramFloat > 0.0F)
        break label43;
      paramFloat = 0.5F;
    }
    while (true)
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("video.brightness", 0).edit();
      localEditor.putFloat("video.brightness", paramFloat);
      localEditor.apply();
      return;
      label43: if (paramFloat >= 0.01F)
        continue;
      paramFloat = 0.01F;
    }
  }

  public static void putMasterVideoGuide(Context paramContext)
  {
    if (paramContext != null)
    {
      SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("video.guide", 0).edit();
      localEditor.putBoolean("video.guide", true);
      localEditor.apply();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.utils.SharePreferenceUtils5
 * JD-Core Version:    0.6.0
 */