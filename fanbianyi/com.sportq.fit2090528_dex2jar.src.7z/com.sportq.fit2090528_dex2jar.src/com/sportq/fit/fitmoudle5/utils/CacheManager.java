package com.sportq.fit.fitmoudle5.utils;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import com.danikula.videocache.HttpProxyCacheServer;
import com.danikula.videocache.HttpProxyCacheServer.Builder;
import com.danikula.videocache.ProxyCacheUtils;
import com.danikula.videocache.file.FileNameGenerator;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import java.io.File;

public class CacheManager
{
  private static File cacheFile;
  private static HttpProxyCacheServer proxy;

  public static void deleteAllMasterVideoCache()
  {
    try
    {
      File[] arrayOfFile = cacheFile.listFiles();
      int i = arrayOfFile.length;
      for (int j = 0; j < i; j++)
        arrayOfFile[j].delete();
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public static void deleteCacheDownFile(Context paramContext, String paramString)
  {
    try
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = cacheFile.getAbsolutePath();
      arrayOfObject[1] = new VideoFileNameGenerator().generate(paramString);
      File localFile = new File(String.format("%s/%s.download", arrayOfObject));
      LogUtils.d("CacheManager->deleteCacheDownFile->缓存视频路径", localFile.getAbsolutePath());
      localFile.delete();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public static void destroy()
  {
    if (proxy != null)
    {
      proxy.shutdown();
      proxy = null;
      System.gc();
    }
  }

  private static File getDiskCacheDir()
  {
    if (("mounted".equals(Environment.getExternalStorageState())) || (!Environment.isExternalStorageRemovable()))
      return BaseApplication.appliContext.getExternalCacheDir();
    return BaseApplication.appliContext.getCacheDir();
  }

  public static HttpProxyCacheServer getProxy()
  {
    if (proxy == null)
    {
      HttpProxyCacheServer localHttpProxyCacheServer = newProxy();
      proxy = localHttpProxyCacheServer;
      return localHttpProxyCacheServer;
    }
    return proxy;
  }

  private static HttpProxyCacheServer newProxy()
  {
    cacheFile = new File(VersionUpdateCheck.MASTER_CACHE_FILE_NAME);
    return new HttpProxyCacheServer.Builder(BaseApplication.appliContext).cacheDirectory(cacheFile).fileNameGenerator(new VideoFileNameGenerator()).maxCacheSize(1073741824L).build();
  }

  static class VideoFileNameGenerator
    implements FileNameGenerator
  {
    private static final int MAX_EXTENSION_LENGTH = 4;

    private String getExtension(String paramString)
    {
      int i = paramString.lastIndexOf('.');
      int j = paramString.lastIndexOf('/');
      if ((i != -1) && (i > j) && (4 + (i + 2) > paramString.length()))
        return paramString.substring(i + 1, paramString.length());
      return "";
    }

    private String getVideoName(String paramString)
    {
      int i = paramString.lastIndexOf("/");
      int j = paramString.lastIndexOf(getExtension(paramString));
      if ((i != -1) && (i < j - 1))
        return paramString.substring(i + 1, j - 1);
      return ProxyCacheUtils.computeMD5(paramString);
    }

    public String generate(String paramString)
    {
      String str1 = getExtension(paramString);
      String str2 = getVideoName(paramString);
      if (TextUtils.isEmpty(str1))
        return str2;
      return str2 + "." + str1;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.utils.CacheManager
 * JD-Core Version:    0.6.0
 */