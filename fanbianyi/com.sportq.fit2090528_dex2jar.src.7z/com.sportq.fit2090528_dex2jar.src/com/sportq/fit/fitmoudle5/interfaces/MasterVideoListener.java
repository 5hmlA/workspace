package com.sportq.fit.fitmoudle5.interfaces;

public abstract interface MasterVideoListener
{
  public abstract void expand();

  public abstract void finished();

  public abstract void pause();

  public abstract void play();

  public abstract void shrink();
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.interfaces.MasterVideoListener
 * JD-Core Version:    0.6.0
 */