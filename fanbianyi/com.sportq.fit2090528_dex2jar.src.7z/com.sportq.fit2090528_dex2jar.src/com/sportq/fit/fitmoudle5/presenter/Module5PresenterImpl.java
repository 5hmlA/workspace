package com.sportq.fit.fitmoudle5.presenter;

import android.content.Context;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.fitmoudle5.reformer.AllLessonReformerImpl;
import com.sportq.fit.fitmoudle5.reformer.LesSectionDetReformerImpl;
import com.sportq.fit.fitmoudle5.reformer.LessonDetReformerImpl;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;

public class Module5PresenterImpl
  implements Module5PresenterInterface
{
  private ApiInterface api = new ApiImpl();
  private FitInterfaceUtils.UIInitListener uiListener;

  public Module5PresenterImpl(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.uiListener = paramUIInitListener;
  }

  public void getAllLesson(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new AllLessonReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetAllLesson);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetAllLesson);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("Module5PresenterImpl.getAllLesson", localException);
    }
  }

  public void getLesSectionDet(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new LesSectionDetReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.GetLesSectionDet);
      localReformerImpl.getReformerInterface(EnumConstant.FitUrl.GetLesSectionDet);
      this.api.getHttp(str, paramContext, this.uiListener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("Module5PresenterImpl.getLesSectionDet", localException);
    }
  }

  public void getLessonDet(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetLessonDet);
      this.api.getHttp(str, paramContext, this.uiListener, new LessonDetReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("Module5PresenterImpl.getLessonDet", localException);
    }
  }

  public void getUserLesson(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      String str = new ReformerImpl().getURL(EnumConstant.FitUrl.GetUserLesson);
      this.api.getHttp(str, paramContext, this.uiListener, new AllLessonReformerImpl(), paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("Module5PresenterImpl.getUserLesson", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.presenter.Module5PresenterImpl
 * JD-Core Version:    0.6.0
 */