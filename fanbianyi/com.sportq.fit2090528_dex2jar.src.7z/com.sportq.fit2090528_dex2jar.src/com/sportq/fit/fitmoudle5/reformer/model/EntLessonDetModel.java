package com.sportq.fit.fitmoudle5.reformer.model;

import java.io.Serializable;
import java.util.ArrayList;

public class EntLessonDetModel
  implements Serializable
{
  public String activityImgUrl;
  public String courseNumber;
  public String fcoinPrice;
  public String fcoinValue;
  public String freeFlg;
  public String imageUrl;
  public String intr;
  public String intrUrl;
  public String isBuy;
  public String isNewTag;
  public String lessonId;
  public ArrayList<LstLesSectionModel> lstLesSection;
  public String price;
  public String title;
  public String videoTime;
  public String videoURL;
  public String wechatKeyword;
  public String wechatNum;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.model.EntLessonDetModel
 * JD-Core Version:    0.6.0
 */