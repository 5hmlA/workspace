package com.sportq.fit.fitmoudle5.reformer.model;

import java.io.Serializable;

public class DownloadUrlModel
  implements Serializable
{
  public String linkSize;
  public String linkUrl;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.model.DownloadUrlModel
 * JD-Core Version:    0.6.0
 */