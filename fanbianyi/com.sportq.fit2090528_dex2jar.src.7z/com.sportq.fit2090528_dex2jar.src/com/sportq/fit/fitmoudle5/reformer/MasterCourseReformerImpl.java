package com.sportq.fit.fitmoudle5.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle5.reformer.data.AllLessonData;
import com.sportq.fit.fitmoudle5.reformer.model.AllLessonBaseModel;

public class MasterCourseReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    AllLessonReformer localAllLessonReformer;
    if (paramBaseData == null)
      localAllLessonReformer = null;
    AllLessonData localAllLessonData;
    do
    {
      return localAllLessonReformer;
      localAllLessonData = (AllLessonData)paramBaseData;
      localAllLessonReformer = new AllLessonReformer();
    }
    while (localAllLessonData.entAllLesson == null);
    localAllLessonReformer.lstLesson = localAllLessonData.entAllLesson.lstLesson;
    return localAllLessonReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (AllLessonData)FitGsonFactory.create().fromJson(paramString2, AllLessonData.class), paramBoolean);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.MasterCourseReformerImpl
 * JD-Core Version:    0.6.0
 */