package com.sportq.fit.fitmoudle5.reformer.model;

import java.io.Serializable;
import java.util.ArrayList;

public class EntLesSectionDetModel
  implements Serializable
{
  public int curPlayIndex;
  public String imageUrl;
  public String intrHtml;
  public ArrayList<LesSectionDetModel> lstLesSection;
  public String sectionId;
  public String title;
  public String videoSize;
  public String videoTime;
  public String videoURL;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle5.reformer.model.EntLesSectionDetModel
 * JD-Core Version:    0.6.0
 */