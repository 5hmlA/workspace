package com.sportq.fit.v25.design;

import android.view.animation.Interpolator;

class ValueAnimatorCompat
{
  private final ValueAnimatorCompat.Impl mImpl;

  ValueAnimatorCompat(ValueAnimatorCompat.Impl paramImpl)
  {
    this.mImpl = paramImpl;
  }

  public void addListener(ValueAnimatorCompat.AnimatorListener paramAnimatorListener)
  {
    if (paramAnimatorListener != null)
    {
      this.mImpl.addListener(new ValueAnimatorCompat.2(this, paramAnimatorListener));
      return;
    }
    this.mImpl.addListener(null);
  }

  public void addUpdateListener(AnimatorUpdateListener paramAnimatorUpdateListener)
  {
    if (paramAnimatorUpdateListener != null)
    {
      this.mImpl.addUpdateListener(new ValueAnimatorCompat.1(this, paramAnimatorUpdateListener));
      return;
    }
    this.mImpl.addUpdateListener(null);
  }

  public void cancel()
  {
    this.mImpl.cancel();
  }

  public void end()
  {
    this.mImpl.end();
  }

  public float getAnimatedFloatValue()
  {
    return this.mImpl.getAnimatedFloatValue();
  }

  public float getAnimatedFraction()
  {
    return this.mImpl.getAnimatedFraction();
  }

  public int getAnimatedIntValue()
  {
    return this.mImpl.getAnimatedIntValue();
  }

  public long getDuration()
  {
    return this.mImpl.getDuration();
  }

  public boolean isRunning()
  {
    return this.mImpl.isRunning();
  }

  public void setDuration(long paramLong)
  {
    this.mImpl.setDuration(paramLong);
  }

  public void setFloatValues(float paramFloat1, float paramFloat2)
  {
    this.mImpl.setFloatValues(paramFloat1, paramFloat2);
  }

  public void setIntValues(int paramInt1, int paramInt2)
  {
    this.mImpl.setIntValues(paramInt1, paramInt2);
  }

  public void setInterpolator(Interpolator paramInterpolator)
  {
    this.mImpl.setInterpolator(paramInterpolator);
  }

  public void start()
  {
    this.mImpl.start();
  }

  static abstract interface AnimatorUpdateListener
  {
    public abstract void onAnimationUpdate(ValueAnimatorCompat paramValueAnimatorCompat);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.v25.design.ValueAnimatorCompat
 * JD-Core Version:    0.6.0
 */