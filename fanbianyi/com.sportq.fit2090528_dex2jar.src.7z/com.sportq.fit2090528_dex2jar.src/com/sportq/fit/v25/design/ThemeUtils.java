package com.sportq.fit.v25.design;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.appcompat.R.attr;

class ThemeUtils
{
  private static final int[] APPCOMPAT_CHECK_ATTRS;

  static
  {
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = R.attr.colorPrimary;
    APPCOMPAT_CHECK_ATTRS = arrayOfInt;
  }

  static void checkAppCompatTheme(Context paramContext)
  {
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(APPCOMPAT_CHECK_ATTRS);
    boolean bool = localTypedArray.hasValue(0);
    int i = 0;
    if (!bool)
      i = 1;
    localTypedArray.recycle();
    if (i != 0)
      throw new IllegalArgumentException("You need to use a Theme.AppCompat theme (or descendant) with the design library.");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.v25.design.ThemeUtils
 * JD-Core Version:    0.6.0
 */