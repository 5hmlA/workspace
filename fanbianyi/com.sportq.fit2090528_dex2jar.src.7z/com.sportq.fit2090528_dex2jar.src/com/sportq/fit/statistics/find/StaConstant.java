package com.sportq.fit.statistics.find;

public class StaConstant
{
  public static final String stats_ad = "p.c.ad|!||!||!|";
  public static final String stats_b1_13_more_detail = "p.c.b|!|p-spd|!|b.p-spd.m-dtl|!|";
  public static final String stats_b1_8_more_detail = "p.c.b|!|p-pj|!|b.p-pj.m-dtl|!|";
  public static final String stats_customized_exit = "p.c.c|!|t-idx|!|c.t-idx.cmmeo|!|";
  public static final String stats_download = "p.c.downLoad|!||!||!|";
  public static final String stats_healthdiet_article_click = "p.c.b|!|m-gud|!|b.m-gud.dtl|!|";
  public static final String stats_lim = "p.c.lim|!||!||!|";
  public static final String stats_plan_related_courses_click = "p.c.b|!|p-pj|!|b.p-pj.abo|!|";
  public static final String stats_plan_related_courses_click02 = "p.c.b|!|p-pnj|!|b.p-pnj.abo|!|";
  public static final String stats_praise = "p.c.eva|!||!||!|";
  public static final String stats_publish_finish_btn_click = "p.c.b|!|g-edt|!|b.g-edt.s|!|";
  public static final String stats_push = "p.c.push|!||!||!|";
  public static final String stats_recommend_course_click = "p.c.b|!|t-idx|!|b.t-idx.rec|!|";
  public static final String stats_recommend_item_click = "p.c.b|!|p-idx|!|b.p-idx.pr|!|";
  public static final String stats_related_courses_item_click = "p.c.b|!|p-abo|!|b.p-abo.p|!|";
  public static final String stats_save_local_click = "p.c.c|!|g-view|!|c.g-view.s|!|";
  public static final String stats_short_time_remind_click = "p.c.b|!|p-st|!|b.p-st.time|!|";
  public static final String stats_single_related_courses_click = "p.c.b|!|p-spd|!|b.p-spd.abo|!|";
  public static final String stats_toolbar = "p.c.toolBar|!||!||!|";
  public static final String stats_train_feedback_up = "p.c.b|!|p-tfb|!|b.p-tfb.s|!|";
  public static final String stats_train_finish_camera_click = "p.c.b|!|p-fst|!|b.p-fst.p|!|";
  public static final String stats_train_finish_feedback_btn = "p.c.b|!|p-fst|!|b.p-fst.tbk|!|";
  public static final String stats_train_info_more_feedback_btn = "p.c.b|!|p-pj|!|b.p-pj.tbk|!|";
  public static final String stats_train_info_more_feedback_btn_02 = "p.c.b|!|p-spd|!|b.p-spd.tbk|!|";
  public static final String stats_train_list_more_feedback_btn = "p.c.b|!|p-pnj|!|b.p-pnj.tbk|!|";
  public static final String stats_traininfo_img_click = "p.c.b|!|g-alb|!|b.g-alb.c|!|";
  public static final String stats_traininfo_more_delete_click = "p.c.b|!|g-det|!|b.g-det.d|!|";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.statistics.find.StaConstant
 * JD-Core Version:    0.6.0
 */