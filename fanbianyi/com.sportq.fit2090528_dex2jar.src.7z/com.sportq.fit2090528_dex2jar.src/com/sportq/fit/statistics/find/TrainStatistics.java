package com.sportq.fit.statistics.find;

import com.sportq.fit.common.interfaces.statistics.TrainStatisticsInterface;

public class TrainStatistics
  implements TrainStatisticsInterface
{
  public String recommendCourseAction()
  {
    return "p.c.b|!|t-idx|!|b.t-idx.rec|!|";
  }

  public String trainShortTimeRemind()
  {
    return "p.c.b|!|p-st|!|b.p-st.time|!|";
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.statistics.find.TrainStatistics
 * JD-Core Version:    0.6.0
 */