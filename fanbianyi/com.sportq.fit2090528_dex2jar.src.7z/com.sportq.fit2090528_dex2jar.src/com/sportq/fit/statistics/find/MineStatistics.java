package com.sportq.fit.statistics.find;

import com.sportq.fit.common.interfaces.statistics.mine.MineStatisticsInterface;

public class MineStatistics
  implements MineStatisticsInterface
{
  public String statsHealthDietArticleClick()
  {
    return "p.c.b|!|m-gud|!|b.m-gud.dtl|!|";
  }

  public String statsTrainFeedBackUp()
  {
    return "p.c.b|!|p-tfb|!|b.p-tfb.s|!|";
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.statistics.find.MineStatistics
 * JD-Core Version:    0.6.0
 */