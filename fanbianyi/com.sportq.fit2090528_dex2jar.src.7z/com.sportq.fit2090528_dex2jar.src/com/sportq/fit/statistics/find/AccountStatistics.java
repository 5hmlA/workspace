package com.sportq.fit.statistics.find;

import com.sportq.fit.common.interfaces.statistics.AccountStatisticsInterface;

public class AccountStatistics
  implements AccountStatisticsInterface
{
  public String appPraiseBtnClick()
  {
    return "p.c.eva|!||!||!|";
  }

  public String statsFitAdClick()
  {
    return "p.c.ad|!||!||!|";
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.statistics.find.AccountStatistics
 * JD-Core Version:    0.6.0
 */