package com.sportq.fit.statistics.find;

import android.content.Context;
import com.sportq.fit.common.interfaces.statistics.find.FindStatisticsInterface;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.StringUtils;

public class FindStatistics
  implements FindStatisticsInterface
{
  public String distributionAction(Context paramContext, String paramString1, String paramString2, boolean paramBoolean, String paramString3)
  {
    if ("0".equals(paramString3))
      return "p.c.downLoad|!||!||!|";
    StringBuilder localStringBuilder = new StringBuilder();
    String str1;
    if ("1".endsWith(CompDeviceInfoUtils.getAPNType(paramContext)))
    {
      str1 = "1";
      localStringBuilder.append(str1);
      localStringBuilder.append("|!|");
      localStringBuilder.append(paramString1);
      localStringBuilder.append("|!|");
      if (!paramBoolean)
        break label127;
    }
    label127: for (String str2 = ""; ; str2 = "0")
    {
      if (StringUtils.isNull(str2))
        str2 = paramString2;
      localStringBuilder.append(str2);
      localStringBuilder.append("|!|");
      localStringBuilder.append(DateUtils.getCurDateTime());
      return localStringBuilder.toString();
      str1 = "0";
      break;
    }
  }

  public String statsCustomizedExit()
  {
    return "p.c.c|!|t-idx|!|c.t-idx.cmmeo|!|";
  }

  public String statsGeTuiNoticeClick()
  {
    return "p.c.push|!||!||!|";
  }

  public String statsPlanRelatedCoursesClick()
  {
    return "p.c.b|!|p-pj|!|b.p-pj.abo|!|";
  }

  public String statsPlanRelatedCoursesClick02()
  {
    return "p.c.b|!|p-pnj|!|b.p-pnj.abo|!|";
  }

  public String statsPublishFinishBtnClick()
  {
    return "p.c.b|!|g-edt|!|b.g-edt.s|!|";
  }

  public String statsRecommendItemClick()
  {
    return "p.c.b|!|p-idx|!|b.p-idx.pr|!|";
  }

  public String statsRelatedCoursesItemClick()
  {
    return "p.c.b|!|p-abo|!|b.p-abo.p|!|";
  }

  public String statsSaveLocalClick()
  {
    return "p.c.c|!|g-view|!|c.g-view.s|!|";
  }

  public String statsSingleRelatedCoursesClick()
  {
    return "p.c.b|!|p-spd|!|b.p-spd.abo|!|";
  }

  public String statsTakePhotoPermission()
  {
    return "p.c.lim|!||!||!|";
  }

  public String statsTrainFinishCameraClick()
  {
    return "p.c.b|!|p-fst|!|b.p-fst.p|!|";
  }

  public String statsTrainFinishFeedBackBtn()
  {
    return "p.c.b|!|p-fst|!|b.p-fst.tbk|!|";
  }

  public String statsTrainInfoImgClick()
  {
    return "p.c.b|!|g-alb|!|b.g-alb.c|!|";
  }

  public String statsTrainInfoMoreDeleteClick()
  {
    return "p.c.b|!|g-det|!|b.g-det.d|!|";
  }

  public String statsTrainInfoMoreFeedBackBtn(String paramString)
  {
    if ("0".equals(paramString))
      return "p.c.b|!|p-spd|!|b.p-spd.tbk|!|";
    return "p.c.b|!|p-pj|!|b.p-pj.tbk|!|";
  }

  public String statsTrainListMoreFeedBackBtn()
  {
    return "p.c.b|!|p-pnj|!|b.p-pnj.tbk|!|";
  }

  public String statsTrainRecordAlbumClick()
  {
    return "p.c.toolBar|!||!||!|";
  }

  public String statsVideoDownLoadFinish()
  {
    return "p.c.downLoad|!||!||!|";
  }

  public String trainInfoAction(String paramString)
  {
    if ("0".equals(paramString))
      return "p.c.b|!|p-spd|!|b.p-spd.m-dtl|!|";
    return "p.c.b|!|p-pj|!|b.p-pj.m-dtl|!|";
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.statistics.find.FindStatistics
 * JD-Core Version:    0.6.0
 */