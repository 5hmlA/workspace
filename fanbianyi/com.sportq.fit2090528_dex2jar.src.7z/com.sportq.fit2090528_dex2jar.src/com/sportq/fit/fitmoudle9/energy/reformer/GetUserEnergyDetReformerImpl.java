package com.sportq.fit.fitmoudle9.energy.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyDetailModel.EnergyTradesDetailModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyDetailModel.EnergyTradesMonthModel;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyData;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;

public class GetUserEnergyDetReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    EnergyReformer localEnergyReformer;
    if (paramBaseData == null)
      localEnergyReformer = null;
    Iterator localIterator1;
    do
    {
      return localEnergyReformer;
      EnergyData localEnergyData = (EnergyData)paramBaseData;
      localEnergyReformer = new EnergyReformer();
      localEnergyReformer.lstUserEnergy = new ArrayList();
      localIterator1 = localEnergyData.lstUserEnergy.iterator();
    }
    while (!localIterator1.hasNext());
    EnergyDetailModel.EnergyTradesMonthModel localEnergyTradesMonthModel = (EnergyDetailModel.EnergyTradesMonthModel)localIterator1.next();
    if (localEnergyTradesMonthModel.tradeMonth.contains("年"));
    Calendar localCalendar;
    for (int i = StringUtils.string2Int(localEnergyTradesMonthModel.tradeMonth.replace("年", "").replace("月", "")); ; i = StringUtils.string2Int(localCalendar.get(1) + localEnergyTradesMonthModel.tradeMonth.replace("月", "")))
    {
      Iterator localIterator2 = localEnergyTradesMonthModel.lstEnergyDet.iterator();
      while (localIterator2.hasNext())
      {
        EnergyDetailModel.EnergyTradesDetailModel localEnergyTradesDetailModel1 = (EnergyDetailModel.EnergyTradesDetailModel)localIterator2.next();
        EnergyDetailModel.EnergyTradesDetailModel localEnergyTradesDetailModel2 = new EnergyDetailModel.EnergyTradesDetailModel();
        localEnergyTradesDetailModel2.tradeId = localEnergyTradesDetailModel1.tradeId;
        localEnergyTradesDetailModel2.formatTime = localEnergyTradesDetailModel1.formatTime;
        localEnergyTradesDetailModel2.energyValue = localEnergyTradesDetailModel1.energyValue;
        localEnergyTradesDetailModel2.comment = localEnergyTradesDetailModel1.comment;
        localEnergyTradesDetailModel2.tradeTime = localEnergyTradesDetailModel1.tradeTime;
        localEnergyTradesDetailModel2.tradeMonth = localEnergyTradesMonthModel.tradeMonth;
        localEnergyTradesDetailModel2.headIndex = i;
        localEnergyReformer.lstUserEnergy.add(localEnergyTradesDetailModel2);
      }
      break;
      localCalendar = Calendar.getInstance();
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (EnergyData)FitGsonFactory.create().fromJson(paramString2, EnergyData.class), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.GetUserEnergyDetReformerImpl
 * JD-Core Version:    0.6.0
 */