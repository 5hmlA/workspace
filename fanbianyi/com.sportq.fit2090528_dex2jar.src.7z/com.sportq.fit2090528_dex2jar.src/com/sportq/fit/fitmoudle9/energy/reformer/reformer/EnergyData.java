package com.sportq.fit.fitmoudle9.energy.reformer.reformer;

import com.sportq.fit.common.BaseData;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyActionModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyCustomModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyDetailModel.EnergyTradesMonthModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyGoodsModel;
import com.sportq.fit.fitmoudle9.energy.reformer.model.ExchangeModel;
import java.util.ArrayList;

public class EnergyData extends BaseData
{
  public String activeId;
  public String classifyId;
  public String energyValue;
  public EnergyCustomModel entCus;
  public ExchangeModel entMessage;
  public String isDisplay;
  public String isDisplayRedeem;
  public ArrayList<EnergyActionModel> lstAction;
  public ArrayList<EnergyGoodsModel> lstCommodity;
  public ArrayList<EnergyDetailModel.EnergyTradesMonthModel> lstUserEnergy;
  public String message;
  public String result;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyData
 * JD-Core Version:    0.6.0
 */