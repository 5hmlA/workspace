package com.sportq.fit.fitmoudle9.energy.reformer.model;

public class EnergyGoodsModel
{
  public String activeImageUrl;
  public String activeUrl;
  public String comment;
  public String commodityComment;
  public String commodityId;
  public String commodityTitle;
  public String commodityType;
  public String energyValue;
  public String olapInfo;
  public String price;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyGoodsModel
 * JD-Core Version:    0.6.0
 */