package com.sportq.fit.fitmoudle9.energy.eventbus;

public class EnergyConstant
{
  public static final String REDEEM_SUCCESS = "redeem.success";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.eventbus.EnergyConstant
 * JD-Core Version:    0.6.0
 */