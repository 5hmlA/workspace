package com.sportq.fit.fitmoudle9.energy.widget;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.DialogListener;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.fitmoudle9.R.id;
import com.sportq.fit.fitmoudle9.R.layout;
import com.sportq.fit.middlelib.statistics.FitAction;

public class GetEnergyDialog
{
  private int changeEnergyValue;
  private ImageView energyDialogClose;
  private LinearLayout energyDialogContent;
  private TextView energyDialogEnergyValue;
  private TextView energyDialogExperience;
  private TextView energyDialogIntroduce;
  private LinearLayout energyDialogLinear;
  private Context mContext;
  private Dialog mDialog;

  public GetEnergyDialog(Context paramContext)
  {
    this.mContext = paramContext;
  }

  public void closeDialog()
  {
    if (this.mDialog != null)
    {
      this.mDialog.dismiss();
      this.mDialog.cancel();
    }
  }

  public void createDialog(FitInterfaceUtils.DialogListener paramDialogListener, int paramInt)
  {
    this.mDialog = new Dialog(this.mContext);
    this.mDialog.requestWindowFeature(1);
    this.mDialog.setCanceledOnTouchOutside(false);
    this.mDialog.setCancelable(false);
    this.mDialog.setContentView(R.layout.energy_get_energy_dialog);
    this.energyDialogEnergyValue = ((TextView)this.mDialog.findViewById(R.id.energy_dialog_energyValue));
    this.energyDialogClose = ((ImageView)this.mDialog.findViewById(R.id.energy_dialog_close));
    this.energyDialogContent = ((LinearLayout)this.mDialog.findViewById(R.id.energy_dialog_Content));
    this.energyDialogLinear = ((LinearLayout)this.mDialog.findViewById(R.id.energy_dialog_linear));
    this.energyDialogIntroduce = ((TextView)this.mDialog.findViewById(R.id.energy_dialog_introduce));
    this.energyDialogExperience = ((TextView)this.mDialog.findViewById(R.id.energy_dialog_experience));
    WindowManager.LayoutParams localLayoutParams = this.mDialog.getWindow().getAttributes();
    double d;
    if (paramInt == 0)
      d = 0.9028000000000001D * BaseApplication.screenWidth;
    while (true)
    {
      localLayoutParams.width = (int)d;
      localLayoutParams.height = -2;
      this.mDialog.getWindow().setAttributes(localLayoutParams);
      this.mDialog.setCancelable(true);
      this.mDialog.setCanceledOnTouchOutside(false);
      Dialog localDialog = this.mDialog;
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      this.energyDialogClose.setOnClickListener(new FitAction(null)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          GetEnergyDialog.this.closeDialog();
        }
      });
      this.energyDialogExperience.setOnClickListener(new FitAction(null, paramDialogListener)
      {
        @Instrumented
        public void onClick(View paramView)
        {
          VdsAgent.onClick(this, paramView);
          if (this.val$dialogListener != null)
            this.val$dialogListener.onDialogClick(GetEnergyDialog.this.mDialog, -2);
          GetEnergyDialog.this.closeDialog();
        }
      });
      return;
      d = 0.7639D * BaseApplication.screenWidth;
    }
  }

  public void setChangeEnergyValue(int paramInt)
  {
    this.changeEnergyValue = paramInt;
    this.energyDialogEnergyValue.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
    this.energyDialogEnergyValue.setText(String.valueOf("+" + paramInt));
    TextView localTextView = this.energyDialogIntroduce;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Integer.valueOf(paramInt);
    localTextView.setText(String.format("获得了%d能量，可立即体验一次能量课程", arrayOfObject));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.widget.GetEnergyDialog
 * JD-Core Version:    0.6.0
 */