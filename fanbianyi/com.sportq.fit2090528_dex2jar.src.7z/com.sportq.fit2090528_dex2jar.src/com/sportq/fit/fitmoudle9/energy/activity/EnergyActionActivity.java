package com.sportq.fit.fitmoudle9.energy.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle9.R.color;
import com.sportq.fit.fitmoudle9.R.id;
import com.sportq.fit.fitmoudle9.R.layout;
import com.sportq.fit.fitmoudle9.R.menu;
import com.sportq.fit.fitmoudle9.R.mipmap;
import com.sportq.fit.fitmoudle9.R.string;
import com.sportq.fit.fitmoudle9.energy.adapter.EnergyActionRecycAdapter;
import com.sportq.fit.fitmoudle9.energy.persenter.EnergyPresenterImpl;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyCustomModel;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer;
import com.sportq.fit.fitmoudle9.energy.widget.HeaderAndFooterRecycler.HeaderAndFooterWrapper;
import com.sportq.fit.middlelib.statistics.FitAction;

public class EnergyActionActivity extends BaseActivity
{
  TextView cur_energy;
  private EnergyPresenterImpl energyPresenter;
  private EnergyReformer energyReformer;
  private ProgressBar loader_icon;
  private RecyclerView recyclerView;

  public void fitOnClick(View paramView)
  {
    super.fitOnClick(paramView);
    if (paramView.getId() == R.id.energy_action_footer_goCustom)
      if (!"1".equals(BaseApplication.userModel.orderf))
        FitJumpImpl.getInstance().jumpTrainStartCustomizeActivity(this, this.energyReformer.entCus.hasCusFlag, this.energyReformer.entCus.hasHistoryFlag);
    do
    {
      return;
      if (("1".equals(BaseApplication.userModel.isVip)) || ("3".equals(BaseApplication.userModel.isVip)))
      {
        FitJumpImpl.getInstance().pushJumpTrainCustomizedActivity(this);
        return;
      }
      FitJumpImpl.getInstance().jumpTrainStartCustomizeActivity(this, this.energyReformer.entCus.hasCusFlag, this.energyReformer.entCus.hasHistoryFlag);
      return;
      if (paramView.getId() != R.id.energy_action_footer_goTask)
        continue;
      FitJumpImpl.getInstance().jumpTask01NewChallengesListActivity(this);
      return;
    }
    while (paramView.getId() != R.id.energy_about_view);
    FitJumpImpl.getInstance().settingJumpWebView(this, "", VersionUpdateCheck.WEB_ADDRESS + "energyInfo");
  }

  public <T> void getDataFail(T paramT)
  {
    if (this.loader_icon != null)
      this.loader_icon.setVisibility(8);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if (this.loader_icon != null)
      this.loader_icon.setVisibility(8);
    String str1;
    View localView1;
    TextView localTextView;
    if ((paramT instanceof EnergyReformer))
    {
      this.energyReformer = ((EnergyReformer)paramT);
      UserModel localUserModel = BaseApplication.userModel;
      if (!"0".equals(this.energyReformer.entCus.stateCode))
        break label289;
      str1 = "0";
      localUserModel.orderf = str1;
      localView1 = LayoutInflater.from(this).inflate(R.layout.energy_action_recyc_head, null);
      this.cur_energy = ((TextView)localView1.findViewById(R.id.cur_energy));
      localView1.findViewById(R.id.energy_about_view).setOnClickListener(new FitAction(this));
      this.cur_energy.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
      localTextView = this.cur_energy;
      if (StringUtils.isNull(BaseApplication.userModel.energyValue))
        break label295;
    }
    label289: label295: for (String str2 = BaseApplication.userModel.energyValue; ; str2 = "0")
    {
      localTextView.setText(str2);
      View localView2 = LayoutInflater.from(this).inflate(R.layout.energy_action_recyc_footer, null);
      ViewGroup.LayoutParams localLayoutParams = new ViewGroup.LayoutParams(-1, -2);
      localView1.setLayoutParams(localLayoutParams);
      localView2.setLayoutParams(localLayoutParams);
      localView2.findViewById(R.id.energy_action_footer_goCustom).setOnClickListener(new FitAction(this));
      localView2.findViewById(R.id.energy_action_footer_goTask).setOnClickListener(new FitAction(this));
      HeaderAndFooterWrapper localHeaderAndFooterWrapper = new HeaderAndFooterWrapper(new EnergyActionRecycAdapter(this, this.energyReformer.lstAction));
      localHeaderAndFooterWrapper.addHeaderView(localView1);
      localHeaderAndFooterWrapper.addFootView(localView2);
      this.recyclerView.setAdapter(localHeaderAndFooterWrapper);
      return;
      str1 = "1";
      break;
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.energy_action_activity);
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    this.recyclerView = ((RecyclerView)findViewById(R.id.energy_action_recyclerView));
    if (localCustomToolBar != null)
    {
      localCustomToolBar.setTitle(UseStringUtils.getStr(this, R.string.c_91_1));
      localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
      localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
      localCustomToolBar.setBackgroundResource(R.color.white);
      setSupportActionBar(localCustomToolBar);
    }
    this.loader_icon = ((ProgressBar)findViewById(R.id.loader_icon));
    this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
    this.loader_icon.setVisibility(0);
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(R.menu.energy_detail_menu, paramMenu);
    return true;
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      if (paramMenuItem.getItemId() != R.id.energy_detail)
        continue;
      startActivity(new Intent(this, EnergyDetailActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  protected void onResume()
  {
    super.onResume();
    if (this.energyPresenter != null);
    for (EnergyPresenterImpl localEnergyPresenterImpl = this.energyPresenter; ; localEnergyPresenterImpl = new EnergyPresenterImpl(this))
    {
      this.energyPresenter = localEnergyPresenterImpl;
      this.energyPresenter.getEnergyAction(this, new RequestModel());
      return;
    }
  }

  protected void onStop()
  {
    super.onStop();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.activity.EnergyActionActivity
 * JD-Core Version:    0.6.0
 */