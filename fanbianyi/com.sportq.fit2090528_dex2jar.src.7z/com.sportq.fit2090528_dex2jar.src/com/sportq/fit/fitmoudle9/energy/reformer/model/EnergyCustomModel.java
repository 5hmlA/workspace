package com.sportq.fit.fitmoudle9.energy.reformer.model;

public class EnergyCustomModel
{
  public String hasCusFlag;
  public String hasHistoryFlag;
  public String stateCode;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyCustomModel
 * JD-Core Version:    0.6.0
 */