package com.sportq.fit.fitmoudle9.energy.reformer.model;

public class EnergyActionModel
{
  public String comment;
  public String ownNumber;
  public String totalNumber;
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyActionModel
 * JD-Core Version:    0.6.0
 */