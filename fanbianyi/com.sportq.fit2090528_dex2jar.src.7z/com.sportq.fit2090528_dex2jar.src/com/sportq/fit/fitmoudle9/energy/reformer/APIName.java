package com.sportq.fit.fitmoudle9.energy.reformer;

public class APIName
{
  private static final String API_PREFIX = "/SFitWeb/sfit/";

  public static String getAPIName(ApiEnum paramApiEnum)
  {
    switch (1.$SwitchMap$com$sportq$fit$fitmoudle9$energy$reformer$APIName$ApiEnum[paramApiEnum.ordinal()])
    {
    default:
      return "";
    case 1:
      return "/SFitWeb/sfit/getAliSign";
    case 2:
      return "/SFitWeb/sfit/aliCheckResults";
    case 3:
      return "/SFitWeb/sfit/weixinOrder";
    case 4:
      return "/SFitWeb/sfit/weixinCheckResults";
    case 5:
      return "/SFitWeb/sfit/getCommodity";
    case 6:
    }
    return "/SFitWeb/sfit/getEnergyAction";
  }

  public static enum ApiEnum
  {
    static
    {
      ALI_CHECK_RESULTS = new ApiEnum("ALI_CHECK_RESULTS", 1);
      WEIXIN_ORDER = new ApiEnum("WEIXIN_ORDER", 2);
      WEIXIN_CHECK_RESULTS = new ApiEnum("WEIXIN_CHECK_RESULTS", 3);
      GET_COMMODITY = new ApiEnum("GET_COMMODITY", 4);
      GET_ENERGY_ACTION = new ApiEnum("GET_ENERGY_ACTION", 5);
      ApiEnum[] arrayOfApiEnum = new ApiEnum[6];
      arrayOfApiEnum[0] = GET_ALI_SIGN;
      arrayOfApiEnum[1] = ALI_CHECK_RESULTS;
      arrayOfApiEnum[2] = WEIXIN_ORDER;
      arrayOfApiEnum[3] = WEIXIN_CHECK_RESULTS;
      arrayOfApiEnum[4] = GET_COMMODITY;
      arrayOfApiEnum[5] = GET_ENERGY_ACTION;
      $VALUES = arrayOfApiEnum;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.APIName
 * JD-Core Version:    0.6.0
 */