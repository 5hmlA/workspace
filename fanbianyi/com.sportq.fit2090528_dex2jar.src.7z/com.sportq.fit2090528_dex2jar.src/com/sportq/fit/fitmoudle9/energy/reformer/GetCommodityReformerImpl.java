package com.sportq.fit.fitmoudle9.energy.reformer;

import com.google.gson.Gson;
import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.FitGsonFactory;
import com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyGoodsModel;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyData;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer;
import java.util.ArrayList;
import java.util.Iterator;

public class GetCommodityReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    EnergyReformer localEnergyReformer;
    if (paramBaseData == null)
      localEnergyReformer = null;
    while (true)
    {
      return localEnergyReformer;
      EnergyData localEnergyData = (EnergyData)paramBaseData;
      localEnergyReformer = new EnergyReformer();
      localEnergyReformer.isDisplay = localEnergyData.isDisplay;
      localEnergyReformer.activeId = localEnergyData.activeId;
      localEnergyReformer.isDisplayRedeem = localEnergyData.isDisplayRedeem;
      localEnergyReformer.lstCommodity = new ArrayList();
      Iterator localIterator = localEnergyData.lstCommodity.iterator();
      while (localIterator.hasNext())
      {
        EnergyGoodsModel localEnergyGoodsModel1 = (EnergyGoodsModel)localIterator.next();
        EnergyGoodsModel localEnergyGoodsModel2 = new EnergyGoodsModel();
        localEnergyGoodsModel2.commodityId = localEnergyGoodsModel1.commodityId;
        localEnergyGoodsModel2.energyValue = localEnergyGoodsModel1.energyValue;
        localEnergyGoodsModel2.comment = localEnergyGoodsModel1.comment;
        localEnergyGoodsModel2.price = localEnergyGoodsModel1.price;
        localEnergyGoodsModel2.commodityTitle = localEnergyGoodsModel1.commodityTitle;
        localEnergyGoodsModel2.commodityComment = localEnergyGoodsModel1.commodityComment;
        localEnergyGoodsModel2.commodityType = localEnergyGoodsModel1.commodityType;
        localEnergyGoodsModel2.activeUrl = localEnergyGoodsModel1.activeUrl;
        localEnergyGoodsModel2.activeImageUrl = localEnergyGoodsModel1.activeImageUrl;
        localEnergyGoodsModel2.olapInfo = localEnergyGoodsModel1.olapInfo;
        localEnergyReformer.lstCommodity.add(localEnergyGoodsModel2);
      }
    }
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    return dataToReformer(paramString1, (EnergyData)FitGsonFactory.create().fromJson(paramString2, EnergyData.class), false);
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.GetCommodityReformerImpl
 * JD-Core Version:    0.6.0
 */