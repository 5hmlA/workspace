package com.sportq.fit.fitmoudle9.energy.reformer.model;

import java.io.Serializable;
import java.util.ArrayList;

public class EnergyDetailModel
{
  public static class EnergyTradesDetailModel
    implements Serializable
  {
    public String comment;
    public String energyValue;
    public String formatTime;
    public int headIndex;
    public String tradeId;
    public String tradeMonth;
    public String tradeTime;
  }

  public static class EnergyTradesMonthModel
    implements Serializable
  {
    public ArrayList<EnergyDetailModel.EnergyTradesDetailModel> lstEnergyDet;
    public String tradeMonth;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.model.EnergyDetailModel
 * JD-Core Version:    0.6.0
 */