package com.sportq.fit.fitmoudle9.energy.reformer;

import com.sportq.fit.common.BaseData;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.reformer.ReformerInterface;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle9.energy.reformer.model.ExchangeModel;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyData;
import com.sportq.fit.fitmoudle9.energy.reformer.reformer.EnergyReformer;
import org.json.JSONObject;

public class RedeemReformerImpl
  implements ReformerInterface
{
  public BaseReformer dataToReformer(String paramString, BaseData paramBaseData, boolean paramBoolean)
  {
    EnergyData localEnergyData = (EnergyData)paramBaseData;
    EnergyReformer localEnergyReformer = new EnergyReformer();
    localEnergyReformer.result = localEnergyData.result;
    localEnergyReformer.message = localEnergyData.message;
    localEnergyReformer.entMessage = localEnergyData.entMessage;
    return localEnergyReformer;
  }

  public BaseReformer dataToReformer(String paramString1, String paramString2, boolean paramBoolean)
  {
    EnergyReformer localEnergyReformer1;
    try
    {
      JSONObject localJSONObject1 = new JSONObject(paramString2);
      if (StringUtils.isNull(paramString2))
      {
        EnergyReformer localEnergyReformer2 = new EnergyReformer();
        localEnergyReformer2.result = "Y";
        return localEnergyReformer2;
      }
      EnergyData localEnergyData = new EnergyData();
      localEnergyData.result = localJSONObject1.optString("result");
      localEnergyData.message = localJSONObject1.optString("message");
      ExchangeModel localExchangeModel = new ExchangeModel();
      JSONObject localJSONObject2 = localJSONObject1.optJSONObject("entMessage");
      if (localJSONObject2 != null)
      {
        localExchangeModel.code = localJSONObject2.optString("code");
        localExchangeModel.message = localJSONObject2.optString("message");
        localExchangeModel.type = localJSONObject2.optString("type");
        localExchangeModel.title = localJSONObject2.optString("title");
        localExchangeModel.linkUrl = localJSONObject2.optString("linkUrl");
        localEnergyData.entMessage = localExchangeModel;
      }
      return dataToReformer(paramString1, localEnergyData, false);
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      localEnergyReformer1 = new EnergyReformer();
      localEnergyReformer1.result = "N";
    }
    return localEnergyReformer1;
  }

  public ReformerInterface getReformerInterface(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }

  public String getURL(EnumConstant.FitUrl paramFitUrl)
  {
    return null;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit2090528_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle9.energy.reformer.RedeemReformerImpl
 * JD-Core Version:    0.6.0
 */