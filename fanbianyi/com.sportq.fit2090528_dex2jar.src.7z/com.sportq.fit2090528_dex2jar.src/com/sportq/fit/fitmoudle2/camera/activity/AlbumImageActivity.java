package com.sportq.fit.fitmoudle2.camera.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.GridView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.event.SecSendImgClickEvent;
import com.sportq.fit.fitmoudle2.R.id;
import com.sportq.fit.fitmoudle2.R.layout;
import com.sportq.fit.fitmoudle2.camera.adapter.AlbumImageGridViewAdapter;
import com.sportq.fit.fitmoudle2.camera.widget.albumimage.AlbumImageDropView;
import com.sportq.fit.fitmoudle2.camera.widget.albumimage.AlbumImageDropView.OnDropItemClickListener;
import com.sportq.fit.fitmoudle2.camera.widget.albumimage.AlbumImageTitleView;
import com.sportq.fit.fitmoudle2.camera.widget.albumimage.AlbumImageTools.AlbumEntity;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class AlbumImageActivity extends BaseActivity
  implements AlbumImageDropView.OnDropItemClickListener
{
  private AlbumImageGridViewAdapter adapter;
  private AlbumImageTitleView album_title;
  private ArrayList<String> curImgList;
  private AlbumImageDropView dropdown_layout;
  private AlbumImageTools.AlbumEntity entity;
  private GridView grid_view;
  private Handler mHandler = new AlbumImageActivity.2(this);
  private View prohibit_action_bar;
  private boolean refreshFlg = false;
  private String strJumpFlg;

  private void initElementUI()
  {
    this.grid_view = ((GridView)findViewById(R.id.grid_view));
    this.prohibit_action_bar = findViewById(R.id.prohibit_action_bar);
    this.album_title = ((AlbumImageTitleView)findViewById(R.id.album_title));
    this.dropdown_layout = ((AlbumImageDropView)findViewById(R.id.dropdown_layout));
    this.album_title.initElementUI(new FitAction(this));
    if (getIntent() != null)
      this.strJumpFlg = getIntent().getStringExtra("sendImg");
    new Thread(new AlbumImageActivity.1(this)).start();
  }

  private void setTitleHint(int paramInt)
  {
    ArrayList localArrayList = this.entity.getAlbumNameList();
    if (paramInt == -1)
      paramInt = 0;
    String str = (String)localArrayList.get(paramInt);
    this.album_title.setTitleHint(str);
  }

  private void titleClickAction(int paramInt)
  {
    if ((this.adapter == null) || (this.adapter.getCount() == 0))
      return;
    this.dropdown_layout.startDropLayoutAnim(new AlbumImageActivity.3(this), paramInt);
  }

  public void fitOnClick(View paramView)
  {
    int i = 1;
    if (R.id.close_icon == paramView.getId())
    {
      finish();
      AnimationUtil.pageJumpAnim(this, i);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if ((R.id.prohibit_action_bar != paramView.getId()) && (R.id.dropdown_layout != paramView.getId()) && (R.id.title_bg_layout != paramView.getId()))
        continue;
      if (paramView.getId() == R.id.title_bg_layout)
        i = 0;
      titleClickAction(i);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.album_image);
    EventBus.getDefault().register(this);
    this.refreshFlg = true;
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    if (this.entity != null)
      this.entity = null;
    super.onDestroy();
  }

  public void onDropItemClick(int paramInt)
  {
    setTitleHint(paramInt);
    this.curImgList = ((ArrayList)this.entity.getAlbumImgPathList().get(paramInt));
    this.adapter = new AlbumImageGridViewAdapter(this, this.curImgList);
    this.grid_view.setAdapter(this.adapter);
  }

  @Subscribe
  public void onEventMainThread(SecSendImgClickEvent paramSecSendImgClickEvent)
  {
    finish();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if (FitnessPicPubRelease.STR_CLOSE_LASTPAGE_TAG.equals(paramString))
      finish();
    do
      return;
    while (!"refresh.album.flg".equals(paramString));
    this.refreshFlg = false;
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  protected void onPause()
  {
    super.onPause();
    this.refreshFlg = true;
  }

  protected void onResume()
  {
    super.onResume();
    if (this.refreshFlg)
      initElementUI();
  }

  public void onlyCloseDropView()
  {
    titleClickAction(1);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle2.camera.activity.AlbumImageActivity
 * JD-Core Version:    0.6.0
 */