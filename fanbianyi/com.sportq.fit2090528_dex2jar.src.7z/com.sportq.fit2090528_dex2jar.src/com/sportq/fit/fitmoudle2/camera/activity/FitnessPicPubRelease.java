package com.sportq.fit.fitmoudle2.camera.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.FitnessPicPubReleaseShareFinishEvent;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.ImageUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.SelectWeightDialog;
import com.sportq.fit.fitmoudle.event.PubAddWeightEvent;
import com.sportq.fit.fitmoudle.network.data.CoursePhotoData;
import com.sportq.fit.fitmoudle2.R.color;
import com.sportq.fit.fitmoudle2.R.id;
import com.sportq.fit.fitmoudle2.R.layout;
import com.sportq.fit.fitmoudle2.R.string;
import com.sportq.fit.fitmoudle2.camera.presenter.PresenterImpl;
import com.sportq.fit.fitmoudle2.camera.util.CameraSharePreference;
import com.sportq.fit.fitmoudle2.camera.widget.fitnesspic.ShareView;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.stub.StubApp;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class FitnessPicPubRelease extends BaseActivity
{
  public static String STR_CLOSE_LASTPAGE_TAG;
  public static String bodyDirection;
  public static String strImageType;
  public static String strImgPath;
  public static String strPubType;
  private RelativeLayout add_image_layout;
  private RelativeLayout back_layout;
  private ImageView choice_img;
  private RelativeLayout confirm_layout;
  private RelativeLayout edit_layout;
  private EditText edit_text;
  private String fromWhere;
  private boolean isShareToQQ = false;
  private String[] itemList;
  private float mCurPosY;
  private float mPosY;
  private String nWeight;
  private CoursePhotoData photoData;
  private PresenterImpl presenterImpl;
  private View rootView;
  private ShareView share_layout;
  private String strInfoTag;
  private String strJumpFlg;
  private RTextView train_info;
  private float weight;
  private TextView weight_hint;
  private LinearLayout weight_record_layout;
  private TextView weight_text_view;

  static
  {
    StubApp.interface11(6047);
    bodyDirection = "-1";
    STR_CLOSE_LASTPAGE_TAG = "close.last.page";
  }

  private void checkCloseCameraLayout()
  {
    if (this.back_layout.getTag() == null)
    {
      this.confirm_layout.setTag("upload.img");
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      return;
    }
    this.dialog.createChoiceDialog(new FitnessPicPubRelease.5(this), this, "", getResources().getString(R.string.g_13_1), getResources().getString(R.string.g_13_3), getResources().getString(R.string.g_13_2));
  }

  private void initElementUI()
  {
    if (getIntent() != null)
    {
      this.photoData = ((CoursePhotoData)getIntent().getSerializableExtra("course.info"));
      this.strJumpFlg = getIntent().getStringExtra("jump.flg");
    }
    this.presenterImpl = new PresenterImpl(this, new ApiImpl());
    String str1;
    int i;
    if (com.sportq.fit.common.utils.StringUtils.isNull(BaseApplication.userModel.currentWeight))
    {
      str1 = "";
      this.nWeight = str1;
      String[] arrayOfString = new String[2];
      arrayOfString[0] = getString(R.string.a_13_2);
      arrayOfString[1] = getString(R.string.g_24_3);
      this.itemList = arrayOfString;
      this.rootView = findViewById(R.id.root_layout);
      this.back_layout = ((RelativeLayout)findViewById(R.id.back_layout));
      if (this.back_layout != null)
        this.back_layout.setOnClickListener(new FitAction(this));
      TextView localTextView = (TextView)findViewById(R.id.title_text_view);
      if (localTextView != null)
        localTextView.setText(R.string.g_8_1);
      this.confirm_layout = ((RelativeLayout)findViewById(R.id.confirm_layout));
      this.confirm_layout.setOnClickListener(new FitAction(this));
      this.share_layout = ((ShareView)findViewById(R.id.share_layout));
      this.share_layout.initElement(new FitAction(this));
      ShareView localShareView = this.share_layout;
      if (!"1".equals(strPubType))
        break label648;
      i = 0;
      label253: localShareView.setVisibility(i);
      this.add_image_layout = ((RelativeLayout)findViewById(R.id.add_image_layout));
      if (this.add_image_layout != null)
      {
        this.add_image_layout.getLayoutParams().height = (int)(0.28D * BaseApplication.screenHeight);
        this.add_image_layout.setOnClickListener(new FitAction(this));
      }
      this.edit_text = ((EditText)findViewById(R.id.edit_text));
      String str2 = getIntent().getStringExtra("comment");
      if (!com.sportq.fit.common.utils.StringUtils.isNull(str2))
      {
        this.edit_text.setText(str2);
        this.edit_text.setSelection(str2.length());
      }
      this.edit_layout = ((RelativeLayout)findViewById(R.id.edit_layout));
      this.train_info = ((RTextView)findViewById(R.id.train_info));
      this.choice_img = ((ImageView)findViewById(R.id.choice_img));
      this.choice_img.setOnClickListener(new FitAction(this));
      RelativeLayout localRelativeLayout = (RelativeLayout)findViewById(R.id.weight_layout);
      if (localRelativeLayout != null)
      {
        View localView = findViewById(R.id.weight_btn_click);
        if (localView != null)
          localView.setOnClickListener(new FitAction(this));
        localRelativeLayout.setVisibility(0);
      }
      this.weight_hint = ((TextView)findViewById(R.id.weight_hint));
      this.weight_record_layout = ((LinearLayout)findViewById(R.id.weight_record_layout));
      this.weight_text_view = ((TextView)findViewById(R.id.weight_text_view));
      Typeface localTypeface = TextUtils.getFontFaceByWM();
      this.weight_text_view.setTypeface(localTypeface);
      String str3 = getIntent().getStringExtra("cur.weight");
      if (com.sportq.fit.common.utils.StringUtils.isNull(str3))
        break label655;
      this.weight = Float.parseFloat(str3);
      this.nWeight = String.valueOf(this.weight);
      this.weight_record_layout.setVisibility(0);
      this.weight_text_view.setText(String.valueOf(this.weight + "KG"));
      this.weight_hint.setVisibility(4);
    }
    while (true)
    {
      TextUtils.onTextChange(new FitnessPicPubRelease.4(this), this.edit_text);
      return;
      str1 = BaseApplication.userModel.currentWeight;
      break;
      label648: i = 8;
      break label253;
      label655: if (!com.sportq.fit.common.utils.StringUtils.isNull(this.nWeight))
      {
        this.weight = Float.parseFloat(this.nWeight);
        this.weight_record_layout.setVisibility(0);
        this.weight_text_view.setText(String.valueOf(this.weight + "KG"));
        this.weight_hint.setVisibility(4);
        continue;
      }
      this.weight = 0.0F;
    }
  }

  private void layoutChangeListener()
  {
    this.rootView.getViewTreeObserver().addOnGlobalLayoutListener(new FitnessPicPubRelease.7(this));
  }

  private void loadImgByNetwork(String paramString)
  {
    GlideUtils.loadUrlToBitmap(this, paramString, new FitnessPicPubRelease.6(this));
  }

  private void savePubInfo(int paramInt)
  {
    int i = 1;
    try
    {
      if (this.back_layout != null)
      {
        RelativeLayout localRelativeLayout = this.back_layout;
        if (paramInt == i)
        {
          str26 = "Edit";
          localRelativeLayout.setTag(str26);
        }
      }
      else
      {
        StringBuilder localStringBuilder1 = new StringBuilder();
        if (this.photoData == null)
          break label760;
        str2 = this.photoData.strMoveTime;
        String str3 = str2 + "±";
        StringBuilder localStringBuilder2 = new StringBuilder().append(str3);
        if (this.photoData == null)
          break label767;
        str4 = this.photoData.strTrainName;
        String str5 = str4 + "±";
        StringBuilder localStringBuilder3 = new StringBuilder().append(str5);
        if (this.photoData == null)
          break label774;
        str6 = this.photoData.strTrainInfo;
        String str7 = str6 + "±";
        StringBuilder localStringBuilder4 = new StringBuilder().append(str7);
        if (this.photoData == null)
          break label781;
        str8 = this.photoData.strPlanId;
        String str9 = str8 + "±";
        StringBuilder localStringBuilder5 = new StringBuilder().append(str9);
        if (this.photoData == null)
          break label788;
        str10 = this.photoData.individualId;
        String str11 = str10 + "±";
        String str12 = str11 + "" + "±";
        String str13 = str12 + "" + "±";
        String str14 = str13 + strImageType + "±";
        StringBuilder localStringBuilder6 = new StringBuilder().append(str14);
        if (!com.sportq.fit.common.utils.StringUtils.isNull(strImgPath))
        {
          StringBuilder localStringBuilder9;
          if ("-1".equals(strImgPath))
          {
            break label747;
            String str16 = str15 + "±";
            String str17 = str16 + this.edit_text.getText().toString() + "±";
            String str18 = str17 + bodyDirection + "±";
            if (this.weight_record_layout.getVisibility() != 0)
              break label795;
            StringBuilder localStringBuilder7 = new StringBuilder().append(str18);
            if (i == 0)
              break label800;
            str19 = String.valueOf(this.weight);
            String str20 = str19 + "±";
            String str21 = str20 + strPubType + "±";
            StringBuilder localStringBuilder8 = new StringBuilder().append(str21);
            if (this.photoData == null)
              break label807;
            str22 = this.photoData.punchDays;
            String str23 = str22 + "±";
            localStringBuilder9 = new StringBuilder().append(str23);
            if (this.photoData == null)
              break label703;
          }
          label703: for (String str24 = this.photoData.continuousDays; ; str24 = "")
          {
            String str25 = str24 + "±";
            if ((com.sportq.fit.common.utils.StringUtils.isNull(this.strInfoTag)) && ("0".equals(this.fromWhere)))
              this.strInfoTag = str25;
            com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.appendCourseData(str25, this);
            CameraSharePreference.putPublishStatusTag(this, "publish");
            return;
            str15 = strImgPath;
            break;
          }
        }
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        if (this.photoData != null);
        for (String str1 = this.photoData.strMoveTime; ; str1 = "")
        {
          com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.delAlbumCoursePhotoData(str1, this);
          CameraSharePreference.putPublishStatusTag(this, "");
          return;
        }
        label747: String str15 = "";
        continue;
        String str26 = null;
        continue;
        label760: String str2 = "";
        continue;
        label767: String str4 = "";
        continue;
        label774: String str6 = "";
        continue;
        label781: String str8 = "";
        continue;
        label788: String str10 = "";
        continue;
        label795: i = 0;
        continue;
        label800: String str19 = "";
        continue;
        label807: String str22 = "";
      }
    }
  }

  private void setFitnessImg(String paramString)
  {
    if ((com.sportq.fit.common.utils.StringUtils.isNull(paramString)) || ("-1".equals(paramString)) || (" ".equals(paramString)))
    {
      this.choice_img.setVisibility(8);
      this.confirm_layout.setAlpha(0.6F);
      return;
    }
    this.choice_img.setVisibility(0);
    if (paramString.contains("http"))
      loadImgByNetwork(paramString);
    while (true)
    {
      this.confirm_layout.setAlpha(1.0F);
      return;
      Bitmap localBitmap = ImageUtils.getImageBitmap(paramString, 2);
      if (localBitmap == null)
        continue;
      if (localBitmap.getWidth() < BaseApplication.screenWidth)
      {
        Matrix localMatrix = new Matrix();
        localMatrix.postScale(BaseApplication.screenWidth / localBitmap.getWidth(), BaseApplication.screenWidth / localBitmap.getHeight());
        localBitmap = Bitmap.createBitmap(localBitmap, 0, 0, localBitmap.getWidth(), localBitmap.getHeight(), localMatrix, true);
      }
      this.choice_img.setImageBitmap(localBitmap);
    }
  }

  private void setGestureListener()
  {
    this.edit_text.setOnTouchListener(new FitnessPicPubRelease.8(this));
  }

  public void fitOnClick(View paramView)
  {
    if (R.id.qq_layout == paramView.getId())
      this.share_layout.setQQIcon();
    do
    {
      while (true)
      {
        return;
        if (R.id.weibo_layout == paramView.getId())
        {
          this.share_layout.setWeiboIcon();
          return;
        }
        if (R.id.wechat_layout == paramView.getId())
        {
          this.share_layout.setWeChatIcon();
          return;
        }
        if (R.id.weichat_fri_layout == paramView.getId())
        {
          this.share_layout.setWeChatFriIcon();
          return;
        }
        if (R.id.back_layout == paramView.getId())
        {
          checkCloseCameraLayout();
          return;
        }
        if (R.id.confirm_layout != paramView.getId())
          break;
        if ("1".equals(strPubType))
        {
          this.dialog.createProgressDialog(this, getResources().getString(R.string.wait_hint));
          MiddleManager.getInstance().getFindPresenterImpl(this, null).uploadLocalTrainData(this, this.dialog);
          return;
        }
        if ((com.sportq.fit.common.utils.StringUtils.isNull(strImgPath)) || ("-1".equals(strImgPath)))
          continue;
        finish();
        AnimationUtil.pagePopAnim(this, 1);
        return;
      }
      if (R.id.add_image_layout == paramView.getId())
      {
        CompDeviceInfoUtils.applyPermission(new FitnessPicPubRelease.1(this), this, new String[] { "android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_SMS" });
        return;
      }
      if (R.id.choice_img != paramView.getId())
        continue;
      Intent localIntent = new Intent(this, FitnessImagePreview.class);
      localIntent.putExtra("fitness.img", strImgPath);
      startActivityForResult(localIntent, 88);
      AnimationUtil.pageJumpAnim(this, 0);
      return;
    }
    while (R.id.weight_btn_click != paramView.getId());
    SelectWeightDialog localSelectWeightDialog = new SelectWeightDialog(this);
    localSelectWeightDialog.setColors(R.color.color_ffd208, R.color.color_313131, R.color.color_e6e6e6, R.color.color_626262);
    localSelectWeightDialog.createDialog(String.valueOf(this.weight), 0, new FitnessPicPubRelease.2(this), this.itemList);
  }

  public <T> void getDataFail(T paramT)
  {
    this.confirm_layout.setTag(null);
    this.dialog.closeDialog();
    if (paramT != null)
      ToastUtils.makeToast(this, (String)paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    ToastUtils.makeToast(this, getResources().getString(R.string.submit_successfully));
    this.dialog.closeDialog();
    ShareView localShareView = this.share_layout;
    String str1 = strImgPath;
    String str2 = this.edit_text.getText().toString();
    String str3;
    if (this.photoData != null)
      str3 = this.photoData.strTrainName;
    while (true)
    {
      String str4;
      if (this.photoData != null)
      {
        str4 = this.photoData.strTrainInfo;
        label76: localShareView.shareAction(this, str1, str2, str3, str4, this.dialog, strImageType, new FitnessPicPubRelease.3(this));
      }
      try
      {
        String str5;
        if (!com.sportq.fit.common.utils.StringUtils.isNull(this.strJumpFlg))
          if (this.photoData != null)
          {
            str5 = this.photoData.strMoveTime;
            label129: com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.delAlbumCoursePhotoData(str5, this);
            CameraSharePreference.putPublishStatusTag(this, "");
          }
        while (true)
        {
          if ((this.weight_record_layout.getVisibility() == 0) && (this.weight > 0.0F))
            EventBus.getDefault().post(new PubAddWeightEvent(this.weight, ""));
          finish();
          return;
          str3 = "";
          break;
          str4 = "";
          break label76;
          str5 = "";
          break label129;
          EventBus.getDefault().post(new FitnessPicPubReleaseShareFinishEvent());
          EventBus.getDefault().post("fitness.pic.finish");
        }
      }
      catch (Exception localException)
      {
        while (true)
          LogUtils.e(localException);
      }
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.new_fitness_pic_release);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    initElementUI();
    setGestureListener();
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    switch (paramInt1)
    {
    default:
    case 88:
    }
    do
      return;
    while ((paramIntent == null) || (!"delete".equals(paramIntent.getStringExtra("delete_status"))));
    setFitnessImg(null);
    strImgPath = "-1";
    savePubInfo(1);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    strImgPath = null;
    this.share_layout = null;
    bodyDirection = "-1";
    strPubType = null;
    EventBus.getDefault().unregister(this);
    if (this.dialog != null)
      this.dialog.closeDialog();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    String str4;
    if ("fitness.pic.finish".equals(paramString))
    {
      finish();
      AnimationUtil.pagePopAnim(this, 1);
      if (this.photoData != null)
      {
        str4 = this.photoData.strMoveTime;
        com.sportq.fit.fitmoudle.compdevicemanager.StringUtils.delAlbumCoursePhotoData(str4, this);
        CameraSharePreference.putPublishStatusTag(this, "");
      }
    }
    do
    {
      return;
      str4 = "";
      break;
      if (!"fitness.share.qq".equals(paramString))
        continue;
      this.isShareToQQ = true;
      return;
    }
    while ((!"event.upload.history.finished".equals(paramString)) || (this.confirm_layout.getTag() != null));
    this.confirm_layout.setTag("upload.img");
    RequestModel localRequestModel = new RequestModel();
    String str1;
    if (this.photoData != null)
    {
      str1 = this.photoData.strMoveTime;
      localRequestModel.moveTime = str1;
      String str2 = this.edit_text.getText().toString();
      if (!com.sportq.fit.common.utils.StringUtils.isNull(str2))
        localRequestModel.comment = str2;
      localRequestModel.imageURL = strImgPath;
      localRequestModel.imageType = strImageType;
      if (!"-1".equals(bodyDirection))
        break label254;
    }
    label254: for (String str3 = "0"; ; str3 = "1")
    {
      localRequestModel.photoType = str3;
      if (!"-1".equals(bodyDirection))
        localRequestModel.bodyDirection = bodyDirection;
      if ((this.weight_record_layout.getVisibility() == 0) && (this.weight > 0.0F))
        localRequestModel.currentWeight = String.valueOf(this.weight);
      this.presenterImpl.addTrainPhoto(localRequestModel, this);
      return;
      str1 = "";
      break;
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      checkCloseCameraLayout();
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  protected void onResume()
  {
    super.onResume();
    if (this.dialog != null)
      this.dialog.closeDialog();
    setFitnessImg(strImgPath);
    String str;
    if (!com.sportq.fit.common.utils.StringUtils.isNull(this.nWeight))
    {
      this.weight_record_layout.setVisibility(0);
      this.weight_text_view.setText(String.valueOf(this.nWeight + "KG"));
      this.weight_hint.setVisibility(4);
      this.fromWhere = getIntent().getStringExtra("from.where");
      if (this.photoData == null)
        break label249;
      str = this.photoData.strTrainName;
      label115: if (com.sportq.fit.common.utils.StringUtils.isNull(str))
        break label255;
      this.train_info.setVisibility(0);
      this.train_info.setText(String.valueOf("完成 「" + str + "」" + this.photoData.strTrainInfo.split(" ")[0]));
    }
    while (true)
    {
      if (this.isShareToQQ)
        EventBus.getDefault().post(new FitnessPicPubReleaseShareFinishEvent());
      boolean bool = com.sportq.fit.common.utils.StringUtils.isNull(this.fromWhere);
      int i = 0;
      if (bool)
        i = 1;
      savePubInfo(i);
      layoutChangeListener();
      return;
      this.weight_hint.setVisibility(0);
      this.weight_record_layout.setVisibility(4);
      break;
      label249: str = "";
      break label115;
      label255: this.train_info.setVisibility(4);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle2.camera.activity.FitnessPicPubRelease
 * JD-Core Version:    0.6.0
 */