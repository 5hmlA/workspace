package com.sportq.fit.fitmoudle2.camera.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle2.R.id;
import com.sportq.fit.fitmoudle2.R.layout;
import com.sportq.fit.fitmoudle2.camera.widget.imagepreview.AlbumImageClipView;
import com.sportq.fit.fitmoudle2.camera.widget.imagepreview.ImagePreviewTitleView;
import com.sportq.fit.fitmoudle2.camera.widget.imagepreview.PreviewBottomView;
import com.sportq.fit.fitmoudle2.camera.widget.imagepreview.PreviewViewPager;
import com.sportq.fit.fitmoudle2.camera.widget.imagepreview.PreviewViewPager.OnSquareImgListener;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class AlbumImagePreviewEdit extends BaseActivity
  implements View.OnClickListener, PreviewViewPager.OnSquareImgListener
{
  public static byte[] imgData;
  private PreviewBottomView bottom_layout;
  private AlbumImageClipView clip_view;
  private int imgTypeByCamera;
  private ImagePreviewTitleView title_layout;
  private PreviewViewPager view_pager;

  private void initElementUI()
  {
    if (getIntent() == null)
    {
      finish();
      imgData = null;
      AnimationUtil.pageJumpAnim(this, 1);
    }
    this.view_pager = ((PreviewViewPager)findViewById(R.id.view_pager));
    this.bottom_layout = ((PreviewBottomView)findViewById(R.id.bottom_layout));
    this.clip_view = ((AlbumImageClipView)findViewById(R.id.clip_view));
    this.title_layout = ((ImagePreviewTitleView)findViewById(R.id.title_layout));
    int i = getIntent().getIntExtra("click.position", 0);
    String str = getIntent().getStringExtra("jump.flg");
    this.bottom_layout.initElementUI(this);
    this.title_layout.initElementUI(this, str, this);
    this.imgTypeByCamera = getIntent().getIntExtra("img.type", 1);
    RelativeLayout localRelativeLayout = this.bottom_layout.getRotation_layout();
    float f;
    if (this.imgTypeByCamera == 0)
      f = 0.4F;
    while (true)
    {
      localRelativeLayout.setAlpha(f);
      if (!"camera.jump".equals(str))
        break;
      View localView = findViewById(R.id.prohibit_view);
      if (localView != null)
        localView.setVisibility(0);
      this.clip_view.setVisibility(8);
      int j = getIntent().getIntExtra("camera.position", 0);
      this.clip_view.imgHandler(new AlbumImagePreviewEdit.1(this, str, i), this, imgData, j, this.imgTypeByCamera);
      return;
      f = 1.0F;
    }
    this.clip_view.setVisibility(0);
    this.view_pager.initElementUI(this, str, i, getIntent().getStringArrayListExtra("cur.all.image.path"), this);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.album_image_preview);
    EventBus.getDefault().register(this);
    initElementUI();
  }

  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    if (R.id.back_layout == paramView.getId())
    {
      EventBus.getDefault().post("refresh.album.flg");
      imgData = null;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    do
      while (true)
      {
        return;
        if (R.id.next_btn == paramView.getId())
        {
          getBarHeight(this);
          this.title_layout.nextBtnClickAction(this.statusBarHeight, this.clip_view, this.view_pager);
          return;
        }
        if (R.id.mirror_flip == paramView.getId())
        {
          this.view_pager.mirrorFlip();
          return;
        }
        if (R.id.rotation_layout != paramView.getId())
          break;
        if ((this.bottom_layout.getRotation_layout().getAlpha() == 0.4F) && (this.imgTypeByCamera == 0))
          continue;
        this.view_pager.rotateCurPicture();
        return;
      }
    while ((R.id.cut_layout != paramView.getId()) || (this.bottom_layout.getCut_img().getAlpha() < 1.0F));
    this.view_pager.scaleImage();
  }

  protected void onDestroy()
  {
    if (this.view_pager != null)
    {
      this.view_pager.clearViewPagerMemoryData();
      this.view_pager = null;
    }
    if (this.bottom_layout != null)
      this.bottom_layout = null;
    if (this.clip_view != null)
      this.clip_view = null;
    if (this.title_layout != null)
      this.title_layout = null;
    imgData = null;
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if (FitnessPicPubRelease.STR_CLOSE_LASTPAGE_TAG.equals(paramString))
    {
      finish();
      imgData = null;
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      EventBus.getDefault().post("refresh.album.flg");
      finish();
      imgData = null;
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  public void onSquareImg(boolean paramBoolean)
  {
    if (this.bottom_layout != null)
      this.bottom_layout.setCutImgAlpha(paramBoolean);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle2.camera.activity.AlbumImagePreviewEdit
 * JD-Core Version:    0.6.0
 */