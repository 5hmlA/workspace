package com.sportq.fit.fitmoudle2.camera.activity;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.reformer.PosterReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.SharePreferenceUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.network.data.CoursePhotoData;
import com.sportq.fit.fitmoudle2.R.id;
import com.sportq.fit.fitmoudle2.R.layout;
import com.sportq.fit.fitmoudle2.R.mipmap;
import com.sportq.fit.fitmoudle2.R.string;
import com.sportq.fit.fitmoudle2.camera.widget.watermarkfilter.ImageClipEditView;
import com.sportq.fit.fitmoudle2.camera.widget.watermarkfilter.ImageClipEditView.OnFilterChangeListener;
import com.sportq.fit.fitmoudle2.camera.widget.watermarkfilter.ImageClipEditView.OnOrdinaryWMDelListener;
import com.sportq.fit.fitmoudle2.camera.widget.watermarkfilter.WatermarkFilterOperateView;
import com.sportq.fit.fitmoudle2.camera.widget.watermarkfilter.WatermarkFilterOperateView.WatermarkListener;
import com.sportq.fit.fitmoudle2.camera.widget.watermarkfilter.filter.FilterHandler;
import com.sportq.fit.fitmoudle2.camera.widget.watermarkfilter.filter.FilterHandler.FilterListener;
import com.sportq.fit.fitmoudle2.camera.widget.watermarkfilter.wmhandler.OrdinaryWMImage;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.io.File;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class WatermarkFilterEditActivity extends BaseActivity
  implements WatermarkFilterOperateView.WatermarkListener, FilterHandler.FilterListener, ImageClipEditView.OnOrdinaryWMDelListener, ImageClipEditView.OnFilterChangeListener
{
  private ImageClipEditView clip_edit_layout;
  private WatermarkFilterEditActivity.NetWorkChangeReceiver netWorkChangeReceiver;
  private CoursePhotoData photoData;
  private String strMoveTime;
  private String strPath;
  private WatermarkFilterOperateView wmfOpeView;

  private void deleteImgByPreview()
  {
    try
    {
      if (StringUtils.isNull(this.strPath))
        return;
      File localFile = new File(this.strPath);
      if (localFile.exists())
      {
        Intent localIntent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        localIntent.setData(Uri.fromFile(localFile));
        sendBroadcast(localIntent);
        return;
      }
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void initElementUI()
  {
    if (getIntent() != null)
    {
      this.photoData = ((CoursePhotoData)getIntent().getSerializableExtra("course.info"));
      if (this.photoData == null)
        break label278;
    }
    label278: for (String str = this.photoData.strMoveTime; ; str = "")
    {
      this.strMoveTime = str;
      this.strPath = getIntent().getStringExtra("img.path");
      RelativeLayout localRelativeLayout = (RelativeLayout)findViewById(R.id.back_btn);
      TextView localTextView1 = (TextView)findViewById(R.id.next_btn);
      TextView localTextView2 = (TextView)findViewById(R.id.title_name);
      this.clip_edit_layout = ((ImageClipEditView)findViewById(R.id.clip_edit_layout));
      this.wmfOpeView = ((WatermarkFilterOperateView)findViewById(R.id.watermark_filter_operate_view));
      this.clip_edit_layout.initElementUI(this, new FitAction(this), this, this, this.strMoveTime).showChoiceImage(this.strPath, null, 0, 0);
      this.wmfOpeView.initElementUI(this, new FitAction(this), this, this);
      if (localRelativeLayout != null)
        localRelativeLayout.setOnClickListener(new FitAction(this));
      if (localTextView1 != null)
        localTextView1.setOnClickListener(new FitAction(this));
      if (localTextView2 != null)
        localTextView2.setVisibility(4);
      this.wmfOpeView.initWatermarkFilter(null);
      MiddleManager.getInstance().getFindPresenterImpl(this, null).getPoster(this);
      IntentFilter localIntentFilter = new IntentFilter();
      localIntentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
      this.netWorkChangeReceiver = new WatermarkFilterEditActivity.NetWorkChangeReceiver(this, null);
      registerReceiver(this.netWorkChangeReceiver, localIntentFilter);
      showWMFilterGuide();
      return;
    }
  }

  private void jumpFitnessRelease()
  {
    deleteImgByPreview();
    this.clip_edit_layout.synthesisNewImg(new WatermarkFilterEditActivity.1(this), this.wmfOpeView.getWmCurIndex());
  }

  private void showWMFilterGuide()
  {
    if (StringUtils.isNull(this.strMoveTime));
    RelativeLayout localRelativeLayout1;
    do
    {
      do
        return;
      while (!StringUtils.isNull(SharePreferenceUtils.getWMGuide(this)));
      localRelativeLayout1 = (RelativeLayout)findViewById(R.id.wmfilter_layout);
    }
    while (localRelativeLayout1 == null);
    localRelativeLayout1.setVisibility(0);
    RelativeLayout localRelativeLayout2 = (RelativeLayout)findViewById(R.id.guide_item_layout);
    ImageView localImageView = (ImageView)localRelativeLayout1.findViewById(R.id.watermark);
    if (localImageView != null)
      if (!StringUtils.isNull(this.photoData.punchDays))
        break label369;
    label369: for (int j = R.mipmap.train_data_watermark03; ; j = R.mipmap.train_data_watermark01)
    {
      localImageView.setImageResource(j);
      int i = BaseApplication.screenHeight - BaseApplication.screenWidth - CompDeviceInfoUtils.convertOfDip(this, 137.0F) - CompDeviceInfoUtils.getStatusBarHeight(this);
      if (CompDeviceInfoUtils.convertOfDip(this, 82.0F) > i)
      {
        RelativeLayout localRelativeLayout3 = (RelativeLayout)findViewById(R.id.first_date_wm);
        if (localRelativeLayout3 != null)
        {
          RelativeLayout.LayoutParams localLayoutParams2 = new RelativeLayout.LayoutParams(i, i);
          localLayoutParams2.addRule(2, R.id.bottom_view);
          localRelativeLayout3.setLayoutParams(localLayoutParams2);
        }
        RelativeLayout localRelativeLayout4 = (RelativeLayout)findViewById(R.id.content_layout);
        if (localRelativeLayout4 != null)
        {
          RelativeLayout.LayoutParams localLayoutParams3 = new RelativeLayout.LayoutParams(-2, -2);
          localLayoutParams3.addRule(2, R.id.first_date_wm);
          localRelativeLayout4.setLayoutParams(localLayoutParams3);
        }
        findViewById(R.id.guide_top).setPadding(-5 + i / 2, 0, 0, CompDeviceInfoUtils.convertOfDip(this, 10.0F));
      }
      if (localRelativeLayout2 != null)
      {
        RelativeLayout.LayoutParams localLayoutParams1 = new RelativeLayout.LayoutParams((int)(0.55D * BaseApplication.screenWidth), -2);
        localLayoutParams1.addRule(12, -1);
        localLayoutParams1.bottomMargin = CompDeviceInfoUtils.convertOfDip(this, 19.0F);
        localLayoutParams1.leftMargin = CompDeviceInfoUtils.convertOfDip(this, 10.0F);
        localRelativeLayout2.setLayoutParams(localLayoutParams1);
      }
      TextView localTextView1 = (TextView)findViewById(R.id.guide_hint);
      if (localTextView1 != null)
        localTextView1.setText(getResources().getString(R.string.f_10_1));
      TextView localTextView2 = (TextView)findViewById(R.id.guide_ok_hint);
      if (localTextView2 == null)
        break;
      localTextView2.setOnClickListener(new WatermarkFilterEditActivity.2(this, localRelativeLayout1));
      return;
    }
  }

  public void fitOnClick(View paramView)
  {
    if (this.clip_edit_layout.getLoader_icon().getVisibility() == 0)
      return;
    if (R.id.watermark_layout == paramView.getId())
    {
      this.wmfOpeView.checkWatermarkOrFilter(true);
      this.wmfOpeView.getWatermark_inverse().setVisibility(0);
      this.clip_edit_layout.getView_pager().setVisibility(4);
      this.clip_edit_layout.getOrdinary_wm_img().setWMRectStatus(true, true);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (R.id.filter_layout == paramView.getId())
      {
        this.wmfOpeView.checkWatermarkOrFilter(false);
        this.wmfOpeView.getWatermark_inverse().setVisibility(4);
        this.clip_edit_layout.getView_pager().setVisibility(0);
        this.clip_edit_layout.getOrdinary_wm_img().setWMRectStatus(false, true);
        continue;
      }
      if (R.id.watermark_inverse == paramView.getId())
      {
        this.wmfOpeView.watermarkFlip();
        continue;
      }
      if (R.id.back_btn == paramView.getId())
      {
        deleteImgByPreview();
        finish();
        AnimationUtil.pageJumpAnim(this, 1);
        continue;
      }
      if (R.id.next_btn != paramView.getId())
        continue;
      jumpFitnessRelease();
    }
  }

  public <T> void getDataSuccess(T paramT)
  {
    PosterReformer localPosterReformer = (PosterReformer)paramT;
    if (this.wmfOpeView != null)
      this.wmfOpeView.initWatermarkFilter(localPosterReformer);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.watermark_filter_ui);
    EventBus.getDefault().register(this);
    initElementUI();
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    if (this.wmfOpeView != null)
    {
      this.wmfOpeView.clearMemory();
      this.wmfOpeView = null;
    }
    if (this.clip_edit_layout != null)
      this.clip_edit_layout = null;
    try
    {
      unregisterReceiver(this.netWorkChangeReceiver);
      super.onDestroy();
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if (FitnessPicPubRelease.STR_CLOSE_LASTPAGE_TAG.equals(paramString))
      finish();
  }

  public void onFilterChange(int paramInt1, int paramInt2)
  {
    if (!this.wmfOpeView.getFilterHandler().isFilterExecuteFlg())
    {
      this.wmfOpeView.getFilterHandler().updFilterProStatus(paramInt1, 1).execute();
      String[] arrayOfString = new String[8];
      arrayOfString[0] = getResources().getString(R.string.original);
      arrayOfString[1] = getResources().getString(R.string.chic);
      arrayOfString[2] = getResources().getString(R.string.confident);
      arrayOfString[3] = getResources().getString(R.string.vigour);
      arrayOfString[4] = getResources().getString(R.string.focusing);
      arrayOfString[5] = getResources().getString(R.string.tenacity);
      arrayOfString[6] = getResources().getString(R.string.night_charm);
      arrayOfString[7] = getResources().getString(R.string.pure);
      this.clip_edit_layout.filterSwitchHint(arrayOfString[paramInt1]);
      this.wmfOpeView.setCurFilterSelectorBg(paramInt1);
    }
    do
      return;
    while (paramInt2 == -1);
    this.clip_edit_layout.getView_pager().setTag("reset.status");
    this.clip_edit_layout.getView_pager().setCurrentItem(paramInt2);
  }

  public void onFilterSuccess(Bitmap paramBitmap, int paramInt1, int paramInt2)
  {
    this.clip_edit_layout.setProShowStatus(false);
    this.clip_edit_layout.showChoiceImage(null, paramBitmap, paramInt1, paramInt2);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      deleteImgByPreview();
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  public void onOrdinaryWMDel()
  {
    this.wmfOpeView.setWmCurIndex(-1);
  }

  public void onWMCancel()
  {
    this.clip_edit_layout.setDataWMImg(null);
  }

  public void onWMExecuteFinish(Bitmap paramBitmap, boolean paramBoolean)
  {
    if (this.clip_edit_layout != null)
    {
      if (!paramBoolean)
        this.clip_edit_layout.setDataWMImg(paramBitmap);
    }
    else
      return;
    this.clip_edit_layout.setProShowStatus(false);
    this.clip_edit_layout.setWMImgByNetwork(paramBitmap);
  }

  public void onWMLoading()
  {
    this.clip_edit_layout.setProShowStatus(true);
  }

  public void startLoading()
  {
    this.clip_edit_layout.setProShowStatus(true);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle2.camera.activity.WatermarkFilterEditActivity
 * JD-Core Version:    0.6.0
 */