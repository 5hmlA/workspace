package com.sportq.fit.fitmoudle2.camera.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.network.data.CoursePhotoData;
import com.sportq.fit.fitmoudle2.R.anim;
import com.sportq.fit.fitmoudle2.R.id;
import com.sportq.fit.fitmoudle2.R.layout;
import com.sportq.fit.fitmoudle2.R.mipmap;
import com.sportq.fit.fitmoudle2.camera.widget.camera.CameraPreviewView;
import com.sportq.fit.fitmoudle2.camera.widget.camera.NewCameraBottomView;
import com.sportq.fit.fitmoudle2.camera.widget.camera.NewCameraSurfaceView;
import com.sportq.fit.fitmoudle2.camera.widget.camera.NewCameraTitleView;
import com.sportq.fit.fitmoudle2.camera.widget.camera.handler.CameraHandler;
import com.sportq.fit.fitmoudle2.camera.widget.camera.handler.CameraHandler.OnCameraStatusListener;
import com.sportq.fit.fitmoudle2.camera.widget.camera.handler.OnCameraChangeListener;
import com.sportq.fit.fitmoudle2.camera.widget.camera.handler.OnSetSurSizeListener;
import com.sportq.fit.middlelib.MiddleManager;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class NewCameraActivity extends BaseActivity
  implements CameraHandler.OnCameraStatusListener, OnSetSurSizeListener, View.OnClickListener, OnCameraChangeListener, View.OnTouchListener
{
  private int[] bodyList;
  private ImageView body_cover_plate;
  private NewCameraBottomView bottomView;
  private View cover_plate;
  private boolean focusFlg = false;
  private CameraPreviewView focusView;
  private float mCurPosX;
  private float mPosX;
  private CoursePhotoData photoData;
  private NewCameraSurfaceView surfaceView;
  private NewCameraTitleView titleView;
  private int whichBody;

  @SuppressLint({"NewApi"})
  private void hideVirtualButtons()
  {
    if (Build.VERSION.SDK_INT >= 19)
      getWindow().getDecorView().setSystemUiVisibility(2818);
  }

  private void initElementUI()
  {
    if (getIntent() != null)
      this.photoData = ((CoursePhotoData)getIntent().getSerializableExtra("course.info"));
    this.cover_plate = findViewById(R.id.cover_plate);
    this.body_cover_plate = ((ImageView)findViewById(R.id.body_cover_plate));
    this.titleView = ((NewCameraTitleView)findViewById(R.id.new_camera_title));
    if (this.titleView != null)
      this.titleView.initElement(this, this);
    this.bottomView = ((NewCameraBottomView)findViewById(R.id.new_camera_bottom_view));
    if (this.bottomView != null)
      this.bottomView.initElement(this, this, this);
    this.surfaceView = ((NewCameraSurfaceView)findViewById(R.id.surfaceView));
    if (this.surfaceView != null)
      this.surfaceView.initElement(this);
    this.focusView = ((CameraPreviewView)findViewById(R.id.preview_area));
    if (this.focusView != null)
      this.focusView.setOnTouchListener(this);
    int[] arrayOfInt;
    if ("0".equals(BaseApplication.userModel.userSex))
    {
      arrayOfInt = new int[4];
      arrayOfInt[0] = R.mipmap.male_body;
      arrayOfInt[1] = R.mipmap.male_front;
      arrayOfInt[2] = R.mipmap.male_side;
      arrayOfInt[3] = R.mipmap.male_back;
    }
    while (true)
    {
      this.bodyList = arrayOfInt;
      this.body_cover_plate.setImageResource(this.bodyList[0]);
      MiddleManager.getInstance().getFindPresenterImpl(this, null).getPoster(this);
      return;
      arrayOfInt = new int[4];
      arrayOfInt[0] = R.mipmap.female_body;
      arrayOfInt[1] = R.mipmap.female_front;
      arrayOfInt[2] = R.mipmap.female_side;
      arrayOfInt[3] = R.mipmap.female_back;
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    requestWindowFeature(1);
    getWindow().setFlags(1024, 1024);
    setContentView(R.layout.new_camera);
    EventBus.getDefault().register(this);
    initElementUI();
  }

  public void onCameraChange(int paramInt)
  {
    ImageView localImageView = this.body_cover_plate;
    int i;
    if (paramInt == 0)
    {
      i = 0;
      localImageView.setVisibility(i);
      this.titleView.onCameraChangeTitleUI(paramInt);
      this.bottomView.onCameraChangeUI(paramInt);
      if ((this.whichBody != 3) || (CameraHandler.getInstance(this, this).getCameraPosition() != 1))
        break label75;
      CameraHandler.getInstance(this, this).switchCamera(this, this.surfaceView.getSurfaceHolder());
    }
    label75: 
    do
    {
      return;
      i = 8;
      break;
    }
    while (CameraHandler.getInstance(this, this).getCameraPosition() != 0);
    CameraHandler.getInstance(this, this).switchCamera(this, this.surfaceView.getSurfaceHolder());
  }

  @Instrumented
  public void onClick(View paramView)
  {
    int i = 1;
    VdsAgent.onClick(this, paramView);
    if (R.id.whole_layout == paramView.getId())
    {
      this.whichBody = 0;
      this.bottomView.changeBodyStatus(paramView);
      this.body_cover_plate.setImageResource(this.bodyList[0]);
      if (CameraHandler.getInstance(this, this).getCameraPosition() == 0)
      {
        this.cover_plate.setVisibility(0);
        CameraHandler.getInstance(this, this).switchCamera(this, this.surfaceView.getSurfaceHolder());
      }
    }
    do
      while (true)
      {
        return;
        if (R.id.positive_layout == paramView.getId())
        {
          this.whichBody = i;
          this.bottomView.changeBodyStatus(paramView);
          this.body_cover_plate.setImageResource(this.bodyList[i]);
          if (CameraHandler.getInstance(this, this).getCameraPosition() != 0)
            continue;
          this.cover_plate.setVisibility(0);
          CameraHandler.getInstance(this, this).switchCamera(this, this.surfaceView.getSurfaceHolder());
          return;
        }
        if (R.id.profile_layout == paramView.getId())
        {
          this.whichBody = 2;
          this.bottomView.changeBodyStatus(paramView);
          this.body_cover_plate.setImageResource(this.bodyList[2]);
          if (CameraHandler.getInstance(this, this).getCameraPosition() != 0)
            continue;
          this.cover_plate.setVisibility(0);
          CameraHandler.getInstance(this, this).switchCamera(this, this.surfaceView.getSurfaceHolder());
          return;
        }
        if (R.id.opposite_layout == paramView.getId())
        {
          this.whichBody = 3;
          this.bottomView.changeBodyStatus(paramView);
          this.body_cover_plate.setImageResource(this.bodyList[3]);
          if (CameraHandler.getInstance(this, this).getCameraPosition() != i)
            continue;
          this.cover_plate.setVisibility(0);
          CameraHandler.getInstance(this, this).switchCamera(this, this.surfaceView.getSurfaceHolder());
          return;
        }
        if (R.id.close_layout == paramView.getId())
        {
          finish();
          FitnessPicPubRelease.bodyDirection = "-1";
          AnimationUtil.pageJumpAnim(this, i);
          return;
        }
        if (R.id.flip_layout == paramView.getId())
        {
          this.cover_plate.setVisibility(0);
          CameraHandler.getInstance(this, this).switchCamera(this, this.surfaceView.getSurfaceHolder());
          return;
        }
        if (R.id.flash_lamp_layout == paramView.getId())
        {
          this.titleView.flashLamp();
          return;
        }
        if (R.id.album_image == paramView.getId())
        {
          if (!this.bottomView.checkImgIsExist())
            continue;
          Intent localIntent = new Intent(this, AlbumImageActivity.class);
          localIntent.putExtra("course.info", this.photoData);
          FitnessPicPubRelease.bodyDirection = "-1";
          startActivity(localIntent);
          AnimationUtil.pageJumpAnim(this, 0);
          return;
        }
        if (R.id.take_picture_btn != paramView.getId())
          break;
        if (paramView.getTag() != null)
          continue;
        paramView.setTag("take.picture");
        CameraHandler.getInstance(null, null).doTakePicture(new NewCameraActivity.1(this, paramView), paramView, this);
        return;
      }
    while ((R.id.view_click_left != paramView.getId()) && (R.id.view_click_right != paramView.getId()));
    ViewPager localViewPager = this.bottomView.getViewpager();
    if (this.bottomView.getViewpager().getCurrentItem() == 0);
    while (true)
    {
      localViewPager.setCurrentItem(i);
      return;
      i = 0;
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
    this.titleView = null;
    this.bottomView = null;
    this.surfaceView = null;
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if (FitnessPicPubRelease.STR_CLOSE_LASTPAGE_TAG.equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      FitnessPicPubRelease.bodyDirection = "-1";
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  public void onOpenError()
  {
    runOnUiThread(new NewCameraActivity.3(this));
  }

  public void onOpenSuccess()
  {
    if (this.cover_plate != null)
    {
      Animation localAnimation = AnimationUtils.loadAnimation(this, R.anim.alpha_camera);
      this.cover_plate.setAnimation(localAnimation);
      this.cover_plate.setVisibility(4);
    }
  }

  protected void onPause()
  {
    super.onPause();
    CameraHandler.getInstance(this, this).doStopPreview();
    new Handler().postAtTime(new NewCameraActivity.4(this), 200L);
  }

  protected void onResume()
  {
    super.onResume();
    hideVirtualButtons();
    this.cover_plate.setVisibility(0);
    if (this.bottomView != null)
    {
      this.bottomView.showAlbumImg(this);
      this.bottomView.changeBodyStatus(this.bottomView.getWhole_layout());
      this.bottomView.getTake_picture_btn().setTag(null);
    }
    CameraHandler.getInstance(this, this).setCameraPosition(1);
    CameraHandler.getInstance(this, this).doStartPreview(this, this.surfaceView.getSurfaceHolder());
  }

  public void onSetSurSize(int paramInt1, int paramInt2)
  {
    if (this.surfaceView != null)
      this.surfaceView.setPreLayoutParams(paramInt1, paramInt2);
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    switch (paramMotionEvent.getAction())
    {
    default:
    case 0:
    case 2:
    case 1:
    }
    do
      while (true)
      {
        return true;
        this.mPosX = paramMotionEvent.getX();
        return true;
        this.mCurPosX = paramMotionEvent.getX();
        return true;
        if ((this.mPosX == 0.0F) || (this.mCurPosX == 0.0F))
          break;
        if ((this.mCurPosX - this.mPosX > 0.0F) && (Math.abs(this.mCurPosX - this.mPosX) > (int)(0.04D * BaseApplication.screenWidth)))
        {
          this.mPosX = 0.0F;
          this.mCurPosX = 0.0F;
          if (this.bottomView.getViewpager().getCurrentItem() == 0)
            continue;
          this.bottomView.getViewpager().setCurrentItem(0);
          return true;
        }
        if ((this.mCurPosX - this.mPosX >= 0.0F) || (Math.abs(this.mCurPosX - this.mPosX) <= (int)(0.04D * BaseApplication.screenWidth)))
          break;
        this.mPosX = 0.0F;
        this.mCurPosX = 0.0F;
        if (this.bottomView.getViewpager().getCurrentItem() == 1)
          continue;
        this.bottomView.getViewpager().setCurrentItem(1);
        return true;
      }
    while (this.focusFlg);
    this.focusFlg = true;
    this.focusView.focusImgAnim(new NewCameraActivity.2(this), paramMotionEvent.getX(), paramMotionEvent.getY());
    this.surfaceView.autoFocusAction(this.focusView.getFocusImg(), paramMotionEvent.getX(), paramMotionEvent.getY());
    return true;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle2.camera.activity.NewCameraActivity
 * JD-Core Version:    0.6.0
 */