package com.sportq.fit.fitmoudle10.organize.activity.bodyfat;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.GetBindScaleModel;
import com.sportq.fit.common.reformer.GetBindScaleReformer;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.BodyFatUnBindAdapter;
import com.sportq.fit.fitmoudle10.organize.adapter.BodyFatUnBindAdapter.OnUnBindListener;
import com.sportq.fit.fitmoudle10.organize.eventbus.BodyFastEvent;
import com.sportq.fit.fitmoudle10.organize.presenter.FitMoudle10ApiPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.BindScaleReformer;
import com.sportq.fit.fitmoudle10.organize.utils.BodyFastBindStoreUtils;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class BodyFatUnBindActivity extends BaseActivity
  implements BodyFatUnBindAdapter.OnUnBindListener
{
  private BodyFastEvent connectBodyFastEvent;
  private RecyclerView recyclerView;

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if ((paramT instanceof GetBindScaleReformer))
    {
      GetBindScaleReformer localGetBindScaleReformer = (GetBindScaleReformer)paramT;
      if ((localGetBindScaleReformer.lstScaleDevice != null) && (localGetBindScaleReformer.lstScaleDevice.size() != 0))
      {
        ArrayList localArrayList = new ArrayList();
        for (int i = 0; i < localGetBindScaleReformer.lstScaleDevice.size(); i++)
          localArrayList.add(String.valueOf(i));
        BodyFatUnBindAdapter localBodyFatUnBindAdapter = new BodyFatUnBindAdapter(this, localArrayList, R.layout.bodyfat_unbind_item_layout);
        localBodyFatUnBindAdapter.setListener(this);
        localBodyFatUnBindAdapter.setBindScaleModelList(localGetBindScaleReformer.lstScaleDevice);
        this.recyclerView.setAdapter(localBodyFatUnBindAdapter);
      }
      if ((localGetBindScaleReformer.lstScaleDevice != null) && (localGetBindScaleReformer.lstScaleDevice.size() > 0))
      {
        Iterator localIterator = localGetBindScaleReformer.lstScaleDevice.iterator();
        while (localIterator.hasNext())
        {
          GetBindScaleModel localGetBindScaleModel = (GetBindScaleModel)localIterator.next();
          BodyFastBindStoreUtils.appendCourseData(localGetBindScaleModel.scaleName + "±" + localGetBindScaleModel.scaleDeviceId + "±" + "null", localGetBindScaleModel.scaleName, this);
        }
      }
      if (this.connectBodyFastEvent != null)
      {
        this.dialog.closeDialog();
        EventBus.getDefault().post(this.connectBodyFastEvent);
      }
    }
    do
      return;
    while (!(paramT instanceof BindScaleReformer));
    new FitMoudle10ApiPresenter(this).getBindScale(this);
    this.connectBodyFastEvent = new BodyFastEvent();
    this.connectBodyFastEvent.isRefresh = true;
    this.connectBodyFastEvent.strOperateType = "1";
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.bodyfat_unbind_layout);
    EventBus.getDefault().register(this);
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setTitle(R.string.c_77_14_1);
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    localCustomToolBar.setBackgroundResource(R.color.white);
    setSupportActionBar(localCustomToolBar);
    this.dialog = new DialogManager();
    this.recyclerView = ((RecyclerView)findViewById(R.id.recycler_View));
    this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
    new FitMoudle10ApiPresenter(this).getBindScale(this);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(BodyFastEvent paramBodyFastEvent)
  {
    if ((paramBodyFastEvent != null) && (paramBodyFastEvent.isRefresh) && ("1".equals(paramBodyFastEvent.strOperateType)))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }

  public void onUnBind()
  {
    this.dialog.createProgressDialog(this, "请稍后...");
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.bodyfat.BodyFatUnBindActivity
 * JD-Core Version:    0.6.0
 */