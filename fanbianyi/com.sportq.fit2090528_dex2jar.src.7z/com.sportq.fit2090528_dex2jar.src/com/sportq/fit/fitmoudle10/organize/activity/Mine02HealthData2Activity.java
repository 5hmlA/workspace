package com.sportq.fit.fitmoudle10.organize.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.anim;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.Mine02HealthData2Adapter;
import com.sportq.fit.fitmoudle10.organize.eventbus.UpdateHealthDataFinishEvent;
import com.sportq.fit.fitmoudle10.organize.eventbus.UpdateTargetWeightEvent;
import com.sportq.fit.fitmoudle10.organize.presenter.commender.WeightCommender;
import com.sportq.fit.fitmoudle10.organize.presenter.model.WeightModel2;
import com.sportq.fit.fitmoudle10.organize.utils.DateUtils10;
import com.sportq.fit.fitmoudle10.organize.utils.Fit10Utils;
import com.sportq.fit.fitmoudle10.organize.widget.HealthDataProgressBar3;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.Date;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Mine02HealthData2Activity extends BaseActivity
{
  private DialogInterface dialog;
  private boolean isFinishBtn = true;
  private TextView mBottomBtn;
  private ImageView mIndicator1;
  private ImageView mIndicator2;
  private TextView mLabel1;
  private TextView mLabel2;
  private TextView mLabel3;
  private LinearLayout mLevelDes;
  private ViewPager mMViewPager;
  private TextView mTime1;
  private TextView mTime2;
  private CustomToolBar mToolbar;
  private TextView mValue1;
  private TextView mValue2;
  private TextView mValue3;
  private String sFitTarget;
  private String sFitWeight;
  private String strCurWeight;
  private String strInitWeight;
  private String strTargetWeight;
  private String strUserBMI;
  private String strUserHeight;
  private Mine02HealthData2Adapter vpAdapter;

  private void initView()
  {
    this.mMViewPager = ((ViewPager)findViewById(R.id.mViewPager));
    CompDeviceInfoUtils.getDeviceWidthHeight(this);
    int i = (int)(0.145F * BaseApplication.screenWidth);
    this.mMViewPager.setPadding(i, 0, i, 0);
    this.mLevelDes = ((LinearLayout)findViewById(R.id.levelDes));
    this.mIndicator1 = ((ImageView)findViewById(R.id.indicator1));
    this.mIndicator2 = ((ImageView)findViewById(R.id.indicator2));
    this.mLabel1 = ((TextView)findViewById(R.id.label1));
    this.mTime1 = ((TextView)findViewById(R.id.time1));
    this.mValue1 = ((TextView)findViewById(R.id.value1));
    this.mLabel2 = ((TextView)findViewById(R.id.label2));
    this.mTime2 = ((TextView)findViewById(R.id.time2));
    this.mValue2 = ((TextView)findViewById(R.id.value2));
    this.mLabel3 = ((TextView)findViewById(R.id.label3));
    this.mValue3 = ((TextView)findViewById(R.id.value3));
    this.mBottomBtn = ((TextView)findViewById(R.id.bottomBtn));
    this.mBottomBtn.setOnClickListener(new FitAction(this));
    TextView localTextView = this.mBottomBtn;
    Resources localResources = getResources();
    if (this.isFinishBtn);
    for (int j = R.string.c_75_3_9; ; j = R.string.c_75_5_2)
    {
      localTextView.setText(localResources.getString(j));
      this.mToolbar = ((CustomToolBar)findViewById(R.id.toolbar));
      this.mToolbar.setTitle(getResources().getString(R.string.c_75_3_1));
      this.mToolbar.setNavIcon(R.mipmap.btn_back_black);
      this.mToolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
      this.mToolbar.setBackgroundResource(R.color.white);
      setSupportActionBar(this.mToolbar);
      this.dialog = new DialogManager();
      return;
    }
  }

  private void setData()
  {
    UserModel localUserModel = new UserModel();
    String str1;
    String str2;
    if (!StringUtils.isNull(this.strUserHeight))
    {
      str1 = this.strUserHeight;
      localUserModel.height = str1;
      if (StringUtils.isNull(this.strInitWeight))
        break label166;
      str2 = this.strInitWeight;
      label43: localUserModel.initialWeight = str2;
      if (StringUtils.isNull(this.strInitWeight))
        break label189;
      if (!StringUtils.isNull(BaseApplication.userModel.currentWeight))
        break label176;
      localUserModel.currentWeight = this.strInitWeight;
      label78: localUserModel.bmi = this.strUserBMI;
      if (StringUtils.isNull(this.strTargetWeight))
        break label202;
    }
    label166: label176: label189: label202: for (String str3 = this.strTargetWeight; ; str3 = BaseApplication.userModel.targetWeight)
    {
      localUserModel.targetWeight = str3;
      this.vpAdapter = new Mine02HealthData2Adapter(this, localUserModel, this.isFinishBtn);
      this.mMViewPager.setAdapter(this.vpAdapter);
      this.mMViewPager.addOnPageChangeListener(new Mine02HealthData2Activity.1(this));
      setPager1Data();
      return;
      str1 = BaseApplication.userModel.height;
      break;
      str2 = BaseApplication.userModel.initialWeight;
      break label43;
      localUserModel.currentWeight = BaseApplication.userModel.currentWeight;
      break label78;
      localUserModel.currentWeight = BaseApplication.userModel.currentWeight;
      break label78;
    }
  }

  private void setPager1Data()
  {
    this.mToolbar.setTitle(getResources().getString(R.string.c_75_3_1));
    this.mIndicator1.setSelected(true);
    this.mIndicator2.setSelected(false);
    this.mLevelDes.setVisibility(4);
    this.mLabel1.setText(getResources().getString(R.string.c_75_3_2));
    this.mTime1.setVisibility(0);
    String str1;
    label187: String str2;
    label224: TextView localTextView4;
    Object[] arrayOfObject3;
    if (!StringUtils.isNull(this.strInitWeight))
      if (StringUtils.isNull(BaseApplication.userModel.currentWeight))
      {
        this.mTime1.setText(DateUtils10.convertCommentDate(String.valueOf(System.currentTimeMillis())));
        TextView localTextView6 = this.mValue1;
        Object[] arrayOfObject5 = new Object[1];
        arrayOfObject5[0] = this.strCurWeight;
        localTextView6.setText(String.format("%skg", arrayOfObject5));
        this.mLabel2.setText(getResources().getString(R.string.c_75_3_7));
        this.mTime2.setVisibility(0);
        TextView localTextView2 = this.mTime2;
        if (!StringUtils.isNull(BaseApplication.userModel.initialWeight))
          break label411;
        str1 = String.valueOf(System.currentTimeMillis());
        localTextView2.setText(DateUtils10.convertCommentDate(str1));
        TextView localTextView3 = this.mValue2;
        Object[] arrayOfObject2 = new Object[1];
        if (StringUtils.isNull(this.strInitWeight))
          break label422;
        str2 = this.strInitWeight;
        arrayOfObject2[0] = str2;
        localTextView3.setText(String.format("%skg", arrayOfObject2));
        this.mLabel3.setText(getResources().getString(R.string.c_75_3_8));
        localTextView4 = this.mValue3;
        arrayOfObject3 = new Object[1];
        if (StringUtils.isNull(this.strTargetWeight))
          break label433;
      }
    label411: label422: label433: for (String str3 = this.strTargetWeight; ; str3 = BaseApplication.userModel.targetWeight)
    {
      arrayOfObject3[0] = str3;
      localTextView4.setText(String.format("%skg", arrayOfObject3));
      return;
      this.mTime1.setText(DateUtils10.convertCommentDate(BaseApplication.userModel.currentWeightDate));
      TextView localTextView5 = this.mValue1;
      Object[] arrayOfObject4 = new Object[1];
      arrayOfObject4[0] = BaseApplication.userModel.currentWeight;
      localTextView5.setText(String.format("%skg", arrayOfObject4));
      break;
      this.mTime1.setText(DateUtils10.convertCommentDate(BaseApplication.userModel.currentWeightDate));
      TextView localTextView1 = this.mValue1;
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = BaseApplication.userModel.currentWeight;
      localTextView1.setText(String.format("%skg", arrayOfObject1));
      break;
      str1 = BaseApplication.userModel.initialWeightDate;
      break label187;
      str2 = BaseApplication.userModel.initialWeight;
      break label224;
    }
  }

  private void setPager2Data()
  {
    this.mToolbar.setTitle(getResources().getString(R.string.c_75_4_1));
    this.mIndicator1.setSelected(false);
    this.mIndicator2.setSelected(true);
    this.mLevelDes.setVisibility(0);
    this.mLabel1.setText(getResources().getString(R.string.c_75_4_6));
    HealthDataProgressBar3 localHealthDataProgressBar3;
    String str1;
    label218: float f;
    String str2;
    boolean bool1;
    if (!StringUtils.isNull(this.strInitWeight))
      if (StringUtils.isNull(BaseApplication.userModel.currentWeight))
      {
        TextView localTextView3 = this.mValue1;
        Object[] arrayOfObject3 = new Object[2];
        arrayOfObject3[0] = this.strUserHeight;
        arrayOfObject3[1] = this.strCurWeight;
        localTextView3.setText(String.format("%scm/%skg", arrayOfObject3));
        this.mTime1.setVisibility(8);
        this.mLabel2.setText(getResources().getString(R.string.c_75_4_8));
        this.mValue2.setText(this.sFitWeight);
        this.mTime2.setVisibility(8);
        this.mLabel3.setText(getResources().getString(R.string.c_75_4_10));
        this.mValue3.setText(this.sFitTarget);
        localHealthDataProgressBar3 = this.vpAdapter.getHealthDataProgressBar3();
        if (!StringUtils.isNull(this.strUserBMI))
          break label369;
        str1 = "0";
        f = Float.valueOf(str1).floatValue();
        str2 = Fit10Utils.getBodyStates(this.strUserBMI);
        bool1 = this.isFinishBtn;
        if (this.mLevelDes.getTag() != null)
          break label378;
      }
    label369: label378: for (boolean bool2 = true; ; bool2 = false)
    {
      localHealthDataProgressBar3.setData(f, str2, bool1, bool2);
      this.mLevelDes.setTag("have.been.execute");
      return;
      TextView localTextView2 = this.mValue1;
      Object[] arrayOfObject2 = new Object[2];
      arrayOfObject2[0] = BaseApplication.userModel.height;
      arrayOfObject2[1] = BaseApplication.userModel.currentWeight;
      localTextView2.setText(String.format("%scm/%skg", arrayOfObject2));
      break;
      TextView localTextView1 = this.mValue1;
      Object[] arrayOfObject1 = new Object[2];
      arrayOfObject1[0] = BaseApplication.userModel.height;
      arrayOfObject1[1] = BaseApplication.userModel.currentWeight;
      localTextView1.setText(String.format("%scm/%skg", arrayOfObject1));
      break;
      str1 = this.strUserBMI;
      break label218;
    }
  }

  public void fitOnClick(View paramView)
  {
    super.fitOnClick(paramView);
    if (paramView.getId() == R.id.bottomBtn)
    {
      if (!this.isFinishBtn)
        break label291;
      RequestModel localRequestModel = new RequestModel();
      if ((!StringUtils.isNull(this.strUserHeight)) && (!this.strUserHeight.equals(BaseApplication.userModel.height)))
        localRequestModel.height = this.strUserHeight;
      if ((!StringUtils.isNull(this.strTargetWeight)) && (!this.strTargetWeight.equals(BaseApplication.userModel.targetWeight)))
      {
        localRequestModel.targetWeight = this.strTargetWeight;
        EventBus.getDefault().post(new UpdateTargetWeightEvent(this.strTargetWeight));
      }
      if (StringUtils.isNull(BaseApplication.userModel.currentWeight))
        localRequestModel.currentWeight = this.strCurWeight;
      if ((!StringUtils.isNull(this.strUserBMI)) && (!this.strUserBMI.equals(BaseApplication.userModel.bmi)))
        localRequestModel.bmi = this.strUserBMI;
      localRequestModel.initialWeight = this.strInitWeight;
      this.dialog.createProgressDialog(this, StringUtils.getStringResources(R.string.wait_hint));
      MiddleManager.getInstance().getMinePresenterImpl(this).updateUserInfo(localRequestModel, this);
      if (StringUtils.isNull(BaseApplication.userModel.currentWeight))
      {
        WeightModel2 localWeightModel2 = new WeightModel2();
        localWeightModel2.recordDate = DateUtils10.date2String(new Date());
        localWeightModel2.girthType = "0";
        localWeightModel2.weight = String.valueOf(this.strCurWeight);
        localWeightModel2.setDMY(localWeightModel2.recordDate);
        WeightCommender.getInstance().addWeight(localWeightModel2);
        if (BaseApplication.userModel != null)
          BaseApplication.userModel.currentWeight = localWeightModel2.weight;
      }
    }
    return;
    label291: startActivity(new Intent(this, PerfectInfoFirstActivity.class));
    AnimationUtil.pageJumpAnim(this, 0);
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    if (this.dialog != null)
      this.dialog.closeDialog();
    ToastUtils.makeToast(BaseApplication.appliContext, StringUtils.getStringResources(R.string.save_error));
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if (this.dialog != null)
      this.dialog.closeDialog();
    EventBus.getDefault().post(new UpdateHealthDataFinishEvent());
    showEditComplete();
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.activity_mine02_health_data2);
    EventBus.getDefault().register(this);
    Intent localIntent = getIntent();
    if (localIntent != null)
    {
      this.strUserHeight = localIntent.getStringExtra("user.height");
      this.strInitWeight = localIntent.getStringExtra("user.current.weight");
      this.strTargetWeight = localIntent.getStringExtra("user.target.weight");
      this.strCurWeight = this.strInitWeight;
    }
    boolean bool;
    String str1;
    label97: String str2;
    if (!StringUtils.isNull(this.strInitWeight))
    {
      bool = true;
      this.isFinishBtn = bool;
      if (StringUtils.isNull(this.strInitWeight))
        break label177;
      str1 = this.strInitWeight;
      if (StringUtils.isNull(this.strUserHeight))
        break label188;
      str2 = this.strUserHeight;
      label113: this.strUserBMI = String.valueOf(Fit10Utils.getBMI(str1, str2));
      this.sFitTarget = Fit10Utils.getSuggestTarget(this.strUserBMI);
      if (StringUtils.isNull(this.strUserHeight))
        break label199;
    }
    label177: label188: label199: for (String str3 = this.strUserHeight; ; str3 = BaseApplication.userModel.height)
    {
      this.sFitWeight = Fit10Utils.getAdviceWight(str3);
      initView();
      setData();
      return;
      bool = false;
      break;
      str1 = BaseApplication.userModel.currentWeight;
      break label97;
      str2 = BaseApplication.userModel.height;
      break label113;
    }
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(UpdateHealthDataFinishEvent paramUpdateHealthDataFinishEvent)
  {
    if ((paramUpdateHealthDataFinishEvent != null) && (!StringUtils.isNull(paramUpdateHealthDataFinishEvent.strCloseHealthDataPageTag)))
      finish();
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  public void showEditComplete()
  {
    RelativeLayout localRelativeLayout = (RelativeLayout)findViewById(R.id.edit_complete_layout);
    if (localRelativeLayout != null)
    {
      Animation localAnimation = AnimationUtils.loadAnimation(this, R.anim.roll_up);
      localAnimation.setFillAfter(true);
      localRelativeLayout.setAnimation(localAnimation);
      localRelativeLayout.setVisibility(0);
      new Handler().postDelayed(new Mine02HealthData2Activity.2(this, localRelativeLayout), 2000L);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.Mine02HealthData2Activity
 * JD-Core Version:    0.6.0
 */