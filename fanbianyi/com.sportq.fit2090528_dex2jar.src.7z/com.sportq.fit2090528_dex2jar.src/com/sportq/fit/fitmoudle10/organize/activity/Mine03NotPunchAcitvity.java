package com.sportq.fit.fitmoudle10.organize.activity;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.event.NoPuchEvent;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.Mine03NotPunchAdapter;
import com.sportq.fit.fitmoudle10.organize.presenter.MinePresenterImpl;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Mine03NotPunchAcitvity extends BaseActivity
{
  Mine03NotPunchAdapter adapter;
  List<PlanReformer> list;
  MinePresenterImpl minePresenter;
  RecyclerView not_punch_recyclerView;
  CustomToolBar toolbar;

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine03_not_punch);
    EventBus.getDefault().register(this);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.toolbar.setTitle(R.string.c_86_1);
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundResource(R.color.white);
    setSupportActionBar(this.toolbar);
    this.not_punch_recyclerView = ((RecyclerView)findViewById(R.id.not_punch_recyclerView));
    this.not_punch_recyclerView.setLayoutManager(new LinearLayoutManager(this));
    this.minePresenter = new MinePresenterImpl(this);
    this.list = this.minePresenter.getNotPunchList();
    this.adapter = new Mine03NotPunchAdapter(this, this.list, R.layout.mine03_not_punch_item, this.minePresenter);
    this.not_punch_recyclerView.setAdapter(this.adapter);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(NoPuchEvent paramNoPuchEvent)
  {
    if (this.adapter != null)
    {
      if (this.minePresenter == null)
        this.minePresenter = new MinePresenterImpl(this);
      this.list = this.minePresenter.getNotPunchList();
      if (this.list.size() <= 0)
        break label86;
      if (this.adapter != null)
      {
        this.adapter.replaceAll(this.list);
        this.adapter.setList(this.list);
        this.adapter.notifyDataSetChanged();
      }
    }
    return;
    label86: finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.Mine03NotPunchAcitvity
 * JD-Core Version:    0.6.0
 */