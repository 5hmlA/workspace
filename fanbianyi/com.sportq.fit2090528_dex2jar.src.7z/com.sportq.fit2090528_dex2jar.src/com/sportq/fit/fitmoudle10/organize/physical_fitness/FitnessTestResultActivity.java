package com.sportq.fit.fitmoudle10.organize.physical_fitness;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.FitVipUserView;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.radar.RadarData;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.radar.RadarView;
import com.sportq.fit.fitmoudle10.organize.presenter.model.PhyResultModel;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.PhyResultReformer;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class FitnessTestResultActivity extends BaseActivity
{
  public static final String HIDE_RECOMMEND_BTN = "hide.recommend.btn";
  public static final String RESULT_DATA = "result.data";
  private TextView fitness_test_level;
  private LinearLayout fitness_test_linear;
  private TextView fitness_test_transcend_hint;
  private boolean isHideRecommendBtn = false;
  private TextView name;
  private PhyResultReformer phyResultReformer;
  private RadarView radarView;
  private LinearLayout share_linear_layout;
  private TextView test_evaluation_desc;
  private FitVipUserView user_icon;

  private void initElements()
  {
    findViewById(R.id.close_btn).setOnClickListener(new FitAction(this));
    findViewById(R.id.share_btn).setOnClickListener(new FitAction(this));
    this.name = ((TextView)findViewById(R.id.name));
    this.user_icon = ((FitVipUserView)findViewById(R.id.user_icon));
    this.fitness_test_level = ((TextView)findViewById(R.id.fitness_test_level));
    this.fitness_test_transcend_hint = ((TextView)findViewById(R.id.fitness_test_transcend_hint));
    this.fitness_test_linear = ((LinearLayout)findViewById(R.id.fitness_test_linear));
    this.radarView = ((RadarView)findViewById(R.id.radarView));
    this.test_evaluation_desc = ((TextView)findViewById(R.id.test_evaluation_desc));
    RTextView localRTextView = (RTextView)findViewById(R.id.get_recomm_train_btn);
    localRTextView.setOnClickListener(new FitAction(this));
    if (this.isHideRecommendBtn);
    for (int i = 8; ; i = 0)
    {
      localRTextView.setVisibility(i);
      this.share_linear_layout = ((LinearLayout)findViewById(R.id.share_linear_layout));
      return;
    }
  }

  private Bitmap loadBitmapFromView(View paramView)
  {
    int i = paramView.getWidth();
    int j = paramView.getHeight();
    Bitmap localBitmap = Bitmap.createBitmap(i, j, Bitmap.Config.ARGB_8888);
    Canvas localCanvas = new Canvas(localBitmap);
    localCanvas.drawColor(-1);
    paramView.layout(0, 0, i, j);
    paramView.draw(localCanvas);
    return localBitmap;
  }

  private void setDataForPage()
  {
    if (this.phyResultReformer == null)
    {
      finish();
      return;
    }
    this.name.setText(BaseApplication.userModel.userName);
    this.user_icon.setIsVip(0);
    this.user_icon.loadUserIcon(BaseApplication.userModel.userImg).setVipTagSize(CompDeviceInfoUtils.convertOfDip(this, 82.0F), 0.2857D);
    String str1 = "体能测试等级  " + this.phyResultReformer.levelCode;
    SpannableString localSpannableString1 = new SpannableString(str1);
    localSpannableString1.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.color_ffd208)), -1 + str1.length(), str1.length(), 33);
    this.fitness_test_level.setText(localSpannableString1);
    int i = R.string.c_78_21_2;
    String[] arrayOfString1 = new String[1];
    arrayOfString1[0] = this.phyResultReformer.fitNumber;
    String str2 = UseStringUtils.getStr(i, arrayOfString1);
    SpannableString localSpannableString2 = new SpannableString(str2);
    localSpannableString2.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.color_ffd208)), 5, -7 + str2.length(), 33);
    this.fitness_test_transcend_hint.setText(localSpannableString2);
    this.test_evaluation_desc.setText(this.phyResultReformer.phyTestEs);
    this.fitness_test_linear.setWeightSum(7.0F);
    int j = (int)(0.16022222D * BaseApplication.screenWidth);
    int[] arrayOfInt = new int[6];
    arrayOfInt[0] = (int)(0.1388888D * BaseApplication.screenWidth);
    arrayOfInt[1] = (int)(0.1805555D * BaseApplication.screenWidth);
    arrayOfInt[2] = (int)(0.222222D * BaseApplication.screenWidth);
    arrayOfInt[3] = (int)(0.2638888D * BaseApplication.screenWidth);
    arrayOfInt[4] = (int)(0.305555D * BaseApplication.screenWidth);
    arrayOfInt[5] = (int)(0.347222D * BaseApplication.screenWidth);
    String[] arrayOfString2 = new String[6];
    arrayOfString2[0] = getResources().getString(R.string.c_78_21_4);
    arrayOfString2[1] = getResources().getString(R.string.c_78_21_6);
    arrayOfString2[2] = getResources().getString(R.string.c_78_21_8);
    arrayOfString2[3] = getResources().getString(R.string.c_78_21_10);
    arrayOfString2[4] = getResources().getString(R.string.c_78_21_12);
    arrayOfString2[5] = getResources().getString(R.string.c_78_21_14);
    String[] arrayOfString3 = new String[6];
    arrayOfString3[0] = getResources().getString(R.string.c_78_21_3);
    arrayOfString3[1] = getResources().getString(R.string.c_78_21_5);
    arrayOfString3[2] = getResources().getString(R.string.c_78_21_7);
    arrayOfString3[3] = getResources().getString(R.string.c_78_21_9);
    arrayOfString3[4] = getResources().getString(R.string.c_78_21_11);
    arrayOfString3[5] = getResources().getString(R.string.c_78_21_13);
    int k = 0;
    if (k < 6)
    {
      View localView = LayoutInflater.from(this).inflate(R.layout.fitness_test_result_item, null);
      RelativeLayout localRelativeLayout = (RelativeLayout)localView.findViewById(R.id.column_relative_layout);
      TextView localTextView1 = (TextView)localView.findViewById(R.id.column_text01);
      TextView localTextView2 = (TextView)localView.findViewById(R.id.column_text02);
      localTextView1.setText(arrayOfString3[k]);
      localTextView2.setText(arrayOfString2[k]);
      this.fitness_test_linear.addView(localView);
      localView.setLayoutParams(new LinearLayout.LayoutParams(-2, arrayOfInt[5]));
      RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)localRelativeLayout.getLayoutParams();
      localLayoutParams.width = j;
      localLayoutParams.height = arrayOfInt[k];
      localLayoutParams.addRule(8, -1);
      if (k != 0)
        localLayoutParams.leftMargin = CompDeviceInfoUtils.convertOfDip(this, 3.0F);
      localRelativeLayout.setLayoutParams(localLayoutParams);
      if (this.phyResultReformer.levelCode.equals(arrayOfString3[k]))
      {
        localRelativeLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.color_ffd208));
        localTextView1.setTextColor(ContextCompat.getColor(this, R.color.color_313131));
        localTextView2.setTextColor(ContextCompat.getColor(this, R.color.color_313131));
      }
      while (true)
      {
        k++;
        break;
        localRelativeLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.color_2e2e2e));
        localTextView1.setTextColor(ContextCompat.getColor(this, R.color.color_6c6c6c));
        localTextView2.setTextColor(ContextCompat.getColor(this, R.color.color_6c6c6c));
      }
    }
    this.radarView.getLayoutParams().width = BaseApplication.screenWidth;
    this.radarView.getLayoutParams().height = (int)(0.92222D * BaseApplication.screenWidth);
    this.radarView.setEmptyHint("无数据");
    ArrayList localArrayList1 = new ArrayList();
    Integer[] arrayOfInteger1 = new Integer[5];
    arrayOfInteger1[0] = Integer.valueOf(R.color.color_ffd208);
    arrayOfInteger1[1] = Integer.valueOf(17170445);
    arrayOfInteger1[2] = Integer.valueOf(17170445);
    arrayOfInteger1[3] = Integer.valueOf(17170445);
    arrayOfInteger1[4] = Integer.valueOf(17170445);
    Collections.addAll(localArrayList1, arrayOfInteger1);
    this.radarView.setLayerColor(localArrayList1);
    ArrayList localArrayList2 = new ArrayList();
    ArrayList localArrayList3 = new ArrayList();
    ArrayList localArrayList4 = new ArrayList();
    Iterator localIterator = this.phyResultReformer.lstPhyScore.iterator();
    while (localIterator.hasNext())
    {
      PhyResultModel localPhyResultModel = (PhyResultModel)localIterator.next();
      localArrayList2.add(localPhyResultModel.name);
      localArrayList3.add(Integer.valueOf(localPhyResultModel.getScore));
      localArrayList4.add(Float.valueOf(localPhyResultModel.fullScore));
    }
    ArrayList localArrayList5 = new ArrayList();
    String[] arrayOfString4 = new String[6];
    arrayOfString4[0] = ((String)localArrayList2.get(1));
    arrayOfString4[1] = ((String)localArrayList2.get(2));
    arrayOfString4[2] = ((String)localArrayList2.get(3));
    arrayOfString4[3] = ((String)localArrayList2.get(4));
    arrayOfString4[4] = ((String)localArrayList2.get(5));
    arrayOfString4[5] = ((String)localArrayList2.get(0));
    Collections.addAll(localArrayList5, arrayOfString4);
    this.radarView.setVertexText(localArrayList5);
    ArrayList localArrayList6 = new ArrayList();
    Integer[] arrayOfInteger2 = new Integer[6];
    arrayOfInteger2[0] = Integer.valueOf(R.mipmap.icn_add_weight10);
    arrayOfInteger2[1] = Integer.valueOf(R.mipmap.icn_add_weight10);
    arrayOfInteger2[2] = Integer.valueOf(R.mipmap.icn_add_weight10);
    arrayOfInteger2[3] = Integer.valueOf(R.mipmap.icn_add_weight10);
    arrayOfInteger2[4] = Integer.valueOf(R.mipmap.icn_add_weight10);
    arrayOfInteger2[5] = Integer.valueOf(R.mipmap.icn_add_weight10);
    Collections.addAll(localArrayList6, arrayOfInteger2);
    this.radarView.setVertexIconResid(localArrayList6);
    this.radarView.setMaxValues(localArrayList4);
    ArrayList localArrayList7 = new ArrayList();
    Float[] arrayOfFloat = new Float[6];
    arrayOfFloat[0] = Float.valueOf(((Integer)localArrayList3.get(1)).intValue());
    arrayOfFloat[1] = Float.valueOf(((Integer)localArrayList3.get(2)).intValue());
    arrayOfFloat[2] = Float.valueOf(((Integer)localArrayList3.get(3)).intValue());
    arrayOfFloat[3] = Float.valueOf(((Integer)localArrayList3.get(4)).intValue());
    arrayOfFloat[4] = Float.valueOf(((Integer)localArrayList3.get(5)).intValue());
    arrayOfFloat[5] = Float.valueOf(((Integer)localArrayList3.get(0)).intValue());
    Collections.addAll(localArrayList7, arrayOfFloat);
    RadarData localRadarData = new RadarData(localArrayList7);
    this.radarView.addData(localRadarData);
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.close_btn)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() == R.id.share_btn)
      {
        new Handler().post(new FitnessTestResultActivity.1(this));
        continue;
      }
      if (paramView.getId() != R.id.get_recomm_train_btn)
        continue;
      Intent localIntent = new Intent(this, FitnessRecommTrainPlanActivity.class);
      localIntent.putExtra("level.code", this.phyResultReformer.levelCode);
      startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.fitness_test_result);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.phyResultReformer = ((PhyResultReformer)getIntent().getSerializableExtra("result.data"));
    this.isHideRecommendBtn = getIntent().getBooleanExtra("hide.recommend.btn", false);
    initElements();
    setDataForPage();
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("phy.close.other.page".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  public Bitmap viewSaveToImage(View paramView)
  {
    paramView.setDrawingCacheEnabled(true);
    paramView.setDrawingCacheQuality(1048576);
    paramView.setDrawingCacheBackgroundColor(getResources().getColor(R.color.color_313131));
    Bitmap localBitmap = loadBitmapFromView(paramView);
    paramView.setDrawingCacheEnabled(false);
    return localBitmap;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.physical_fitness.FitnessTestResultActivity
 * JD-Core Version:    0.6.0
 */