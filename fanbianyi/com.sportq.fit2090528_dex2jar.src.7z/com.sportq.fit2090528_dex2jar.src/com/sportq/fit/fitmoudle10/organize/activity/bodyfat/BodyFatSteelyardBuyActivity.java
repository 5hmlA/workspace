package com.sportq.fit.fitmoudle10.organize.activity.bodyfat;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.BodyFatBuyAdapter;
import com.sportq.fit.fitmoudle10.organize.eventbus.BodyFastEvent;
import com.sportq.fit.fitmoudle10.organize.eventbus.BodyFatBindFailEvent;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.BindBodyFastScale;
import com.sportq.fit.fitmoudle10.organize.presenter.FitMoudle10ApiPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.BodyFatSteelyarBuyReformer;
import com.sportq.fit.fitmoudle10.organize.utils.BindFailDialog;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class BodyFatSteelyardBuyActivity extends BaseActivity
{
  BodyFatBuyAdapter adapter;
  TextView bind_steelyard;
  RecyclerView recyclerView;
  CustomToolBar toolbar;

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.bind_steelyard)
    {
      BluetoothAdapter localBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
      if (localBluetoothAdapter == null)
      {
        ToastUtils.makeToast(this, "设备不支持蓝牙");
        return;
      }
      if (localBluetoothAdapter.getState() == 12)
        break label67;
      this.dialog.createChoiceDialog(new BodyFatSteelyardBuyActivity.1(this), this, "", "请打开手机蓝牙功能", "确定", "");
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      label67: startActivity(new Intent(this, BindBodyFastScale.class));
    }
  }

  public <T> void getDataFail(T paramT)
  {
    if ((paramT instanceof String))
      ToastUtils.makeToast(this, paramT.toString());
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    BodyFatSteelyarBuyReformer localBodyFatSteelyarBuyReformer;
    if ((paramT instanceof BodyFatSteelyarBuyReformer))
    {
      localBodyFatSteelyarBuyReformer = (BodyFatSteelyarBuyReformer)paramT;
      if (this.adapter != null)
        break label85;
      this.adapter = new BodyFatBuyAdapter(this, localBodyFatSteelyarBuyReformer.lstPro, R.layout.bodyfat_buy_item_layout);
      this.adapter.addHeaderView(View.inflate(this, R.layout.bodyfat_buy_header_view, null));
      this.adapter.addFooterView(View.inflate(this, R.layout.bodyfat_buy_footer_view, null));
      this.recyclerView.setAdapter(this.adapter);
    }
    while (true)
    {
      super.getDataSuccess(paramT);
      return;
      label85: this.adapter.replaceAll(localBodyFatSteelyarBuyReformer.lstPro);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.bodyfat_steelyard_buy_layout);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.toolbar.setTitle(R.string.c_77_1_1);
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundResource(R.color.white);
    setSupportActionBar(this.toolbar);
    this.bind_steelyard = ((TextView)findViewById(R.id.bind_steelyard));
    this.bind_steelyard.setOnClickListener(new FitAction(this));
    this.recyclerView = ((RecyclerView)findViewById(R.id.recycler_View));
    this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
    new FitMoudle10ApiPresenter(this).getScalePro(this);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(BodyFastEvent paramBodyFastEvent)
  {
    if ((paramBodyFastEvent != null) && (paramBodyFastEvent.isRefresh))
      finish();
  }

  @Subscribe
  public void onEventMainThread(BodyFatBindFailEvent paramBodyFatBindFailEvent)
  {
    if ((paramBodyFatBindFailEvent != null) && (!StringUtils.isNull(paramBodyFatBindFailEvent.strBindFail)))
      new BindFailDialog(this).showBindFailDialog("绑定失败");
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.bodyfat.BodyFatSteelyardBuyActivity
 * JD-Core Version:    0.6.0
 */