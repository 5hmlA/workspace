package com.sportq.fit.fitmoudle10.organize.activity.physicaltest;

import android.app.Dialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.support.percent.PercentRelativeLayout.LayoutParams;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.utils.superView.helper.RTextViewHelper;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.WGalleryAdapter;
import com.sportq.fit.fitmoudle10.organize.eventbus.PhysicalPlayEvent;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.FitnessTestResultActivity;
import com.sportq.fit.fitmoudle10.organize.presenter.FitMoudle10ApiPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.model.PhyActItemModel;
import com.sportq.fit.fitmoudle10.organize.presenter.model.PhyActModel;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.PhyActReformer;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.PhyResultReformer;
import com.sportq.fit.fitmoudle10.organize.utils.FileDownloadManager.OnDownloadListener;
import com.sportq.fit.fitmoudle10.organize.utils.MinesecSharePreUtils;
import com.sportq.fit.fitmoudle10.organize.widget.PhysicalVolumeView;
import com.sportq.fit.fitmoudle10.organize.widget.custom_gallery.WGallery;
import com.sportq.fit.supportlib.CommonUtils;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class PhysicalVideoActivity extends BaseActivity
  implements FileDownloadManager.OnDownloadListener
{
  public static final String PHYSICAL_DATA = "phy.data";
  private ImageView btn_close;
  private ProgressBar download_pro;
  private Dialog finishDialog;
  private Dialog finishDialog02;
  View finishView;
  private WGallery gallery;
  private boolean initResume = false;
  private boolean isBack = false;
  Dialog mDialog;
  private PhysicalVideoActivity.NetWorkChangeReceiver netWorkChangeReceiver;
  private PhysicalVolumeView physicalVolumeView;
  private LinearLayout physical_hint_title;
  private LinearLayout physical_layout;
  private TextView physical_test_content;
  private TextView physical_test_introduce;
  private TextView physical_test_name;
  private RTextView physical_test_start;
  private PhysicalPresenter presenter;
  private PhyActReformer reformer;
  private PhyResultReformer resultReformer;
  private RTextView skip_rest;
  private Dialog startDialog;
  View startView;

  private void physicalTestFinishDialog()
  {
    PhyBgMusicMediaPlayer.getInstance().resume();
    if (this.finishView == null)
      this.finishView = View.inflate(this, R.layout.physical_test_finished_layout, null);
    if (this.finishDialog == null)
    {
      this.finishDialog = new Dialog(this);
      this.finishDialog.requestWindowFeature(1);
      this.finishDialog.getWindow().setBackgroundDrawableResource(17170445);
      this.finishDialog.setCanceledOnTouchOutside(false);
      this.finishDialog.setCancelable(false);
      PercentRelativeLayout.LayoutParams localLayoutParams1 = new PercentRelativeLayout.LayoutParams(-1, -1);
      this.finishView.setLayoutParams(localLayoutParams1);
      this.skip_rest = ((RTextView)this.finishView.findViewById(R.id.skip_rest));
      this.physical_test_name = ((TextView)this.finishView.findViewById(R.id.physical_test_name));
      this.gallery = ((WGallery)this.finishView.findViewById(R.id.wgallery));
      this.gallery.getLayoutParams().width = (int)(0.8859D * BaseApplication.screenHeight);
    }
    this.skip_rest.setTag(null);
    this.finishDialog.dismiss();
    PhyActModel localPhyActModel = this.presenter.getCurrentInfo();
    int i = 0;
    int j = localPhyActModel.lstOption.size();
    int k = 0;
    WGalleryAdapter localWGalleryAdapter;
    if (i < j)
    {
      if ("1".equals(((PhyActItemModel)localPhyActModel.lstOption.get(i)).flag))
        k = i;
    }
    else
    {
      localWGalleryAdapter = new WGalleryAdapter(this, localPhyActModel.lstOption);
      if ((localPhyActModel.lstOption.size() <= 0) || (!((PhyActItemModel)localPhyActModel.lstOption.get(0)).name.contains("脚尖")))
        break label425;
    }
    label425: int n;
    for (int m = 120; ; n = 75)
    {
      this.gallery.setSpacing(CompDeviceInfoUtils.dipToPx(m));
      this.gallery.setAdapter(localWGalleryAdapter);
      this.gallery.setSelection(k);
      this.physical_test_name.setText(localPhyActModel.phyResComment);
      this.skip_rest.setOnClickListener(new PhysicalVideoActivity.5(this));
      this.finishDialog.setContentView(this.finishView);
      WindowManager.LayoutParams localLayoutParams = this.finishDialog.getWindow().getAttributes();
      localLayoutParams.width = -1;
      localLayoutParams.height = Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight);
      this.finishDialog.getWindow().setAttributes(localLayoutParams);
      Dialog localDialog = this.finishDialog;
      localDialog.show();
      VdsAgent.showDialog((Dialog)localDialog);
      return;
      i++;
      break;
    }
  }

  private void reSetBgMusic()
  {
    String str = MinesecSharePreUtils.getPhysicalBgMusic();
    if (StringUtils.isNull(str))
    {
      this.reformer.currentBgMShowName = this.reformer.defaultBgMName;
      this.reformer.currentBgUrl = this.reformer.defaultBgUrl;
      return;
    }
    this.reformer.currentBgMShowName = FileUtils.convertBgMusicName(str);
    this.reformer.currentBgUrl = (VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME + str);
  }

  private void restoreView()
  {
    this.download_pro.setVisibility(8);
    this.download_pro.setProgress(0);
    this.physical_test_start.setText(R.string.c_78_2_3);
    this.physical_test_start.setAlpha(1.0F);
    this.physical_test_start.setEnabled(true);
  }

  private void updateFailedDialog()
  {
    this.dialog.createChoiceDialog(new PhysicalVideoActivity.2(this), this, "", "网络异常，上传失败", getResources().getString(R.string.a_13_3), getResources().getString(R.string.a_13_2));
  }

  private void updatePhyResult()
  {
    CommonUtils.deleteFile(EnumConstant.FitUrl.GetPhyResult);
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.optionJson = new Gson().toJson(this.presenter.getResultList());
    LogUtils.e("提交体侧结果---", localRequestModel.optionJson);
    new FitMoudle10ApiPresenter(this).getPhyResult(this, localRequestModel);
  }

  public <T> void getDataFail(T paramT)
  {
    if (isFinishing())
      return;
    this.presenter.stopLoading();
    updateFailedDialog();
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT instanceof PhyResultReformer))
    {
      EventBus.getDefault().post("phy.close.other.page");
      this.presenter.stopLoading();
      this.resultReformer = ((PhyResultReformer)paramT);
      Intent localIntent = new Intent(this, FitnessTestResultActivity.class);
      localIntent.putExtra("result.data", this.resultReformer);
      startActivity(localIntent);
      finish();
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.physical_video_layout);
    getWindow().addFlags(128);
    getWindow().addFlags(4194304);
    getWindow().addFlags(1024);
    EventBus.getDefault().register(this);
    this.reformer = ((PhyActReformer)getIntent().getSerializableExtra("phy.data"));
    reSetBgMusic();
    this.dialog = new DialogManager();
    this.physical_layout = ((LinearLayout)findViewById(R.id.physical_layout));
    this.initResume = true;
    this.presenter = new PhysicalPresenter(this, this.physical_layout, this.reformer);
    this.presenter.playCurrentVideo();
    new Handler().postDelayed(new PhysicalVideoActivity.1(this), 200L);
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
    this.netWorkChangeReceiver = new PhysicalVideoActivity.NetWorkChangeReceiver(this, null);
    registerReceiver(this.netWorkChangeReceiver, localIntentFilter);
  }

  protected void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    if (this.presenter != null)
      this.presenter.onDestroy();
    try
    {
      if (this.netWorkChangeReceiver != null)
        unregisterReceiver(this.netWorkChangeReceiver);
      PhyBgMusicMediaPlayer.getInstance().destroy();
      super.onDestroy();
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      while (true)
        LogUtils.e(localIllegalArgumentException);
    }
  }

  public void onError()
  {
  }

  @Subscribe
  public void onEventMainThread(PhysicalPlayEvent paramPhysicalPlayEvent)
  {
    String str1 = paramPhysicalPlayEvent.strType;
    int i = -1;
    switch (str1.hashCode())
    {
    default:
    case 48:
    case 49:
    case 50:
    case 51:
    case 52:
    }
    while (true)
      switch (i)
      {
      default:
        return;
        if (!str1.equals("0"))
          continue;
        i = 0;
        continue;
        if (!str1.equals("1"))
          continue;
        i = 1;
        continue;
        if (!str1.equals("2"))
          continue;
        i = 2;
        continue;
        if (!str1.equals("3"))
          continue;
        i = 3;
        continue;
        if (!str1.equals("4"))
          continue;
        i = 4;
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      }
    if (this.presenter.isHavePhyResult())
    {
      physicalTestFinishDialog();
      return;
    }
    PhyBgMusicMediaPlayer.getInstance().pause();
    this.presenter.pausePlay();
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      updateFailedDialog();
      return;
    }
    this.presenter.loading();
    updatePhyResult();
    return;
    this.presenter.countDownTimeSubscriptionStop();
    if ((this.presenter.isHavePhyResult()) && (this.gallery != null))
      this.presenter.setPhyResult(this.gallery.getSelectedItemPosition());
    this.presenter.addIndex();
    if (this.presenter.isHavePhyResult())
      physicalTestStartDialog();
    while (true)
    {
      new Handler().postDelayed(new PhysicalVideoActivity.12(this), 500L);
      return;
      this.presenter.playCurrentVideo();
    }
    PhyBgMusicMediaPlayer.getInstance().pause();
    String str2;
    if (this.presenter.isWarmUpStage())
      str2 = getString(R.string.c_80_5_1);
    while (true)
    {
      Dialog localDialog2 = this.dialog.createChoiceDialog(new PhysicalVideoActivity.13(this), this, "", str2, getString(R.string.c_80_3_3), getString(R.string.c_80_3_2));
      localDialog2.setCanceledOnTouchOutside(false);
      localDialog2.setCancelable(false);
      return;
      if (this.presenter.isStretchStage())
      {
        str2 = getString(R.string.c_78_26_21);
        continue;
      }
      str2 = getString(R.string.c_80_4_1);
    }
    PhyBgMusicMediaPlayer.getInstance().pause();
    Dialog localDialog1 = this.dialog.createChoiceDialog(new PhysicalVideoActivity.14(this), this, "", getString(R.string.c_80_3_1), getString(R.string.c_80_3_3), getString(R.string.c_80_3_2));
    localDialog1.setCancelable(false);
    localDialog1.setCanceledOnTouchOutside(false);
    return;
    showVolumeDialog();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      this.presenter.pausePlay();
      onEventMainThread(new PhysicalPlayEvent("3"));
    }
    return false;
  }

  public void onLoading(float paramFloat)
  {
    if (this.download_pro.getVisibility() != 0)
    {
      this.download_pro.setVisibility(0);
      this.physical_test_start.setText("下载中");
      this.physical_test_start.setAlpha(0.6F);
      this.physical_test_start.setEnabled(false);
    }
    if (paramFloat < 0.0F);
    do
      return;
    while (this.download_pro.getProgress() > paramFloat);
    this.download_pro.setProgress((int)paramFloat);
  }

  protected void onPause()
  {
    super.onPause();
    this.isBack = true;
    PhyBgMusicMediaPlayer.getInstance().pause();
    if (this.presenter == null)
      return;
    if ((this.finishDialog != null) && (this.finishDialog.isShowing()))
      this.presenter.countDownTimeSubscriptionStop();
    this.presenter.pausePlay();
  }

  protected void onResume()
  {
    super.onResume();
    this.isBack = false;
    if (this.initResume)
      this.initResume = false;
    while (true)
    {
      return;
      try
      {
        if (this.presenter == null)
          this.presenter = new PhysicalPresenter(this, this.physical_layout, this.reformer);
        if (((this.startDialog != null) && (this.startDialog.isShowing())) || ((this.finishDialog != null) && (this.finishDialog.isShowing())) || (this.presenter.isPause()))
          continue;
        LogUtils.e("恢复播放---", "onResume");
        this.presenter.resumePlay();
        return;
      }
      catch (Exception localException)
      {
        finish();
        LogUtils.e(localException);
      }
    }
  }

  public void onSuccess()
  {
    LogUtils.e("下载成功----", "onSuccess");
    if ((this.isBack) || (this.finishDialog02 != null))
      restoreView();
    do
    {
      return;
      PhyBgMusicMediaPlayer.getInstance().resume();
      this.presenter.playCurrentVideo();
      new Handler().postDelayed(new PhysicalVideoActivity.15(this), 300L);
    }
    while (this.download_pro.getVisibility() != 0);
    restoreView();
  }

  public void physicalTestStartDialog()
  {
    PhyBgMusicMediaPlayer.getInstance().resume();
    if (this.startView == null)
      this.startView = View.inflate(this, R.layout.physical_test_hint_layout, null);
    if (this.startDialog == null)
    {
      Dialog localDialog1 = new Dialog(this);
      this.startDialog = localDialog1;
      this.startDialog.requestWindowFeature(1);
      this.startDialog.getWindow().setBackgroundDrawableResource(17170445);
      this.startDialog.setCanceledOnTouchOutside(false);
      this.startDialog.setCancelable(false);
      PercentRelativeLayout.LayoutParams localLayoutParams = new PercentRelativeLayout.LayoutParams(-1, -1);
      this.startView.setLayoutParams(localLayoutParams);
      this.physical_hint_title = ((LinearLayout)this.startView.findViewById(R.id.physical_hint_title));
      this.physical_test_content = ((TextView)this.startView.findViewById(R.id.physical_test_content));
      this.physical_test_introduce = ((TextView)this.startView.findViewById(R.id.physical_test_introduce));
      this.physical_test_start = ((RTextView)this.startView.findViewById(R.id.physical_test_start));
      this.download_pro = ((ProgressBar)this.startView.findViewById(R.id.download_pro));
      this.btn_close = ((ImageView)this.startView.findViewById(R.id.btn_close));
    }
    this.download_pro.setVisibility(8);
    this.download_pro.setProgress(0);
    this.physical_test_start.setTag(null);
    this.startDialog.dismiss();
    this.physical_hint_title.removeAllViews();
    this.physical_hint_title.setWeightSum(this.reformer.trainActionNum);
    int i = (int)(0.0625D * BaseApplication.screenHeight);
    RelativeLayout.LayoutParams localLayoutParams1 = new RelativeLayout.LayoutParams(i, i);
    int j = 0;
    if (j < this.reformer.trainActionNum)
    {
      View localView = View.inflate(this, R.layout.physical_test_hint_item_layout, null);
      localView.setLayoutParams(new RelativeLayout.LayoutParams(CompDeviceInfoUtils.convertOfDip(this, 70.0F), CompDeviceInfoUtils.convertOfDip(this, 70.0F)));
      RelativeLayout localRelativeLayout = (RelativeLayout)localView.findViewById(R.id.item_finished_icn);
      RTextView localRTextView2 = (RTextView)localView.findViewById(R.id.item_unfinished_icn);
      localRelativeLayout.setLayoutParams(localLayoutParams1);
      localRTextView2.setLayoutParams(localLayoutParams1);
      if (j < -1 + this.presenter.getCurrentIndex())
      {
        localRelativeLayout.setVisibility(0);
        localRTextView2.setVisibility(8);
      }
      while (true)
      {
        this.physical_hint_title.addView(localView);
        j++;
        break;
        if (j == -1 + this.presenter.getCurrentIndex())
        {
          localRelativeLayout.setVisibility(8);
          localRTextView2.setVisibility(0);
          localRTextView2.getHelper().setCornerRadius(180.0F);
          localRTextView2.getHelper().setBackgroundColorNormal(getResources().getColor(R.color.color_ffd208));
          localRTextView2.setText(String.valueOf(j + 1));
          localRTextView2.setTextColor(ContextCompat.getColor(this, R.color.color_313131));
          continue;
        }
        localRelativeLayout.setVisibility(8);
        localRTextView2.setVisibility(0);
        localRTextView2.getHelper().setCornerRadius(180.0F);
        localRTextView2.getHelper().setBackgroundColorNormal(getResources().getColor(R.color.color_494949));
        localRTextView2.setText(String.valueOf(j + 1));
        localRTextView2.setTextColor(ContextCompat.getColor(this, R.color.color_313131));
      }
    }
    this.physical_test_content.setText(this.presenter.getCurrentInfo().name);
    String str1 = this.presenter.getCurrentInfo().phyComment;
    String str2 = this.presenter.getCurrentInfo().phyColorComment;
    int k = str1.indexOf(str2);
    int m = k + str2.length();
    SpannableString localSpannableString = new SpannableString(str1);
    localSpannableString.setSpan(new ForegroundColorSpan(ContextCompat.getColor(this, R.color.color_ffd208)), k, m, 18);
    this.physical_test_introduce.setText(localSpannableString);
    RTextView localRTextView1 = this.physical_test_start;
    PhysicalVideoActivity.3 local3 = new PhysicalVideoActivity.3(this);
    localRTextView1.setOnClickListener(local3);
    ImageView localImageView = this.btn_close;
    PhysicalVideoActivity.4 local4 = new PhysicalVideoActivity.4(this);
    localImageView.setOnClickListener(local4);
    this.startDialog.setContentView(this.startView);
    WindowManager.LayoutParams localLayoutParams2 = this.startDialog.getWindow().getAttributes();
    localLayoutParams2.width = -1;
    localLayoutParams2.height = Math.min(BaseApplication.screenWidth, BaseApplication.screenHeight);
    this.startDialog.getWindow().setAttributes(localLayoutParams2);
    Dialog localDialog2 = this.startDialog;
    localDialog2.show();
    VdsAgent.showDialog((Dialog)localDialog2);
  }

  public void showVolumeDialog()
  {
    this.presenter.setVolumeShow(true);
    this.presenter.pausePlay();
    this.physicalVolumeView = new PhysicalVolumeView(this, this.reformer);
    this.physicalVolumeView.setRestoreOnClickListener(new PhysicalVideoActivity.6(this));
    this.physicalVolumeView.setActionOnSeekBarChangeListener(new PhysicalVideoActivity.7(this));
    this.physicalVolumeView.setBgMusicOnSeekBarChangeListener(new PhysicalVideoActivity.8(this));
    this.physicalVolumeView.setBgOnCheckedChangeListener(new PhysicalVideoActivity.9(this));
    this.physicalVolumeView.setOnDismissListener(new PhysicalVideoActivity.10(this));
    this.physicalVolumeView.setBgMOnChangeListener(new PhysicalVideoActivity.11(this));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.physicaltest.PhysicalVideoActivity
 * JD-Core Version:    0.6.0
 */