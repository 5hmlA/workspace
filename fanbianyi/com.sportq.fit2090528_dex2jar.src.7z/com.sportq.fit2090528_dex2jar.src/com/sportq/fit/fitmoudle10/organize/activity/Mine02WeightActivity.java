package com.sportq.fit.fitmoudle10.organize.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.GetBindScaleModel;
import com.sportq.fit.common.reformer.GetBindScaleReformer;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.Mine02WeightAdapter;
import com.sportq.fit.fitmoudle10.organize.eventbus.BodyFastEvent;
import com.sportq.fit.fitmoudle10.organize.presenter.FitMoudle10ApiPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.WeightPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.WeightReformer2;
import com.sportq.fit.fitmoudle10.organize.utils.BindFailDialog;
import com.sportq.fit.fitmoudle10.organize.utils.BodyFastBindStoreUtils;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Mine02WeightActivity extends BaseActivity
  implements View.OnClickListener
{
  private Mine02WeightAdapter adapter;
  public BodyFastEvent bodyFastEvent;
  private WeightPresenter presenter;

  private void getData()
  {
    if (this.presenter == null)
      this.presenter = new WeightPresenter(this);
    if (this.dialog == null)
      this.dialog = new DialogManager();
    this.dialog.createProgressDialog(this, StringUtils.getStringResources(R.string.wait_hint));
    this.presenter.getWeight(this);
  }

  private void initView()
  {
    ((ImageView)findViewById(R.id.backBtn)).setOnClickListener(this);
    CustomTabLayout localCustomTabLayout = (CustomTabLayout)findViewById(R.id.tabLayout);
    ((TextView)findViewById(R.id.editBtn)).setOnClickListener(this);
    ViewPager localViewPager = (ViewPager)findViewById(R.id.viewPager);
    this.adapter = new Mine02WeightAdapter(getSupportFragmentManager());
    localViewPager.setAdapter(this.adapter);
    localCustomTabLayout.setViewPager(localViewPager);
  }

  private void setData(WeightReformer2 paramWeightReformer2)
  {
    this.adapter.setData(paramWeightReformer2, this);
  }

  public <T> void getDataFail(T paramT)
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
    WeightReformer2 localWeightReformer2;
    if ((paramT instanceof WeightReformer2))
    {
      localWeightReformer2 = (WeightReformer2)paramT;
      if (localWeightReformer2.isNeedGetDataFromDB)
      {
        this.presenter.getAllData();
        ArrayList localArrayList = BodyFastBindStoreUtils.getBodyFastDataList(this);
        if ((localArrayList == null) || (localArrayList.size() == 0))
          new FitMoudle10ApiPresenter(this).getBindScale(this);
      }
    }
    do
    {
      GetBindScaleReformer localGetBindScaleReformer;
      do
      {
        do
        {
          return;
          this.presenter.setReformer2(localWeightReformer2);
          setData(this.presenter.getReformer2());
          break;
        }
        while (!(paramT instanceof GetBindScaleReformer));
        localGetBindScaleReformer = (GetBindScaleReformer)paramT;
      }
      while ((localGetBindScaleReformer.lstScaleDevice == null) || (localGetBindScaleReformer.lstScaleDevice.size() <= 0));
      Iterator localIterator = localGetBindScaleReformer.lstScaleDevice.iterator();
      while (localIterator.hasNext())
      {
        GetBindScaleModel localGetBindScaleModel = (GetBindScaleModel)localIterator.next();
        BodyFastBindStoreUtils.appendCourseData(localGetBindScaleModel.scaleName + "±" + localGetBindScaleModel.scaleDeviceId + "±" + "null", localGetBindScaleModel.scaleName, this);
      }
    }
    while (this.adapter == null);
    this.adapter.checkBodyFastLockUI();
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.activity_weight);
    EventBus.getDefault().register(this);
    initView();
    this.presenter = new WeightPresenter(this);
    this.presenter.checkSurroundSet();
    getData();
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  @Instrumented
  public void onClick(View paramView)
  {
    VdsAgent.onClick(this, paramView);
    int i = paramView.getId();
    if (i == R.id.backBtn)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    do
      return;
    while (i != R.id.editBtn);
    startActivity(new Intent(this, MineWeightSetActivity.class));
    AnimationUtil.pageJumpAnim(this, 0);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(BodyFastEvent paramBodyFastEvent)
  {
    if ((paramBodyFastEvent != null) && (paramBodyFastEvent.isRefresh))
    {
      this.bodyFastEvent = paramBodyFastEvent;
      if (!"0".equals(this.bodyFastEvent.strOperateType))
        break label103;
      if (this.dialog == null)
        this.dialog = new DialogManager();
      this.adapter.checkBodyFastLockUI();
      this.dialog.createChoiceDialog(new Mine02WeightActivity.1(this), this, "", getResources().getString(R.string.c_77_3_1), getResources().getString(R.string.c_77_3_2), "");
    }
    label103: 
    do
      return;
    while (!"1".equals(this.bodyFastEvent.strOperateType));
    new BindFailDialog(this).showBindFailDialog(getResources().getString(R.string.c_77_15_1));
    this.adapter.checkBodyFastLockUI();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("bodyfat.update.success".equals(paramString))
      getData();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.Mine02WeightActivity
 * JD-Core Version:    0.6.0
 */