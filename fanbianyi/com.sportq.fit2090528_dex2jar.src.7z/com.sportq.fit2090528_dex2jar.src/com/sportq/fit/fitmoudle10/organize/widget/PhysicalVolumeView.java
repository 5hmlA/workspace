package com.sportq.fit.fitmoudle10.organize.widget;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.kyleduo.switchbutton.SwitchButton;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.presenter.video.Callback;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.FileUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.organize.activity.physicaltest.PhyBgMusicMediaPlayer;
import com.sportq.fit.fitmoudle10.organize.activity.physicaltest.PhysicalPlayTools;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.PhyActReformer;
import com.sportq.fit.fitmoudle10.organize.utils.MinesecSharePreUtils;
import java.io.File;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class PhysicalVolumeView
{
  private SeekBar.OnSeekBarChangeListener actionOnSeekBarChangeListener;
  private SeekBar actionSeekBar;
  private Callback bgMOnChangeListener;
  private ArrayList<File> bgMusicList;
  private CustomTextView bgMusicName;
  private SeekBar.OnSeekBarChangeListener bgMusicOnSeekBarChangeListener;
  private CompoundButton.OnCheckedChangeListener bgOnCheckedChangeListener;
  private View.OnClickListener closeOnClickListener;
  private String currentBgMShowName;
  private String currentBgUrl;
  private String defaultBgMName;
  private String defaultBgUrl;
  private boolean isVipMusic = false;
  private Context mContext;
  private LinearLayout musicChooseLayout;
  private CustomTextView musicHint;
  private LinearLayout musicLayout;
  private SeekBar musicSeekBar;
  private ImageView nextBgMBtn;
  private DialogInterface.OnDismissListener onDismissListener;
  private ImageView previousBgMBtn;
  private RTextView restoreDefaultsLayout;
  private View.OnClickListener restoreOnClickListener;
  private int selectIndex = -1;
  private SwitchButton switchButton;
  private float toggle = Constant.MUSIC_ON;
  private Drawable vipDrawable;
  private Dialog volumeDialog;

  public PhysicalVolumeView(Context paramContext, PhyActReformer paramPhyActReformer)
  {
    this.bgMusicList = paramPhyActReformer.bgMusicList;
    this.defaultBgMName = paramPhyActReformer.defaultBgMName;
    this.defaultBgUrl = paramPhyActReformer.defaultBgUrl;
    String str = MinesecSharePreUtils.getPhysicalBgMusic();
    if (StringUtils.isNull(str))
      paramPhyActReformer.currentBgMShowName = paramPhyActReformer.defaultBgMName;
    for (paramPhyActReformer.currentBgUrl = paramPhyActReformer.defaultBgUrl; ; paramPhyActReformer.currentBgUrl = (VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME + str))
    {
      this.currentBgMShowName = paramPhyActReformer.currentBgMShowName;
      this.currentBgUrl = paramPhyActReformer.currentBgUrl;
      this.selectIndex = PhysicalPlayTools.getSelectedIndex(paramPhyActReformer);
      initUI(paramContext);
      EventBus.getDefault().register(this);
      return;
      paramPhyActReformer.currentBgMShowName = FileUtils.convertBgMusicName(str);
    }
  }

  private void bgMusicToggle(int paramInt)
  {
    if (this.bgMusicList == null)
      return;
    this.selectIndex = (paramInt + this.selectIndex);
    if (this.selectIndex < -1)
      this.selectIndex = (-1 + this.bgMusicList.size());
    if (this.selectIndex > -1 + this.bgMusicList.size())
      this.selectIndex = -1;
    if (this.selectIndex == -1)
    {
      this.currentBgMShowName = this.defaultBgMName;
      this.currentBgUrl = this.defaultBgUrl;
      this.isVipMusic = false;
      clearBgMInShare();
    }
    while (true)
    {
      refreshBGMLayoutUI();
      PhyBgMusicMediaPlayer.getInstance().setDataSource(this.currentBgUrl);
      this.bgMOnChangeListener.callback(Integer.valueOf(this.selectIndex));
      setShowRestoreDefaultsBtn();
      return;
      File localFile = (File)this.bgMusicList.get(this.selectIndex);
      this.currentBgMShowName = FileUtils.convertBgMusicName(localFile.getName());
      this.currentBgUrl = ((File)this.bgMusicList.get(this.selectIndex)).getAbsolutePath();
      this.isVipMusic = PhysicalPlayTools.isVipMusic(localFile.getName());
      MinesecSharePreUtils.putPhysicalBgMusic(localFile.getName());
    }
  }

  private void clearBgMInShare()
  {
    MinesecSharePreUtils.putPhysicalBgMusic("");
  }

  private void initUI(Context paramContext)
  {
    this.mContext = paramContext;
    if (this.volumeDialog == null)
    {
      this.volumeDialog = new Dialog(paramContext);
      this.volumeDialog.requestWindowFeature(1);
      this.volumeDialog.setCanceledOnTouchOutside(false);
      this.volumeDialog.getWindow().setBackgroundDrawableResource(R.color.color_313131);
    }
    this.volumeDialog.setContentView(R.layout.physical_dialog_volume);
    WindowManager.LayoutParams localLayoutParams = this.volumeDialog.getWindow().getAttributes();
    localLayoutParams.width = Math.max(BaseApplication.screenHeight, BaseApplication.screenWidth);
    localLayoutParams.height = Math.min(BaseApplication.screenHeight, BaseApplication.screenWidth);
    localLayoutParams.gravity = 17;
    this.volumeDialog.getWindow().setAttributes(localLayoutParams);
    Dialog localDialog = this.volumeDialog;
    localDialog.show();
    VdsAgent.showDialog((Dialog)localDialog);
    this.volumeDialog.setOnDismissListener(new PhysicalVolumeView.1(this));
    float f1 = MinesecSharePreUtils.getPhysicalActionVolume();
    int i;
    float f2;
    if (f1 == -1.0F)
    {
      i = (int)(Constant.MAX_VOLUME_VALUE * Constant.DEFAULT_VOLUME_VALUE);
      f2 = MinesecSharePreUtils.getPhysicalBgVolume();
      if (f2 != -1.0F)
        break label658;
    }
    label658: for (int j = (int)(Constant.MAX_VOLUME_VALUE * Constant.DEFAULT_VOLUME_VALUE); ; j = (int)(f2 * Constant.MAX_VOLUME_VALUE))
    {
      this.toggle = MinesecSharePreUtils.getPhysicalMusicState();
      this.actionSeekBar = ((SeekBar)this.volumeDialog.findViewById(R.id.action_seekBar));
      this.musicSeekBar = ((SeekBar)this.volumeDialog.findViewById(R.id.music_seekBar));
      this.switchButton = ((SwitchButton)this.volumeDialog.findViewById(R.id.bg_switch_button));
      this.musicHint = ((CustomTextView)this.volumeDialog.findViewById(R.id.music_hint));
      this.musicLayout = ((LinearLayout)this.volumeDialog.findViewById(R.id.music_layout));
      this.musicChooseLayout = ((LinearLayout)this.volumeDialog.findViewById(R.id.dialog_volume_music_choose_layout));
      this.previousBgMBtn = ((ImageView)this.volumeDialog.findViewById(R.id.dialog_volume_previous));
      this.nextBgMBtn = ((ImageView)this.volumeDialog.findViewById(R.id.dialog_volume_next));
      this.bgMusicName = ((CustomTextView)this.volumeDialog.findViewById(R.id.dialog_volume_music_name));
      this.restoreDefaultsLayout = ((RTextView)this.volumeDialog.findViewById(R.id.restore_view));
      this.volumeDialog.findViewById(R.id.dialog_volume_progressbar_layout).getLayoutParams().width = (int)(0.485D * Math.max(BaseApplication.screenHeight, BaseApplication.screenWidth));
      this.vipDrawable = ContextCompat.getDrawable(this.mContext, R.mipmap.vip_icon);
      this.vipDrawable.setBounds(0, 0, CompDeviceInfoUtils.convertOfDip(this.mContext, 15.0F), CompDeviceInfoUtils.convertOfDip(this.mContext, 15.0F));
      this.isVipMusic = PhysicalPlayTools.isVipMusic(this.currentBgUrl.replace(VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME, ""));
      this.previousBgMBtn.setOnClickListener(new PhysicalVolumeView.2(this));
      this.nextBgMBtn.setOnClickListener(new PhysicalVolumeView.3(this));
      refreshBGMLayoutUI();
      this.volumeDialog.findViewById(R.id.close_layout).setOnClickListener(new PhysicalVolumeView.4(this));
      this.switchButton.setOnCheckedChangeListener(new PhysicalVolumeView.5(this));
      this.switchButton.setAnimationDuration(0L);
      this.switchButton.setChecked(isMusicOn());
      this.actionSeekBar.setMax((int)Constant.MAX_VOLUME_VALUE);
      this.musicSeekBar.setMax((int)Constant.MAX_VOLUME_VALUE);
      this.actionSeekBar.setProgress(i);
      this.musicSeekBar.setProgress(j);
      this.restoreDefaultsLayout.setOnClickListener(new PhysicalVolumeView.6(this));
      this.actionSeekBar.setOnSeekBarChangeListener(new PhysicalVolumeView.7(this));
      this.musicSeekBar.setOnSeekBarChangeListener(new PhysicalVolumeView.8(this));
      setShowRestoreDefaultsBtn();
      return;
      i = (int)(f1 * Constant.MAX_VOLUME_VALUE);
      break;
    }
  }

  private boolean isMusicOn()
  {
    return Constant.MUSIC_ON == this.toggle;
  }

  private void refreshBGMLayoutUI()
  {
    setBgMName();
    showPreviewNextBtn();
  }

  private void restoreBgM()
  {
    if (this.selectIndex != -1)
      PhyBgMusicMediaPlayer.getInstance().setDataSource(this.defaultBgUrl);
    this.currentBgUrl = this.defaultBgUrl;
    this.currentBgMShowName = this.defaultBgMName;
    this.selectIndex = -1;
    this.isVipMusic = PhysicalPlayTools.isVipMusic(this.currentBgUrl.replace(VersionUpdateCheck.ALBUM_MUSIC_FILE_NAME, ""));
    refreshBGMLayoutUI();
  }

  private void setBgMName()
  {
    CustomTextView localCustomTextView;
    if (this.currentBgMShowName.equals(this.defaultBgMName))
    {
      this.bgMusicName.setText("Fit推荐：" + this.defaultBgMName);
      localCustomTextView = this.bgMusicName;
      if (!this.isVipMusic)
        break label84;
    }
    label84: for (Drawable localDrawable = this.vipDrawable; ; localDrawable = null)
    {
      localCustomTextView.setCompoundDrawables(null, null, localDrawable, null);
      return;
      this.bgMusicName.setText(this.currentBgMShowName);
      break;
    }
  }

  private void setShowRestoreDefaultsBtn()
  {
    if ((this.actionSeekBar.getProgress() == Constant.MAX_VOLUME_VALUE * Constant.DEFAULT_VOLUME_VALUE) && (this.musicSeekBar.getProgress() == Constant.MAX_VOLUME_VALUE * Constant.DEFAULT_VOLUME_VALUE) && (this.switchButton.isChecked()) && (this.selectIndex == -1))
    {
      this.restoreDefaultsLayout.setVisibility(8);
      return;
    }
    this.restoreDefaultsLayout.setVisibility(0);
  }

  private void showMusicLayout(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      this.toggle = Constant.MUSIC_ON;
      this.switchButton.setThumbDrawableRes(R.mipmap.icn_music_on);
      this.musicHint.setVisibility(8);
      this.musicLayout.setVisibility(0);
      this.musicChooseLayout.setVisibility(0);
      return;
    }
    this.toggle = Constant.MUSIC_OFF;
    this.switchButton.setThumbDrawableRes(R.mipmap.icn_music_off);
    this.musicHint.setVisibility(0);
    this.musicLayout.setVisibility(4);
    this.musicChooseLayout.setVisibility(8);
  }

  private void showPreviewNextBtn()
  {
    this.previousBgMBtn.setVisibility(0);
    this.nextBgMBtn.setVisibility(0);
    if ((this.bgMusicList != null) && (this.bgMusicList.size() == 0))
    {
      this.previousBgMBtn.setVisibility(4);
      this.nextBgMBtn.setVisibility(4);
    }
  }

  public void dismiss()
  {
    if (this.volumeDialog != null)
      this.volumeDialog.dismiss();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("phy.bg.player.error".equals(paramString))
    {
      this.bgMusicList = PhysicalPlayTools.getBgMusicList(this.defaultBgMName);
      restoreBgM();
    }
  }

  public void save()
  {
    MinesecSharePreUtils.putPhysicalActionVolume(this.actionSeekBar.getProgress() / Constant.MAX_VOLUME_VALUE);
    MinesecSharePreUtils.putPhysicalBgVolume(this.musicSeekBar.getProgress() / Constant.MAX_VOLUME_VALUE);
    MinesecSharePreUtils.putPhysicalMusicState(this.toggle);
  }

  public void setActionOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener paramOnSeekBarChangeListener)
  {
    this.actionOnSeekBarChangeListener = paramOnSeekBarChangeListener;
  }

  public void setBgMOnChangeListener(Callback paramCallback)
  {
    this.bgMOnChangeListener = paramCallback;
  }

  public void setBgMusicOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener paramOnSeekBarChangeListener)
  {
    this.bgMusicOnSeekBarChangeListener = paramOnSeekBarChangeListener;
  }

  public void setBgOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener paramOnCheckedChangeListener)
  {
    this.bgOnCheckedChangeListener = paramOnCheckedChangeListener;
  }

  public void setCloseOnClickListener(View.OnClickListener paramOnClickListener)
  {
    this.closeOnClickListener = paramOnClickListener;
  }

  public void setOnDismissListener(DialogInterface.OnDismissListener paramOnDismissListener)
  {
    this.onDismissListener = paramOnDismissListener;
  }

  public void setRestoreOnClickListener(View.OnClickListener paramOnClickListener)
  {
    this.restoreOnClickListener = paramOnClickListener;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.widget.PhysicalVolumeView
 * JD-Core Version:    0.6.0
 */