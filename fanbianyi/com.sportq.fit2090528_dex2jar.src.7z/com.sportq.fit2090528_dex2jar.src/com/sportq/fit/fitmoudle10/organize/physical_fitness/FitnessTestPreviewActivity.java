package com.sportq.fit.fitmoudle10.organize.physical_fitness;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.liulishuo.filedownloader.FileDownloader;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.activity.physicaltest.PhysicalVideoActivity;
import com.sportq.fit.fitmoudle10.organize.adapter.FitnessTestPreviewAdapter;
import com.sportq.fit.fitmoudle10.organize.presenter.FitMoudle10ApiPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.model.LstUrlModel;
import com.sportq.fit.fitmoudle10.organize.presenter.model.PhyActBaseModel;
import com.sportq.fit.fitmoudle10.organize.presenter.model.PhyActModel;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.PhyActReformer;
import com.sportq.fit.fitmoudle10.organize.utils.FileDownloadManager;
import com.sportq.fit.fitmoudle10.organize.utils.FileDownloadManager.OnDownloadListener;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.Iterator;
import org.byteam.superadapter.IMulItemViewType;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class FitnessTestPreviewActivity extends BaseActivity
  implements FileDownloadManager.OnDownloadListener
{
  private FitnessTestPreviewAdapter adapter;
  ArrayList<String> countList = new ArrayList();
  private ArrayList<LstUrlModel> downlaodUrlList;
  private ProgressBar download_pro;
  private RelativeLayout loading_layout;
  private final Context mContext = this;
  private Dialog mDialog;
  private IMulItemViewType<String> multiItemViewType = new FitnessTestPreviewActivity.2(this);
  private PhyActReformer phyActReformer;
  private RecyclerView recycler_view;
  private ImageView start_fitness_btn;
  private TextView start_warm_up_btn;
  private String strOperate;
  private FitnessTestPreviewActivity.TrainInfoNetWorkChangeReceiver trainInfoNetWorkChangeReceiver;

  private void jumpTrainAction()
  {
    this.download_pro.setProgress(0);
    this.download_pro.setVisibility(4);
    this.start_fitness_btn.setAlpha(1.0F);
    this.strOperate = "";
    Intent localIntent = new Intent(this, PhysicalVideoActivity.class);
    localIntent.putExtra("phy.data", this.phyActReformer);
    startActivity(localIntent);
    AnimationUtil.pageJumpAnim(this, 0);
  }

  private void startWarmUpAction()
  {
    if (this.adapter == null)
      return;
    CompDeviceInfoUtils.applyPermission(new FitnessTestPreviewActivity.1(this), this, new String[] { "android.permission.WRITE_EXTERNAL_STORAGE" });
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.start_warm_up_btn)
      if ("开始热身".equals(this.start_warm_up_btn.getText().toString()))
        startWarmUpAction();
    while (true)
    {
      super.fitOnClick(paramView);
      do
      {
        return;
        if (!CompDeviceInfoUtils.checkNetwork())
        {
          ToastUtils.makeToast(this, StringUtils.getStringResources(R.string.network_useless_check_settings));
          return;
        }
        FileDownloadManager.getInstance().pauseDownload();
        break;
        if (paramView.getId() == R.id.loading_layout)
        {
          this.loading_layout.setVisibility(4);
          this.start_warm_up_btn.setVisibility(0);
          this.start_warm_up_btn.setText(R.string.pause_download);
          FileDownloadManager.getInstance().pauseDownload();
          break;
        }
        if (paramView.getId() == R.id.exist_btn)
        {
          finish();
          AnimationUtil.pageJumpAnim(this, 1);
          break;
        }
        if (paramView.getId() == R.id.history_btn)
        {
          startActivity(new Intent(this, FitnessHistoryActivity.class));
          AnimationUtil.pageJumpAnim(this, 0);
          break;
        }
        if (paramView.getId() != R.id.start_fitness_btn)
          break;
      }
      while ("is_exe_download".equals(this.strOperate));
      if ("no_network".equals(this.strOperate))
      {
        if (CompDeviceInfoUtils.checkNetwork())
        {
          this.strOperate = "is_exe_download";
          this.start_fitness_btn.setAlpha(0.4F);
          this.download_pro.setVisibility(0);
          this.download_pro.setProgress(1);
          new FitMoudle10ApiPresenter(this).getPhyAct(this);
          continue;
        }
        startWarmUpAction();
        continue;
      }
      this.strOperate = "is_exe_download";
      this.start_fitness_btn.setAlpha(0.4F);
      this.download_pro.setVisibility(0);
      this.download_pro.setProgress(1);
      if (("load_data".equals(this.strOperate)) || ("request_error".equals(this.strOperate)))
      {
        if (!"request_error".equals(this.strOperate))
          continue;
        new FitMoudle10ApiPresenter(this).getPhyAct(this);
        continue;
      }
      if ("load_finish".equals(this.strOperate))
      {
        startWarmUpAction();
        continue;
      }
      startWarmUpAction();
    }
  }

  public <T> void getDataFail(T paramT)
  {
    this.strOperate = "request_error";
    this.download_pro.setProgress(0);
    this.download_pro.setVisibility(4);
    this.start_fitness_btn.setAlpha(1.0F);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (paramT == null)
      return;
    this.phyActReformer = ((PhyActReformer)paramT);
    if ((this.phyActReformer.lstStag != null) && (this.phyActReformer.lstStag.size() != 0))
    {
      int i = 0;
      ArrayList localArrayList = new ArrayList();
      SparseArray localSparseArray = new SparseArray();
      this.countList = new ArrayList();
      this.countList.add("");
      this.downlaodUrlList = new ArrayList();
      Iterator localIterator1 = this.phyActReformer.lstStag.iterator();
      while (true)
      {
        PhyActBaseModel localPhyActBaseModel;
        if (localIterator1.hasNext())
        {
          localPhyActBaseModel = (PhyActBaseModel)localIterator1.next();
          if (this.phyActReformer.lstStag.indexOf(localPhyActBaseModel) != 1);
        }
        else
        {
          this.adapter = new FitnessTestPreviewAdapter(this.mContext, this.countList, this.multiItemViewType, localArrayList, localSparseArray);
          this.recycler_view.setLayoutManager(new LinearLayoutManager(this.mContext));
          this.recycler_view.setAdapter(this.adapter);
          if (!"is_exe_download".equals(this.strOperate))
            break;
          startWarmUpAction();
          return;
        }
        localSparseArray.append(i, localPhyActBaseModel);
        i += localPhyActBaseModel.lstAction.size();
        localArrayList.addAll(localPhyActBaseModel.lstAction);
        Iterator localIterator2 = localPhyActBaseModel.lstAction.iterator();
        while (localIterator2.hasNext())
        {
          PhyActModel localPhyActModel = (PhyActModel)localIterator2.next();
          this.countList.add("");
          LstUrlModel localLstUrlModel = new LstUrlModel();
          localLstUrlModel.linkSize = localPhyActModel.videoSize;
          localLstUrlModel.linkUrl = localPhyActModel.actionVideoURL;
          this.downlaodUrlList.add(localLstUrlModel);
        }
      }
      this.strOperate = "load_finish";
      return;
    }
    ToastUtils.makeToast(this, "空数据结果");
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.fitness_test_preview);
    EventBus.getDefault().register(this);
    FileDownloader.setup(this);
    this.dialog = new DialogManager();
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setTitle(R.string.c_78_20_1);
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_white);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.white));
    localCustomToolBar.setBackgroundResource(R.color.color_313131);
    setSupportActionBar(localCustomToolBar);
    this.recycler_view = ((RecyclerView)findViewById(R.id.recycler_view));
    this.start_warm_up_btn = ((TextView)findViewById(R.id.start_warm_up_btn));
    this.start_warm_up_btn.setOnClickListener(new FitAction(this));
    this.download_pro = ((ProgressBar)findViewById(R.id.download_pro));
    this.loading_layout = ((RelativeLayout)findViewById(R.id.loading_layout));
    this.loading_layout.setOnClickListener(new FitAction(this));
    findViewById(R.id.exist_btn).setOnClickListener(new FitAction(this));
    findViewById(R.id.history_btn).setOnClickListener(new FitAction(this));
    this.start_fitness_btn = ((ImageView)findViewById(R.id.start_fitness_btn));
    this.start_fitness_btn.setOnClickListener(new FitAction(this));
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
    this.trainInfoNetWorkChangeReceiver = new FitnessTestPreviewActivity.TrainInfoNetWorkChangeReceiver(this, null);
    registerReceiver(this.trainInfoNetWorkChangeReceiver, localIntentFilter);
    this.strOperate = "load_data";
    new FitMoudle10ApiPresenter(this).getPhyAct(this);
    if (!CompDeviceInfoUtils.checkNetwork())
      this.strOperate = "no_network";
  }

  protected void onDestroy()
  {
    super.onDestroy();
    FileDownloadManager.getInstance().stopDownload();
    EventBus.getDefault().unregister(this);
    try
    {
      if (this.trainInfoNetWorkChangeReceiver != null)
        unregisterReceiver(this.trainInfoNetWorkChangeReceiver);
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      LogUtils.e(localIllegalArgumentException);
    }
  }

  public void onError()
  {
    this.strOperate = "";
    this.download_pro.setProgress(0);
    this.download_pro.setVisibility(4);
    this.start_fitness_btn.setAlpha(1.0F);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("phy.close.other.page".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  public void onLoading(float paramFloat)
  {
    if (paramFloat < 0.0F)
      if (this.dialog != null)
        this.dialog.closeDialog();
    do
    {
      return;
      if (this.download_pro.getVisibility() == 0)
        continue;
      this.download_pro.setVisibility(0);
      this.start_fitness_btn.setAlpha(0.4F);
      this.strOperate = "is_exe_download";
    }
    while (this.download_pro.getProgress() > paramFloat);
    this.download_pro.setProgress((int)paramFloat);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }

  protected void onPause()
  {
    onError();
    FileDownloadManager.getInstance().pauseDownload();
    super.onPause();
  }

  public void onSuccess()
  {
    this.loading_layout.setVisibility(4);
    this.start_warm_up_btn.setVisibility(0);
    this.start_warm_up_btn.setText(R.string.c_78_20_7);
    jumpTrainAction();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.physical_fitness.FitnessTestPreviewActivity
 * JD-Core Version:    0.6.0
 */