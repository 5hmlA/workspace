package com.sportq.fit.fitmoudle10.organize.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.widget.LinearLayout;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.GetuiDataModel;
import com.sportq.fit.common.model.MessageModel;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.MineReformer;
import com.sportq.fit.common.reformer.PlanReformer;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.GotoShopTabEvent;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.custom.refresh.OnLoadMoreListener;
import com.sportq.fit.fitmoudle.widget.custom.refresh.OnRefreshListener;
import com.sportq.fit.fitmoudle.widget.custom.refresh.SwipeToLoadLayout;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.Mine02NoticeAdapter;
import com.sportq.fit.fitmoudle10.organize.eventbus.ClearNoticeEventBus;
import com.sportq.fit.fitmoudle10.organize.presenter.MinePresenterImpl;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.MessageListReformer;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.minepresenter.reformer.GetMessageNumberReformer;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Mine02NoticeActivity extends BaseActivity
  implements OnRefreshListener, OnLoadMoreListener
{
  private Mine02NoticeAdapter adapter;
  int commentNumber = 0;
  LinearLayout emp_ll;
  private GetuiDataModel getuiDataModel;
  int likeNum = 0;
  private ArrayList<MessageModel> messageList;
  MinePresenterImpl minePresenter;
  RecyclerView recycler_view;
  private MessageListReformer reformer;
  PlanReformer reformers;
  int remindNumber = 0;
  private String strClick;
  private SwipeToLoadLayout swipeToLoadLayout;
  CustomToolBar toolbar;

  private void getInfo()
  {
    if (getIntent() != null)
    {
      this.strClick = getIntent().getStringExtra("click.flg");
      this.getuiDataModel = ((GetuiDataModel)getIntent().getSerializableExtra("message.model"));
      if (("click".equals(this.strClick)) && (this.getuiDataModel != null))
        MiddleManager.getInstance().getFindPresenterImpl(this, null).geTuiNoticeClick(this.getuiDataModel);
    }
    this.minePresenter = new MinePresenterImpl(this);
  }

  private void init()
  {
    EventBus.getDefault().register(this);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.swipeToLoadLayout = ((SwipeToLoadLayout)findViewById(R.id.swipeToLoadLayout));
    this.recycler_view = ((RecyclerView)findViewById(R.id.swipe_target));
    this.emp_ll = ((LinearLayout)findViewById(R.id.emp_ll));
    this.emp_ll.setVisibility(8);
    this.dialog = new DialogManager();
    this.toolbar.setTitle(R.string.c_3_1);
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundResource(R.color.white);
    setSupportActionBar(this.toolbar);
    this.recycler_view.setLayoutManager(new LinearLayoutManager(this));
    this.messageList = new ArrayList();
    this.messageList.add(null);
    this.adapter = new Mine02NoticeAdapter(this, this.messageList, this);
    this.adapter.setNumbers(this.commentNumber, this.likeNum, this.remindNumber);
    this.recycler_view.setAdapter(this.adapter);
    this.recycler_view.addOnScrollListener(new Mine02NoticeActivity.1(this));
    this.swipeToLoadLayout.setOnRefreshListener(this);
    this.swipeToLoadLayout.setOnLoadMoreListener(this);
    MiddleManager.getInstance().getMinePresenterImpl(this).getMessageNumber(new RequestModel(), this);
    this.minePresenter.getMessageList(this, Constant.STR_2, this.adapter.getList(), "1");
  }

  private void reSwipeToLoadLayoutState()
  {
    if (this.swipeToLoadLayout.isRefreshing())
      this.swipeToLoadLayout.setRefreshing(false);
    if (this.swipeToLoadLayout.isLoadingMore())
      this.swipeToLoadLayout.setLoadingMore(false);
  }

  public <T> void getDataFail(T paramT)
  {
    reSwipeToLoadLayoutState();
  }

  public <T> void getDataSuccess(T paramT)
  {
    reSwipeToLoadLayoutState();
    SwipeToLoadLayout localSwipeToLoadLayout;
    if ((paramT instanceof GetMessageNumberReformer))
    {
      MessageModel localMessageModel = ((GetMessageNumberReformer)paramT).messageModel;
      this.commentNumber = StringUtils.string2Int(localMessageModel.commentNumber);
      this.likeNum = StringUtils.string2Int(localMessageModel.likeNum);
      this.remindNumber = StringUtils.string2Int(localMessageModel.remindNumber);
      this.adapter.setNumbers(this.commentNumber, this.likeNum, this.remindNumber);
      this.adapter.notifyDataSetChanged();
      if ((this.swipeToLoadLayout != null) && (this.adapter != null))
      {
        localSwipeToLoadLayout = this.swipeToLoadLayout;
        if (this.adapter.getItemCount() == 1)
          break label372;
      }
    }
    label372: for (boolean bool = true; ; bool = false)
    {
      localSwipeToLoadLayout.setLoadMoreEnabled(bool);
      return;
      if ((paramT instanceof MineReformer))
      {
        MineReformer localMineReformer = (MineReformer)paramT;
        this.commentNumber = StringUtils.string2Int(localMineReformer.messageModel.commentNumber);
        this.likeNum = StringUtils.string2Int(localMineReformer.messageModel.likeNum);
        this.remindNumber = StringUtils.string2Int(localMineReformer.messageModel.remindNumber);
        this.adapter.setNumbers(this.commentNumber, this.likeNum, this.remindNumber);
        this.adapter.notifyDataSetChanged();
        break;
      }
      if ((paramT instanceof PlanReformer))
      {
        this.reformers = ((PlanReformer)paramT);
        if ((this.reformers._individualInfo != null) && (this.reformers._individualInfo.stageArray.size() > 0))
        {
          FitJumpImpl.getInstance().pushJumpTrainInfoActivity(this, this.reformers._planInfo.planId, "", "clic", null);
          break;
        }
        FitJumpImpl.getInstance().pushJumpTrainListActivity(this, this.reformers._planInfo.planId, "", null);
        break;
      }
      this.reformer = ((MessageListReformer)paramT);
      if ((this.reformer.list == null) || (this.reformer.list.size() == 0) || (this.adapter == null))
        break;
      this.adapter.addList(this.reformer.list, this.reformer.type);
      this.adapter.notifyDataSetChanged();
      break;
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine02_notice);
    getInfo();
    init();
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(GotoShopTabEvent paramGotoShopTabEvent)
  {
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  @Subscribe
  public void onEventMainThread(ClearNoticeEventBus paramClearNoticeEventBus)
  {
    this.dialog.createChoiceDialog(new Mine02NoticeActivity.2(this), this, "", UseStringUtils.getStr(this, R.string.c_4_1));
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  public void onLoadMore()
  {
    if ((this.adapter == null) || (this.reformer == null))
      if (this.swipeToLoadLayout.isLoadingMore())
        this.swipeToLoadLayout.setLoadingMore(false);
    do
    {
      return;
      if (!this.reformer.isArrowedFrash)
        continue;
      this.minePresenter.getMessageList(this, Constant.STR_2, this.adapter.getList(), "0");
      return;
    }
    while (!this.swipeToLoadLayout.isLoadingMore());
    this.swipeToLoadLayout.setLoadingMore(false);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }

  protected void onPause()
  {
    super.onPause();
    reSwipeToLoadLayoutState();
  }

  public void onRefresh()
  {
    MiddleManager.getInstance().getMinePresenterImpl(this).getMessageNumber(new RequestModel(), this);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.Mine02NoticeActivity
 * JD-Core Version:    0.6.0
 */