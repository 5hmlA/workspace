package com.sportq.fit.fitmoudle10.organize.activity.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.rong.map.linechartview.Axis;
import com.rong.map.linechartview.AxisValue;
import com.rong.map.linechartview.Chart;
import com.rong.map.linechartview.ChartData;
import com.rong.map.linechartview.LineChartData;
import com.rong.map.linechartview.LineChartView;
import com.rong.map.linechartview.Viewport;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.organize.dialog.WeightDialog;
import com.sportq.fit.fitmoudle10.organize.eventbus.AddWeightEvent;
import com.sportq.fit.fitmoudle10.organize.eventbus.UpdateWeightEvent;
import com.sportq.fit.fitmoudle10.organize.manager.ChartViewManager;
import com.sportq.fit.fitmoudle10.organize.presenter.SurroundPresent;
import com.sportq.fit.fitmoudle10.organize.presenter.model.WeightModel2;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.SurroundReformer;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.SurroundReformer.SurroundModel;
import com.sportq.fit.fitmoudle10.organize.utils.MinesecSharePreUtils;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

@Instrumented
public class SurroundFragment extends Fragment
  implements FitInterfaceUtils.UIInitListener
{
  private RelativeLayout addSurroundBtnLayout;
  private Map<String, LineChartView> chartViewMap = new HashMap();
  private ViewStub contentView;
  private ViewStub emptyView;
  private boolean isInited = false;
  private LinearLayout listLayout;
  private Map<String, View> notDataViewMap = new HashMap();
  private SurroundPresent presenter;
  private SurroundReformer reformer;
  private WeightDialog weightDialog;

  private boolean haveData()
  {
    String str = MinesecSharePreUtils.getShowDimension(getContext());
    return (!StringUtils.isNull(str)) && (!"[]".equals(str));
  }

  private void initAxisX(List<AxisValue> paramList, ChartData paramChartData)
  {
    paramChartData.setAxisXBottom(new Axis(paramList));
  }

  private void initAxisY(LineChartData paramLineChartData, String paramString)
  {
    paramLineChartData.setAxisYLeft(this.presenter.getSurroundAxisY(paramString));
  }

  private void initChartView(LineChartView paramLineChartView)
  {
    ChartViewManager.initChartView(paramLineChartView);
  }

  public static SurroundFragment newInstance()
  {
    return new SurroundFragment();
  }

  private void setCurrentViewport(Chart paramChart)
  {
    Viewport localViewport = new Viewport(paramChart.getMaximumViewport());
    if (localViewport.right >= 7.0F)
      localViewport.left = (localViewport.right - 6.5F);
    paramChart.setCurrentViewport(localViewport);
  }

  private void setData()
  {
    this.listLayout.removeAllViews();
    LayoutInflater localLayoutInflater = LayoutInflater.from(getContext());
    Iterator localIterator = this.reformer.getSurroundCtrlList().iterator();
    if (localIterator.hasNext())
    {
      String str = ChartViewManager.weightChartNameConvertCode((String)localIterator.next());
      View localView1 = localLayoutInflater.inflate(R.layout.item_surround, this.listLayout, false);
      View localView2 = localView1.findViewById(R.id.notDataView);
      if (((SurroundReformer.SurroundModel)this.reformer.surroundMap.get(str)).haveData)
        localView2.setVisibility(8);
      while (true)
      {
        ((TextView)localView1.findViewById(R.id.chartViewName)).setText(ChartViewManager.weightCordConvertChartName(str));
        LineChartView localLineChartView = (LineChartView)localView1.findViewById(R.id.chartView);
        LineChartData localLineChartData = ChartViewManager.getLineChartData(((SurroundReformer.SurroundModel)this.reformer.surroundMap.get(str)).values);
        initChartView(localLineChartView);
        initAxisX(((SurroundReformer.SurroundModel)this.reformer.surroundMap.get(str)).axisValuesX, localLineChartData);
        initAxisY(localLineChartData, str);
        setMaximunViewPort(localLineChartView, str);
        setCurrentViewport(localLineChartView);
        localLineChartView.setLineChartData(localLineChartData);
        this.chartViewMap.put(str, localLineChartView);
        this.notDataViewMap.put(str, localView2);
        this.listLayout.addView(localView1);
        break;
        localView2.setVisibility(0);
      }
    }
  }

  private void setMaximunViewPort(Chart paramChart, String paramString)
  {
    Viewport localViewport = new Viewport(paramChart.getMaximumViewport());
    if (((SurroundReformer.SurroundModel)this.reformer.surroundMap.get(paramString)).axisValuesX.size() <= 7)
    {
      localViewport.left = -0.5F;
      localViewport.right = 6.0F;
      if (this.presenter.haveDate(paramString))
        break label127;
      localViewport.bottom = 0.0F;
    }
    for (localViewport.top = 2.9F; ; localViewport.top = (((SurroundReformer.SurroundModel)this.reformer.surroundMap.get(paramString)).max + ((SurroundReformer.SurroundModel)this.reformer.surroundMap.get(paramString)).ySpace / 2.0F))
    {
      paramChart.setMaximumViewport(localViewport);
      return;
      localViewport.left = 0.0F;
      localViewport.right = (-1 + ((SurroundReformer.SurroundModel)this.reformer.surroundMap.get(paramString)).axisValuesX.size());
      break;
      label127: localViewport.bottom = (((SurroundReformer.SurroundModel)this.reformer.surroundMap.get(paramString)).min - ((SurroundReformer.SurroundModel)this.reformer.surroundMap.get(paramString)).ySpace / 5.0F);
    }
  }

  private void showContentPager()
  {
    if (this.contentView == null)
    {
      this.contentView = ((ViewStub)getView().findViewById(R.id.contentView));
      this.contentView.inflate();
      this.listLayout = ((LinearLayout)getView().findViewById(R.id.listLayout));
      this.addSurroundBtnLayout = ((RelativeLayout)getView().findViewById(R.id.addSurroundBtnLayout));
      this.addSurroundBtnLayout.setOnClickListener(new FitAction(this));
    }
    this.contentView.setVisibility(0);
    if (this.emptyView != null)
      this.emptyView.setVisibility(8);
    setData();
  }

  private void showEmptyPager()
  {
    if (this.emptyView == null)
    {
      this.emptyView = ((ViewStub)getView().findViewById(R.id.emptyView));
      this.emptyView.inflate();
    }
    this.emptyView.setVisibility(0);
    if (this.contentView != null)
      this.contentView.setVisibility(8);
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.addSurroundBtnLayout)
    {
      if (this.weightDialog == null)
        this.weightDialog = new WeightDialog(getContext());
      this.weightDialog.wdithDialog(new SurroundFragment.1(this));
    }
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
    if ((paramT != null) && ((paramT instanceof SurroundReformer)))
    {
      this.reformer = ((SurroundReformer)paramT);
      this.presenter.setReformer(this.reformer);
      if ((this.isInited) && (haveData()))
        showContentPager();
    }
  }

  public void initLayout(Bundle paramBundle)
  {
  }

  public void onActivityCreated(@Nullable Bundle paramBundle)
  {
    super.onActivityCreated(paramBundle);
    this.presenter = new SurroundPresent(this);
    if (this.reformer == null);
    for (SurroundReformer localSurroundReformer = new SurroundReformer(); ; localSurroundReformer = this.reformer)
    {
      this.reformer = localSurroundReformer;
      if (!haveData())
        showEmptyPager();
      return;
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
  }

  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    View localView = paramLayoutInflater.inflate(R.layout.fragment_surround, paramViewGroup, false);
    this.isInited = true;
    EventBus.getDefault().register(this);
    return localView;
  }

  public void onDestroyView()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroyView();
  }

  @Subscribe
  public void onEventMainThread(AddWeightEvent paramAddWeightEvent)
  {
    if ((this.isInited) && (!"0".equals(paramAddWeightEvent.weightModel2.girthType)))
      refreshChartView(paramAddWeightEvent.weightModel2.girthType);
  }

  @Subscribe
  public void onEventMainThread(UpdateWeightEvent paramUpdateWeightEvent)
  {
    if ((this.isInited) && (!"0".equals(paramUpdateWeightEvent.weightModel2.girthType)))
      refreshChartView(paramUpdateWeightEvent.weightModel2.girthType);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("event.save".equals(paramString))
    {
      if (haveData())
        showContentPager();
    }
    else
      return;
    showEmptyPager();
  }

  public void onHiddenChanged(boolean paramBoolean)
  {
    super.onHiddenChanged(paramBoolean);
    VdsAgent.onFragmentHiddenChanged(this, paramBoolean);
  }

  public void onPause()
  {
    super.onPause();
    VdsAgent.onFragmentPause(this);
  }

  public <T> void onRefresh(T paramT)
  {
  }

  public void onResume()
  {
    super.onResume();
    VdsAgent.onFragmentResume(this);
  }

  public void refreshChartView(String paramString)
  {
    if ((this.chartViewMap != null) && (this.chartViewMap.get(paramString) != null))
    {
      initAxisY(((LineChartView)this.chartViewMap.get(paramString)).getLineChartData(), paramString);
      setMaximunViewPort((Chart)this.chartViewMap.get(paramString), paramString);
      setCurrentViewport((Chart)this.chartViewMap.get(paramString));
      ((LineChartView)this.chartViewMap.get(paramString)).startDataAnimation();
      ((View)this.notDataViewMap.get(paramString)).setVisibility(8);
    }
  }

  public void setReformer(SurroundReformer paramSurroundReformer)
  {
    this.reformer = paramSurroundReformer;
  }

  public void setUserVisibleHint(boolean paramBoolean)
  {
    super.setUserVisibleHint(paramBoolean);
    VdsAgent.setFragmentUserVisibleHint(this, paramBoolean);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.fragment.SurroundFragment
 * JD-Core Version:    0.6.0
 */