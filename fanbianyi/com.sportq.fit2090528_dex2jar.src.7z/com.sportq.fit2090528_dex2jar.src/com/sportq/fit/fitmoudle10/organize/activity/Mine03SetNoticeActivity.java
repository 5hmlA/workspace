package com.sportq.fit.fitmoudle10.organize.activity;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.presenter.mine.MinePresenterInterface;
import com.sportq.fit.common.model.NoticeModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.NoticeReformer;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.superView.RTextView;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.SelectTimeDialog;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.Mine03NoticeAdapter;
import com.sportq.fit.fitmoudle10.organize.eventbus.MineAccountEventBus;
import com.sportq.fit.fitmoudle10.organize.presenter.MinePresenterImpl;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Mine03SetNoticeActivity extends BaseActivity
{
  private Mine03NoticeAdapter adapter;
  private RTextView add_item_tv;
  private boolean dialogFlg = false;
  LinearLayout mAll_ll;
  Switch mMine_notice_comment;
  Switch mMine_notice_like;
  Switch mMine_notice_remind;
  ListView mine03List;
  private TextView mine03_notice_text;
  Switch mine_notice_system;
  Switch msg_switch;
  List<NoticeModel> noticeList;
  CustomToolBar toolbar;

  private void addItemDialog(String paramString)
  {
    this.dialogFlg = true;
    new SelectTimeDialog(this).createDialog(new Mine03SetNoticeActivity.1(this), paramString);
  }

  private View addNoticeItem()
  {
    View localView = LayoutInflater.from(this).inflate(R.layout.mine03_set_notice_head, null);
    this.mine03_notice_text = ((TextView)localView.findViewById(R.id.mine03_setnotic_text));
    this.mine_notice_system = ((Switch)localView.findViewById(R.id.mine_notice_system));
    this.add_item_tv = ((RTextView)localView.findViewById(R.id.add_item_tv));
    this.add_item_tv.setOnClickListener(new FitAction(this));
    this.msg_switch = ((Switch)localView.findViewById(R.id.msg_switch));
    this.mAll_ll = ((LinearLayout)localView.findViewById(R.id.all_ll));
    this.mMine_notice_like = ((Switch)localView.findViewById(R.id.mine_notice_like));
    this.mMine_notice_comment = ((Switch)localView.findViewById(R.id.mine_notice_comment));
    this.mMine_notice_remind = ((Switch)localView.findViewById(R.id.mine_notice_remind));
    checkWakeText(this.mine03_notice_text);
    setSelectChange(this.msg_switch, 5);
    setSelectChange(this.mMine_notice_like, 0);
    setSelectChange(this.mMine_notice_comment, 1);
    setSelectChange(this.mMine_notice_remind, 2);
    setSelectChange(this.mine_notice_system, 3);
    return localView;
  }

  private void checkWakeText(View paramView)
  {
    if (this.adapter.getList().size() > 0);
    for (int i = 8; ; i = 0)
    {
      paramView.setVisibility(i);
      return;
    }
  }

  private void setSelectChange(Switch paramSwitch, int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
      while (true)
      {
        paramSwitch.setOnCheckedChangeListener(new Mine03SetNoticeActivity.2(this, paramInt));
        return;
        paramSwitch.setChecked("1".equals(BaseApplication.userModel.likeRemindFlag));
        continue;
        paramSwitch.setChecked("1".equals(BaseApplication.userModel.commentRemindFlag));
        continue;
        paramSwitch.setChecked("1".equals(BaseApplication.userModel.reminderFlag));
        continue;
        paramSwitch.setChecked("1".equals(BaseApplication.userModel.systemRemindFlag));
        continue;
        paramSwitch.setChecked("1".equals(BaseApplication.userModel.coachNotification));
      }
    case 5:
    }
    paramSwitch.setChecked("1".equals(BaseApplication.userModel.messageRemindFlag));
    LinearLayout localLinearLayout = this.mAll_ll;
    if ("1".equals(BaseApplication.userModel.messageRemindFlag));
    for (int i = 0; ; i = 8)
    {
      localLinearLayout.setVisibility(i);
      Mine03NoticeAdapter localMine03NoticeAdapter = this.adapter;
      boolean bool1 = "1".equals(BaseApplication.userModel.messageRemindFlag);
      boolean bool2 = false;
      if (!bool1)
        bool2 = true;
      localMine03NoticeAdapter.setFlg(Boolean.valueOf(bool2));
      this.adapter.notifyDataSetChanged();
      break;
    }
  }

  private void updateUIforGetInfo(ArrayList<NoticeModel> paramArrayList)
  {
    runOnUiThread(new Mine03SetNoticeActivity.3(this, paramArrayList));
  }

  public void finish_do()
  {
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.coachNotification = BaseApplication.userModel.coachNotification;
    localRequestModel.remindf = BaseApplication.userModel.remindf;
    localRequestModel.remindTime = BaseApplication.userModel.remindTime;
    localRequestModel.messageRemindFlag = BaseApplication.userModel.messageRemindFlag;
    localRequestModel.systemRemindFlag = BaseApplication.userModel.systemRemindFlag;
    localRequestModel.reminderFlag = BaseApplication.userModel.reminderFlag;
    localRequestModel.commentRemindFlag = BaseApplication.userModel.commentRemindFlag;
    localRequestModel.likeRemindFlag = BaseApplication.userModel.likeRemindFlag;
    new MinePresenterImpl(this).updateMineInfo(this, localRequestModel);
    MiddleManager.getInstance().getMinePresenterImpl(this).saveNoticeItemsInfo(this, localRequestModel, this.adapter.getList(), "");
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  public void fitOnClick(View paramView)
  {
    if (R.id.add_item_tv == paramView.getId())
    {
      if (this.adapter.getList().size() >= 5)
        ToastUtils.makeToast(getString(R.string.c_56_15));
    }
    else
      return;
    addItemDialog(DateUtils.StringToFormat(DateUtils.randomDate("19:00", "20:00").getTime() + "", "HH:mm"));
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    if ((paramT instanceof NoticeReformer))
      updateUIforGetInfo((ArrayList)((NoticeReformer)paramT).noticeList);
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if ((paramT instanceof NoticeReformer))
      updateUIforGetInfo((ArrayList)((NoticeReformer)paramT).noticeList);
    do
      return;
    while (!(paramT instanceof List));
    updateUIforGetInfo((ArrayList)paramT);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.mine03_set_notice);
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.mine03List = ((ListView)findViewById(R.id.mine03_list));
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setTitle(R.string.c_34_6);
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
    setSupportActionBar(this.toolbar);
    this.noticeList = new ArrayList();
    this.adapter = new Mine03NoticeAdapter(this, this.noticeList);
    this.mine03List.addHeaderView(addNoticeItem());
    this.mine03List.setAdapter(this.adapter);
    MiddleManager.getInstance().getMinePresenterImpl(this).getNoticeItemsInfo();
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(MineAccountEventBus paramMineAccountEventBus)
  {
    if ("notice.update".equals(paramMineAccountEventBus.getMsg()))
    {
      checkWakeText(this.mine03_notice_text);
      this.adapter.setList(this.adapter.getList());
      this.adapter.notifyDataSetChanged();
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      finish_do();
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish_do();
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.Mine03SetNoticeActivity
 * JD-Core Version:    0.6.0
 */