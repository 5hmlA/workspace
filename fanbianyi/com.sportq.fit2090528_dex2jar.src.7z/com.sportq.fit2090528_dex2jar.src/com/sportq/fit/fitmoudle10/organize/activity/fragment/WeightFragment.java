package com.sportq.fit.fitmoudle10.organize.activity.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.rong.map.linechartview.Axis;
import com.rong.map.linechartview.AxisValue;
import com.rong.map.linechartview.LineChartData;
import com.rong.map.linechartview.LineChartView;
import com.rong.map.linechartview.PointValue;
import com.rong.map.linechartview.SelectedValue;
import com.rong.map.linechartview.SelectedValue.SelectedValueType;
import com.rong.map.linechartview.Viewport;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02HealthData2Activity;
import com.sportq.fit.fitmoudle10.organize.activity.Mine02WeightActivity;
import com.sportq.fit.fitmoudle10.organize.activity.PerfectInfoFirstActivity;
import com.sportq.fit.fitmoudle10.organize.activity.bodyfat.BodyFatSteelyardBuyActivity;
import com.sportq.fit.fitmoudle10.organize.dialog.WeightDialog;
import com.sportq.fit.fitmoudle10.organize.eventbus.AddBodyFastEvent;
import com.sportq.fit.fitmoudle10.organize.eventbus.AddWeightEvent;
import com.sportq.fit.fitmoudle10.organize.eventbus.UpdateBodyFastEvent;
import com.sportq.fit.fitmoudle10.organize.eventbus.UpdateTargetWeightEvent;
import com.sportq.fit.fitmoudle10.organize.eventbus.UpdateWeightEvent;
import com.sportq.fit.fitmoudle10.organize.manager.ChartViewManager;
import com.sportq.fit.fitmoudle10.organize.presenter.BodyFastPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.WeightPresenter1;
import com.sportq.fit.fitmoudle10.organize.presenter.model.WeightModel2;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.BodyFastReformer;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.WeightReformer2;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.WeightReformer3;
import com.sportq.fit.fitmoudle10.organize.utils.BodyFastBindStoreUtils;
import com.sportq.fit.fitmoudle10.organize.utils.MinesecSharePreUtils;
import com.sportq.fit.fitmoudle10.organize.widget.WeightTabLayout;
import com.sportq.fit.fitmoudle10.organize.widget.calendar.CalendarNewView;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

@Instrumented
public class WeightFragment extends Fragment
  implements FitInterfaceUtils.UIInitListener
{
  private static DialogInterface dialog;
  private TextView bindBodyFatHint;
  private RelativeLayout bodyFastBtn;
  private LineChartData bodyFastData;
  private RelativeLayout bodyFastLayout;
  private BodyFastPresenter bodyFastPresenter;
  private BodyFastReformer bodyFastReformer;
  private LineChartView bodyFastView;
  private LineChartData data;
  private View mCalendarLine;
  private CalendarNewView mCalendarView;
  private LineChartView mChartView;
  WeightTabLayout mChartViewTab;
  TextView mHowToMeasure;
  private TextView mNotDataView;
  private TextView mTargetWeight;
  LinearLayout mTargetWeightLayout;
  private TextView no_bodyFast_view;
  private WeightPresenter1 presenter;
  private ImageView unbunding_bodyfat_view;
  private Mine02WeightActivity weightActivity;
  private WeightDialog weightDialog;

  private void initAxisX(List<AxisValue> paramList, int paramInt)
  {
    Axis localAxis = new Axis(paramList);
    if (paramInt == 0)
    {
      this.data.setAxisXBottom(localAxis);
      return;
    }
    this.bodyFastData.setAxisXBottom(localAxis);
  }

  private void initAxisY(int paramInt)
  {
    if (paramInt == 0)
    {
      this.data.setAxisYLeft(this.presenter.getWeightAxisY());
      return;
    }
    this.bodyFastData.setAxisYLeft(this.bodyFastPresenter.getWeightAxisY());
  }

  private void initChartView()
  {
    ChartViewManager.initChartView(this.mChartView);
    ChartViewManager.initChartView(this.bodyFastView);
  }

  private void initLineChartData(List<PointValue> paramList, int paramInt)
  {
    if (paramInt == 0)
    {
      this.data = ChartViewManager.getLineChartData(paramList);
      return;
    }
    this.bodyFastData = ChartViewManager.getLineChartData(paramList);
  }

  private void initView(View paramView)
  {
    this.mCalendarLine = paramView.findViewById(R.id.calendarLine);
    this.mCalendarView = ((CalendarNewView)paramView.findViewById(R.id.calendarView));
    showCalendar();
    this.mChartView = ((LineChartView)paramView.findViewById(R.id.chartView));
    this.mNotDataView = ((TextView)paramView.findViewById(R.id.notDataView));
    this.mTargetWeightLayout = ((LinearLayout)paramView.findViewById(R.id.targetWeightLayout));
    this.mTargetWeight = ((TextView)paramView.findViewById(R.id.targetWeight));
    this.mTargetWeightLayout.setOnClickListener(new FitAction(this));
    this.mHowToMeasure = ((TextView)paramView.findViewById(R.id.howToMeasure));
    this.mHowToMeasure.setOnClickListener(new FitAction(this));
    ((RelativeLayout)paramView.findViewById(R.id.addWeightBtnLayout)).setOnClickListener(new FitAction(this));
    this.bodyFastBtn = ((RelativeLayout)paramView.findViewById(R.id.bodyFastBtn));
    this.bodyFastBtn.setOnClickListener(new FitAction(this));
    this.bindBodyFatHint = ((TextView)paramView.findViewById(R.id.bindBodyFatHint));
    this.bindBodyFatHint.setOnClickListener(new FitAction(this));
    this.mChartViewTab = ((WeightTabLayout)paramView.findViewById(R.id.chartViewTab));
    this.mChartViewTab.setSelectedListener(new WeightFragment.1(this));
    this.bodyFastView = ((LineChartView)paramView.findViewById(R.id.bodyFastView));
    this.no_bodyFast_view = ((TextView)paramView.findViewById(R.id.no_bodyFast_view));
    this.unbunding_bodyfat_view = ((ImageView)paramView.findViewById(R.id.unbunding_bodyfat_view));
    this.unbunding_bodyfat_view.setOnClickListener(new FitAction(this));
    this.bodyFastLayout = ((RelativeLayout)paramView.findViewById(R.id.bodyFastLayout));
  }

  public static WeightFragment newInstance()
  {
    WeightFragment localWeightFragment = new WeightFragment();
    localWeightFragment.presenter = new WeightPresenter1(localWeightFragment);
    localWeightFragment.bodyFastPresenter = new BodyFastPresenter(localWeightFragment);
    if (dialog == null)
      dialog = new DialogManager();
    return localWeightFragment;
  }

  private void refreshBodyFastChartView()
  {
    initAxisY(1);
    setBodyFastMaximunViewPort(this.bodyFastPresenter.getCurrentReformer());
    setBodyFastCurrentViewport();
    this.bodyFastView.startDataAnimation();
    this.bodyFastView.selectValue(new SelectedValue(0, -1 + this.bodyFastPresenter.getCurrentReformer().bodyFastModels.size(), SelectedValue.SelectedValueType.LINE));
  }

  private void refreshChartView()
  {
    initAxisY(0);
    setMaximunViewPort(this.presenter.getCurrentReformer());
    setCurrentViewport();
    this.mChartView.startDataAnimation();
    this.mChartView.selectValue(new SelectedValue(0, -1 + this.presenter.getCurrentReformer().weightModels.size(), SelectedValue.SelectedValueType.LINE));
  }

  private void setBodyFastCurrentViewport()
  {
    Viewport localViewport = new Viewport(this.bodyFastView.getMaximumViewport());
    if (localViewport.right >= 7.0F)
      localViewport.left = (localViewport.right - 6.5F);
    this.bodyFastView.setCurrentViewport(localViewport);
  }

  private void setBodyFastData(BodyFastReformer paramBodyFastReformer)
  {
    checkBodyFastCoverPlate();
    initLineChartData(paramBodyFastReformer.values, 1);
    initAxisX(paramBodyFastReformer.axisValuesX, 1);
    initAxisY(1);
    this.bodyFastView.setLineChartData(this.bodyFastData);
    setBodyFastMaximunViewPort(paramBodyFastReformer);
    setBodyFastCurrentViewport();
    this.bodyFastView.selectValue(new SelectedValue(0, -1 + paramBodyFastReformer.values.size(), SelectedValue.SelectedValueType.LINE));
    this.bodyFastView.startDataAnimation(2000L);
  }

  private void setBodyFastMaximunViewPort(BodyFastReformer paramBodyFastReformer)
  {
    Viewport localViewport = new Viewport(this.bodyFastView.getMaximumViewport());
    if (paramBodyFastReformer.axisValuesX.size() <= 7)
    {
      localViewport.left = -0.5F;
      localViewport.right = 6.0F;
      if (paramBodyFastReformer.haveDate)
        break label111;
      localViewport.bottom = 0.0F;
    }
    for (localViewport.top = 2.9F; ; localViewport.top = (paramBodyFastReformer.max + paramBodyFastReformer.ySpace / 2.0F))
    {
      this.bodyFastView.setMaximumViewport(localViewport);
      if (!paramBodyFastReformer.haveDate)
        break label154;
      this.no_bodyFast_view.setVisibility(8);
      return;
      localViewport.left = 0.0F;
      localViewport.right = (-1 + paramBodyFastReformer.axisValuesX.size());
      break;
      label111: localViewport.bottom = Math.max(0.0F, paramBodyFastReformer.min - paramBodyFastReformer.ySpace / 5.0F);
    }
    label154: this.no_bodyFast_view.setVisibility(0);
  }

  private void setCurrentViewport()
  {
    Viewport localViewport = new Viewport(this.mChartView.getMaximumViewport());
    if (localViewport.right >= 7.0F)
      localViewport.left = (localViewport.right - 6.5F);
    this.mChartView.setCurrentViewport(localViewport);
  }

  private void setData(WeightReformer3 paramWeightReformer3)
  {
    TextView localTextView = this.mTargetWeight;
    int i = R.string.c_57_1_4;
    String[] arrayOfString = new String[1];
    arrayOfString[0] = BaseApplication.userModel.targetWeight;
    localTextView.setText(UseStringUtils.getStr(i, arrayOfString));
    initLineChartData(paramWeightReformer3.values, 0);
    initAxisX(paramWeightReformer3.axisValuesX, 0);
    initAxisY(0);
    this.mChartView.setLineChartData(this.data);
    setMaximunViewPort(paramWeightReformer3);
    setCurrentViewport();
    this.mChartView.selectValue(new SelectedValue(0, -1 + paramWeightReformer3.values.size(), SelectedValue.SelectedValueType.LINE));
    this.mChartView.startDataAnimation(2000L);
  }

  private void setMaximunViewPort(WeightReformer3 paramWeightReformer3)
  {
    Viewport localViewport = new Viewport(this.mChartView.getMaximumViewport());
    if (paramWeightReformer3.axisValuesX.size() <= 7)
    {
      localViewport.left = -0.5F;
      localViewport.right = 6.0F;
      if (paramWeightReformer3.haveDate)
        break label111;
      localViewport.bottom = 0.0F;
    }
    for (localViewport.top = 2.9F; ; localViewport.top = (paramWeightReformer3.max + paramWeightReformer3.ySpace / 2.0F))
    {
      this.mChartView.setMaximumViewport(localViewport);
      if (!paramWeightReformer3.haveDate)
        break label154;
      this.mNotDataView.setVisibility(8);
      return;
      localViewport.left = 0.0F;
      localViewport.right = (-1 + paramWeightReformer3.axisValuesX.size());
      break;
      label111: localViewport.bottom = Math.max(0.0F, paramWeightReformer3.min - paramWeightReformer3.ySpace / 5.0F);
    }
    label154: this.mNotDataView.setVisibility(0);
  }

  private void showCalendar()
  {
    if ((this.mCalendarLine != null) && (this.mChartView != null))
    {
      if (MinesecSharePreUtils.getCalendarShowFlg())
      {
        this.mCalendarLine.setVisibility(0);
        this.mCalendarView.setVisibility(0);
      }
    }
    else
      return;
    this.mCalendarLine.setVisibility(8);
    this.mCalendarView.setVisibility(8);
  }

  public void checkBodyFastCoverPlate()
  {
    ArrayList localArrayList = BodyFastBindStoreUtils.getBodyFastDataList(this.weightActivity);
    if ((localArrayList != null) && (localArrayList.size() > 0))
    {
      this.unbunding_bodyfat_view.setVisibility(8);
      this.bodyFastLayout.setVisibility(0);
      this.bodyFastBtn.setVisibility(0);
      this.bindBodyFatHint.setVisibility(8);
      return;
    }
    if ((this.bodyFastReformer != null) && (this.bodyFastReformer.bodyFastModels != null) && (this.bodyFastReformer.bodyFastModels.size() > 0))
    {
      this.unbunding_bodyfat_view.setVisibility(8);
      this.bodyFastLayout.setVisibility(0);
      this.bodyFastBtn.setVisibility(8);
      this.bindBodyFatHint.setVisibility(0);
      return;
    }
    this.unbunding_bodyfat_view.setVisibility(0);
    this.bodyFastLayout.setVisibility(4);
    this.bodyFastBtn.setVisibility(8);
    this.bindBodyFatHint.setVisibility(8);
  }

  public void fitOnClick(View paramView)
  {
    int i = paramView.getId();
    if (i == R.id.addWeightBtnLayout)
    {
      if (this.weightDialog == null)
        this.weightDialog = new WeightDialog(getContext());
      this.weightDialog.showWeightDialog(new WeightFragment.2(this));
    }
    do
    {
      return;
      if (i == R.id.bodyFastBtn)
      {
        if ((StringUtils.isNull(BaseApplication.userModel.birthday)) || (StringUtils.isNull(BaseApplication.userModel.height)) || (StringUtils.isNull(BaseApplication.userModel.currentWeight)))
        {
          dialog.createChoiceDialog(new WeightFragment.3(this), this.weightActivity, "", this.weightActivity.getResources().getString(R.string.c_77_17_1), this.weightActivity.getResources().getString(R.string.c_77_17_3), this.weightActivity.getResources().getString(R.string.c_77_17_2));
          return;
        }
        CompDeviceInfoUtils.applyPermission(new WeightFragment.4(this), this.weightActivity, new String[] { "android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION" });
        return;
      }
      if (i == R.id.targetWeightLayout)
      {
        UserModel localUserModel = BaseApplication.userModel;
        Intent localIntent2 = new Intent(getContext(), Mine02HealthData2Activity.class);
        if (StringUtils.isNull(localUserModel.initialWeight))
          localIntent2.setClass(getContext(), PerfectInfoFirstActivity.class);
        getContext().startActivity(localIntent2);
        AnimationUtil.pageJumpAnim(getActivity(), 0);
        return;
      }
      if (i != R.id.howToMeasure)
        continue;
      FitJumpImpl.getInstance().settingJumpWebView(getContext(), null, VersionUpdateCheck.WEB_ADDRESS + "newLes/250.html");
      return;
    }
    while ((i != R.id.unbunding_bodyfat_view) && (i != R.id.bindBodyFatHint));
    Intent localIntent1 = new Intent(getContext(), BodyFatSteelyardBuyActivity.class);
    getContext().startActivity(localIntent1);
    AnimationUtil.pageJumpAnim(getActivity(), 0);
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (paramT == null);
    while (true)
    {
      return;
      if ((paramT instanceof WeightReformer3))
      {
        WeightReformer3 localWeightReformer32 = (WeightReformer3)paramT;
        this.presenter.putReformer(localWeightReformer32.tabType, localWeightReformer32);
        setData(this.presenter.getReformer(localWeightReformer32.tabType));
      }
      while (this.mCalendarView != null)
      {
        this.mCalendarView.setPageData();
        return;
        if ((paramT instanceof WeightReformer2))
        {
          WeightReformer2 localWeightReformer2 = (WeightReformer2)paramT;
          WeightReformer3 localWeightReformer31 = localWeightReformer2.weightReformer3;
          this.presenter.putReformer(localWeightReformer31.tabType, localWeightReformer31);
          setData(this.presenter.getReformer(localWeightReformer31.tabType));
          this.bodyFastReformer = localWeightReformer2.bodyFastReformer;
          this.bodyFastPresenter.putReformer(this.bodyFastReformer.tabType, this.bodyFastReformer);
          setBodyFastData(this.bodyFastPresenter.getReformer(this.bodyFastReformer.tabType));
          checkBodyFastCoverPlate();
          continue;
        }
        if (!(paramT instanceof BodyFastReformer))
          continue;
        this.bodyFastReformer = ((BodyFastReformer)paramT);
        this.bodyFastPresenter.putReformer(this.bodyFastReformer.tabType, this.bodyFastReformer);
        setBodyFastData(this.bodyFastPresenter.getReformer(this.bodyFastReformer.tabType));
      }
    }
  }

  public <T> void getDataSuccess(T paramT, Mine02WeightActivity paramMine02WeightActivity)
  {
    this.weightActivity = paramMine02WeightActivity;
    getDataSuccess(paramT);
  }

  public void initLayout(Bundle paramBundle)
  {
  }

  public void onActivityCreated(@Nullable Bundle paramBundle)
  {
    super.onActivityCreated(paramBundle);
    initChartView();
    if (this.presenter == null)
      this.presenter = new WeightPresenter1(this);
    if (this.presenter.getReformer(0) != null)
      getDataSuccess(this.presenter.getReformer(0));
    if (this.bodyFastPresenter == null)
      this.bodyFastPresenter = new BodyFastPresenter(this);
    if (this.bodyFastPresenter.getReformer(0) != null)
      getDataSuccess(this.bodyFastPresenter.getReformer(0));
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
  }

  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    View localView = paramLayoutInflater.inflate(R.layout.fragment_weight, paramViewGroup, false);
    EventBus.getDefault().register(this);
    initView(localView);
    return localView;
  }

  public void onDestroy()
  {
    EventBus.getDefault().unregister(this);
    super.onDestroy();
  }

  @Subscribe
  public void onEventMainThread(AddBodyFastEvent paramAddBodyFastEvent)
  {
    if ("7".equals(paramAddBodyFastEvent.weightModel2.girthType))
    {
      this.bodyFastPresenter.refreshDate();
      refreshBodyFastChartView();
      this.mCalendarView.refreshPageData(paramAddBodyFastEvent.weightModel2.recordDate);
    }
  }

  @Subscribe
  public void onEventMainThread(AddWeightEvent paramAddWeightEvent)
  {
    if ("0".equals(paramAddWeightEvent.weightModel2.girthType))
    {
      this.presenter.refreshDate();
      refreshChartView();
      this.mCalendarView.refreshPageData(paramAddWeightEvent.weightModel2.recordDate);
    }
  }

  @Subscribe
  public void onEventMainThread(UpdateBodyFastEvent paramUpdateBodyFastEvent)
  {
    if ("7".equals(paramUpdateBodyFastEvent.weightModel2.girthType))
    {
      this.bodyFastPresenter.refreshDate();
      refreshBodyFastChartView();
      this.mCalendarView.refreshPageData(paramUpdateBodyFastEvent.weightModel2.recordDate);
    }
  }

  @Subscribe
  public void onEventMainThread(UpdateTargetWeightEvent paramUpdateTargetWeightEvent)
  {
    if (this.mTargetWeight != null)
    {
      TextView localTextView = this.mTargetWeight;
      int i = R.string.c_57_1_4;
      String[] arrayOfString = new String[1];
      arrayOfString[0] = paramUpdateTargetWeightEvent.newTargetWeight;
      localTextView.setText(UseStringUtils.getStr(i, arrayOfString));
    }
  }

  @Subscribe
  public void onEventMainThread(UpdateWeightEvent paramUpdateWeightEvent)
  {
    if ("0".equals(paramUpdateWeightEvent.weightModel2.girthType))
    {
      this.presenter.refreshDate();
      refreshChartView();
      this.mCalendarView.refreshPageData(paramUpdateWeightEvent.weightModel2.recordDate);
    }
  }

  public void onHiddenChanged(boolean paramBoolean)
  {
    super.onHiddenChanged(paramBoolean);
    VdsAgent.onFragmentHiddenChanged(this, paramBoolean);
  }

  public void onPause()
  {
    super.onPause();
    VdsAgent.onFragmentPause(this);
  }

  public <T> void onRefresh(T paramT)
  {
  }

  public void onResume()
  {
    VdsAgent.onFragmentResume(this);
    super.onResume();
    showCalendar();
  }

  public void setReformer(WeightReformer2 paramWeightReformer2)
  {
    WeightReformer3 localWeightReformer3 = paramWeightReformer2.weightReformer3;
    this.presenter.putReformer(localWeightReformer3.tabType, localWeightReformer3);
    this.bodyFastReformer = paramWeightReformer2.bodyFastReformer;
    this.bodyFastPresenter.putReformer(this.bodyFastReformer.tabType, this.bodyFastReformer);
  }

  public void setUserVisibleHint(boolean paramBoolean)
  {
    super.setUserVisibleHint(paramBoolean);
    VdsAgent.setFragmentUserVisibleHint(this, paramBoolean);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.fragment.WeightFragment
 * JD-Core Version:    0.6.0
 */