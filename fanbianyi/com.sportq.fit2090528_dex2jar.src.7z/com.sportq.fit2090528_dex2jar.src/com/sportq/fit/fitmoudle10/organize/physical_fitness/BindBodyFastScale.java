package com.sportq.fit.fitmoudle10.organize.physical_fitness;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.MenuItem;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.kitnew.ble.QNBleApi;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.organize.eventbus.BodyFastEvent;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.radar.RippleEffectLayout;
import java.util.Timer;
import java.util.TimerTask;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class BindBodyFastScale extends BaseActivity
{
  private int COUNTDOWN = 30;
  private QNBleApi qnBleApi;
  private String resultFlg;
  private RippleEffectLayout ripple_effect_layout;
  TimerTask task = new BindBodyFastScale.3(this);
  private Timer timer;

  private void doStartScan()
  {
    if (this.qnBleApi.isScanning())
      return;
    this.qnBleApi.setScanMode(0);
    this.qnBleApi.setSteadyBodyfat(true);
    this.qnBleApi.startLeScan(null, null, new BindBodyFastScale.2(this));
  }

  private void doStopScan()
  {
    if ((this.qnBleApi == null) || (!this.qnBleApi.isScanning()))
      return;
    this.qnBleApi.stopScan();
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.bind_body_fast_scale);
    EventBus.getDefault().register(this);
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setTitle("绑定体脂秤");
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    localCustomToolBar.setBackgroundResource(R.color.white);
    setSupportActionBar(localCustomToolBar);
    CompDeviceInfoUtils.applyPermission(new BindBodyFastScale.1(this), this, new String[] { "android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION" });
  }

  protected void onDestroy()
  {
    super.onDestroy();
    if (this.timer != null)
      this.timer.cancel();
    if (this.qnBleApi != null)
      this.qnBleApi.disconnectAll();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(BodyFastEvent paramBodyFastEvent)
  {
    if ((paramBodyFastEvent != null) && (paramBodyFastEvent.isRefresh))
      finish();
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.physical_fitness.BindBodyFastScale
 * JD-Core Version:    0.6.0
 */