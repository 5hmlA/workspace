package com.sportq.fit.fitmoudle10.organize.physical_fitness;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.FitnessHistoryAdapter;
import com.sportq.fit.fitmoudle10.organize.presenter.FitMoudle10ApiPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.model.PhyResultData;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.PhyHisReformer;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.PhyResultReformer;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class FitnessHistoryActivity extends BaseActivity
{
  private LinearLayout emptyView;
  private TextView empty_hint;
  private ImageView empty_icon;
  private RecyclerView recyclerView;

  private PhyResultReformer convertData(PhyResultData paramPhyResultData)
  {
    Gson localGson = new Gson();
    return (PhyResultReformer)localGson.fromJson(localGson.toJson(paramPhyResultData), PhyResultReformer.class);
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    PhyHisReformer localPhyHisReformer;
    if ((paramT instanceof PhyHisReformer))
    {
      localPhyHisReformer = (PhyHisReformer)paramT;
      if ((localPhyHisReformer.lstPhyRes == null) || (localPhyHisReformer.lstPhyRes.size() == 0))
      {
        this.recyclerView.setVisibility(8);
        this.emptyView.setVisibility(0);
        this.empty_icon.setImageResource(R.mipmap.icn_photo);
        this.empty_hint.setText(getString(R.string.c_67_13_2));
      }
    }
    else
    {
      return;
    }
    this.recyclerView.setVisibility(0);
    this.emptyView.setVisibility(8);
    FitnessHistoryAdapter localFitnessHistoryAdapter = new FitnessHistoryAdapter(this, localPhyHisReformer.lstPhyRes, R.layout.phy_history_item_layout);
    localFitnessHistoryAdapter.setOnItemClickListener(new FitnessHistoryActivity.1(this, localPhyHisReformer));
    this.recyclerView.setAdapter(localFitnessHistoryAdapter);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.fitness_history_layout);
    EventBus.getDefault().register(this);
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setTitle(getString(R.string.c_79_1_1));
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    localCustomToolBar.setBackgroundResource(R.color.white);
    setSupportActionBar(localCustomToolBar);
    this.emptyView = ((LinearLayout)findViewById(R.id.emptyView));
    this.empty_icon = ((ImageView)findViewById(R.id.empty_icon));
    this.empty_hint = ((TextView)findViewById(R.id.empty_hint));
    this.recyclerView = ((RecyclerView)findViewById(R.id.history_recyclerView));
    this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
    new FitMoudle10ApiPresenter(this).getPhyHistory(this);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("phy.close.other.page".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.physical_fitness.FitnessHistoryActivity
 * JD-Core Version:    0.6.0
 */