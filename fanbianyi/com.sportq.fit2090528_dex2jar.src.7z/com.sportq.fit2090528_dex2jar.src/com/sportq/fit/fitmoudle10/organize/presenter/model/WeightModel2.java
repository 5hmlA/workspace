package com.sportq.fit.fitmoudle10.organize.presenter.model;

import com.sportq.fit.common.model.BaseDBModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle10.organize.utils.DateUtils10;
import com.tencent.bugly.crashreport.CrashReport;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import org.xutils.db.annotation.Column;
import org.xutils.db.annotation.Table;
import org.xutils.db.table.DbModel;

@Table(name="weightModel2")
public class WeightModel2 extends BaseDBModel
  implements Serializable
{
  private static final long serialVersionUID = 1L;

  @Column(name="date")
  public int date;
  public String dbRecordDate;

  @Column(name="girthType")
  public String girthType;

  @Column(name="month")
  public int month;

  @Column(name="quarter")
  public int quarter;

  @Column(name="recordDate")
  public String recordDate;
  public String strBodyFatJson;

  @Column(name="weight")
  public String weight;

  @Column(name="year")
  public int year;

  public void calculateQuarter()
  {
    switch (this.month)
    {
    default:
      return;
    case 1:
    case 2:
    case 3:
      this.quarter = 1;
      return;
    case 4:
    case 5:
    case 6:
      this.quarter = 2;
      return;
    case 7:
    case 8:
    case 9:
      this.quarter = 3;
      return;
    case 10:
    case 11:
    case 12:
    }
    this.quarter = 4;
  }

  public void setDMY(String paramString)
  {
    try
    {
      Date localDate = DateUtils10.string2Date(paramString);
      Calendar localCalendar = Calendar.getInstance();
      localCalendar.setTime(localDate);
      this.date = localCalendar.get(5);
      this.month = (1 + localCalendar.get(2));
      this.year = localCalendar.get(1);
      calculateQuarter();
      return;
    }
    catch (ParseException localParseException)
    {
      LogUtils.e(localParseException);
    }
  }

  public void setData(DbModel paramDbModel, int paramInt)
  {
    try
    {
      this.recordDate = paramDbModel.getString("recordDate");
      this.weight = paramDbModel.getString("weight");
      this.girthType = paramDbModel.getString("girthType");
      this.date = paramDbModel.getInt("date");
      this.month = paramDbModel.getInt("month");
      this.year = paramDbModel.getInt("year");
      this.quarter = paramDbModel.getInt("quarter");
      if ((paramInt == 0) && (!this.weight.contains("±")))
        this.weight = new DecimalFormat("0.0").format(Float.parseFloat(this.weight));
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
      CrashReport.postCatchedException(new Throwable(localException));
    }
  }

  public String toString()
  {
    return "WeightModel2{recordDate='" + this.recordDate + '\'' + ", weight='" + this.weight + '\'' + ", type='" + this.girthType + '\'' + ", dbRecordDate='" + this.dbRecordDate + '\'' + ", id=" + this.id + ", userId='" + this.userId + '\'' + '}';
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.presenter.model.WeightModel2
 * JD-Core Version:    0.6.0
 */