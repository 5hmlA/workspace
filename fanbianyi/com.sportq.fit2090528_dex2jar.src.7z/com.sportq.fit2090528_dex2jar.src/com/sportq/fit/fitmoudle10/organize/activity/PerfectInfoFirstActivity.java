package com.sportq.fit.fitmoudle10.organize.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.style.RelativeSizeSpan;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.RuleLineAdapter;
import com.sportq.fit.fitmoudle10.organize.eventbus.UpdateHealthDataFinishEvent;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class PerfectInfoFirstActivity extends BaseActivity
  implements AbsListView.OnScrollListener
{
  private RuleLineAdapter adapter;
  private int firstIndex;
  private TextView height_value;
  private ListView list_view;

  private void initControl()
  {
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setTitle(R.string.c_75_1_1);
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    localCustomToolBar.setBackgroundResource(R.color.white);
    setSupportActionBar(localCustomToolBar);
    ((TextView)findViewById(R.id.next_btn)).setOnClickListener(new FitAction(this));
    this.height_value = ((TextView)findViewById(R.id.height_value));
    ImageView localImageView = (ImageView)findViewById(R.id.user_model_icon);
    RelativeLayout localRelativeLayout1 = (RelativeLayout)findViewById(R.id.rule_layout);
    RelativeLayout localRelativeLayout2 = (RelativeLayout)findViewById(R.id.user_model_layout);
    this.list_view = ((ListView)findViewById(R.id.list_view));
    this.adapter = new RuleLineAdapter(localRelativeLayout2, this);
    this.list_view.setAdapter(this.adapter);
    this.list_view.setOnScrollListener(this);
    localRelativeLayout1.getLayoutParams().width = (int)(0.17D * BaseApplication.screenWidth);
    if ("0".equals(BaseApplication.userModel.userSex))
    {
      localImageView.setImageResource(R.mipmap.male_model_icon);
      new Handler().postDelayed(new PerfectInfoFirstActivity.1(this), 100L);
      return;
    }
    localImageView.setImageResource(R.mipmap.female_model_icon);
    new Handler().postDelayed(new PerfectInfoFirstActivity.2(this), 100L);
  }

  public void fitOnClick(View paramView)
  {
    String str;
    if (paramView.getId() == R.id.next_btn)
    {
      str = this.height_value.getText().toString();
      if (!StringUtils.isNull(str))
        break label45;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      label45: Intent localIntent = new Intent(this, PerfectInfoSecondActivity.class);
      localIntent.putExtra("user.height", str.replace("cm", ""));
      startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.perfect_info_first);
    EventBus.getDefault().register(this);
    initControl();
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(UpdateHealthDataFinishEvent paramUpdateHealthDataFinishEvent)
  {
    if ((paramUpdateHealthDataFinishEvent == null) || (StringUtils.isNull(paramUpdateHealthDataFinishEvent.strCloseHealthDataPageTag)))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }

  public void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
  {
    try
    {
      this.firstIndex = paramInt1;
      if ((this.adapter != null) && (5 + this.firstIndex < this.adapter.getIndexList().size()))
      {
        String str = this.adapter.getIndexList().get(paramInt1 + 5) + "cm";
        SpannableString localSpannableString = new SpannableString(str);
        localSpannableString.setSpan(new RelativeSizeSpan(0.95F), -2 + str.length(), str.length(), 33);
        this.height_value.setText(localSpannableString);
        this.height_value.getPaint().setFakeBoldText(true);
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
  {
    switch (paramInt)
    {
    case 1:
    default:
      return;
    case 0:
    }
    this.list_view.smoothScrollToPosition(this.firstIndex);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.PerfectInfoFirstActivity
 * JD-Core Version:    0.6.0
 */