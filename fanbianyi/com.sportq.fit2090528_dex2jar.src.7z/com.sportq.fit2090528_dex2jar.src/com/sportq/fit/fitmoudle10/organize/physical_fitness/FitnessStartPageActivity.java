package com.sportq.fit.fitmoudle10.organize.physical_fitness;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class FitnessStartPageActivity extends BaseActivity
{
  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.exist_btn)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() == R.id.history_btn)
      {
        startActivity(new Intent(this, FitnessHistoryActivity.class));
        AnimationUtil.pageJumpAnim(this, 0);
        continue;
      }
      if (paramView.getId() != R.id.start_fitness_btn)
        continue;
      startActivity(new Intent(this, FitnessTestPreviewActivity.class));
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.fitness_start_page);
    EventBus.getDefault().register(this);
    findViewById(R.id.exist_btn).setOnClickListener(new FitAction(this));
    findViewById(R.id.history_btn).setOnClickListener(new FitAction(this));
    findViewById(R.id.start_fitness_btn).setOnClickListener(new FitAction(this));
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("phy.close.other.page".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.physical_fitness.FitnessStartPageActivity
 * JD-Core Version:    0.6.0
 */