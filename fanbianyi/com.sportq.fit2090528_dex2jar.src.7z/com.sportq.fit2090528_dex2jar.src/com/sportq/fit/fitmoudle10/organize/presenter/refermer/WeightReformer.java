package com.sportq.fit.fitmoudle10.organize.presenter.refermer;

import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.BaseReformer;
import com.sportq.fit.common.constant.Constant;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.model.WeightModel;
import com.sportq.fit.common.model.response.ResponseModel;
import com.sportq.fit.common.model.response.ResponseModel.WeightData;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.StringUtils;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

@Deprecated
public class WeightReformer extends BaseReformer
  implements Serializable
{
  public ArrayList<WeightModel> _weightArray;
  public ArrayList<ArrayList<WeightModel>> _weightShowArrays;
  public String lastRecordStr = "";
  public ArrayList<ArrayList<WeightModel>> m_weightShowArrays;
  public String maxWeight;
  public String type;
  public ArrayList<ArrayList<WeightModel>> w_weightShowArrays;

  public WeightReformer(String paramString)
  {
    this.type = paramString;
  }

  private void removeMoreInfo()
  {
    int i = 0;
    ArrayList localArrayList = (ArrayList)this._weightShowArrays.get(0);
    Iterator localIterator = localArrayList.iterator();
    while (localIterator.hasNext())
    {
      if (!"-1".equals(((WeightModel)localIterator.next()).weight))
        continue;
      i++;
    }
    if (i == localArrayList.size())
    {
      this._weightShowArrays.remove(0);
      removeMoreInfo();
    }
  }

  private String rep_0_Number(String paramString)
  {
    return paramString.replaceFirst("^0*", "");
  }

  public void dateToWeightReformer(ResponseModel paramResponseModel)
  {
    this._weightArray = new ArrayList();
    for (int i = 0; i < paramResponseModel.lstWeight.size(); i++)
    {
      ResponseModel.WeightData localWeightData = (ResponseModel.WeightData)paramResponseModel.lstWeight.get(i);
      WeightModel localWeightModel = new WeightModel();
      localWeightModel.recordDate = localWeightData.recordDate;
      localWeightModel.weight = localWeightData.weight;
      localWeightModel.isShowDot = localWeightData.isShowDot;
      localWeightModel.userId = BaseApplication.userModel.userId;
      this._weightArray.add(localWeightModel);
    }
  }

  public void getWeightDateList(int paramInt, ArrayList<WeightModel> paramArrayList)
  {
    this._weightShowArrays = new ArrayList();
    ArrayList localArrayList1 = null;
    int i = 0;
    String str1 = Constant.STR_0;
    int j = 0;
    if (j < paramArrayList.size())
    {
      if ((StringUtils.isNull(this.maxWeight)) || (Float.valueOf(((WeightModel)paramArrayList.get(j)).weight).floatValue() > Float.valueOf(this.maxWeight).floatValue()))
        this.maxWeight = ((WeightModel)paramArrayList.get(j)).weight;
      WeightModel localWeightModel2 = new WeightModel();
      localWeightModel2.dbRecordDate = ((WeightModel)paramArrayList.get(j)).recordDate;
      localWeightModel2.recordDate = weightDate(((WeightModel)paramArrayList.get(j)).recordDate, 1);
      localWeightModel2.weight = ((WeightModel)paramArrayList.get(j)).weight;
      localWeightModel2.isShowDot = ((WeightModel)paramArrayList.get(j)).isShowDot;
      if (Constant.STR_0.equals(localWeightModel2.isShowDot))
      {
        localWeightModel2.lineFlg = str1;
        label194: if (localArrayList1 == null)
          localArrayList1 = new ArrayList();
        if (paramInt - 1 == i)
          break label336;
        localArrayList1.add(localWeightModel2);
        i++;
        if (j == -1 + paramArrayList.size())
        {
          Collections.reverse(localArrayList1);
          this._weightShowArrays.add(localArrayList1);
        }
      }
      while (true)
      {
        j++;
        break;
        str1 = Constant.STR_1;
        localWeightModel2.lineFlg = str1;
        if (!StringUtils.isNull(this.lastRecordStr))
          break label194;
        int i1 = DateUtils.getChaNowDate(((WeightModel)paramArrayList.get(j)).recordDate);
        if (i1 == 0);
        for (String str4 = "当前体重"; ; str4 = i1 + "天前")
        {
          this.lastRecordStr = str4;
          break;
        }
        label336: localArrayList1.add(localWeightModel2);
        Collections.reverse(localArrayList1);
        this._weightShowArrays.add(localArrayList1);
        i = 0;
        localArrayList1 = null;
      }
    }
    Collections.reverse(this._weightShowArrays);
    if (this._weightShowArrays != null)
    {
      removeMoreInfo();
      if (this._weightShowArrays.size() > 1)
      {
        ArrayList localArrayList2 = (ArrayList)this._weightShowArrays.get(0);
        if (localArrayList2.size() != paramInt)
        {
          int m = localArrayList2.size();
          for (int n = 0; n < paramInt - m; n++)
          {
            WeightModel localWeightModel1 = new WeightModel();
            localWeightModel1.dbRecordDate = DateUtils.getYesterDayDate(((WeightModel)localArrayList2.get(0)).dbRecordDate);
            localWeightModel1.recordDate = rep_0_Number(localWeightModel1.dbRecordDate.split("-")[2]);
            localWeightModel1.weight = "-1";
            localWeightModel1.isShowDot = "0";
            localWeightModel1.lineFlg = "0";
            localArrayList2.add(0, localWeightModel1);
          }
          this._weightShowArrays.set(0, localArrayList2);
        }
      }
      for (int k = 0; k < this._weightShowArrays.size(); k++)
      {
        String str3 = ((WeightModel)((ArrayList)this._weightShowArrays.get(k)).get(0)).dbRecordDate;
        ((WeightModel)((ArrayList)this._weightShowArrays.get(k)).get(0)).recordDate = weightDate(str3, 0);
      }
    }
    String str2;
    if (StringUtils.isNull(this.lastRecordStr))
    {
      str2 = "当前体重";
      this.lastRecordStr = str2;
      if (paramInt != 7)
        break label648;
      this.w_weightShowArrays = this._weightShowArrays;
    }
    label648: 
    do
    {
      return;
      str2 = this.lastRecordStr;
      break;
    }
    while (paramInt != 30);
    this.m_weightShowArrays = this._weightShowArrays;
  }

  public ArrayList<WeightModel> setShowArray(ArrayList<WeightModel> paramArrayList)
  {
    if ((paramArrayList != null) && (paramArrayList.size() > 1) && ("0".equals(((WeightModel)paramArrayList.get(0)).weight)))
      ((WeightModel)paramArrayList.get(0)).weight = BaseApplication.userModel.targetWeight;
    Collections.reverse(paramArrayList);
    ArrayList localArrayList1 = new ArrayList();
    int i = 0;
    ArrayList localArrayList2 = new ArrayList();
    int j = 0;
    if (j < paramArrayList.size())
    {
      WeightModel localWeightModel = (WeightModel)paramArrayList.get(j);
      if ("0".equals(localWeightModel.weight))
      {
        if (j == 0)
          i = 1;
        if (i != 0)
          localWeightModel.weight = "-1";
        localArrayList2.add(Integer.valueOf(j));
      }
      while (true)
      {
        localArrayList1.add(localWeightModel);
        j++;
        break;
        if (i == 0)
        {
          int k = localArrayList2.size();
          if (k > 0)
          {
            int m = ((Integer)localArrayList2.get(0)).intValue();
            float f1;
            int n;
            label227: float f2;
            if (m > 0)
            {
              f1 = (Float.valueOf(((WeightModel)paramArrayList.get(m - 1)).weight).floatValue() - Float.valueOf(localWeightModel.weight).floatValue()) / (k + 1);
              n = 0;
              if (n >= k)
                break label355;
              if (m <= 0)
                break label340;
              f2 = Float.valueOf(((WeightModel)paramArrayList.get(m - 1)).weight).floatValue() - f1 * (n + 1);
            }
            while (true)
            {
              String str = new DecimalFormat(".0").format(f2);
              ((WeightModel)paramArrayList.get(((Integer)localArrayList2.get(n)).intValue())).weight = str;
              n++;
              break label227;
              f1 = Float.valueOf(localWeightModel.weight).floatValue() / (k + 1);
              break;
              label340: f2 = f1 * (n + 1);
            }
          }
        }
        else
        {
          i = 0;
        }
        label355: localArrayList2.clear();
      }
    }
    Collections.reverse(localArrayList1);
    return localArrayList1;
  }

  public String weightDate(String paramString, int paramInt)
  {
    String[] arrayOfString = paramString.split("-");
    if (paramInt == 0)
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = rep_0_Number(arrayOfString[1]);
      arrayOfObject[1] = rep_0_Number(arrayOfString[2]);
      return String.format("%s.%s", arrayOfObject);
    }
    return rep_0_Number(arrayOfString[2]);
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.presenter.refermer.WeightReformer
 * JD-Core Version:    0.6.0
 */