package com.sportq.fit.fitmoudle10.organize.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.ButterKnife;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.event.TrainFinishPageFinishBtnClickEvent;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.find.FindPresenterInterface;
import com.sportq.fit.common.model.ActionModel;
import com.sportq.fit.common.model.EntdayPlanData;
import com.sportq.fit.common.model.PlanModel;
import com.sportq.fit.common.model.StageModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.StringUtils;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.DelFitnessPhotoEvent;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.sharemanager.dataModel.UseShareModel;
import com.sportq.fit.fitmoudle.widget.CustomTextView;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.menu;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.presenter.MinePresenterImpl;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.TrainDetailsReformer;
import com.sportq.fit.middlelib.MiddleManager;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class TrainDetailInfoActivity extends BaseActivity
  implements FitInterfaceUtils.UIInitListener
{
  public static final String INTENT_CALORIE = "intent.calorie";
  public static final String INTENT_OLAPINFO = "intent.olapInfo";
  public static final String INTENT_PLANID = "intent.planId";
  public static final String INTENT_TIME = "intent.time";
  public static final String KEY_SHOW_BOTTOM_BTN = "show.bottom.btn";
  private CustomTextView act_duration;
  private CustomTextView act_item_length;
  private CustomTextView act_item_name;
  private LinearLayout act_layout;
  private RelativeLayout act_name;
  private TextView calorie_hint;
  private TextView duration_hint;
  private ImageView energy_icon;
  private TextView finish_number;
  private String hisId;
  boolean isShowBottomBtn = false;
  private Object object = null;
  private String olapInfo;
  private CustomTextView phase_length;
  private CustomTextView phase_name;
  private RelativeLayout phase_name_l;
  private PlanModel planModel;
  private String strCalorie;
  private String strId;
  private String strTrainTime;
  private String strWeekId;
  private Menu tMenu;
  private CustomToolBar toolbar;
  private TextView train_name;

  private void finishPage()
  {
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  private View inflaterItemView()
  {
    View localView = LayoutInflater.from(this).inflate(R.layout.mine03_traininfo_item, null);
    this.phase_name_l = ((RelativeLayout)localView.findViewById(R.id.phase_name));
    this.phase_name = ((CustomTextView)localView.findViewById(R.id.mine02_collec_train_act_name));
    this.phase_length = ((CustomTextView)localView.findViewById(R.id.mine02_collec_train_act_length));
    this.act_name = ((RelativeLayout)localView.findViewById(R.id.act_name));
    this.act_duration = ((CustomTextView)localView.findViewById(R.id.mine02_collec_act_duration));
    this.act_item_name = ((CustomTextView)localView.findViewById(R.id.mine02_collec_act_name));
    this.act_item_length = ((CustomTextView)localView.findViewById(R.id.mine02_collec_act_time));
    return localView;
  }

  private void initMine02()
  {
    this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.act_layout = ((LinearLayout)findViewById(R.id.act_layout));
    this.train_name = ((TextView)findViewById(R.id.train_name));
    this.energy_icon = ((ImageView)findViewById(R.id.energy_icon));
    this.finish_number = ((TextView)findViewById(R.id.finish_number));
    this.duration_hint = ((TextView)findViewById(R.id.duration_hint));
    this.calorie_hint = ((TextView)findViewById(R.id.calorie_hint));
    this.toolbar.setTitle("");
    this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    this.toolbar.setNavIcon(R.mipmap.btn_back_black);
    this.toolbar.setBackgroundResource(R.color.white);
    setSupportActionBar(this.toolbar);
    this.hisId = getIntent().getStringExtra("intent.planId");
    this.olapInfo = getIntent().getStringExtra("intent.olapInfo");
    int i;
    if (StringUtils.isNull(this.hisId))
    {
      this.object = getIntent().getSerializableExtra("data");
      this.strWeekId = getIntent().getStringExtra("week.id");
      this.strId = getIntent().getStringExtra("use.id");
      this.isShowBottomBtn = getIntent().getBooleanExtra("show.bottom.btn", false);
      View localView = findViewById(R.id.train_again);
      if (!this.isShowBottomBtn)
        break label313;
      i = 0;
      localView.setVisibility(i);
      findViewById(R.id.train_again).setOnClickListener(new FitAction(this));
      if (!(this.object instanceof PlanModel))
        break label319;
      this.hisId = ((PlanModel)this.object).histId;
    }
    while (true)
    {
      if (!StringUtils.isNull(this.hisId))
        break label346;
      return;
      label313: i = 8;
      break;
      label319: if (!(this.object instanceof EntdayPlanData))
        continue;
      this.hisId = ((EntdayPlanData)this.object).histId;
    }
    label346: RequestModel localRequestModel = new RequestModel();
    localRequestModel.histId = this.hisId;
    this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
    new MinePresenterImpl(this).getTrainDetails(this, localRequestModel);
  }

  private void setData()
  {
    setHeadData();
    setListData();
  }

  private void setHeadData()
  {
    if (this.planModel == null);
    while (true)
    {
      return;
      if (!StringUtils.isNull(this.planModel.planName))
        this.train_name.setText(this.planModel.planName);
      label61: int i;
      label108: String str1;
      label221: Object localObject;
      if ("1".equals(this.planModel.energyFlag))
      {
        this.energy_icon.setImageResource(R.mipmap.icn_energy);
        ImageView localImageView = this.energy_icon;
        boolean bool1 = "1".equals(this.planModel.energyFlag);
        i = 0;
        if (!bool1)
        {
          boolean bool2 = "2".equals(this.planModel.energyFlag);
          i = 0;
          if (!bool2)
            break label496;
        }
        localImageView.setVisibility(i);
        this.duration_hint.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
        this.strTrainTime = StringUtils.getTrainDuration(StringUtils.string2Int(String.valueOf(StringUtils.timeStr2Long(this.planModel.planTrainDuration).longValue())));
        this.duration_hint.setText(this.strTrainTime);
        this.calorie_hint.setTypeface(Typeface.createFromAsset(BaseApplication.appliContext.getAssets(), "fonts/impact.ttf"));
        if (!this.planModel.planKaluri.contains("千卡"))
          break label502;
        str1 = this.planModel.planKaluri.replace("千卡", "");
        this.strCalorie = str1;
        this.calorie_hint.setText(this.strCalorie);
        this.finish_number.setText("已完成" + this.planModel.finishSection);
        localObject = "";
      }
      try
      {
        String str2 = String.valueOf(Calendar.getInstance().get(1));
        String[] arrayOfString1;
        String[] arrayOfString2;
        if (this.planModel.planTitleDate.contains("/"))
        {
          arrayOfString1 = this.planModel.planTitleDate.split(" ");
          arrayOfString2 = arrayOfString1[0].split("/");
          if (arrayOfString2.length != 2)
            break label514;
          localObject = arrayOfString2[0] + "月" + arrayOfString2[1] + "日" + " " + arrayOfString1[1];
        }
        while (true)
        {
          CustomToolBar localCustomToolBar = this.toolbar;
          if (StringUtils.isNull((String)localObject))
            localObject = this.planModel.planTitleDate;
          localCustomToolBar.setTitle((CharSequence)localObject);
          if ((this.tMenu == null) || (this.planModel.flg == null))
            break;
          this.tMenu.findItem(R.id.action_photoInfo).setVisible("1".equals(this.planModel.flg));
          return;
          if (!"2".equals(this.planModel.energyFlag))
            break label61;
          this.energy_icon.setImageResource(R.mipmap.icon_exclusive_lesson);
          break label61;
          label496: i = 8;
          break label108;
          label502: str1 = this.planModel.planKaluri;
          break label221;
          label514: if (arrayOfString2.length != 3)
            continue;
          if (str2.equals(arrayOfString2[0]))
          {
            localObject = arrayOfString2[1] + "月" + arrayOfString2[2] + "日" + " " + arrayOfString1[1];
            continue;
          }
          String str3 = arrayOfString2[0] + "年" + arrayOfString2[1] + "月" + arrayOfString2[2] + "日" + " " + arrayOfString1[1];
          localObject = str3;
        }
      }
      catch (Exception localException)
      {
        while (true)
          LogUtils.e(localException);
      }
    }
  }

  private void setListData()
  {
    if (this.planModel == null);
    do
    {
      return;
      this.act_layout.removeAllViews();
      View localView1 = View.inflate(this, R.layout.train_detail_item_title_layout, null);
      ((TextView)localView1.findViewById(R.id.item_title)).setText("动作详情");
      this.act_layout.addView(localView1);
      Iterator localIterator1 = this.planModel.stageArray.iterator();
      while (localIterator1.hasNext())
      {
        StageModel localStageModel = (StageModel)localIterator1.next();
        View localView4 = inflaterItemView();
        this.phase_name_l.setVisibility(0);
        String str2 = localStageModel.stageName.replace("阶段", "");
        if (str2.equals("拉伸"))
          str2 = "拉伸放松";
        this.phase_name.setText(str2);
        this.phase_length.setText(StringUtils.timeInt2Str(localStageModel.duration));
        this.act_name.setVisibility(8);
        this.act_duration.setVisibility(8);
        this.act_layout.addView(localView4);
        Iterator localIterator2 = localStageModel.actionArray.iterator();
        while (localIterator2.hasNext())
        {
          ActionModel localActionModel = (ActionModel)localIterator2.next();
          View localView5 = inflaterItemView();
          this.phase_name_l.setVisibility(8);
          this.act_duration.setText(localActionModel.actionDuration);
          this.act_item_length.setTextContent(localActionModel.trainDuration);
          this.act_item_name.setText(localActionModel.actionName);
          this.act_layout.addView(localView5);
        }
      }
    }
    while ((!"0".equals(this.planModel.feelingCode)) && (!"1".equals(this.planModel.feelingCode)) && (!"2".equals(this.planModel.feelingCode)));
    View localView2 = View.inflate(this, R.layout.train_detail_item_title_layout, null);
    ((TextView)localView2.findViewById(R.id.item_title)).setText("训练反馈");
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, -2);
    localLayoutParams.topMargin = CompDeviceInfoUtils.convertOfDip(this, 25.0F);
    this.act_layout.addView(localView2, localLayoutParams);
    View localView3 = View.inflate(this, R.layout.train_feedback_item_layout, null);
    TextView localTextView = (TextView)localView3.findViewById(R.id.train_experience);
    int i;
    Drawable localDrawable;
    String str1;
    if ("0".equals(this.planModel.feelingCode))
    {
      i = R.mipmap.train_feeling_simple_detiel;
      localDrawable = ContextCompat.getDrawable(this, i);
      if (!"0".equals(this.planModel.feelingCode))
        break label531;
      str1 = "太简单";
    }
    while (true)
    {
      localDrawable.setBounds(0, 0, CompDeviceInfoUtils.convertOfDip(this, 22.0F), CompDeviceInfoUtils.convertOfDip(this, 22.0F));
      localTextView.setText(str1);
      localTextView.setCompoundDrawables(localDrawable, null, null, null);
      this.act_layout.addView(localView3);
      return;
      if ("1".equals(this.planModel.feelingCode))
      {
        i = R.mipmap.train_feeling_good_detiel;
        break;
      }
      i = R.mipmap.train_feeling_difficult_detiel;
      break;
      label531: if ("1".equals(this.planModel.feelingCode))
      {
        str1 = "刚刚好";
        continue;
      }
      str1 = "太难了";
    }
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.train_again)
    {
      if (!(this.object instanceof PlanModel))
        break label63;
      PlanModel localPlanModel = (PlanModel)this.object;
      FitJumpImpl.getInstance().customizeJumpCourse(this, localPlanModel.planId, "", localPlanModel.customDetailId, this.strWeekId, this.strId, "");
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      label63: if (!(this.object instanceof EntdayPlanData))
        continue;
      EntdayPlanData localEntdayPlanData = (EntdayPlanData)this.object;
      FitJumpImpl.getInstance().fatCampJumpCourseDetail(this, this.strId, localEntdayPlanData.customDetailId, localEntdayPlanData.planId, this.strWeekId, "", localEntdayPlanData.trainableDay);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
    try
    {
      if ((paramT instanceof String))
      {
        if (paramT.toString().contains("getReceiveMedalsSuccess"))
        {
          if (this.dialog != null)
            this.dialog.closeDialog();
          EventBus.getDefault().post(new TrainFinishPageFinishBtnClickEvent());
          EventBus.getDefault().post("fitness.pic.finish");
          finish();
          AnimationUtil.pagePopAnim(this, 1);
        }
        LogUtils.d("Find06TrainFinishActivi-》方法getDataFail：", paramT.toString());
      }
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
    if ((paramT instanceof TrainDetailsReformer))
    {
      this.planModel = ((TrainDetailsReformer)paramT)._planInfo;
      setData();
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.train_detail_info_layout);
    ButterKnife.bind(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    initMine02();
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    this.tMenu = paramMenu;
    getMenuInflater().inflate(R.menu.train_detail_info_menu, paramMenu);
    if ((this.planModel != null) && (this.planModel.flg != null))
      paramMenu.findItem(R.id.action_photoInfo).setVisible("1".equals(this.planModel.flg));
    return super.onCreateOptionsMenu(paramMenu);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    ButterKnife.unbind(this);
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(DelFitnessPhotoEvent paramDelFitnessPhotoEvent)
  {
    if (this.tMenu != null)
      this.tMenu.findItem(R.id.action_photoInfo).setVisible(false);
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finishPage();
      return true;
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
      finishPage();
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      if (paramMenuItem.getItemId() == R.id.action_share)
      {
        if (this.planModel == null)
          continue;
        UseShareModel localUseShareModel = new UseShareModel();
        localUseShareModel.planTrainDuration = this.strTrainTime;
        localUseShareModel.planKaluri = this.strCalorie;
        localUseShareModel.headUrl = this.planModel.shareImgUrl;
        localUseShareModel.planName = this.planModel.planName;
        int i = R.string.e_46_1;
        String[] arrayOfString = new String[1];
        arrayOfString[0] = this.planModel.finishSection.replace("第", "").replace("次", "");
        localUseShareModel.finishCount = UseStringUtils.getStr(this, i, arrayOfString);
        localUseShareModel.finishTime = this.toolbar.getTitle().toString();
        localUseShareModel.stageArray = this.planModel.stageArray;
        localUseShareModel.energyFlag = this.planModel.energyFlag;
        localUseShareModel.campFlag = this.planModel.campFlag;
        localUseShareModel.olapInfo = ("|!|" + this.olapInfo);
        if (this.dialog == null)
          continue;
        this.dialog.showShareChoiseDialog(this, 11, localUseShareModel, this.dialog);
        continue;
      }
      if (paramMenuItem.getItemId() != R.id.action_photoInfo)
        continue;
      MiddleManager.getInstance().getFindPresenterImpl(this, null).statsTrainRecordAlbumClick("add_train_img");
      FitJumpImpl.getInstance().recordJumpTrainPhotoInfo(this, this.hisId, "0");
    }
  }

  protected void onResume()
  {
    super.onResume();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.TrainDetailInfoActivity
 * JD-Core Version:    0.6.0
 */