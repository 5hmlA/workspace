package com.sportq.fit.fitmoudle10.organize.physical_fitness.radar;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.FontMetrics;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.support.v4.content.ContextCompat;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.styleable;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.radar.util.AnimeUtil;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.radar.util.AnimeUtil.AnimeType;
import com.sportq.fit.fitmoudle10.organize.physical_fitness.radar.util.RotateUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class RadarView extends View
{
  public static final int VERTEX_ICON_POSITION_BOTTOM = 4;
  public static final int VERTEX_ICON_POSITION_CENTER = 5;
  public static final int VERTEX_ICON_POSITION_LEFT = 1;
  public static final int VERTEX_ICON_POSITION_RIGHT = 2;
  public static final int VERTEX_ICON_POSITION_TOP = 3;
  public static final int WEB_MODE_CIRCLE = 2;
  public static final int WEB_MODE_POLYGON = 1;
  private double mAngle;
  private AnimeUtil mAnimeUtil;
  private String mCenterText;
  private int mCenterTextColor;
  private TextPaint mCenterTextPaint;
  private float mCenterTextSize;
  private Context mContext;
  private String mEmptyHint = "no data";
  private float mFlingPoint;
  private int mLayer;
  private List<Integer> mLayerColor;
  private int mLayerLineColor;
  private float mLayerLineWidth;
  private Paint mLayerPaint;
  private String mMaxLengthVertexText;
  private float mMaxValue;
  private List<Float> mMaxValues;
  private int mMaxVertex;
  private double mPerimeter;
  private PointF mPointCenter;
  private List<RadarData> mRadarData;
  private Paint mRadarLinePaint;
  private Path mRadarPath;
  private float mRadius;
  private double mRotateAngle;
  private double mRotateOrientation;
  private boolean mRotationEnable;
  private Paint mValuePaint;
  private TextPaint mValueTextPaint;
  private List<Bitmap> mVertexIcon;
  private float mVertexIconMargin;
  private int mVertexIconPosition;
  private RectF mVertexIconRect;
  private float mVertexIconSize;
  private int mVertexLineColor;
  private float mVertexLineWidth;
  private List<String> mVertexText;
  private int mVertexTextColor;
  private float mVertexTextOffset;
  private TextPaint mVertexTextPaint;
  private float mVertexTextSize;
  private int mWebMode;

  public RadarView(Context paramContext)
  {
    this(paramContext, null);
  }

  public RadarView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public RadarView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
    initAttrs(paramAttributeSet);
    init();
  }

  private void calcRadius()
  {
    if ((this.mVertexText == null) || (this.mVertexText.size() == 0))
    {
      this.mRadius = (Math.min(this.mPointCenter.x, this.mPointCenter.y) - this.mVertexTextOffset);
      return;
    }
    float f;
    if ((this.mVertexIconPosition == 1) || (this.mVertexIconPosition == 2))
      f = (this.mVertexTextPaint.measureText(this.mMaxLengthVertexText) + this.mVertexIconMargin + this.mVertexIconSize) / 2.0F;
    while (true)
    {
      this.mRadius = (Math.min(this.mPointCenter.x, this.mPointCenter.y) - (f + this.mVertexTextOffset));
      this.mPerimeter = (6.283185307179586D * this.mRadius);
      return;
      f = Math.max(this.mVertexTextPaint.measureText(this.mMaxLengthVertexText), this.mVertexIconSize) / 2.0F;
    }
  }

  private float dp2px(float paramFloat)
  {
    return 0.5F + paramFloat * this.mContext.getResources().getDisplayMetrics().density;
  }

  private void drawCenterText(Canvas paramCanvas)
  {
    if (!TextUtils.isEmpty(this.mCenterText))
    {
      float f1 = this.mCenterTextPaint.measureText(this.mCenterText);
      Paint.FontMetrics localFontMetrics = this.mCenterTextPaint.getFontMetrics();
      float f2 = localFontMetrics.descent - localFontMetrics.ascent;
      paramCanvas.drawText(this.mCenterText, this.mPointCenter.x - f1 / 2.0F, this.mPointCenter.y + f2 / 3.0F, this.mCenterTextPaint);
    }
  }

  private void drawCircle(Canvas paramCanvas)
  {
    for (int i = this.mLayer; i >= 1; i--)
    {
      float f = this.mRadius / this.mLayer * i;
      int j = ((Integer)this.mLayerColor.get(i - 1)).intValue();
      if (j != 0)
      {
        this.mLayerPaint.setColor(j);
        paramCanvas.drawCircle(this.mPointCenter.x, this.mPointCenter.y, f, this.mLayerPaint);
      }
      if (this.mLayerLineWidth <= 0.0F)
        continue;
      this.mRadarLinePaint.setColor(this.mLayerLineColor);
      this.mRadarLinePaint.setStrokeWidth(this.mLayerLineWidth);
      paramCanvas.drawCircle(this.mPointCenter.x, this.mPointCenter.y, f, this.mRadarLinePaint);
    }
  }

  private void drawData(Canvas paramCanvas)
  {
    for (int i = 0; i < this.mRadarData.size(); i++)
    {
      RadarData localRadarData = (RadarData)this.mRadarData.get(i);
      this.mValuePaint.setColor(localRadarData.getColor());
      this.mValueTextPaint.setTextSize(localRadarData.getValueTextSize());
      this.mValueTextPaint.setColor(localRadarData.getVauleTextColor());
      List localList1 = localRadarData.getValue();
      this.mRadarPath.reset();
      PointF[] arrayOfPointF = new PointF[this.mMaxVertex];
      int j = 1;
      if (j <= this.mMaxVertex)
      {
        int m = localList1.size();
        float f3 = 0.0F;
        if (m >= j)
          f3 = ((Float)localList1.get(j - 1)).floatValue();
        Float localFloat;
        label168: label182: float f4;
        float f5;
        if (this.mMaxValues != null)
        {
          localFloat = Float.valueOf(f3 / ((Float)this.mMaxValues.get(j - 1)).floatValue());
          if (!localFloat.isInfinite())
            break label344;
          localFloat = Float.valueOf(1.0F);
          if (localFloat.floatValue() > 1.0F)
            localFloat = Float.valueOf(1.0F);
          f4 = (float)(this.mPointCenter.x + Math.sin(this.mAngle * j - this.mRotateAngle) * this.mRadius * localFloat.floatValue());
          f5 = (float)(this.mPointCenter.y - Math.cos(this.mAngle * j - this.mRotateAngle) * this.mRadius * localFloat.floatValue());
          if (j != 1)
            break label361;
          this.mRadarPath.moveTo(f4, f5);
        }
        while (true)
        {
          int n = j - 1;
          PointF localPointF = new PointF(f4, f5);
          arrayOfPointF[n] = localPointF;
          j++;
          break;
          localFloat = Float.valueOf(f3 / this.mMaxValue);
          break label168;
          label344: if (!localFloat.isNaN())
            break label182;
          localFloat = Float.valueOf(0.0F);
          break label182;
          label361: this.mRadarPath.lineTo(f4, f5);
        }
      }
      this.mRadarPath.close();
      this.mValuePaint.setAlpha(255);
      this.mValuePaint.setStyle(Paint.Style.STROKE);
      this.mValuePaint.setStrokeWidth(localRadarData.getLineWidth());
      paramCanvas.drawPath(this.mRadarPath, this.mValuePaint);
      this.mValuePaint.setStyle(Paint.Style.FILL);
      this.mValuePaint.setAlpha(150);
      paramCanvas.drawPath(this.mRadarPath, this.mValuePaint);
      if (!localRadarData.isValueTextEnable())
        continue;
      List localList2 = localRadarData.getValueText();
      for (int k = 0; k < arrayOfPointF.length; k++)
      {
        String str = "";
        if (localList2.size() > k)
          str = (String)localList2.get(k);
        float f1 = this.mValueTextPaint.measureText(str);
        Paint.FontMetrics localFontMetrics = this.mValueTextPaint.getFontMetrics();
        float f2 = localFontMetrics.descent - localFontMetrics.ascent;
        paramCanvas.drawText(str, arrayOfPointF[k].x - f1 / 2.0F, arrayOfPointF[k].y + f2 / 3.0F, this.mValueTextPaint);
      }
    }
  }

  private void drawRadar(Canvas paramCanvas)
  {
    drawRadarLine(paramCanvas);
    if (this.mWebMode == 1)
      drawWeb(paramCanvas);
    do
      return;
    while (this.mWebMode != 2);
    drawCircle(paramCanvas);
  }

  private void drawRadarLine(Canvas paramCanvas)
  {
    for (int i = 1; i <= this.mMaxVertex; i++)
    {
      double d1 = Math.sin(this.mAngle * i - this.mRotateAngle);
      double d2 = Math.cos(this.mAngle * i - this.mRotateAngle);
      drawVertex(paramCanvas, i, d1, d2);
      drawVertexLine(paramCanvas, d1, d2);
    }
  }

  private void drawVertex(Canvas paramCanvas, int paramInt, double paramDouble1, double paramDouble2)
  {
    float f1 = (float)(this.mPointCenter.x + paramDouble1 * (this.mRadius + this.mVertexTextOffset));
    float f2 = (float)(this.mPointCenter.y - paramDouble2 * (this.mRadius + this.mVertexTextOffset));
    String str = (String)this.mVertexText.get(paramInt - 1);
    float f3 = this.mVertexTextPaint.measureText(str);
    Paint.FontMetrics localFontMetrics = this.mVertexTextPaint.getFontMetrics();
    float f4 = localFontMetrics.descent - localFontMetrics.ascent;
    if ((this.mVertexIcon != null) && (this.mVertexIcon.size() >= paramInt))
    {
      Bitmap localBitmap = (Bitmap)this.mVertexIcon.get(paramInt - 1);
      int[] arrayOfInt = RotateUtil.geometricScaling(localBitmap.getWidth(), localBitmap.getHeight(), this.mVertexIconSize);
      float f5 = f2 + f4 / 4.0F;
      float f6 = f1 - f3 / 2.0F;
      switch (this.mVertexIconPosition)
      {
      default:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      }
      while (true)
      {
        drawVertexImpl(paramCanvas, str, localBitmap, this.mVertexTextPaint, f5, f6);
        return;
        this.mVertexIconRect.left = (f1 - (f3 + (arrayOfInt[0] + this.mVertexIconMargin)) / 2.0F);
        this.mVertexIconRect.right = (this.mVertexIconRect.left + arrayOfInt[0]);
        this.mVertexIconRect.top = (f2 - arrayOfInt[1] / 2.0F);
        this.mVertexIconRect.bottom = (this.mVertexIconRect.top + arrayOfInt[1]);
        f6 = this.mVertexIconRect.right + this.mVertexIconMargin;
        continue;
        this.mVertexIconRect.right = (f1 + (f3 + (arrayOfInt[0] + this.mVertexIconMargin)) / 2.0F);
        this.mVertexIconRect.left = (this.mVertexIconRect.right - arrayOfInt[0]);
        this.mVertexIconRect.top = (f2 - arrayOfInt[1] / 2.0F);
        this.mVertexIconRect.bottom = (this.mVertexIconRect.top + arrayOfInt[1]);
        f6 = this.mVertexIconRect.left - this.mVertexIconMargin - f3;
        continue;
        this.mVertexIconRect.left = (f1 - arrayOfInt[0] / 2.0F);
        this.mVertexIconRect.right = (this.mVertexIconRect.left + arrayOfInt[0]);
        this.mVertexIconRect.top = (f2 - (f4 + (arrayOfInt[1] + this.mVertexIconMargin)) / 2.0F);
        this.mVertexIconRect.bottom = (this.mVertexIconRect.top + arrayOfInt[1]);
        f5 = this.mVertexIconRect.bottom + this.mVertexIconMargin + f4 / 2.0F + f4 / 4.0F;
        continue;
        this.mVertexIconRect.left = (f1 - arrayOfInt[0] / 2.0F);
        this.mVertexIconRect.right = (this.mVertexIconRect.left + arrayOfInt[0]);
        this.mVertexIconRect.bottom = (f2 + (f4 + (arrayOfInt[1] + this.mVertexIconMargin)) / 2.0F);
        this.mVertexIconRect.top = (this.mVertexIconRect.bottom - arrayOfInt[1]);
        f5 = this.mVertexIconRect.top - this.mVertexIconMargin - f4 / 2.0F + f4 / 4.0F;
        continue;
        this.mVertexIconRect.left = (f1 - arrayOfInt[0] / 2.0F);
        this.mVertexIconRect.right = (this.mVertexIconRect.left + arrayOfInt[0]);
        this.mVertexIconRect.top = (f2 - arrayOfInt[1] / 2.0F);
        this.mVertexIconRect.bottom = (this.mVertexIconRect.top + arrayOfInt[1]);
      }
    }
    drawVertexImpl(paramCanvas, str, null, this.mVertexTextPaint, f1 - f3 / 2.0F, f2 + f4 / 4.0F);
  }

  private void drawVertexLine(Canvas paramCanvas, double paramDouble1, double paramDouble2)
  {
    if (this.mVertexLineWidth <= 0.0F)
      return;
    float f1 = (float)(this.mPointCenter.x + paramDouble1 * this.mRadius);
    float f2 = (float)(this.mPointCenter.y - paramDouble2 * this.mRadius);
    this.mRadarLinePaint.setColor(this.mVertexLineColor);
    this.mRadarLinePaint.setStrokeWidth(this.mVertexLineWidth);
    paramCanvas.drawLine(this.mPointCenter.x, this.mPointCenter.y, f1, f2, this.mRadarLinePaint);
  }

  private void drawWeb(Canvas paramCanvas)
  {
    int i = this.mLayer;
    if (i >= 1)
    {
      float f1 = this.mRadius / this.mLayer * i;
      this.mRadarPath.reset();
      int j = 1;
      if (j <= this.mMaxVertex)
      {
        double d1 = Math.sin(this.mAngle * j - this.mRotateAngle);
        double d2 = Math.cos(this.mAngle * j - this.mRotateAngle);
        float f3 = (float)(this.mPointCenter.x + d1 * f1);
        float f4 = (float)(this.mPointCenter.y - d2 * f1);
        if (j == 1)
          this.mRadarPath.moveTo(f3, f4);
        while (true)
        {
          j++;
          break;
          this.mRadarPath.lineTo(f3, f4);
        }
      }
      this.mRadarPath.close();
      int k;
      label191: Paint localPaint2;
      float f2;
      if (this.mLayerLineWidth > 0.0F)
      {
        Paint localPaint1 = this.mRadarLinePaint;
        Context localContext = this.mContext;
        if (i != this.mLayer)
          break label249;
        k = R.color.color_db9500;
        localPaint1.setColor(ContextCompat.getColor(localContext, k));
        localPaint2 = this.mRadarLinePaint;
        if (i != this.mLayer)
          break label257;
        f2 = dp2px(2.0F);
      }
      while (true)
      {
        localPaint2.setStrokeWidth(f2);
        paramCanvas.drawPath(this.mRadarPath, this.mRadarLinePaint);
        i--;
        break;
        label249: k = R.color.color_efb70d;
        break label191;
        label257: f2 = this.mLayerLineWidth;
      }
    }
  }

  private void handleRotate(double paramDouble)
  {
    this.mRotateAngle = RotateUtil.getNormalizedAngle(paramDouble);
    invalidate();
  }

  private void init()
  {
    this.mRadarPath = new Path();
    this.mAnimeUtil = new AnimeUtil(this);
    this.mRadarData = new ArrayList();
    this.mLayerColor = new ArrayList();
    initLayerColor();
    this.mRadarLinePaint = new Paint();
    this.mLayerPaint = new Paint();
    this.mValuePaint = new Paint();
    this.mVertexTextPaint = new TextPaint();
    this.mValueTextPaint = new TextPaint();
    this.mCenterTextPaint = new TextPaint();
    this.mRadarLinePaint.setAntiAlias(true);
    this.mLayerPaint.setAntiAlias(true);
    this.mVertexTextPaint.setAntiAlias(true);
    this.mCenterTextPaint.setAntiAlias(true);
    this.mValueTextPaint.setAntiAlias(true);
    this.mValuePaint.setAntiAlias(true);
    this.mValueTextPaint.setFakeBoldText(true);
    this.mVertexIconRect = new RectF();
  }

  private void initAttrs(AttributeSet paramAttributeSet)
  {
    TypedArray localTypedArray = this.mContext.obtainStyledAttributes(paramAttributeSet, R.styleable.RadarView);
    this.mLayer = localTypedArray.getInt(R.styleable.RadarView_radar_layer, 4);
    this.mRotationEnable = localTypedArray.getBoolean(R.styleable.RadarView_rotation_enable, true);
    this.mWebMode = localTypedArray.getInt(R.styleable.RadarView_web_mode, 1);
    this.mMaxValue = localTypedArray.getFloat(R.styleable.RadarView_fitness_max_value, 0.0F);
    this.mLayerLineColor = localTypedArray.getColor(R.styleable.RadarView_layer_line_color, this.mContext.getResources().getColor(R.color.color_db9500));
    this.mLayerLineWidth = localTypedArray.getDimension(R.styleable.RadarView_layer_line_width, dp2px(1.0F));
    this.mVertexLineColor = localTypedArray.getColor(R.styleable.RadarView_vertex_line_color, this.mContext.getResources().getColor(R.color.color_db9500));
    this.mVertexLineWidth = localTypedArray.getDimension(R.styleable.RadarView_vertex_line_width, dp2px(1.0F));
    this.mVertexTextColor = localTypedArray.getColor(R.styleable.RadarView_vertex_text_color, this.mVertexLineColor);
    this.mVertexTextSize = localTypedArray.getDimension(R.styleable.RadarView_vertex_text_size, dp2px(12.0F));
    this.mVertexTextOffset = localTypedArray.getDimension(R.styleable.RadarView_vertex_text_offset, 0.0F);
    this.mCenterTextColor = localTypedArray.getColor(R.styleable.RadarView_center_text_color, this.mVertexLineColor);
    this.mCenterTextSize = localTypedArray.getDimension(R.styleable.RadarView_center_text_size, dp2px(30.0F));
    this.mCenterText = localTypedArray.getString(R.styleable.RadarView_center_text);
    this.mVertexIconSize = localTypedArray.getDimension(R.styleable.RadarView_vertex_icon_size, dp2px(20.0F));
    this.mVertexIconPosition = localTypedArray.getInt(R.styleable.RadarView_vertex_icon_position, 3);
    this.mVertexIconMargin = localTypedArray.getDimension(R.styleable.RadarView_vertex_icon_margin, 0.0F);
    int i = localTypedArray.getResourceId(R.styleable.RadarView_vertex_text, 0);
    localTypedArray.recycle();
    initVertexText(i);
  }

  private void initData(RadarData paramRadarData)
  {
    List localList = paramRadarData.getValue();
    float f = ((Float)Collections.max(localList)).floatValue();
    if ((this.mMaxValue == 0.0F) || (this.mMaxValue < f))
      this.mMaxValue = f;
    int i = localList.size();
    if (this.mMaxVertex < i)
      this.mMaxVertex = i;
    this.mAngle = (6.283185307179586D / this.mMaxVertex);
    initVertexText();
    initMaxValues();
  }

  private void initLayerColor()
  {
    if (this.mLayerColor == null)
      this.mLayerColor = new ArrayList();
    if (this.mLayerColor.size() < this.mLayer)
    {
      int i = this.mLayer - this.mLayerColor.size();
      for (int j = 0; j < i; j++)
        this.mLayerColor.add(Integer.valueOf(0));
    }
  }

  private void initMaxValues()
  {
    if ((this.mMaxValues != null) && (this.mMaxValues.size() < this.mMaxVertex))
    {
      int i = this.mMaxVertex - this.mMaxValues.size();
      for (int j = 0; j < i; j++)
        this.mMaxValues.add(Float.valueOf(0.0F));
    }
  }

  private void initPaint()
  {
    this.mRadarLinePaint.setStyle(Paint.Style.STROKE);
    this.mVertexTextPaint.setColor(this.mContext.getResources().getColor(R.color.color_313131));
    this.mVertexTextPaint.setTextSize(this.mVertexTextSize);
    this.mLayerPaint.setStyle(Paint.Style.FILL);
    this.mCenterTextPaint.setTextSize(this.mCenterTextSize);
    this.mCenterTextPaint.setColor(this.mCenterTextColor);
  }

  private void initVertexText()
  {
    int i;
    if ((this.mVertexText == null) || (this.mVertexText.size() == 0))
    {
      this.mVertexText = new ArrayList();
      i = 0;
    }
    while (i < this.mMaxVertex)
    {
      char c = (char)(i + 65);
      this.mVertexText.add(String.valueOf(c));
      i++;
      continue;
      if (this.mVertexText.size() >= this.mMaxVertex)
        break;
      int j = this.mMaxVertex - this.mVertexText.size();
      for (int k = 0; k < j; k++)
        this.mVertexText.add("");
    }
    if (this.mVertexText.size() == 0)
      return;
    this.mMaxLengthVertexText = ((String)Collections.max(this.mVertexText, new RadarView.1(this)));
  }

  private void initVertexText(int paramInt)
  {
    try
    {
      String[] arrayOfString = this.mContext.getResources().getStringArray(paramInt);
      if (arrayOfString.length > 0)
      {
        this.mVertexText = new ArrayList();
        Collections.addAll(this.mVertexText, arrayOfString);
      }
      return;
    }
    catch (Exception localException)
    {
      Log.e("RadarView", "实例化");
    }
  }

  public void addData(RadarData paramRadarData)
  {
    this.mRadarData.add(paramRadarData);
    initData(paramRadarData);
    animeValue(2000, paramRadarData);
  }

  public void animeValue(int paramInt)
  {
    Iterator localIterator = this.mRadarData.iterator();
    while (localIterator.hasNext())
      animeValue(paramInt, (RadarData)localIterator.next());
  }

  public void animeValue(int paramInt, RadarData paramRadarData)
  {
    if (!this.mAnimeUtil.isPlaying(paramRadarData))
      this.mAnimeUtil.animeValue(AnimeUtil.AnimeType.ZOOM, paramInt, paramRadarData);
  }

  public void clearRadarData()
  {
    this.mRadarData.clear();
    invalidate();
  }

  protected void drawVertexImpl(Canvas paramCanvas, String paramString, Bitmap paramBitmap, Paint paramPaint, float paramFloat1, float paramFloat2)
  {
    if ((paramBitmap == null) || (!TextUtils.isEmpty(paramString)))
    {
      if ((!"柔韧性".equals(paramString)) && (!"下肢".equals(paramString)))
        break label95;
      paramFloat1 -= CompDeviceInfoUtils.convertOfDip(this.mContext, 25.0F);
      if ((!"核心".equals(paramString)) && (!"下肢".equals(paramString)))
        break label163;
      paramFloat2 -= CompDeviceInfoUtils.convertOfDip(this.mContext, 10.0F);
    }
    while (true)
    {
      paramCanvas.drawText(paramString, paramFloat2, paramFloat1, paramPaint);
      return;
      label95: if ("心肺功能".equals(paramString))
      {
        paramFloat1 -= CompDeviceInfoUtils.convertOfDip(this.mContext, 35.0F);
        break;
      }
      if ((!"平衡性".equals(paramString)) && (!"核心".equals(paramString)))
        break;
      paramFloat1 -= CompDeviceInfoUtils.convertOfDip(this.mContext, 15.0F);
      break;
      label163: if ((!"平衡性".equals(paramString)) && (!"柔韧性".equals(paramString)))
        continue;
      paramFloat2 += CompDeviceInfoUtils.convertOfDip(this.mContext, 5.0F);
    }
  }

  public String getCenterText()
  {
    return this.mCenterText;
  }

  public int getCenterTextColor()
  {
    return this.mCenterTextColor;
  }

  public float getCenterTextSize()
  {
    return this.mCenterTextSize;
  }

  public String getEmptyHint()
  {
    return this.mEmptyHint;
  }

  public int getLayer()
  {
    return this.mLayer;
  }

  public List<Integer> getLayerColor()
  {
    return this.mLayerColor;
  }

  public int getLayerLineColor()
  {
    return this.mLayerLineColor;
  }

  public float getLayerLineWidth()
  {
    return this.mLayerLineWidth;
  }

  public float getMaxValue()
  {
    return this.mMaxValue;
  }

  public List<Float> getMaxValues()
  {
    return this.mMaxValues;
  }

  @Deprecated
  public int getRadarLineColor()
  {
    return -1;
  }

  @Deprecated
  public float getRadarLineWidth()
  {
    return -1.0F;
  }

  public List<Bitmap> getVertexIcon()
  {
    return this.mVertexIcon;
  }

  public float getVertexIconMargin()
  {
    return this.mVertexIconMargin;
  }

  public int getVertexIconPosition()
  {
    return this.mVertexIconPosition;
  }

  public float getVertexIconSize()
  {
    return this.mVertexIconSize;
  }

  public int getVertexLineColor()
  {
    return this.mVertexLineColor;
  }

  public float getVertexLineWidth()
  {
    return this.mVertexLineWidth;
  }

  public List<String> getVertexText()
  {
    return this.mVertexText;
  }

  public int getVertexTextColor()
  {
    return this.mVertexTextColor;
  }

  public float getVertexTextOffset()
  {
    return this.mVertexTextOffset;
  }

  public float getVertexTextSize()
  {
    return this.mVertexTextSize;
  }

  public int getWebMode()
  {
    return this.mWebMode;
  }

  @Deprecated
  public boolean isRadarLineEnable()
  {
    return false;
  }

  public boolean isRotationEnable()
  {
    return this.mRotationEnable;
  }

  protected void onDraw(Canvas paramCanvas)
  {
    if (this.mRadarData.size() == 0)
    {
      this.mValueTextPaint.setTextSize(dp2px(16.0F));
      float f = this.mValueTextPaint.measureText(this.mEmptyHint);
      paramCanvas.drawText(this.mEmptyHint, this.mPointCenter.x - f / 2.0F, this.mPointCenter.y, this.mValueTextPaint);
      return;
    }
    initPaint();
    calcRadius();
    drawRadar(paramCanvas);
    drawData(paramCanvas);
    drawCenterText(paramCanvas);
  }

  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    this.mPointCenter = new PointF(paramInt1 / 2, paramInt2 / 2);
  }

  public void removeRadarData(RadarData paramRadarData)
  {
    this.mRadarData.remove(paramRadarData);
    invalidate();
  }

  public void setCenterText(String paramString)
  {
    this.mCenterText = paramString;
    invalidate();
  }

  public void setCenterTextColor(int paramInt)
  {
    this.mCenterTextColor = paramInt;
    invalidate();
  }

  public void setCenterTextSize(float paramFloat)
  {
    this.mCenterTextSize = paramFloat;
    invalidate();
  }

  public void setEmptyHint(String paramString)
  {
    this.mEmptyHint = paramString;
    invalidate();
  }

  public void setLayer(int paramInt)
  {
    this.mLayer = paramInt;
    initLayerColor();
    invalidate();
  }

  public void setLayerColor(List<Integer> paramList)
  {
    this.mLayerColor = paramList;
    initLayerColor();
    invalidate();
  }

  public void setLayerLineColor(int paramInt)
  {
    this.mLayerLineColor = paramInt;
    invalidate();
  }

  public void setLayerLineWidth(float paramFloat)
  {
    this.mLayerLineWidth = paramFloat;
    invalidate();
  }

  public void setMaxValue(float paramFloat)
  {
    this.mMaxValue = paramFloat;
    this.mMaxValues = null;
    invalidate();
  }

  public void setMaxValues(List<Float> paramList)
  {
    this.mMaxValues = paramList;
    initMaxValues();
    invalidate();
  }

  @Deprecated
  public void setRadarLineColor(int paramInt)
  {
  }

  @Deprecated
  public void setRadarLineEnable(boolean paramBoolean)
  {
  }

  @Deprecated
  public void setRadarLineWidth(float paramFloat)
  {
  }

  public void setRotationEnable(boolean paramBoolean)
  {
    this.mRotationEnable = paramBoolean;
  }

  public void setVertexIconBitmap(List<Bitmap> paramList)
  {
    this.mVertexIcon = paramList;
    invalidate();
  }

  public void setVertexIconMargin(float paramFloat)
  {
    this.mVertexIconMargin = paramFloat;
    invalidate();
  }

  public void setVertexIconPosition(int paramInt)
  {
    if ((paramInt != 4) && (paramInt != 5) && (paramInt != 1) && (paramInt != 2) && (paramInt != 3))
      throw new IllegalStateException("only support VERTEX_ICON_POSITION_BOTTOM  VERTEX_ICON_POSITION_CENTER  VERTEX_ICON_POSITION_LEFT  VERTEX_ICON_POSITION_RIGHT  VERTEX_ICON_POSITION_TOP");
    this.mVertexIconPosition = paramInt;
    invalidate();
  }

  public void setVertexIconResid(List<Integer> paramList)
  {
    this.mVertexIcon = new ArrayList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      Integer localInteger = (Integer)localIterator.next();
      this.mVertexIcon.add(BitmapFactory.decodeResource(this.mContext.getResources(), localInteger.intValue()));
    }
    invalidate();
  }

  public void setVertexIconSize(float paramFloat)
  {
    this.mVertexIconSize = paramFloat;
    invalidate();
  }

  public void setVertexLineColor(int paramInt)
  {
    this.mVertexLineColor = paramInt;
    invalidate();
  }

  public void setVertexLineWidth(float paramFloat)
  {
    this.mVertexLineWidth = paramFloat;
    invalidate();
  }

  public void setVertexText(List<String> paramList)
  {
    this.mVertexText = paramList;
    initVertexText();
    invalidate();
  }

  public void setVertexTextColor(int paramInt)
  {
    this.mVertexTextColor = paramInt;
    invalidate();
  }

  public void setVertexTextOffset(float paramFloat)
  {
    this.mVertexTextOffset = paramFloat;
    invalidate();
  }

  public void setVertexTextSize(float paramFloat)
  {
    this.mVertexTextSize = paramFloat;
    invalidate();
  }

  public void setWebMode(int paramInt)
  {
    if ((paramInt != 1) && (paramInt != 2))
      throw new IllegalStateException("only support WEB_MODE_POLYGON or WEB_MODE_CIRCLE");
    this.mWebMode = paramInt;
    invalidate();
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.physical_fitness.radar.RadarView
 * JD-Core Version:    0.6.0
 */