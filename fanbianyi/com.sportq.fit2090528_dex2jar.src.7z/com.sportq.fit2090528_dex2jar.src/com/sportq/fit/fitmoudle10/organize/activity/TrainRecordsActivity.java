package com.sportq.fit.fitmoudle10.organize.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v7.widget.Toolbar.OnMenuItemClickListener;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.HeadModel;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.compdevicemanager.SharePreferenceUtils2;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.DelFitnessPhotoEvent;
import com.sportq.fit.fitmoudle.event.NoPuchEvent;
import com.sportq.fit.fitmoudle.widget.CustomTabLayout;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.NoScrollViewPager;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.menu;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.widget.train_record.TrainRecord_DayFragment;
import com.sportq.fit.fitmoudle10.organize.widget.train_record.TrainRecord_MonthFragment;
import com.sportq.fit.fitmoudle10.organize.widget.train_record.TrainRecord_NoTrainFragment;
import com.sportq.fit.fitmoudle10.organize.widget.train_record.TrainRecord_TotalFragment;
import com.sportq.fit.fitmoudle10.organize.widget.train_record.TrainRecord_WeekFragment;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class TrainRecordsActivity extends BaseActivity
{
  public static final String KEY_MONTH_DATE = "MONTH_DATE";
  public static final String KEY_WEEK_DATE = "WEEK_DATE";
  public TrainRecord_DayFragment dayFragment;
  private String index_month_date;
  private String index_week_date;
  private TrainRecord_MonthFragment monthFragment;
  public RelativeLayout noPushView;
  private TextView noPushViewText;
  private TrainRecord_NoTrainFragment noTrainFragment;
  private Toolbar.OnMenuItemClickListener onMenuItemClick = new TrainRecordsActivity.2(this);
  private ViewPager.OnPageChangeListener pageChangeListener = new TrainRecordsActivity.1(this);
  private CustomTabLayout tabLayout;
  private int tmpPosition;
  private TrainRecord_TotalFragment totalFragment;
  private NoScrollViewPager trans_viewpager;
  private ArrayList<View> viewArrayList;
  private NoScrollViewPager viewPager;
  private TrainRecord_WeekFragment weekFragment;

  public void fitOnClick(View paramView)
  {
    super.fitOnClick(paramView);
    if (paramView.getId() == R.id.mine02_train_record_NoPush)
    {
      startActivity(new Intent(this, Mine03NotPunchAcitvity.class));
      AnimationUtil.pageJumpAnim(this, 0);
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.train_records);
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    this.tabLayout = ((CustomTabLayout)findViewById(R.id.tab_layout));
    this.viewPager = ((NoScrollViewPager)findViewById(R.id.mine02_train_record_viewPager));
    this.trans_viewpager = ((NoScrollViewPager)findViewById(R.id.trans_viewpager));
    this.noPushView = ((RelativeLayout)findViewById(R.id.mine02_train_record_NoPush));
    this.noPushViewText = ((TextView)findViewById(R.id.mine02_train_record_NoPush_text));
    EventBus.getDefault().register(this);
    localCustomToolBar.setTitle(UseStringUtils.getStr(this, R.string.c_82_1));
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    localCustomToolBar.setBackgroundResource(R.color.white);
    setSupportActionBar(localCustomToolBar);
    localCustomToolBar.setOnMenuItemClickListener(this.onMenuItemClick);
    String str1;
    String str2;
    if (getIntent() != null)
    {
      if (StringUtils.isNull(getIntent().getStringExtra("MONTH_DATE")))
      {
        str1 = "";
        this.index_month_date = str1;
        if (!StringUtils.isNull(getIntent().getStringExtra("WEEK_DATE")))
          break label296;
        str2 = "";
        label193: this.index_week_date = str2;
      }
    }
    else
    {
      this.viewPager.addOnPageChangeListener(this.pageChangeListener);
      this.trans_viewpager.setNoScroll(true);
      this.viewPager.setNoScroll(true);
      this.noPushView.setOnClickListener(new FitAction(this));
      this.dialog = new DialogManager();
      initView();
      if (StringUtils.isNull(this.index_month_date))
        break label310;
      this.viewPager.setCurrentItem(2);
      this.trans_viewpager.setCurrentItem(2);
    }
    label296: label310: 
    do
    {
      return;
      str1 = getIntent().getStringExtra("MONTH_DATE");
      break;
      str2 = getIntent().getStringExtra("WEEK_DATE");
      break label193;
    }
    while (StringUtils.isNull(this.index_week_date));
    this.viewPager.setCurrentItem(1);
    this.trans_viewpager.setCurrentItem(1);
  }

  public void initNoTrianRecord()
  {
    this.dayFragment = null;
    this.weekFragment = null;
    this.monthFragment = null;
    this.totalFragment = null;
    this.viewArrayList = new ArrayList();
    for (int i = 0; i < 4; i++)
    {
      this.noTrainFragment = new TrainRecord_NoTrainFragment(this);
      this.viewArrayList.add(this.noTrainFragment);
    }
    this.viewPager.setAdapter(new CustomViewPagerAdapter(this.viewArrayList));
    String[] arrayOfString = new String[4];
    arrayOfString[0] = getString(R.string.c_82_2);
    arrayOfString[1] = getString(R.string.c_82_3);
    arrayOfString[2] = getString(R.string.c_82_4);
    arrayOfString[3] = getString(R.string.c_82_5);
    this.tabLayout.setViewPager(this.viewPager, arrayOfString);
  }

  public void initTrianRecord()
  {
    BaseApplication.dataCache.clear();
    this.dayFragment = new TrainRecord_DayFragment(this);
    this.weekFragment = new TrainRecord_WeekFragment(this, this.index_week_date);
    this.monthFragment = new TrainRecord_MonthFragment(this, this.index_month_date);
    this.totalFragment = new TrainRecord_TotalFragment(this);
    this.viewArrayList = new ArrayList();
    this.viewArrayList.add(this.dayFragment);
    this.viewArrayList.add(this.weekFragment);
    this.viewArrayList.add(this.monthFragment);
    this.viewArrayList.add(this.totalFragment);
    this.viewPager.setAdapter(new CustomViewPagerAdapter(this.viewArrayList));
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(this.dayFragment.getTransView());
    localArrayList.add(this.dayFragment.getTransView());
    localArrayList.add(this.dayFragment.getTransView());
    localArrayList.add(this.dayFragment.getTransView());
    this.trans_viewpager.setAdapter(new CustomViewPagerAdapter(localArrayList));
    String[] arrayOfString = new String[4];
    arrayOfString[0] = getString(R.string.c_82_2);
    arrayOfString[1] = getString(R.string.c_82_3);
    arrayOfString[2] = getString(R.string.c_82_4);
    arrayOfString[3] = getString(R.string.c_82_5);
    this.tabLayout.setViewPager(this.viewPager, arrayOfString);
  }

  public void initView()
  {
    if ((SharePreferenceUtils2.getAllLocalTrainDataPlanReformer() != null) && (SharePreferenceUtils2.getAllLocalTrainDataPlanReformer().size() > 0))
    {
      TextView localTextView = this.noPushViewText;
      int i = R.string.c_85_1;
      String[] arrayOfString = new String[1];
      arrayOfString[0] = String.valueOf(SharePreferenceUtils2.getAllLocalTrainDataPlanReformer().size());
      localTextView.setText(UseStringUtils.getStr(this, i, arrayOfString));
      this.noPushView.setVisibility(0);
    }
    while ((BaseApplication.headModel != null) && (!StringUtils.isNull(BaseApplication.headModel.trainDuration)) && ("0".equals(BaseApplication.headModel.trainDuration)))
    {
      initNoTrianRecord();
      return;
      this.noPushView.setVisibility(8);
    }
    initTrianRecord();
    this.dayFragment.initView();
    this.weekFragment.initView();
    this.monthFragment.initView();
    this.totalFragment.initView();
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(R.menu.train_rec_menu, paramMenu);
    return true;
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(DelFitnessPhotoEvent paramDelFitnessPhotoEvent)
  {
    try
    {
      this.dayFragment.deletePhoto(paramDelFitnessPhotoEvent.hisId);
      this.weekFragment.deletePhoto(paramDelFitnessPhotoEvent.hisId);
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  @Subscribe
  public void onEventMainThread(NoPuchEvent paramNoPuchEvent)
  {
    if (NoPuchEvent.DELETDO.equals(paramNoPuchEvent.state))
      if ((SharePreferenceUtils2.getAllLocalTrainDataPlanReformer() != null) && (SharePreferenceUtils2.getAllLocalTrainDataPlanReformer().size() > 0))
      {
        TextView localTextView2 = this.noPushViewText;
        int j = R.string.c_85_1;
        String[] arrayOfString2 = new String[1];
        arrayOfString2[0] = String.valueOf(SharePreferenceUtils2.getAllLocalTrainDataPlanReformer().size());
        localTextView2.setText(UseStringUtils.getStr(this, j, arrayOfString2));
        this.noPushView.setVisibility(0);
      }
    do
    {
      return;
      this.noPushView.setVisibility(8);
      return;
    }
    while (!NoPuchEvent.SUCCED.equals(paramNoPuchEvent.state));
    if ((SharePreferenceUtils2.getAllLocalTrainDataPlanReformer() != null) && (SharePreferenceUtils2.getAllLocalTrainDataPlanReformer().size() > 0))
    {
      TextView localTextView1 = this.noPushViewText;
      int i = R.string.c_85_1;
      String[] arrayOfString1 = new String[1];
      arrayOfString1[0] = String.valueOf(SharePreferenceUtils2.getAllLocalTrainDataPlanReformer().size());
      localTextView1.setText(UseStringUtils.getStr(this, i, arrayOfString1));
      this.noPushView.setVisibility(0);
    }
    while (true)
    {
      BaseApplication.dataCache.clear();
      if (this.dayFragment == null)
        initTrianRecord();
      if (this.dayFragment == null)
        break;
      this.dayFragment.setRecBaseReformer(null);
      this.weekFragment.setRecBaseReformer(null);
      this.monthFragment.setRecBaseReformer(null);
      this.totalFragment.setRecBaseReformer(null);
      switch (this.viewPager.getCurrentItem())
      {
      default:
        return;
      case 0:
        this.dayFragment.initView();
        return;
        this.noPushView.setVisibility(8);
      case 1:
      case 2:
      case 3:
      }
    }
    this.weekFragment.initView();
    return;
    this.monthFragment.initView();
    return;
    this.totalFragment.initView();
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if (paramString.equals("trainrecord_notrain_starttrain"))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.TrainRecordsActivity
 * JD-Core Version:    0.6.0
 */