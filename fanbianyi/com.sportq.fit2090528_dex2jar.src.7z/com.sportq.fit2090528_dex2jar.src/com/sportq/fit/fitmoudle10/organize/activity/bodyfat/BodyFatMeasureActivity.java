package com.sportq.fit.fitmoudle10.organize.activity.bodyfat;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.kitnew.ble.QNApiManager;
import com.kitnew.ble.QNBleApi;
import com.kitnew.ble.QNBleCallback;
import com.kitnew.ble.QNBleDevice;
import com.kitnew.ble.QNData;
import com.kitnew.ble.QNItemData;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.GetBindScaleModel;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.reformer.GetBindScaleReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.DateUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.TextUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle10.R.anim;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.BodyFatMeasureAdapter;
import com.sportq.fit.fitmoudle10.organize.eventbus.BodyFastEvent;
import com.sportq.fit.fitmoudle10.organize.presenter.FitMoudle10ApiPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.model.NormData;
import com.sportq.fit.fitmoudle10.organize.presenter.model.NormItemModel;
import com.sportq.fit.fitmoudle10.organize.presenter.model.UserDataModel;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.BindScaleReformer;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.UpdateBodyFatReformer;
import com.sportq.fit.fitmoudle10.organize.utils.BodyFastBindStoreUtils;
import com.sportq.fit.fitmoudle10.organize.utils.BodyFatDecimalUtils;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.CommonUtils;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class BodyFatMeasureActivity extends BaseActivity
  implements QNBleCallback
{
  public static final String BODY_FAT_DATA = "data";
  public static final String BODY_FAT_DATE = "date";
  public static final String STR_JUMP_TYPE = "jump.type";
  public static BodyFastEvent bodyFastEvent;
  BodyFatMeasureAdapter adapter;
  private RotateAnimation animation;
  RelativeLayout back_layout;
  private QNBleApi bleApi;
  private LinearLayout bottom_layout;
  private TextView cancel_btn;
  private ArrayList<NormData> dataList;
  private DialogManager dialog;
  private Gson gson;
  private View headerView;
  private ArrayList<NormData> initList;
  private ImageView measureImg;
  TextView measure_date;
  private TextView measure_failed_hint;
  private TextView measure_state;
  private TextView measure_value;
  RecyclerView recyclerView;
  private TextView save_result;
  private String strData;
  private String strDate;
  RelativeLayout unbunding_layout;
  private UserDataModel userDataModel;

  private void checkStartBodyFast()
  {
    if (!"0".equals(getIntent().getStringExtra("jump.type")));
    do
      return;
    while (bodyFastEvent == null);
    BluetoothAdapter localBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    if (localBluetoothAdapter == null)
    {
      ToastUtils.makeToast(this, "该设备不支持蓝牙");
      finish();
      return;
    }
    if (!localBluetoothAdapter.isEnabled())
    {
      ToastUtils.makeToast(this, "蓝牙未启动");
      finish();
      return;
    }
    startConnectBodyFast();
  }

  private void setCurrentValue(String paramString)
  {
    String str1 = CommonUtils.invokeJsMethod("analysisReport.js", "analysisReport", new Object[] { paramString }).toString();
    if (!StringUtils.isNull(str1))
    {
      HashMap localHashMap = (HashMap)this.gson.fromJson(str1, HashMap.class);
      Iterator localIterator = this.initList.iterator();
      while (localIterator.hasNext())
      {
        NormData localNormData1 = (NormData)localIterator.next();
        try
        {
          String str2 = this.gson.toJson(localHashMap.get(BodyFatTools.typeConvetKey(String.valueOf(localNormData1.qnItemData.type))));
          NormData localNormData2 = (NormData)this.gson.fromJson(str2, NormData.class);
          if (localNormData1.qnItemData.type != 14)
          {
            ArrayList localArrayList = localNormData2.progress;
            localNormData1.minValue = Float.valueOf((String)localArrayList.get(0)).floatValue();
            localNormData1.maxValue = Float.valueOf((String)localArrayList.get(-1 + localArrayList.size())).floatValue();
            localArrayList.remove(0);
            localArrayList.remove(-1 + localArrayList.size());
            localNormData1.progress = localArrayList;
            localNormData1.progressComment = localNormData2.progressComment;
            localNormData1.averagePro = BodyFatDecimalUtils.div(1000.0F, 1 + localNormData1.progress.size(), 1);
          }
          localNormData1.comment = localNormData2.comment;
          localNormData1.state = localNormData2.state;
          localNormData1.info = localNormData2.info;
          localNormData1.value = localNormData2.value;
        }
        catch (Exception localException)
        {
          LogUtils.e(localException);
        }
      }
    }
  }

  private void setInitData()
  {
    this.dataList = new ArrayList();
    this.dataList.addAll(this.initList);
    this.dataList.remove(0);
    if (this.adapter == null)
    {
      this.adapter = new BodyFatMeasureAdapter(this, this.dataList, R.layout.bodyfat_result_item_layout);
      this.adapter.addHeaderView(this.headerView);
      this.adapter.setOnItemClickListener(new BodyFatMeasureActivity.3(this));
      this.recyclerView.setAdapter(this.adapter);
    }
    while (true)
    {
      this.save_result.setBackgroundColor(ContextCompat.getColor(this, R.color.color_f7f7f7));
      this.save_result.setTextColor(ContextCompat.getColor(this, R.color.color_c8c8c8));
      this.save_result.setOnClickListener(null);
      return;
      this.adapter.setData(this.dataList);
      this.adapter.notifyItemRangeChanged(1, this.dataList.size());
    }
  }

  private void startConnectBodyFast()
  {
    Date localDate = DateUtils.stringToDate(BaseApplication.userModel.birthday.replaceAll("\\.", "-"));
    if (StringUtils.string2Int(BaseApplication.userModel.userSex) == 0);
    int j;
    for (int i = 1; ; i = 0)
    {
      j = StringUtils.string2Int(BaseApplication.userModel.height);
      this.bleApi.disconnectAll();
      if (bodyFastEvent.device == null)
        break;
      this.bleApi.connectDevice(bodyFastEvent.device, BaseApplication.userModel.userId, j, i, localDate, this);
      return;
    }
    this.bleApi.connectDevice(bodyFastEvent.mac, BaseApplication.userModel.userId, j, i, localDate, this);
  }

  private void stopAnimation()
  {
    if ((this.animation != null) && (this.animation.hasStarted()))
      this.animation.cancel();
  }

  private RotateAnimation viewRotateAnimation()
  {
    RotateAnimation localRotateAnimation = new RotateAnimation(0.0F, 360.0F, 1, 0.5F, 1, 0.5F);
    localRotateAnimation.setDuration(2000L);
    localRotateAnimation.setRepeatCount(-1);
    localRotateAnimation.setInterpolator(new LinearInterpolator());
    return localRotateAnimation;
  }

  private void viewTranslateAnimation()
  {
    if (this.measure_failed_hint != null)
    {
      Animation localAnimation = AnimationUtils.loadAnimation(this, R.anim.roll_up);
      localAnimation.setFillAfter(true);
      this.measure_failed_hint.startAnimation(localAnimation);
      this.measure_failed_hint.setVisibility(0);
      new Handler().postDelayed(new BodyFatMeasureActivity.1(this), 2000L);
    }
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.back_layout)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      if (paramView.getId() == R.id.unbunding_layout)
      {
        startActivity(new Intent(this, BodyFatUnBindActivity.class));
        continue;
      }
      if (paramView.getId() == R.id.save_result)
      {
        this.dialog.createProgressDialog(this, getString(R.string.wait_hint));
        new FitMoudle10ApiPresenter(this).recordBodyFatDate(this, this.userDataModel, this.measure_value.getText().toString());
        continue;
      }
      if (paramView.getId() != R.id.cancel_btn)
        continue;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (this.dialog != null)
      this.dialog.closeDialog();
    if ((paramT instanceof BindScaleReformer))
      new FitMoudle10ApiPresenter(this).getBindScale(this);
    UpdateBodyFatReformer localUpdateBodyFatReformer;
    do
    {
      do
        while (true)
        {
          return;
          if (!(paramT instanceof GetBindScaleReformer))
            break;
          GetBindScaleReformer localGetBindScaleReformer = (GetBindScaleReformer)paramT;
          if ((localGetBindScaleReformer.lstScaleDevice == null) || (localGetBindScaleReformer.lstScaleDevice.size() <= 0))
            continue;
          Iterator localIterator = localGetBindScaleReformer.lstScaleDevice.iterator();
          while (localIterator.hasNext())
          {
            GetBindScaleModel localGetBindScaleModel = (GetBindScaleModel)localIterator.next();
            BodyFastBindStoreUtils.appendCourseData(localGetBindScaleModel.scaleName + "±" + localGetBindScaleModel.scaleDeviceId + "±" + "null", localGetBindScaleModel.scaleName, this);
          }
        }
      while (!(paramT instanceof UpdateBodyFatReformer));
      localUpdateBodyFatReformer = (UpdateBodyFatReformer)paramT;
      if (!localUpdateBodyFatReformer.result.equals("Y"))
        continue;
      BaseApplication.userModel.currentWeight = String.valueOf(BodyFatDecimalUtils.round(((NormData)this.initList.get(0)).qnItemData.value, 1));
      BaseApplication.userModel.currentWeightDate = String.valueOf(System.currentTimeMillis());
      EventBus.getDefault().post("bodyfat.update.success");
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
      return;
    }
    while (StringUtils.isNull(localUpdateBodyFatReformer.message));
    ToastUtils.makeToast(this, localUpdateBodyFatReformer.message);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.bodyfat_measure_layout);
    this.bleApi = QNApiManager.getApi(this);
    EventBus.getDefault().register(this);
    this.dialog = new DialogManager();
    this.gson = new Gson();
    this.animation = viewRotateAnimation();
    this.back_layout = ((RelativeLayout)findViewById(R.id.back_layout));
    this.back_layout.setOnClickListener(new FitAction(this));
    this.unbunding_layout = ((RelativeLayout)findViewById(R.id.unbunding_layout));
    this.unbunding_layout.setOnClickListener(new FitAction(this));
    this.measure_date = ((TextView)findViewById(R.id.measure_date));
    this.bottom_layout = ((LinearLayout)findViewById(R.id.bottom_layout));
    this.save_result = ((TextView)findViewById(R.id.save_result));
    this.cancel_btn = ((TextView)findViewById(R.id.cancel_btn));
    this.cancel_btn.setOnClickListener(new FitAction(this));
    this.recyclerView = ((RecyclerView)findViewById(R.id.recycler_View));
    this.recyclerView.setLayoutManager(new StaggeredGridLayoutManager(3, 1));
    this.recyclerView.addItemDecoration(new BodyDecoration(CompDeviceInfoUtils.convertOfDip(this, 1.5F)));
    this.headerView = View.inflate(this, R.layout.bodyfat_measure_header_view, new RelativeLayout(this));
    this.measureImg = ((ImageView)this.headerView.findViewById(R.id.measure_animation_view));
    this.measure_state = ((TextView)this.headerView.findViewById(R.id.measure_state));
    this.measure_value = ((TextView)this.headerView.findViewById(R.id.measure_value));
    this.measure_failed_hint = ((TextView)this.headerView.findViewById(R.id.measure_failed_hint));
    this.initList = BodyFatTools.getInitList();
    this.measureImg.setImageResource(R.mipmap.measure_empty);
    this.measure_state.setText(getString(R.string.c_77_8_4));
    this.measure_state.setTextColor(ContextCompat.getColor(this, R.color.color_ffd208));
    this.measure_value.setTypeface(TextUtils.getFontFaceImpact());
    this.measure_value.setText("0");
    this.strDate = getIntent().getStringExtra("date");
    this.strData = getIntent().getStringExtra("data");
    if (!StringUtils.isNull(this.strData))
    {
      setCurrentValue(this.strData);
      this.measure_value.setText(BodyFatDecimalUtils.round(((NormData)this.initList.get(0)).value, 1));
      this.measureImg.setImageResource(R.mipmap.measure_success_img);
      this.measure_state.setVisibility(4);
      this.bottom_layout.setVisibility(8);
    }
    this.measure_date.setText(BodyFatTools.getShowDate(this.strDate));
    setInitData();
  }

  public void onCompete(int paramInt)
  {
  }

  public void onConnectStart(QNBleDevice paramQNBleDevice)
  {
  }

  public void onConnected(QNBleDevice paramQNBleDevice)
  {
  }

  protected void onDestroy()
  {
    stopAnimation();
    super.onDestroy();
    bodyFastEvent = null;
    EventBus.getDefault().unregister(this);
    if (this.bleApi != null)
    {
      if (this.bleApi.isScanning())
        this.bleApi.stopScan();
      this.bleApi.disconnectAll();
    }
  }

  public void onDeviceModelUpdate(QNBleDevice paramQNBleDevice)
  {
    LogUtils.d("hdr", "读取到了新的型号：" + paramQNBleDevice.getModel());
  }

  public void onDisconnected(QNBleDevice paramQNBleDevice, int paramInt)
  {
    try
    {
      if (getString(R.string.c_77_9_1).equals(this.measure_state.getText().toString()))
      {
        this.measureImg.setImageResource(R.mipmap.measure_empty);
        this.measure_state.setText(getString(R.string.c_77_8_4));
        this.measure_state.setTextColor(ContextCompat.getColor(this, R.color.color_ffd208));
        this.measure_value.setText("0");
        this.measureImg.setTag(null);
        setInitData();
      }
      if ((bodyFastEvent == null) || (bodyFastEvent.device == null))
        return;
    }
    catch (Exception localException)
    {
      while (true)
        LogUtils.e(localException);
      new Handler().postDelayed(new BodyFatMeasureActivity.2(this), 200L);
    }
  }

  @Subscribe
  public void onEventMainThread(BodyFastEvent paramBodyFastEvent)
  {
    if ((paramBodyFastEvent != null) && (paramBodyFastEvent.isRefresh) && ("1".equals(paramBodyFastEvent.strOperateType)))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return false;
  }

  public void onLowPower()
  {
  }

  public void onReceivedData(QNBleDevice paramQNBleDevice, QNData paramQNData)
  {
    this.measureImg.setTag(null);
    this.measureImg.setImageResource(R.mipmap.measure_success_img);
    this.measure_state.setText(getString(R.string.c_77_10_1));
    stopAnimation();
    this.userDataModel = new UserDataModel();
    this.userDataModel.age = String.valueOf(DateUtils.getUserAge());
    this.userDataModel.height = BaseApplication.userModel.height;
    this.userDataModel.weight = BaseApplication.userModel.currentWeight;
    this.userDataModel.sex = BaseApplication.userModel.userSex;
    this.userDataModel.jsonArr = BodyFatTools.initJsonArrList();
    Iterator localIterator = paramQNData.getAll().iterator();
    label296: 
    while (localIterator.hasNext())
    {
      QNItemData localQNItemData1 = (QNItemData)localIterator.next();
      for (int i = 0; ; i++)
      {
        if (i >= this.initList.size())
          break label296;
        NormData localNormData = (NormData)this.initList.get(i);
        if (localNormData.qnItemData.type != localQNItemData1.type)
          continue;
        QNItemData localQNItemData2 = localNormData.qnItemData;
        float f;
        if (localQNItemData1.type == 2)
          f = BodyFatDecimalUtils.round(localQNItemData1.value, 1);
        while (true)
        {
          localQNItemData2.value = f;
          ((NormItemModel)this.userDataModel.jsonArr.get(i)).type = BodyFatTools.typeConvetKey(String.valueOf(localNormData.qnItemData.type));
          ((NormItemModel)this.userDataModel.jsonArr.get(i)).value = String.valueOf(localNormData.qnItemData.value);
          break;
          f = localQNItemData1.value;
        }
      }
    }
    this.measure_value.setText(String.valueOf(BodyFatDecimalUtils.round(((NormData)this.initList.get(0)).qnItemData.value, 1)));
    if (((NormData)this.initList.get(2)).qnItemData.value <= 0.0F)
      viewTranslateAnimation();
    while (true)
    {
      setCurrentValue(this.gson.toJson(this.userDataModel));
      if (this.adapter != null)
      {
        this.dataList.clear();
        this.dataList.addAll(this.initList);
        this.dataList.remove(0);
        this.adapter.setData(this.dataList);
        this.adapter.notifyItemRangeChanged(1, this.dataList.size());
      }
      return;
      this.save_result.setBackgroundColor(ContextCompat.getColor(this, R.color.color_ffd208));
      this.save_result.setTextColor(ContextCompat.getColor(this, R.color.color_313131));
      this.save_result.setOnClickListener(new FitAction(this));
    }
  }

  public void onReceivedStoreData(QNBleDevice paramQNBleDevice, List<QNData> paramList)
  {
  }

  protected void onResume()
  {
    super.onResume();
    checkStartBodyFast();
  }

  protected void onStop()
  {
    super.onStop();
    if ((this.bleApi != null) && (this.bleApi.isScanning()))
      this.bleApi.stopScan();
  }

  public void onUnsteadyWeight(QNBleDevice paramQNBleDevice, float paramFloat)
  {
    try
    {
      if (this.measureImg.getTag() == null)
      {
        this.measureImg.setTag("start.animation");
        this.measureImg.setImageResource(R.mipmap.measure_animation_img);
        this.measure_state.setText(getString(R.string.c_77_9_1));
        this.measure_state.setTextColor(ContextCompat.getColor(this, R.color.color_828282));
        this.animation.reset();
        this.measureImg.startAnimation(this.animation);
        this.initList = BodyFatTools.getInitList();
        setInitData();
      }
      this.measure_value.setText(String.valueOf(BodyFatDecimalUtils.round(paramFloat, 1)));
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.bodyfat.BodyFatMeasureActivity
 * JD-Core Version:    0.6.0
 */