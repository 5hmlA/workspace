package com.sportq.fit.fitmoudle10.organize.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreAdapter;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper;
import com.sportq.fit.common.utils.loadMoreAdapter.LoadMoreWrapper.OnLoadMoreWarpperListener;
import com.sportq.fit.common.utils.stickrecycleradapter.StickyRecyclerHeadersDecoration;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.compdevicemanager.UseStringUtils;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.event.DelFitnessPhotoEvent;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle.widget.custom.refresh.OnRefreshListener;
import com.sportq.fit.fitmoudle.widget.custom.refresh.SwipeToLoadLayout;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.adapter.TrainRecordListAdapter;
import com.sportq.fit.fitmoudle10.organize.presenter.MinePresenterImpl;
import com.sportq.fit.fitmoudle10.organize.presenter.model.TrainRecordAllEntity.TrainDayTrainBaseEntity;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.TrainRec_BaseReformer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class TrainRecordsAllActivity extends BaseActivity
  implements OnRefreshListener, LoadMoreWrapper.OnLoadMoreWarpperListener
{
  private TrainRecordListAdapter adapter;
  private String down_MoveTime;
  private LoadMoreWrapper loadMoreWrapper;
  private ArrayList<TrainRecordAllEntity.TrainDayTrainBaseEntity> lstMouthChange;
  private MinePresenterImpl minePresenter;
  private String month_MoveTime;
  private RecyclerView recyclerView;
  private SwipeToLoadLayout swipeToLoadLayout;
  private CustomToolBar toolbar;
  private String up_MoveTime;

  private boolean checkDateIsBefore(ArrayList<TrainRecordAllEntity.TrainDayTrainBaseEntity> paramArrayList)
  {
    if (this.lstMouthChange == null)
      return false;
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Date localDate1 = new Date();
    Date localDate2 = new Date();
    Date localDate3 = new Date();
    Object localObject = new Date();
    try
    {
      localDate1 = localSimpleDateFormat.parse(((TrainRecordAllEntity.TrainDayTrainBaseEntity)this.lstMouthChange.get(0)).moveTime);
      localDate2 = localSimpleDateFormat.parse(((TrainRecordAllEntity.TrainDayTrainBaseEntity)this.lstMouthChange.get(-1 + this.lstMouthChange.size())).moveTime);
      localDate3 = localSimpleDateFormat.parse(((TrainRecordAllEntity.TrainDayTrainBaseEntity)paramArrayList.get(0)).moveTime);
      Date localDate4 = localSimpleDateFormat.parse(((TrainRecordAllEntity.TrainDayTrainBaseEntity)paramArrayList.get(-1 + paramArrayList.size())).moveTime);
      localObject = localDate4;
      if (localDate3.before(localDate2))
        return false;
    }
    catch (ParseException localParseException)
    {
      while (true)
        localParseException.printStackTrace();
      if (((Date)localObject).after(localDate1))
        return true;
    }
    return false;
  }

  private void getData(String paramString1, String paramString2)
  {
    if (this.minePresenter == null)
      this.minePresenter = new MinePresenterImpl(this);
    if (!StringUtils.isNull(this.month_MoveTime))
    {
      Log.d("TrainRec.getData.Month", "month_MoveTime: " + this.month_MoveTime);
      RequestModel localRequestModel2 = new RequestModel();
      localRequestModel2.moveTime = this.month_MoveTime;
      this.minePresenter.getMonthTrainRecord(this, localRequestModel2);
      this.month_MoveTime = null;
      return;
    }
    Log.d("TrainRec.getData.All", "upOrDownFresh: " + paramString1 + "||month_MoveTime: " + paramString2);
    RequestModel localRequestModel1 = new RequestModel();
    localRequestModel1.pageFlag = paramString1;
    localRequestModel1.moveTime = paramString2;
    this.minePresenter.getTrainRecord(this, localRequestModel1);
  }

  private void stopRefresh()
  {
    if ((this.swipeToLoadLayout != null) && (this.swipeToLoadLayout.isRefreshing()))
      this.swipeToLoadLayout.setRefreshing(false);
  }

  public void fitOnClick(View paramView)
  {
    super.fitOnClick(paramView);
  }

  public <T> void getDataFail(T paramT)
  {
    stopRefresh();
    super.getDataFail(paramT);
  }

  public <T> void getDataSuccess(T paramT)
  {
    stopRefresh();
    super.getDataSuccess(paramT);
    TrainRec_BaseReformer localTrainRec_BaseReformer;
    if ((paramT instanceof TrainRec_BaseReformer))
    {
      localTrainRec_BaseReformer = (TrainRec_BaseReformer)paramT;
      if (this.lstMouthChange != null)
        break label183;
      this.lstMouthChange = localTrainRec_BaseReformer.trainList;
      this.adapter = new TrainRecordListAdapter(this.lstMouthChange, this);
      this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
      this.recyclerView.setAdapter(this.adapter);
      if (this.loadMoreWrapper == null)
        this.recyclerView.addItemDecoration(new StickyRecyclerHeadersDecoration(this.adapter));
      this.loadMoreWrapper = new LoadMoreWrapper(new LoadMoreAdapter(this.adapter), this);
      this.loadMoreWrapper.into(this.recyclerView);
    }
    while (true)
    {
      this.up_MoveTime = ((TrainRecordAllEntity.TrainDayTrainBaseEntity)this.lstMouthChange.get(-1 + this.lstMouthChange.size())).moveTime;
      this.down_MoveTime = ((TrainRecordAllEntity.TrainDayTrainBaseEntity)this.lstMouthChange.get(0)).moveTime;
      return;
      label183: if (localTrainRec_BaseReformer.trainList.size() > 0)
      {
        if (checkDateIsBefore(localTrainRec_BaseReformer.trainList))
        {
          this.lstMouthChange.addAll(0, localTrainRec_BaseReformer.trainList);
          this.adapter.setList(this.lstMouthChange);
          this.adapter.notifyDataSetChanged();
          continue;
        }
        this.lstMouthChange.addAll(localTrainRec_BaseReformer.trainList);
        this.adapter.setList(this.lstMouthChange);
        this.adapter.notifyDataSetChanged();
        continue;
      }
      this.loadMoreWrapper.setLoadMoreEnabled(false);
      this.adapter.notifyDataSetChanged();
    }
  }

  public void initLayout(Bundle paramBundle)
  {
    if (getIntent() != null)
      this.month_MoveTime = getIntent().getStringExtra("view_all_train_monthtime");
    int i;
    if (this.month_MoveTime != null)
    {
      i = R.layout.train_records_all;
      setContentView(i);
      this.toolbar = ((CustomToolBar)findViewById(R.id.toolbar));
      this.recyclerView = ((RecyclerView)findViewById(R.id.swipe_target));
      this.swipeToLoadLayout = ((SwipeToLoadLayout)findViewById(R.id.swipeToLoadLayout));
      EventBus.getDefault().register(this);
      this.toolbar.setTitle(UseStringUtils.getStr(this, R.string.c_12_1));
      this.toolbar.setNavIcon(R.mipmap.btn_back_black);
      this.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
      this.toolbar.setBackgroundResource(R.color.white);
      setSupportActionBar(this.toolbar);
      if (this.month_MoveTime == null)
        break label191;
      this.swipeToLoadLayout.setOnRefreshListener(this);
      this.swipeToLoadLayout.post(new TrainRecordsAllActivity.1(this));
    }
    while (true)
    {
      this.dialog = new DialogManager();
      return;
      i = R.layout.train_records_all1;
      break;
      label191: onRefresh();
    }
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(DelFitnessPhotoEvent paramDelFitnessPhotoEvent)
  {
    for (int i = 0; ; i++)
    {
      if (i < this.lstMouthChange.size())
      {
        if (!paramDelFitnessPhotoEvent.hisId.equals(((TrainRecordAllEntity.TrainDayTrainBaseEntity)this.lstMouthChange.get(i)).historyId))
          continue;
        ((TrainRecordAllEntity.TrainDayTrainBaseEntity)this.lstMouthChange.get(i)).flg = "0";
      }
      this.adapter.setList(this.lstMouthChange);
      this.adapter.notifyDataSetChanged();
      return;
    }
  }

  public void onLoadMore()
  {
    if (((this.swipeToLoadLayout != null) && (this.swipeToLoadLayout.isRefreshing())) || (this.recyclerView == null))
      return;
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      ToastUtils.makeToast(this, getString(R.string.current_network_again_later));
      return;
    }
    getData("1", this.up_MoveTime);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    switch (paramMenuItem.getItemId())
    {
    default:
    case 16908332:
    }
    while (true)
    {
      boolean bool = super.onOptionsItemSelected(paramMenuItem);
      VdsAgent.handleClickResult(new Boolean(bool));
      return bool;
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  protected void onPause()
  {
    super.onPause();
    stopRefresh();
  }

  public void onRefresh()
  {
    if (!CompDeviceInfoUtils.checkNetwork())
    {
      ToastUtils.makeToast(this, getString(R.string.current_network_again_later));
      stopRefresh();
      return;
    }
    if (!StringUtils.isNull(this.down_MoveTime));
    for (String str = "0"; ; str = "")
    {
      getData(str, this.down_MoveTime);
      return;
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.TrainRecordsAllActivity
 * JD-Core Version:    0.6.0
 */