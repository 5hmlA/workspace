package com.sportq.fit.fitmoudle10.organize.physical_fitness;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.QuestionnaireReformer;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.GlideUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.common.version.VersionUpdateCheck;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.adapter.CustomViewPagerAdapter;
import com.sportq.fit.fitmoudle.fitjump.FitJumpImpl;
import com.sportq.fit.fitmoudle.fitjump.FitJumpInterface;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.drawable;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.presenter.FitMoudle10ApiPresenter;
import com.sportq.fit.fitmoudle10.organize.presenter.model.PhyRecommModel;
import com.sportq.fit.fitmoudle10.organize.presenter.refermer.PhyRecommReformer;
import com.sportq.fit.middlelib.statistics.FitAction;
import java.util.ArrayList;
import java.util.Iterator;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class FitnessRecommTrainPlanActivity extends BaseActivity
{
  private TextView diff_text;
  private TextView fat_text;
  private TextView jump_btn;
  private LinearLayout page_index_layout;
  private PhyRecommReformer phyRecommReformer;
  private TextView recomm_desc;
  private TextView recomm_explain;
  private TextView recomm_title;
  private String strLevelCode;
  private TextView time_text;
  private ViewPager view_pager;

  private void setCurPageInfo(PhyRecommModel paramPhyRecommModel)
  {
    this.recomm_title.setText(paramPhyRecommModel.name);
    TextView localTextView = this.jump_btn;
    int i;
    if ("1".equals(paramPhyRecommModel.code))
    {
      i = R.string.c_82_2_3;
      localTextView.setText(i);
      this.recomm_title.setTag(paramPhyRecommModel.code);
      if (StringUtils.isNull(paramPhyRecommModel.intr))
        break label175;
      this.recomm_desc.setVisibility(0);
      this.recomm_desc.setText(paramPhyRecommModel.intr);
    }
    while (true)
    {
      this.fat_text.setText(BaseApplication.quReformer.getCustomizedTargetName(paramPhyRecommModel.fitGoal));
      this.diff_text.setText(StringUtils.difficultyLevel(paramPhyRecommModel.fitBase));
      this.time_text.setText(paramPhyRecommModel.fitDays);
      if (StringUtils.isNull(paramPhyRecommModel.comment))
        break label187;
      this.recomm_explain.setVisibility(0);
      this.recomm_explain.setText(paramPhyRecommModel.comment);
      return;
      if ("2".equals(paramPhyRecommModel.code))
      {
        i = R.string.c_82_3_4;
        break;
      }
      i = R.string.c_82_1_9;
      break;
      label175: this.recomm_desc.setVisibility(8);
    }
    label187: this.recomm_explain.setVisibility(8);
  }

  public void fitOnClick(View paramView)
  {
    int i;
    if (paramView.getId() == R.id.jump_btn)
    {
      if (this.recomm_title.getTag() == null)
        return;
      i = Integer.valueOf(String.valueOf(this.recomm_title.getTag())).intValue();
      if (i != 1)
        break label57;
      EventBus.getDefault().post("fitness.custom");
    }
    while (true)
    {
      super.fitOnClick(paramView);
      return;
      label57: if (i == 2)
      {
        FitJumpImpl.getInstance().JumpTrainCategoryActivity(this, "STR_LEVEL_CODE±" + this.strLevelCode, "能量课程推荐");
        continue;
      }
      if (i != 3)
        continue;
      FitJumpImpl.getInstance().settingJumpWebView(this, "", VersionUpdateCheck.WEB_ADDRESS + "h5/2017Fat/1?pageSource=8");
    }
  }

  public <T> void getDataFail(T paramT)
  {
  }

  public <T> void getDataSuccess(T paramT)
  {
    if (paramT == null);
    do
    {
      do
        return;
      while (!(paramT instanceof PhyRecommReformer));
      this.phyRecommReformer = ((PhyRecommReformer)paramT);
    }
    while ((this.phyRecommReformer.lstPhyRec == null) || (this.phyRecommReformer.lstPhyRec.size() == 0));
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.phyRecommReformer.lstPhyRec.iterator();
    if (localIterator.hasNext())
    {
      PhyRecommModel localPhyRecommModel = (PhyRecommModel)localIterator.next();
      View localView1 = LayoutInflater.from(this).inflate(R.layout.fitness_recomm_viewpager_item, null);
      ImageView localImageView = (ImageView)localView1.findViewById(R.id.recomm_img);
      localImageView.getLayoutParams().width = (int)(0.875D * BaseApplication.screenWidth);
      localImageView.getLayoutParams().height = (int)(0.61111D * BaseApplication.screenWidth);
      GlideUtils.loadImgByDefault(localPhyRecommModel.imageUrl, localImageView);
      localArrayList.add(localView1);
      if (this.phyRecommReformer.lstPhyRec.indexOf(localPhyRecommModel) == 0)
        setCurPageInfo(localPhyRecommModel);
      View localView2 = new View(this);
      if (this.phyRecommReformer.lstPhyRec.indexOf(localPhyRecommModel) == 0)
        localView2.setBackgroundResource(R.drawable.selector_radius);
      while (true)
      {
        this.page_index_layout.addView(localView2);
        localView2.getLayoutParams().width = CompDeviceInfoUtils.convertOfDip(this, 7.0F);
        if (this.phyRecommReformer.lstPhyRec.indexOf(localPhyRecommModel) != 0)
          ((LinearLayout.LayoutParams)localView2.getLayoutParams()).leftMargin = CompDeviceInfoUtils.convertOfDip(this, 15.0F);
        localView2.getLayoutParams().height = CompDeviceInfoUtils.convertOfDip(this, 7.0F);
        break;
        localView2.setBackgroundResource(R.drawable.radius);
      }
    }
    this.view_pager.getLayoutParams().height = (int)(0.61111D * BaseApplication.screenWidth);
    this.view_pager.setPadding((int)(0.041666D * BaseApplication.screenWidth), 0, (int)(0.041666D * BaseApplication.screenWidth), 0);
    this.view_pager.setAdapter(new CustomViewPagerAdapter(localArrayList));
    this.view_pager.addOnPageChangeListener(new FitnessRecommTrainPlanActivity.RecomPageViewChangeListener(this, null));
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.fitness_recomm_train_plan);
    EventBus.getDefault().register(this);
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setTitle(R.string.c_82_1_1);
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    localCustomToolBar.setBackgroundResource(R.color.white);
    setSupportActionBar(localCustomToolBar);
    this.view_pager = ((ViewPager)findViewById(R.id.view_pager));
    this.page_index_layout = ((LinearLayout)findViewById(R.id.page_index_layout));
    this.recomm_title = ((TextView)findViewById(R.id.recomm_title));
    this.recomm_desc = ((TextView)findViewById(R.id.recomm_desc));
    this.fat_text = ((TextView)findViewById(R.id.fat_text));
    this.diff_text = ((TextView)findViewById(R.id.diff_text));
    this.time_text = ((TextView)findViewById(R.id.time_text));
    this.recomm_explain = ((TextView)findViewById(R.id.recomm_explain));
    this.jump_btn = ((TextView)findViewById(R.id.jump_btn));
    this.jump_btn.setOnClickListener(new FitAction(this));
    FitMoudle10ApiPresenter localFitMoudle10ApiPresenter = new FitMoudle10ApiPresenter(this);
    this.strLevelCode = getIntent().getStringExtra("level.code");
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.levelCode = this.strLevelCode;
    localFitMoudle10ApiPresenter.getPhyRecommend(this, localRequestModel);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("phy.close.other.page".equals(paramString))
      finish();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.physical_fitness.FitnessRecommTrainPlanActivity
 * JD-Core Version:    0.6.0
 */