package com.sportq.fit.fitmoudle10.organize.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.common.BaseApplication;
import com.sportq.fit.common.model.UserModel;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.StringUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle10.R.color;
import com.sportq.fit.fitmoudle10.R.id;
import com.sportq.fit.fitmoudle10.R.layout;
import com.sportq.fit.fitmoudle10.R.mipmap;
import com.sportq.fit.fitmoudle10.R.string;
import com.sportq.fit.fitmoudle10.organize.eventbus.UpdateHealthDataFinishEvent;
import com.sportq.fit.fitmoudle10.organize.widget.DecimalScaleRulerView;
import com.sportq.fit.middlelib.statistics.FitAction;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class PerfectInfoSecondActivity extends BaseActivity
{
  public static final String USER_CURRENT_WEIGHT = "user.current.weight";
  public static final String USER_HEIGHT_KEY = "user.height";
  public static final String USER_TARGET_WEIGHT = "user.target.weight";
  private String userHeight;
  private TextView weight_value;
  private TextView weight_value01;

  private void initControl()
  {
    this.userHeight = getIntent().getStringExtra("user.height");
    CustomToolBar localCustomToolBar = (CustomToolBar)findViewById(R.id.toolbar);
    localCustomToolBar.setTitle(R.string.c_75_2_1);
    localCustomToolBar.setNavIcon(R.mipmap.btn_back_black);
    localCustomToolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.color_313131));
    localCustomToolBar.setBackgroundResource(R.color.white);
    setSupportActionBar(localCustomToolBar);
    ((TextView)findViewById(R.id.next_btn)).setOnClickListener(new FitAction(this));
    this.weight_value = ((TextView)findViewById(R.id.weight_value));
    DecimalScaleRulerView localDecimalScaleRulerView1 = (DecimalScaleRulerView)findViewById(R.id.weight_scale_view01);
    float f1;
    float f2;
    if ((BaseApplication.userModel != null) && (!StringUtils.isNull(BaseApplication.userModel.initialWeight)))
    {
      this.weight_value.setText(BaseApplication.userModel.initialWeight);
      f1 = Float.valueOf(BaseApplication.userModel.initialWeight).floatValue();
      localDecimalScaleRulerView1.setParam(CompDeviceInfoUtils.convertOfDip(this, 14.0F), CompDeviceInfoUtils.convertOfDip(this, 24.0F), CompDeviceInfoUtils.convertOfDip(this, 19.0F), CompDeviceInfoUtils.convertOfDip(this, 12.0F), CompDeviceInfoUtils.convertOfDip(this, 9.0F), CompDeviceInfoUtils.convertOfDip(this, 15.0F));
      localDecimalScaleRulerView1.initViewParam(f1, 30.0F, 150.0F, 1);
      localDecimalScaleRulerView1.setValueChangeListener(new PerfectInfoSecondActivity.1(this));
      this.weight_value01 = ((TextView)findViewById(R.id.weight_value01));
      DecimalScaleRulerView localDecimalScaleRulerView2 = (DecimalScaleRulerView)findViewById(R.id.weight_scale_view02);
      if ((BaseApplication.userModel != null) && (!StringUtils.isNull(BaseApplication.userModel.targetWeight)))
      {
        this.weight_value01.setText(BaseApplication.userModel.targetWeight);
        f2 = Float.valueOf(BaseApplication.userModel.targetWeight).floatValue();
        localDecimalScaleRulerView2.setParam(CompDeviceInfoUtils.convertOfDip(this, 14.0F), CompDeviceInfoUtils.convertOfDip(this, 24.0F), CompDeviceInfoUtils.convertOfDip(this, 19.0F), CompDeviceInfoUtils.convertOfDip(this, 12.0F), CompDeviceInfoUtils.convertOfDip(this, 9.0F), CompDeviceInfoUtils.convertOfDip(this, 15.0F));
        localDecimalScaleRulerView2.initViewParam(f2, 30.0F, 150.0F, 1);
        localDecimalScaleRulerView2.setValueChangeListener(new PerfectInfoSecondActivity.2(this));
        return;
      }
    }
    else
    {
      if ("0".equals(BaseApplication.userModel.userSex))
        f1 = 70.0F;
      while (true)
      {
        this.weight_value.setText(String.valueOf(f1));
        break;
        f1 = 50.0F;
      }
    }
    if ("0".equals(BaseApplication.userModel.userSex))
      f2 = 70.0F;
    while (true)
    {
      this.weight_value01.setText(String.valueOf(f2));
      break;
      f2 = 50.0F;
    }
  }

  public void fitOnClick(View paramView)
  {
    if (paramView.getId() == R.id.next_btn)
    {
      UpdateHealthDataFinishEvent localUpdateHealthDataFinishEvent = new UpdateHealthDataFinishEvent();
      localUpdateHealthDataFinishEvent.strCloseHealthDataPageTag = "close";
      EventBus.getDefault().post(localUpdateHealthDataFinishEvent);
      Intent localIntent = new Intent(this, Mine02HealthData2Activity.class);
      localIntent.putExtra("user.height", this.userHeight);
      localIntent.putExtra("user.current.weight", this.weight_value.getText().toString());
      localIntent.putExtra("user.target.weight", this.weight_value01.getText().toString());
      startActivity(localIntent);
      AnimationUtil.pageJumpAnim(this, 0);
    }
    super.fitOnClick(paramView);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.perfect_info_second);
    EventBus.getDefault().register(this);
    initControl();
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    finish();
    AnimationUtil.pageJumpAnim(this, 1);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(UpdateHealthDataFinishEvent paramUpdateHealthDataFinishEvent)
  {
    if ((paramUpdateHealthDataFinishEvent == null) || (StringUtils.isNull(paramUpdateHealthDataFinishEvent.strCloseHealthDataPageTag)))
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      AnimationUtil.pageJumpAnim(this, 1);
    }
    boolean bool = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool));
    return bool;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle10.organize.activity.PerfectInfoSecondActivity
 * JD-Core Version:    0.6.0
 */