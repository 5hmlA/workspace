package com.sportq.fit.fitmoudle11.video.widget.squareprogressbar;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.fitmoudle11.video.R.color;
import com.sportq.fit.fitmoudle11.video.utils.CalculationUtil;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class SquareProgressView extends View
{
  public static final String EVENT_START = "SquareProgressView.start.event";
  public static final String EVENT_STOP = "SquareProgressView.stop.event";
  private Canvas canvas;
  private boolean centerline = false;
  private boolean clearOnHundred = false;
  private int indeterminate_count = 1;
  private float indeterminate_width = 20.0F;
  private boolean isIndeterminate = false;
  private SquareProgressView.OnProgressChangeListener onProgressChangeListener;
  private boolean outline = false;
  private Paint outlinePaint;
  private double progress;
  private Paint progressBarPaint;
  private Runnable progressTaskRunnable = new SquareProgressView.1(this);
  private boolean showProgress = false;
  private boolean startline = false;
  private float strokewidth = 0.0F;
  private Paint textPaint;
  private long timeMillis = 5000L;
  private float widthInDp = 2.0F;

  public SquareProgressView(Context paramContext)
  {
    super(paramContext);
    initializePaints(paramContext);
  }

  public SquareProgressView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    initializePaints(paramContext);
  }

  public SquareProgressView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    initializePaints(paramContext);
  }

  private void drawCenterline(float paramFloat)
  {
    float f = paramFloat / 2.0F;
    Path localPath = new Path();
    localPath.moveTo(f, f);
    localPath.lineTo(this.canvas.getWidth() - f, f);
    localPath.lineTo(this.canvas.getWidth() - f, this.canvas.getHeight() - f);
    localPath.lineTo(f, this.canvas.getHeight() - f);
    localPath.lineTo(f, f);
    this.canvas.drawPath(localPath, this.outlinePaint);
  }

  private void drawOutline()
  {
    Path localPath = new Path();
    localPath.moveTo(0.0F, 0.0F);
    localPath.lineTo(this.canvas.getWidth(), 0.0F);
    localPath.lineTo(this.canvas.getWidth(), this.canvas.getHeight());
    localPath.lineTo(0.0F, this.canvas.getHeight());
    localPath.lineTo(0.0F, 0.0F);
    this.canvas.drawPath(localPath, this.outlinePaint);
  }

  private void drawStartline()
  {
    Path localPath = new Path();
    localPath.moveTo(this.canvas.getWidth() / 2, 0.0F);
    localPath.lineTo(this.canvas.getWidth() / 2, this.strokewidth);
    this.canvas.drawPath(localPath, this.outlinePaint);
  }

  private void initializePaints(Context paramContext)
  {
    this.progressBarPaint = new Paint();
    this.progressBarPaint.setColor(paramContext.getResources().getColor(R.color.color_ffd208));
    this.progressBarPaint.setStrokeWidth(CalculationUtil.convertDpToPx(this.widthInDp, getContext()));
    this.progressBarPaint.setAntiAlias(true);
    this.progressBarPaint.setStyle(Paint.Style.STROKE);
    this.outlinePaint = new Paint();
    this.outlinePaint.setColor(paramContext.getResources().getColor(17170444));
    this.outlinePaint.setStrokeWidth(1.0F);
    this.outlinePaint.setAntiAlias(true);
    this.outlinePaint.setStyle(Paint.Style.STROKE);
    this.textPaint = new Paint();
    this.textPaint.setColor(paramContext.getResources().getColor(17170444));
    this.textPaint.setAntiAlias(true);
    this.textPaint.setStyle(Paint.Style.STROKE);
  }

  private double validateProgress(double paramDouble)
  {
    if (paramDouble > 100.0D)
      paramDouble = 100.0D;
    do
      return paramDouble;
    while (paramDouble >= 0.0D);
    return 0.0D;
  }

  public SquareProgressView.DrawStop getDrawEnd(float paramFloat, Canvas paramCanvas)
  {
    SquareProgressView.DrawStop localDrawStop = new SquareProgressView.DrawStop(this);
    this.strokewidth = CalculationUtil.convertDpToPx(this.widthInDp, getContext());
    float f1 = paramCanvas.getWidth();
    if (paramFloat > f1)
    {
      float f2 = paramFloat - f1;
      if (f2 > paramCanvas.getHeight())
      {
        float f3 = f2 - paramCanvas.getHeight();
        if (f3 > paramCanvas.getWidth())
        {
          float f4 = f3 - paramCanvas.getWidth();
          if (f4 > paramCanvas.getHeight())
          {
            float f5 = f4 - paramCanvas.getHeight();
            if (f5 == f1)
            {
              SquareProgressView.DrawStop.access$002(localDrawStop, SquareProgressView.Place.TOP);
              SquareProgressView.DrawStop.access$102(localDrawStop, f1);
              return localDrawStop;
            }
            SquareProgressView.DrawStop.access$002(localDrawStop, SquareProgressView.Place.TOP);
            SquareProgressView.DrawStop.access$102(localDrawStop, f5 + this.strokewidth);
            return localDrawStop;
          }
          SquareProgressView.DrawStop.access$002(localDrawStop, SquareProgressView.Place.LEFT);
          SquareProgressView.DrawStop.access$102(localDrawStop, paramCanvas.getHeight() - f4);
          return localDrawStop;
        }
        SquareProgressView.DrawStop.access$002(localDrawStop, SquareProgressView.Place.BOTTOM);
        SquareProgressView.DrawStop.access$102(localDrawStop, paramCanvas.getWidth() - f3);
        return localDrawStop;
      }
      SquareProgressView.DrawStop.access$002(localDrawStop, SquareProgressView.Place.RIGHT);
      SquareProgressView.DrawStop.access$102(localDrawStop, f2 + this.strokewidth);
      return localDrawStop;
    }
    SquareProgressView.DrawStop.access$002(localDrawStop, SquareProgressView.Place.TOP);
    SquareProgressView.DrawStop.access$102(localDrawStop, paramFloat);
    return localDrawStop;
  }

  public double getProgress()
  {
    return this.progress;
  }

  public boolean isCenterline()
  {
    return this.centerline;
  }

  public boolean isClearOnHundred()
  {
    return this.clearOnHundred;
  }

  public boolean isIndeterminate()
  {
    return this.isIndeterminate;
  }

  public boolean isOutline()
  {
    return this.outline;
  }

  public boolean isShowProgress()
  {
    return this.showProgress;
  }

  public boolean isStartline()
  {
    return this.startline;
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    EventBus.getDefault().register(this);
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    EventBus.getDefault().unregister(this);
  }

  protected void onDraw(Canvas paramCanvas)
  {
    this.canvas = paramCanvas;
    super.onDraw(paramCanvas);
    this.strokewidth = CalculationUtil.convertDpToPx(this.widthInDp, getContext());
    float f = paramCanvas.getWidth() + paramCanvas.getHeight() + paramCanvas.getHeight() + paramCanvas.getWidth() - this.strokewidth;
    if (isOutline())
      drawOutline();
    if (isStartline())
      drawStartline();
    if (isCenterline())
      drawCenterline(this.strokewidth);
    if (((isClearOnHundred()) && (this.progress == 100.0D)) || (this.progress <= 0.0D));
    Path localPath2;
    SquareProgressView.DrawStop localDrawStop2;
    do
    {
      return;
      if (isIndeterminate())
      {
        Path localPath1 = new Path();
        SquareProgressView.DrawStop localDrawStop1 = getDrawEnd(f / 100.0F * Float.valueOf(String.valueOf(this.indeterminate_count)).floatValue(), paramCanvas);
        if (SquareProgressView.DrawStop.access$000(localDrawStop1) == SquareProgressView.Place.TOP)
        {
          localPath1.moveTo(SquareProgressView.DrawStop.access$100(localDrawStop1) - this.indeterminate_width - this.strokewidth, this.strokewidth / 2.0F);
          localPath1.lineTo(SquareProgressView.DrawStop.access$100(localDrawStop1), this.strokewidth / 2.0F);
          paramCanvas.drawPath(localPath1, this.progressBarPaint);
        }
        if (SquareProgressView.DrawStop.access$000(localDrawStop1) == SquareProgressView.Place.RIGHT)
        {
          localPath1.moveTo(paramCanvas.getWidth() - this.strokewidth / 2.0F, SquareProgressView.DrawStop.access$100(localDrawStop1) - this.indeterminate_width);
          localPath1.lineTo(paramCanvas.getWidth() - this.strokewidth / 2.0F, this.strokewidth + SquareProgressView.DrawStop.access$100(localDrawStop1));
          paramCanvas.drawPath(localPath1, this.progressBarPaint);
        }
        if (SquareProgressView.DrawStop.access$000(localDrawStop1) == SquareProgressView.Place.BOTTOM)
        {
          localPath1.moveTo(SquareProgressView.DrawStop.access$100(localDrawStop1) - this.indeterminate_width - this.strokewidth, paramCanvas.getHeight() - this.strokewidth / 2.0F);
          localPath1.lineTo(SquareProgressView.DrawStop.access$100(localDrawStop1), paramCanvas.getHeight() - this.strokewidth / 2.0F);
          paramCanvas.drawPath(localPath1, this.progressBarPaint);
        }
        if (SquareProgressView.DrawStop.access$000(localDrawStop1) == SquareProgressView.Place.LEFT)
        {
          localPath1.moveTo(this.strokewidth / 2.0F, SquareProgressView.DrawStop.access$100(localDrawStop1) - this.indeterminate_width - this.strokewidth);
          localPath1.lineTo(this.strokewidth / 2.0F, SquareProgressView.DrawStop.access$100(localDrawStop1));
          paramCanvas.drawPath(localPath1, this.progressBarPaint);
        }
        this.indeterminate_count = (1 + this.indeterminate_count);
        if (this.indeterminate_count > 100)
          this.indeterminate_count = 0;
        invalidate();
        return;
      }
      localPath2 = new Path();
      localDrawStop2 = getDrawEnd(f / 100.0F * Float.valueOf(String.valueOf(this.progress)).floatValue(), paramCanvas);
      LogUtils.d("SquareProgressView->onDraw->location:", "" + SquareProgressView.DrawStop.access$100(localDrawStop2));
      if (SquareProgressView.DrawStop.access$000(localDrawStop2) == SquareProgressView.Place.TOP)
      {
        localPath2.moveTo(0.0F, this.strokewidth / 2.0F);
        localPath2.lineTo(SquareProgressView.DrawStop.access$100(localDrawStop2), this.strokewidth / 2.0F);
        paramCanvas.drawPath(localPath2, this.progressBarPaint);
      }
      if (SquareProgressView.DrawStop.access$000(localDrawStop2) == SquareProgressView.Place.RIGHT)
      {
        localPath2.moveTo(0.0F, this.strokewidth / 2.0F);
        localPath2.lineTo(paramCanvas.getWidth() - this.strokewidth / 2.0F, this.strokewidth / 2.0F);
        localPath2.lineTo(paramCanvas.getWidth() - this.strokewidth / 2.0F, this.strokewidth / 2.0F + SquareProgressView.DrawStop.access$100(localDrawStop2));
        paramCanvas.drawPath(localPath2, this.progressBarPaint);
      }
      if (SquareProgressView.DrawStop.access$000(localDrawStop2) != SquareProgressView.Place.BOTTOM)
        continue;
      localPath2.moveTo(0.0F, this.strokewidth / 2.0F);
      localPath2.lineTo(paramCanvas.getWidth() - this.strokewidth / 2.0F, this.strokewidth / 2.0F);
      localPath2.lineTo(paramCanvas.getWidth() - this.strokewidth / 2.0F, paramCanvas.getHeight());
      localPath2.moveTo(paramCanvas.getWidth(), paramCanvas.getHeight() - this.strokewidth / 2.0F);
      localPath2.lineTo(SquareProgressView.DrawStop.access$100(localDrawStop2), paramCanvas.getHeight() - this.strokewidth / 2.0F);
      paramCanvas.drawPath(localPath2, this.progressBarPaint);
    }
    while (SquareProgressView.DrawStop.access$000(localDrawStop2) != SquareProgressView.Place.LEFT);
    localPath2.moveTo(0.0F, this.strokewidth / 2.0F);
    localPath2.lineTo(paramCanvas.getWidth() - this.strokewidth / 2.0F, this.strokewidth / 2.0F);
    localPath2.lineTo(paramCanvas.getWidth() - this.strokewidth / 2.0F, paramCanvas.getHeight() - this.strokewidth / 2.0F);
    localPath2.lineTo(0.0F, paramCanvas.getHeight() - this.strokewidth / 2.0F);
    localPath2.moveTo(this.strokewidth / 2.0F, paramCanvas.getHeight() - this.strokewidth / 2.0F);
    localPath2.lineTo(this.strokewidth / 2.0F, SquareProgressView.DrawStop.access$100(localDrawStop2));
    paramCanvas.drawPath(localPath2, this.progressBarPaint);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("SquareProgressView.stop.event".equals(paramString))
      stop();
    do
      return;
    while (!"SquareProgressView.start.event".equals(paramString));
    start();
  }

  public void pause()
  {
    removeCallbacks(this.progressTaskRunnable);
  }

  public void setCenterline(boolean paramBoolean)
  {
    this.centerline = paramBoolean;
    invalidate();
  }

  public void setClearOnHundred(boolean paramBoolean)
  {
    this.clearOnHundred = paramBoolean;
    invalidate();
  }

  public void setColor(int paramInt)
  {
    this.progressBarPaint.setColor(paramInt);
    invalidate();
  }

  public void setIndeterminate(boolean paramBoolean)
  {
    this.isIndeterminate = paramBoolean;
    invalidate();
  }

  public void setOnProgressChangeListener(SquareProgressView.OnProgressChangeListener paramOnProgressChangeListener)
  {
    this.onProgressChangeListener = paramOnProgressChangeListener;
  }

  public void setOutline(boolean paramBoolean)
  {
    this.outline = paramBoolean;
    invalidate();
  }

  public void setProgress(double paramDouble)
  {
    this.progress = paramDouble;
    invalidate();
  }

  public void setShowProgress(boolean paramBoolean)
  {
    this.showProgress = paramBoolean;
    invalidate();
  }

  public void setStartline(boolean paramBoolean)
  {
    this.startline = paramBoolean;
    invalidate();
  }

  public void setTimeMillis(long paramLong)
  {
    this.timeMillis = paramLong;
  }

  public void setWidthInDp(int paramInt)
  {
    this.widthInDp = paramInt;
    this.progressBarPaint.setStrokeWidth(CalculationUtil.convertDpToPx(this.widthInDp, getContext()));
    invalidate();
  }

  public void start()
  {
    pause();
    post(this.progressTaskRunnable);
  }

  public void stop()
  {
    pause();
    this.progress = 0.0D;
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle11.video.widget.squareprogressbar.SquareProgressView
 * JD-Core Version:    0.6.0
 */