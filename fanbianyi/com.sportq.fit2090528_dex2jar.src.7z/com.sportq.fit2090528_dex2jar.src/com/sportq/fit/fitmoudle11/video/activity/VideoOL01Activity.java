package com.sportq.fit.fitmoudle11.video.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewStub;
import android.view.Window;
import com.danikula.videocache.CacheListener;
import com.danikula.videocache.HttpProxyCacheServer;
import com.growingio.android.sdk.autoburry.VdsAgent;
import com.growingio.android.sdk.instrumentation.Instrumented;
import com.sportq.fit.browsepresenter.BrowsePresenter;
import com.sportq.fit.common.event.VideoLikeEvent;
import com.sportq.fit.common.interfaces.dialog.DialogInterface;
import com.sportq.fit.common.interfaces.presenter.browse.BrowseInterface;
import com.sportq.fit.common.model.BrowseEntity;
import com.sportq.fit.common.model.CacheDBModel;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.common.reformer.BrowseVideoListReformer;
import com.sportq.fit.common.utils.BrowseLikeStatusAlbumSaveTools;
import com.sportq.fit.common.utils.CompDeviceInfoUtils;
import com.sportq.fit.common.utils.LogUtils;
import com.sportq.fit.common.utils.ToastUtils;
import com.sportq.fit.fitmoudle.AnimationUtil;
import com.sportq.fit.fitmoudle.BaseActivity;
import com.sportq.fit.fitmoudle.dialogmanager.DialogManager;
import com.sportq.fit.fitmoudle.dialogmanager.MaterialDialog;
import com.sportq.fit.fitmoudle.widget.CustomToolBar;
import com.sportq.fit.fitmoudle11.video.R.id;
import com.sportq.fit.fitmoudle11.video.R.layout;
import com.sportq.fit.fitmoudle11.video.R.menu;
import com.sportq.fit.fitmoudle11.video.R.mipmap;
import com.sportq.fit.fitmoudle11.video.R.style;
import com.sportq.fit.fitmoudle11.video.event.NetWorkEvent;
import com.sportq.fit.fitmoudle11.video.event.PlayVideoOLEvent;
import com.sportq.fit.fitmoudle11.video.interfaces.VideoOL01View;
import com.sportq.fit.fitmoudle11.video.manager.cachemanager.CacheManager;
import com.sportq.fit.fitmoudle11.video.presenter.VideoOL01Presenter;
import com.sportq.fit.fitmoudle11.video.reformer.VideoOL01Reformer;
import com.sportq.fit.fitmoudle11.video.utils.SharePreferenceUtils11;
import com.sportq.fit.fitmoudle11.video.widget.VideoOLShareDialog;
import com.sportq.fit.fitmoudle11.video.widget.sptvideoplayerol.SptVideoPlayerOL;
import com.sportq.fit.videopresenter.manager.cachemanager.VideoCacheDBManager;
import com.sportq.fit.videopresenter.manager.cachemanager.VideoCacheManager;
import com.tencent.bugly.crashreport.CrashReport;
import java.io.File;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class VideoOL01Activity extends BaseActivity
  implements VideoOL01View, CacheListener
{
  private BrowseVideoListReformer browseVideoListReformer;

  @SuppressLint({"HandlerLeak"})
  private Handler handler = new VideoOL01Activity.1(this);
  private String isLike;
  private CustomToolBar mToolbar;
  private SptVideoPlayerOL mVideoPlayer;
  private MaterialDialog materialDialog;
  private MenuItem menuItem;
  private VideoOL01Presenter presenter;
  private VideoOLShareDialog shareDialog;
  private BrowseLikeStatusAlbumSaveTools statusAlbumSaveTools;

  private void checkNetWork()
  {
    if (("1".equals(CompDeviceInfoUtils.getAPNType(this))) || (!CompDeviceInfoUtils.checkNetwork()) || (CacheManager.getProxy().isCached(this.presenter.getReformer().videoURL)))
      return;
    if (this.materialDialog == null)
      this.materialDialog = new MaterialDialog(this).setContentView(R.layout.videool_dialog_choise);
    if (!this.materialDialog.ismHasShow())
      this.materialDialog.show();
    if ((this.mVideoPlayer != null) && (this.mVideoPlayer.isPlaying()))
    {
      CacheManager.destroy();
      this.mVideoPlayer.releaseMediaPlayer();
    }
    this.materialDialog.findViewById(R.id.cancel_btn).setOnClickListener(new VideoOL01Activity.4(this));
    this.materialDialog.findViewById(R.id.confirm_btn).setOnClickListener(new VideoOL01Activity.5(this));
  }

  private void hideShareDialog()
  {
    if ((this.shareDialog != null) && (this.shareDialog.isShowing()));
    try
    {
      this.shareDialog.dismiss();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  private void initView()
  {
    this.mToolbar = ((CustomToolBar)findViewById(R.id.toolbar));
    this.mToolbar.setNavIcon(R.mipmap.btn_back_white);
    this.mToolbar.setTitleTextColor(-1);
    setSupportActionBar(this.mToolbar);
    this.dialog = new DialogManager();
    this.mVideoPlayer = ((SptVideoPlayerOL)findViewById(R.id.videoPlayer));
    this.mVideoPlayer.setVideoOL01Handler(this.handler);
  }

  private void showShareDialog()
  {
    if (this.shareDialog == null)
    {
      this.shareDialog = new VideoOLShareDialog(this, R.style.videoolDialog);
      this.shareDialog.setOnDismissListener(new VideoOL01Activity.6(this));
    }
    this.mVideoPlayer.hideController();
    this.shareDialog.setVideoLists(this.presenter.getReformer().shareDialogVideoList);
    this.shareDialog.setModel(this.presenter.getCurrentVideoEntity());
    this.shareDialog.setDialog(this.dialog);
    this.shareDialog.setCompletion(this.presenter.getReformer().isCompleted);
    this.shareDialog.show();
    this.presenter.getReformer().isShareDialogShowing = true;
  }

  public void exit()
  {
    removeCacheIfNeed();
    EventBus.getDefault().post(this.browseVideoListReformer);
    finish();
  }

  public <T> void getDataFail(T paramT)
  {
    super.getDataFail(paramT);
    ToastUtils.makeToast(this, String.valueOf(paramT));
  }

  public <T> void getDataSuccess(T paramT)
  {
    super.getDataSuccess(paramT);
    if ((paramT instanceof VideoOL01Reformer))
      setData((VideoOL01Reformer)paramT);
  }

  public void initLayout(Bundle paramBundle)
  {
    setContentView(R.layout.activity_videool01);
    getWindow().addFlags(1024);
    getWindow().addFlags(128);
    getWindow().addFlags(4194304);
    EventBus.getDefault().register(this);
    this.presenter = new VideoOL01Presenter(this);
    this.statusAlbumSaveTools = new BrowseLikeStatusAlbumSaveTools(this);
    if (paramBundle != null)
    {
      this.browseVideoListReformer = ((BrowseVideoListReformer)paramBundle.getSerializable("reformer"));
      VideoOL01Reformer localVideoOL01Reformer = (VideoOL01Reformer)paramBundle.getSerializable("videoOL01Reformer");
      this.presenter.setReformer(localVideoOL01Reformer);
    }
    if (this.browseVideoListReformer == null)
      this.browseVideoListReformer = ((BrowseVideoListReformer)getIntent().getSerializableExtra("reformer"));
    initView();
    if (!SharePreferenceUtils11.getGuideVideool(this))
      showGuideView();
    while (true)
    {
      this.presenter.initReformer(this.browseVideoListReformer);
      return;
      this.mVideoPlayer.loading();
    }
  }

  public void like(boolean paramBoolean)
  {
    BrowsePresenter localBrowsePresenter = new BrowsePresenter(this);
    RequestModel localRequestModel = new RequestModel();
    localRequestModel.contentId = this.presenter.getCurrentVideoEntity().tpcId;
    localRequestModel.likeType = "1";
    if (paramBoolean);
    for (String str = "0"; ; str = "1")
    {
      localRequestModel.flg = str;
      localBrowsePresenter.addLike(localRequestModel, this);
      return;
    }
  }

  public void menuLikeUI(MenuItem paramMenuItem, boolean paramBoolean)
  {
    BrowseLikeStatusAlbumSaveTools localBrowseLikeStatusAlbumSaveTools;
    String str1;
    if (paramBoolean)
    {
      paramMenuItem.setIcon(R.mipmap.icn_favorited);
      paramMenuItem.setChecked(paramBoolean);
      localBrowseLikeStatusAlbumSaveTools = this.statusAlbumSaveTools;
      str1 = this.presenter.getCurrentVideoEntity().tpcId;
      if (!paramBoolean)
        break label85;
    }
    label85: for (String str2 = "1"; ; str2 = "0")
    {
      localBrowseLikeStatusAlbumSaveTools.putVideoLikeFlg(str1, str2);
      EventBus.getDefault().post(new VideoLikeEvent(paramBoolean));
      return;
      paramMenuItem.setIcon(R.mipmap.icn_favorite_white);
      break;
    }
  }

  public void onCacheAvailable(File paramFile, String paramString, int paramInt)
  {
    LogUtils.d("percentsAvailable:", String.valueOf(paramInt));
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(R.menu.menu_video_ol, paramMenu);
    this.menuItem = paramMenu.findItem(R.id.menu_like);
    menuLikeUI(this.menuItem, "1".equals(this.isLike));
    return super.onCreateOptionsMenu(paramMenu);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    this.mVideoPlayer.destroy();
    EventBus.getDefault().unregister(this);
  }

  @Subscribe
  public void onEventMainThread(NetWorkEvent paramNetWorkEvent)
  {
    LogUtils.d("VideoOL01Activity->onEventMainThread->:", "网络变化监听");
    checkNetWork();
  }

  @Subscribe
  public void onEventMainThread(PlayVideoOLEvent paramPlayVideoOLEvent)
  {
    hideShareDialog();
    BrowseVideoListReformer localBrowseVideoListReformer = this.browseVideoListReformer;
    localBrowseVideoListReformer.curPlayIndex += paramPlayVideoOLEvent.position;
    this.presenter.playNext(this.browseVideoListReformer);
  }

  @Subscribe
  public void onEventMainThread(String paramString)
  {
    if ("SptVideoPlayerOL.event.next.video".equals(paramString))
    {
      hideShareDialog();
      this.presenter.playNext(this.browseVideoListReformer);
    }
    do
      return;
    while (!"SptVideoPlayerOL.event.finished".equals(paramString));
    removeCacheIfNeed();
    showShareDialog();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      exit();
      return true;
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  @Instrumented
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    VdsAgent.onOptionsItemSelected(this, paramMenuItem);
    int i = paramMenuItem.getItemId();
    boolean bool2;
    switch (i)
    {
    default:
      if (i != R.id.menu_like)
        break label106;
      bool2 = paramMenuItem.isChecked();
      if (bool2)
        break;
    case 16908332:
    }
    for (boolean bool3 = true; ; bool3 = false)
    {
      menuLikeUI(paramMenuItem, bool3);
      like(bool2);
      this.mVideoPlayer.resetHideTimer();
      VdsAgent.handleClickResult(new Boolean(true));
      return true;
      exit();
      AnimationUtil.pageJumpAnim(this, 1);
      break;
    }
    label106: if (i == R.id.menu_share)
    {
      this.mVideoPlayer.hideController();
      onPause();
      showShareDialog();
      VdsAgent.handleClickResult(new Boolean(true));
      return true;
    }
    boolean bool1 = super.onOptionsItemSelected(paramMenuItem);
    VdsAgent.handleClickResult(new Boolean(bool1));
    return bool1;
  }

  protected void onPause()
  {
    super.onPause();
    if (this.mVideoPlayer != null)
      this.mVideoPlayer.onPause();
    if (this.shareDialog != null)
      this.shareDialog.onPause();
  }

  protected void onResume()
  {
    super.onResume();
    if ((this.presenter != null) && (!this.presenter.getReformer().isShareDialogShowing) && (this.mVideoPlayer != null))
      this.mVideoPlayer.onResume();
    try
    {
      if (this.dialog != null)
        this.dialog.closeDialog();
      if ((this.shareDialog != null) && (this.shareDialog.isShowing()))
        this.shareDialog.onResume();
      return;
    }
    catch (Exception localException)
    {
      LogUtils.e(localException);
    }
  }

  public void onSaveInstanceState(Bundle paramBundle)
  {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putSerializable("reformer", this.browseVideoListReformer);
    paramBundle.putSerializable("videoOL01Reformer", this.presenter.getReformer());
  }

  public void removeCacheIfNeed()
  {
    try
    {
      if (VideoCacheDBManager.getIntance().selectCache(this.presenter.getCurrentVideoEntity().tpcId) == null)
      {
        CacheDBModel localCacheDBModel = new CacheDBModel();
        localCacheDBModel.videoURL = this.presenter.getReformer().videoURL;
        VideoCacheManager.deleteCache(localCacheDBModel);
        VideoCacheManager.deleteDownLoadFile(localCacheDBModel);
      }
      return;
    }
    catch (Exception localException)
    {
      CrashReport.postCatchedException(new Throwable(localException + "看看视频播放完成删除缓存报错"));
    }
  }

  public void setData(VideoOL01Reformer paramVideoOL01Reformer)
  {
    this.mToolbar.post(new VideoOL01Activity.3(this, paramVideoOL01Reformer));
    this.isLike = this.statusAlbumSaveTools.getVideoLikeFlg(this.presenter.getCurrentVideoEntity().tpcId);
    if (this.menuItem != null)
      menuLikeUI(this.menuItem, "1".equals(this.isLike));
    this.mVideoPlayer.initData(paramVideoOL01Reformer);
  }

  public void showGuideView()
  {
    this.mVideoPlayer.hideController();
    ((ViewStub)findViewById(R.id.guideView)).inflate().setOnClickListener(new VideoOL01Activity.2(this));
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.fitmoudle11.video.activity.VideoOL01Activity
 * JD-Core Version:    0.6.0
 */