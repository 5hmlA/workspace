package com.sportq.fit.browsepresenter;

import android.content.Context;
import com.sportq.fit.common.constant.EnumConstant.FitUrl;
import com.sportq.fit.common.interfaces.FitInterfaceUtils.UIInitListener;
import com.sportq.fit.common.interfaces.api.ApiInterface;
import com.sportq.fit.common.interfaces.presenter.browse.BrowseInterface;
import com.sportq.fit.common.model.request.RequestModel;
import com.sportq.fit.middlelib.statistics.FitAction;
import com.sportq.fit.supportlib.http.ApiImpl;
import com.sportq.fit.supportlib.http.reformer.AddLikeReformerImpl;
import com.sportq.fit.supportlib.http.reformer.ReformerImpl;

public class BrowsePresenter
  implements BrowseInterface
{
  private ApiInterface apiInterface = new ApiImpl();
  private FitInterfaceUtils.UIInitListener listener;

  public BrowsePresenter(FitInterfaceUtils.UIInitListener paramUIInitListener)
  {
    this.listener = paramUIInitListener;
  }

  public void addLike(RequestModel paramRequestModel, Context paramContext)
  {
    try
    {
      ReformerImpl localReformerImpl = new ReformerImpl(new AddLikeReformerImpl());
      String str = localReformerImpl.getURL(EnumConstant.FitUrl.ADD_LIKE);
      this.apiInterface.getHttp(str, paramContext, this.listener, localReformerImpl, paramRequestModel);
      return;
    }
    catch (Exception localException)
    {
      FitAction.upload_e("BrowsePresenter.addLike", localException);
    }
  }
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.browsepresenter.BrowsePresenter
 * JD-Core Version:    0.6.0
 */