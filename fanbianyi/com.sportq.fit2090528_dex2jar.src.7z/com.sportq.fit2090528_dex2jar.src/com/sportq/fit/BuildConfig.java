package com.sportq.fit;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "com.sportq.fit";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = 360;
  public static final String VERSION_NAME = "5.0.6";
}

/* Location:           D:\0_0DevTools\Android\fanbianyi\com.sportq.fit6154960_dex2jar.jar
 * Qualified Name:     com.sportq.fit.BuildConfig
 * JD-Core Version:    0.6.0
 */